//***
// Action
//   - Detach and attach database to the SQL Server
// Created
//   - CopyPaste � 20260717 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260717 � VVDW
// Proposal (To Do)
//   - 
//***

using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;
using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDetachAttach: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblAttachedDatabase;
    internal System.Windows.Forms.TextBox txtNameOfAttach;
    internal System.Windows.Forms.TextBox txtFileToAttach;
    internal System.Windows.Forms.Button cmdLocateFile;
    internal System.Windows.Forms.Label lblFile;
    internal System.Windows.Forms.Button cmdAttach;
    internal System.Windows.Forms.TabPage pagAttach;
    internal System.Windows.Forms.OpenFileDialog dlgOpen;
    internal System.Windows.Forms.Label lblDatabase;
    internal System.Windows.Forms.ListBox lstDatabase;
    internal System.Windows.Forms.Button cmdDetach;
    internal System.Windows.Forms.TabPage pagDetach;
    internal System.Windows.Forms.TabControl tabDetachAttach;
    internal System.Windows.Forms.Label lblSQLServer;
    internal System.Windows.Forms.ListBox lstSQLServer;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDetachAttach));
      this.lblAttachedDatabase = new System.Windows.Forms.Label();
      this.txtNameOfAttach = new System.Windows.Forms.TextBox();
      this.txtFileToAttach = new System.Windows.Forms.TextBox();
      this.cmdLocateFile = new System.Windows.Forms.Button();
      this.lblFile = new System.Windows.Forms.Label();
      this.cmdAttach = new System.Windows.Forms.Button();
      this.pagAttach = new System.Windows.Forms.TabPage();
      this.dlgOpen = new System.Windows.Forms.OpenFileDialog();
      this.lblDatabase = new System.Windows.Forms.Label();
      this.lstDatabase = new System.Windows.Forms.ListBox();
      this.cmdDetach = new System.Windows.Forms.Button();
      this.pagDetach = new System.Windows.Forms.TabPage();
      this.tabDetachAttach = new System.Windows.Forms.TabControl();
      this.lblSQLServer = new System.Windows.Forms.Label();
      this.lstSQLServer = new System.Windows.Forms.ListBox();
      this.pagAttach.SuspendLayout();
      this.pagDetach.SuspendLayout();
      this.tabDetachAttach.SuspendLayout();
      this.SuspendLayout();
      // 
      // lblAttachedDatabase
      // 
      this.lblAttachedDatabase.Location = new System.Drawing.Point(16, 88);
      this.lblAttachedDatabase.Name = "lblAttachedDatabase";
      this.lblAttachedDatabase.Size = new System.Drawing.Size(160, 16);
      this.lblAttachedDatabase.TabIndex = 2;
      this.lblAttachedDatabase.Text = "Name of Attached Database";
      // 
      // txtNameOfAttach
      // 
      this.txtNameOfAttach.Location = new System.Drawing.Point(16, 112);
      this.txtNameOfAttach.Multiline = true;
      this.txtNameOfAttach.Name = "txtNameOfAttach";
      this.txtNameOfAttach.Size = new System.Drawing.Size(280, 24);
      this.txtNameOfAttach.TabIndex = 3;
      this.txtNameOfAttach.Text = "";
      this.txtNameOfAttach.TextChanged += new System.EventHandler(this.txtNameOfAttach_TextChanged);
      // 
      // txtFileToAttach
      // 
      this.txtFileToAttach.Location = new System.Drawing.Point(16, 40);
      this.txtFileToAttach.Multiline = true;
      this.txtFileToAttach.Name = "txtFileToAttach";
      this.txtFileToAttach.Size = new System.Drawing.Size(280, 40);
      this.txtFileToAttach.TabIndex = 1;
      this.txtFileToAttach.Text = "";
      this.txtFileToAttach.TextChanged += new System.EventHandler(this.txtFileToAttach_TextChanged);
      // 
      // cmdLocateFile
      // 
      this.cmdLocateFile.Location = new System.Drawing.Point(309, 43);
      this.cmdLocateFile.Name = "cmdLocateFile";
      this.cmdLocateFile.Size = new System.Drawing.Size(78, 34);
      this.cmdLocateFile.TabIndex = 4;
      this.cmdLocateFile.Text = "&Locate File";
      this.cmdLocateFile.Click += new System.EventHandler(this.cmdLocateFile_Click);
      // 
      // lblFile
      // 
      this.lblFile.Location = new System.Drawing.Point(16, 16);
      this.lblFile.Name = "lblFile";
      this.lblFile.Size = new System.Drawing.Size(120, 16);
      this.lblFile.TabIndex = 0;
      this.lblFile.Text = "File to Attach";
      // 
      // cmdAttach
      // 
      this.cmdAttach.Enabled = false;
      this.cmdAttach.Location = new System.Drawing.Point(312, 104);
      this.cmdAttach.Name = "cmdAttach";
      this.cmdAttach.Size = new System.Drawing.Size(80, 40);
      this.cmdAttach.TabIndex = 5;
      this.cmdAttach.Text = "&Attach Database";
      this.cmdAttach.Click += new System.EventHandler(this.cmdAttach_Click);
      // 
      // pagAttach
      // 
      this.pagAttach.Controls.Add(this.lblAttachedDatabase);
      this.pagAttach.Controls.Add(this.txtNameOfAttach);
      this.pagAttach.Controls.Add(this.cmdLocateFile);
      this.pagAttach.Controls.Add(this.lblFile);
      this.pagAttach.Controls.Add(this.txtFileToAttach);
      this.pagAttach.Controls.Add(this.cmdAttach);
      this.pagAttach.Location = new System.Drawing.Point(4, 22);
      this.pagAttach.Name = "pagAttach";
      this.pagAttach.Size = new System.Drawing.Size(409, 171);
      this.pagAttach.TabIndex = 1;
      this.pagAttach.Text = "Attach Database";
      this.pagAttach.Visible = false;
      // 
      // lblDatabase
      // 
      this.lblDatabase.Location = new System.Drawing.Point(8, 8);
      this.lblDatabase.Name = "lblDatabase";
      this.lblDatabase.Size = new System.Drawing.Size(104, 16);
      this.lblDatabase.TabIndex = 0;
      this.lblDatabase.Text = "Databases";
      // 
      // lstDatabase
      // 
      this.lstDatabase.Location = new System.Drawing.Point(8, 32);
      this.lstDatabase.Name = "lstDatabase";
      this.lstDatabase.Size = new System.Drawing.Size(104, 134);
      this.lstDatabase.TabIndex = 1;
      this.lstDatabase.SelectedIndexChanged += new System.EventHandler(this.lstDatabase_SelectedIndexChanged);
      // 
      // cmdDetach
      // 
      this.cmdDetach.Enabled = false;
      this.cmdDetach.Location = new System.Drawing.Point(318, 118);
      this.cmdDetach.Name = "cmdDetach";
      this.cmdDetach.Size = new System.Drawing.Size(80, 40);
      this.cmdDetach.TabIndex = 2;
      this.cmdDetach.Text = "Detach Database";
      this.cmdDetach.Click += new System.EventHandler(this.cmdDetach_Click);
      // 
      // pagDetach
      // 
      this.pagDetach.Controls.Add(this.lblDatabase);
      this.pagDetach.Controls.Add(this.lstDatabase);
      this.pagDetach.Controls.Add(this.cmdDetach);
      this.pagDetach.Location = new System.Drawing.Point(4, 22);
      this.pagDetach.Name = "pagDetach";
      this.pagDetach.Size = new System.Drawing.Size(409, 171);
      this.pagDetach.TabIndex = 0;
      this.pagDetach.Text = "Detach Database";
      // 
      // tabDetachAttach
      // 
      this.tabDetachAttach.Controls.Add(this.pagDetach);
      this.tabDetachAttach.Controls.Add(this.pagAttach);
      this.tabDetachAttach.ItemSize = new System.Drawing.Size(96, 18);
      this.tabDetachAttach.Location = new System.Drawing.Point(146, 19);
      this.tabDetachAttach.Name = "tabDetachAttach";
      this.tabDetachAttach.SelectedIndex = 0;
      this.tabDetachAttach.Size = new System.Drawing.Size(417, 197);
      this.tabDetachAttach.TabIndex = 5;
      // 
      // lblSQLServer
      // 
      this.lblSQLServer.Location = new System.Drawing.Point(14, 21);
      this.lblSQLServer.Name = "lblSQLServer";
      this.lblSQLServer.Size = new System.Drawing.Size(104, 16);
      this.lblSQLServer.TabIndex = 3;
      this.lblSQLServer.Text = "SQL Servers";
      // 
      // lstSQLServer
      // 
      this.lstSQLServer.Location = new System.Drawing.Point(17, 44);
      this.lstSQLServer.Name = "lstSQLServer";
      this.lstSQLServer.Size = new System.Drawing.Size(104, 173);
      this.lstSQLServer.TabIndex = 4;
      this.lstSQLServer.SelectedIndexChanged += new System.EventHandler(this.lstSQLServer_SelectedIndexChanged);
      // 
      // frmDetachAttach
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(576, 237);
      this.Controls.Add(this.lblSQLServer);
      this.Controls.Add(this.lstSQLServer);
      this.Controls.Add(this.tabDetachAttach);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDetachAttach";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Creating a Detach/Attach SQL Server Database Dialog  ";
      this.Load += new System.EventHandler(this.frmDetachAttach_Load);
      this.pagAttach.ResumeLayout(false);
      this.pagDetach.ResumeLayout(false);
      this.tabDetachAttach.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDetachAttach'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDetachAttach()
      //***
      // Action
      //   - Create instance of 'frmDetachAttach'
      // Called by
      //   - 
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDetachAttach()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAttach_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a string
      //   - Define and initialize a SQLServer
      //   - Try to
      //     - Connect to the SQL Server with Windows Security
      //     - Detach the database
      //     - Refresh the list of database
      //   - On possible error
      //     - Show corresponding messagebox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpSQLDMORoutines.GetSQLDatabase(String, �ListBox)
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      StringCollection theCollection = new StringCollection();
      Server theSQLServer;
      
      try
      {
        theSQLServer = new Server(lstSQLServer.SelectedItem.ToString());
        theSQLServer.ConnectionContext.Connect();
        theCollection.Add(txtFileToAttach.Text);
        theSQLServer.AttachDatabase(txtNameOfAttach.Text, theCollection);
        cpSQLDMORoutines.GetSQLDatabase(lstSQLServer.SelectedItem.ToString(), ref lstDatabase);
        MessageBox.Show("Database Attached");
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // cmdAttach_Click(System.Object, System.EventArgs) Handles cmdAttach.Click

    private void cmdDetach_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a string
      //   - Define and initialize a SQLServer
      //   - Try to
      //     - Connect to the SQL Server with Windows Security
      //     - Detach the database
      //     - Refresh the list of database
      //   - On possible error
      //     - Show corresponding messagebox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpSQLDMORoutines.GetSQLDatabase(String, �ListBox)
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Server theSQLServer;

      try
      {
        theSQLServer = new Server(lstSQLServer.SelectedItem.ToString());
        theSQLServer.ConnectionContext.Connect();
        theSQLServer.DetachDatabase(lstDatabase.SelectedItem.ToString(), false);
        cpSQLDMORoutines.GetSQLDatabase(lstSQLServer.SelectedItem.ToString(), ref lstDatabase);
        MessageBox.Show("Database Detached");
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // cmdDetach_Click(System.Object, System.EventArgs) Handles cmdDetach.Click

    private void cmdLocateFile_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a file open dialog
      //   - Set the directory
      //   - Set the filter
      //   - Show the dialog
      //   - Set the selected filename
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dlgOpen.InitialDirectory = "S:\\Data\\";
      dlgOpen.Filter = "SQL Server Database files (*.mdf)|*.mdf";
      dlgOpen.ShowDialog();
      txtFileToAttach.Text = dlgOpen.FileName;
    }
    // cmdLocateFile_Click(System.Object, System.EventArgs) Handles cmdLocateFile.Click

    private void frmDetachAttach_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Load the list of SQL Servers
      // Called by
      //   - User action (Starting a form)
      // Calls
      //   - cpSQLDMORoutines.LoadSQLServer(�ListBox)
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpSQLDMORoutines.LoadSQLServer(ref lstSQLServer);
    }
    // frmDetachAttach_Load(System.Object, System.EventArgs) Handles this.Load

    private void lstDatabase_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If a server is selected and a database is selected
      //     - Enable the detach button
      //   - If not
      //     - Disable the detach button
      // Called by
      //   - User action (Choosing an option)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if ((lstSQLServer.SelectedItems.Count > 0) && (lstDatabase.SelectedItems.Count > 0))
      {
        cmdDetach.Enabled = true;
      }
      else
        // lstSQLServer.SelectedItems.Count <= 0 OrElse lstDatabase.SelectedItems.Count <= 0
      {
        cmdDetach.Enabled = false;
      }
      // lstSQLServer.SelectedItems.Count > 0 AndAlso lstDatabase.SelectedItems.Count > 0
    
    }
    // lstDatabase_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstDatabase.SelectedIndexChanged

    private void lstSQLServer_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If a server is selected and a database is selected
      //     - Enable the detach button
      //   - If not
      //     - Disable the detach button
      // Called by
      //   - User action (Choosing an option)
      // Calls
      //   - cpSQLDMORoutines.GetSQLDatabase(String, �ListBox)
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if ((lstSQLServer.SelectedItems.Count > 0) && (lstDatabase.SelectedItems.Count > 0)) 
      {
        cmdDetach.Enabled = true;
      }
      else
        // lstSQLServer.SelectedItems.Count <= 0 OrElse lstDatabase.SelectedItems.Count <= 0
      {
        cmdDetach.Enabled = false;
      }
      // lstSQLServer.SelectedItems.Count > 0 AndAlso lstDatabase.SelectedItems.Count > 0

      cpSQLDMORoutines.GetSQLDatabase(lstSQLServer.SelectedItem.ToString(), ref lstDatabase);
    }
    // lstSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstSQLServer.SelectedIndexChanged

    private void txtNameOfAttach_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If textbox of the file and name are filled in
      //     - Enable the attach button
      //   - If not
      //     - Disable the attach button
      // Called by
      //   - User action (Changing a textbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if ((txtFileToAttach.Text.Length > 0) && (txtNameOfAttach.Text.Length > 0))
      {
        cmdAttach.Enabled = true;
      }
      else
        // txtFileToAttach.Text.Length <= 0 OrElse txtNameOfAttach.Text.Length <= 0
      {
        cmdAttach.Enabled = false;
      }
      // txtFileToAttach.Text.Length > 0 AndAlso txtNameOfAttach.Text.Length > 0
    
    }
    // txtNameOfAttach_TextChanged(System.Object, System.EventArgs) Handles txtNameOfAttach.TextChanged

    private void txtFileToAttach_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If textbox of the file and name are filled in
      //     - Enable the attach button
      //   - If not
      //     - Disable the attach button
      // Called by
      //   - User action (Changing a textbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if ((txtFileToAttach.Text.Length > 0) && (txtNameOfAttach.Text.Length > 0))
      {
        cmdAttach.Enabled = true;
      }
      else
        // txtFileToAttach.Text.Length <= 0 OrElse txtNameOfAttach.Text.Length <= 0
      {
        cmdAttach.Enabled = false;
      }
      // txtFileToAttach.Text.Length > 0 AndAlso txtNameOfAttach.Text.Length > 0
    
    }
    // txtFileToAttach_TextChanged(System.Object, System.EventArgs) Handles txtFileToAttach.TextChanged

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDetachAttach

}
// CopyPaste.Learning