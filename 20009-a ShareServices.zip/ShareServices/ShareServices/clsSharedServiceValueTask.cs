﻿//***
// Action
//   - Definition of Shared Service Value Task
// Created
//   - CopyPaste – 20251222 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251222 – VVDW
// Proposal (To Do)
//   - You have to install a NuGet package System.Threading.Tasks.Extensions
//***

using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  public class cpSharedServiceValueTask
  {

    #region "Constructors / Destructors"

    public cpSharedServiceValueTask(int intNumberOfSeconds)
    //***
    // Action
    //   - Basic constructor
    //   - TimeSpan cache set to 2 seconds
    // Called by
    //   - cpProgram.RunSharedServiceValueTask()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251221 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251221 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      tspCache = TimeSpan.FromSeconds(2);
    }
    // cpSharedServiceValueTask(int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private DateTime dtmLastRun;
    private IEnumerable<cpStockNasDaq> theCachedListings;
    private readonly TimeSpan tspCache;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private async Task<IEnumerable<cpStockNasDaq>> GetShareDetails()
    //***
    // Action
    //   - Create a list of cpStockNasDaq with some hardcoded values (wait for the result)
    //     - Three cpStockNasDaq items
    //   - Set the last run time to now
    //   - Mention in the console that share details were retrieved (so that not the cache is used)
    //   - Return the result 
    // Called by
    //   - ValueTask<IEnumerable<cpStockNasDaq>> GetStockDetails()
    // Calls
    //   - cpStockNasDaq(string, decimal, decimal, decimal, long)
    // Created
    //   - CopyPaste – 20251221 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251221 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theCachedListings = await Task.Run(
        () => new List<cpStockNasDaq>
          {
            new cpStockNasDaq("AAPL", 157.50m, 158.52m, 154.55m, 74137),
            new cpStockNasDaq("AMZN", 1473.35m, 1513.47m, 1449.00m, 72271),
            new cpStockNasDaq("QCOM", 56.33m, 57.53m, 56.24m, 6886)
          }
        );

      dtmLastRun = DateTime.Now;
      Console.WriteLine($"Get share details - {dtmLastRun}");
      return theCachedListings;
    }
    // Task<IEnumerable<cpStockNasDaq>> GetShareDetails()

    public ValueTask<IEnumerable<cpStockNasDaq>> GetStockDetails()
    //***
    // Action
    //   - If timespan is not passed
    //     - Return the cached listings
    //   - If not
    //     - Return the share details (wait for the result)
    //     - This is mentioned in the console
    // Called by
    //   - 
    // Calls
    //   - Task<IEnumerable<cpStockNasDaq>> GetShareDetails()
    // Created
    //   - CopyPaste – 20251221 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251221 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ValueTask<IEnumerable<cpStockNasDaq>> theResult;

      if (DateTime.Now - dtmLastRun < tspCache)
      {
        theResult = new ValueTask<IEnumerable<cpStockNasDaq>>(theCachedListings);
      }
      else
      {
        theResult = new ValueTask<IEnumerable<cpStockNasDaq>>(GetShareDetails());
      }

      return theResult;
    }
    // Task<IEnumerable<cpStockNasDaq>> GetStockDetails()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpSharedServiceValueTask

}
// CopyPaste.Learning