//***
// Action
//   - Example of some default dialogs (File open, Color)
// Created
//   - CopyPaste � 20240516 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240516 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDialogBox: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.PictureBox picPicture;
    internal System.Windows.Forms.Label lblClock;
    internal System.Windows.Forms.OpenFileDialog dlgOpenFile;
    internal System.Windows.Forms.MenuItem mnuFile;
    internal System.Windows.Forms.MenuItem mnuFileOpen;
    internal System.Windows.Forms.MenuItem mnuFileClose;
    internal System.Windows.Forms.MenuItem mnuFileExit;
    internal System.Windows.Forms.MenuItem mnuClock;
    internal System.Windows.Forms.MenuItem mnuClockDate;
    internal System.Windows.Forms.MenuItem mnuClockTime;
    internal System.Windows.Forms.MenuItem mnuClockColor;
    internal System.Windows.Forms.MainMenu mnuMain;
    internal System.Windows.Forms.ColorDialog dlgColor;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDialogBox));
      this.picPicture = new System.Windows.Forms.PictureBox();
      this.lblClock = new System.Windows.Forms.Label();
      this.dlgOpenFile = new System.Windows.Forms.OpenFileDialog();
      this.mnuFile = new System.Windows.Forms.MenuItem();
      this.mnuFileOpen = new System.Windows.Forms.MenuItem();
      this.mnuFileClose = new System.Windows.Forms.MenuItem();
      this.mnuFileExit = new System.Windows.Forms.MenuItem();
      this.mnuClock = new System.Windows.Forms.MenuItem();
      this.mnuClockDate = new System.Windows.Forms.MenuItem();
      this.mnuClockTime = new System.Windows.Forms.MenuItem();
      this.mnuClockColor = new System.Windows.Forms.MenuItem();
      this.mnuMain = new System.Windows.Forms.MainMenu();
      this.dlgColor = new System.Windows.Forms.ColorDialog();
      this.SuspendLayout();
      // 
      // picPicture
      // 
      this.picPicture.Location = new System.Drawing.Point(74, 88);
      this.picPicture.Name = "picPicture";
      this.picPicture.Size = new System.Drawing.Size(144, 128);
      this.picPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picPicture.TabIndex = 4;
      this.picPicture.TabStop = false;
      // 
      // lblClock
      // 
      this.lblClock.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblClock.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblClock.Location = new System.Drawing.Point(74, 24);
      this.lblClock.Name = "lblClock";
      this.lblClock.Size = new System.Drawing.Size(144, 48);
      this.lblClock.TabIndex = 3;
      this.lblClock.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // mnuFile
      // 
      this.mnuFile.Index = 0;
      this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFileOpen,
                                                                            this.mnuFileClose,
                                                                            this.mnuFileExit});
      this.mnuFile.Text = "&File";
      // 
      // mnuFileOpen
      // 
      this.mnuFileOpen.Index = 0;
      this.mnuFileOpen.Text = "&Open ...";
      this.mnuFileOpen.Click += new System.EventHandler(this.mnuFileOpen_Click);
      // 
      // mnuFileClose
      // 
      this.mnuFileClose.Enabled = false;
      this.mnuFileClose.Index = 1;
      this.mnuFileClose.Text = "&Close";
      this.mnuFileClose.Click += new System.EventHandler(this.mnuFileClose_Click);
      // 
      // mnuFileExit
      // 
      this.mnuFileExit.Index = 2;
      this.mnuFileExit.Text = "E&xit";
      this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
      // 
      // mnuClock
      // 
      this.mnuClock.Index = 1;
      this.mnuClock.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                             this.mnuClockDate,
                                                                             this.mnuClockTime,
                                                                             this.mnuClockColor});
      this.mnuClock.Text = "&Clock";
      // 
      // mnuClockDate
      // 
      this.mnuClockDate.Index = 0;
      this.mnuClockDate.Shortcut = System.Windows.Forms.Shortcut.CtrlD;
      this.mnuClockDate.Text = "&Date";
      this.mnuClockDate.Click += new System.EventHandler(this.mnuClockDate_Click);
      // 
      // mnuClockTime
      // 
      this.mnuClockTime.Index = 1;
      this.mnuClockTime.Shortcut = System.Windows.Forms.Shortcut.CtrlT;
      this.mnuClockTime.Text = "&Time";
      this.mnuClockTime.Click += new System.EventHandler(this.mnuClockTime_Click);
      // 
      // mnuClockColor
      // 
      this.mnuClockColor.Index = 2;
      this.mnuClockColor.Text = "&Color Text";
      this.mnuClockColor.Click += new System.EventHandler(this.mnuClockColor_Click);
      // 
      // mnuMain
      // 
      this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFile,
                                                                            this.mnuClock});
      // 
      // frmDialogBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.picPicture);
      this.Controls.Add(this.lblClock);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mnuMain;
      this.Name = "frmDialogBox";
      this.Text = "Menu";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDialogBox'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDialogBox()
      //***
      // Action
      //   - Create instance of 'frmDialogBox'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDialogBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void mnuClockColor_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the color dialog
      //   - Fore color of the clock changes into the choosen color
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dlgColor.ShowDialog();
      lblClock.ForeColor = dlgColor.Color;
    }
    // mnuClockColor_Click(System.Object, System.EventArgs) Handles mnuClockColor.Click

    private void mnuClockDate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Label changes in the current date
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblClock.Text = DateTime.Now.ToString("dd/MM/yyyy");
    }
    // mnuClockDate_Click(System.Object, System.EventArgs) Handles mnuClockDate.Click

    private void mnuClockTime_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Label changes in the current time
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblClock.Text = DateTime.Now.ToString("hh:mm:ss");
    }
    // mnuClockTime_Click(System.Object, System.EventArgs) Handles mnuClockTime.Click

    private void mnuFileClose_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Picture is removed
      //   - Menu Close is disabled
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      picPicture.Image = null;
      mnuFileClose.Enabled = false;
    }
    // mnuFileClose_Click(System.Object, System.EventArgs) Handles mnuFileClose.Click

    private void mnuFileExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Application stops
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // mnuFileExit_Click(System.Object, System.EventArgs) Handles mnuFileExit.Click

    private void mnuFileOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The filter of open dialog is set to jpg
      //   - File open dialog is shown
      //   - If OK button is clicked
      //     - Choosen file is shown in the form
      //     - Close menu is enabled
      //   - If not
      //     - Do nothing
      //   - Menu Close is disabled
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dlgOpenFile.Filter = "Jpeg Picture (*.jpg)|*.jpg";

      if (dlgOpenFile.ShowDialog() == DialogResult.OK)
      {
        picPicture.Image = Image.FromFile(dlgOpenFile.FileName);
        mnuFileClose.Enabled = true;
      }
      else
        // dlgOpenFile.ShowDialog() <> DialogResult.OK
      {
      }
      // dlgOpenFile.ShowDialog() = DialogResult.OK
    
    }
    // mnuFileOpen_Click(System.Object, System.EventArgs) Handles mnuFileOpen.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDialogBox
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDialogBox()
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDialogBox());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDialogBox

}
// CopyPaste.Learning