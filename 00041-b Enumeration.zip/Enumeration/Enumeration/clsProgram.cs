﻿//***
// Action
//   - Basic example of an enumeration
// Created
//   - CopyPaste – 20260624 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260624 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - xxxx
    // Created
    //   - CopyPaste – 20260624 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260624 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpDefault()

    #endregion

    #region "Designer"

    enum Days
    {
      Sat,
      Sun,
      Mon,
      Tue,
      Wed,
      Thu,
      Fri
    };

    #endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Set the console title to Enumeration
    //   - Define and initialize a constant
    //   - Define the data type of an enum
    //   - Get the name of the second item
    //   - Check if some description is defined in the enum
    //   - Show some results on the console based on the variables defined
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260624 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260624 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.Title = "Enumeration";

      const double cdblPi = 3.14159265358979;
      Days aDay = Days.Sun;
      System.Type typDays = typeof(Days);
      string strName = Enum.GetName(typDays, 1);
      bool blnDefined = Enum.IsDefined(typDays, "Mon");

      Console.WriteLine("Pi Type: " + cdblPi.GetType());
      Console.WriteLine("Circumference: " + (cdblPi * 2));
      Console.WriteLine();
      Console.WriteLine("Second Name: " + aDay);
      Console.WriteLine("3th Index: " + (int)Days.Mon);
      Console.WriteLine();
      Console.WriteLine("2nd Index: " + strName);
      Console.WriteLine("Contains Mon?: " + blnDefined);
      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadKey();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx