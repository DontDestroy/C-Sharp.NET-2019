//***
// Action
//   - Demo of some label borders
// Created
//   - CopyPaste � 20240214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240214 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmLabelBorders: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblThird;
    internal System.Windows.Forms.Label lblSecond;
    internal System.Windows.Forms.Label lblFirst;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmLabelBorders));
      this.lblThird = new System.Windows.Forms.Label();
      this.lblSecond = new System.Windows.Forms.Label();
      this.lblFirst = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // lblThird
      // 
      this.lblThird.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblThird.Location = new System.Drawing.Point(32, 141);
      this.lblThird.Name = "lblThird";
      this.lblThird.Size = new System.Drawing.Size(150, 25);
      this.lblThird.TabIndex = 5;
      this.lblThird.Text = "Fixed 3D Border";
      // 
      // lblSecond
      // 
      this.lblSecond.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblSecond.Location = new System.Drawing.Point(32, 81);
      this.lblSecond.Name = "lblSecond";
      this.lblSecond.Size = new System.Drawing.Size(150, 25);
      this.lblSecond.TabIndex = 4;
      this.lblSecond.Text = "Fixed Single Border";
      // 
      // lblFirst
      // 
      this.lblFirst.Location = new System.Drawing.Point(32, 31);
      this.lblFirst.Name = "lblFirst";
      this.lblFirst.Size = new System.Drawing.Size(150, 25);
      this.lblFirst.TabIndex = 3;
      this.lblFirst.Text = "No border";
      // 
      // frmLabelBorders
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 197);
      this.Controls.Add(this.lblThird);
      this.Controls.Add(this.lblSecond);
      this.Controls.Add(this.lblFirst);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmLabelBorders";
      this.Text = "Label Borders";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmLabelBorders'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmLabelBorders()
      //***
      // Action
      //   - Create instance of 'frmLabelBorders'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmLabelBorders()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmLabelBorders
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmLabelBorders());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmLabelBorders

}
// CopyPaste.Learning