In the tools directory a file "InstallUtil.exe" can be found.
It is also part of the .Net library on
  C:\WINDOWS\Microsoft.NET\Framework\your version
  (Can differ on your pc)

A version inside the solution in folder "Tools" of this exercise is added.

Find also the executable of this project

Important.
- First start Visual Studio as Runned as Administrator

To install the service
- Start a command prompt in visual studio and type
  - Tools > Command Line > Developer Command Prompt
  YourPath\installutil YourPath\FileMonitorService.exe

To uninstall the service
- Make sure the Service Management Console is closed
- Start a command prompt and type
  YourPath\installutil /u YourPath\FileMonitorService.exe
