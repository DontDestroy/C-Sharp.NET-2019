//***
// Action
//   - Testroutine of an instance of cpCylinder
// Created
//   - CopyPaste � 20231230 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231230 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Math;
using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace Circle
{

	public class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main()
			//***
			// Action
			//   - Create a new instance of a cpCylinder
			//   - Get some properties
			//   - Set some properties
			//   - Use of ToString()
			//   - Show the diameter
			//   - Show the circumference
			//   - Show the area
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - cpCircle(cpPoint, double)
			//   - cpCircle(int, int, double)
			//   - cpCylinder(cpCircle, double)
			//   - cpCylinder(cpPoint, double, double)
			//   - cpCylinder(int, int, double, double)
			//   - cpCylinder.Height(double) (Set)
			//   - cpCylinder.Radius(double) (Set)
			//   - cpCylinder.X(int) (Set)
			//   - cpCylinder.Y(int) (Set)
			//   - cpPoint(int, int)
			//   - double cpCylinder.Area()
			//   - double cpCylinder.Circumference() 
			//   - double cpCylinder.Diameter()
			//   - double cpCylinder.Height (Get)
			//   - double cpCylinder.Radius (Get)
			//   - int cpCylinder.X (Get)
			//   - int cpCylinder.Y (Get)
			//   - string cpCircle.ToString()
			// Created
			//   - CopyPaste � 20070130 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20070130 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
	  {
      string strOutput;

      // cpPoint thecpPoint = new cpPoint(12, 23);
      // cpCircle thecpCircle = new cpCircle(12, 23, 2.5);
      // cpCircle thecpCircle = new cpCircle(thecpPoint, 2.5);

      cpCylinder thecpCylinder = new cpCylinder(12, 23, 2.5, 5.7);
      // cpCylinder thecpCylinder = new cpCylinder(thecpCircle, 5.7);
      // cpCylinder thecpCylinder = new cpCylinder(thecpPoint, 2.5, 5.7);

      strOutput = "X coordinate is " + thecpCylinder.X + Environment.NewLine +
        "Y coordinate is " + thecpCylinder.Y + Environment.NewLine +
        "Radius is " + thecpCylinder.Radius + Environment.NewLine +
        "Height is " + thecpCylinder.Height;
      MessageBox.Show(strOutput, "Demonstrating Class cpCylinder");

			thecpCylinder.X = 2;
			thecpCylinder.Y = 2;
			thecpCylinder.Height = 10;
			thecpCylinder.Radius = 4.25;

	    strOutput = "The new location, radius and height of cylinder are" + Environment.NewLine + 
		    thecpCylinder.ToString() + Environment.NewLine +
			  "Diameter = " + String.Format("{0:F}", thecpCylinder.Diameter()) + Environment.NewLine +
				"Circumference is " + String.Format("{0:F}", thecpCylinder.Circumference()) + Environment.NewLine +
				"Area is " + String.Format("{0:F}", thecpCylinder.Area()) + Environment.NewLine +
				"Volume is " + String.Format("{0:F}", thecpCylinder.Volume());
			MessageBox.Show(strOutput, "Demonstrating Class cpCylinder");
		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpProgram

}
// Circle