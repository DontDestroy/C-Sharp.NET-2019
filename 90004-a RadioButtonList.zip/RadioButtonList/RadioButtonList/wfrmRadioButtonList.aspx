﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmRadioButtonList.aspx.cs" Inherits="CopyPaste.Learning.wfrmRadioButtonList" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Radio Button List</title>
</head>
<body ms_positioning="GridLayout">
  <form id="wfrmRadioButtonList" method="post" runat="server">
    <asp:RadioButtonList ID="optNames" Style="z-index: 101; position: absolute; top: 24px; left: 32px" runat="server"
      Width="176px" BorderStyle="Solid" BorderWidth="1px" OnSelectedIndexChanged="optNames_SelectedIndexChanged">
      <asp:ListItem Value="John">John</asp:ListItem>
      <asp:ListItem Value="Second">James</asp:ListItem>
      <asp:ListItem Value="Third">Francis</asp:ListItem>
      <asp:ListItem Value="Fourth">Roland</asp:ListItem>
    </asp:RadioButtonList>
    <asp:Label ID="lblResult" Style="z-index: 103; position: absolute; top: 176px; left: 40px"
      runat="server" Width="472px"></asp:Label>
    <asp:Button ID="cmdChoose" Style="z-index: 102; position: absolute; top: 136px; left: 40px"
      runat="server" Width="168px" Text="Select a name and click" OnClick="cmdChoose_Click"></asp:Button>
  </form>
</body>
</html>
