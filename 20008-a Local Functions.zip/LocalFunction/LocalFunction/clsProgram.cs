﻿//***
// Action
//   - Starting point of the example
// Created
//   - CopyPaste – 20251218 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251218 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251218 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251218 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Starting Point
    //   - Try to
    //     - Create a cube
    //     - Show the volume
    //     - Create a pyramid
    //     - Show the volume
    //     - Create a sphere
    //     - Show the volume
    //     - Create a datetime
    //     - Show the volume
    //   - On error
    //     - Show the exception message
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpCube(double) 
    //   - cpPyramid(double, double, double)
    //   - cpSphere(double)
    //   - DisplayResult(System.Object)
    // Created
    //   - CopyPaste – 20251218 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251218 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      double dblSize = 5.0;

      try
      {
        cpCube theCube = new cpCube(dblSize);
        DisplayResult(theCube);

        cpPyramid thePiramid = new cpPyramid(dblSize, dblSize, dblSize);
        DisplayResult(thePiramid);

        cpSphere theSphere = new cpSphere(dblSize);
        DisplayResult(theSphere);

        DateTime theDate = new DateTime(1970, 5, 6);
        DisplayResult(theDate);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error: " + theException.Message);
      }

      Console.ReadLine();
    }
    // Main()

    static public void DisplayResult(System.Object theShape)
    //***
    // Action
    //   - Create a new instace of cpLocalFunction
    //   - Display the result of the volume calculation with 5 decimals
    // Called by
    //   - Main()
    // Calls
    //   - cpLocalFunction(System.Object)
    //   - double cpLocalFunction.ShapeVolume (Get)
    //   - string cpLocalFunction.ShapeType (Get)
    // Created
    //   - CopyPaste – 20251218 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251218 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strMessage;

      cpLocalFunction theLocalFunction = new cpLocalFunction(theShape);

      strMessage = "The volume of the " + theLocalFunction.ShapeType + " is " + theLocalFunction.ShapeVolume.ToString("F5");
      Console.WriteLine(strMessage);
    }
    // DisplayResult(System.Object)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning