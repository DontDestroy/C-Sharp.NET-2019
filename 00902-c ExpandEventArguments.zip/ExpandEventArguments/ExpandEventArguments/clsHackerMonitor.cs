﻿//***
// Action
//   - Code that checks if there is some suspicious activity
// Created
//   - CopyPaste – 20250716 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250716 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpHackerMonitor
  {

    #region "Constructors / Destructors"

    public cpHackerMonitor()
      //***
      // Action
      //   - Empty constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250716 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250716 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpHackerMonitor()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public event cpDelegate HackerAttack;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate void cpDelegate(System.Object theSender, cpMoreArguments thecpArguments);

    #endregion

    #region "Sub / Function"

    public void GenerateEvent()
      //***
      // Action
      //   - Create a new instance of cpMoreArguments
      //   - Raise the event HackerAttack with the arguments the current instance and the instance of cpMoreArguments
      // Called by
      //   - modExpandEventArguments.Main()
      // Calls
      //   - cpMoreArguments(string, DateTime)
      //   - cpProgram.Attack(System.Object, cpMoreArguments) Handles thecpHackerAlarm.HackerAttack
      //   - HackerAttack(System.Object, cpMoreArguments)
      // Created
      //   - CopyPaste – 20250716 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250716 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpMoreArguments thecpArguments = new cpMoreArguments("Hacker, Hacker", DateTime.Now);
      
      HackerAttack(this, thecpArguments);
    }
    // GenerateEvent()

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpHackerMonitor

}
// CopyPaste.Learning