//***
// Action
//   - Show text at console screen, using subroutine
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace SubRoutines
{

  class cpSubRoutines
	{

    static void Main()
    //***
    // Action
    //   - Show text at console screen
    //   - Draw line
    //   - Show text at console screen
    //   - Draw line
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - Line()
    //   - string System.Console.ReadLine() 
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Main menu");
      //Line();
      Console.WriteLine("1. From cm to inch.");
      Console.WriteLine("2. From inch to cm.");
      //Line();
      Console.WriteLine("Make your choice:");
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

    static void Line()
    //***
    // Action
    //   - Initialise variable
    //   - Loop from 1 to 79 (bytCounter)
    //     - Place a "-" at the console screen
    //   - Go to new line at console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.Write(string)
    //   - System.Console.WriteLine()
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      byte bytCounter;

      for (bytCounter = 1; bytCounter <= 79; bytCounter++)
      {
        Console.Write("-");
      }
      //' bytCounter = 80
      
      Console.WriteLine();
    }
    // Line()

  }
  // cpSubRoutines

}
// SubRoutines