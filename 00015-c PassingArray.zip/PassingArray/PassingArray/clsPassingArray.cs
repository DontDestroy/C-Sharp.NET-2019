//***
// Action
//   - Defining an array
//   - Passing the array as argument
//   - Passing an array elemnent as argument
// Created
//   - CopyPaste � 20220210 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220210 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace PassingArray
{

  class cpPassingArray
	{
    static string strOutput;

    static void Main()
    //***
    // Action
    //   - The whole routine through an output message is generated
    //   - Define an array of 5 elements
    //   - Loop through the elements
    //   - Routine Modify Array
    //   - Loop through the elements
    //   - Routine Modify element of array by value
    //   - Routine Modify element of array by reference
    //   - Show the output message in a MessageBox
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - int Array.GetUpperBound(int)
    //   - ModifyArray(int[])
    //   - ModifyArrayByRef(�int[])
    //   - ModifyArrayByVal(int[])
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int intCounter;
      int[] arrNumber = new int[] {1, 2, 3, 4, 5};

      strOutput = "EFFECTS OF PASSING ENTIRE ARRAY BY REFERENCE:\n\n" +
        "The values of the original array are:\n";
            
      for (intCounter = 0; intCounter <= arrNumber.GetUpperBound(0); intCounter++)
      {
        strOutput += arrNumber[intCounter] + " ";
      }
      // intCounter = arrNumber.GetUpperBound(0) + 1

      ModifyArray(arrNumber);

      strOutput += "\nThe values of the modified array are:\n";

      for (intCounter = 0; intCounter <= arrNumber.GetUpperBound(0); intCounter++)
      {
        strOutput += arrNumber[intCounter] + " ";
      }
      // intCounter = arrNumber.GetUpperBound(0) + 1

      strOutput += "\n\nEFFECTS OF PASSING ARRAY ELEMENT BY VALUE:\n\n" +
        "arrNumber[3] before ModifyElementByVal: " + arrNumber[3];
      ModifyElementByVal(arrNumber[3]);

      strOutput += "\narrNumber[3] after ModifyElementByVal: " + arrNumber[3];
      strOutput += "\n\nEFFECTS OF PASSING ARRAY ELEMENT BY REFERENCE:\n\n" + 
        "arrNumber[3] before ModifyElementByRef: " + arrNumber[3];
      ModifyElementByRef(ref arrNumber[3]);
      strOutput += "\narrNumber[3] after ModifyElementByRef: " + arrNumber[3];
      MessageBox.Show(strOutput, "Passing Arrays", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // Main()

    static void ModifyArray(int[] arrParameter)
    //***
    // Action
    //   - Loop thru all items of arrParameter
    //     - Multiply values by 2
    // Called by
    //   - Main()
    // Calls
    //   - int Array.GetUpperBound(int)
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int intCounter;

      for (intCounter = 0; intCounter <= arrParameter.GetUpperBound(0); intCounter++)
      {
        arrParameter[intCounter] *= 2;
      }
      // intCounter = arrParameter.GetUpperBound(0) + 1

    }
    // ModifyArray(int[])

    static void ModifyElementByRef(ref int intNumber)
    //***
    //   - Show the value of element before change
    //   - Multiply value by 2
    //   - Show the value of element after change
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      strOutput += "\nValue received in ModifyElementByRef: " + intNumber;
      intNumber *= 2;
      strOutput += "\nValue calculated in ModifyElementByRef: " + intNumber;
    }
    // ModifyElementByRef(�int)

    static void ModifyElementByVal(int intNumber)
    //***
    // Action
    //   - Show the value of element before change
    //   - Multiply value by 2
    //   - Show the value of element after change
    // Called by
    //   - Main()
    // Calls
    //   - Microsoft.VisualBasic.ControlChars.CrLf
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      strOutput += "\nValue received in ModifyElementByVal: " + intNumber;
      intNumber *= 2;
      strOutput += "\nValue calculated in ModifyElementByVal: " + intNumber;
    }
    // ModifyElementByVal(int)

  }
  // cpPassingArray

}
// PassingArray