//***
// Action
//   - Creating a form, to see the difference with Visual Basic 6.0
// Created
//   - CopyPaste � 20210824 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210824 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Drawing;
using System.Windows.Forms;

namespace theProject
{

  public class frmForm : System.Windows.Forms.Form
	{

    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdButton;
    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.cmdButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdButton
      // 
      this.cmdButton.Location = new System.Drawing.Point(86, 116);
      this.cmdButton.Name = "cmdButton";
      this.cmdButton.Size = new System.Drawing.Size(120, 40);
      this.cmdButton.TabIndex = 1;
      this.cmdButton.Text = "Click here !";
      // 
      // Form1
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdButton);
      this.Name = "Form1";
      this.Text = "the Form";
      this.ResumeLayout(false);

    }
    #endregion

		protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210824 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210824 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***

    {
      if (disposing)
      {

        if (components == null) 
        {
        }
        // (components != null) 
        else
        {
          components.Dispose();
        }
        // (components == null) 

      }
        // Not disposing
      else
      {
      }
      // disposing

			base.Dispose(disposing);
		}
    // Dispose(bool)

    public frmForm()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210824 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210824 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmForm()

		static void Main()
    //***
    // Action
    //   - Starting the application
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmform()
    // Created
    //   - CopyPaste � 20210824 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210824 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmForm());
		}
    // Main()

  }
  // frmForm 

}
// theProject