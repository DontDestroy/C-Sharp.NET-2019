//***
// Action
//   - A custom control (a round button)
// Created
//   - CopyPaste � 20240221 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240221 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class cpctlRoundButton : System.Windows.Forms.Button
	{

    #region Component Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      components = new System.ComponentModel.Container();
    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpctlRoundButton'
      // Called by
      //   - User action (Closing the cpctlRoundButton)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpctlRoundButton()
      //***
      // Action
      //   - Create instance of 'cpctlRoundButton'
      // Called by
      //   - frmTestRoundButton_Load(System.Object, System.EventArgs) Handles this.Load
      //   - User action (Starting the cpctlRoundButton)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // cpctlRoundButton()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"
      
    protected override void OnPaint(PaintEventArgs thePaintEventArguments)
      //***
      // Action
      //   - Overrides the way a button is drawn on the screen
      //   - A circle is a 2D drawing
      //   - An ellipse in drawn into a rectangle of 50 by 50
      //   - An ellipse is added of size 50 by 50
      //   - The region is defined by the circle
      // Called by
      //   - User action (Starting the cpctlRoundButton)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      GraphicsPath aCircle = new GraphicsPath();
      
      aCircle.AddEllipse(new RectangleF(0, 0, 50, 50));
      this.Size = new Size(50, 50);
      this.Region = new Region(aCircle);
    }
    // OnPaint(PaintEventArgs)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpctlRoundButton

}
// CopyPaste.Learning
