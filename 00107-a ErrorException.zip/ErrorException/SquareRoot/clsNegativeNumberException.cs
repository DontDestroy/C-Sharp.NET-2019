//***
// Action
//   - Definition of cpNegativeNumberException
// Created
//   - CopyPaste � 20230820 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230820 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpNegativeNumberException : ApplicationException
  {

    #region "Constructors / Destructors"

    public cpNegativeNumberException() : base("Illegal operation for a negative number")
      //***
      // Action
      //   - Constructor for cpNegativeNumberException with no parameters
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230820 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230820 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpNegativeNumberException()

    public cpNegativeNumberException(string strMessage) : base(strMessage)
      //***
      // Action
      //   - Constructor for cpNegativeNumberException with a text as parameter
      // Called by
      //   - double frmSquareRootTest.SquareRoot(double)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230820 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230820 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpNegativeNumberException(string)

    public cpNegativeNumberException(string strMessage, Exception theInnerException) : base(strMessage, theInnerException)
      //***
      // Action
      //   - Constructor for cpNegativeNumberException with a text and an exception as parameters
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230820 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230820 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpNegativeNumberException(string, Exception)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpNegativeNumberException

}
// CopyPaste.Learning