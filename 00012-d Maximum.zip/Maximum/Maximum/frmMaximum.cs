//***
// Action
//   - Determine the maximum value of 3 textboxes
// Created
//   - CopyPaste � 20230620 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230620 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Maximum
{

  public class frmMaximum : System.Windows.Forms.Form
  {
    #region Windows Form Designer generated code

    internal System.Windows.Forms.Label lblMaximum;
    internal System.Windows.Forms.Button cmdMaximum;
    internal System.Windows.Forms.TextBox txtThird;
    internal System.Windows.Forms.TextBox txtSecond;
    internal System.Windows.Forms.TextBox txtFirst;
    internal System.Windows.Forms.Label lblThree;
    internal System.Windows.Forms.Label lblTwo;
    internal System.Windows.Forms.Label lblOne;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMaximum));
      this.lblMaximum = new System.Windows.Forms.Label();
      this.cmdMaximum = new System.Windows.Forms.Button();
      this.txtThird = new System.Windows.Forms.TextBox();
      this.txtSecond = new System.Windows.Forms.TextBox();
      this.txtFirst = new System.Windows.Forms.TextBox();
      this.lblThree = new System.Windows.Forms.Label();
      this.lblTwo = new System.Windows.Forms.Label();
      this.lblOne = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // lblMaximum
      // 
      this.lblMaximum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblMaximum.Location = new System.Drawing.Point(18, 158);
      this.lblMaximum.Name = "lblMaximum";
      this.lblMaximum.Size = new System.Drawing.Size(216, 32);
      this.lblMaximum.TabIndex = 14;
      // 
      // cmdMaximum
      // 
      this.cmdMaximum.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmdMaximum.Location = new System.Drawing.Point(74, 206);
      this.cmdMaximum.Name = "cmdMaximum";
      this.cmdMaximum.Size = new System.Drawing.Size(136, 32);
      this.cmdMaximum.TabIndex = 15;
      this.cmdMaximum.Text = "Maximum";
      this.cmdMaximum.Click += new System.EventHandler(this.cmdMaximum_Click);
      // 
      // txtThird
      // 
      this.txtThird.Location = new System.Drawing.Point(194, 110);
      this.txtThird.Name = "txtThird";
      this.txtThird.Size = new System.Drawing.Size(80, 20);
      this.txtThird.TabIndex = 13;
      this.txtThird.Text = "";
      // 
      // txtSecond
      // 
      this.txtSecond.Location = new System.Drawing.Point(194, 62);
      this.txtSecond.Name = "txtSecond";
      this.txtSecond.Size = new System.Drawing.Size(80, 20);
      this.txtSecond.TabIndex = 11;
      this.txtSecond.Text = "";
      // 
      // txtFirst
      // 
      this.txtFirst.Location = new System.Drawing.Point(194, 14);
      this.txtFirst.Name = "txtFirst";
      this.txtFirst.Size = new System.Drawing.Size(80, 20);
      this.txtFirst.TabIndex = 9;
      this.txtFirst.Text = "";
      // 
      // lblThree
      // 
      this.lblThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblThree.Location = new System.Drawing.Point(18, 110);
      this.lblThree.Name = "lblThree";
      this.lblThree.Size = new System.Drawing.Size(144, 24);
      this.lblThree.TabIndex = 12;
      this.lblThree.Text = "Enter Third Value:";
      // 
      // lblTwo
      // 
      this.lblTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblTwo.Location = new System.Drawing.Point(18, 62);
      this.lblTwo.Name = "lblTwo";
      this.lblTwo.Size = new System.Drawing.Size(160, 24);
      this.lblTwo.TabIndex = 10;
      this.lblTwo.Text = "Enter Second Value:";
      // 
      // lblOne
      // 
      this.lblOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblOne.Location = new System.Drawing.Point(18, 14);
      this.lblOne.Name = "lblOne";
      this.lblOne.Size = new System.Drawing.Size(144, 24);
      this.lblOne.TabIndex = 8;
      this.lblOne.Text = "Enter First Value:";
      // 
      // frmMaximum
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 253);
      this.Controls.Add(this.lblMaximum);
      this.Controls.Add(this.cmdMaximum);
      this.Controls.Add(this.txtThird);
      this.Controls.Add(this.txtSecond);
      this.Controls.Add(this.txtFirst);
      this.Controls.Add(this.lblThree);
      this.Controls.Add(this.lblTwo);
      this.Controls.Add(this.lblOne);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMaximum";
      this.Text = "Maximum Program";
      this.Load += new System.EventHandler(this.frmMaximum_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmMaximum'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMaximum()
    //***
    // Action
    //   - Create instance of 'frmMaximum'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmMaximum()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
        
    private void cmdMaximum_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Take the values of 3 textboxes and put them into variables
    //   - 'lblMaximum'.'Text' becomes maximum
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - double Maximum(double, double, double)
    //   - double System.Convert.ToDouble(string)
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   - It is possible to crash the program
    //   - The exercise here is to solve this
    //***
    {
      double dblValue1;
      double dblValue2;
      double dblValue3;

      dblValue1 = Convert.ToDouble(txtFirst.Text);
      dblValue2 = Convert.ToDouble(txtSecond.Text);
      dblValue3 = Convert.ToDouble(txtThird.Text);

      lblMaximum.Text = Maximum(dblValue1, dblValue2, dblValue3).ToString();
    }
    // cmdMaximum_Click(System.Object, System.EventArgs) Handles cmdMaximum.Click

    private void frmMaximum_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Starting the form
    // Called by
    //   - User action (Loading a form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // frmMaximum_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmMaximum
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmMaximum());
    }
    // Main() 

    private double Maximum(double dblValueOne, double dblValueTwo, double dblValueThree)
    //***
    // Action
    //   - Take maximum of 3 values
    // Called by
    //   - cmdMaximum_Click(System.Object, System.EventArgs) Handles cmdMaximum.Click
    // Calls
    //   - double System.Math.Max(double, double)
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return Math.Max(Math.Max(dblValueOne, dblValueTwo), dblValueThree);
    }
    // double Maximum(double, double, double)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMaximum

}
// Maximum