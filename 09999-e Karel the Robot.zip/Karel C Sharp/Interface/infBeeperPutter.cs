﻿//***
// Action
//   - Interface of a beeper putter
// Created
//   - CopyPaste – 20251028 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251028 – VVDW
// Proposal (To Do)
//   -
//***

using kareltherobot;

namespace cpKarelTheRobot
{

	public interface cpinfBeeperPutter
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		void DistributeBeepers();
    //***
    // Action
    //   - Functionality that will distribute beepers
    // Called by
    //   - cpProgram.TwoDifferentRobotsInterface()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***

    void SwitchOff();
    //***
    // Action
    //   - Functionality that will switch off robot
    // Called by
    //   - cpProgram.TwoDifferentRobotsInterface()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpinfBeeperPutter

}
// cpKarelTheRobot