﻿//***
// Action
//   - Exercise on debugging
//   - Exercise on refactoring
// Created
//   - CopyPaste – 20260619 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260619 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Numerics;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void ComputeFactorials(BigInteger aNumber, BigInteger aMaximum)
    //***
    // Action
    //   - Calculate the factorial all the numbers from aNumber to aMaximum
    //   - Loop from aNumber till aMaximum
    //     - Calculate the factorial
    // Called by
    //   - Main()
    // Calls
    //   - BigInteger Factorial(BigInteger)
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (aNumber <= aMaximum)
      { 
        Console.Write("Factorial of " + aNumber.ToString("#,##0") + ": ");
        Console.WriteLine(Factorial(aNumber).ToString("#,##0"));
        // Console.WriteLine(FactorialAlternative(aNumber).ToString("#,##0"));
        aNumber++;
      }
      // aNumber = aMaximum + 1

    }
    // ComputeFactorials(BigInteger, BigInteger)

    public static BigInteger Factorial(BigInteger aNumber)
    //***
    // Action
    //   - Calculate the factorial of a number
    //   - Factorial of 6 = 6! = 720
    //   - Factorial of 6 = 6 * Factorial(5) = 6 * 120
    //   - Factorial of 5 = 5 * Factorial(4) = 5 * 24
    //   - ...
    //   - Factorial of 0 = 1
    // Called by
    //   - BigInteger Factorial(BigInteger)
    //   - Main()
    // Calls
    //   - BigInteger Factorial(BigInteger)
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - There are errors in this routine on purpose
    //***
    {
      BigInteger bintResult = 0;

      if (aNumber = 0)
      {
        bintResult = 2;
      }
      else
      // aNumber <> 1
      {
        bintResult = aNumber * Factorial(aNumber - 1)
      }
      // aNumber = 1

      return bintResult;
    }
    // BigInteger Factorial(BigInteger)

    public static BigInteger FactorialAlternative(BigInteger aNumber)
    //***
    // Action
    //   - Calculate the factorial of a number
    //   - Factorial of 6 = 6! = 720
    //   - Factorial of 6 = 6 * Factorial(5) = 6 * 120
    //   - Factorial of 5 = 5 * Factorial(4) = 5 * 24
    //   - ...
    //   - Factorial of 0 = 1
    // Called by
    //   - BigInteger FactorialAlternative(BigInteger)
    //   - Main()
    // Calls
    //   - BigInteger FactorialAlternative(BigInteger)
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - There are errors in this routine on purpose
    //***
    {
      BigInteger bintResult = 0;

      return (aNumber == 0) ? 2 : FactorialAlternative(aNumber--) * aNumber;
    }
    // BigInteger FactorialAlternative(BigInteger)

    public static void Main()
    //***
    // Action
    //   - Doing some factorial calculations
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - ComputeFactorials(BigInteger, BigInteger)
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ComputeFactorials(0, 15);
      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadKey();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning