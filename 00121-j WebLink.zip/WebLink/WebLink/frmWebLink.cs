//***
// Action
//   - Demo of a weblink on a form
// Created
//   - CopyPaste � 20240705 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240705 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmWebLink: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.LinkLabel lnlMicrosoft;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmWebLink));
      this.lnlMicrosoft = new System.Windows.Forms.LinkLabel();
      this.SuspendLayout();
      // 
      // lnlMicrosoft
      // 
      this.lnlMicrosoft.Location = new System.Drawing.Point(32, 24);
      this.lnlMicrosoft.Name = "lnlMicrosoft";
      this.lnlMicrosoft.Size = new System.Drawing.Size(160, 23);
      this.lnlMicrosoft.TabIndex = 1;
      this.lnlMicrosoft.TabStop = true;
      this.lnlMicrosoft.Text = "www.microsoft.com";
      this.lnlMicrosoft.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnlMicrosoft_LinkClicked);
      // 
      // frmWebLink
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.lnlMicrosoft);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmWebLink";
      this.Text = "Web Link Test";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmWebLink'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmWebLink()
      //***
      // Action
      //   - Create instance of 'frmWebLink'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmWebLink()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void lnlMicrosoft_LinkClicked(System.Object theSender, LinkLabelLinkClickedEventArgs theLinkLabelLinkClickedEventArguments)
      //***
      // Action
      //   - Change the color of the link by setting LinkVisited to True
      //   - Use the Process.Start method to open the default broswer using the text of the link
      // Called by
      //   - User action (Clicking on a link)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20270705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20270705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lnlMicrosoft.LinkVisited = true;
      Process.Start(lnlMicrosoft.Text);
    }
    // lnlMicrosoft_LinkClicked(System.Object, LinkLabelLinkClickedEventArgs) Handles lnlMicrosoft.LinkClicked

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmWebLink
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmWebLink()
      // Created
      //   - CopyPaste � 20240705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmWebLink());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmWebLink

}
// CopyPaste.Learning