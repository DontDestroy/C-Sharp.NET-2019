//***
// Action
//   - First form using cpSortablePoint
//   - Loop normal thru an ArrayList
//   - Loop using an enumerator thru an ArrayList
//   - Loop using an cpPointEnumerator thru an ArrayList
// Created
//   - CopyPaste � 20240314 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240314 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPoint: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.Timer tmrClick;
    internal System.Windows.Forms.Button cmdDraw;
    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPoint));
      this.tmrClick = new System.Windows.Forms.Timer(this.components);
      this.cmdDraw = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // tmrClick
      // 
      this.tmrClick.Enabled = true;
      this.tmrClick.Interval = 4000;
      this.tmrClick.Tick += new System.EventHandler(this.tmrClick_Tick);
      // 
      // cmdDraw
      // 
      this.cmdDraw.Location = new System.Drawing.Point(208, 240);
      this.cmdDraw.Name = "cmdDraw";
      this.cmdDraw.TabIndex = 1;
      this.cmdDraw.Text = "&Draw";
      this.cmdDraw.Click += new System.EventHandler(this.cmdDraw_Click);
      // 
      // frmPoint
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdDraw);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPoint";
      this.Text = "Points";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPoint'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPoint()
      //***
      // Action
      //   - Create instance of 'frmPoint'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPoint()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdDraw_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Generate a random color
      //   - Loop 101 times
      //     - Loop 241 times
      //       - Create a cpSortablePoint
      //       - Add it to an arraylist
      //     - Sort them
      //     - Visualise the points on the screen in 3 different ways
      //       - First is using a normal loop (in comments)
      //       - Second is using an enumerator (in comments)
      //       - Third is using hte cpPointEnumerator
      //     - Clear the array
      //   - At the end there are 24341 elements in the screen
      // Called by
      //   - User action (Clicking a button)
      //   - tmrClick_Tick(System.Object, System.EventArgs) Handles tmrClick.Tick
      // Calls
      //   - bool cpPointEnumerator.MoveNext()
      //   - cpPointEnumerator.New(ArrayList)
      //   - cpSortablePoint(int, int)
      //   - int cpSortablePoint.X (Get)
      //   - int cpSortablePoint.Y (Get)
      //   - System.Object cpPointEnumerator.Current (Get)
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ArrayList arrPoint = new ArrayList();
      Color theColor;
      cpSortablePoint thecpPoint;
      Graphics theGraph = this.CreateGraphics();
      int lngColor;
      int lngCounter;
      int lngCounterLoop;
      Random rndGenerator = new System.Random();

      lngColor = rndGenerator.Next(250);

      for (lngCounterLoop = 0; lngCounterLoop <= 100; lngCounterLoop++)
      {

        for (lngCounter = 0; lngCounter <= 240; lngCounter++)
        {
          thecpPoint = new cpSortablePoint(rndGenerator.Next(200), rndGenerator.Next(200));
          arrPoint.Add(thecpPoint);
        }
        // lngCounter = 241
        
        arrPoint.Sort();
        
        // Method 1 for looping the array
        // Normal way of looping
        
        // for (lngCounter = 0; lngCounter <= 240; lngCounter++)
        // {
        //   thecpPoint = (cpSortablePoint) arrPoint[lngCounter];
        //   theColor = Color.FromArgb(lngColor, lngColor, lngCounter);
        // 
        //   SolidBrush theBrush = new SolidBrush(theColor);
        //   theGraph.FillEllipse(theBrush, thecpPoint.X, thecpPoint.Y, 1, 2);
        //   theBrush.Dispose();
        // }
        // // lngCounter = 241
        
        // Method 2 for looping the array
        // Using the default enumerator
        
        IEnumerator theEnumerator = arrPoint.GetEnumerator();
        
        // lngCounter = 0;
        // 
        // while (theEnumerator.MoveNext())
        // {
        //   thecpPoint = (cpSortablePoint) theEnumerator.Current;
        //   theColor = Color.FromArgb(lngColor, lngColor, lngCounter);
        //   lngCounter += 1;
        // 
        //   SolidBrush theBrush = new SolidBrush(theColor);
        //   theGraph.FillEllipse(theBrush, thecpPoint.X, thecpPoint.Y, 1, 2);
        //   theBrush.Dispose();
        // }
        // // Not theEnumerator.MoveNext
        
        // Method 3 for looping the array
        // Using the enumerator interface
        
        cpPointEnumerator cpPointEnumerator = new cpPointEnumerator(arrPoint);
        lngCounter = 0;
        
        while (theEnumerator.MoveNext())
        {
          thecpPoint = (cpSortablePoint) theEnumerator.Current;
          theColor = Color.FromArgb(lngColor, lngColor, lngCounter);
          lngCounter += 1;
        
          SolidBrush theBrush = new SolidBrush(theColor);
          theGraph.FillEllipse(theBrush, thecpPoint.X, thecpPoint.Y, 1, 2);
          theBrush.Dispose();
        }
        // Not theEnumerator.MoveNext
        
        arrPoint.Clear();
      }
      // lngCounterLoop = 101
    
    }
    // cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
    
    private void tmrClick_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Simulate clicking the button
      // Called by
      //   - System action (Timer is triggered)
      // Calls
      //   - cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cmdDraw_Click(theSender, theEventArguments);
    }
    // tmrClick_Tick(System.Object, System.EventArgs) Handles tmrClick.Tick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPoint
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPoint());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPoint

}
// CopyPaste.Learning