//***
// Action
//   - A demo of System.Math
// Created
//   - CopyPaste � 20220301 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220301 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Math
{

  class cpMath
	{

    static void Main()
    //***
    // Action
    //   - Show absolute value of -1
    //   - Show the square root of 144
    //   - Show PI
    //   - Show 10 to the power 2
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - Console.WriteLine(string)
    //   - double Math.Sqrt(double)
    //   - double Math.PI()
    //   - double Math.Pow(double, double)
    //   - int Math.Abs(int)
    //   - string Console.ReadLine()
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine("Absolute value of -1 is " + System.Math.Abs(-1));
      Console.WriteLine("Square Root of 144 is " + System.Math.Sqrt(144));
      Console.WriteLine("Value for PI is " + System.Math.PI);
      Console.WriteLine("10 raised to the power of 2 is " + System.Math.Pow(10, 2));
      Console.ReadLine();
    }
    // Main()

	}
  // cpMath

}
// MathClass