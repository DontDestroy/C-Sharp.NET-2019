﻿//***
// Action
//   - Reading Application Settings
// Created
//   - CopyPaste – 20210806 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210806 – VVDW
// Proposal(To Do)
//   -List of actions that can be added to the functionality
//***

using System.Configuration;

namespace WPFConnection
{
  public static class cpApplicationSetting
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public static string ConnectionString
    //***
    // Action Get
    //   - Look up the connection string in the Application Configuration(App.config)
    // Called by
    //   - cpViewModel()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210806 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210806 – VVDW
    // Keyboard Key
    //   - 
    // Proposal(To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      get
      {
        return ConfigurationManager.ConnectionStrings["WPFConnection"].ConnectionString;
      }
      // string ConnectionString (Get)
    }
    // string ConnectionString 

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpApplicationSetting

}
// WPFConnection.cpclsComponent
