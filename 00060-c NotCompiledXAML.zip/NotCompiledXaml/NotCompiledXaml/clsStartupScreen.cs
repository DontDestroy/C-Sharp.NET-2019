//***
// Action
//   - Startup screen
// Created
//   - CopyPaste � 20220814 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220814 � VVDW
// Proposal (To Do)
//   -
//***

using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace NotCompiledXaml
{

  public class cpStartupScreen : Window
  {

    #region "Constructors / Destructors"

    public cpStartupScreen()
    //***
    // Action
    //   - Create a new instance of Startup screen
    //   - Initialize the content of the screen
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste � 20220814 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220814 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // cpStartupScreen()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private Button cmdButton;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdButton_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Change something on the screen to prove that you can add functionality to a button
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220814 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220814 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cmdButton.Content = "Thank you";
    }
    // cmdButton_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdButton.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void InitializeComponent()
    //***
    // Action
    //   - Building up the Startup screen
    //   - Information of the screen is written in a file (XAMLFile.xml)
    // Called by
    //   - cpStartupScreen()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220814 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220814 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      this.Height = 285;
      this.Width = 285;
      this.Left = 100;
      this.Top = 100;
      this.Title = "Dynamically Loaded XAML";

      FileStream theFileScreen = new FileStream("XAMLFile.xml", FileMode.Open);
      DependencyObject rootElement = (DependencyObject)XamlReader.Load(theFileScreen);
      this.Content = rootElement;

      FrameworkElement frameworkElement = (FrameworkElement)rootElement; // Find the control with the correct name
      cmdButton = (Button)frameworkElement.FindName("cmdButton");
      // cmdButton = (Button)LogicalTreeHelper.FindLogicalNode(rootElement, "cmdButton"); // Alternative way

      cmdButton.Click += new RoutedEventHandler(cmdButton_Click); // Add event to the button
    }
    // InitializeComponent()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpStartupScreen

}
// NotCompiledXaml