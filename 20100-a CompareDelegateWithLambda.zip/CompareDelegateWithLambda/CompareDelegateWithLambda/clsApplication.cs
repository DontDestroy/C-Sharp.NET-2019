﻿//***
// Action
//   - Contains applications (methods) that can be used in a delegate
// Created
//   - CopyPaste – 20230408 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230408 – VVDW
// Proposal (To Do)
//   -
//***

namespace CompareDelegateWithLambda
{

  public class cpApplication
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public static bool IsEven(int intNumber)
    //***
    // Action
    //   - Checking if a number is even
    //   - Used a bitwize operator to check this
    //   - Important to notice
    //     - The parameters and return value matches the delegate used
    // Called by
    //   - cpProgram.DelegateExample()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230408 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230408 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      return ((intNumber & 1) == 0);
    }
    // bool IsEven(int)

    public static bool IsOdd(int intNumber)
    //***
    // Action
    //   - Checking if a number is odd
    //   - Used a bitwize operator to check this
    //   - Important to notice
    //     - The parameters and return value matches the delegate used
    // Called by
    //   - cpProgram.DelegateExample()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230408 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230408 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      return ((intNumber & 1) == 1);
    }
    // bool IsOdd(int)

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpApplication

}
// CompareDelegateWithLambda