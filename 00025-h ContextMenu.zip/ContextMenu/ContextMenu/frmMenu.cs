//***
// Action
//   - Example of a menu
// Created
//   - CopyPaste � 20240514 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240514 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMenu: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.MenuItem mnuFile;
    internal System.Windows.Forms.MenuItem mnuFileExit;
    internal System.Windows.Forms.MenuItem mnuFormatForeGroundBlue;
    internal System.Windows.Forms.MenuItem mnuFormatLine02;
    internal System.Windows.Forms.Label lblStop;
    internal System.Windows.Forms.MenuItem mnuFormatTitleBox;
    internal System.Windows.Forms.MenuItem mnuFormatForeground;
    internal System.Windows.Forms.MenuItem mnuFormatForeGroundGreen;
    internal System.Windows.Forms.GroupBox grpForeGround;
    internal System.Windows.Forms.RadioButton optBleu;
    internal System.Windows.Forms.RadioButton optGreen;
    internal System.Windows.Forms.MainMenu mnuMain;
    internal System.Windows.Forms.MenuItem mnuFormat;
    internal System.Windows.Forms.MenuItem mnuFormatBackground;
    internal System.Windows.Forms.MenuItem mnuFormatBackGroundWhite;
    internal System.Windows.Forms.MenuItem mnuFormatBackGroundYellow;
    internal System.Windows.Forms.MenuItem mnuFormatLine01;
    internal System.Windows.Forms.CheckBox chkTitleBox;
    internal System.Windows.Forms.Label lblChoose;
    internal System.Windows.Forms.GroupBox grpBackGround;
    internal System.Windows.Forms.RadioButton optYellow;
    internal System.Windows.Forms.ContextMenu ctmTitle;
    internal System.Windows.Forms.MenuItem mnuTimesNewRoman;
    internal System.Windows.Forms.MenuItem mnuCourierNew;
    internal System.Windows.Forms.MenuItem mnuSansSerif;
    internal System.Windows.Forms.MenuItem mnuLine01;
    internal System.Windows.Forms.RadioButton optWhite;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMenu));
      this.mnuFile = new System.Windows.Forms.MenuItem();
      this.mnuFileExit = new System.Windows.Forms.MenuItem();
      this.mnuFormatForeGroundBlue = new System.Windows.Forms.MenuItem();
      this.mnuFormatLine02 = new System.Windows.Forms.MenuItem();
      this.lblStop = new System.Windows.Forms.Label();
      this.mnuFormatTitleBox = new System.Windows.Forms.MenuItem();
      this.mnuFormatForeground = new System.Windows.Forms.MenuItem();
      this.mnuFormatForeGroundGreen = new System.Windows.Forms.MenuItem();
      this.grpForeGround = new System.Windows.Forms.GroupBox();
      this.optBleu = new System.Windows.Forms.RadioButton();
      this.optGreen = new System.Windows.Forms.RadioButton();
      this.mnuMain = new System.Windows.Forms.MainMenu();
      this.mnuFormat = new System.Windows.Forms.MenuItem();
      this.mnuFormatBackground = new System.Windows.Forms.MenuItem();
      this.mnuFormatBackGroundWhite = new System.Windows.Forms.MenuItem();
      this.mnuFormatBackGroundYellow = new System.Windows.Forms.MenuItem();
      this.mnuFormatLine01 = new System.Windows.Forms.MenuItem();
      this.chkTitleBox = new System.Windows.Forms.CheckBox();
      this.lblChoose = new System.Windows.Forms.Label();
      this.grpBackGround = new System.Windows.Forms.GroupBox();
      this.optYellow = new System.Windows.Forms.RadioButton();
      this.optWhite = new System.Windows.Forms.RadioButton();
      this.ctmTitle = new System.Windows.Forms.ContextMenu();
      this.mnuTimesNewRoman = new System.Windows.Forms.MenuItem();
      this.mnuCourierNew = new System.Windows.Forms.MenuItem();
      this.mnuSansSerif = new System.Windows.Forms.MenuItem();
      this.mnuLine01 = new System.Windows.Forms.MenuItem();
      this.grpForeGround.SuspendLayout();
      this.grpBackGround.SuspendLayout();
      this.SuspendLayout();
      // 
      // mnuFile
      // 
      this.mnuFile.Index = 0;
      this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFileExit});
      this.mnuFile.Text = "&File";
      // 
      // mnuFileExit
      // 
      this.mnuFileExit.Index = 0;
      this.mnuFileExit.OwnerDraw = true;
      this.mnuFileExit.Text = "E&xit";
      this.mnuFileExit.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.mnuFileExit_DrawItem);
      this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
      this.mnuFileExit.MeasureItem += new System.Windows.Forms.MeasureItemEventHandler(this.mnuFileExit_MeasureItem);
      // 
      // mnuFormatForeGroundBlue
      // 
      this.mnuFormatForeGroundBlue.Index = 0;
      this.mnuFormatForeGroundBlue.Shortcut = System.Windows.Forms.Shortcut.CtrlB;
      this.mnuFormatForeGroundBlue.Text = "&Blue";
      this.mnuFormatForeGroundBlue.Click += new System.EventHandler(this.mnuFormatForeGroundBlue_Click);
      // 
      // mnuFormatLine02
      // 
      this.mnuFormatLine02.Index = 3;
      this.mnuFormatLine02.Text = "-";
      // 
      // lblStop
      // 
      this.lblStop.Image = ((System.Drawing.Image)(resources.GetObject("lblStop.Image")));
      this.lblStop.Location = new System.Drawing.Point(217, 56);
      this.lblStop.Name = "lblStop";
      this.lblStop.TabIndex = 9;
      this.lblStop.Visible = false;
      // 
      // mnuFormatTitleBox
      // 
      this.mnuFormatTitleBox.Index = 4;
      this.mnuFormatTitleBox.Text = "&Title has box";
      this.mnuFormatTitleBox.Click += new System.EventHandler(this.mnuFormatTitleBox_Click);
      // 
      // mnuFormatForeground
      // 
      this.mnuFormatForeground.Index = 2;
      this.mnuFormatForeground.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                        this.mnuFormatForeGroundBlue,
                                                                                        this.mnuFormatForeGroundGreen});
      this.mnuFormatForeground.Text = "Foreground";
      // 
      // mnuFormatForeGroundGreen
      // 
      this.mnuFormatForeGroundGreen.Index = 1;
      this.mnuFormatForeGroundGreen.Shortcut = System.Windows.Forms.Shortcut.CtrlG;
      this.mnuFormatForeGroundGreen.Text = "&Green";
      this.mnuFormatForeGroundGreen.Click += new System.EventHandler(this.mnuFormatForeGroundGreen_Click);
      // 
      // grpForeGround
      // 
      this.grpForeGround.Controls.Add(this.optBleu);
      this.grpForeGround.Controls.Add(this.optGreen);
      this.grpForeGround.Location = new System.Drawing.Point(169, 104);
      this.grpForeGround.Name = "grpForeGround";
      this.grpForeGround.Size = new System.Drawing.Size(128, 136);
      this.grpForeGround.TabIndex = 8;
      this.grpForeGround.TabStop = false;
      this.grpForeGround.Text = "Foreground Color";
      // 
      // optBleu
      // 
      this.optBleu.Location = new System.Drawing.Point(24, 64);
      this.optBleu.Name = "optBleu";
      this.optBleu.Size = new System.Drawing.Size(72, 24);
      this.optBleu.TabIndex = 1;
      this.optBleu.Text = "B&lue";
      this.optBleu.CheckedChanged += new System.EventHandler(this.optBleu_CheckedChanged);
      // 
      // optGreen
      // 
      this.optGreen.Location = new System.Drawing.Point(24, 32);
      this.optGreen.Name = "optGreen";
      this.optGreen.Size = new System.Drawing.Size(72, 24);
      this.optGreen.TabIndex = 0;
      this.optGreen.Text = "&Green";
      this.optGreen.CheckedChanged += new System.EventHandler(this.optGreen_CheckedChanged);
      // 
      // mnuMain
      // 
      this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFile,
                                                                            this.mnuFormat});
      // 
      // mnuFormat
      // 
      this.mnuFormat.Index = 1;
      this.mnuFormat.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.mnuFormatBackground,
                                                                              this.mnuFormatLine01,
                                                                              this.mnuFormatForeground,
                                                                              this.mnuFormatLine02,
                                                                              this.mnuFormatTitleBox});
      this.mnuFormat.Text = "F&ormat";
      this.mnuFormat.Popup += new System.EventHandler(this.mnuFormat_Popup);
      // 
      // mnuFormatBackground
      // 
      this.mnuFormatBackground.Index = 0;
      this.mnuFormatBackground.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                        this.mnuFormatBackGroundWhite,
                                                                                        this.mnuFormatBackGroundYellow});
      this.mnuFormatBackground.Text = "&Background";
      // 
      // mnuFormatBackGroundWhite
      // 
      this.mnuFormatBackGroundWhite.Index = 0;
      this.mnuFormatBackGroundWhite.Shortcut = System.Windows.Forms.Shortcut.CtrlW;
      this.mnuFormatBackGroundWhite.Text = "&White";
      this.mnuFormatBackGroundWhite.Click += new System.EventHandler(this.mnuFormatBackGroundWhite_Click);
      // 
      // mnuFormatBackGroundYellow
      // 
      this.mnuFormatBackGroundYellow.Index = 1;
      this.mnuFormatBackGroundYellow.Shortcut = System.Windows.Forms.Shortcut.CtrlY;
      this.mnuFormatBackGroundYellow.Text = "&Yellow";
      this.mnuFormatBackGroundYellow.Click += new System.EventHandler(this.mnuFormatBackGroundYellow_Click);
      // 
      // mnuFormatLine01
      // 
      this.mnuFormatLine01.Index = 1;
      this.mnuFormatLine01.Text = "-";
      // 
      // chkTitleBox
      // 
      this.chkTitleBox.Location = new System.Drawing.Point(25, 64);
      this.chkTitleBox.Name = "chkTitleBox";
      this.chkTitleBox.TabIndex = 6;
      this.chkTitleBox.Text = "&Title has box";
      this.chkTitleBox.CheckedChanged += new System.EventHandler(this.chkTitleBox_CheckedChanged);
      // 
      // lblChoose
      // 
      this.lblChoose.ContextMenu = this.ctmTitle;
      this.lblChoose.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblChoose.Location = new System.Drawing.Point(9, 8);
      this.lblChoose.Name = "lblChoose";
      this.lblChoose.Size = new System.Drawing.Size(312, 32);
      this.lblChoose.TabIndex = 5;
      this.lblChoose.Text = "Choose your options";
      this.lblChoose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // grpBackGround
      // 
      this.grpBackGround.Controls.Add(this.optYellow);
      this.grpBackGround.Controls.Add(this.optWhite);
      this.grpBackGround.Location = new System.Drawing.Point(33, 104);
      this.grpBackGround.Name = "grpBackGround";
      this.grpBackGround.Size = new System.Drawing.Size(128, 136);
      this.grpBackGround.TabIndex = 7;
      this.grpBackGround.TabStop = false;
      this.grpBackGround.Text = "Background Color";
      // 
      // optYellow
      // 
      this.optYellow.Location = new System.Drawing.Point(24, 64);
      this.optYellow.Name = "optYellow";
      this.optYellow.Size = new System.Drawing.Size(72, 24);
      this.optYellow.TabIndex = 1;
      this.optYellow.Text = "&Yellow";
      this.optYellow.CheckedChanged += new System.EventHandler(this.optYellow_CheckedChanged);
      // 
      // optWhite
      // 
      this.optWhite.Location = new System.Drawing.Point(24, 32);
      this.optWhite.Name = "optWhite";
      this.optWhite.Size = new System.Drawing.Size(72, 24);
      this.optWhite.TabIndex = 0;
      this.optWhite.Text = "&White";
      this.optWhite.CheckedChanged += new System.EventHandler(this.optWhite_CheckedChanged);
      // 
      // ctmTitle
      // 
      this.ctmTitle.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                             this.mnuTimesNewRoman,
                                                                             this.mnuCourierNew,
                                                                             this.mnuSansSerif,
                                                                             this.mnuLine01});
      this.ctmTitle.Popup += new System.EventHandler(this.ctmTitle_Popup);
      // 
      // mnuTimesNewRoman
      // 
      this.mnuTimesNewRoman.Index = 0;
      this.mnuTimesNewRoman.Text = "Times New Roman";
      this.mnuTimesNewRoman.Click += new System.EventHandler(this.mnuTimesNewRoman_Click);
      // 
      // mnuCourierNew
      // 
      this.mnuCourierNew.Index = 1;
      this.mnuCourierNew.Text = "Courier New";
      this.mnuCourierNew.Click += new System.EventHandler(this.mnuCourierNew_Click);
      // 
      // mnuSansSerif
      // 
      this.mnuSansSerif.Index = 2;
      this.mnuSansSerif.Text = "Sans Serif";
      this.mnuSansSerif.Click += new System.EventHandler(this.mnuSansSerif_Click);
      // 
      // mnuLine01
      // 
      this.mnuLine01.Index = 3;
      this.mnuLine01.Text = "-";
      // 
      // frmMenu
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(330, 273);
      this.Controls.Add(this.grpForeGround);
      this.Controls.Add(this.chkTitleBox);
      this.Controls.Add(this.lblChoose);
      this.Controls.Add(this.grpBackGround);
      this.Controls.Add(this.lblStop);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.Menu = this.mnuMain;
      this.Name = "frmMenu";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "CheckBox, RadioButton and GroupBox";
      this.grpForeGround.ResumeLayout(false);
      this.grpBackGround.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMenu'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMenu()
      //***
      // Action
      //   - Create instance of 'frmMenu'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMenu()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void chkTitleBox_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - TitleBox()
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      TitleBox();    
    }
    // chkTitleBox_CheckedChanged(System.Object, System.EventArgs) Handles chkTitleBox.CheckedChanged

    private void ctmTitle_Popup(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mnuCourierNew.Checked = lblChoose.Font.Equals(new Font("Courier New", 16));
      mnuTimesNewRoman.Checked = lblChoose.Font.Equals(new Font("Times New Roman", 16));
      mnuSansSerif.Checked = lblChoose.Font.Equals(new Font("Microsoft Sans Serif", 16));
    }
    // ctmTitle_Popup(System.Object, System.EventArgs) Handles ctmTitle.Popup

    private void mnuCourierNew_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblChoose.Font = new Font("Courier New", 16);
    }
    // mnuCourierNew_Click(System.Object, System.EventArgs) Handles mnuCourierNew.Click

    private void mnuFileExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Close the application
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // mnuFileExit_Click(System.Object, System.EventArgs) Handles mnuFileExit.Click

    private void mnuFileExit_DrawItem(System.Object theSender, System.Windows.Forms.DrawItemEventArgs theDrawItemEventArguments)
      //***
      // Action
      //   - Draw the file exit menu item 
      // Called by
      //   - User action (Drawing a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Brush theBrush = Brushes.Black;

      theDrawItemEventArguments.Graphics.DrawImage(lblStop.Image, 0, 0);
      theDrawItemEventArguments.Graphics.DrawString("Exit", this.Font, theBrush, lblStop.Image.Width + 3, 0);    
    }
    // mnuFileExit_DrawItem(System.Object, System.Windows.Forms.DrawItemEventArgs) Handles mnuFileExit.DrawItem

    private void mnuFileExit_MeasureItem(System.Object theSender, System.Windows.Forms.MeasureItemEventArgs theMeasureItemEventArguments)
      //***
      // Action
      //   - Generate the size of file exit menu item 
      // Called by
      //   - User action (Measure a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      theMeasureItemEventArguments.ItemHeight = lblStop.Image.Height;
      theMeasureItemEventArguments.ItemWidth = lblStop.Image.Width + 3 + Convert.ToInt32(theMeasureItemEventArguments.Graphics.MeasureString("Exit", this.Font).Width);
    }
    // mnuFileExit_MeasureItem(System.Object, System.Windows.Forms.MeasureItemEventArgs) Handles mnuFileExit.MeasureItem

    private void mnuFormatBackGroundWhite_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - BackColorWhite() (indirectly)
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      optWhite.Checked = true;
      // BackColorWhite();
    }
    // mnuFormatBackGroundWhite_Click(System.Object, System.EventArgs) Handles mnuFormatBackGroundWhite.Click

    private void mnuFormatBackGroundYellow_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - BackColorYellow() (indirectly)
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      optYellow.Checked = true;
      // BackColorYellow();    
    }
    // mnuFormatBackGroundYellow_Click(System.Object, System.EventArgs) Handles mnuFormatBackGroundYellow.Click

    private void mnuFormatForeGroundBlue_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ForeColorBlue() (indirectly)
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      optBleu.Checked = true;
      // ForeColorBlue();
    }
    // mnuFormatForeGroundBlue_Click(System.Object, System.EventArgs) Handles mnuFormatForeGroundBlue.Click

    private void mnuFormatForeGroundGreen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ForeColorGreen() (indirectly)
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      optGreen.Checked = true;
      // ForeColorGreen();
    }
    // mnuFormatForeGroundGreen_Click(System.Object, System.EventArgs) Handles mnuFormatForeGroundGreen.Click

    private void mnuFormatTitleBox_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - TitleBox() (indirectly)
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      chkTitleBox.Checked = !chkTitleBox.Checked;
      // TitleBox();
    }
    // mnuFormatTitleBox_Click(System.Object, System.EventArgs) Handles mnuFormatTitleBox.Click

    private void mnuFormat_Popup(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Check the correct menu items depending on the situation
      // Called by
      //   - User action (Popup a menu)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mnuFormatBackGroundWhite.Checked = lblChoose.BackColor.Equals(Color.White);
      mnuFormatBackGroundYellow.Checked = lblChoose.BackColor.Equals(Color.Yellow);
      mnuFormatForeGroundBlue.Checked = lblChoose.ForeColor.Equals(Color.Blue);
      mnuFormatForeGroundGreen.Checked = lblChoose.ForeColor.Equals(Color.Green);
      mnuFormatTitleBox.Checked = lblChoose.BorderStyle.Equals(BorderStyle.FixedSingle);
    }
    // mnuFormat_Popup(System.Object, System.EventArgs) Handles mnuFormat.Popup 

    private void mnuSansSerif_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblChoose.Font = new Font("Microsoft Sans Serif", 16);
    }
    // mnuSansSerif_Click(System.Object, System.EventArgs) Handles mnuSansSerif.Click

    private void mnuTimesNewRoman_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblChoose.Font = new Font("Times New Roman", 16);
    }
    // mnuTimesNewRoman_Click(System.Object theSender, System.EventArgs theEventArguments) Handles mnuTimesNewRoman.Click

    private void optBleu_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ForeColorBlue()
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ForeColorBlue();    
    }
    // optBleu_CheckedChanged(System.Object, System.EventArgs) Handles optBleu.CheckedChanged

    private void optGreen_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ForeColorGreen()
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ForeColorGreen();    
    }
    // optGreen_CheckedChanged(System.Object, System.EventArgs) Handles optGreen.CheckedChanged

    private void optWhite_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - BackColorWhite()
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BackColorWhite();
    }
    // optWhite_CheckedChanged(System.Object, System.EventArgs) Handles optWhite.CheckedChanged

    private void optYellow_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do some action on the titlebox
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - BackColorYellow()
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BackColorYellow();    
    }
    // optYellow_CheckedChanged(System.Object, System.EventArgs) Handles optYellow.CheckedChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void BackColorWhite()
      //***
      // Action
      //   - Backcolor of label becomes white
      // Called by
      //   - optWhite_CheckedChanged(System.Object, System.EventArgs) Handles optWhite.CheckedChanged
      //   - mnuFormatBackGroundWhite_Click(System.Object, System.EventArgs) Handles mnuFormatBackGroundWhite.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblChoose.BackColor = Color.White;
    }
    // BackColorWhite()

    private void BackColorYellow()
      //***
      // Action
      //   - Backcolor of label becomes yellow
      // Called by
      //   - optYellow_CheckedChanged(System.Object, System.EventArgs) Handles optYellow.CheckedChanged
      //   - mnuFormatBackGroundYellow_Click(System.Object, System.EventArgs) Handles mnuFormatBackGroundYellow.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblChoose.BackColor = Color.Yellow;
    }
    // BackColorYellow()

    private void ForeColorBlue()
      //***
      // Action
      //   - Forecolor of label becomes blue
      // Called by
      //   - optBleu_CheckedChanged(System.Object, System.EventArgs) Handles optBleu.CheckedChanged
      //   - mnuFormatForeGroundBlue_Click(System.Object, System.EventArgs) Handles mnuFormatForeGroundBlue.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblChoose.ForeColor = Color.Blue;
    }
    // ForeColorBlue()

    private void ForeColorGreen()
      //***
      // Action
      //   - Forecolor of label becomes green
      // Called by
      //   - optGreen_CheckedChanged(System.Object, System.EventArgs) Handles optGreen.CheckedChanged
      //   - mnuFormatForeGroundGreen_Click(System.Object, System.EventArgs) Handles mnuFormatForeGroundGreen.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblChoose.ForeColor = Color.Green;
    }
    // ForeColorGreen()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMenu
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmMenu()
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMenu());
    }
    // Main() 

    private void TitleBox()
      //***
      // Action
      //   - If checkbox is checked
      //     - Border style becomes a single line
      //   - If not
      //     - Border style becomes no line
      // Called by
      //   - chkTitleBox_CheckedChanged(System.Object, System.EventArgs) Handles chkTitleBox.CheckedChanged
      //   - mnuFormatTitleBox_Click(System.Object, System.EventArgs) Handles mnuFormatTitleBox.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    
      if (chkTitleBox.Checked)
      {
        lblChoose.BorderStyle = BorderStyle.FixedSingle;
      }
      else
        // Not chkTitleBox.Checked
      {
        lblChoose.BorderStyle = BorderStyle.None;
      }
      // chkTitleBox.Checked

    }
    // TitleBox()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMenu

}
// CopyPaste.Learning