using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace DataFormWizard
{
	/// <summary>
	/// Summary description for frmDataWizard.
	/// </summary>
	public class frmDataWizard : System.Windows.Forms.Form
	{
    private System.Data.OleDb.OleDbCommand oleDbSelectCommand1;
    private System.Data.OleDb.OleDbCommand oleDbInsertCommand1;
    private System.Data.OleDb.OleDbCommand oleDbUpdateCommand1;
    private System.Data.OleDb.OleDbCommand oleDbDeleteCommand1;
    private System.Data.OleDb.OleDbCommand oleDbSelectCommand2;
    private System.Data.OleDb.OleDbCommand oleDbInsertCommand2;
    private System.Data.OleDb.OleDbCommand oleDbUpdateCommand2;
    private System.Data.OleDb.OleDbCommand oleDbDeleteCommand2;
    private System.Data.OleDb.OleDbConnection oleDbConnection1;
    private System.Data.OleDb.OleDbDataAdapter oleDbDataAdapter1;
    private System.Data.OleDb.OleDbDataAdapter oleDbDataAdapter2;
    private DataFormWizard.dsData objdsData;
    private System.Windows.Forms.Button btnLoad;
    private System.Windows.Forms.Button btnUpdate;
    private System.Windows.Forms.Button btnCancelAll;
    private System.Windows.Forms.DataGrid grdtblCPCategory;
    private System.Windows.Forms.DataGridTableStyle objTableStylegrdtblCPCategorytblCPCategory;
    private System.Windows.Forms.DataGridTextBoxColumn objColumnStylegrdtblCPCategoryintIdCategory;
    private System.Windows.Forms.DataGridTextBoxColumn objColumnStylegrdtblCPCategorystrCategoryName;
    private System.Windows.Forms.DataGridTextBoxColumn objColumnStylegrdtblCPCategorymemDescription;
    private System.Windows.Forms.DataGrid grdtblCPProduct;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmDataWizard()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataWizard));
      this.oleDbSelectCommand1 = new System.Data.OleDb.OleDbCommand();
      this.oleDbConnection1 = new System.Data.OleDb.OleDbConnection();
      this.oleDbInsertCommand1 = new System.Data.OleDb.OleDbCommand();
      this.oleDbUpdateCommand1 = new System.Data.OleDb.OleDbCommand();
      this.oleDbDeleteCommand1 = new System.Data.OleDb.OleDbCommand();
      this.oleDbSelectCommand2 = new System.Data.OleDb.OleDbCommand();
      this.oleDbInsertCommand2 = new System.Data.OleDb.OleDbCommand();
      this.oleDbUpdateCommand2 = new System.Data.OleDb.OleDbCommand();
      this.oleDbDeleteCommand2 = new System.Data.OleDb.OleDbCommand();
      this.oleDbDataAdapter1 = new System.Data.OleDb.OleDbDataAdapter();
      this.oleDbDataAdapter2 = new System.Data.OleDb.OleDbDataAdapter();
      this.objdsData = new DataFormWizard.dsData();
      this.btnLoad = new System.Windows.Forms.Button();
      this.btnUpdate = new System.Windows.Forms.Button();
      this.btnCancelAll = new System.Windows.Forms.Button();
      this.grdtblCPCategory = new System.Windows.Forms.DataGrid();
      this.objTableStylegrdtblCPCategorytblCPCategory = new System.Windows.Forms.DataGridTableStyle();
      this.objColumnStylegrdtblCPCategoryintIdCategory = new System.Windows.Forms.DataGridTextBoxColumn();
      this.objColumnStylegrdtblCPCategorystrCategoryName = new System.Windows.Forms.DataGridTextBoxColumn();
      this.objColumnStylegrdtblCPCategorymemDescription = new System.Windows.Forms.DataGridTextBoxColumn();
      this.grdtblCPProduct = new System.Windows.Forms.DataGrid();
      ((System.ComponentModel.ISupportInitialize)(this.objdsData)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.grdtblCPCategory)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.grdtblCPProduct)).BeginInit();
      this.SuspendLayout();
      // 
      // oleDbSelectCommand1
      // 
      this.oleDbSelectCommand1.CommandText = "SELECT intIdCategory, strCategoryName, memDescription, imgPicture FROM tblCPCateg" +
    "ory";
      this.oleDbSelectCommand1.Connection = this.oleDbConnection1;
      // 
      // oleDbConnection1
      // 
      this.oleDbConnection1.ConnectionString = "Provider=SQLNCLI11;Data Source=COPYPASTEPOWER\\COPYPASTE;Integrated Security=SSPI;" +
    "Initial Catalog=cpNorthWindScript2019";
      // 
      // oleDbInsertCommand1
      // 
      this.oleDbInsertCommand1.CommandText = "INSERT INTO [tblCPCategory] ([strCategoryName], [memDescription], [imgPicture]) V" +
    "ALUES (?, ?, ?)";
      this.oleDbInsertCommand1.Connection = this.oleDbConnection1;
      this.oleDbInsertCommand1.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("strCategoryName", System.Data.OleDb.OleDbType.VarChar, 0, "strCategoryName"),
            new System.Data.OleDb.OleDbParameter("memDescription", System.Data.OleDb.OleDbType.LongVarChar, 0, "memDescription"),
            new System.Data.OleDb.OleDbParameter("imgPicture", System.Data.OleDb.OleDbType.LongVarBinary, 0, "imgPicture")});
      // 
      // oleDbUpdateCommand1
      // 
      this.oleDbUpdateCommand1.CommandText = "UPDATE [tblCPCategory] SET [strCategoryName] = ?, [memDescription] = ?, [imgPictu" +
    "re] = ? WHERE (([intIdCategory] = ?) AND ([strCategoryName] = ?))";
      this.oleDbUpdateCommand1.Connection = this.oleDbConnection1;
      this.oleDbUpdateCommand1.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("strCategoryName", System.Data.OleDb.OleDbType.VarChar, 0, "strCategoryName"),
            new System.Data.OleDb.OleDbParameter("memDescription", System.Data.OleDb.OleDbType.LongVarChar, 0, "memDescription"),
            new System.Data.OleDb.OleDbParameter("imgPicture", System.Data.OleDb.OleDbType.LongVarBinary, 0, "imgPicture"),
            new System.Data.OleDb.OleDbParameter("Original_intIdCategory", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdCategory", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strCategoryName", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCategoryName", System.Data.DataRowVersion.Original, null)});
      // 
      // oleDbDeleteCommand1
      // 
      this.oleDbDeleteCommand1.CommandText = "DELETE FROM [tblCPCategory] WHERE (([intIdCategory] = ?) AND ([strCategoryName] =" +
    " ?))";
      this.oleDbDeleteCommand1.Connection = this.oleDbConnection1;
      this.oleDbDeleteCommand1.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("Original_intIdCategory", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdCategory", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strCategoryName", System.Data.OleDb.OleDbType.VarChar, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCategoryName", System.Data.DataRowVersion.Original, null)});
      // 
      // oleDbSelectCommand2
      // 
      this.oleDbSelectCommand2.CommandText = "SELECT intIdProduct, strProductName, intSupplierId, intCategoryId, strQuantityPer" +
    "Unit, dblUnitPrice, intUnitsInStock, intUnitsOnOrder, intReorderLevel, blnDiscon" +
    "tinued FROM tblCPProduct";
      this.oleDbSelectCommand2.Connection = this.oleDbConnection1;
      // 
      // oleDbInsertCommand2
      // 
      this.oleDbInsertCommand2.CommandText = resources.GetString("oleDbInsertCommand2.CommandText");
      this.oleDbInsertCommand2.Connection = this.oleDbConnection1;
      this.oleDbInsertCommand2.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("intIdProduct", System.Data.OleDb.OleDbType.Integer, 4, "intIdProduct"),
            new System.Data.OleDb.OleDbParameter("strProductName", System.Data.OleDb.OleDbType.VarChar, 40, "strProductName"),
            new System.Data.OleDb.OleDbParameter("intSupplierId", System.Data.OleDb.OleDbType.Integer, 4, "intSupplierId"),
            new System.Data.OleDb.OleDbParameter("intCategoryId", System.Data.OleDb.OleDbType.Integer, 4, "intCategoryId"),
            new System.Data.OleDb.OleDbParameter("strQuantityPerUnit", System.Data.OleDb.OleDbType.VarChar, 20, "strQuantityPerUnit"),
            new System.Data.OleDb.OleDbParameter("dblUnitPrice", System.Data.OleDb.OleDbType.Currency, 8, "dblUnitPrice"),
            new System.Data.OleDb.OleDbParameter("intUnitsInStock", System.Data.OleDb.OleDbType.SmallInt, 2, "intUnitsInStock"),
            new System.Data.OleDb.OleDbParameter("intUnitsOnOrder", System.Data.OleDb.OleDbType.SmallInt, 2, "intUnitsOnOrder"),
            new System.Data.OleDb.OleDbParameter("intReorderLevel", System.Data.OleDb.OleDbType.SmallInt, 2, "intReorderLevel"),
            new System.Data.OleDb.OleDbParameter("blnDiscontinued", System.Data.OleDb.OleDbType.Boolean, 1, "blnDiscontinued"),
            new System.Data.OleDb.OleDbParameter("Select_intIdProduct", System.Data.OleDb.OleDbType.Integer, 4, "intIdProduct")});
      // 
      // oleDbUpdateCommand2
      // 
      this.oleDbUpdateCommand2.CommandText = resources.GetString("oleDbUpdateCommand2.CommandText");
      this.oleDbUpdateCommand2.Connection = this.oleDbConnection1;
      this.oleDbUpdateCommand2.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("intIdProduct", System.Data.OleDb.OleDbType.Integer, 4, "intIdProduct"),
            new System.Data.OleDb.OleDbParameter("strProductName", System.Data.OleDb.OleDbType.VarChar, 40, "strProductName"),
            new System.Data.OleDb.OleDbParameter("intSupplierId", System.Data.OleDb.OleDbType.Integer, 4, "intSupplierId"),
            new System.Data.OleDb.OleDbParameter("intCategoryId", System.Data.OleDb.OleDbType.Integer, 4, "intCategoryId"),
            new System.Data.OleDb.OleDbParameter("strQuantityPerUnit", System.Data.OleDb.OleDbType.VarChar, 20, "strQuantityPerUnit"),
            new System.Data.OleDb.OleDbParameter("dblUnitPrice", System.Data.OleDb.OleDbType.Currency, 8, "dblUnitPrice"),
            new System.Data.OleDb.OleDbParameter("intUnitsInStock", System.Data.OleDb.OleDbType.SmallInt, 2, "intUnitsInStock"),
            new System.Data.OleDb.OleDbParameter("intUnitsOnOrder", System.Data.OleDb.OleDbType.SmallInt, 2, "intUnitsOnOrder"),
            new System.Data.OleDb.OleDbParameter("intReorderLevel", System.Data.OleDb.OleDbType.SmallInt, 2, "intReorderLevel"),
            new System.Data.OleDb.OleDbParameter("blnDiscontinued", System.Data.OleDb.OleDbType.Boolean, 1, "blnDiscontinued"),
            new System.Data.OleDb.OleDbParameter("Original_intIdProduct", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdProduct", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_blnDiscontinued", System.Data.OleDb.OleDbType.Boolean, 1, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "blnDiscontinued", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_dblUnitPrice", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblUnitPrice", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_dblUnitPrice1", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblUnitPrice", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intCategoryId", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intCategoryId1", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intReorderLevel", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReorderLevel", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intReorderLevel1", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReorderLevel", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intSupplierId", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intSupplierId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intSupplierId1", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intSupplierId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsInStock", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsInStock", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsInStock1", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsInStock", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsOnOrder", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsOnOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsOnOrder1", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsOnOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strProductName", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strProductName", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strQuantityPerUnit", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strQuantityPerUnit", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strQuantityPerUnit1", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strQuantityPerUnit", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Select_intIdProduct", System.Data.OleDb.OleDbType.Integer, 4, "intIdProduct")});
      // 
      // oleDbDeleteCommand2
      // 
      this.oleDbDeleteCommand2.CommandText = resources.GetString("oleDbDeleteCommand2.CommandText");
      this.oleDbDeleteCommand2.Connection = this.oleDbConnection1;
      this.oleDbDeleteCommand2.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("Original_intIdProduct", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdProduct", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_blnDiscontinued", System.Data.OleDb.OleDbType.Boolean, 1, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "blnDiscontinued", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_dblUnitPrice", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblUnitPrice", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_dblUnitPrice1", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblUnitPrice", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intCategoryId", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intCategoryId1", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intReorderLevel", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReorderLevel", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intReorderLevel1", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReorderLevel", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intSupplierId", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intSupplierId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intSupplierId1", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intSupplierId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsInStock", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsInStock", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsInStock1", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsInStock", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsOnOrder", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsOnOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsOnOrder1", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsOnOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strProductName", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strProductName", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strQuantityPerUnit", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strQuantityPerUnit", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strQuantityPerUnit1", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strQuantityPerUnit", System.Data.DataRowVersion.Original, null)});
      // 
      // oleDbDataAdapter1
      // 
      this.oleDbDataAdapter1.DeleteCommand = this.oleDbDeleteCommand1;
      this.oleDbDataAdapter1.InsertCommand = this.oleDbInsertCommand1;
      this.oleDbDataAdapter1.SelectCommand = this.oleDbSelectCommand1;
      this.oleDbDataAdapter1.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCategory", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdCategory", "intIdCategory"),
                        new System.Data.Common.DataColumnMapping("strCategoryName", "strCategoryName"),
                        new System.Data.Common.DataColumnMapping("memDescription", "memDescription"),
                        new System.Data.Common.DataColumnMapping("imgPicture", "imgPicture")})});
      this.oleDbDataAdapter1.UpdateCommand = this.oleDbUpdateCommand1;
      // 
      // oleDbDataAdapter2
      // 
      this.oleDbDataAdapter2.DeleteCommand = this.oleDbDeleteCommand2;
      this.oleDbDataAdapter2.InsertCommand = this.oleDbInsertCommand2;
      this.oleDbDataAdapter2.SelectCommand = this.oleDbSelectCommand2;
      this.oleDbDataAdapter2.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPProduct", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdProduct", "intIdProduct"),
                        new System.Data.Common.DataColumnMapping("strProductName", "strProductName"),
                        new System.Data.Common.DataColumnMapping("intSupplierId", "intSupplierId"),
                        new System.Data.Common.DataColumnMapping("intCategoryId", "intCategoryId"),
                        new System.Data.Common.DataColumnMapping("strQuantityPerUnit", "strQuantityPerUnit"),
                        new System.Data.Common.DataColumnMapping("dblUnitPrice", "dblUnitPrice"),
                        new System.Data.Common.DataColumnMapping("intUnitsInStock", "intUnitsInStock"),
                        new System.Data.Common.DataColumnMapping("intUnitsOnOrder", "intUnitsOnOrder"),
                        new System.Data.Common.DataColumnMapping("intReorderLevel", "intReorderLevel"),
                        new System.Data.Common.DataColumnMapping("blnDiscontinued", "blnDiscontinued")})});
      this.oleDbDataAdapter2.UpdateCommand = this.oleDbUpdateCommand2;
      // 
      // objdsData
      // 
      this.objdsData.DataSetName = "dsData";
      this.objdsData.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.objdsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // btnLoad
      // 
      this.btnLoad.Location = new System.Drawing.Point(10, 10);
      this.btnLoad.Name = "btnLoad";
      this.btnLoad.Size = new System.Drawing.Size(75, 23);
      this.btnLoad.TabIndex = 0;
      this.btnLoad.Text = "&Load";
      this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
      // 
      // btnUpdate
      // 
      this.btnUpdate.Location = new System.Drawing.Point(315, 10);
      this.btnUpdate.Name = "btnUpdate";
      this.btnUpdate.Size = new System.Drawing.Size(75, 23);
      this.btnUpdate.TabIndex = 1;
      this.btnUpdate.Text = "&Update";
      this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
      // 
      // btnCancelAll
      // 
      this.btnCancelAll.Location = new System.Drawing.Point(315, 43);
      this.btnCancelAll.Name = "btnCancelAll";
      this.btnCancelAll.Size = new System.Drawing.Size(75, 23);
      this.btnCancelAll.TabIndex = 2;
      this.btnCancelAll.Text = "Ca&ncel All";
      this.btnCancelAll.Click += new System.EventHandler(this.btnCancelAll_Click);
      // 
      // grdtblCPCategory
      // 
      this.grdtblCPCategory.AllowNavigation = false;
      this.grdtblCPCategory.DataMember = "tblCPCategory";
      this.grdtblCPCategory.DataSource = this.objdsData;
      this.grdtblCPCategory.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.grdtblCPCategory.Location = new System.Drawing.Point(10, 76);
      this.grdtblCPCategory.Name = "grdtblCPCategory";
      this.grdtblCPCategory.Size = new System.Drawing.Size(380, 250);
      this.grdtblCPCategory.TabIndex = 3;
      this.grdtblCPCategory.TableStyles.AddRange(new System.Windows.Forms.DataGridTableStyle[] {
            this.objTableStylegrdtblCPCategorytblCPCategory});
      // 
      // objTableStylegrdtblCPCategorytblCPCategory
      // 
      this.objTableStylegrdtblCPCategorytblCPCategory.DataGrid = this.grdtblCPCategory;
      this.objTableStylegrdtblCPCategorytblCPCategory.GridColumnStyles.AddRange(new System.Windows.Forms.DataGridColumnStyle[] {
            this.objColumnStylegrdtblCPCategoryintIdCategory,
            this.objColumnStylegrdtblCPCategorystrCategoryName,
            this.objColumnStylegrdtblCPCategorymemDescription});
      this.objTableStylegrdtblCPCategorytblCPCategory.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.objTableStylegrdtblCPCategorytblCPCategory.MappingName = "tblCPCategory";
      // 
      // objColumnStylegrdtblCPCategoryintIdCategory
      // 
      this.objColumnStylegrdtblCPCategoryintIdCategory.Format = "";
      this.objColumnStylegrdtblCPCategoryintIdCategory.FormatInfo = null;
      this.objColumnStylegrdtblCPCategoryintIdCategory.HeaderText = "intIdCategory";
      this.objColumnStylegrdtblCPCategoryintIdCategory.MappingName = "intIdCategory";
      this.objColumnStylegrdtblCPCategoryintIdCategory.Width = 75;
      // 
      // objColumnStylegrdtblCPCategorystrCategoryName
      // 
      this.objColumnStylegrdtblCPCategorystrCategoryName.Format = "";
      this.objColumnStylegrdtblCPCategorystrCategoryName.FormatInfo = null;
      this.objColumnStylegrdtblCPCategorystrCategoryName.HeaderText = "strCategoryName";
      this.objColumnStylegrdtblCPCategorystrCategoryName.MappingName = "strCategoryName";
      this.objColumnStylegrdtblCPCategorystrCategoryName.Width = 75;
      // 
      // objColumnStylegrdtblCPCategorymemDescription
      // 
      this.objColumnStylegrdtblCPCategorymemDescription.Format = "";
      this.objColumnStylegrdtblCPCategorymemDescription.FormatInfo = null;
      this.objColumnStylegrdtblCPCategorymemDescription.HeaderText = "memDescription";
      this.objColumnStylegrdtblCPCategorymemDescription.MappingName = "memDescription";
      this.objColumnStylegrdtblCPCategorymemDescription.Width = 75;
      // 
      // grdtblCPProduct
      // 
      this.grdtblCPProduct.AllowNavigation = false;
      this.grdtblCPProduct.DataMember = "tblCPCategory.ProductCategory";
      this.grdtblCPProduct.DataSource = this.objdsData;
      this.grdtblCPProduct.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.grdtblCPProduct.Location = new System.Drawing.Point(10, 336);
      this.grdtblCPProduct.Name = "grdtblCPProduct";
      this.grdtblCPProduct.Size = new System.Drawing.Size(380, 292);
      this.grdtblCPProduct.TabIndex = 4;
      // 
      // frmDataWizard
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(392, 611);
      this.Controls.Add(this.btnLoad);
      this.Controls.Add(this.btnUpdate);
      this.Controls.Add(this.btnCancelAll);
      this.Controls.Add(this.grdtblCPCategory);
      this.Controls.Add(this.grdtblCPProduct);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataWizard";
      this.Text = "frmDataWizard";
      ((System.ComponentModel.ISupportInitialize)(this.objdsData)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.grdtblCPCategory)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.grdtblCPProduct)).EndInit();
      this.ResumeLayout(false);

    }
		#endregion

    public void FillDataSet(DataFormWizard.dsData dataSet)
    {
      // Turn off constraint checking before the dataset is filled.
      // This allows the adapters to fill the dataset without concern
      // for dependencies between the tables.
      dataSet.EnforceConstraints = false;
      try 
      {
        // Open the connection.
        this.oleDbConnection1.Open();
        // Attempt to fill the dataset through the OleDbDataAdapter1.
        this.oleDbDataAdapter1.Fill(dataSet);
        this.oleDbDataAdapter2.Fill(dataSet);
      }
      catch (System.Exception fillException) 
      {
        // Add your error handling code here.
        throw fillException;
      }
      finally 
      {
        // Turn constraint checking back on.
        dataSet.EnforceConstraints = true;
        // Close the connection whether or not the exception was thrown.
        this.oleDbConnection1.Close();
      }

    }

    public void UpdateDataSource(DataFormWizard.dsData ChangedRows)
    {
      try 
      {
        // The data source only needs to be updated if there are changes pending.
        if ((ChangedRows != null)) 
        {
          // Open the connection.
          this.oleDbConnection1.Open();
          // Attempt to update the data source.
          oleDbDataAdapter1.Update(ChangedRows);
          oleDbDataAdapter2.Update(ChangedRows);
        }
      }
      catch (System.Exception updateException) 
      {
        // Add your error handling code here.
        throw updateException;
      }
      finally 
      {
        // Close the connection whether or not the exception was thrown.
        this.oleDbConnection1.Close();
      }

    }

    public void LoadDataSet()
    {
      // Create a new dataset to hold the records returned from the call to FillDataSet.
      // A temporary dataset is used because filling the existing dataset would
      // require the databindings to be rebound.
      DataFormWizard.dsData objDataSetTemp;
      objDataSetTemp = new DataFormWizard.dsData();
      try 
      {
        // Attempt to fill the temporary dataset.
        this.FillDataSet(objDataSetTemp);
      }
      catch (System.Exception eFillDataSet) 
      {
        // Add your error handling code here.
        throw eFillDataSet;
      }
      try 
      {
        grdtblCPProduct.DataSource = null;
        grdtblCPCategory.DataSource = null;
        // Empty the old records from the dataset.
        objdsData.Clear();
        // Merge the records into the main dataset.
        objdsData.Merge(objDataSetTemp);
        grdtblCPCategory.SetDataBinding(objdsData, "tblCPCategory");
        grdtblCPProduct.SetDataBinding(objdsData, "tblCPCategory.ProductCategory");
      }
      catch (System.Exception eLoadMerge) 
      {
        // Add your error handling code here.
        throw eLoadMerge;
      }

    }

    public void UpdateDataSet()
    {
      // Create a new dataset to hold the changes that have been made to the main dataset.
      DataFormWizard.dsData objDataSetChanges = new DataFormWizard.dsData();
      // Stop any current edits.
      this.BindingContext[objdsData,"tblCPCategory"].EndCurrentEdit();
      this.BindingContext[objdsData,"tblCPProduct"].EndCurrentEdit();
      // Get the changes that have been made to the main dataset.
      objDataSetChanges = ((DataFormWizard.dsData)(objdsData.GetChanges()));
      // Check to see if any changes have been made.
      if ((objDataSetChanges != null)) 
      {
        try 
        {
          // There are changes that need to be made, so attempt to update the datasource by
          // calling the update method and passing the dataset and any parameters.
          this.UpdateDataSource(objDataSetChanges);
          objdsData.Merge(objDataSetChanges);
          objdsData.AcceptChanges();
        }
        catch (System.Exception eUpdate) 
        {
          // Add your error handling code here.
          throw eUpdate;
        }
        // Add your code to check the returned dataset for any errors that may have been
        // pushed into the row object's error.
      }

    }

    private void btnCancelAll_Click(object sender, System.EventArgs e)
    {
      this.objdsData.RejectChanges();

    }

    private void btnLoad_Click(object sender, System.EventArgs e)
    {
      try 
      {
        // Attempt to load the dataset.
        this.LoadDataSet();
      }
      catch (System.Exception eLoad) 
      {
        // Add your error handling code here.
        // Display error message, if any.
        System.Windows.Forms.MessageBox.Show(eLoad.Message);
      }

    }

    private void btnUpdate_Click(object sender, System.EventArgs e)
    {
      try 
      {
        // Attempt to update the datasource.
        this.UpdateDataSet();
      }
      catch (System.Exception eUpdate) 
      {
        // Add your error handling code here.
        // Display error message, if any.
        System.Windows.Forms.MessageBox.Show(eUpdate.Message);
      }

    }

    /// <summary>
    /// The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main() 
    {
      Application.Run(new frmDataWizard());
    }

  }
}
