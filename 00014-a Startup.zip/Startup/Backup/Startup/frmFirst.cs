//***
// Action
//   - A First form 
// Created
//   - CopyPaste � 20070209 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20070209 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmFirst: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

		private System.ComponentModel.Container components = null;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFirst));
      // 
      // frmFirst
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFirst";
      this.Text = "First Form";

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmFirst'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20070209 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20070209 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmFirst()
			//***
			// Action
			//   - Create instance of 'frmFirst'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20070209 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20070209 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmFirst()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// frmFirst

}
// CopyPaste.Learning