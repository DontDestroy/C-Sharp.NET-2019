//***
// Action
//   - Show unique records in a data set
//   - Retrieve Unique Records Only Using a Select Query
//     - Show the customers that have at least one order
// Created
//   - CopyPaste � 20260114 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260114 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmUniqueRecord: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.IContainer components;
    internal System.Windows.Forms.DataGrid dgrResult;
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.Label lblSQLString;
    internal System.Windows.Forms.RadioButton optDistinct;
    internal System.Windows.Forms.RadioButton optShowAll;
    internal System.Windows.Forms.Label lblSQLStatement;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmUniqueRecord));
      this.dgrResult = new System.Windows.Forms.DataGrid();
      this.lblResult = new System.Windows.Forms.Label();
      this.lblSQLString = new System.Windows.Forms.Label();
      this.optDistinct = new System.Windows.Forms.RadioButton();
      this.optShowAll = new System.Windows.Forms.RadioButton();
      this.lblSQLStatement = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.dgrResult)).BeginInit();
      this.SuspendLayout();
      // 
      // dgrResult
      // 
      this.dgrResult.AlternatingBackColor = System.Drawing.Color.Silver;
      this.dgrResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrResult.BackColor = System.Drawing.Color.White;
      this.dgrResult.CaptionBackColor = System.Drawing.Color.Maroon;
      this.dgrResult.CaptionFont = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.CaptionForeColor = System.Drawing.Color.White;
      this.dgrResult.DataMember = "";
      this.dgrResult.Font = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.ForeColor = System.Drawing.Color.Black;
      this.dgrResult.GridLineColor = System.Drawing.Color.Silver;
      this.dgrResult.HeaderBackColor = System.Drawing.Color.Silver;
      this.dgrResult.HeaderFont = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.HeaderForeColor = System.Drawing.Color.Black;
      this.dgrResult.LinkColor = System.Drawing.Color.Maroon;
      this.dgrResult.Location = new System.Drawing.Point(16, 168);
      this.dgrResult.Name = "dgrResult";
      this.dgrResult.ParentRowsBackColor = System.Drawing.Color.Silver;
      this.dgrResult.ParentRowsForeColor = System.Drawing.Color.Black;
      this.dgrResult.PreferredColumnWidth = 400;
      this.dgrResult.SelectionBackColor = System.Drawing.Color.Maroon;
      this.dgrResult.SelectionForeColor = System.Drawing.Color.White;
      this.dgrResult.Size = new System.Drawing.Size(368, 224);
      this.dgrResult.TabIndex = 11;
      // 
      // lblResult
      // 
      this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblResult.Location = new System.Drawing.Point(16, 144);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(96, 16);
      this.lblResult.TabIndex = 10;
      this.lblResult.Text = "Results";
      // 
      // lblSQLString
      // 
      this.lblSQLString.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblSQLString.Location = new System.Drawing.Point(16, 80);
      this.lblSQLString.Name = "lblSQLString";
      this.lblSQLString.Size = new System.Drawing.Size(360, 48);
      this.lblSQLString.TabIndex = 9;
      // 
      // optDistinct
      // 
      this.optDistinct.Location = new System.Drawing.Point(96, 16);
      this.optDistinct.Name = "optDistinct";
      this.optDistinct.TabIndex = 7;
      this.optDistinct.Text = "Use Distinct";
      this.optDistinct.CheckedChanged += new System.EventHandler(this.optDistinct_CheckedChanged);
      // 
      // optShowAll
      // 
      this.optShowAll.Checked = true;
      this.optShowAll.Location = new System.Drawing.Point(16, 16);
      this.optShowAll.Name = "optShowAll";
      this.optShowAll.Size = new System.Drawing.Size(72, 24);
      this.optShowAll.TabIndex = 6;
      this.optShowAll.TabStop = true;
      this.optShowAll.Text = "Show All";
      // 
      // lblSQLStatement
      // 
      this.lblSQLStatement.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblSQLStatement.Location = new System.Drawing.Point(16, 56);
      this.lblSQLStatement.Name = "lblSQLStatement";
      this.lblSQLStatement.Size = new System.Drawing.Size(88, 16);
      this.lblSQLStatement.TabIndex = 8;
      this.lblSQLStatement.Text = "SQL Statement";
      // 
      // frmUniqueRecord
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(400, 397);
      this.Controls.Add(this.dgrResult);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.lblSQLString);
      this.Controls.Add(this.optDistinct);
      this.Controls.Add(this.optShowAll);
      this.Controls.Add(this.lblSQLStatement);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmUniqueRecord";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Retrieve Unique Records Only Using Distinct";
      this.Load += new System.EventHandler(this.frmUniqueRecord_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrResult)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmUniqueRecord'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmUniqueRecord()
      //***
      // Action
      //   - Create instance of 'frmUniqueRecord'
      // Called by
      //   - frmMain.cmdRetrieveUniqueRecord_Click(System.Object, System.EventArgs) Handles cmdRetrieveUniqueRecord.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmUniqueRecord()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmUniqueRecord_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the correct option
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - GenerateData(bool)
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      GenerateData(optDistinct.Checked);
    }
    // frmUniqueRecord_Load(System.Object, System.EventArgs) Handles MyBase.Load

    private void optDistinct_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the correct option
      // Called by
      //   - User action (Choosing an option button)
      // Calls
      //   - GenerateData(Boolean)
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      GenerateData(optDistinct.Checked);
    }
    // optDistinct_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void GenerateData(bool blnUseDistinct)
      //***
      // Action
      //   - Define a data adapter
      //   - Define and create a new data table
      //   - Define and set a sql statement
      //   - There is a little difference depending on what option is chosen
      //   - Define the data adapter with the SQL statement and the connection
      //   - Fill the data table using the data adapter
      //   - Set the data table as source for the data grid
      // Called by
      //   - frmUniqueRecord_Load(System.Object, System.EventArgs) Handles MyBase.Load
      //   - optDistinct_CheckedChanged(System.Object, System.EventArgs) Handles optDistinct.CheckedChanged
      // Calls
      //   - cpGeneralRoutines()
      //   - SqlClient.SqlConnection cpGeneralRoutines.GetConnection()
      //   - string cpGeneralRoutines.BuildConnectionString()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpGeneralRoutines theRoutines = new cpGeneralRoutines();
      DataTable dtResult = new DataTable();
      SqlDataAdapter dtaResult;
      string strSQLStatement;

      strSQLStatement = "SELECT ";

      if (blnUseDistinct)
      {
        strSQLStatement += "DISTINCT ";
      }
      else
        // Not blnUseDistinct 
      {
      }
      // blnUseDistinct 

      strSQLStatement += "tblCPCustomer.strCompanyName FROM tblCPCustomer " +
        "INNER JOIN tblCPOrder ON tblCPCustomer.strIdCustomer = tblCPOrder.strCustomerId";

      lblSQLString.Text = strSQLStatement;
      dtaResult = new SqlDataAdapter(strSQLStatement, theRoutines.GetConnection());
      // dtaResult = new SqlDataAdapter(strSQLStatement, theRoutines.BuildConnectionString());
      dtaResult.Fill(dtResult);
      dgrResult.DataSource = dtResult;
    }
    // GenerateData(bool)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmUniqueRecord

}
// CopyPaste.Learning