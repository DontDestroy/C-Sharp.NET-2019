//***
// Action
//  - Show difference between Option Explicit On and Off
//  - This program contains errors
//  - This functionality does not exist in C#, so there are compile errors
//    - The items are put in comment, with the correct C# code below it
// Created
//  - CopyPaste � 20220111 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Proposal (To Do)
//   -
//***

// Option Explicit Off
// Option Strict Off

using System;

namespace OptionExplicit
{

  class cpOptionExplicit
	{

    static void Main()
        //***
        // Action
        //   - Create Byte and Integer
        //   - Byte variable becomes Integer variable
        //   - Show Byte in console screen
        //   - Wait for user interaction
        // Called by
        //   - User action (Starting the application)
        // Calls
        //   - byte System.Convert.ToByte(Integer)
        //   - string System.Console.ReadLine()
        //   - System.Console.WriteLine(Byte)
        //   - Test()
        // Created
        //   - CopyPaste � 20220111 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220111 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
        {
            byte bytSmall;
      int intBig = 100;

      // bytSmall = intBug;
      bytSmall = Convert.ToByte(intBig);
      Console.WriteLine(bytSmall);
      Test();
      Console.ReadLine();
		}
    // Main()

    static void Test()
        //***
        // Action
        //   - Initialise two single variables
        //   - Int32 variable becomes multiplication
        //   - Show result on console screen
        // Called by
        //   - Main() 
        // Calls
        //   - int System.Convert.ToInt32(Single)
        //   - System.Console.WriteLine(Int32)
        // Created
        //   - CopyPaste � 20220111 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220111 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
        {
            int intBelgianAmount;
      float fltEuroAmount = 5000.0F;
      const float fltEuroValue = 40.3399F;
      
      // intBelgianAmount = fltEuroAmount * fltEuroValeu;
      intBelgianAmount = Convert.ToInt32(fltEuroAmount * fltEuroValue);
      Console.WriteLine(intBelgianAmount);
    }
    // Test()
    
  }
  // cpOptionExplicit

}
// OptionExplicit