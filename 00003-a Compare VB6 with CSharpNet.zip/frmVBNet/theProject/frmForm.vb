'***
' Action
'   - Creating a form, to see the difference with Visual Basic 6.0
' Created
'   - CopyPaste � 20210824 � VVDW
' Changed
'   - Organisation � yyyymmdd � Initials of programmer � What changed
' Tested
'   - CopyPaste � 20210824 � VVDW
' Proposal (To Do)
'   - List of actions that can be added to the functionality
'***

Option Explicit On 
Option Strict On

Public Class frmForm
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  Protected Overloads Overrides Sub Dispose(ByVal blnDisposing As Boolean)
    '***
    ' Action
    '   - Cleanup after closing the form
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210824 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210824 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    If blnDisposing Then

      If components Is Nothing Then
      Else
        ' Not components Is Nothing
        components.Dispose()
      End If
      ' components Is Nothing

    Else
      ' Not blnDisposing
    End If
    ' blnDisposing

    MyBase.Dispose(blnDisposing)
  End Sub
  ' Dispose(Boolean)

  Public Sub New()
    '***
    ' Action
    '   - Creating an instance of the form
    '   - Initialize the components of that form
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210824 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210824 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    MyBase.New()
    InitializeComponent()
  End Sub
  ' New()

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  Friend WithEvents cmdButton As System.Windows.Forms.Button
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Me.cmdButton = New System.Windows.Forms.Button
    Me.SuspendLayout()
    '
    'cmdButton
    '
    Me.cmdButton.Location = New System.Drawing.Point(88, 104)
    Me.cmdButton.Name = "cmdButton"
    Me.cmdButton.Size = New System.Drawing.Size(120, 40)
    Me.cmdButton.TabIndex = 0
    Me.cmdButton.Text = "Click here !"
    '
    'frmForm
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(292, 273)
    Me.Controls.Add(Me.cmdButton)
    Me.Name = "frmForm"
    Me.Text = "the Form"
    Me.ResumeLayout(False)

  End Sub

#End Region

End Class
' frmForm