﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmElixirs.aspx.cs" Inherits="CopyPaste.Learning.wfrmElixirs" %>

<!DOCTYPE html>

<html lang="uk" xmlns="http://www.w3.org/1999/html">
<head>
  <title>Copy Paste Elixirs</title>
  <link type="text/css" rel="stylesheet" href="cssLounge.css">
  <link rel="shortcut icon" href="./CopyPaste.ico">
</head>
<body>
  <form id="wfrmElixirs">
    <h1>Our Elixirs</h1>

    <h2>Green Tea Cooler</h2>
    <img src="resources/Green.gif" alt="Picture of Green Tea Cooler">
    <p class="GreenTea">
      Chock full of vitamins and minerals, this elixir combines the healthful benefits of green tea with a twist of chamomile blossoms and ginger root.
    </p>
    <h2>Raspberry Ice Concentration</h2>
    <img src="resources/LightBlue.gif" alt="Picture of Raspberry Ice Concentration">
    <p class="Raspberry">
      Combining raspberry juice with lemon grass, citrus peel and rosehips, this icy drink will make your mind feel clear and crisp.
    </p>
    <h2>Blueberry Bliss Elixir</h2>
    <img src="resources/Blue.gif" alt="Picture of Blueberry Bliss Elixir">
    <p class="Blueberry">
      Blueberries and cherry essence mixed into a base of elderflower herb tea will put you in a relaxed state of bliss in no time.
    </p class="Cranberry">
    <h2>Cranberry Antioxidant Blast</h2>
    <img src="resources/Red.gif" alt="Picture of Cranberry Antioxidant Blast">
    <p>
      Wake up to the flavors of cranberry and hibiscus in this vitamin C rich elixir.
    </p>
    <p>
      Go back to <a href="wfrmHomePage.aspx">Home</a>
    </p>
  </form>
</body>
</html>
