//***
// Action
//   - Demo the class cpTime
// Created
//   - CopyPaste � 20220301 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220301 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning.Toolkit.Time
{

  class cpProgram
	{

    static void Main()
    //***
    // Action
    //   - Define 13 (intSpacing)
    //   - Define an instance of cpTime (thecpTime1)
    //   - Define an instance of cpTime (thecpTime2)
    //   - Define an instance of cpTime (thecpTime3)
    //   - Define an instance of cpTime (thecpTime4)
    //   - Define an instance of cpTime (thecpTime5)
    //   - Define an instance of cpTime (thecpTime6)
    //   - Prepare some output
    //   - Show a messagebox with the output
    //   - Set the time of thecpTime
    //   - Repeat for all six cpTime
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpTime.New()
    //   - cpTime.New(int)
    //   - cpTime.New(int, int)
    //   - cpTime.New(int, int, int)
    //   - cpTime.New(cpTime)
    //   - cpTime.SetTime([int], [int], [int])
    //   - cpTime.ToAmericanString()
    //   - cpTime.ToUniversalString()
    //   - DialogResult MessageBox.Show(string, string) 
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      const string strSpacing = "             ";

      cpTime thecpTime1 = new cpTime();
      cpTime thecpTime2 = new cpTime(2);
      cpTime thecpTime3 = new cpTime(21, 34);
      cpTime thecpTime4 = new cpTime(12, 25, 42);
      cpTime thecpTime5 = new cpTime(27, 74, 99);
      cpTime thecpTime6 = new cpTime(thecpTime4);
      string strOutput;

      strOutput = "cpTime1: all arguments defaulted" + "\n" +
        strSpacing + thecpTime1.ToUniversalString() + "\n" +
        strSpacing + thecpTime1.ToAmericanString();
      MessageBox.Show(strOutput, "Demonstrating Overloaded Constructors");
      
      strOutput = "cpTime2: hour specified; minute and second defaulted" + "\n" +
        strSpacing + thecpTime2.ToUniversalString() + "\n" +
        strSpacing + thecpTime2.ToAmericanString();
      MessageBox.Show(strOutput, "Demonstrating Overloaded Constructors");
      
      strOutput = "cpTime3: hour and minute specified; second defaulted" + "\n" +
        strSpacing + thecpTime3.ToUniversalString() + "\n" +
        strSpacing + thecpTime3.ToAmericanString();
      MessageBox.Show(strOutput, "Demonstrating Overloaded Constructors");

      strOutput = "cpTime4: hour, minute and second specified" + "\n" +
        strSpacing + thecpTime4.ToUniversalString() + "\n" +
        strSpacing + thecpTime4.ToAmericanString();
      MessageBox.Show(strOutput, "Demonstrating Overloaded Constructors");
      
      strOutput = "cpTime5: hour specified; minute and second wrongly specified" + "\n" +
        strSpacing + thecpTime5.ToUniversalString() + "\n" +
        strSpacing + thecpTime5.ToAmericanString();
      MessageBox.Show(strOutput, "Demonstrating Overloaded Constructors");
      
      strOutput = "cpTime6: object cpTime4 specified" + "\n" +
        strSpacing + thecpTime6.ToUniversalString() + "\n" +
        strSpacing + thecpTime6.ToAmericanString();
      MessageBox.Show(strOutput, "Demonstrating Overloaded Constructors");
		}
    // Main()

	}
  // cpProgram

}
// CopyPaste.Learning.Toolkit.Time