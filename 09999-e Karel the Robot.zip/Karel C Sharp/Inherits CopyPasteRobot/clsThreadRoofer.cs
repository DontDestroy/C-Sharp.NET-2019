﻿//***
// Action
//   - Implementation of a ThreadRoofer
// Created
//   - CopyPaste – 20251105 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251105 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpThreadRoofer : cpCopyPasteRobot
	{

    #region "Constructors / Destructors"

    public cpThreadRoofer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpThreadRoofer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpThreadRoofer(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251105 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251105 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpThreadRoofer(int, int, Directions.Direction, int) 

    public cpThreadRoofer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpThreadRoofer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpThreadRoofer(int, int, Directions.Direction, int)
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251105 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251105 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpThreadRoofer(int, int, Directions.Direction, int, Color) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void BuildRoof()
    //***
    // Action
    //   - Face to the North
    //   - Repeat 5 times
    //     - Put beeper
    //     - Move diagonal right
    //   - Face to the East
    //   - Repeat 6 times
    //     - Put beeper
    //     - Move diagonal right
    // Called by
    //   - cpThreadRoofer.RooferTask()
    // Calls
    //   - cpCopyPasteRobot.DiagonalRight();
    //   - cpCopyPasteRobot.FaceEast()
    //   - cpCopyPasteRobot.FaceNorth()
    // Created
    //   - CopyPaste – 20251105 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251105 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FaceNorth();

      for (int counter = 0; counter < 5; counter++)
      {
        putBeeper();
        DiagonalRight();
      }
      // counter = 5

      FaceEast();

      for (int counter = 0; counter < 6; counter++)
      {
        putBeeper();
        DiagonalRight();
      }
      // counter = 6

    }
    // BuildRoof()

    public void GoToStartRoof()
    //***
    // Action
    //   - cpCopyPasteForwardFaceNorth
    //   - Move four forward
    // Called by
    //   - cpThreadRoofer.RooferTask()
    // Calls
    //   - cpCopyPasteRobot.FaceNorth()
    // Created
    //   - CopyPaste – 20251105 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251105 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FaceNorth();

      for (int counter = 0; counter < 4; counter++)
      {
        move();
      }
      // counter = 4

    }
    // GoToStartStartRoof()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpThreadRoofer

}
// cpKarelTheRobot