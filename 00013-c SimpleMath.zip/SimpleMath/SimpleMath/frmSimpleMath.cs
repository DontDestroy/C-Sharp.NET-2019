//***
// Action
//   - Examples of simple math calculations
// Created
//   - CopyPaste � 20210827 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210827 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Drawing;
using System.Windows.Forms;

namespace SimpleMath
{

  public class frmSimpleMath : System.Windows.Forms.Form
  {
    
    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdQuit;
    internal System.Windows.Forms.Button cmdCalculate;
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.Label Label2;
    internal System.Windows.Forms.Label lblOperator;
    internal System.Windows.Forms.RadioButton optDivide;
    internal System.Windows.Forms.RadioButton optSubtract;
    internal System.Windows.Forms.RadioButton optAdd;
    internal System.Windows.Forms.RadioButton optMultiply;
    internal System.Windows.Forms.TextBox txtNumber02;
    internal System.Windows.Forms.TextBox txtNumber01;
    internal System.Windows.Forms.RadioButton optReminder;
    private System.ComponentModel.Container components = null;
    
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSimpleMath));
      this.cmdQuit = new System.Windows.Forms.Button();
      this.cmdCalculate = new System.Windows.Forms.Button();
      this.lblResult = new System.Windows.Forms.Label();
      this.Label2 = new System.Windows.Forms.Label();
      this.lblOperator = new System.Windows.Forms.Label();
      this.optReminder = new System.Windows.Forms.RadioButton();
      this.optDivide = new System.Windows.Forms.RadioButton();
      this.optSubtract = new System.Windows.Forms.RadioButton();
      this.optAdd = new System.Windows.Forms.RadioButton();
      this.optMultiply = new System.Windows.Forms.RadioButton();
      this.txtNumber02 = new System.Windows.Forms.TextBox();
      this.txtNumber01 = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdQuit
      // 
      this.cmdQuit.Location = new System.Drawing.Point(192, 160);
      this.cmdQuit.Name = "cmdQuit";
      this.cmdQuit.TabIndex = 23;
      this.cmdQuit.Text = "Quit";
      this.cmdQuit.Click += new System.EventHandler(this.cmdQuit_Click);
      // 
      // cmdCalculate
      // 
      this.cmdCalculate.Location = new System.Drawing.Point(192, 120);
      this.cmdCalculate.Name = "cmdCalculate";
      this.cmdCalculate.TabIndex = 22;
      this.cmdCalculate.Text = "Calculate";
      this.cmdCalculate.Click += new System.EventHandler(this.cmdCalculate_Click);
      // 
      // lblResult
      // 
      this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblResult.Location = new System.Drawing.Point(216, 24);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(75, 20);
      this.lblResult.TabIndex = 21;
      // 
      // Label2
      // 
      this.Label2.Location = new System.Drawing.Point(192, 24);
      this.Label2.Name = "Label2";
      this.Label2.Size = new System.Drawing.Size(15, 20);
      this.Label2.TabIndex = 20;
      this.Label2.Text = "=";
      // 
      // lblOperator
      // 
      this.lblOperator.Location = new System.Drawing.Point(88, 24);
      this.lblOperator.Name = "lblOperator";
      this.lblOperator.Size = new System.Drawing.Size(15, 20);
      this.lblOperator.TabIndex = 19;
      this.lblOperator.Text = "+";
      // 
      // optReminder
      // 
      this.optReminder.Location = new System.Drawing.Point(24, 176);
      this.optReminder.Name = "optReminder";
      this.optReminder.Size = new System.Drawing.Size(104, 20);
      this.optReminder.TabIndex = 18;
      this.optReminder.Text = "Reminder (%)";
      this.optReminder.CheckedChanged += new System.EventHandler(this.optReminder_CheckedChanged);
      // 
      // optDivide
      // 
      this.optDivide.Location = new System.Drawing.Point(24, 156);
      this.optDivide.Name = "optDivide";
      this.optDivide.Size = new System.Drawing.Size(104, 20);
      this.optDivide.TabIndex = 17;
      this.optDivide.Text = "Divide (float /)";
      this.optDivide.CheckedChanged += new System.EventHandler(this.optDivide_CheckedChanged);
      // 
      // optSubtract
      // 
      this.optSubtract.Location = new System.Drawing.Point(24, 116);
      this.optSubtract.Name = "optSubtract";
      this.optSubtract.Size = new System.Drawing.Size(104, 20);
      this.optSubtract.TabIndex = 16;
      this.optSubtract.Text = "Subtract (-)";
      this.optSubtract.CheckedChanged += new System.EventHandler(this.optSubtract_CheckedChanged);
      // 
      // optAdd
      // 
      this.optAdd.Checked = true;
      this.optAdd.Location = new System.Drawing.Point(24, 96);
      this.optAdd.Name = "optAdd";
      this.optAdd.Size = new System.Drawing.Size(104, 20);
      this.optAdd.TabIndex = 15;
      this.optAdd.TabStop = true;
      this.optAdd.Text = "Add (+)";
      this.optAdd.CheckedChanged += new System.EventHandler(this.optAdd_CheckedChanged);
      // 
      // optMultiply
      // 
      this.optMultiply.Location = new System.Drawing.Point(24, 136);
      this.optMultiply.Name = "optMultiply";
      this.optMultiply.Size = new System.Drawing.Size(104, 20);
      this.optMultiply.TabIndex = 14;
      this.optMultiply.Text = "Multiply (*)";
      this.optMultiply.CheckedChanged += new System.EventHandler(this.optMultiply_CheckedChanged);
      // 
      // txtNumber02
      // 
      this.txtNumber02.Location = new System.Drawing.Point(104, 24);
      this.txtNumber02.Name = "txtNumber02";
      this.txtNumber02.Size = new System.Drawing.Size(75, 20);
      this.txtNumber02.TabIndex = 13;
      this.txtNumber02.Text = "";
      // 
      // txtNumber01
      // 
      this.txtNumber01.Location = new System.Drawing.Point(8, 24);
      this.txtNumber01.Name = "txtNumber01";
      this.txtNumber01.Size = new System.Drawing.Size(75, 20);
      this.txtNumber01.TabIndex = 12;
      this.txtNumber01.Text = "";
      // 
      // frmSimpleMath
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(302, 233);
      this.Controls.Add(this.cmdQuit);
      this.Controls.Add(this.cmdCalculate);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.Label2);
      this.Controls.Add(this.lblOperator);
      this.Controls.Add(this.optReminder);
      this.Controls.Add(this.optDivide);
      this.Controls.Add(this.optSubtract);
      this.Controls.Add(this.optAdd);
      this.Controls.Add(this.optMultiply);
      this.Controls.Add(this.txtNumber02);
      this.Controls.Add(this.txtNumber01);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSimpleMath";
      this.Text = "Simple Math";
      this.ResumeLayout(false);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose( bool disposing )
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210827 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210827 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if ( disposing )
      {
        if (components == null) 
        {
        }
        else
          // (components != null) 
        {
          components.Dispose();
        }
        // (components == null) 

      }
      else
        // Not ( disposing )
      {
      }
      // ( disposing )

      base.Dispose( disposing );
    }
    // Dispose( bool )
  
    public frmSimpleMath()
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    // Called by
    //   - Main()
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste � 20210827 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210827 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmSimpleMath()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCalculate_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Do a calculation
    //   - If 'txtNumber01' is not a number, show error message
    //   - If 'txtNumber02' is not a number, show error message
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - Microsoft.VisualBasic.IsNumeric(string)
    //   - System.Windows.Forms.MessageBox.Show(string)
    //   - System.Convert.ToInt32(string)
    // Created
    //   - CopyPaste � 20210827 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210827 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //   - Rewrite this exercise using int.TryParse(input, output)
    //***
    {
      int intNumber01;
      int intNumber02;
      double dblResult;
      
      try
      {
        intNumber01 = int.Parse(txtNumber01.Text);
      }
      catch
      {
        MessageBox.Show("Please type a number in the first field.");
        txtNumber01.Focus();
        return;
      }

      try
      {
        intNumber02 = int.Parse(txtNumber02.Text);
      }
      catch
      {
        MessageBox.Show("Please type a number in the second field.");
        txtNumber02.Focus();
        return;
      }
      
      switch (lblOperator.Text)
      {
        case "+":
        {
          dblResult = intNumber01 + intNumber02;
          lblResult.Text = dblResult.ToString();
          break;
        }
          // lblOperator.Text == "+"
        case "-":
        {
          dblResult = intNumber01 - intNumber02;
          lblResult.Text = dblResult.ToString();
          break;
        }
          // lblOperator.Text == "-"
        case "*":
        {
          dblResult = intNumber01 * intNumber02;
          lblResult.Text = dblResult.ToString();
          break;
        }
          // lblOperator.Text == "*"
        case "/":
        {
          dblResult = intNumber01 / intNumber02;
          lblResult.Text = dblResult.ToString();
          break;
        }
          // lblOperator.Text == "/"
        case "%":
        {
          dblResult = intNumber01 % intNumber02;
          lblResult.Text = dblResult.ToString();
          break;
        }
          // lblOperator.Text == "%"

      }
      // lblOperator.Text

    }
    // cmdCalculate_Click(System.Object, System.EventArgs)
    
    private void cmdQuit_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - End program
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210827 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210827 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.Close();
    }
    // cmdQuit_Click(System.Object, System.EventArgs)

    private void optAdd_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change 'lblOperator' to "+"
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210827 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210827 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblOperator.Text = "+";
    }
    //' optAdd_CheckedChanged(System.Object, System.EventArgs)

    private void optDivide_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change 'lblOperator' to "/"
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210827 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210827 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblOperator.Text = "/";
    }
    // optDivide_CheckedChanged(System.Object, System.EventArgs)

    private void optMultiply_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change 'lblOperator' to "*"
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210827 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210827 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblOperator.Text = "*";
    }
    // optMultiply_CheckedChanged(System.Object, System.EventArgs)

    private void optReminder_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change 'lblOperator' to "%"
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210827 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210827 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblOperator.Text = "%";
    }
    // optReminder_CheckedChanged(System.Object, System.EventArgs)

    private void optSubtract_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change 'lblOperator' to "-"
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210827 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210827 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblOperator.Text = "-";
    }
    // optSubtract_CheckedChanged(System.Object, System.EventArgs)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    // Action
    //   - Start of the application
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmSimpleMath()
    // Created
    //   - CopyPaste � 20210827 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210827 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmSimpleMath());
    }
    // Main()

    #endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSimpleMath

}
// SimpleMath