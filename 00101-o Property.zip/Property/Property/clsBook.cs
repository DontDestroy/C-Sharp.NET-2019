//***
// Action
//   - Define a cpBook (Title,  Author, Pages and Price)
//   - A constructor
// Created
//   - CopyPaste � 20220308 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220308 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning.Toolkit
{

  public class cpBook
	{

    #region "Constructors / Destructors"

    public cpBook(string strTitle, string strAuthor)
      //***
      // Action
      //   - Create a new instance of cpBook
      //   - Define the title and author
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220308 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220308 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mstrTitle = strTitle;
      mstrAuthor = strAuthor;
    }
    // cpBook(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    private double mdblBookPrice;
    private int mintBookPages;
    public string mstrAuthor;
    public string mstrTitle;

    #endregion

    #region "Properties"
    
    public int Pages
    {

      get
        //***
        // Action Get
        //   - Return mintBookPages
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220308 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220308 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mintBookPages;
      }
      // int Pages (Get)

      set
        //***
        // Action Set
        //   - Define mintBookPages
        //   - Check on positive number below 3001
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220308 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220308 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if ((value >= 0) && (value <= 3000))
        {
          mintBookPages = value;
        }
        else
          // (value < 0) || (value > 3000) 
        {
          MessageBox.Show("Invalid page count for " + mstrTitle);
          mintBookPages = 0;
        }
        // (value >= 0) And (value <= 3000) 

      }
      // Pages(int) (Set)

    }
    // int Pages

    public double Price
    {
      
      get
        //***
        // Action Get
        //   - Return mdblBookPrice
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220308 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220308 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdblBookPrice;
      }
      // double Price (Get)

      set
        //***
        // Action Set
        //   - Define mdblBookPrice
        //   - Check on positive number below 500
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220308 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220308 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if ((value >= 0) && (value <= 500))
        {
          mdblBookPrice = value;
        }
        else
          // (value < 0) || (value > 500) 
        {
          MessageBox.Show("Invalid price for " + mstrTitle);
          mdblBookPrice = 0;
        }
        // (value >= 0) && (value <= 500) 

      }
      // Price(double) (Set)

    }
    // double Price

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

	}
  // cpBook

}
// CopyPaste.Learning.Toolkit