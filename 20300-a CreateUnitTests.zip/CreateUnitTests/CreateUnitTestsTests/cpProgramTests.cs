﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CopyPaste.Learning;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Learning.Tests
{
  [TestClass()]
  public class cpProgramTests
  {
    [TestMethod()]
    public void PrintDateTest()
    {
      Assert.Fail();
    }

  }
}