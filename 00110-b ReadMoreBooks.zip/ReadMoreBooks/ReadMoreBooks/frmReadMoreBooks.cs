//***
// Action
//   - Definition of a frmReadMoreBooks
// Created
//   - CopyPaste � 20240106 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240106 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmReadMoreBooks: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

    internal System.Windows.Forms.Label lblDisplay;
    internal System.Windows.Forms.Label lblPageLength;
    internal System.Windows.Forms.Label lblListOfBooks;
    internal System.Windows.Forms.Label lblTitle;
    internal System.Windows.Forms.RichTextBox txtPage;
    internal System.Windows.Forms.NumericUpDown nudPageToDisplay;
    internal System.Windows.Forms.NumericUpDown nudPageLength;
    internal System.Windows.Forms.ListBox lstBooks;
		private System.ComponentModel.Container components = null;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmReadMoreBooks));
      this.lblDisplay = new System.Windows.Forms.Label();
      this.lblPageLength = new System.Windows.Forms.Label();
      this.lblListOfBooks = new System.Windows.Forms.Label();
      this.lblTitle = new System.Windows.Forms.Label();
      this.txtPage = new System.Windows.Forms.RichTextBox();
      this.nudPageToDisplay = new System.Windows.Forms.NumericUpDown();
      this.nudPageLength = new System.Windows.Forms.NumericUpDown();
      this.lstBooks = new System.Windows.Forms.ListBox();
      ((System.ComponentModel.ISupportInitialize)(this.nudPageToDisplay)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudPageLength)).BeginInit();
      this.SuspendLayout();
      // 
      // lblDisplay
      // 
      this.lblDisplay.Location = new System.Drawing.Point(168, 148);
      this.lblDisplay.Name = "lblDisplay";
      this.lblDisplay.Size = new System.Drawing.Size(100, 16);
      this.lblDisplay.TabIndex = 14;
      this.lblDisplay.Text = "Page to display";
      // 
      // lblPageLength
      // 
      this.lblPageLength.Location = new System.Drawing.Point(16, 148);
      this.lblPageLength.Name = "lblPageLength";
      this.lblPageLength.TabIndex = 12;
      this.lblPageLength.Text = "Page length";
      // 
      // lblListOfBooks
      // 
      this.lblListOfBooks.Location = new System.Drawing.Point(16, 12);
      this.lblListOfBooks.Name = "lblListOfBooks";
      this.lblListOfBooks.Size = new System.Drawing.Size(100, 16);
      this.lblListOfBooks.TabIndex = 8;
      this.lblListOfBooks.Text = "List of books";
      // 
      // lblTitle
      // 
      this.lblTitle.Location = new System.Drawing.Point(128, 12);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(152, 16);
      this.lblTitle.TabIndex = 10;
      // 
      // txtPage
      // 
      this.txtPage.Location = new System.Drawing.Point(168, 36);
      this.txtPage.Name = "txtPage";
      this.txtPage.Size = new System.Drawing.Size(120, 96);
      this.txtPage.TabIndex = 11;
      this.txtPage.Text = "";
      // 
      // nudPageToDisplay
      // 
      this.nudPageToDisplay.Location = new System.Drawing.Point(168, 172);
      this.nudPageToDisplay.Minimum = new System.Decimal(new int[] {
                                                                     1,
                                                                     0,
                                                                     0,
                                                                     0});
      this.nudPageToDisplay.Name = "nudPageToDisplay";
      this.nudPageToDisplay.TabIndex = 15;
      this.nudPageToDisplay.Value = new System.Decimal(new int[] {
                                                                   1,
                                                                   0,
                                                                   0,
                                                                   0});
      this.nudPageToDisplay.ValueChanged += new System.EventHandler(this.nudPageToDisplay_ValueChanged);
      // 
      // nudPageLength
      // 
      this.nudPageLength.Location = new System.Drawing.Point(16, 172);
      this.nudPageLength.Minimum = new System.Decimal(new int[] {
                                                                  1,
                                                                  0,
                                                                  0,
                                                                  0});
      this.nudPageLength.Name = "nudPageLength";
      this.nudPageLength.TabIndex = 13;
      this.nudPageLength.Value = new System.Decimal(new int[] {
                                                                1,
                                                                0,
                                                                0,
                                                                0});
      this.nudPageLength.ValueChanged += new System.EventHandler(this.nudPageLength_ValueChanged);
      // 
      // lstBooks
      // 
      this.lstBooks.Location = new System.Drawing.Point(16, 36);
      this.lstBooks.Name = "lstBooks";
      this.lstBooks.Size = new System.Drawing.Size(120, 95);
      this.lstBooks.Sorted = true;
      this.lstBooks.TabIndex = 9;
      this.lstBooks.SelectedIndexChanged += new System.EventHandler(this.lstBooks_SelectedIndexChanged);
      // 
      // frmReadMoreBooks
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(304, 205);
      this.Controls.Add(this.lblDisplay);
      this.Controls.Add(this.lblPageLength);
      this.Controls.Add(this.lblListOfBooks);
      this.Controls.Add(this.lblTitle);
      this.Controls.Add(this.txtPage);
      this.Controls.Add(this.nudPageToDisplay);
      this.Controls.Add(this.nudPageLength);
      this.Controls.Add(this.lstBooks);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmReadMoreBooks";
      this.Text = "Read Books";
      this.Load += new System.EventHandler(this.frmReadMoreBooks_Load);
      ((System.ComponentModel.ISupportInitialize)(this.nudPageToDisplay)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudPageLength)).EndInit();
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmReadMoreBooks'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240106 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240106 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - List of actions that can be added to the functionality
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmReadMoreBooks()
			//***
			// Action
			//   - Create instance of 'frmReadMoreBooks'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240106 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240106 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - List of actions that can be added to the functionality
			//***
		{
			InitializeComponent();
		}
		// frmReadMoreBooks()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"

    private void frmReadMoreBooks_Load(System.Object thesender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try
      //     - Two cpBooks are defined
      //     - Both books gets a text (variable)
      //     - Both books gets a title (property)
      //     - Add both books to an array of cpBooks
      //     - Array of cpBooks is the datasource of the listbox
      //     - A wrong book is added
      //   - If error
      //     - Show error message
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpBook(string, string)
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBook thecpCookies;
      cpBook thecpFairyTales;
      cpBook thecpWrongBook;
      cpBook[] arrcpLibrary;

      try
      {
        // Happy flow
        thecpCookies = new cpBook("Cookies", "Chocolate chip cookies are the most delicious cookies.");
        thecpFairyTales = new cpBook("Fairy Tales", "Once upon a time there was a bear.");
        
        arrcpLibrary = new cpBook[] {thecpFairyTales, thecpCookies};
        lstBooks.DataSource = arrcpLibrary;
        lstBooks.SelectedIndex = -1; // Select no item

        // Not Happy flow, will be trigger the catch
        thecpWrongBook = new cpBook("Book with no text", "");
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }

    }
    // frmReadMoreBooks_Load(System.Object, System.EventArgs) Handles this.Load

    private void lstBooks_SelectedIndexChanged(System.Object thesender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there is an item selected in the listbox
      //     - Get the title of the selected item
      //     - Define the pagelength of the book by the value of the numeric up down component
      //     - Define the page of the book by the value of the numeric up down component
      //     - Show the title on the screen
      //     - Show the pagetext on the screen
      //   - If Not
      //     - Do nothing
      // Called by
      //   - nudPageLength_ValueChanged(System.Object, System.EventArgs) Handles nudPageLength.ValueChanged
      //   - nudPageToDisplay_ValueChanged(System.Object, System.EventArgs) Handles nudPageToDisplay.ValueChanged
      //   - User action (Selecting an item in a listbox)
      // Calls
      //   - string cpBook.GetPage(int)
      //   - string cpBook.Title (Get)
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBook thecpBook;

      if (lstBooks.SelectedItem == null)
      {
      }
      else
        // lstBooks.SelectedItem <> null
      {
        thecpBook = lstBooks.SelectedItem as cpBook;
        lblTitle.Text = thecpBook.Title;
        thecpBook.mlngPageLength = Convert.ToInt32(nudPageLength.Value);
        txtPage.Text = thecpBook.GetPage(Convert.ToInt32(nudPageToDisplay.Value));
      }
      // lstBooks.SelectedItem = null
    
    }
    // lstBooks_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBooks.SelectedIndexChanged

    private void nudPageLength_ValueChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Starts an event as if you selected an item in the listbox
      // Called by
      //   - User action (Changing a value of a numeric up down)
      // Calls
      //   - lstBooks_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBooks.SelectedIndexChanged
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      lstBooks_SelectedIndexChanged(this.lstBooks, new EventArgs());
    }
    // nudPageLength_ValueChanged(System.Object, System.EventArgs) Handles nudPageLength.ValueChanged
    
    private void nudPageToDisplay_ValueChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Starts an event as if you selected an item in the listbox
      // Called by
      //   - User action (Changing a value of a numeric up down)
      // Calls
      //   - lstBooks_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBooks.SelectedIndexChanged
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      lstBooks_SelectedIndexChanged(this.lstBooks, new EventArgs());
    }
    // nudPageToDisplay_ValueChanged(System.Object, System.EventArgs) Handles nudPageToDisplay.ValueChanged

    #endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmReadMoreBooks
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmReadMoreBooks()
			// Created
			//   - CopyPaste � yyyymmdd � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � yyyymmdd � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - List of actions that can be added to the functionality
			//***
		{
			Application.Run(new frmReadMoreBooks());
		}
  	// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmReadMoreBooks

}
// CopyPaste.Learning