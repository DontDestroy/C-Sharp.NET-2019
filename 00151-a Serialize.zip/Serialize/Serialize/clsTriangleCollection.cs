//***
// Action
//   - Implementation of a cpTriangleCollection that is serializable
//   - A list of cpTriangles is in the collection (0, 1 or more cpTriangle)
// Created
//   - CopyPaste � 20240408 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240408 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;

namespace CopyPaste.Learning
{

  // The Serializable attritube marks the class to be serializable
  [SerializableAttribute()]
  public class cpTriangleCollection : CollectionBase
  {

    #region "Constructors / Destructors"

    public cpTriangleCollection()
      //***
      // Action
      //   - Default constructor
      // Called by
      //   - frmSerialize.cmdLoadXML_Click(System.Object, System.EventArgs) Handles cmdLoadXML.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpTriangleCollection()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public cpTriangle this[int lngIndex]
    {

      get
        //***
        // Action Get
        //   - Indexer of cpTriangleCollection that returns a specific cpTriangle
        // Called by
        //   - cpTriangle[] ToArray()
        //   - frmSerialize.cmdSaveXML_Click(System.Object, System.EventArgs) Handles cmdSaveXML.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240408 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240408 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return (cpTriangle)InnerList[lngIndex];
      }
      // cpTriangle this[int] (Get)

      set
        //***
        // Action Set
        //   - An indexer of cpTriangleCollection becomes value
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240408 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240408 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        InnerList[lngIndex] = value;
      }
      // this[int](cpTriangle) (Set)

    }
    // cpTriangle this[int]

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Visualisation of a cpTriagleCollection
      //   - Given by the coordinates of the 3 points of all cpTriangles
      // Called by
      //   - 
      // Calls
      //   - string cpTriangle.ToString()
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strTriangle = "";

      foreach (cpTriangle thecpTriangle in InnerList)
      {
        strTriangle += thecpTriangle.ToString() + Environment.NewLine;
      }
      // in InnerList

      return strTriangle;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Add(cpTriangle thecpTriangle)
      //***
      // Action
      //   - Add a triangle to the collection
      // Called by
      //   - frmSerialize.cmdAddTriangle_Click(System.Object, System.EventArgs) Handles cmdAddTriangle.Click
      //   - frmSerialize.cmdLoadXML_Click(System.Object, System.EventArgs) Handles cmdLoadXML.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InnerList.Add(thecpTriangle);
    }
    // Add(cpTriangle)

    public void Remove(cpTriangle thecpTriangle)
      //***
      // Action
      //   - Remove a triangle from the collection
      // Called by
      //   - frmSerialize.cmdRemoveTriangle_Click(System.Object, System.EventArgs) Handles cmdRemoveTriangle.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InnerList.Remove(thecpTriangle);
    }
    // Remove(cpTriangle)

    public cpTriangle[] ToArray()
      //***
      // Action
      //   - Convert the collection of cpTriangles towards an array of triangles
      // Called by
      //   - frmSerialize.cmdAddTriangle_Click(System.Object, System.EventArgs) Handles cmdAddTriangle.Click
      //   - frmSerialize.cmdLoadBinary_Click(System.Object, .EventArgs) Handles cmdLoadBinary.Click
      //   - frmSerialize.cmdLoadXML_Click(System.Object, System.EventArgs) Handles cmdLoadXML.Click
      //   - frmSerialize.cmdRemoveTriangle_Click(System.Object, System.EventArgs) Handles cmdRemoveTriangle.Click
      // Calls
      //   - cpTriangle this(int) (Get)
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - Alternative. Use InnerList.ToArray()
      //***
    {
      cpTriangle[] arrTriangle = new cpTriangle[Count];
      int lngCounter;

      for (lngCounter = 0; lngCounter < Count; lngCounter++)
      {
        arrTriangle[lngCounter] = (cpTriangle)InnerList[lngCounter];
      }
      // lngCounter = Count

      return arrTriangle;
    }
    // cpTriangle[] ToArray()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpTriangleCollection

}
// CopyPaste.Learning