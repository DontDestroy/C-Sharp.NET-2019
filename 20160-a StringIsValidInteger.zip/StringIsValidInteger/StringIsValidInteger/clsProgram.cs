﻿//***
// Action
//   - Code to test a string extension
// Created
//   - CopyPaste – 20260129 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260129 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - 
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - bool cpStringExtension.IsValidInteger()
    //   - bool cpStringExtension.IsValidInteger(int)
    // Created
    //   - CopyPaste – 20260129 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260129 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intResult;
      string strTest01 = "ABC";
      string strTest02 = "123";

      if (strTest01.IsValidInteger())
      {
        Console.WriteLine($"{strTest01} is a valid integer");
      }
      else
      // Not strTest01.IsValidInteger()
      {
        Console.WriteLine($"{strTest01} is not a valid integer");
      }
      // strTest01.IsValidInteger()

      if (strTest02.IsValidInteger())
      {
        Console.WriteLine($"{strTest02} is a valid integer");
      }
      else
      // Not strTest02.IsValidInteger()
      {
        Console.WriteLine($"{strTest02} is not a valid integer");
      }
      // strTest02.IsValidInteger()

      if (strTest01.IsValidInteger(out intResult))
      {
        Console.WriteLine($"{strTest01} is a valid integer with value {intResult}");
      }
      else
      // Not strTest01.IsValidInteger(out intResult)
      {
        Console.WriteLine($"{strTest01} is not a valid integer with value {intResult}");
      }
      // strTest01.IsValidInteger(out intResult)

      if (strTest02.IsValidInteger(out intResult))
      {
        Console.WriteLine($"{strTest02} is a valid integer with value {intResult}");
      }
      else
      // Not strTest02.IsValidInteger(out intResult)
      {
        Console.WriteLine($"{strTest02} is not a valid integer with value {intResult}");
      }
      // strTest02.IsValidInteger(out intResult)

      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning