﻿//***
// Action
//   - The test routine for starting up the application
// Created
//   - CopyPaste – 20220815 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220815 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows;

namespace theApplication
{
  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute()]
    static void Main()
    //***
    // Action
    //   - Create a new application
    //   - Create a new startup screen
    //   - Option 1
    //     - Run the application with the startup screen
    //   - Option 2 (alternative)
    //     - Startup screen becomes the main window of the application
    //     - Startup screen is shown
    //     - The application is runned
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpWindow()
    // Created
    //   - CopyPaste – 20220815 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220815 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application theApplication = new Application();  // Create instance of Application
      wpfWindow cpStartupScreen = new wpfWindow(); // Create instance of wpfWindow

      // Option 1
      theApplication.Run(cpStartupScreen); // Start the application with the Startup screen
      // All code after the run will be runned when the last windows closes

      // // Option 2 (alternative)
      // theApplication.MainWindow = cpStartupScreen;
      // cpStartupScreen.Show();
      // theApplication.Run();
      // // All code after the run will be runned when the last windows closes
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// theApplication