﻿//***
// Action
//   - Hardcoded connectionstring
//   - Returning a connection
// Created
//   - CopyPaste – 20251211 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251211 – VVDW
// Proposal (To Do)
//   -
//***

using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpGeneralRoutines
  {

    #region "Constructors / Destructors"

    public cpGeneralRoutines()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - frmMultiSelectList.cmdSelect_Click(System.Object, System.EventArgs) Handles cmdSelect.Click
      //   - frmMultiSelectList.cmdUnSelect_Click(System.Object, System.EventArgs) Handles cmdUnSelect.Click
      //   - frmMultiSelectList.frmMultiSelectList_Load(System.Object, System.EventArgs) Handles MyBase.Load
      //   - frmMultiSelectList.LoadProduct(bool)
      //   - frmPointAndClickQuery.frmPointAndClickQuery_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmTrySearch.LoadIndividual(string)
      //   - frmUpdateMultipleLookupTable.frmUpdateMultipleLookupTable_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251211 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251211 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpGeneralRoutines()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private string BuildConnectionString()
      //***
      // Action
      //   - Return a hardcode connectionstring
      // Called by
      //   - SqlClient.SqlConnection GetConnection() 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251211 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251211 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "";
    }
    // string BuildConnectionString()

    public SqlConnection GetConnection()
      //***
      // Action
      //   - Create a sql connection
      //   - Set the connectionstring to the hardcoded connectionstring
      //   - Return the connection
      // Called by
      //   - frmMultiSelectList.cmdSelect_Click(System.Object, System.EventArgs) Handles cmdSelect.Click
      //   - frmMultiSelectList.cmdUnSelect_Click(System.Object, System.EventArgs) Handles cmdUnSelect.Click
      //   - frmMultiSelectList.frmMultiSelectList_Load(System.Object, System.EventArgs) Handles MyBase.Load
      //   - frmMultiSelectList.LoadProduct(bool)
      //   - frmPointAndClickQuery.frmPointAndClickQuery_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmTrySearch.LoadIndividual(string)
      //   - frmUpdateMultipleLookupTable.frmUpdateMultipleLookupTable_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - string BuildConnectionString()
      // Created
      //   - CopyPaste – 20251211 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251211 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return new SqlConnection();
    }
    // SqlConnection GetConnection()

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpGeneralRoutines

}
// CopyPaste.Learning