﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace BackgroundWorker
{

  public partial class App : Application
  {
  }
  // App

}
// BackgroundWorker