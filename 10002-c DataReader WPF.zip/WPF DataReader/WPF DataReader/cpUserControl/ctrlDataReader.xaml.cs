﻿//***
// Action
//   - Having a Data Reader towards a database
//   - Interaction logic for ctrlDataReader.xaml (part of MainWindow.xaml)
// Created
//   - CopyPaste – 20210819 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210819 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System.Text;
using System.Windows.Controls;
using WPFDataReader.ViewModel;

namespace WPFDataReader.cpUserControl
{

  public partial class ctrlDataReader : UserControl
  {

    #region "Constructors / Destructors"

    public ctrlDataReader()
    //***
    // Action
    //   - Creating an instance of the WPF control
    //   - Initialize the components of that control
    //   - Define a cpDataReaderViewModel
    // Called by
    //   - User Action Or System action (Showing the control)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
      _viewModel = (cpDataReaderViewModel)this.Resources["viewModel"];
    }
    // ctrlCommand()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    private readonly cpDataReaderViewModel _viewModel;

    private void cmdDataReader_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - cpDataReaderViewModel.GetProductsAsDataReader()
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      _viewModel.GetProductsAsDataReader();
    }
    // cmdDataReader_Click(System.Object, System.Windows.RoutedEventArgs)

    private void cmdExtensionMethods_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   -  ObservableCollection<cpProduct> cpDataReaderViewModel.GetProductsUsingExtensionMethods()
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      _viewModel.GetProductsUsingExtensionMethods();
    }
    // cmdExtensionMethods_Click(System.Object, System.Windows.RoutedEventArgs)

    private void cmdFieldValue_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - ObservableCollection<cpProduct> cpDataReaderViewModel.GetProductsUsingFieldValue()
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      _viewModel.GetProductsUsingFieldValue();
    }
    // cmdFieldValue_Click(System.Object, System.Windows.RoutedEventArgs)

    private void cmdGenericList_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - ObservableCollection<cpProduct> cpDataReaderViewModel.GetProductsAsGenericList()
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      _viewModel.GetProductsAsGenericList();
    }
    // cmdGenericList_Click(System.Object, System.Windows.RoutedEventArgs)

    private void cmdMultipleResultSets_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - cpDataReaderViewModel.GetMultipleResultSets()
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      _viewModel.GetMultipleResultSets();
    }
    // cmdMultipleResultSets_Click(System.Object, System.Windows.RoutedEventArgs)

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    // (System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Insert a product with parameters and return one parameter
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - int cpCommandViewModel.InsertProductOutputParameters()
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***

    #endregion

    //#region "Functionality"

    #region "Event"
    private void OnAutoGeneratingColumn(System.Object theSender, DataGridAutoGeneratingColumnEventArgs theDataGridAutoGeneratingColumnEventArguments)
    //***
    // Action
    //   - Defining the column in a specific format for dates
    //   - If the Column is of PropertyType DateTime
    //     - Set a specific format (European date)
    // Called by
    //   - User Action Or System action (Showing the control)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //   - Functionality fails if field is nullable (Retire is hardcoded)
    //***
    {
      if (theDataGridAutoGeneratingColumnEventArguments.PropertyType == typeof(System.DateTime))
      {
        (theDataGridAutoGeneratingColumnEventArguments.Column as DataGridTextColumn).Binding.StringFormat = "dd/MM/yyyy HH:mm:ss";
      }
      else
      // (theDataGridAutoGeneratingColumnEventArguments.PropertyType != typeof(System.DateTime))
      {

        if (theDataGridAutoGeneratingColumnEventArguments.PropertyName == "Retire")
        {
          (theDataGridAutoGeneratingColumnEventArguments.Column as DataGridTextColumn).Binding.StringFormat = "dd/MM/yyyy HH:mm:ss";
        }
        else
        // (theDataGridAutoGeneratingColumnEventArguments.PropertyName != "Retire")
        {
        }
        // (theDataGridAutoGeneratingColumnEventArguments.PropertyName == "Retire")

      }
      // (theDataGridAutoGeneratingColumnEventArguments.PropertyType == typeof(System.DateTime))

    }
    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // ctrlDataReader

}
// WPFDataReader.cpUserControl