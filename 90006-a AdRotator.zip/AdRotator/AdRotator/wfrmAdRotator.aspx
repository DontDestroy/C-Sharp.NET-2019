﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmAdRotator.aspx.cs" Inherits="CopyPaste.Learning.wfrmAdRotator" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Advertisement Rotator</title>
</head>
  <body MS_POSITIONING="GridLayout">
    <form id="wfrmAdRotator" method="post" runat="server">
      <asp:AdRotator id="adrTravelAdvise" style="Z-INDEX: 101; POSITION: absolute; TOP: 16px; LEFT: 112px"
        runat="server" Width="40px" Height="32px" AdvertisementFile="Countries.xml"></asp:AdRotator>
      <asp:Label id="lblTravelAdvise" style="Z-INDEX: 102; POSITION: absolute; TOP: 16px; LEFT: 16px"
        runat="server">Travel advise</asp:Label>
    </form>
  </body>
</html>
