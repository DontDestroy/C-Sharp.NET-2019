//***
// Action
//   - Startup screen of the application
//   - Form will be hidden, but an icon in the tray will be shown
//   - With the tray icon, you can select some menu items
// Created
//   - CopyPaste � 20250806 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250806 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.PostIt
{

  public class frmNoteStartup: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmNoteStartup));
      this.notIcon = new System.Windows.Forms.NotifyIcon(this.components);
      // 
      // notIcon
      // 
      this.notIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notIcon.Icon")));
      this.notIcon.Text = "Sticky";
      this.notIcon.Visible = true;
      // 
      // frmNoteStartup
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmNoteStartup";
      this.Opacity = 0;
      this.ShowInTaskbar = false;
      this.Text = "Note Startup";

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmNoteStartup'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - cpStickyOrganiser.SaveData()
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {
        mcpNoteOrganisation.SaveData();

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmNoteStartup()
      //***
      // Action
      //   - Create instance of 'frmNoteStartup'
      // Called by
      //   - Main()
      // Calls
      //   - AddContextMenu()
      //   - cpStickyOrganiser()
      //   - cpStickyOrganiser.ReadData()
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      mcpNoteOrganisation = new cpStickyOrganiser();
      AddContextMenu();
      mcpNoteOrganisation.ReadData();
    }
    // frmNoteStartup()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static cpStickyOrganiser mcpNoteOrganisation;
    private ContextMenu mctmContextMenu = new ContextMenu();
    private MenuItem mmnuHideAll = new MenuItem("Hide All");
    private MenuItem mmnuNewNote = new MenuItem("New Note");
    private MenuItem mmnuQuitProgram = new MenuItem("Quit Program");
    private MenuItem mmnuSaveAll = new MenuItem("Save All");
    internal System.Windows.Forms.NotifyIcon notIcon;
    private MenuItem mmnuShowAll = new MenuItem("Show All");

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private void mnuHide(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Hide all the sticky notes
      // Called by
      //   - AddContextMenu()
      // Calls
      //   - cpNoteOrganisation.HideAll()
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpNoteOrganisation.HideAll();
    }
    // mnuHide(System.Object, System.EventArgs)

    private void mnuNew(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new sticky note
      //   - Set the text to today
      //   - Set the tag to now
      //   - Show the sticky note
      //   - Add the sticky note to the array of notes
      // Called by
      //   - AddContextMenu()
      // Calls
      //   - cpNoteOrganisation.AddNewNote(frmStickyNote)
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmStickyNote theNote = new frmStickyNote();
      
      theNote.Text = DateTime.Now.ToString("dd/MM/yyyy");
      theNote.Tag = DateTime.Now;
      theNote.Show();
      mcpNoteOrganisation.AddNewNote(theNote);
    }
    // mnuNew(System.Object, System.EventArgs)

    private void mnuQuit(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Close the application
      // Called by
      //   - AddContextMenu()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Dispose();
    }
    // mnuQuit(System.Object, System.EventArgs)

    private void mnuSave(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Save (Serialize) all the sticky notes
      //     - Go from object to a readable (saveable) format (in this case xml)
      // Called by
      //   - AddContextMenu()
      // Calls
      //   - cpNoteOrganisation.SaveData()
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpNoteOrganisation.SaveData();
    }
    // mnuSave(System.Object, System.EventArgs)

    private void mnuShow(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show all the sticky notes
      // Called by
      //   - AddContextMenu()
      // Calls
      //   - cpNoteOrganisation.ShowAll()
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpNoteOrganisation.ShowAll();
    }
    // mnuShow(System.Object, System.EventArgs)

    #endregion

    #region "Sub / Function"

    private void AddContextMenu()
      //***
      // Action
      //   - Define 5 context menu items
      //     - Add note, hide notes, show notes, save notes (Is alsoby default on closing), quit application
      //   - Add the context menu items to the notification icon
      //   - Add the corresponding handler to it
      // Called by
      //   - User action (Clicking context menu item)
      // Calls
      //   - mnuHide(System.Object, System.EventArgs)
      //   - mnuNew(System.Object, System.EventArgs)
      //   - mnuQuit(System.Object, System.EventArgs)
      //   - mnuSave(System.Object, System.EventArgs)
      //   - mnuShow(System.Object, System.EventArgs)
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mctmContextMenu.MenuItems.Add(mmnuNewNote);
      mctmContextMenu.MenuItems.Add(mmnuHideAll);
      mctmContextMenu.MenuItems.Add(mmnuShowAll);
      mctmContextMenu.MenuItems.Add(mmnuSaveAll);
      mctmContextMenu.MenuItems.Add(mmnuQuitProgram);

      notIcon.ContextMenu = mctmContextMenu;
      mmnuNewNote.Click += new EventHandler(mnuNew);
      mmnuHideAll.Click += new EventHandler(mnuHide);
      mmnuShowAll.Click += new EventHandler(mnuShow);
      mmnuQuitProgram.Click += new EventHandler(mnuQuit);
      mmnuSaveAll.Click += new EventHandler(mnuSave);
    }
    // AddContextMenu()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmNoteStartup
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmNoteStartup()
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmNoteStartup());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmNoteStartup

}
// CopyPaste.Learning.PostIt