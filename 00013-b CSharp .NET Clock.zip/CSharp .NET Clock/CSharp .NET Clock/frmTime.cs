//***
// Action
//   - Show the time in a windows form
// Created
//   - CopyPaste � 20240107 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240107 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmTime: System.Windows.Forms.Form
	{
    internal System.Windows.Forms.Label lblTime;
    internal System.Windows.Forms.NotifyIcon notIcon;
    internal System.Windows.Forms.Timer tmrTimer;
    private System.ComponentModel.IContainer components;

		#region Windows Form Designer generated code


		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTime));
      this.lblTime = new System.Windows.Forms.Label();
      this.notIcon = new System.Windows.Forms.NotifyIcon(this.components);
      this.tmrTimer = new System.Windows.Forms.Timer(this.components);
      this.SuspendLayout();
      // 
      // lblTime
      // 
      this.lblTime.BackColor = System.Drawing.Color.LemonChiffon;
      this.lblTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblTime.ForeColor = System.Drawing.Color.Blue;
      this.lblTime.Location = new System.Drawing.Point(23, 21);
      this.lblTime.Name = "lblTime";
      this.lblTime.Size = new System.Drawing.Size(248, 23);
      this.lblTime.TabIndex = 1;
      // 
      // notIcon
      // 
      this.notIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("notIcon.Icon")));
      this.notIcon.Text = "VB .NET Time";
      this.notIcon.Visible = true;
      // 
      // tmrTimer
      // 
      this.tmrTimer.Enabled = true;
      this.tmrTimer.Interval = 500;
      this.tmrTimer.Tick += new System.EventHandler(this.tmrTimer_Tick);
      // 
      // frmTime
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(294, 64);
      this.Controls.Add(this.lblTime);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTime";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "C# .NET Time";
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmTime'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240107 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240107 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmTime()
			//***
			// Action
			//   - Create instance of 'frmTime'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240107 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240107 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmTime()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"
    
    private void tmrTimer_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show time in a form, with different methods
      //   - Show notification icon (Can be seen in the taskbar)
      // Called by
      //   - System action (Timer tick is passed)
      // Calls
      //   - Microsoft.VisualBasic.Strings.FormatDateTime(Date, Microsoft.VisualBasic.DateFormat.LongDate)
      //   - System.DateTime.Now()
      // Created
      //   - CopyPaste � 20240107 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240107 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DateTime dtmDateTime = DateTime.Now;
      string strMessageDate;

      // strMessageDate = Strings.FormatDateTime(dtmDateTime, DateFormat.LongDate) + " ";
      // strMessageDate = dtmDateTime.ToString("HH:mm:ss tt");
      strMessageDate = dtmDateTime.ToString("F");
      lblTime.Text = strMessageDate;
      notIcon.Text = strMessageDate;
    }
    // tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick

    #endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmTime
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmTime()
			// Created
			//   - CopyPaste � 20240107 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240107 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmTime());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmTime

}
// CopyPaste.Learning