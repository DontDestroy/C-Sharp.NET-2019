//***
// Action
//   - Click 100 times on the form to fill the progress bar
// Created
//   - CopyPaste � 20240312 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240312 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmProgressBar: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblText;
    internal System.Windows.Forms.ProgressBar prgBar;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmProgressBar));
      this.lblText = new System.Windows.Forms.Label();
      this.prgBar = new System.Windows.Forms.ProgressBar();
      this.SuspendLayout();
      // 
      // lblText
      // 
      this.lblText.Location = new System.Drawing.Point(16, 8);
      this.lblText.Name = "lblText";
      this.lblText.Size = new System.Drawing.Size(200, 23);
      this.lblText.TabIndex = 3;
      this.lblText.Text = "Click on form to move progressbar";
      // 
      // prgBar
      // 
      this.prgBar.Location = new System.Drawing.Point(24, 56);
      this.prgBar.Name = "prgBar";
      this.prgBar.Size = new System.Drawing.Size(240, 23);
      this.prgBar.TabIndex = 2;
      // 
      // frmProgressBar
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 101);
      this.Controls.Add(this.lblText);
      this.Controls.Add(this.prgBar);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmProgressBar";
      this.Text = "Progress bar: 0%";
      this.Click += new System.EventHandler(this.frmProgressBar_Click);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmProgressBar'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmProgressBar()
      //***
      // Action
      //   - Create instance of 'frmProgressBar'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmProgressBar()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmProgressBar_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If value of the progress bar is 100
      //     - Form is closed
      //   - If Not
      //     - Value of the progressbar is incremented by one
      //     - Adapt the text of progressbar
      // Called by
      //   - User action (Clicking the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (prgBar.Value == 100)
      {
        this.Close();
      }
      else
        // prgBar.Value <> 100
      {
        prgBar.Value += 1;
        this.Text = "Progress bar: " + prgBar.Value + "%";
      }
      // prgBar.Value = 100
    
    }
    // frmProgressBar_Click(System.Object, System.EventArgs) Handles MyBase.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmProgressBar
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmProgressBar());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmProgressBar

}
// CopyPaste.Learning