//***
// Action
//   - Implementation of a cpCopyMachine using an interface for the cost
// Created
//   - CopyPaste � 20240410 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240410 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning.Employee
{

  public class cpCopyMachine : cpiCost
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private decimal mdecPageCost;
    private int mlngNumberOfPages;

    #endregion

    #region "Properties"

    public decimal Amount
    {

      get
        //***
        // Action Get
        //   - Returns the number of pages multiplied by the cost for every page
        // Called by
        //   - modMainProgram.Main()
        // Calls
        //   - NumberOfPages() As Integer (Get)
        //   - PageCost() As Decimal (Get)
        // Created
        //   - CopyPaste � 20240410 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240410 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return NumberOfPages * PageCost;
      }
      // decimal Amount (Get)

    }
    // decimal Amount

    public bool Human
    {

      get
        //***
        // Action Get
        //   - Returns false
        //   - The cost of a copy machine is not human
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240410 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240410 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return false;
      }
      // bool Human (Get)

    }
    // bool Human

    public int NumberOfPages
    {

      get
        //***
        // Action Get
        //   - Returns mlngNumberOfPages
        // Called by
        //   - decimal Amount (Get)
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240410 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240410 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngNumberOfPages;
      }
      // int NumberOfPages (Get)

      set
        //***
        // Action Set
        //   - mlngNumberOfPages becomes value
        //   - When the value is negative, a value zero is stored
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240410 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240410 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value >= 0)
        {
          mlngNumberOfPages = value;
        }
        else
          // value < 0
        {
          mlngNumberOfPages = 0;
        }
        // value >= 0

      }
      // NumberOfPages(int) (Set)

    }
    // int NumberOfPages

    public decimal PageCost
    {

      get
        //***
        // Action Get
        //   - Returns mdecPageCost
        // Called by
        //   - decimal Amount (Get)
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240410 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240410 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecPageCost;
      }
      // decimal PageCost (Get)

      set
        //***
        // Action Set
        //   - mdecPageCost becomes value
        //   - When the value is negative, a value zero is stored
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240410 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240410 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value >= 0)
        {
          mdecPageCost = value;
        }
        else
          // value < 0
        {
          mdecPageCost = 0;
        }
        // value >= 0

      }
      // PageCost(decimal) (Set)

    }
    // decimal PageCost

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Returns the Number of pages and the page cost
      // Called by
      //   - modMainProgram.Main()
      // Calls
      //   - NumberOfPages() As Integer (Get)
      //   - PageCost() As Decimal (Get)
      // Created
      //   - CopyPaste � 20240410 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240410 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return NumberOfPages + " pages at " + PageCost + " per page.";
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx