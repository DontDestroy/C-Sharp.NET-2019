//***
// Action
//   - Use the static class Path
// Created
//   - CopyPaste � 20240723 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240723 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Show the path of several strings
      //   - Wait till user hits a key
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - ShowPath(string)
      // Created
      //   - CopyPaste � 20240723 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240723 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      ShowPath("C:\\Folder\\Subdir\\Filename.ext");
      ShowPath("C:Filename.ext");
      ShowPath("C:Filename");
      ShowPath("C:\\");
      ShowPath("\\");
      Console.ReadLine();
    }
		// Main()

    public static void ShowPath(string strPath)
      //***
      // Action
      //   - A strPath is given
      //   - Try to
      //     - Show it
      //     - Show the directory name
      //     - Show the extension
      //     - Show the filename
      //     - Show the filenam without extension
      //     - Show the full path
      //     - Show the path root
      //   - On error
      //     - Show an error message
      //     - Show the exception message
      //   - Show an empty line
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240723 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240723 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        Console.WriteLine("Starting path: {0}", strPath);
        Console.WriteLine("Directory name: {0}", Path.GetDirectoryName(strPath));
        Console.WriteLine("Extension: {0}", Path.GetExtension(strPath));
        Console.WriteLine("Filename: {0}", Path.GetFileName(strPath));
        Console.WriteLine("Filename without extension: {0}", Path.GetFileNameWithoutExtension(strPath));
        Console.WriteLine("Full path: {0}", Path.GetFullPath(strPath));
        Console.WriteLine("Root: {0}", Path.GetPathRoot(strPath));
      }
      catch (Exception theException)
      {
        Console.WriteLine("** Error processing **");
        Console.WriteLine("Error: {0}", theException.Message);
      }
      finally
      {
        Console.WriteLine();
      }

    }
    // ShowPath(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning