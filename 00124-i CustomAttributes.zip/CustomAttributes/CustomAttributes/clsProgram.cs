//***
// Action
//   - Testroutine for cpDemo and cpProgrammerName
// Created
//   - CopyPaste � 20240710 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240710 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Reflection;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define a method info
      //   - Create an instance of cpDemo (thecpMessage)
      //   - Loop thru all the methods of thecpMessage
      //     - Show the method info name
      //     - Show the attribute
      //     - Cast the attribute as a cpProgrammerName and show the value mstrName, if it is possible
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpDemo.New(String)
      // Created
      //   - CopyPaste � 20240710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpDemo thecpMessage = new cpDemo("Hello, World");

      foreach (MethodInfo theMethodInfo in thecpMessage.GetType().GetMethods())
      {
        
        foreach (Attribute theAttribute in theMethodInfo.GetCustomAttributes(false))
        {
          cpProgrammerName theAttributeOfCorrectType = theAttribute as cpProgrammerName;

          if (theAttributeOfCorrectType == null)
          {
          }
          else
            // theAttributeOfCorrectType <> null
          {
            Console.WriteLine("Method name: " + theMethodInfo.Name);
            Console.WriteLine("Type: " + theAttribute.ToString());
            Console.WriteLine("Programmer: " + ((cpProgrammerName)theAttribute).mstrName);
            Console.WriteLine();
          }
          // theAttributeOfCorrectType = null

        }
        // In theMethodInfo.GetCustomAttributes(False)

      }
      // In thecpMessage.GetType.GetMethods()

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning