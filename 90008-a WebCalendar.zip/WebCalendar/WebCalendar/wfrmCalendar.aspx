﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="wfrmCalendar.aspx.vb" Inherits="WebCalendar.CopyPaste.Learning.wfrmCalendar" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Web Calendar</title>
</head>
<body ms_positioning="GridLayout">
  <form id="wfrmCalendar" method="post" runat="server">
    <asp:TextBox ID="txtDate" Style="z-index: 101; position: absolute; top: 28px; left: 34px" runat="server"
      Width="365px"></asp:TextBox>
    <asp:Calendar ID="calDate" Style="z-index: 102; position: absolute; top: 61px; left: 33px" runat="server"
      Width="360px" BorderWidth="1px" NextPrevFormat="FullMonth" BackColor="White" ForeColor="Black"
      Height="190px" Font-Size="9pt" Font-Names="Verdana" BorderColor="White" TabIndex="1">
      <TodayDayStyle BackColor="#CCCCCC"></TodayDayStyle>
      <NextPrevStyle Font-Size="8pt" Font-Bold="True" ForeColor="#333333" VerticalAlign="Bottom"></NextPrevStyle>
      <DayHeaderStyle Font-Size="8pt" Font-Bold="True"></DayHeaderStyle>
      <SelectedDayStyle ForeColor="White" BackColor="#333399"></SelectedDayStyle>
      <TitleStyle Font-Size="12pt" Font-Bold="True" BorderWidth="4px" ForeColor="#333399" BorderColor="Black"
        BackColor="White"></TitleStyle>
      <OtherMonthDayStyle ForeColor="#999999"></OtherMonthDayStyle>
    </asp:Calendar>
    <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" style="Z-INDEX: 103; POSITION: absolute; TOP: 306px; LEFT: 46px"
        runat="server" ErrorMessage="Please enter a date!" ControlToValidate="txtDate"></asp:RequiredFieldValidator>
    <asp:Button ID="cmdSubmit" Style="z-index: 104; position: absolute; top: 270px; left: 165px"
      runat="server" Width="112px" Text="Submit" TabIndex="2"></asp:Button>
  </form>
</body>
</html>
