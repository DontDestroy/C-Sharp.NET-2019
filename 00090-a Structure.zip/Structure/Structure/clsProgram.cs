//***
// Action
//   - Demo of a structure
// Created
//   - CopyPaste � 20240216 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240216 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpDefault
  {

    #region "Constructors / Destructors"

    public void cpProgram()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    #region "Structures"

    public struct Classmate
    {
      public string strName;
      public byte bytAge;
    }
    // Classmate

    #endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static public void Main()
      //***
      // Action
      //   - Explanation of the code in this method
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240216 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Classmate[] arrClassMates = new Classmate[8];
      int intCounter;

      arrClassMates[0].strName = "Thomas";
      arrClassMates[0].bytAge = 32;
      arrClassMates[1].strName = "James";
      arrClassMates[1].bytAge = 20;
      arrClassMates[2].strName = "Percy";
      arrClassMates[2].bytAge = 24;
      arrClassMates[3].strName = "Gordon";
      arrClassMates[3].bytAge = 38;
      arrClassMates[4].strName = "Harold";
      arrClassMates[4].bytAge = 49;
      arrClassMates[5].strName = "Terence";
      arrClassMates[5].bytAge = 17;
      arrClassMates[6].strName = "Annie";
      arrClassMates[6].bytAge = 32;
      arrClassMates[7].strName = "Clarabell";
      arrClassMates[7].bytAge = 25;

      for (intCounter = 0; intCounter < arrClassMates.Length; intCounter++)
      {
        Console.WriteLine("{0} is {1} years old.", arrClassMates[intCounter].strName, arrClassMates[intCounter].bytAge);
      }
      // intCounter = arrClassMates.Length

      Console.WriteLine();
      Console.WriteLine("Hit enter ...");
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning