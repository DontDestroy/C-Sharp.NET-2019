//***
// Action
//   - Playing around with dates and time
// Created
//   - CopyPaste � 20240412 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240412 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Take the current date and time
      //   - Add 5 hours to it
      //   - Add 45 days to it
      //   - Check if it is a leap year
      //   - Show the date is long format
      //   - Show the date is short format
      //   - Show the time is long format
      //   - Show the time is short format
      //   - Show the time in UTC
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240412 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240412 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      DateTime theDateTime = DateTime.Now;
      DateTime theNewDateTime = theDateTime;

      theNewDateTime = theNewDateTime.AddHours(5);

      Console.WriteLine("Current date and time: " + theDateTime);
      Console.WriteLine("Five hours from now is: " + theNewDateTime);

      theNewDateTime = theDateTime;
      theNewDateTime = theNewDateTime.AddDays(45);

      Console.WriteLine("45 days from now is: " + theNewDateTime);

      if (DateTime.IsLeapYear(theDateTime.Year))
      {
        Console.WriteLine("This is a leap year");
      }
      else
        // Not DateTime.IsLeapYear(theDateTime.Year)
      {
        Console.WriteLine("This is not a leap year");
      }
      // DateTime.IsLeapYear(theDateTime.Year)

      Console.WriteLine("Long date: " + theDateTime.ToLongDateString());
      Console.WriteLine("Short date: " + theDateTime.ToShortDateString());
      Console.WriteLine("Long time: " + theDateTime.ToLongTimeString());
      Console.WriteLine("Short time: " + theDateTime.ToShortTimeString());
      Console.WriteLine("Universal time: " + theDateTime.ToUniversalTime());
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning