﻿//***
// Action
//   - Definition of a cpWorker
// Created
//   - CopyPaste – 20260617 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260617 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Timers;

namespace CopyPaste.Learning
{

  public class cpWorker
  {

    #region "Constructors / Destructors"

    public cpWorker()
    //***
    // Action
    //   - Basic constructor
    //   - Subscribe to a static timer
    // Called by
    //   -
    // Calls
    //   - OnTimerElapsed(System.Object, ElapsedEventArgs)
    // Created
    //   - CopyPaste – 20260617 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260617 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      aTimer.Elapsed += OnTimerElapsed;     
    }
    // cpWorker()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static Timer aTimer = new Timer();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private void OnTimerElapsed(System.Object theSender, ElapsedEventArgs theElapsedEventArguments)
    //***
    // Action
    //   - Routine that is executed when a timer interval is passed
    // Called by
    //   - cpWorker()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260617 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260617 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // OnTimerElapsed(System.Object, ElapsedEventArgs)

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpWorker

}
// CopyPaste.Learning