﻿//***
// Action
//   - Design of the Startup screen of the morse code
// Created
//   - CopyPaste – 20241227 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20241227 – VVDW
// Proposal (To Do)
//   - 
//***

namespace CopyPaste.MorseCode
{
	partial class frmMorseCode
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMorseCode));
			lblTextToSend = new Label();
			txtTextToSend = new TextBox();
			chkSound = new CheckBox();
			chkLight = new CheckBox();
			chkOutput = new CheckBox();
			cmdSend = new Button();
			picLightBulb = new PictureBox();
			txtMorseCode = new TextBox();
			lblMorseCode = new Label();
			((System.ComponentModel.ISupportInitialize)picLightBulb).BeginInit();
			SuspendLayout();
			// 
			// lblTextToSend
			// 
			lblTextToSend.AutoSize = true;
			lblTextToSend.Location = new Point(12, 30);
			lblTextToSend.Name = "lblTextToSend";
			lblTextToSend.Size = new Size(161, 37);
			lblTextToSend.TabIndex = 0;
			lblTextToSend.Text = "Text to Send";
			// 
			// txtTextToSend
			// 
			txtTextToSend.Location = new Point(204, 30);
			txtTextToSend.Name = "txtTextToSend";
			txtTextToSend.Size = new Size(610, 43);
			txtTextToSend.TabIndex = 1;
			txtTextToSend.Text = "SMS";
			// 
			// chkSound
			// 
			chkSound.AutoSize = true;
			chkSound.Location = new Point(204, 106);
			chkSound.Name = "chkSound";
			chkSound.Size = new Size(125, 41);
			chkSound.TabIndex = 2;
			chkSound.Text = "Sound";
			chkSound.UseVisualStyleBackColor = true;
			// 
			// chkLight
			// 
			chkLight.AutoSize = true;
			chkLight.Location = new Point(204, 153);
			chkLight.Name = "chkLight";
			chkLight.Size = new Size(109, 41);
			chkLight.TabIndex = 3;
			chkLight.Text = "Light";
			chkLight.UseVisualStyleBackColor = true;
			// 
			// chkOutput
			// 
			chkOutput.AutoSize = true;
			chkOutput.Location = new Point(204, 200);
			chkOutput.Name = "chkOutput";
			chkOutput.Size = new Size(133, 41);
			chkOutput.TabIndex = 4;
			chkOutput.Text = "Output";
			chkOutput.UseVisualStyleBackColor = true;
			// 
			// cmdSend
			// 
			cmdSend.Location = new Point(35, 1021);
			cmdSend.Name = "cmdSend";
			cmdSend.Size = new Size(313, 52);
			cmdSend.TabIndex = 5;
			cmdSend.Text = "Send Message";
			cmdSend.UseVisualStyleBackColor = true;
			cmdSend.Click += cmdSend_Click;
			// 
			// picLightBulb
			// 
			picLightBulb.Image = (Image)resources.GetObject("picLightBulb.Image");
			picLightBulb.Location = new Point(847, 24);
			picLightBulb.Name = "picLightBulb";
			picLightBulb.Size = new Size(838, 846);
			picLightBulb.SizeMode = PictureBoxSizeMode.StretchImage;
			picLightBulb.TabIndex = 6;
			picLightBulb.TabStop = false;
			picLightBulb.Visible = false;
			// 
			// txtMorseCode
			// 
			txtMorseCode.Enabled = false;
			txtMorseCode.Location = new Point(204, 273);
			txtMorseCode.Multiline = true;
			txtMorseCode.Name = "txtMorseCode";
			txtMorseCode.Size = new Size(610, 597);
			txtMorseCode.TabIndex = 8;
			txtMorseCode.TabStop = false;
			// 
			// lblMorseCode
			// 
			lblMorseCode.AutoSize = true;
			lblMorseCode.Location = new Point(12, 273);
			lblMorseCode.Name = "lblMorseCode";
			lblMorseCode.Size = new Size(179, 37);
			lblMorseCode.TabIndex = 7;
			lblMorseCode.Text = "Sent message";
			// 
			// frmMorseCode
			// 
			AutoScaleDimensions = new SizeF(15F, 37F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(1714, 1110);
			Controls.Add(txtMorseCode);
			Controls.Add(lblMorseCode);
			Controls.Add(picLightBulb);
			Controls.Add(cmdSend);
			Controls.Add(chkOutput);
			Controls.Add(chkLight);
			Controls.Add(chkSound);
			Controls.Add(txtTextToSend);
			Controls.Add(lblTextToSend);
			Icon = (Icon)resources.GetObject("$this.Icon");
			Margin = new Padding(6, 7, 6, 7);
			Name = "frmMorseCode";
			Text = "Copy Paste Morse Code";
			Load += frmMorseCode_Load;
			((System.ComponentModel.ISupportInitialize)picLightBulb).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private Label lblTextToSend;
		private TextBox txtTextToSend;
		private CheckBox chkSound;
		private CheckBox chkLight;
		private CheckBox chkOutput;
		private Button cmdSend;
		private PictureBox picLightBulb;
		private TextBox txtMorseCode;
		private Label lblMorseCode;
	}
	// frmMorseCode

}
// CopyPaste.MorseCode