﻿//***
// Action
//   - Having a chat with a fake Psychiatrist
// Created
//   - CopyPaste – 20220906 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220906 – VVDW
// Proposal (To Do)
//   -
//***

using Eliza;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Eliza_WPF
{

  public partial class wpfPsychiatrist : Window
  {

    #region "Constructors / Destructors"

    public wpfPsychiatrist()
    //***
    // Action
    //   - Create instance of 'wpfPsychiatrist'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220906 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220906 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      lblDoctor.Content = "What would you like to talk about this beautiful day?";
    }
    // wpfPsychiatrist()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    cpDialog aDialog = new cpDialog();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void txtQuestion_KeyDown(System.Object theSender, System.Windows.Input.KeyEventArgs theKeyEventArguments)
    //***
    // Action
    //   - When you hit enter in the Question textbox
    //     - Find a response by Eliza 
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - bool theKeyEventArguments.KeyCode.Equals(int)
    //   - Keys Enumeration
    //   - string Eliza.cpDialog.GetElizaResponse(string)
    // Created
    //   - CopyPaste – 20220906 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220906 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      if (theKeyEventArguments.Key.Equals(Key.Enter))
      {
        lblDoctor.Content = aDialog.GetElizaResponse(txtQuestion.Text);
        txtQuestion.Text = "";
      }
      else
      // Not theKeyEventArguments.Key.Equals(Key.Enter)
      {
      }
      // theKeyEventArguments.Key.Equals(Key.Enter)

    }
    // txtQuestion_KeyDown(System.Object, System.Windows.Input.KeyEventArgs) Handles txtQuestion.KeyDown

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfPsychiatrist

}
// Eliza_WPF