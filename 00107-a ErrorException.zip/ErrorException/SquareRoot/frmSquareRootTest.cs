//***
// Action
//   - Testroutine for cpNegativeNumberException
// Created
//   - CopyPaste � 20230820 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230820 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSquareRootTest : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    internal System.Windows.Forms.TextBox txtInput;
    internal System.Windows.Forms.Button cmdSquareRoot;
    internal System.Windows.Forms.Label lblOutput;
    internal System.Windows.Forms.Label lblInput;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSquareRootTest));
      this.txtInput = new System.Windows.Forms.TextBox();
      this.cmdSquareRoot = new System.Windows.Forms.Button();
      this.lblOutput = new System.Windows.Forms.Label();
      this.lblInput = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // txtInput
      // 
      this.txtInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.txtInput.Location = new System.Drawing.Point(171, 7);
      this.txtInput.Name = "txtInput";
      this.txtInput.TabIndex = 5;
      this.txtInput.Text = "";
      // 
      // cmdSquareRoot
      // 
      this.cmdSquareRoot.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmdSquareRoot.Location = new System.Drawing.Point(93, 39);
      this.cmdSquareRoot.Name = "cmdSquareRoot";
      this.cmdSquareRoot.Size = new System.Drawing.Size(112, 24);
      this.cmdSquareRoot.TabIndex = 6;
      this.cmdSquareRoot.Text = "Square Root";
      this.cmdSquareRoot.Click += new System.EventHandler(this.cmdSquareRoot_Click);
      // 
      // lblOutput
      // 
      this.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblOutput.Location = new System.Drawing.Point(17, 71);
      this.lblOutput.Name = "lblOutput";
      this.lblOutput.Size = new System.Drawing.Size(264, 23);
      this.lblOutput.TabIndex = 7;
      // 
      // lblInput
      // 
      this.lblInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblInput.Location = new System.Drawing.Point(11, 7);
      this.lblInput.Name = "lblInput";
      this.lblInput.Size = new System.Drawing.Size(144, 23);
      this.lblInput.TabIndex = 4;
      this.lblInput.Text = "Please enter a number";
      // 
      // frmSquareRootTest
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 100);
      this.Controls.Add(this.txtInput);
      this.Controls.Add(this.cmdSquareRoot);
      this.Controls.Add(this.lblOutput);
      this.Controls.Add(this.lblInput);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSquareRootTest";
      this.RightToLeft = System.Windows.Forms.RightToLeft.No;
      this.Text = "Computing the Square Root";
      this.Load += new System.EventHandler(this.frmSquareRootTest_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSquareRootTest'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230820 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230820 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSquareRootTest()
      //***
      // Action
      //   - Create instance of 'frmSquareRootTest'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230820 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230820 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSquareRootTest()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdSquareRoot_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to convert the typed text into a double
      //     - On error show the FormatException
      //   - Try to calculate the squareroot
      //     - On error show the cpNegativeNumberException
      //   - Show the result on the screen
      //   - On any unforseen error, show the errormessage
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - double SquareRoot(double)
      // Created
      //   - CopyPaste � 20230820 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230820 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblOutput.Text = "";
      
      try
      {
        double dblResult = SquareRoot(Convert.ToDouble(txtInput.Text));
        
        lblOutput.Text = dblResult.ToString();
      }
      catch (FormatException theFormatException)
      {
        MessageBox.Show(theFormatException.Message, "Invalid Number Format", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
      catch (cpNegativeNumberException thecpNegativeNumberException)
      {
        MessageBox.Show(thecpNegativeNumberException.Message, "Invalid Operation", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message, "Not forseen error", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }

    }
    // cmdSquareRoot_Click(System.Object, System.EventArgs) Handles cmdSquareRoot.Click

    private void frmSquareRootTest_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - 
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230820 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230820 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmSquareRootTest_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSquareRootTest
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230820 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230820 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSquareRootTest());
    }
    // Main() 
    
    public double SquareRoot(double dblOperand)
      //***
      // Action
      //   - Calculate the squareroot of a double
      //   - Will throw an error when double is negative
      // Called by
      //   - cmdSquareRoot_Click(System.Object, System.EventArgs) Handles cmdSquareRoot.Click
      // Calls
      //   - cpNegativeNumberException(string)
      // Created
      //   - CopyPaste � 20230820 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230820 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      
      if (dblOperand < 0)
      {
        throw new cpNegativeNumberException("Square root of negative number not permitted");
      }
      else
        // dblOperand >= 0
      {
      }
      // dblOperand < 0

      return Math.Sqrt(dblOperand);
    }
    // double SquareRoot(double)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmSquareRootTest

}
// CopyPaste.Learning