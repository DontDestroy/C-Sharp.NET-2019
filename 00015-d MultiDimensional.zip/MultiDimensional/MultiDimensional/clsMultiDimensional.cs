//***
// Action
//   - A multidimensional array
// Created
//   - CopyPaste � 20220210 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220210 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace MultiDimensional
{

  class cpMultiDimensional
	{

    static void Main()
    //***
    // Action
    //   - Define a 2 dimensional array
    //   - Define a jagged array (an array of arrays)
    //   - Loop thru both arrays and create a messagebox with the content of the arrays
    //     - Look at the difference between the 2 types of arrays
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - int Array.GetUpperBound(int)
    //   - DialogResult Microsoft.VisualBasic.MessageBox.Show(String, String, Integer, Integer)
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int[,] arrNumber = new int[,] {{1, 2, 3}, {4, 5, 6}};
      int[][] arrJagged = new int[3][];
      long lngColumn;
      long lngRow;
      string strOutput;

      arrJagged[0] = new int[] {1, 2};
      arrJagged[1] = new int[] {3};
      arrJagged[2] = new int[] {4, 5, 6};

      strOutput = "Values in array by row are\n";

      for (lngRow = 0; lngRow <= arrNumber.GetUpperBound(0); lngRow++)
      {
      
        for (lngColumn = 0; lngColumn <= arrNumber.GetUpperBound(1); lngColumn++)
        {
          strOutput += arrNumber[lngRow, lngColumn] + " ";
        }
        // lngColumn = arrNumber.GetUpperBound(1) + 1
        
        strOutput += "\n";
      }
      // lngRow = arrNumber.GetUpperBound(0) + 1
      
      strOutput += "\nValues in array by row are\n";

      for (lngRow = 0; lngRow <= arrJagged.GetUpperBound(0); lngRow++)
      {

        for (lngColumn = 0; lngColumn <= arrJagged[lngRow].GetUpperBound(0); lngColumn++)
        {
          strOutput += arrJagged[lngRow][lngColumn] + " ";
        }
        // lngColumn = arrJagged[lngRow].GetUpperBound(0) + 1

        strOutput += "\n";
      }
      // lngRow = arrJagged.GetUpperBound(0) + 1
      
      MessageBox.Show(strOutput, "Initializing Multi-Dimensional Arrays", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // Main()

  }
  // cpMultiDimensional

}
// MultiDimensional