﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmViewBookInfo.aspx.cs" Inherits="CopyPaste.Learning.wfrmViewBookInfo" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>View Book Info</title>
</head>
<body>
  <form id="wfrmViewBookInfo" method="post" runat="server">
    <asp:Label ID="lblTitle" Style="z-index: 101; position: absolute; top: 50px; left: 32px" runat="server"
      Font-Size="XX-Large">View Book Information</asp:Label>
    <asp:Button ID="cmdCSharp" Style="z-index: 102; position: absolute; top: 144px; left: 62px"
      runat="server" Text="C# Programming"></asp:Button>
    <asp:TextBox ID="txtResult" Style="z-index: 103; position: absolute; top: 238px; left: 61px"
      runat="server" Height="134px" Width="445px" TextMode="MultiLine" TabIndex="4"></asp:TextBox>
    <asp:Button ID="cmdVisualBasic" Style="z-index: 104; position: absolute; top: 145px; left: 225px"
      runat="server" Text="Visual Basic .Net" TabIndex="1"></asp:Button>
    <asp:Button ID="cmdHTML" Style="z-index: 105; position: absolute; top: 190px; left: 306px" runat="server"
      Text="HTML &amp; Web Design" TabIndex="3"></asp:Button>
    <asp:Button ID="cmdUpgrade" Style="z-index: 106; position: absolute; top: 189px; left: 66px"
      runat="server" Text="Upgrading &amp; Performance" TabIndex="2"></asp:Button>
  </form>
</body>
</html>
