﻿//***
// Action
//   - Explanation of the code in this module or class
// Created
//   - CopyPaste – 20251223 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251223 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Linq;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Explanation of the code in this method
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – yyyymmdd – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – yyyymmdd – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Restaurant aRestaurant = new Restaurant();
      RestaurantFood aFood = new RestaurantFood();

      aFood.Name = "Test food";
      aFood.Price = 10;
      aFood.Description = "Test description";
      aFood.Calories = 150;

      aRestaurant.Food = new RestaurantFood[1];
      aRestaurant.Food[0] = aFood;

      Console.WriteLine(aRestaurant.Food[0].Description);
      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning