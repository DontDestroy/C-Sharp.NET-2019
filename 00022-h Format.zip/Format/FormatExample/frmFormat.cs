//***
// Action
//   - Example of formatting date and time
// Created
//   - CopyPaste � 20240423 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240423 � VVDW
// Proposal (To Do)
//   - 
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFormat: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.TextBox txtFormat;
    internal System.Windows.Forms.ListBox lstFormat;
    internal System.Windows.Forms.GroupBox grpVariable;
    internal System.Windows.Forms.RadioButton optNumeric;
    internal System.Windows.Forms.RadioButton optTime;
    internal System.Windows.Forms.RadioButton optDate;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFormat));
      this.lblResult = new System.Windows.Forms.Label();
      this.txtFormat = new System.Windows.Forms.TextBox();
      this.lstFormat = new System.Windows.Forms.ListBox();
      this.grpVariable = new System.Windows.Forms.GroupBox();
      this.optNumeric = new System.Windows.Forms.RadioButton();
      this.optTime = new System.Windows.Forms.RadioButton();
      this.optDate = new System.Windows.Forms.RadioButton();
      this.grpVariable.SuspendLayout();
      this.SuspendLayout();
      // 
      // lblResult
      // 
      this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblResult.Location = new System.Drawing.Point(288, 24);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(352, 48);
      this.lblResult.TabIndex = 7;
      this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // txtFormat
      // 
      this.txtFormat.Location = new System.Drawing.Point(152, 24);
      this.txtFormat.Name = "txtFormat";
      this.txtFormat.Size = new System.Drawing.Size(120, 20);
      this.txtFormat.TabIndex = 5;
      this.txtFormat.Text = "";
      this.txtFormat.TextChanged += new System.EventHandler(this.txtFormat_TextChanged);
      // 
      // lstFormat
      // 
      this.lstFormat.Location = new System.Drawing.Point(152, 56);
      this.lstFormat.Name = "lstFormat";
      this.lstFormat.Size = new System.Drawing.Size(120, 199);
      this.lstFormat.TabIndex = 6;
      this.lstFormat.SelectedIndexChanged += new System.EventHandler(this.lstFormat_SelectedIndexChanged);
      // 
      // grpVariable
      // 
      this.grpVariable.Controls.Add(this.optNumeric);
      this.grpVariable.Controls.Add(this.optTime);
      this.grpVariable.Controls.Add(this.optDate);
      this.grpVariable.Location = new System.Drawing.Point(16, 16);
      this.grpVariable.Name = "grpVariable";
      this.grpVariable.Size = new System.Drawing.Size(112, 240);
      this.grpVariable.TabIndex = 4;
      this.grpVariable.TabStop = false;
      this.grpVariable.Tag = "";
      this.grpVariable.Text = "Variable";
      // 
      // optNumeric
      // 
      this.optNumeric.Location = new System.Drawing.Point(24, 96);
      this.optNumeric.Name = "optNumeric";
      this.optNumeric.Size = new System.Drawing.Size(72, 24);
      this.optNumeric.TabIndex = 2;
      this.optNumeric.Tag = "Numeric";
      this.optNumeric.Text = "Numeric";
      this.optNumeric.CheckedChanged += new System.EventHandler(this.optNumeric_CheckedChanged);
      // 
      // optTime
      // 
      this.optTime.Location = new System.Drawing.Point(24, 64);
      this.optTime.Name = "optTime";
      this.optTime.Size = new System.Drawing.Size(72, 24);
      this.optTime.TabIndex = 1;
      this.optTime.Tag = "Time";
      this.optTime.Text = "Time";
      this.optTime.CheckedChanged += new System.EventHandler(this.optTime_CheckedChanged);
      // 
      // optDate
      // 
      this.optDate.Checked = true;
      this.optDate.Location = new System.Drawing.Point(24, 32);
      this.optDate.Name = "optDate";
      this.optDate.Size = new System.Drawing.Size(72, 24);
      this.optDate.TabIndex = 0;
      this.optDate.TabStop = true;
      this.optDate.Tag = "Date";
      this.optDate.Text = "Date";
      this.optDate.CheckedChanged += new System.EventHandler(this.optDate_CheckedChanged);
      // 
      // frmFormat
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(648, 273);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.txtFormat);
      this.Controls.Add(this.lstFormat);
      this.Controls.Add(this.grpVariable);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFormat";
      this.Text = "Copy Paste Format";
      this.Load += new System.EventHandler(this.frmFormat_Load);
      this.grpVariable.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFormat'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFormat()
      //***
      // Action
      //   - Create instance of 'frmFormat'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFormat()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmFormat_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Tag is set to the tag of optDate
      //   - Listbox is filled
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - FillListBox()
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      grpVariable.Tag = optDate.Tag;
      FillListBox();
    }
    // frmFormat_Load(System.Object, System.EventArgs) Handles this.Load
    
    private void lstFormat_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Text is correctly filled in
      // Called by
      //   - User action (Selecting another index)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtFormat.Text = lstFormat.SelectedItem.ToString();
    }
    // lstFormat_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstFormat.SelectedIndexChanged

    private void optDate_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Tag is set to the tag of optDate
      //   - Listbox is filled
      // Called by
      //   - User action (Selection an option)
      // Calls
      //   - FillListBox()
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      grpVariable.Tag = optDate.Tag;
      FillListBox();
    }
    // optDate_CheckedChanged(System.Object, System.EventArgs) Handles optDate.CheckedChanged

    private void optNumeric_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Tag is set to the tag of optNumeric
      //   - Listbox is filled
      // Called by
      //   - User action (Selection an option)
      // Calls
      //   - FillListBox()
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      grpVariable.Tag = optNumeric.Tag;
      FillListBox();
    }
    // optNumeric_CheckedChanged(System.Object, System.EventArgs) Handles optDate.CheckedChanged

    private void optTime_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Tag is set to the tag of optTime
      //   - Listbox is filled
      // Called by
      //   - User action (Selection an option)
      // Calls
      //   - FillListBox()
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      grpVariable.Tag = optTime.Tag;
      FillListBox();
    }
    // optTime_CheckedChanged(System.Object, System.EventArgs) Handles optDate.CheckedChanged

    private void txtFormat_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Depending on the tag
      //     - "Date"
      //       - Current date is set in selected format
      //     - "Numeric"
      //       - Number 123456.789 is set in selected format
      //     - "Time"
      //       - Current time is set in selected format
      //   - On an error
      //     - Result becomes "Not accepted"
      // Called by
      //   - User action (Text is changed)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        string strTag;
        
        strTag = grpVariable.Tag.ToString();

        switch (strTag)
        {
          case "Date":
            lblResult.Text = Strings.Format(DateTime.Today, txtFormat.Text);
            break;
          case "Time":
            lblResult.Text = Strings.Format(DateTime.Now, txtFormat.Text);
            break;
          case "Numeric":
            lblResult.Text = Strings.Format(123456.789, txtFormat.Text);
            break;
          default:
            break;
        }
        // strTag

      }
      catch
      {
        lblResult.Text = "Not Accepted";
      }
    
    }
    // txtFormat_TextChanged(System.Object, System.EventArgs) Handles txtFormat.TextChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void FillListBox()
      //***
      // Action
      //   - Fill thte listbox with the options depending on the option button that is selected
      //   - The selected option button is setting a tag to the group
      //   - Depending on the tag
      //     - "Date"
      //       - Clear all options
      //       - Add 4 options for the date
      //     - "Numeric"
      //       - Clear all options
      //       - Add 9 options for the date
      //     - "Time"
      //       - Clear all options
      //       - Add 3 options for the date
      //   - Select first option
      // Called by
      //   - frmFormat_Load(System.Object, System.EventArgs) Handles this.Load
      //   - optDate_CheckedChanged(System.Object, System.EventArgs) Handles optDate.CheckedChanged
      //   - optNumeric_CheckedChanged(System.Object, System.EventArgs) Handles optNumeric.CheckedChanged
      //   - optTime_CheckedChanged(System.Object, System.EventArgs) Handles optTime.CheckedChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strTag;

      if (grpVariable.Tag == null)
      {
      }
      else
        // grpVariable.Tag <> null
      {
        strTag = grpVariable.Tag.ToString();

        switch (strTag)
        {
          case null:
          case "Date":
            lstFormat.Items.Clear();
            lstFormat.Items.Add("General Date");
            lstFormat.Items.Add("Long Date");
            lstFormat.Items.Add("Medium Date");
            lstFormat.Items.Add("Short Date");
            lstFormat.SelectedIndex = 0;
            break;
          case "Numeric":
            lstFormat.Items.Clear();
            lstFormat.Items.Add("General Number");
            lstFormat.Items.Add("Currency");
            lstFormat.Items.Add("Fixed");
            lstFormat.Items.Add("Standard");
            lstFormat.Items.Add("Percent");
            lstFormat.Items.Add("Scientific");
            lstFormat.Items.Add("Yes/No");
            lstFormat.Items.Add("True/False");
            lstFormat.Items.Add("On/Off");
            lstFormat.SelectedIndex = 0;
            break;
          case "Time":
            lstFormat.Items.Clear();
            lstFormat.Items.Add("Long Time");
            lstFormat.Items.Add("Medium Time");
            lstFormat.Items.Add("Short Time");
            lstFormat.SelectedIndex = 0;
            break;
        }
        // grpVariable.Tag

      }
      // grpVariable.Tag = null

    }
    // FillListBox()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFormat
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmFormat()
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFormat());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmFormat

}
// CopyPaste.Learning