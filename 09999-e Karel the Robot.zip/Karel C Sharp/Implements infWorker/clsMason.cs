﻿//***
// Action
//   - Implementation of a Mason
// Created
//   - CopyPaste – 20251104 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251104 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpMason : cpCopyPasteRobot, cpinfWorker
	{

    #region "Constructors / Destructors"

    public cpMason(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpMason starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpMason(int, int, Directions.Direction, int)
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpMason(int, int, Directions.Direction, int, Color) 

    public cpMason(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpMason starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpMason(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpMason(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void BuildWall()
    //***
    // Action
    //   - Face to the North
    //   - Repeat 5 times
    //     - Put beeper
    //     - Move one forward
    // Called by
    //   - GetToWork()
    // Calls
    //   - cpCopyPasteRobot.FaceNorth()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FaceNorth();

      for (int counter = 0; counter < 5; counter++)
      {
        putBeeper();
        move();
      }
      // counter = 5

    }
    // BuildWall()

    public void GetToWork()
    //***
    // Action
    //   - Implementation of GetToWork
    //   - Go to the position for the first wall
    //   - Build the wall
    //   - Go back to the origin
    //   - Go to the position for the second wall
    //   - Build the wall
    //   - Go back to the origin
    // Called by
    //   - cpContractor.BuildHouse()
    // Calls
    //   - BuildWall()
    //   - cpCopyPasteRobot.GoToStartPosition()
    //   - GoToStartFirstWall()
    //   - GoToStartSecondWall()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      GoToStartFirstWall();
      BuildWall();
      GoToStartPosition();
      GoToStartSecondWall();
      BuildWall();
      GoToStartPosition();
    }
    // GetToWork()

    private void GoToStartFirstWall()
    //***
    // Action
    //   - Move one forward
    // Called by
    //   - GetToWork()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      move();
    }
    // GoToStartFirstWall()

    private void GoToStartSecondWall()
    //***
    // Action
    //   - Move one forward
    // Called by
    //   - GetToWork()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      for (int counter = 0; counter < 9; counter++)
      {
        move();
      }
      // counter = 9

    }
    // GoToStartSecondWall()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpMason

}
// cpKarelTheRobot