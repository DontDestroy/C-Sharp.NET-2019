﻿//***
// Action
//   - Explain the basic principles of Performance
//     - Algoritmic efficiency 
//       - AllNumbersFromXTillY
//       - AllEvenNumbersFromXTillY
//     - Memory behaviour
//     - Runtime execution
//       - StartupCost
//   - Measured by throughput, latency and resource utilization
// Created
//   - CopyPaste – 20260524 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260524 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260524 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260524 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void AllEvenNumbersFromXTillY()
    //***
    // Action
    //   - Create a Linq List Range from 1 to 100 million
    //   - Make sure it is an array
    //   - First loop
    //     - Define and initialize a total
    //     - Prepare the calculation of milliseconds
    //     - Loop thru the array
    //       - Add to the total the value of the current item when it is divisable by 2
    //     - Prepare the calculation of milliseconds
    //     - Show the total on the console
    //     - Show the total needed time in milliseconds
    //   - Second loop
    //     - Define and initialize a total
    //     - Prepare the calculation of milliseconds
    //     - Loop thru the array
    //       - Add to the total the value of the current item when it is divisable by 2 (used modulo)
    //     - Prepare the calculation of milliseconds
    //     - Show the total on the console
    //     - Show the total needed time in milliseconds
    //   - Third loop
    //     - Define and initialize a total
    //     - Prepare the calculation of milliseconds
    //     - Loop thru the array
    //       - Add to the total the value of the current item when it is divisable by 2 (bitwize operator)
    //     - Prepare the calculation of milliseconds
    //     - Show the total on the console
    //     - Show the total needed time in milliseconds
    //   - Fourth loop
    //     - Define and initialize a total
    //     - Prepare the calculation of milliseconds
    //     - Use another technique than looping
    //       - Calculate the total using Linq (filtering with modulo)
    //     - Prepare the calculation of milliseconds
    //     - Show the total on the console
    //     - Show the total needed time in milliseconds
    //   - Fifth loop
    //     - Define and initialize a total
    //     - Prepare the calculation of milliseconds
    //     - Use another technique than looping
    //       - Calculate the total using Linq (filtering with bitwize operator)
    //     - Prepare the calculation of milliseconds
    //     - Show the total on the console
    //     - Show the total needed time in milliseconds
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260524 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260524 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      const int intMinimum = 1;
      const int intMaximum = 100_000_000;

      DateTime dtmStart;
      DateTime dtmEnd;

      double dblMilliseconds = 0;

      // int[] arrNumber = Enumerable.Range(intMinimum, intMaximum).ToArray();
      // VVDW - This is not used because it causes an overflow on some calculations

      long[] arrNumber = new long[intMaximum];
      int intLength = arrNumber.Length;

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {
        arrNumber[intCounter] = intCounter + 1;
      }
      // intCounter = intLength + 1

      long lngTotalFirstRun = 0;
      long lngTotalSecondRun = 0;
      long lngTotalThirdRun = 0;
      long lngTotalFourthRun = 0;
      long lngTotalFifthRun = 0;

      Console.WriteLine($"All even numbers between {intMinimum:#,##0} and {intMaximum:#,##0}");
      Console.WriteLine();

      TimeSpan tsExecutionTime;

      // The first loop

      dtmStart = DateTime.Now;

      for (int intCounter = 0; intCounter < arrNumber.Length; intCounter++)
      {

        if (arrNumber[intCounter] % 2 == 0)
        {
          lngTotalFirstRun += arrNumber[intCounter];
        }
        else
        // arrNumber[intCounter] % 2 <> 0
        {
        }
        // arrNumber[intCounter] % 2 = 0

      }
      // intCounter = intLength

      dtmEnd = DateTime.Now;
      tsExecutionTime = dtmEnd - dtmStart;
      dblMilliseconds = tsExecutionTime.TotalMilliseconds;

      Console.WriteLine("Result of first run (Normal loop)");
      Console.WriteLine("The total of the even numbers is {0:#,##0}", lngTotalFirstRun);
      Console.WriteLine("The execution time in milliseconds is {0}", dblMilliseconds);
      Console.WriteLine("");

      // The second loop (Loop a bit faster, using a variable)

      dtmStart = DateTime.Now;

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {

        if (arrNumber[intCounter] % 2 == 0)
        {
          lngTotalSecondRun += arrNumber[intCounter];
        }
        else
        // arrNumber[intCounter] % 2 <> 0
        {
        }
        // arrNumber[intCounter] % 2 = 0

      }
      // intCounter = intLength

      dtmEnd = DateTime.Now;
      tsExecutionTime = dtmEnd - dtmStart;
      dblMilliseconds = tsExecutionTime.TotalMilliseconds;

      Console.WriteLine("Result of second run (Loop a bit faster, using a variable)");
      Console.WriteLine("The total of the even numbers is {0:#,##0}", lngTotalSecondRun);
      Console.WriteLine("The execution time in milliseconds is {0}", dblMilliseconds);
      Console.WriteLine("");

      // The third loop (Bitwise operator)

      dtmStart = DateTime.Now;

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {

        if ((arrNumber[intCounter] & 1) == 0)
        {
          lngTotalThirdRun += arrNumber[intCounter];
        }
        else
        // (intCounter & 1) <> 0
        {
        }
        // (intCounter & 1) = 0

      }
      // intCounter = intLength

      dtmEnd = DateTime.Now;
      tsExecutionTime = dtmEnd - dtmStart;
      dblMilliseconds = tsExecutionTime.TotalMilliseconds;

      Console.WriteLine("Result of third run (Bitwise operator)");
      Console.WriteLine("The total of the even numbers is {0:#,##0}", lngTotalThirdRun);
      Console.WriteLine("The execution time in milliseconds is {0}", dblMilliseconds);
      Console.WriteLine("");

      // The fourth loop (Linq with modulo)

      dtmStart = DateTime.Now;

      try
      {
        lngTotalFourthRun = arrNumber.Where(intNumber => intNumber % 2 == 0).Sum();
      }
      catch
      {
        Console.WriteLine("There was an overflow");
      }

      dtmEnd = DateTime.Now;
      tsExecutionTime = dtmEnd - dtmStart;
      dblMilliseconds = tsExecutionTime.TotalMilliseconds;

      Console.WriteLine("Result of fourth run (Linq with modulo)");
      Console.WriteLine("The total of the even numbers is {0:#,##0}", lngTotalFourthRun);
      Console.WriteLine("The execution time in milliseconds is {0}", dblMilliseconds);
      Console.WriteLine();

      // The fifth loop (Linq with bitwize operator)

      dtmStart = DateTime.Now;

      try
      {
        lngTotalFifthRun = arrNumber.Where(intNumber => (intNumber & 1) == 0).Sum();
      }
      catch
      {
        Console.WriteLine("There was an overflow");
      }

      dtmEnd = DateTime.Now;
      tsExecutionTime = dtmEnd - dtmStart;
      dblMilliseconds = tsExecutionTime.TotalMilliseconds;

      Console.WriteLine("Result of fifth run (Linq with bitwize operator)");
      Console.WriteLine("The total of the even numbers is {0:#,##0}", lngTotalFifthRun);
      Console.WriteLine("The execution time in milliseconds is {0}", dblMilliseconds);
      Console.WriteLine();
    }
    // AllEvenNumbersFromXTillY()

    public static void AllNumbersFromXTillY()
    //***
    // Action
    //   - Create a Linq List Range from 1 to 100 million
    //   - Make sure it is an array
    //   - First loop
    //     - Define and initialize a total
    //     - Prepare the calculation of milliseconds
    //     - Loop thru the array
    //       - Add to the total the value of the current item
    //     - Prepare the calculation of milliseconds
    //     - Show the total on the console
    //     - Show the total needed time in milliseconds
    //   - Second loop
    //     - Define and initialize a total
    //     - Prepare the calculation of milliseconds
    //     - Loop thru the array
    //       - Add to the total the value of the current item
    //     - Prepare the calculation of milliseconds
    //     - Show the total on the console
    //     - Show the total needed time in milliseconds
    //   - Third loop
    //     - Define and initialize a total
    //     - Prepare the calculation of milliseconds
    //     - Use another technique than looping
    //       - Calculate the total
    //     - Prepare the calculation of milliseconds
    //     - Show the total on the console
    //     - Show the total needed time in milliseconds
    //   - Fourth loop
    //     - Define and initialize a total
    //     - Prepare the calculation of milliseconds
    //     - Use another technique than looping
    //       - Calculate the total using Linq
    //     - Prepare the calculation of milliseconds
    //     - Show the total on the console
    //     - Show the total needed time in milliseconds
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260524 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260524 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      const int intMinimum = 1;
      const int intMaximum = 100_000_000;

      DateTime dtmStart;
      DateTime dtmEnd;

      double dblMilliseconds = 0;

      // int[] arrNumber = Enumerable.Range(intMinimum, intMaximum).ToArray();
      // VVDW - This is not used because it causes an overflow on some calculations

      long[] arrNumber = new long[intMaximum];
      int intLength = arrNumber.Length;

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {
        arrNumber[intCounter] = intCounter + 1;
      }
      // intCounter = intLength + 1

      long lngTotalFirstRun = 0;
      long lngTotalSecondRun = 0;
      long lngTotalThirdRun = 0;
      long lngTotalFourthRun = 0;

      Console.WriteLine($"All numbers between {intMinimum:#,##0} and {intMaximum:#,##0}");
      Console.WriteLine();

      TimeSpan tsExecutionTime;

      // The first loop (Normal loop)

      dtmStart = DateTime.Now;

      for (int intCounter = 0; intCounter < arrNumber.Length; intCounter++)
      {
        lngTotalFirstRun += arrNumber[intCounter];
      }
      // intCounter = intLength

      dtmEnd = DateTime.Now;
      tsExecutionTime = dtmEnd - dtmStart;
      dblMilliseconds = tsExecutionTime.TotalMilliseconds;

      Console.WriteLine("Result of first run (Normal loop)");
      Console.WriteLine("The total is {00:#,##0}", lngTotalFirstRun);
      Console.WriteLine("The execution time in milliseconds is {0}", dblMilliseconds);
      Console.WriteLine("");

      // The second loop (Loop a bit faster, using a variable)

      dtmStart = DateTime.Now;

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {
        lngTotalSecondRun += arrNumber[intCounter];
      }
      // intCounter = intLength

      dtmEnd = DateTime.Now;
      tsExecutionTime = dtmEnd - dtmStart;
      dblMilliseconds = tsExecutionTime.TotalMilliseconds;

      Console.WriteLine("Result of second run (Loop a bit faster, using a variable)");
      Console.WriteLine("The total is {0:#,##0}", lngTotalSecondRun);
      Console.WriteLine("The execution time in milliseconds is {0}", dblMilliseconds);
      Console.WriteLine("");

      // The third loop (Shortcut)

      dtmStart = DateTime.Now;

      lngTotalThirdRun = (long)(intMaximum) * (intMaximum + 1) / 2;

      dtmEnd = DateTime.Now;
      tsExecutionTime = dtmEnd - dtmStart;
      dblMilliseconds = tsExecutionTime.TotalMilliseconds;

      Console.WriteLine("Result of third run (Shortcut)");
      Console.WriteLine("The total is {0:#,##0}", lngTotalThirdRun);
      Console.WriteLine("The execution time in milliseconds is {0}", dblMilliseconds);
      Console.WriteLine("");

      // The fourth loop (Linq)

      dtmStart = DateTime.Now;

      try
      {
        lngTotalFourthRun = arrNumber.Sum();
      }
      catch
      {
        Console.WriteLine("There was an overflow");
      }

      dtmEnd = DateTime.Now;
      tsExecutionTime = dtmEnd - dtmStart;
      dblMilliseconds = tsExecutionTime.TotalMilliseconds;

      Console.WriteLine("Result of fourth run (Linq)");
      Console.WriteLine("The total is {0:#,##0}", lngTotalFourthRun);
      Console.WriteLine("The execution time in milliseconds is {0}", dblMilliseconds);
      Console.WriteLine();
    }
    // AllNumbersFromXTillY()

    public static void ComputeSumOfSeries(int intMaximum)
    //***
    // Action
    //   - Loops thru all numbers from 0 till intNumber
    //     - Add all of them
    //   - Return the result
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      const int intMinimum = 0;
      DateTime dtmStart;
      DateTime dtmEnd;

      double dblMilliseconds = 0;

      long lngTotal = 0;

      Console.WriteLine($"All numbers between {intMinimum:#,##0} and {intMaximum:#,##0}");
      Console.WriteLine();

      TimeSpan tsExecutionTime;

      dtmStart = DateTime.Now;

      for (int intCounter = intMinimum; intCounter <= intMaximum; intCounter++)
      {
        lngTotal += intCounter;
      }
      // intCounter = intMaximum + 1

      dtmEnd = DateTime.Now;
      tsExecutionTime = dtmEnd - dtmStart;
      dblMilliseconds = tsExecutionTime.TotalMilliseconds;

      Console.WriteLine("Result of run");
      Console.WriteLine("The total is {00:#,##0}", lngTotal);
      Console.WriteLine("The execution time in milliseconds is {0}", dblMilliseconds);
      Console.WriteLine("");
    }
    // ComputeSumOfSeries(int)

    [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
    public static void ComputeSumOfSeriesDoubles(int intMaximum)
    //***
    // Action
    //   - Loops thru all numbers from 0 till intNumber
    //     - Duplicate the number
    //     - Add all of the duplicated
    //   - Return the result
    // Called by
    //   - Main()
    // Calls
    //   - int Multiply(int, int)
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      const int intMinimum = 0;
      DateTime dtmStart;
      DateTime dtmEnd;

      double dblMilliseconds = 0;

      long lngTotal = 0;

      Console.WriteLine($"All numbers between {intMinimum:#,##0} and {intMaximum:#,##0}");
      Console.WriteLine();

      TimeSpan tsExecutionTime;

      dtmStart = DateTime.Now;

      for (int intCounter = intMinimum; intCounter <= intMaximum; intCounter++)
      {
        lngTotal += Multiply(intCounter, 2);
      }
      // intCounter = intMaximum + 1

      dtmEnd = DateTime.Now;
      tsExecutionTime = dtmEnd - dtmStart;
      dblMilliseconds = tsExecutionTime.TotalMilliseconds;

      Console.WriteLine("Result of run");
      Console.WriteLine("The total is {00:#,##0}", lngTotal);
      Console.WriteLine("The execution time in milliseconds is {0}", dblMilliseconds);
      Console.WriteLine("");
    }
    // ComputeSumOfSeriesDoubles(int)

    public static void Main()
    //***
    // Action
    //   - Four loops thru all numbers from X till Y
    //   - Fife loops thru all even numbers from X till Y
    //   - Run the routine ComputeSumOfSeries four times
    //   - Run the routine ComputeSumOfSeriesDoubles four times
    //   - Wait for a user key
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - AllEvenNumbersFromXTillY()
    //   - AllNumbersFromXTillY()
    //   - ComputeSumOfSeries(int)
    //   - ComputeSumOfSeriesDoubles(int)
    // Created
    //   - CopyPaste – 20260524 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260524 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      // AllNumbersFromXTillY();
      // AllEvenNumbersFromXTillY();

      for (int intCounter = 0; intCounter < 4; intCounter++)
      {
        ComputeSumOfSeries(100_000_000);
      }
      // intCounter = 4

      for (int intCounter = 0; intCounter < 4; intCounter++)
      {
        ComputeSumOfSeriesDoubles(100_000_000);
      }
      // intCounter = 4

      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadKey();
    }
    // Main()

    [MethodImplAttribute(MethodImplOptions.AggressiveInlining)]
    public static int Multiply(int intFirst, int intSecond)
     => intFirst * intSecond;
    // ComputeSumOfSeriesDoubles(int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning
