//***
// Action
//   - Having a context to the data set
// Created
//   - CopyPaste � 20251120 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251120 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBindingContextTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Label lblPosition;
    internal System.Windows.Forms.TextBox txtNotes;
    internal System.Windows.Forms.TextBox txtTitle;
    internal System.Windows.Forms.Button cmdPrevious;
    internal System.Windows.Forms.TextBox txtLastName;
    internal System.Windows.Forms.TextBox txtFirstName;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBindingContextTryout));
      this.cmdNext = new System.Windows.Forms.Button();
      this.lblPosition = new System.Windows.Forms.Label();
      this.txtNotes = new System.Windows.Forms.TextBox();
      this.txtTitle = new System.Windows.Forms.TextBox();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.txtLastName = new System.Windows.Forms.TextBox();
      this.txtFirstName = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdNext
      // 
      this.cmdNext.Location = new System.Drawing.Point(201, 168);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(40, 23);
      this.cmdNext.TabIndex = 13;
      this.cmdNext.Text = ">>";
      // 
      // lblPosition
      // 
      this.lblPosition.BackColor = System.Drawing.Color.Lime;
      this.lblPosition.Location = new System.Drawing.Point(65, 168);
      this.lblPosition.Name = "lblPosition";
      this.lblPosition.Size = new System.Drawing.Size(128, 23);
      this.lblPosition.TabIndex = 11;
      this.lblPosition.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // txtNotes
      // 
      this.txtNotes.Location = new System.Drawing.Point(16, 80);
      this.txtNotes.Multiline = true;
      this.txtNotes.Name = "txtNotes";
      this.txtNotes.Size = new System.Drawing.Size(224, 72);
      this.txtNotes.TabIndex = 10;
      this.txtNotes.Text = "";
      // 
      // txtTitle
      // 
      this.txtTitle.Location = new System.Drawing.Point(16, 48);
      this.txtTitle.Name = "txtTitle";
      this.txtTitle.Size = new System.Drawing.Size(225, 20);
      this.txtTitle.TabIndex = 9;
      this.txtTitle.Text = "";
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Location = new System.Drawing.Point(17, 168);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(40, 23);
      this.cmdPrevious.TabIndex = 12;
      this.cmdPrevious.Text = "<<";
      // 
      // txtLastName
      // 
      this.txtLastName.Location = new System.Drawing.Point(145, 16);
      this.txtLastName.Name = "txtLastName";
      this.txtLastName.Size = new System.Drawing.Size(96, 20);
      this.txtLastName.TabIndex = 8;
      this.txtLastName.Text = "";
      // 
      // txtFirstName
      // 
      this.txtFirstName.Location = new System.Drawing.Point(16, 16);
      this.txtFirstName.Name = "txtFirstName";
      this.txtFirstName.TabIndex = 7;
      this.txtFirstName.Text = "";
      // 
      // frmBindingContextTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(256, 206);
      this.Controls.Add(this.txtNotes);
      this.Controls.Add(this.txtTitle);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.txtLastName);
      this.Controls.Add(this.txtFirstName);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.lblPosition);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBindingContextTryout";
      this.Text = "BindingText Tryout";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBindingContext'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251120 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251120 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBindingContextTryout()
      //***
      // Action
      //   - Create instance of 'frmBindingContext'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251120 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251120 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmBindingContext()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static int mlngCurrentPosition;
    private static int mlngRecordCount;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmBindingContextTryout_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Doing some stuff with data set, data row, data table, and columns
      //   - Get the columns of data table tblCPEmployee
      //   - Loop thru all the columns
      //     - Get the column name and column data type
      //   - Show the result
      //   - Fill the data set
      //   - Get how many records there are
      //   - Loop thru all the records
      //     - Get the key and last name
      //   - Show the result
      //   - Add a table (not in the database)
      //   - Create 2 columns and add them to the table
      //   - Create 3 records and add them to the table
      //   - Find a record
      //   - Update a record
      //   - Delete a record
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251120 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251120 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - Everything is in comment because it was a style exercise
      //***
    {
    }
    // frmBindingContextTryout_Load(System.Object, System.EventArgs) Handling this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmBindingContextTryout
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmBindingContextTryout()
      // Created
      //   - CopyPaste � 20251120 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251120 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmBindingContextTryout());
    }
    // Main() 

    private void SetUpData()
      //***
      // Action
      //   - Make an array of 4 controls
      //   - Fill the data of employee
      //   - Bind the correct column to the control
      //   - Loop thru the controls
      //     - Set the backcolor
      //     - Set the fore color
      //     - Disable the control
      //   - Add a functionality to the next and previous button
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251120 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251120 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // SetUpData()

    private void UpdateLabel()
      //***
      // Action
      //   - Get the number of records in tblCPEmployee
      //   - Get the current position (what record is selected)
      //   - If there are records
      //     - Show the current position
      //   - If not
      //     - Show that there are no records
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251120 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251120 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // UpdateLabel()

    private void ValidateRecords(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Get the number of records in tblCPEmployee
    //   - Get the current position (what record is selected)
    //   - If there are records
    //     - Have you clicked on the previous button
    //       - If you are on the first position
    //         - Previous button is disabled
    //       - If not
    //         - Go one back in the recordset
    //     - Have you clicked on the next button
    //       - If you are on the last position
    //         - Next button is disabled
    //       - If not
    //         - Go one forward in the recordset
    //     - Get the current position
    //     - If you are at the last position
    //       - Disable next button
    //     - If not
    //       - Enable next button
    //     - If you are at the first position
    //       - Disable previous button
    //     - If not
    //       - Enable previous button
    //   - If not
    //     - Next and previous buttons are disabled
    //   - Show correct label
    // Called by
    //   - User action (Clicking the next or previous button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20251120 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20251120 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // ValidateRecords(System.Object, System.EventArgs)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBindingContextTryout

}
// CopyPaste.Learning