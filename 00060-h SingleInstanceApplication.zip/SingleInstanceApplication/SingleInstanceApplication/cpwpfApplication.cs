﻿//***
// Action
//   - Because App.xaml is removed, we need to define the application by ourselves
//   - The application contains a list of open documents
//   - Some actions must be done on startup
//   - We can show a document that is opened (by double clicking it)
// Created
//   - CopyPaste – 20220817 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220817 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.ObjectModel;
using System.Windows;

namespace SingleInstanceApplication
{

  public class cpwpfApplication : System.Windows.Application
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    // An ObservableCollection is a List that can provide notifications, a kind of trigger that something is changed
    // When something changes (items are added, deleted, or removed), it triggers a refresh for the controls that are binded with it
    // This pattern is preferred for data binding
    private ObservableCollection<cpDocumentReference> colDocuments = new ObservableCollection<cpDocumentReference>();

    #endregion

    #region "Properties"

    public ObservableCollection<cpDocumentReference> OpenDocuments
    {
      
      get
      //***
      // Action Get
      //   - Returns the list of open documents
      // Called by
      //   - ShowDocument(string)
      //   - wpfcpDocument.OnClosed(System.EventArgs)
      //   - wpfcpDocumentList()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220817 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220817 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return colDocuments;
      }
      // ObservableCollection<cpDocumentReference> OpenDocuments() (Get)

      set
      //***
      // Action Set
      //   - Defines the list of open documents
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220817 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220817 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        colDocuments = value; 
      }
      // OpenDocuments(ObservableCollection<cpDocumentReference>) (Set)
    
    }
    // ObservableCollection<cpDocumentReference> OpenDocuments

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    protected override void OnStartup(System.Windows.StartupEventArgs theStartupEventArguments)
    //***
    // Action
    //   - Startup routine when you startup the application
    //   - Load the main window (only the first time)
    //   - Generate a window that represents all open documents
    //   - Load the document that was specified as an argument.
    // Called by
    //   - Manual action (Starting the application)
    // Calls
    //   - ShowDocument(string)
    //   - wpfcpDocumentList()
    // Created
    //   - CopyPaste – 20220817 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220817 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      base.OnStartup(theStartupEventArguments);

      wpfcpDocumentList theStartupScreen = new wpfcpDocumentList();
      this.MainWindow = theStartupScreen;
      theStartupScreen.Show();

      if (theStartupEventArguments.Args.Length > 0)
      {
        ShowDocument(theStartupEventArguments.Args[0]);
      }
      // theStartupEventArguments.Args.Length > 0

    }
    // OnStartup(System.Windows.StartupEventArgs)

    #endregion

    #region "Sub / Function"

    public void ShowDocument(string strFileName)
    //***
    // Action
    //   - Try to show the document inside the application
    //     - Create a new instance of the Document (the form)
    //     - Create a new instance of the DocumentReference (the Document and Name)
    //     - Load the file
    //     - Make the form a child of the application
    //     - Show the document
    //     - Make the form active
    //     - Add the document to the list of open documents
    //   - Show a message when it fails
    // Called by
    //   - cpSingleInstanceApplicationWrapper.OnStartupNextInstance(Microsoft.VisualBasic.ApplicationServices.StartupNextInstanceEventArgs)
    //   - OnStartup(System.Windows.StartupEventArgs)
    // Calls
    //   - cpDocumentReference(wpfcpDocument, string)
    //   - ObservableCollection<cpDocumentReference> OpenDocuments() (Get)
    //   - wpfcpDocument()
    //   - wpfcpDocument.LoadFile(cpDocumentReference)
    // Created
    //   - CopyPaste – 20220817 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220817 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      try
      {
        wpfcpDocument aDocument = new wpfcpDocument();
        cpDocumentReference aDocumentReference = new cpDocumentReference(aDocument, strFileName);
        aDocument.LoadFile(aDocumentReference);
        aDocument.Owner = this.MainWindow;
        aDocument.Show();
        aDocument.Activate();
        OpenDocuments.Add(aDocumentReference);
      }
      catch
      {
        MessageBox.Show("Could not load document.");
      }

    }
    // ShowDocument(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpwpfApplication

}
// SingleInstanceApplication