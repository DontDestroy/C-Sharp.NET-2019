﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmEuroCalculator.aspx.cs" Inherits="CopyPaste.Learning.wfrmEuroCalculator" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Euro Calculator</title>
</head>
<body>
  <form id="wfrmEuroCalculator" method="post" runat="server">
    <asp:Label ID="lblEuro" Style="z-index: 101; position: absolute; top: 24px; left: 24px" runat="server">Euro</asp:Label>
    <asp:Label ID="lblCountConversions" Style="z-index: 111; position: absolute; top: 160px; left: 40px"
      runat="server">Count conversions: 0</asp:Label>
    <asp:TextBox ID="txtDollar" Style="z-index: 110; position: absolute; top: 112px; left: 72px"
      runat="server" Width="80px"></asp:TextBox>
    <asp:Label ID="lblDollar" Style="z-index: 109; position: absolute; top: 112px; left: 24px"
      runat="server">Dollar</asp:Label>
    <asp:ImageButton ID="ibtConvert" Style="z-index: 108; position: absolute; top: 64px; left: 304px"
      runat="server" ImageUrl="/Currency.jpg"></asp:ImageButton>
    <asp:LinkButton ID="lbtConvert" Style="z-index: 106; position: absolute; top: 64px; left: 176px"
      runat="server">Convert</asp:LinkButton>
    <asp:Button ID="cmdConvert" Style="z-index: 105; position: absolute; top: 64px; left: 40px"
      runat="server" Text="Convert"></asp:Button>
    <asp:CompareValidator ID="cmpvEuro" Style="z-index: 104; position: absolute; top: 24px; left: 168px" runat="server"
      ErrorMessage="The entered amount is not correct" Type="Double" ControlToValidate="txtEuro" Operator="DataTypeCheck"></asp:CompareValidator>
    <asp:RequiredFieldValidator ID="rfvEuro" Style="z-index: 103; position: absolute; top: 24px; left: 168px" runat="server"
      ErrorMessage="Type an amount" ControlToValidate="txtEuro"></asp:RequiredFieldValidator>
    <asp:TextBox ID="txtEuro" Style="z-index: 102; position: absolute; top: 24px; left: 72px" runat="server"
      Width="80px"></asp:TextBox>
  </form>
</body>
</html>
