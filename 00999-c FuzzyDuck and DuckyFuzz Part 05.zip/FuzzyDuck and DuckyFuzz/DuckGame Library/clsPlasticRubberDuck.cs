﻿//***
// Action
//   - Implementation of a cpPlasticRubberDuck
//     - Inherits from cpDuck, where Display (how do I look like) is an abstract method
//       - All class that inherit from cpDuck must implement the Display method
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
//   - The way a cpPlasticRubberDuck moves on water is inherited
//     - All cpDuck and child classes moves on water the same way
//   - The sound that a cpPlasticRubberDuck makes is thru an interface
// Created
//   - CopyPaste – 20240718 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240718 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Game.Duck.Library
{

	public class cpPlasticRubberDuck : cpDuck, cpiQuackable
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpPlasticRubberDuck
		/// </summary>
		public cpPlasticRubberDuck() : base()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - User action (Creating an instance)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpPlasticRubberDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		#region "Overrides"

		/// <summary>
		/// The visualization (displaying) of a cpPlasticRubberDuck
		/// </summary>
		public override void Display()
		//***
		// Action
		//   - Define how a cpPlasticRubberDuck looks like
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Representation of a cpPlasticRubberDuck");
		}
		// Display()

		#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// What noise is the cpPlasticRubberDuck making 
		/// </summary>
		public void Quack()
		//***
		// Action
		//   - Define the noise that the cpPlasticRubberDuck makes
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Represent the sound of a cpPlasticRubberDuck");
		}
		// Quack()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpPlasticRubberDuck

}
// CopyPaste.Game.Duck.Library