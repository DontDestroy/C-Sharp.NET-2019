//***
// Action
//   - Demo of an IFormattable and IComparable implementation thru inheritance
// Created
//   - CopyPaste � 20240531 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240531 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpDerivedDemo : cpDemo
  {

    #region "Constructors / Destructors"

    public cpDerivedDemo(string strValue) : base(strValue)
      //***
      // Action
      //   - Constructor of cpDemo
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpDemo(string)
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDemo(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString(string strFormat, IFormatProvider theFormatProvider)
      //***
      // Action
      //   - Return mstrValue in capitals
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return mstrValue.ToUpper();
    }
    // string ToString(string, IFormatProvider)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpDerivedDemo

}
// CopyPaste.Learning