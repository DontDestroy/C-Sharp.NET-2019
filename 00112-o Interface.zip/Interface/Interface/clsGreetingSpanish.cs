//***
// Action
//   - Implementation of the interface cpiGreetUser results in cpGreetingSpanish
// Created
//   - CopyPaste � 20240529 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240529 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpGreetingSpanish : cpiGreetUser
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void GoodEvening(System.DateTime dtmCurrent)
      //***
      // Action
      //   - Saying Good Evening in Spanish
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Buenas noches -- La fetcha y hora son " + dtmCurrent);
    }
    // GoodEvening(DateTime) Implements cpiGreetUser.GoodEvening

    public void GoodMorning()
      //***
      // Action
      //   - Saying Good Morning in Spanish
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Buenos Dias!");
      Console.WriteLine(DateTime.Now);
    }
    // GoodMorning() Implements cpiGreetUser.GoodMorning

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpGreetingSpanish

}
// CopyPaste.Learning