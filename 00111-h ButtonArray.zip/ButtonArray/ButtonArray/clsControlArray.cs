//***
// Action
//   - Implementation of a Button Array
// Created
//   - CopyPaste � 20240524 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240524 � VVDW
// Proposal (To Do)
//   -
//***

using System.Collections;
using System.Windows.Forms;

namespace CopyPaste.Learning.Toolkit
{

  public class cpControlArray : CollectionBase
  {

    #region "Constructors / Destructors"

    public cpControlArray(Form aContainer)
      //***
      // Action
      //   - Constructor of a button array
      //   - The container is defined (location of the buttons)
      // Called by
      //   - frmButtonArray_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mfrmContainer = aContainer;
    }
    // cpControlArray()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private readonly Form mfrmContainer;

    #endregion

    #region "Properties"

    public Button this[int lngIndex]
    {

      get
        //***
        // Action Get
        //   - Indexer of the buttons
        //   - A certain button on lngIndex is returned
        //     - Button 1 is at position 0
        // Called by
        //   - RemoveLastCommandButton()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240524 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240524 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return List[lngIndex - 1] as Button;
      }
      // Button this[int] (Get)

    }
    // Button this[int]

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private void ButtonArrayClick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Find the control that is showing the result
      //   - At the end of the text of that control, the text of the clicked button is added
      // Called by
      //   - AddCommandButton(int)
      // Calls
      //   - int GetControl(string)
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Button cmdClicked;
      int lngIndex;

      lngIndex = GetControl("lblResult");

      cmdClicked = theSender as Button;
      mfrmContainer.Controls[lngIndex].Text += cmdClicked.Text;
    }
    // ButtonArrayClick(System.Object, System.EventArgs)

    #endregion

    #region "Sub / Function"

    public void AddCommandButton(int lngIndex)
      //***
      // Action
      //   - A new button is defined
      //   - It is added to a list
      //   - It is added to the controls of the container
      //   - Button is given a tag (lngIndex)
      //   - Top and Left (Position) of button is calculated
      //   - Text of button is the text of lngIndex
      //   - A handler is added to the click event of the button
      // Called by
      //   - frmButtonArray.frmButtonArray_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - ButtonArrayClick(System.Object, System.EventArgs)
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Button cmdButton = new Button();

      List.Add(cmdButton);
      mfrmContainer.Controls.Add(cmdButton);
      cmdButton.Tag = lngIndex;
      cmdButton.Top = 20 + lngIndex * 30;
      cmdButton.Left = 30;
      cmdButton.Text = lngIndex.ToString();
      cmdButton.Click += new System.EventHandler(ButtonArrayClick);
    }
    // AddCommandButton(int)
		
    public int GetControl(string strName)
      //***
      // Action
      //   - Find a control with a specific name
      //   - Loop thru the controls of the container
      //     - If the name of the control is the name we are looking for
      //       - Go out of the loop
      //     - If not
      //       - Increment the index by one
      //   - Return the index
      // Called by
      //   - ButtonArrayClick(System.Object, System.EventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngIndex = 0;
      
      foreach (Control theControl in mfrmContainer.Controls)
      {

        if (theControl.Name == strName)
        {
          break;
        }
        else
          // theControl.Name <> strName
        {
          lngIndex += 1;
        }
        // theControl.Name = strName

      }
      // in mfrmContainer.Controls

      return lngIndex;
    }
    // int GetControl(string)

    public void RemoveLastCommandButton()
      //***
      // Action
      //   - Find a control with a specific name
      //   - Count the controls of the container and subtract one
      //   - Result is the index of the last control
      //   - If there are controls in the container
      //     - Remove the last (using index of last control) from the container
      //     - Remove it from the list
      //   - If not
      //     - Do nothing
      // Called by
      //   - frmButtonArray.frmButtonArray_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - Button this[int] (Get)
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngIndex;

      lngIndex = mfrmContainer.Controls.Count - 1;

      if (mfrmContainer.Controls.Count > 0)
      {
        mfrmContainer.Controls.Remove(this[lngIndex]);
        List.RemoveAt(lngIndex - 1);
      }
      else
        // mfrmContainer.Controls.Count <= 0
      {
      }
      // mfrmContainer.Controls.Count > 0

    }
    // RemoveLastCommandButton()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpControlArray

}
// CopyPaste.Learning.Toolkit