﻿//***
// Action
//   - A WPF form to show pets from a pet store.
//   - Working with properties (Get and Set) and methods of the class cpPet and derived classes
// Created
//   - CopyPaste – 20230407 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW
// Tested
//   - CopyPaste – 20230407 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CopyPaste.Pet
{

  public partial class wpfPetStore : Window
  {

    #region "Constructors / Destructors"

    public wpfPetStore()
    //***
    // Action
    //   - Create instance of 'wpfPetStore'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FillArray();
      InitializeComponent();
    }
    // wpfPetStore()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static cpPet[] arrcpPets = new cpPet[9];
    int mintCounter;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdSpeak_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Shows a messagebox with the sound of the animal selected
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - string CopyPaste.Pet.cpAnimal.Speak()
    // Created
    //   - CopyPaste – 20230407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW
    // Tested
    //   - CopyPaste – 20230407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      MessageBox.Show(arrcpPets[lstAnimal.SelectedIndex].Speak());
    }
    // cmdSpeak_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdSpeak.Click

    private void cmdPlay_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Shows a messagebox how the animal selected plays
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - CopyPaste.Pet.cpAnimal.Play() As String
    // Created
    //   - CopyPaste – 20230407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW
    // Tested
    //   - CopyPaste – 20230407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      MessageBox.Show(arrcpPets[lstAnimal.SelectedIndex].Play());
    }
    // cmdPlay_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdPlay.Click

    private void lstAnimal_SelectionChanged(System.Object theSender, System.Windows.Controls.SelectionChangedEventArgs theSelectionChangedEventArguments)
    //***
    // Action
    //   - Display the information of the selected pet in the listbox
    // Called by
    //   - Use action (Clicked another pet in the listbox)
    // Calls
    //   - Display(CopyPaste.Pet.cpPet)
    // Created
    //   - CopyPaste – 20230407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW
    // Tested
    //   - CopyPaste – 20230407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Display(arrcpPets[lstAnimal.SelectedIndex]);
    }
    // lstAnimal_SelectionChanged(System.Object, System.Windows.Controls.SelectionChangedEventArgs) Handles lstAnimal.SelectionChanged

    private void wndStartup_Initialized(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Loop thru the arrcpPets
    //     - Put the breed in the listbox
    // Called by
    //   - Loading / Showing the form
    // Calls
    //   - string CopyPaste.Pet.cpAnimal.cpPet.Breed (Get)
    // Created
    //   - CopyPaste – 20230407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW
    // Tested
    //   - CopyPaste – 20230407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      for (mintCounter = 0; mintCounter < arrcpPets.Length; mintCounter++)
      {
        lstAnimal.Items.Add(arrcpPets[mintCounter].Breed);
      }
      // mintCounter = arrcpPets.Length

    }
    // wndStartup_Initialized(System.Object, System.EventArgs) Handles wndStartup.Initialized

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void Display(CopyPaste.Pet.cpPet thePet)
    //***
    // Action
    //   - Display the information of the selected pet in the listbox
    //   - Fill a textbox with the name of the pet
    //   - Fill a textbox with the species of the pet
    //   - Fill a textbox with the breed of the pet
    //   - Fill a textbox with the gender of the pet
    //   - Fill a textbox with the color of the pet
    //   - Fill a textbox with the leg of the pet
    //   - Fill a textbox with the cost of the pet
    //   - Fill a textbox with the food of the pet
    // Called by
    //   - lstAnimal_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstAnimal.SelectedIndexChanged
    // Calls
    //   - decimal CopyPaste.Pet.cpAnimal.Cost (Get)
    //   - int CopyPaste.Pet.cpAnimal.Legs (Get)
    //   - string CopyPaste.Pet.cpAnimal.Breed (Get)
    //   - string CopyPaste.Pet.cpAnimal.Coloration (Get)
    //   - string CopyPaste.Pet.cpAnimal.Gender (Get)
    //   - string CopyPaste.Pet.cpAnimal.Name (Get)
    //   - string CopyPaste.Pet.cpAnimal.Species (Get)
    //   - string CopyPaste.Pet.cpPet.Food (Get)
    // Created
    //   - CopyPaste – 20230407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW
    // Tested
    //   - CopyPaste – 20230407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      txtName.Text = thePet.Name;
      txtSpecies.Text = thePet.Species;
      txtBreed.Text = thePet.Breed;
      txtGender.Text = thePet.Gender;
      txtColor.Text = thePet.Coloration;
      txtLeg.Text = thePet.Legs.ToString();
      txtCost.Text = thePet.Cost.ToString();
      txtFood.Text = thePet.Food;
    }
    // Display(CopyPaste.Pet.cpPet)

    static void FillArray()
    //***
    // Action
    //   - Fill the array with all the pets
    //   - arrcpPets[0] is a dog with name "Ranger"
    //   - The breed, colloration, cost and gender is filled in
    //   - arrcpPets[1] is a MiniDoxen with name Cindy and color Black
    //   - The gender is filled in
    //   - arrcpPets[2] is a GreatDane with name Sir Ralph and color Brown/White
    //   - The gender is filled in
    //   - arrcpPets[3] is a cat with name "Misty"
    //   - The breed, colloration, cost and gender is filled in
    //   - arrcpPets[4] is a Siamese with name Buster and color Orange/White
    //   - The gender is filled in
    //   - arrcpPets[5] is a Manx with name Horatio and color Brown
    //   - The gender is filled in
    //   - arrcpPets[6] is a bird with name "Bluebill"
    //   - The breed, colloration, cost and gender is filled in
    //   - arrcpPets[7] is a Cockatiel with name Sparky and color Gray/Yellow
    //   - The gender is filled in
    //   - arrcpPets[8] is a Parakeet with name Sprinkles and color White
    //   - The gender is filled in
    // Called by
    //   - Main()
    // Calls
    //   - CopyPaste.Pet.Bird.cpCockatiel(string, string)
    //   - CopyPaste.Pet.Bird.cpParakeet(string, string)
    //   - CopyPaste.Pet.Cat.cpManx(string, string)
    //   - CopyPaste.Pet.Cat.cpSiamese(string, string)
    //   - CopyPaste.Pet.cpAnimal.Breed(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Coloration(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Cost(decimal) (Set)
    //   - CopyPaste.Pet.cpAnimal.Gender(string) (Set)
    //   - CopyPaste.Pet.cpBird(string)
    //   - CopyPaste.Pet.cpCat(string)
    //   - CopyPaste.Pet.cpDog(string)
    //   - CopyPaste.Pet.Dog.cpGreatDane(string, string)
    //   - CopyPaste.Pet.Dog.cpMiniDoxen(string, string)
    // Created
    //   - CopyPaste – 20230407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW
    // Tested
    //   - CopyPaste – 20230407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      arrcpPets[0] = new CopyPaste.Pet.cpDog("Ranger");
      arrcpPets[0].Breed = "German Shepherd";
      arrcpPets[0].Coloration = "Brown/Black";
      arrcpPets[0].Cost = 200;
      arrcpPets[0].Gender = "Male";

      arrcpPets[1] = new CopyPaste.Pet.Dog.cpMiniDoxen("Cindy", "Black");
      arrcpPets[1].Gender = "Female";

      arrcpPets[2] = new CopyPaste.Pet.Dog.cpGreatDane("Sir Ralph", "Brown/White");
      arrcpPets[2].Gender = "Male";

      arrcpPets[3] = new CopyPaste.Pet.cpCat("Misty");
      arrcpPets[3].Breed = "Calico";
      arrcpPets[3].Coloration = "Orange/Black";
      arrcpPets[3].Cost = 50;
      arrcpPets[3].Gender = "Female";

      arrcpPets[4] = new CopyPaste.Pet.Cat.cpSiamese("Buster", "Orange/White");
      arrcpPets[4].Gender = "Male";

      arrcpPets[5] = new CopyPaste.Pet.Cat.cpManx("Horatio", "Brown");
      arrcpPets[5].Gender = "Male";

      arrcpPets[6] = new CopyPaste.Pet.cpBird("Bluebill");
      arrcpPets[6].Breed = "Blue Macaw Parrot";
      arrcpPets[6].Coloration = "Blue/Green/Yellow";
      arrcpPets[6].Cost = 1200;
      arrcpPets[6].Gender = "Male";

      arrcpPets[7] = new CopyPaste.Pet.Bird.cpCockatiel("Sparky", "Gray/Yellow");
      arrcpPets[7].Gender = "Female";

      arrcpPets[8] = new CopyPaste.Pet.Bird.cpParakeet("Sprinkles", "White");
      arrcpPets[8].Gender = "Male";
    }
    // FillArray()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfPetStore

}
// CopyPaste.Pet