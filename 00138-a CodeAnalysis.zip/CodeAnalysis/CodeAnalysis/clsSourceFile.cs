//***
// Action
//   - Implementation of cpSourceFile
// Created
//   - CopyPaste � 20240124 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240124 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System.IO;

namespace CopyPaste.Learning
{

  /// <summary>
  /// A Source File is a textfile that contains programming code
  /// </summary>
  public class cpSourceFile
  {

    #region "Constructors / Destructors"

    /// <summary>
    /// Constructor of cpSourceFile
    /// </summary>
    /// <param name="strFullPath">Full path to the source of the code</param>
    public cpSourceFile(string strFullPath)
      //***
      // Action
      //   - Constructor of cpSourceFile with a full path
      //   - marrstrClassName becomes an array of strings size 10
      //   - Try to do something
      //     - Read the file defined by 'strFullPath'
      //     - Loop thru the lines
      //       - Remove spaces in front and at the back
      //       - Check if it is an empty line or comment
      //       - If Not
      //         - Add 1 to the line counter of code
      //       - If it starts with "Public Class"
      //         - Find the class name
      //         - Add it to the array
      //         - Add 1 to the class counter
      //   - When it fails
      //     - Throw a new exception
      // Called by
      //   - frmCodeAnalysis.cmdBrowse_Click(System.Object, System.EventArgs) Handles cmdBrowse.Click
      // Calls
      //   - int ClassCount (Get)
      // Created
      //   - CopyPaste � 20240124 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240124 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - A lot of improvement can be done
      //***
    {
      marrstrClassName = new string[10];
      mlngClassCount = 0;
      mlngLinesOfCode = 0;
      mstrFullPath = strFullPath;

      StreamReader theStreamReader = new StreamReader(mstrFullPath);

      try
      {
        int lngNameStart;
        string strLine;

        strLine = theStreamReader.ReadLine();

        while (strLine != null)
        {
          strLine = strLine.Trim();

          if ((strLine == "") || (strLine.StartsWith("//")))
          {
          }
          else
            // strLine <> "" And Not strLine.StartsWith("//") 
            // Don �t count blank lines and comment lines
          {
            mlngLinesOfCode++;
          }
          // strLine = "" Or strLine.StartsWith("//")

          if (strLine.StartsWith("public class "))
          {
            string[] arrstrName;
            char[] arrstrSeparator = {ControlChars.Tab, ' '};
            
            lngNameStart = strLine.IndexOf("class ") + 6;
            arrstrName = strLine.Substring(lngNameStart).Trim().Split(arrstrSeparator);
            
            string strClassName = arrstrName[0].Trim();

            marrstrClassName[ClassCount] = strClassName;
            mlngClassCount++;
            // marrstrClassName[mlngClassCount++] = strClassName;
          }
          else
            // Not strLine.StartsWith("Public Class ")
          {
          }
          // strLine.StartsWith("Public Class ")
          
          strLine = theStreamReader.ReadLine();
        }
        // strLine is null

      }
      catch (System.Exception theException)
      {
        throw new System.Exception("Problems parsing source file:" + theException.Message);
      }
      finally
      {
        theStreamReader.Close();
      }

    }
    // cpSourceFile(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string[] marrstrClassName;
    private int mlngClassCount;
    private int mlngLinesOfCode;
    private string mstrFullPath;

    #endregion

    #region "Properties"

    /// <summary>
    /// The number of classes in a cpSourceFile (Get only)
    /// </summary>
    public int ClassCount 
    {

      get
        //***
        // Action Get
        //   - Returns mlngClassCount
        // Called by
        //   - frmCodeAnalysis.cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click
        //   - string GetClass(int)
        //   - Visualisation of cpSourceFile in data grid 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240124 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240124 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngClassCount;
      }
      // int ClassCount (Get)

    }
    // int ClassCount 

    /// <summary>
    /// Returns the file name of the cpSourceFile (Get only)
    /// </summary>
    public string FileName
    {

      get
        //***
        // Action Get
        //   - Returns mlngClassCount
        // Called by
        //   - frmCodeAnalysis.cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click
        //   - Visualisation of cpSourceFile in data grid 
        // Calls
        //   - string FullPath (Get)
        // Created
        //   - CopyPaste � 20240124 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240124 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        int lngLastSlash;

        lngLastSlash = FullPath.LastIndexOf("\\");
        return FullPath.Substring(lngLastSlash + 1);
      }
      // string FileName (Get)

    }
    // string FileName

    /// <summary>
    /// Returns the full path of the cpSourceFile (Get only)
    /// </summary>
    public string FullPath
    {

      get
        //***
        // Action Get
        //   - Returns the full path
        // Called by
        //   - string FileName (Get)
        //   - Visualisation of cpSourceFile in data grid 
        // Calls
        //   - string FullPath() (Get)
        // Created
        //   - CopyPaste � 20240124 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240124 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrFullPath;
      }
      // string FullPath (Get)

    }
    // string FullPath

    /// <summary>
    /// The number of lines of code in a cpSourceFile (Get only)
    /// </summary>
    public int LinesOfCode 
    {

      get
        //***
        // Action Get
        //   - Returns the number of lines of code
        // Called by
        //   - Visualisation of cpSourceFile in data grid 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240124 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240124 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngLinesOfCode;
      }
      // int LinesOfCode (Get)

    }
    // int LinesOfCode 

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    /// <summary>
    /// Returns based on an index the correct class name in a cpSourceFile
    /// </summary>
    /// <param name="lngIndex">An index starting with 0</param>
    /// <returns>A classname</returns>
    public string GetClass(int lngIndex)
      //***
      // Action Get
      //   - If lngIndex is smaller then mlngClassCount
      //     - Returns marrstrClassName(lngIndex)
      //   - If Not
      //     - Throw a new IndexOutOfRangeException
      // Called by
      //   - frmCodeAnalysis.cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click
      //   - Visualisation of cpSourceFile in data grid 
      // Calls
      //   - int ClassCount() (Get)
      // Created
      //   - CopyPaste � 20240124 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240124 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (lngIndex < ClassCount)
      {
        return marrstrClassName[lngIndex];
      }
      else
        // lngIndex >= ClassCount
      {
        throw new System.IndexOutOfRangeException("There are only " + ClassCount + " classes defined.");
      }
      // lngIndex < ClassCount

    }
    // string GetClass(int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpSourceFile

}
// CopyPaste.Learning