//***
// Action
//   - Starting 3 different websites
// Created
//   - CopyPaste � 20250629 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250629 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Diagnostics;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmCompanyInfo: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdYahoo;
    internal System.Windows.Forms.Button cmdGoogle;
    internal System.Windows.Forms.Button cmdMicrosoft;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCompanyInfo));
      this.cmdYahoo = new System.Windows.Forms.Button();
      this.cmdGoogle = new System.Windows.Forms.Button();
      this.cmdMicrosoft = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdYahoo
      // 
      this.cmdYahoo.Location = new System.Drawing.Point(80, 152);
      this.cmdYahoo.Name = "cmdYahoo";
      this.cmdYahoo.Size = new System.Drawing.Size(112, 26);
      this.cmdYahoo.TabIndex = 5;
      this.cmdYahoo.Text = "Yahoo";
      this.cmdYahoo.Click += new System.EventHandler(this.cmdYahoo_Click);
      // 
      // cmdGoogle
      // 
      this.cmdGoogle.Location = new System.Drawing.Point(80, 96);
      this.cmdGoogle.Name = "cmdGoogle";
      this.cmdGoogle.Size = new System.Drawing.Size(112, 28);
      this.cmdGoogle.TabIndex = 4;
      this.cmdGoogle.Text = "Google";
      this.cmdGoogle.Click += new System.EventHandler(this.cmdGoogle_Click);
      // 
      // cmdMicrosoft
      // 
      this.cmdMicrosoft.Location = new System.Drawing.Point(80, 48);
      this.cmdMicrosoft.Name = "cmdMicrosoft";
      this.cmdMicrosoft.Size = new System.Drawing.Size(112, 30);
      this.cmdMicrosoft.TabIndex = 3;
      this.cmdMicrosoft.Text = "Microsoft";
      this.cmdMicrosoft.Click += new System.EventHandler(this.cmdMicrosoft_Click);
      // 
      // frmCompanyInfo
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdYahoo);
      this.Controls.Add(this.cmdGoogle);
      this.Controls.Add(this.cmdMicrosoft);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCompanyInfo";
      this.Text = "CompanyInfo";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmCompanyInfo'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250629 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmCompanyInfo()
      //***
      // Action
      //   - Create instance of 'frmCompanyInfo'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250629 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmCompanyInfo()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdGoogle_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to start the website google.com
      //   - If not successful, show an error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250629 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        Process.Start("msedge.exe", "www.google.com");
      }
      catch
      {
        MessageBox.Show("Error launching Microsoft Edge");
      }
      finally
      {
      }
    
    }
    // cmdGoogle_Click(System.Object, System.EventArgs) Handles cmdGoogle.Click

    private void cmdMicrosoft_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to start the website microsoft.com
      //   - If not successful, show an error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250629 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        Process.Start("msedge.exe", "www.microsoft.com");
      }
      catch
      {
        MessageBox.Show("Error launching Microsoft Edge");
      }
      finally
      {
      }
    
    }
    // cmdMicrosoft_Click(System.Object, System.EventArgs) Handles cmdMicrosoft.Click

    private void cmdYahoo_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to start the website yahoo.com
      //   - If not successful, show an error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250629 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        Process.Start("msedge.exe", "www.yahoo.com");
      }
      catch
      {
        MessageBox.Show("Error launching Microsoft Edge");
      }
      finally
      {
      }
    
    }
    // cmdYahoo_Click(System.Object, System.EventArgs) Handles cmdYahoo.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmCompanyInfo
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDefault()
      // Created
      //   - CopyPaste � 20250629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250629 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmCompanyInfo());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmCompanyInfo

}
// CopyPaste.Learning