﻿  //***
// Action
//   - Client part of a Client Server Application
// Created
//   - CopyPaste – 20220825 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220825 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.ServerApplication;
using System.Collections.Generic;
using System;

namespace CopyPaste.ClientApplication
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Startup of the Client Application
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220825 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220825 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Console.WriteLine("Client says hello!\n");
      Console.WriteLine("Call the product categories from the server:");

      cpDataService theDataService = new cpDataService();
      IList<string> lstProductCategories = theDataService.AllProductCategories();

      foreach (string aProductCategory in lstProductCategories)
      {
        Console.WriteLine(aProductCategory);
      }
      // in lstProductCategories

      Console.ReadKey();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.ClientApplication