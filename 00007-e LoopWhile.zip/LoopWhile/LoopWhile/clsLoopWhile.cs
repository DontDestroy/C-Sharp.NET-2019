//***
// Action
//   - Loop with Do ... Loop While
//   - This structure does not exist in C#
// Created
//   - CopyPaste � 20220117 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220117 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace LoopWhile
{

  class cpLoopWhile
	{

    static void Main()
    //***
    // Action
    //   - Show message
    //   - Ask for number
    //   - While number is not 0
    //     - Add number to total
    //     - Ask for number
    //   - Show total
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - int System.Convert.ToInt32(String)
    //   - string System.Console.ReadLine() 
    //   - System.Console.WriteLine(string)
    //   - System.Console.WriteLine(string, System.Object)
    // Created
    //   - CopyPaste � 20220117 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220117 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngNumber;
      long lngTotal = 0;
      
      Console.WriteLine("Type some numbers. Stop with 0 (zero)");
      
      do
      {
        lngNumber = Convert.ToInt32(Console.ReadLine());
        lngTotal += lngNumber;
      }
      while (lngNumber != 0);
      // lngNumber = 0
      
      Console.WriteLine("Total is {0}", lngTotal);
      Console.ReadLine();
		}
    // Main()

  }
  // cpLoopWhile

}
// LoopWhile