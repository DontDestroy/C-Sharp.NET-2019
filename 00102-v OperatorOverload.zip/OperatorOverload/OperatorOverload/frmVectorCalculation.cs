//***
// Action
//   - A testscreen to visualise the calculations of vectors
//   - 2 vectors and a scalar are given
//   - The functionality add, multiply, subtract are testable
// Created
//   - CopyPaste � 20240403 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240403 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmVectorCalculations: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    private System.Windows.Forms.TextBox txtResult;
    private System.Windows.Forms.Label lblVectorResult;
    private System.Windows.Forms.NumericUpDown nudScalar;
    private System.Windows.Forms.NumericUpDown nudVectorBY;
    private System.Windows.Forms.NumericUpDown nudVectorBX;
    private System.Windows.Forms.Label lblVectorB;
    private System.Windows.Forms.NumericUpDown nudVectorAY;
    private System.Windows.Forms.NumericUpDown nudVectorAX;
    private System.Windows.Forms.Label lblVectorA;
    private System.Windows.Forms.Label lblY;
    private System.Windows.Forms.ComboBox cmbOperator;
    private System.Windows.Forms.Label lblOperator;
    private System.Windows.Forms.Label lblX;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmVectorCalculations));
      this.txtResult = new System.Windows.Forms.TextBox();
      this.lblVectorResult = new System.Windows.Forms.Label();
      this.nudScalar = new System.Windows.Forms.NumericUpDown();
      this.lblOperator = new System.Windows.Forms.Label();
      this.nudVectorBY = new System.Windows.Forms.NumericUpDown();
      this.nudVectorBX = new System.Windows.Forms.NumericUpDown();
      this.lblVectorB = new System.Windows.Forms.Label();
      this.nudVectorAY = new System.Windows.Forms.NumericUpDown();
      this.nudVectorAX = new System.Windows.Forms.NumericUpDown();
      this.lblVectorA = new System.Windows.Forms.Label();
      this.lblY = new System.Windows.Forms.Label();
      this.lblX = new System.Windows.Forms.Label();
      this.cmbOperator = new System.Windows.Forms.ComboBox();
      ((System.ComponentModel.ISupportInitialize)(this.nudScalar)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudVectorBY)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudVectorBX)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudVectorAY)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudVectorAX)).BeginInit();
      this.SuspendLayout();
      // 
      // txtResult
      // 
      this.txtResult.ForeColor = System.Drawing.Color.Green;
      this.txtResult.Location = new System.Drawing.Point(464, 144);
      this.txtResult.Name = "txtResult";
      this.txtResult.TabIndex = 12;
      this.txtResult.Text = "";
      // 
      // lblVectorResult
      // 
      this.lblVectorResult.ForeColor = System.Drawing.Color.Green;
      this.lblVectorResult.Location = new System.Drawing.Point(400, 144);
      this.lblVectorResult.Name = "lblVectorResult";
      this.lblVectorResult.Size = new System.Drawing.Size(56, 23);
      this.lblVectorResult.TabIndex = 11;
      this.lblVectorResult.Text = "Result";
      // 
      // nudScalar
      // 
      this.nudScalar.DecimalPlaces = 1;
      this.nudScalar.Increment = new System.Decimal(new int[] {
                                                                1,
                                                                0,
                                                                0,
                                                                65536});
      this.nudScalar.Location = new System.Drawing.Point(616, 104);
      this.nudScalar.Maximum = new System.Decimal(new int[] {
                                                              2,
                                                              0,
                                                              0,
                                                              0});
      this.nudScalar.Minimum = new System.Decimal(new int[] {
                                                              2,
                                                              0,
                                                              0,
                                                              -2147483648});
      this.nudScalar.Name = "nudScalar";
      this.nudScalar.Size = new System.Drawing.Size(40, 20);
      this.nudScalar.TabIndex = 10;
      this.nudScalar.Value = new System.Decimal(new int[] {
                                                            1,
                                                            0,
                                                            0,
                                                            0});
      this.nudScalar.ValueChanged += new System.EventHandler(this.SomethingChanged);
      this.nudScalar.Leave += new System.EventHandler(this.SomethingChanged);
      // 
      // lblOperator
      // 
      this.lblOperator.Location = new System.Drawing.Point(592, 104);
      this.lblOperator.Name = "lblOperator";
      this.lblOperator.Size = new System.Drawing.Size(16, 23);
      this.lblOperator.TabIndex = 9;
      this.lblOperator.Text = "*";
      // 
      // nudVectorBY
      // 
      this.nudVectorBY.DecimalPlaces = 1;
      this.nudVectorBY.Increment = new System.Decimal(new int[] {
                                                                  1,
                                                                  0,
                                                                  0,
                                                                  65536});
      this.nudVectorBY.Location = new System.Drawing.Point(536, 104);
      this.nudVectorBY.Maximum = new System.Decimal(new int[] {
                                                                4,
                                                                0,
                                                                0,
                                                                0});
      this.nudVectorBY.Minimum = new System.Decimal(new int[] {
                                                                4,
                                                                0,
                                                                0,
                                                                -2147483648});
      this.nudVectorBY.Name = "nudVectorBY";
      this.nudVectorBY.Size = new System.Drawing.Size(40, 20);
      this.nudVectorBY.TabIndex = 8;
      this.nudVectorBY.ValueChanged += new System.EventHandler(this.SomethingChanged);
      this.nudVectorBY.Leave += new System.EventHandler(this.SomethingChanged);
      // 
      // nudVectorBX
      // 
      this.nudVectorBX.DecimalPlaces = 1;
      this.nudVectorBX.Increment = new System.Decimal(new int[] {
                                                                  1,
                                                                  0,
                                                                  0,
                                                                  65536});
      this.nudVectorBX.Location = new System.Drawing.Point(464, 104);
      this.nudVectorBX.Maximum = new System.Decimal(new int[] {
                                                                4,
                                                                0,
                                                                0,
                                                                0});
      this.nudVectorBX.Minimum = new System.Decimal(new int[] {
                                                                4,
                                                                0,
                                                                0,
                                                                -2147483648});
      this.nudVectorBX.Name = "nudVectorBX";
      this.nudVectorBX.Size = new System.Drawing.Size(40, 20);
      this.nudVectorBX.TabIndex = 7;
      this.nudVectorBX.ValueChanged += new System.EventHandler(this.SomethingChanged);
      this.nudVectorBX.Leave += new System.EventHandler(this.SomethingChanged);
      // 
      // lblVectorB
      // 
      this.lblVectorB.ForeColor = System.Drawing.Color.Blue;
      this.lblVectorB.Location = new System.Drawing.Point(400, 104);
      this.lblVectorB.Name = "lblVectorB";
      this.lblVectorB.Size = new System.Drawing.Size(56, 23);
      this.lblVectorB.TabIndex = 6;
      this.lblVectorB.Text = "VectorB";
      // 
      // nudVectorAY
      // 
      this.nudVectorAY.DecimalPlaces = 1;
      this.nudVectorAY.Increment = new System.Decimal(new int[] {
                                                                  1,
                                                                  0,
                                                                  0,
                                                                  65536});
      this.nudVectorAY.Location = new System.Drawing.Point(536, 40);
      this.nudVectorAY.Maximum = new System.Decimal(new int[] {
                                                                4,
                                                                0,
                                                                0,
                                                                0});
      this.nudVectorAY.Minimum = new System.Decimal(new int[] {
                                                                4,
                                                                0,
                                                                0,
                                                                -2147483648});
      this.nudVectorAY.Name = "nudVectorAY";
      this.nudVectorAY.Size = new System.Drawing.Size(40, 20);
      this.nudVectorAY.TabIndex = 4;
      this.nudVectorAY.ValueChanged += new System.EventHandler(this.SomethingChanged);
      this.nudVectorAY.Leave += new System.EventHandler(this.SomethingChanged);
      // 
      // nudVectorAX
      // 
      this.nudVectorAX.DecimalPlaces = 1;
      this.nudVectorAX.Increment = new System.Decimal(new int[] {
                                                                  1,
                                                                  0,
                                                                  0,
                                                                  65536});
      this.nudVectorAX.Location = new System.Drawing.Point(464, 40);
      this.nudVectorAX.Maximum = new System.Decimal(new int[] {
                                                                4,
                                                                0,
                                                                0,
                                                                0});
      this.nudVectorAX.Minimum = new System.Decimal(new int[] {
                                                                4,
                                                                0,
                                                                0,
                                                                -2147483648});
      this.nudVectorAX.Name = "nudVectorAX";
      this.nudVectorAX.Size = new System.Drawing.Size(40, 20);
      this.nudVectorAX.TabIndex = 3;
      this.nudVectorAX.ValueChanged += new System.EventHandler(this.SomethingChanged);
      this.nudVectorAX.Leave += new System.EventHandler(this.SomethingChanged);
      // 
      // lblVectorA
      // 
      this.lblVectorA.ForeColor = System.Drawing.Color.Red;
      this.lblVectorA.Location = new System.Drawing.Point(400, 48);
      this.lblVectorA.Name = "lblVectorA";
      this.lblVectorA.Size = new System.Drawing.Size(56, 23);
      this.lblVectorA.TabIndex = 2;
      this.lblVectorA.Text = "Vector A";
      // 
      // lblY
      // 
      this.lblY.Location = new System.Drawing.Point(552, 8);
      this.lblY.Name = "lblY";
      this.lblY.Size = new System.Drawing.Size(48, 23);
      this.lblY.TabIndex = 1;
      this.lblY.Text = "Y";
      // 
      // lblX
      // 
      this.lblX.Location = new System.Drawing.Point(472, 8);
      this.lblX.Name = "lblX";
      this.lblX.Size = new System.Drawing.Size(56, 23);
      this.lblX.TabIndex = 0;
      this.lblX.Text = "X";
      // 
      // cmbOperator
      // 
      this.cmbOperator.ItemHeight = 13;
      this.cmbOperator.Location = new System.Drawing.Point(464, 72);
      this.cmbOperator.Name = "cmbOperator";
      this.cmbOperator.Size = new System.Drawing.Size(121, 21);
      this.cmbOperator.TabIndex = 5;
      this.cmbOperator.Text = "cmbOperator";
      this.cmbOperator.SelectedIndexChanged += new System.EventHandler(this.SomethingChanged);
      // 
      // frmVectorCalculations
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(664, 350);
      this.Controls.Add(this.cmbOperator);
      this.Controls.Add(this.txtResult);
      this.Controls.Add(this.lblVectorResult);
      this.Controls.Add(this.nudScalar);
      this.Controls.Add(this.lblOperator);
      this.Controls.Add(this.nudVectorBY);
      this.Controls.Add(this.nudVectorBX);
      this.Controls.Add(this.lblVectorB);
      this.Controls.Add(this.nudVectorAY);
      this.Controls.Add(this.nudVectorAX);
      this.Controls.Add(this.lblVectorA);
      this.Controls.Add(this.lblY);
      this.Controls.Add(this.lblX);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmVectorCalculations";
      this.Text = "Demo of vector calculations";
      this.Load += new System.EventHandler(this.frmVectorCalculations_Load);
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.frmVectorCalculations_Paint);
      ((System.ComponentModel.ISupportInitialize)(this.nudScalar)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudVectorBY)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudVectorBX)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudVectorAY)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudVectorAX)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmVectorCalculations'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmVectorCalculations()
      //***
      // Action
      //   - Create instance of 'frmVectorCalculations'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmVectorCalculations()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private SortedList srlCalculations = new SortedList();
      // A list of all the calculations
      // The selected calculation in the list is done on every change of the coordinates
    private static int lngCenterPosition = 180; // Center of the diagram
    private static int lngLength = 320; // Length of the axes
    private static int lngStartPosition = 20; // Start Position of axes
    private static int lngPixelsPerUnit = 12; // One unit is xx pixels

    #endregion

    #region "Properties"

    private cpVector FirstVector
    {

      get
        //***
        // Action Get
        //   - Makes from 2 coordinates on the screen an actual cpVector
        // Called by
        //   - 
        // Calls
        //   - cpVector(double, double)
        // Created
        //   - CopyPaste � 20240403 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240403 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        cpVector cpResult;
        double XCoordinate;
        double YCoordinate;

        XCoordinate = (double) nudVectorAX.Value;
        YCoordinate = (double) nudVectorAY.Value;

        cpResult = new cpVector(XCoordinate, YCoordinate);

        return cpResult;
      }
      // cpVector FirstVector (Get)

    }
    // cpVector FirstVector

    private cpVector SecondVector
    {

      get
        //***
        // Action Get
        //   - Makes from 2 coordinates on the screen an actual cpVector
        // Called by
        //   - 
        // Calls
        //   - cpVector(double, double)
        // Created
        //   - CopyPaste � 20240403 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240403 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        cpVector cpResult;
        double XCoordinate;
        double YCoordinate;

        XCoordinate = (double) nudVectorBX.Value;
        YCoordinate = (double) nudVectorBY.Value;

        cpResult = new cpVector(XCoordinate, YCoordinate);

        return cpResult;
      }
      // cpVector SecondVector (Get)

    }
    // cpVector FirstVector

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmVectorCalculations_Paint(System.Object theSender, System.Windows.Forms.PaintEventArgs thePaintEventArguments)
      //***
      // Action
      //   - Draw the X and Y axis of the region where we will visualize the cpVectors
      // Called by
      //   - User action (Drawing the from)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      thePaintEventArguments.Graphics.DrawLine(Pens.Black, lngStartPosition, lngCenterPosition, lngStartPosition + lngLength, lngCenterPosition);
      thePaintEventArguments.Graphics.DrawLine(Pens.Black, lngCenterPosition, lngStartPosition, lngCenterPosition, lngStartPosition + lngLength);
    }
    // frmVectorCalculations_Paint(System.Object, System.Windows.Forms.PaintEventArgs) Handles frmVectorCalculations.Paint

    private void frmVectorCalculations_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define the possible calculations, using the delegate
      //   - At this moment there are 3 calculations possible
      //     - Add
      //     - Are equal
      //     - Subtract
      // Called by
      //   - User action (Starting the from)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      srlCalculations.Add("Add", new cpVectorMath(AddVectors));
      srlCalculations.Add("Are Equal", new cpVectorMath(AreVectorsEqual));
      srlCalculations.Add("Subtract", new cpVectorMath(SubtractVectors));
      cmbOperator.DataSource = srlCalculations.Keys;
    }
    // frmVectorCalculations_Load(System.Object, System.EventArgs) Handles frmVectorCalculations.Load

    #endregion

    #region "Functionality"

    #region "Event"

    private delegate void cpVectorMath(cpVector theFirstVector, cpVector theSecondVector);
    // frmVectorCalculations_Load(System.Object, System.EventArgs) Handles frmVectorCalculations.Load
    // Represents the calculation executed
    // Can be AddVectors, AreVectorsEqual, SubtractVectors
    // All calculations must have the same signature

    #endregion

    #region "Sub / Function"

    private void AddVectors(cpVector theFirstVector, cpVector theSecondVector)
      //***
      // Action
      //   - Draw the first cpVector on the diagram in red 
      //     - Starting point is the center
      //   - Draw the second cpVector on the diagram in blue
      //     - Starting point is the end of the first cpVector
      //   - Add the 2 cpVectors
      //   - Draw the result cpVector on the diagram in green
      //   - Show the coordinates of the result cpVector
      // Called by
      //   - 
      // Calls
      //   - cpVector cpVector.+(cpVector, cpVector)
      //   - DrawVector(cpVector, Color)
      //   - DrawVector(cpVector, cpVector, Color)
      //   - string cpVector.ToString()
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpVector theResultVector;
      
      DrawVector(theFirstVector, Color.Red);
      DrawVector(theFirstVector, theSecondVector, Color.Blue);
      theResultVector = theFirstVector + theSecondVector;
      DrawVector(theResultVector, Color.Green);
      txtResult.Text = theResultVector.ToString();
    }
    // AddVectors(cpVector, cpVector)

    private void AreVectorsEqual(cpVector theFirstVector, cpVector theSecondVector)
      //***
      // Action
      //   - Compare both cpVectors
      //   - Show the result on the screen
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;
      
      blnResult = (theFirstVector == theSecondVector);
      txtResult.Text = blnResult.ToString();
    }
    // AreVectorsEqual(cpVector, cpVector)

    private Point cpVectorCoordinateToPoint(cpVector theVector)
      //***
      // Action
      //   - The center of the diagram is at lngCenterPosition
      //   - The lenght of the diagram is lngLength
      //   - The coordinates can be between -4 and +4
      //   - The multiplication can be between -2 and +2
      //   - The biggest result is vector (4, 4) + 2 times vector (4, 4)
      //     --> (12, 12) is the biggest result
      //   - Calculation is coordinate * 12 to have the position on the diagram
      //   - Take also the center of the diagram into account
      //     --> Coordinate = lngCenterPosition + coordinate * 12 (lngPixelsPerUnit)
      //   - X coordinate is this calculation
      //   - Y coordinate is this calculation, but with a negative coordinate
      //     (Y positive is higher on the screen)
      // Called by
      //   - DrawVector(cpVector, Color)
      //   - DrawVector(cpVector, cpVector, Color)
      // Calls
      //   - cpVector.X(double) (Set)
      //   - cpVector.Y(double) (Set)
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngX;
      int lngY;

      lngX = (int) (theVector.X * lngPixelsPerUnit + lngCenterPosition);
      lngY = (int) (-theVector.Y * lngPixelsPerUnit + lngCenterPosition);

      return new Point(lngX, lngY);
    }
    // Point cpVectorCoordinateToPoint(cpVector)

    private void DrawVector(cpVector theVector, Color theColor)
      //***
      // Action
      //   - Draw a cpVector on the diagram from the centerpoint
      //   - Calculate the start position
      //   - Calculate the end position
      //   - Draw a line of a specific color
      // Called by
      //   - AddVectors(cpVector, cpVector)
      //   - SubtractVectors(cpVector, cpVector)
      // Calls
      //   - cpVector(double, double)
      //   - Point cpVectorCoordinateToPoint(cpVector)
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpVector theCenterVector;
      SolidBrush theBrush;
      Pen thePen;

      theBrush = new SolidBrush(theColor);
      theCenterVector = new cpVector(0,0);
      thePen = new Pen(theBrush, 3);

      Point theCenter = cpVectorCoordinateToPoint(theCenterVector);
      Point theEnd = cpVectorCoordinateToPoint(theVector);

      this.CreateGraphics().DrawLine(thePen, theCenter, theEnd);
    }
    // DrawVector(cpVector, Color)

    private void DrawVector(cpVector theFirstVector, cpVector theSecondVector, Color theColor)
      //***
      // Action
      //   - Draw a cpVector on the diagram from the end position of another cpVector
      //   - Calculate the start position
      //   - Calculate the end position
      //   - Draw a line of a specific color
      // Called by
      //   - AddVectors(cpVector, cpVector)
      //   - SubtractVectors(cpVector, cpVector)
      // Calls
      //   - cpVector cpVector.+(cpVector, cpVector)
      //   - Point cpVectorCoordinateToPoint(cpVector)
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      SolidBrush theBrush;
      Pen thePen;

      theBrush = new SolidBrush(theColor);
      thePen = new Pen(theBrush, 3);

      Point theStart = cpVectorCoordinateToPoint(theFirstVector);
      Point theEnd = cpVectorCoordinateToPoint(theFirstVector + theSecondVector);

      this.CreateGraphics().DrawLine(thePen, theStart, theEnd);
    }
    // DrawVector(cpVector, cpVector, Color)

    [STAThreadAttribute]
    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmVectorCalculations
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmVectorCalculations()
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmVectorCalculations());
    }
    // Main() 

    private void SomethingChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Something changed on the screen, so the calculations and drawings must be done again
      //   - Redraw the screen
      //   - Determing the selected calculation (one of three options at this moment)
      //   - Execute the choosen calculation
      // Called by
      //   - User action (Changing a value in NumericUpDown)
      //   - User action (Selecting an option in ComboBox)
      // Calls
      //   - bool ==(cpVector, cpVector) thru AreVectorsEqual(cpVector, cpVector)
      //   - bool AreVectorsEqual(cpVector, cpVector)
      //   - cpVector +(cpVector, cpVector) thru AddVectors(cpVector, cpVector)
      //   - cpVector -(cpVector, cpVector) thru SubtractVectors(cpVector, cpVector)
      //   - cpVector *(cpVector, double)
      //   - cpVector AddVectors(cpVector, cpVector)
      //   - cpVector SubtractVectors(cpVector, cpVector)
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpVectorMath theSelectedCalculation; 
      string strOperator;

      this.Refresh();
      strOperator = cmbOperator.Text;
      theSelectedCalculation = (cpVectorMath)srlCalculations[strOperator];
      theSelectedCalculation(FirstVector, SecondVector * (double)nudScalar.Value);
    }
    // SomethingChanged(System.Object, System.EventArgs) Handles cmbOperator.SelectedIndexChanged, 
    //   nudVectorAX.ValueChanged, nudVectorAX.Leave,
    //   nudVectorAY.ValueChanged, nudVectorAY.Leave, 
    //   nudVectorBX.ValueChanged, nudVectorBX.Leave, 
    //   nudVectorBY.ValueChanged, nudVectorBY.Leave,
    //   nudScalar.ValueChanged, nudScalar.Leave

    private void SubtractVectors(cpVector theFirstVector, cpVector theSecondVector)
      //***
      // Action
      //   - Draw the first cpVector on the diagram in red 
      //     - Starting point is the center
      //   - Draw the second cpVector on the diagram in blue
      //     - Starting point is the end of the first cpVector
      //   - Add the 2 cpVectors
      //   - Draw the result cpVector on the diagram in green
      //   - Show the coordinates of the result cpVector
      // Called by
      //   - 
      // Calls
      //   - cpVector cpVector.-(cpVector)
      //   - cpVector cpVector.-(cpVector, cpVector)
      //   - DrawVector(cpVector, Color)
      //   - DrawVector(cpVector, cpVector, Color)
      //   - string cpVector.ToString()
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpVector theResultVector;
      
      DrawVector(theFirstVector, Color.Red);
      DrawVector(theFirstVector, -theSecondVector, Color.Blue);
      theResultVector = theFirstVector - theSecondVector;
      DrawVector(theResultVector, Color.Green);
      txtResult.Text = theResultVector.ToString();
    }
    // SubtractVectors(cpVector, cpVector)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmVectorCalculations

}
// CopyPaste.Learning