﻿//***
// Action
//   - Class implements the INotifyPropertyChanged Event Procedure
//   - Implementing PropertyChanged Event to raise to any UI object
// Created
//   - CopyPaste – 20210809 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210809 – VVDW
// Proposal (To Do)
//   - Later will it be only executed when databinding is used for that component
//***

using System.ComponentModel;

namespace WPFCommand
{

  public class cpCommon : INotifyPropertyChanged
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public event PropertyChangedEventHandler PropertyChanged;

    #endregion

    #region "Sub / Function"

    protected void RaisePropertyChanged(string strPropertyName)
    //***
    // Action
    //   - Define a handler (theHandler) 
    //   - If thehandler Is connected (Not null)
    //     - Define the arguments of a certain property (strPropertyName)
    //     - Raise the PropertyChanged event with the arguments of that property
    // Called by
    //   - User Action Or System Action (a property of a UI object Is changed)
    //   - cpViewModelBase.ResultText(string) (Set)
    //   - cpViewModelBase.RowsAffected(int) (Set)
    //   - cpCommandViewModel.InputEntity(cpProduct) (Set)
    //   - cpCommandViewModel.SearchEntity(cpProduct) (Set)
    //   - int cpCommandViewModel.InsertProductOutputParameters()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //    - 
    // Proposal (To Do)
    //    -
    //***
    {
      PropertyChangedEventHandler theHandler = this.PropertyChanged;

      if (theHandler == null)
      {
      }
      else
      // (theHandler != null)
      {
        PropertyChangedEventArgs args = new PropertyChangedEventArgs(strPropertyName);

        theHandler(this, args);
      }
      // (theHandler == null)

    }
    // RaisePropertyChanged(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCommon 

}
// WPFCommand