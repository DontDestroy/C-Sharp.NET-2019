﻿//***
// Action
//   - Implementation of a cpPlasticRubberDuck
//     - Inherits from cpDuck, where Display (how do I look like) is an abstract method
//       - All class that inherit from cpDuck must implement the Display method
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
//   - The way a cpPlasticRubberDuck moves on water is inherited
//     - All cpDuck and child classes moves on water the same way
//   - The sound that a cpPlasticRubberDuck makes is given thru a delegate and an event
//   - The way a cpPlasticRubberDuck moves on land is given thru a delegate and an event
//   - The way a cpPlasticRubberDuck moves in the air is given thru a delegate and an event
// Created
//   - CopyPaste – 20240725 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240725 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;
using CopyPaste.Game.Animal.Library;

namespace CopyPaste.Game.Duck.Library
{

	public class cpPlasticRubberDuck : cpDuck
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpPlasticRubberDuck
		/// </summary>
		public cpPlasticRubberDuck() : base()
		//***
		// Action
		//   - Basic constructor
		//   - Define how a cpPlasticRubberDuck flies (not)
		//   - Define how a cpPlasticRubberDuck makes some noise (squeaking)
		//   - Define how a cpPlasticRubberDuck walks (not)
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - cpDuck()
		//   - cpFlyNoWay()
		//   - cpFlyNoWay.Fly()
		//   - cpSqueak()
		//   - cpSqueak.MakeNoise()
		//   - cpWalkNoWay()
		//   - cpWalkNoWay.Walk()
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			cpiFly cpHowToFly = new cpFlyNoWay();
			cpiMakeNoise cpHowToMakeNoise = new cpSqueak();
			cpiWalk cpHowToWalk = new cpWalkNoWay();

			PerformFly += new cpDelegateFly(cpHowToFly.Fly);
			PerformMakeNoise += new cpDelegateMakeNoise(cpHowToMakeNoise.MakeNoise);
			PerformWalk += new cpDelegateWalk(cpHowToWalk.Walk);
		}
		// cpPlasticRubberDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		#region "Overrides"

		/// <summary>
		/// The visualization (displaying) of a cpPlasticRubberDuck
		/// </summary>
		public override void Display()
		//***
		// Action
		//   - Define how a cpPlasticRubberDuck looks like
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Representation of a cpPlasticRubberDuck");
		}
		// Display()

		#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpPlasticRubberDuck

}
// CopyPaste.Game.Duck.Library