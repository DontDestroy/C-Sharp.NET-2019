﻿//***
// Action
//   - Working with a fixed connectionstring
// Created
//   - CopyPaste – 20251209 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251209 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpConnectionString
  {

    #region "Constructors / Destructors"

    public cpConnectionString()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - frmListBoxAddDelete.LoadList()
      //   - frmListBoxAddDelete.RefreshIndividual()
      //   - frmListBoxUpdate.LoadList()
      //   - frmListBoxUpdate.RefreshIndividual()
      //   - frmStoredProcedure.cmdView_Click(System.Object, System.EventArgs) Handles cmdView.Click
      //   - frmUpdateOnTheFly.cmdExecute_Click(System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdExecute.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251209 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251209 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpConnectionString()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string BuildConnectionString()
      //***
      // Action
      //   - Returning a hardcoded connectionstring
      // Called by
      //   - frmListBoxAddDelete.LoadList()
      //   - frmListBoxAddDelete.RefreshIndividual()
      //   - frmListBoxUpdate.LoadList()
      //   - frmListBoxUpdate.RefreshIndividual()
      //   - frmStoredProcedure.cmdView_Click(System.Object, System.EventArgs) Handles cmdView.Click
      //   - frmUpdateOnTheFly.cmdExecute_Click(System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdExecute.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251209 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251209 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {     
      return "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integrated Security=True";
    }
    // string BuildConnectionString()
		
		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpConnectionString

}
// CopyPaste.Learning