//***
// Action
//   - Demo of events on a button
// Created
//   - CopyPaste � 20240522 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240522 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmEvent: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdButton;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmEvent));
      this.cmdButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdButton
      // 
      this.cmdButton.Location = new System.Drawing.Point(104, 72);
      this.cmdButton.Name = "cmdButton";
      this.cmdButton.TabIndex = 1;
      this.cmdButton.Text = "Click me";
      this.cmdButton.Click += new System.EventHandler(this.cmdButton_Click);
      this.cmdButton.TextChanged += new System.EventHandler(this.cmdButton_TextChanged);
      // 
      // frmEvent
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(280, 181);
      this.Controls.Add(this.cmdButton);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmEvent";
      this.Text = "Event Demo";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmEvent'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmEvent()
      //***
      // Action
      //   - Create instance of 'frmEvent'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmEvent()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdButton_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a message that the click event occurred
      //   - If text of button is "Click me"
      //     - Change the text into "Clicked"
      //   - If not
      //     - Change the text into "Click me"
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show("Click event occurred");

      if (cmdButton.Text == "Click me")
      {
        cmdButton.Text = "Clicked";
      }
      else
        // cmdButton.Text <> "Click me"
      {
        cmdButton.Text = "Click me";
      }
      // cmdButton.Text = "Click me"
    
    }
    // cmdButton_Click(System.Object, System.EventArgs) Handles cmdButton.Click

    private void cmdButton_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a message that the text of the button is changed
      // Called by
      //   - System action (Text of a button is changed)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show("Textchanged event occurred");
    }
    // cmdButton_TextChanged(System.Object, System.EventArgs) Handles cmdButton.TextChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmEvent
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmEvent()
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmEvent());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmEvent

}
// CopyPaste.Learning