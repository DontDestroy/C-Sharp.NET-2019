//***
// Action
//   - Choose the green or red button
// Created
//   - CopyPaste � 20240227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240227 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmModal: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdRed;
    internal System.Windows.Forms.Button cmdGreen;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmModal));
      this.cmdRed = new System.Windows.Forms.Button();
      this.cmdGreen = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdRed
      // 
      this.cmdRed.Location = new System.Drawing.Point(122, 24);
      this.cmdRed.Name = "cmdRed";
      this.cmdRed.TabIndex = 3;
      this.cmdRed.Text = "Red";
      this.cmdRed.Click += new System.EventHandler(this.cmdRed_Click);
      // 
      // cmdGreen
      // 
      this.cmdGreen.Location = new System.Drawing.Point(18, 24);
      this.cmdGreen.Name = "cmdGreen";
      this.cmdGreen.TabIndex = 2;
      this.cmdGreen.Text = "Green";
      this.cmdGreen.Click += new System.EventHandler(this.cmdGreen_Click);
      // 
      // frmModal
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(214, 99);
      this.Controls.Add(this.cmdRed);
      this.Controls.Add(this.cmdGreen);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.Name = "frmModal";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Modal";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmModal'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmModal()
      //***
      // Action
      //   - Create instance of 'frmModal'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmModal()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdGreen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a new frmGreen
      //   - Show it as a dialog
      //   - Dispose it when the dialog is stopped
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmGreen()
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    { 
      frmGreen theForm = new frmGreen();

      theForm.ShowDialog();
      theForm.Dispose();
    }
    // cmdGreen_Click(System.Object, System.EventArgs) Handles cmdGreen.Click

    private void cmdRed_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a new frmRed
      //   - Show it as a dialog
      //   - Dispose it when the dialog is stopped
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmRed()
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmRed theForm = new frmRed();

      theForm.ShowDialog();
      theForm.Dispose();
    }
    // cmdRed_Click(System.Object, System.EventArgs) Handles cmdRed.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmModal
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmModal());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmModal

}
// CopyPaste.Learning