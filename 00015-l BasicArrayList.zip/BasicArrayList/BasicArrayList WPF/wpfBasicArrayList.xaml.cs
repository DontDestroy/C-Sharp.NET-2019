﻿//***
// Action
//   - Working with a basic array list
// Created
//   - CopyPaste – 20220825 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220825 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BasicArrayList_WPF
{

  public partial class wpfBasicArrayList : Window
  {

    #region "Constructors / Destructors"

    public wpfBasicArrayList()
    //***
    // Action
    //   - Create instance of 'wpfBasicArrayList'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220825 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220825 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfBasicArrayList()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    ArrayList marrLaborsOfHercules = new ArrayList();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFind_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Find a specific element in the array list
    //   - Show info in MessageBox
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - int ArrayList.IndexOf(Array, System.Object)
    //   - DialogResult MessageBox.Show(string, string)
    //   - ArrayList.Sort(Array)
    // Created
    //   - CopyPaste – 20220825 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220825 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngIndex;

      lngIndex = marrLaborsOfHercules.IndexOf("Learn C# .NET");
      MessageBox.Show("In element: " + lngIndex.ToString(), "Copy Paste Tryout");

      marrLaborsOfHercules.Sort();
      lngIndex = marrLaborsOfHercules.IndexOf("Learn C# .NET");
      MessageBox.Show("In element: " + lngIndex.ToString(), "Copy Paste Tryout");
    }
    // cmdFind_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdFind.Click

    private void cmdToDo_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Loop thru elements of array
    //     - Prepare message with value of element
    //   - Show info in MessageBox
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - ArrayList.Reverse()
    //   - ArrayList.Sort()
    //   - DialogResult MessageBox.Show(string, string) 
    // Created
    //   - CopyPaste – 20220825 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220825 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngIndex = 0;
      string strCollectionContent = "";

      // marrLaborsOfHercules.Sort()
      // marrLaborsOfHercules.Reverse()

      foreach (string strCollectionItemContent in marrLaborsOfHercules)
      {
        strCollectionContent += strCollectionItemContent + "\n";
        // lngIndex += 1;
        // strCollectionContent += lngIndex.ToString() + ". " + strCollectionItemContent + "\n";
      }
      // In marrLaborsOfHercules

      MessageBox.Show(strCollectionContent, "Copy Paste Tryout");
    }
    // cmdToDo_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdToDo.Click

    private void Window_Loaded(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Fill an array list with 13 elements
    //   - Show some info in MessageBox
    // Called by
    //   - User action (Loading a form)
    // Calls
    //   - ArrayList.Clear()
    //   - ArrayList.TrimToSize()
    //   - DialogResult MessageBox.Show(string, string)
    //   - int ArrayList.Add(string)
    //   - int ArrayList.Capacity()
    //   - int ArrayList.Count()
    // Created
    //   - CopyPaste – 20220214 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220214 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strCollectionInfo;

      marrLaborsOfHercules.Add("Kill Nemean Lion");
      marrLaborsOfHercules.Add("Slay nine-headed hydra of Lerna");
      marrLaborsOfHercules.Add("Capture elusive Stag of Arcadia");
      marrLaborsOfHercules.Add("Capture wild boar on Mt. Erymantus");
      marrLaborsOfHercules.Add("Clean Stables of King Augeas of Elis");
      marrLaborsOfHercules.Add("Shoot monstrous man-eating burds of the Stymphalian Marshes");
      marrLaborsOfHercules.Add("Capture mad bul of Crete");
      marrLaborsOfHercules.Add("Kill man-eating mares of King Diomedes");
      marrLaborsOfHercules.Add("Steal Girdle of Hippolyta");
      marrLaborsOfHercules.Add("Seize cattle of Geryon of Erytheia");
      marrLaborsOfHercules.Add("Fetch golden apples of Hesperides");
      marrLaborsOfHercules.Add("Retrieve three-headed dog Cerberus from Hell");
      marrLaborsOfHercules.Add("Learn C# .NET");
      // marrLaborsOfHercules.Add("Learn C# .NET in a single day");

      // marrLaborsOfHercules.Clear()
      // marrLaborsOfHercules.TrimToSize()

      strCollectionInfo = "Collection Count is: " + marrLaborsOfHercules.Count.ToString() + "\n";
      strCollectionInfo += "Collection Capacity is: " + marrLaborsOfHercules.Capacity.ToString() + "\n";

      MessageBox.Show(strCollectionInfo, "Copy Paste Tryout: Collection Information");
    }
    // Window_Loaded(System.Object, System.Windows.RoutedEventArgs) Handles Window.Loaded


    #endregion

    //#region "Functionality"

    //***
    // Action
    //   - Explanation of the code in this module or class
    // Called by
    //   - List of code that uses this procedure
    // Calls
    //   - List of procedures that are called by this piece of code
    // Created
    //   - CopyPaste – yyyymmdd – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – yyyymmdd – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfBasicArrayList 

}
// BasicArrayList_WPF