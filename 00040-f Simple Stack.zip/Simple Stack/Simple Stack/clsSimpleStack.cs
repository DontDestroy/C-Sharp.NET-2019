﻿//***
// Action
//   - Creating a simple stack, not using the existing libraries
// Created
//   - CopyPaste – 20220930 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220930 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Text;

namespace Simple_Stack
{

  public class cpSimpleStack
  {

    #region "Constructors / Destructors"

    public cpSimpleStack()
    //***
    // Action
    //   - Define the array 10 long
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220930 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220930 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      arrThings = new Object[10];
    }
    // cpSimpleStack()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int intPosition;
    private Object[] arrThings;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public Object Pop()
    //***
    // Action
    //   - Takes the top item of the stack
    //   - Because the thing is an Object, you will downcast it to the type you want
    //     - Every instance of whatever type can be used, because all types inherit from Object
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220930 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220930 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      return arrThings[--intPosition];
    }
    // Object Pop()

    public void Push(Object aThing)
    //***
    // Action
    //   - Push an item on top of the stack
    //   - Because the thing that will be place on the stack is an Object
    //     - Every instance of whatever type can be used, because all types inherit from Object
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220930 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220930 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      arrThings[intPosition++] = aThing;
    }
    // Push(Object)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpSimpleStack

}
// Simple_Stack