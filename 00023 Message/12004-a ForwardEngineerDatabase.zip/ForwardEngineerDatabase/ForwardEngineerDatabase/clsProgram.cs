﻿//***
// Action
//   - There is a database cpWings
//     - The script can be found in the folder 'SQL Script'
//   - The database is a result of forward engineer classes with Entity FrameWork Core
//   - The commands used for doing this can be found in the folder 'Executed Commands'
//   - The testroutine uses methods from classes that were generated
// Created
//   - CopyPaste – 20230711 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230711 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.BusinessObjects;
using CopyPaste.DataAccess;
using CopyPaste.Toolkit;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ForwardEngineerDatabase
{

  class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Testroutine for the generated database, to prove that it works
    //   - Show a start heading
    //   - Create a cpWingsContext
    //   - Delete the database if it already exists
    //   - Create the database
    //   - Push some data towards the database
    //   - Read some data from the database
    //   - Create some more test data
    //   - Cleaning up the cpWingsContext
    //   - Show an end heading
    //   - Wait for user action
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintSuccess(string)
    //   - cpDataGeneration.CreateTestData(cpWingsContext)
    //   - cpWingsContext()
    //   - Passenger()
    //   - Passenger.GivenName(string) (Set)
    //   - Passenger.Surname(string) (Set)
    //   - int Passenger.PersonId() (Get)
    //   - string Passenger.GivenName() (Get)
    //   - string Passenger.Surname() (Get)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnIsCreated;
      int intNumberOfBookings;
      int intNumberOfFlights;
      int intNumberOfPassengers;
      int intNumberOfPilots;

      List<Passenger> lstPassenger;

      cpConsole.PrintMainHeadLine("Start ...");

      using (cpWingsContext theContext = new cpWingsContext())
      {
        // Delete the database thru the context if it already exists
        cpConsole.PrintMainHeadLine("Delete Database");
        theContext.Database.EnsureDeleted();

        // Create a new database thru the context
        cpConsole.PrintMainHeadLine("Create Database");
        blnIsCreated = theContext.Database.EnsureCreated();

        if (blnIsCreated)
        {
          cpConsole.PrintSuccess("Database is created");

          // Create a new Passenger (just one to prove it works)
          Passenger newPassenger = new Passenger();
          newPassenger.GivenName = "Gertrude";
          newPassenger.Surname = "Gryson";

          theContext.Passenger.Add(newPassenger);
          int intCounter = theContext.SaveChanges();

          cpConsole.PrintMainHeadLine("There are some changes");
          cpConsole.Print($"Number of changes: {intCounter}");
          cpConsole.PrintMainHeadLine("Count all Passengers");

          lstPassenger = theContext.Passenger.Select(aPassenger => aPassenger).ToList();
          cpConsole.Print($"Number of Passengers: {lstPassenger.Count}");

          cpConsole.PrintMainHeadLine("Show all Passengers with name 'Gryson'");

          foreach (Passenger thePassenger in lstPassenger.Where(aPassenger => aPassenger.Surname == "Gryson"))
          {
            cpConsole.Print($"{thePassenger.PersonId}: {thePassenger.Surname}, {thePassenger.GivenName}");
          }
          // lstPassenger.Where(aPassenger => aPassenger.Surname == "Gryson")

          // Create a lot of data randomly (to fill the database)
          cpDataGeneration.CreateTestData(theContext);

          cpConsole.PrintMainHeadLine("Count all Pilots");
          intNumberOfPilots = theContext.Pilot.Count();
          cpConsole.Print($"Number of Pilots: {intNumberOfPilots}");
          cpConsole.PrintMainHeadLine("Count all Passengers");
          intNumberOfPassengers = theContext.Passenger.Count();
          cpConsole.Print($"Number of Passengers: {intNumberOfPassengers}");
          cpConsole.PrintMainHeadLine("Count all Flights");
          intNumberOfFlights = theContext.Flight.Count();
          cpConsole.Print($"Number of Flights: {intNumberOfFlights}");
          cpConsole.PrintMainHeadLine("Count all Bookings");
          intNumberOfBookings = theContext.Booking.Count();
          cpConsole.Print($"Number of Bookings: {intNumberOfBookings}");
        }
        else
        // Not blnIsCreated
        {
        }
        // blnIsCreated

      }
      // cpWingsContext

      cpConsole.PrintMainHeadLine("... Done");

      Console.WriteLine("Hit any key ...");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// ForwardEngineerDatabase