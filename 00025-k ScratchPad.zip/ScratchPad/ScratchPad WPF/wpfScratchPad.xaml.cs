﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ScatchPad_WPF
{

  public partial class wpfScratchPad : Window
  {

    #region "Constructors / Destructors"

    public wpfScratchPad()
    //***
    // Action
    //   - Create instance of 'wpfScratchPad'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230526 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230526 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfScratchPad()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void mnuFileNew_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Clear (make blanc) the richtext textbox
    // Called by
    //   - User action (Clicking a menuitem)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230525 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20230525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      rtxtText.Document.Blocks.Clear();
    }
    // mnuFileNew_Click(System.Object, System.Windows.RoutedEventArgs) Handles mnuFileNew.Click

    private void mnuFileOpen_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Prepare and show a FileOpen dialogbox
    //   - strFileName becomes the FileOpen dialogbox FileName
    //   - If strFilename was filled in
    //     - Determine 4 positions for the extension
    //       - The range is determined
    //       - The filestream is defined
    //     - If extension is ".TXT"
    //       - The textfile is loaded
    //     - If Not
    //       - The rtffile is loaded
    //     - Load the content of the file (strFileName) into the richtext textbox
    //     - The filestream is closed
    //   - If Not
    //     - Do nothing
    // Called by
    //   - User action (Clicking a menuitem)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230525 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20230525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      FileStream theFileStream;
      OpenFileDialog dlgFileOpen = new OpenFileDialog();
      string strFileName;
      string strSub;
      TextRange theRange;

      dlgFileOpen.DefaultExt = "*.rtf";
      dlgFileOpen.Filter = "RichText Files|*.rtf|Text Files|*.txt";
      dlgFileOpen.ShowDialog();
      strFileName = dlgFileOpen.FileName;

      if (strFileName.Length > 0)
      {
        strSub = strFileName.Substring(strFileName.Length - 4, 4);
        theRange = new TextRange(rtxtText.Document.ContentStart, rtxtText.Document.ContentEnd);
        theFileStream = new FileStream(strFileName, FileMode.Open);

        if (strSub.ToUpper() == ".TXT")
        {
          theRange.Load(theFileStream, DataFormats.Text);
        }
        else
        // strSub.ToUpper() <> ".TXT"
        {
          theRange.Load(theFileStream, DataFormats.Rtf);
        }
        // strSub.ToUpper() = ".TXT"

        theFileStream.Close();
      }
      else
      // strFileName.Length <= 0
      {
      }
      // strFileName.Length > 0

    }
    // mnuFileOpen_Click(System.Object, System.Windows.RoutedEventArgs) Handles mnuFileOpen.Click

    private void mnuFileQuit_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - End the program
    // Called by
    //   - User action (Clicking a menuitem)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230525 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20230525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.Close();
    }
    // mnuFileQuit_Click(System.Object, System.Windows.RoutedEventArgs) Handles mnuFileQuit.Click

    private void mnuFileSave_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Prepare and show a FileSave dialogbox
    //   - strFileName becomes the FileSave dialogbox FileName
    //   - If strFilename was filled in
    //     - Determine 4 positions for the extension
    //       - The range is determined
    //       - The filestream is defined
    //     - If extension is ".TXT"
    //       - The textfile is loaded
    //     - If Not
    //       - The rtffile is loaded
    //     - Load the content of the file (strFileName) into the richtext textbox
    //     - The filestream is closed
    //   - If Not
    //     - Do nothing
    // Called by
    //   - User action (Clicking a menuitem)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230525 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20230525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      FileStream theFileStream;
      SaveFileDialog dlgFileSave = new SaveFileDialog();
      string strFileName;
      string strSub;
      TextRange theRange;

      dlgFileSave.DefaultExt = "*.rtf";
      dlgFileSave.Filter = "RichText Files|*.rtf|Text Files|*.txt";
      dlgFileSave.ShowDialog();
      strFileName = dlgFileSave.FileName;

      if (strFileName.Length > 0)
      {
        strSub = strFileName.Substring(strFileName.Length - 4, 4);
        theRange = new TextRange(rtxtText.Document.ContentStart, rtxtText.Document.ContentEnd);
        theFileStream = new FileStream(strFileName, FileMode.Open);

        if (strSub.ToUpper() == ".TXT")
        {
          theRange.Save(theFileStream, DataFormats.Text);
        }
        else
        // strSub.ToUpper() <> ".TXT"
        {
          theRange.Save(theFileStream, DataFormats.Rtf);
        }
        // strSub.ToUpper() = ".TXT"

        theFileStream.Close();
      }
      else
      // strFileName.Length <= 0
      {
      }
      // strFileName.Length > 0

    }
    // mnuFileSave_Click(System.Object, System.Windows.RoutedEventArgs) Handles mnuFileSave.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }

}
