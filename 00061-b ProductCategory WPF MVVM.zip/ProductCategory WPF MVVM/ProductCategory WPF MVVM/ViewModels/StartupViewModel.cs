﻿//***
// Action
//   - StartupViewModel class (in ViewModels)
// Created
//   - CopyPaste – 20220824 – VVDW
// Changed
//   - CopyPaste – 20220907 – VVDW – Used the Service for getting the data
//   - CopyPaste – 20220908 – VVDW – Add ProductCategoryViewModel to be used in the DataContext property of the xamls
// Tested
//   - CopyPaste – 20220824 – VVDW
// Proposal (To Do)
//   -
//***

using ProductCategory_WPF_MVVM.Services;
using ProductCategory_WPF_MVVM.Utilities;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProductCategory_WPF_MVVM.ViewModels
{

  public class StartupViewModel : ObservableObject
  {

    #region "Constructors / Destructors"

    public StartupViewModel()
    //***
    // Action
    //   - Create an instance of "StartupViewModel"
    //   - Assign a new MockDataService
    //   - Create a new instance of Product Category View Model with a DataService
    // Called by
    //   - 
    // Calls
    //   -  MockDataService()
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - The MockDataService will later change into the real DataService
    //***
    {
      _dataService = new MockDataService();
      ProductCategoryVWM = new ProductCategoryViewModel(_dataService);
    }
    // StartupViewModel()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private IDataService _dataService;
    private ProductCategoryViewModel _vwmProductCategory;

    #endregion

    #region "Properties"

    public ProductCategoryViewModel ProductCategoryVWM
    {

      get
      //***
      // Action Get
      //   - Return _vwmProductCategory
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220908 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220908 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _vwmProductCategory;
      }
      // ProductCategoryViewModel ProductCategoryVWM

      set
      //***
      // Action Set
      //   - Sets _vwmProductCategory with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - 
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220908 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220908 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        OnPropertyChanged(ref _vwmProductCategory, value);
      }
      // ProductCategoryVWM(ProductCategoryViewModel) (Set)

    }
    // ProductCategoryViewModel ProductCategoryVWM

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // StartupViewModel

}
// ProductCategory_WPF_MVVM.ViewModels