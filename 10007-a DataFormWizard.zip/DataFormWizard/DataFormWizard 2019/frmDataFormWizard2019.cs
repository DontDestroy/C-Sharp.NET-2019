﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataFormWizard_2019
{
  public partial class frmDataFormWizard2019 : Form
  {
    public frmDataFormWizard2019()
    {
      InitializeComponent();
    }

    private void tblCPCategoryBindingNavigatorSaveItem_Click(object sender, EventArgs e)
    {
      this.Validate();
      this.tblCPCategoryBindingSource.EndEdit();
      this.tableAdapterManager.UpdateAll(this.dsData);

    }

    private void frmDataWizard2019_Load(object sender, EventArgs e)
    {
      // TODO: This line of code loads data into the 'dsData.tblCPProduct' table. You can move, or remove it, as needed.
      this.tblCPProductTableAdapter.Fill(this.dsData.tblCPProduct);
      // TODO: This line of code loads data into the 'dsData.tblCPCategory' table. You can move, or remove it, as needed.
      this.tblCPCategoryTableAdapter.Fill(this.dsData.tblCPCategory);

    }
  }
}
