//***
// Action
//   - Test routine for cpBankAccount, cpCheckingAccount and cpSavingsAccount
// Created
//   - CopyPaste � 20240221 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240221 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTheBank: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdAddInterest;
    internal System.Windows.Forms.Button cmdSubmit;
    internal System.Windows.Forms.ComboBox cmbAmount;
    internal System.Windows.Forms.Label lblAmount;
    internal System.Windows.Forms.ComboBox cmbAction;
    internal System.Windows.Forms.Label lblAction;
    internal System.Windows.Forms.ComboBox cmbAccount;
    internal System.Windows.Forms.Label lblAccount;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTheBank));
      this.cmdAddInterest = new System.Windows.Forms.Button();
      this.cmdSubmit = new System.Windows.Forms.Button();
      this.cmbAmount = new System.Windows.Forms.ComboBox();
      this.lblAmount = new System.Windows.Forms.Label();
      this.cmbAction = new System.Windows.Forms.ComboBox();
      this.lblAction = new System.Windows.Forms.Label();
      this.cmbAccount = new System.Windows.Forms.ComboBox();
      this.lblAccount = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdAddInterest
      // 
      this.cmdAddInterest.Location = new System.Drawing.Point(128, 176);
      this.cmdAddInterest.Name = "cmdAddInterest";
      this.cmdAddInterest.TabIndex = 15;
      this.cmdAddInterest.Text = "Add interest";
      this.cmdAddInterest.Visible = false;
      this.cmdAddInterest.Click += new System.EventHandler(this.cmdAddInterest_Click);
      // 
      // cmdSubmit
      // 
      this.cmdSubmit.Location = new System.Drawing.Point(16, 176);
      this.cmdSubmit.Name = "cmdSubmit";
      this.cmdSubmit.TabIndex = 14;
      this.cmdSubmit.Text = "Submit";
      this.cmdSubmit.Click += new System.EventHandler(this.cmdSubmit_Click);
      // 
      // cmbAmount
      // 
      this.cmbAmount.DropDownWidth = 248;
      this.cmbAmount.Location = new System.Drawing.Point(128, 128);
      this.cmbAmount.Name = "cmbAmount";
      this.cmbAmount.Size = new System.Drawing.Size(248, 21);
      this.cmbAmount.TabIndex = 13;
      // 
      // lblAmount
      // 
      this.lblAmount.Location = new System.Drawing.Point(16, 128);
      this.lblAmount.Name = "lblAmount";
      this.lblAmount.TabIndex = 12;
      this.lblAmount.Text = "Amount";
      // 
      // cmbAction
      // 
      this.cmbAction.DropDownWidth = 248;
      this.cmbAction.Items.AddRange(new object[] {
                                                   "Deposit",
                                                   "Withdraw"});
      this.cmbAction.Location = new System.Drawing.Point(128, 80);
      this.cmbAction.Name = "cmbAction";
      this.cmbAction.Size = new System.Drawing.Size(248, 21);
      this.cmbAction.TabIndex = 11;
      // 
      // lblAction
      // 
      this.lblAction.Location = new System.Drawing.Point(16, 80);
      this.lblAction.Name = "lblAction";
      this.lblAction.TabIndex = 10;
      this.lblAction.Text = "Action";
      // 
      // cmbAccount
      // 
      this.cmbAccount.DropDownWidth = 248;
      this.cmbAccount.Location = new System.Drawing.Point(128, 24);
      this.cmbAccount.Name = "cmbAccount";
      this.cmbAccount.Size = new System.Drawing.Size(248, 21);
      this.cmbAccount.TabIndex = 9;
      this.cmbAccount.SelectedIndexChanged += new System.EventHandler(this.cmbAccount_SelectedIndexChanged);
      // 
      // lblAccount
      // 
      this.lblAccount.Location = new System.Drawing.Point(16, 24);
      this.lblAccount.Name = "lblAccount";
      this.lblAccount.TabIndex = 8;
      this.lblAccount.Text = "Account";
      // 
      // frmTheBank
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(392, 222);
      this.Controls.Add(this.cmdAddInterest);
      this.Controls.Add(this.cmdSubmit);
      this.Controls.Add(this.cmbAmount);
      this.Controls.Add(this.lblAmount);
      this.Controls.Add(this.cmbAction);
      this.Controls.Add(this.lblAction);
      this.Controls.Add(this.cmbAccount);
      this.Controls.Add(this.lblAccount);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTheBank";
      this.Text = "The Bank";
      this.Load += new System.EventHandler(this.frmTheBank_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTheBank'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTheBank()
      //***
      // Action
      //   - Create instance of 'frmTheBank'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTheBank()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpCheckingAccount mcpCheckingAccount = new cpCheckingAccount("Vincent");
    private cpSavingsAccount mcpSavingsAccount = new cpSavingsAccount("Vincent");

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmbAccount_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If the selected account is a cpSavingsAccount
      //     - cmdAddInterest button is visible
      //   - If Not
      //     - cmdAddInterest button is not visible
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (cmbAccount.SelectedItem is cpSavingsAccount)
      {
        cmdAddInterest.Visible = true;
      }
      else
        // Not cmbAccount.SelectedItem is cpSavingsAccount
      {
        cmdAddInterest.Visible = false;
      }
      // cmbAccount.SelectedItem is cpSavingsAccount
    
    }
    // cmbAccount_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbAccount.SelectedIndexChanged
  
    private void cmdAddInterest_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If the selected account is a cpSavingsAccount
      //     - The selected account is casted as a cpSavingsAccount
      //     - Some interest is added
      //     - Information about the cpSavingsAccount is shown
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpSavingsAccount.AddInterest()
      //   - decimal cpBankAccount.Balance (Get)
      //   - string cpBankAccount.Id (Get)
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      
      if (cmbAccount.SelectedItem is cpSavingsAccount)
      {
        cpSavingsAccount theSavings = cmbAccount.SelectedItem as cpSavingsAccount;
        // cpSavingsAccount theSavings = (cpSavingsAccount)cmbAccount.SelectedItem;
        // Fails if is was unsuccessful
        // try ... catch is needed
        
        if (theSavings == null)
        {
        }
        else
          // theSavings <> null
        {
          theSavings.AddInterest();
          MessageBox.Show(String.Format("{0} has {1:C} on the account.", theSavings.Id, theSavings.Balance));
        }
        // theSavings = null

      }
      else
        // Not cmbAccount.SelectedItem is cpSavingsAccount
      {
      }
      // cmbAccount.SelectedItem is cpSavingsAccount 
    
    }
    // cmdAddInterest_Click(System.Object, System.EventArgs) Handles cmdAddInterest.Click

    private void cmdSubmit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The selected account is defined as an object
      //   - The object is casted to a cpBankAccount
      //     - It can be a checkingaccount or a savingsaccount
      //   - Depending on the choosen action
      //     - A deposit is done
      //     - A withdraw is done
      //   - A messagebox is show with the information of the selected account
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpBankAccount.Deposit(decimal)
      //   - cpBankAccount.WithDraw(decimal)
      //   - decimal cpBankAccount.Balance (Get)
      //   - string cpBankAccount.Id (Get)
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpBankAccount aSelectedAccount;
      System.Object theItem = cmbAccount.SelectedItem;
      
      aSelectedAccount = (cpBankAccount)theItem;
      
      switch (cmbAction.Text)
      {              
        case "Deposit":
          aSelectedAccount.Deposit(Decimal.Parse(cmbAmount.Text));
          break;
        case "Withdraw":
          aSelectedAccount.Withdraw(Decimal.Parse(cmbAmount.Text));
          break;
      }
      // cmbAction.Text

      MessageBox.Show(String.Format("{0} has {1:C} on the account.", aSelectedAccount.Id, aSelectedAccount.Balance));
    }
    // cmdSubmit_Click(System.Object, System.EventArgs) Handles cmdSubmit.Click

    private void frmTheBank_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - A checkingaccount is added to cmbAccount
      //   - A savingsaccount is added to cmbAccount
      //   - The checkingaccount is selected
      //   - The first action is selected
      //   - Add the values 100, 150 and 200 to the cmbAmount
      //   - First value (100) is selected
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cmbAccount.Items.Add(mcpCheckingAccount);
      cmbAccount.Items.Add(mcpSavingsAccount);
      cmbAccount.SelectedIndex = 0;
      cmbAction.SelectedIndex = 0;
      cmbAmount.Items.Add("100");
      cmbAmount.Items.Add("150");
      cmbAmount.Items.Add("200");
      cmbAmount.SelectedIndex = 0;    
    }
    // frmTheBank_Load(System.Object, System.EventArgs) Handles frmTheBank.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTheBank
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTheBank());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTheBank

}
// CopyPaste.Learning