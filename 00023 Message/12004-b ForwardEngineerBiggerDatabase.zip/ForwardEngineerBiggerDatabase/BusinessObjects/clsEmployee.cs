﻿//***
// Action
//   - Definition of a Employee
// Created
//   - CopyPaste – 20230714 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230714 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Text;

namespace CopyPaste.BusinessObjects
{

  public class Employee : Person
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string _PassportNumber;

    #endregion

    #region "Properties"

    // Missing Primary Key, see OnModelCreating for solution

    public DateTime? HireDate;

    // This property does not have a set in the property, it has a set method instead
    // This property becomes not a column in the table Employee
    public string PassportNumber => this._PassportNumber;

    public float Salary { get; set; }

    // A relation towards entity class Employee (the one part)
    // This property is a reference to an instance of the same class
    // This property becomes a column in the table Employee
    // Look at the generated field (SupervisorPersonId) and relation in the database 
    public Employee Supervisor { get; set; }

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void SetPassportNumber(string strPassportNumber)
    //***
    // Action
    //   - Set the _PassportNumber
    //   - This is on purpose not a set in the Property PassportNumber
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230714 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      _PassportNumber = strPassportNumber;
    }
    // SetPassportNumber(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Employee

}
// CopyPaste.BusinessObjects 