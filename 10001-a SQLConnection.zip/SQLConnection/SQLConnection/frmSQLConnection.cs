//***
// Action
//   - A SQL Connection by code
//   - A SQL Command by code
// Created
//   - CopyPaste � 20250724 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250724 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSQLConnection: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdGetData;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSQLConnection));
      this.cmdGetData = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdGetData
      // 
      this.cmdGetData.Location = new System.Drawing.Point(24, 22);
      this.cmdGetData.Name = "cmdGetData";
      this.cmdGetData.Size = new System.Drawing.Size(232, 48);
      this.cmdGetData.TabIndex = 1;
      this.cmdGetData.Text = "&Get Data";
      this.cmdGetData.Click += new System.EventHandler(this.cmdGetData_Click);
      // 
      // frmSQLConnection
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(280, 93);
      this.Controls.Add(this.cmdGetData);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSQLConnection";
      this.Text = "SQL Connection";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSQLConnection'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250724 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250724 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSQLConnection()
      //***
      // Action
      //   - Create instance of 'frmSQLConnection'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250724 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250724 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSQLConnection()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdGetData_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a new connection
      //   - Define a new command
      //   - Define a sql data reader
      //   - Set the correct connection string
      //   - Open the connection
      //   - Assign the connection to the command
      //   - Set a command text (SQL statement) to the command
      //   - Execute the reader (meaning, execute the command and set the result in a data reader
      //   - Loop thru all the records
      //     - Show information about the record
      //   - Show a messagebox that you are ready
      //   - Close the data reader
      //   - Close the connection
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250724 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250724 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      SqlCommand cmmSQL = new SqlCommand();
      SqlConnection cnnSQL = new SqlConnection();
      SqlDataReader drdSQL;

      cnnSQL.ConnectionString = "Data Source=COPYPASTEPOWER\\COPYPASTE;Initial Catalog=cpNorthWindScript2019;Integrated Security=True";
      cnnSQL.Open();
      cmmSQL.Connection = cnnSQL;
      cmmSQL.CommandText = "SELECT strIdCustomer, strCompanyName FROM tblCPCustomer";
      drdSQL = cmmSQL.ExecuteReader();
      Console.WriteLine("---------");

      while (drdSQL.Read())
      {
        Console.WriteLine("\t{0}\t{1}", drdSQL[0].ToString(), drdSQL.GetString(1));
      }
      // Not drdSQL.Read()

      MessageBox.Show("Ready", "Copy Paste");
      drdSQL.Close();
      cnnSQL.Close();
    }
    // cmdGetData_Click(System.Object, System.EventArgs) Handles cmdGetData.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSQLConnection
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSQLConnection()
      // Created
      //   - CopyPaste � 20250724 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250724 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSQLConnection());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSQLConnection

}
// CopyPaste.Learning