﻿//***
// Action
//   - Define a format for a keyword
// Created
//   - CopyPaste – 20250721 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250721 – VVDW
// Proposal (To Do)
//   -
//***

using System.Drawing;

namespace CopyPaste.Learning.UserInterface
{

  public class cpKeyWordFormat
  {

    #region "Constructors / Destructors"

    public cpKeyWordFormat(Color theColor) : this(theColor, null)
      //***
      // Action
      //   - Constructor setting the color
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - cpKeyWordFormat(Color, Font)
      // Created
      //   - CopyPaste – 20250721 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250721 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpKeyWordFormat(Color)

    public cpKeyWordFormat(Font theFont) : this(Color.Empty, theFont)
      //***
      // Action
      //   - Constructor setting the font
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - cpKeyWordFormat(Color, Font)
      // Created
      //   - CopyPaste – 20250721 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250721 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpKeyWordFormat(Color)

    public cpKeyWordFormat(Color theColor, Font theFont)
      //***
      // Action
      //   - Constructor setting the color and the font
      // Called by
      //   - cpKeyWordFormat(Color)
      //   - cpKeyWordFormat(Font)
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250721 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250721 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Color = theColor;
      this.Font = theFont;
    }
    // cpKeyWordFormat(Color, Font)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    private Color mclrKey;
    private Font mfntKey;

    #endregion

    #region "Properties"

    public Color Color
    {

      get
        //***
        // Action Get
        //   - Return mclrKey
        // Called by
        //   - cpctlRichTextBoxKeyWord.SetWordAttributes(int, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20250721 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250721 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mclrKey;
      }
      // Color Color (Get)

      set
        //***
        // Action Set
        //   - mclrKey becomes value
        // Called by
        //   - cpKeyWordFormat(Color, Font)
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20250721 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250721 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mclrKey = value;
      }
      // Color(Color) (Set)

    }
    // Color Color

    public Font Font
    {

      get
        //***
        // Action Get
        //   - Return mfntKey
        // Called by
        //   - cpctlRichTextBoxKeyWord.SetWordAttributes(Int32, Int32)
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20250721 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250721 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mfntKey;
      }
      // Font Font (Get)

      set
        //***
        // Action Set
        //   - mfntKey becomes value
        // Called by
        //   - cpKeyWordFormat(Color, Font)
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20250721 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250721 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mfntKey = value;
      }
      // Font(Font) (Set)

    }
    // Font Font

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
		//#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpKeyWordFormat

}
// CopyPaste.Learning.UserInterface