//***
// Action
//   - Testroutine for cpEmployee
// Created
//   - CopyPaste � 20230614 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230614 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThread]
    static void Main()
      //***
      // Action
      //   - Create a new employee theBoss
      //   - Assign the name thru a public variable
      //   - Assign the offuce number thru a public variable
      //   - Assign the age thru a public method
      //   - Assign the phone thru a public method
      //   - Show information of theBoss
      // Called by
      //   - 
      // Calls
      //   - cpEmployee.AssignAge(int)
      //   - cpEmployee.AssignHomePhone(string)
      //   - cpEmployee.ShowEmployee()
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpEmployee theBoss = new cpEmployee();

      theBoss.mstrName = "Jane Doe";
      theBoss.mstrOfficeNumber = "123A";
      theBoss.AssignAge(35);
      theBoss.AssignHomePhone("555-1212");

      theBoss.ShowEmployee();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// CopyPaste.Learning