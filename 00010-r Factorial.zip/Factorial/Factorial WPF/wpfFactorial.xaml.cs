﻿//***
// Action
//   - 
// Created
//   - CopyPaste – 20220813 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220813 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Factorial_WPF
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class wpfFactorial : Window
  {

    #region "Constructors / Destructors"

    public wpfFactorial()
    //***
    // Action
    //   - Create instance of 'wpfFactorial'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220813 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220813 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfFactorial()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCalculate_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Loop from 0 to 'lngValue' (lngCounter)
    //     - Calculate factorial of 'lngCounter'
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - string Environment.NewLine()
    // Created
    //   - CopyPaste – 20220813 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220813 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter;
      long lngValue = Convert.ToInt64(txtInput.Text);

      txtDisplay.Text = "";

      for (lngCounter = 0; lngCounter <= lngValue; lngCounter++)
      {
        txtDisplay.Text += lngCounter + "! = " + Factorial(lngCounter) + Environment.NewLine;
      }
      // lngCounter = lngValue + 1

    }
    // cmdCalculate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCalculate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private long Factorial(long lngNumber)
    //***
    // Action
    //   - Recursively generates factorial of number
    // Called by
    //   - Factorial(Int64) 
    // Calls
    //   - cmdCalculate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCalculate.Click
    //   - long Factorial(long)
    // Created
    //    - CopyPaste – 20220813 – VVDW
    // Changed
    //    - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //    - CopyPaste – 20220813 – VVDW
    // Keyboard key
    //    -
    // Proposal (To Do)
    //    -
    //***
    {

      if (lngNumber <= 1)
      {
        return 1;
      }
      else
      // lngNumber > 1
      {
        return lngNumber * Factorial(lngNumber - 1);
      }
      // lngNumber <= 1

    }
    // long Factorial(long) 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfFactorial

}
// Factorial_WPF