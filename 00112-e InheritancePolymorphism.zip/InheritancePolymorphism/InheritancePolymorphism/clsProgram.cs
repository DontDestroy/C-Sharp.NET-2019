//***
// Action
//   - Testroutine for cpEmployee, cpHandWorker, cpOfficeWorker, cpManager and cpDirector
// Created
//   - CopyPaste � 20240405 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240405 � VVDW
// Proposal (To Do)
//   - Not all getters and setters are tested, but the usual stuff is
//   - Pay attention, the result of the testroutine will be different if you do the extra exercises
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Instantiation of a cpEmployee
      //   - Instantiation of a cpHandWorker
      //   - Instantiation of a cpManager
      //   - Instantiation of a cpOfficeWorker
      //   - Instantiation of a cpDirector
      //   - Add them all in an array
      //   - Loop the array
      //     - Show information of a cpEmployee using ShowInfo
      //     - Show information of a cpEmployee using ToString
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpDirector.New(String, String)
      //   - cpDirector.ShowInfo()
      //   - cpDirector.ToString() As String
      //   - cpEmployee.New(String, String)
      //   - cpEmployee.ShowInfo()
      //   - cpEmployee.ToString() As String
      //   - cpHandWorker.New(String, String)
      //   - cpHandWorker.ShowInfo()
      //   - cpHandWorker.ToString() As String
      //   - cpManager.New(String, String)
      //   - cpManager.ShowInfo()
      //   - cpManager.ToString() As String
      //   - cpOfficeWorker.New(String, String)
      //   - cpOfficeWorker.ShowInfo()
      //   - cpOfficeWorker.ToString() As String
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpEmployee[] arrcpEmployee = new cpEmployee[5];

      arrcpEmployee[0] = new cpEmployee("Alfons", "Transport");
      arrcpEmployee[1] = new cpHandWorker("Xavier", "Production");
      arrcpEmployee[2] = new cpOfficeWorker("Hilde", "Human Resources");
      arrcpEmployee[3] = new cpManager("Vincent", "Finance");
      arrcpEmployee[4] = new cpDirector("Gertrude", "General");

      foreach (cpEmployee thecpEmployee in arrcpEmployee)
      {
        thecpEmployee.ShowInfo();
        Console.WriteLine(thecpEmployee.ToString());
      }
      // in arrcpEmployee

      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning.Employee