//***
// Action
//   - Demo of anchoring controls
// Created
//   - CopyPaste � 20240227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240227 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmAnchor: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.Button cmdClear;
    internal System.Windows.Forms.TextBox txtRoadDescription;
    internal System.Windows.Forms.Label Label1;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmAnchor));
      this.cmdExit = new System.Windows.Forms.Button();
      this.cmdClear = new System.Windows.Forms.Button();
      this.txtRoadDescription = new System.Windows.Forms.TextBox();
      this.Label1 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdExit
      // 
      this.cmdExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdExit.Location = new System.Drawing.Point(407, 127);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.TabIndex = 7;
      this.cmdExit.Text = "Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // cmdClear
      // 
      this.cmdClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdClear.Location = new System.Drawing.Point(327, 127);
      this.cmdClear.Name = "cmdClear";
      this.cmdClear.TabIndex = 6;
      this.cmdClear.Text = "Clear";
      this.cmdClear.Click += new System.EventHandler(this.cmdClear_Click);
      // 
      // txtRoadDescription
      // 
      this.txtRoadDescription.AcceptsReturn = true;
      this.txtRoadDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.txtRoadDescription.Location = new System.Drawing.Point(7, 39);
      this.txtRoadDescription.Multiline = true;
      this.txtRoadDescription.Name = "txtRoadDescription";
      this.txtRoadDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtRoadDescription.Size = new System.Drawing.Size(472, 80);
      this.txtRoadDescription.TabIndex = 5;
      this.txtRoadDescription.Text = "";
      // 
      // Label1
      // 
      this.Label1.Location = new System.Drawing.Point(7, 7);
      this.Label1.Name = "Label1";
      this.Label1.Size = new System.Drawing.Size(472, 23);
      this.Label1.TabIndex = 4;
      this.Label1.Text = "Type here the roaddescription to your home:";
      // 
      // frmAnchor
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(488, 157);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.cmdClear);
      this.Controls.Add(this.txtRoadDescription);
      this.Controls.Add(this.Label1);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmAnchor";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Anchoring";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmAnchor'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmAnchor()
      //***
      // Action
      //   - Create instance of 'frmAnchor'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmAnchor()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdClear_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Erase the text that was typed in the textbox
      // Called by
      //   - User action (Clicking on button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtRoadDescription.Clear();
    }
    // cmdClear_Click(System.Object, System.EventArgs) Handling cmdClear.Click

    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop the program
      // Called by
      //   - User action (Clicking on button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handling cmdExit.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmAnchor
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmAnchor());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmAnchor

}
// CopyPaste.Learning