//***
// Action
//   - Compare two numbers
// Created
//   - CopyPaste � 20210823 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20080501 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace Comparison
{

  class cpComparison
	{

		static void Main()
    //***
    // Action
    //   - Show messages, depending on the comparison of two numbers
    //   - Compare equal
    //   - Compare different
    //   - Compare smaller
    //   - Compare bigger
    //   - Compare smaller or equal
    //   - Compare bigger or equal
    // Called by
    //   - User action (Starting the program)
    // Calls
    //   - System.Console.ReadLine()
    //   - System.Console.Write(string)
    //   - System.Console.WriteLine(string, System.Object, System.Object)
    //   - System.Convert.ToInt64(System.Object)
    // Created
    //   - CopyPaste � 20210823 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210823 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      long lngNumber1;
      long lngNumber2;

      Console.Write("Please enter first integer: ");
      lngNumber1 = Convert.ToInt64(Console.ReadLine());
      
      Console.Write("Please enter second integer: ");
      lngNumber2 = Convert.ToInt64(Console.ReadLine());
      
      if (lngNumber1 == lngNumber2)
      {
        Console.WriteLine("{0} = {1}", lngNumber1, lngNumber2);
      }
      else
        // (lngNumber1 != lngNumber2)
      {
      }
      // (lngNumber1 == lngNumber2)

      if (lngNumber1 != lngNumber2)
      {
        Console.WriteLine("{0} <> {1}", lngNumber1, lngNumber2);
      }
      else
        // (lngNumber1 = lngNumber2) 
      {
      }
      // (lngNumber1 <> lngNumber2) 

      if (lngNumber1 < lngNumber2)
      {
        Console.WriteLine("{0} < {1}", lngNumber1, lngNumber2);
      }
      else
        // (lngNumber1 >= lngNumber2)
      {
      }
      // (lngNumber1 < lngNumber2) 

      if (lngNumber1 > lngNumber2)
      {
        Console.WriteLine("{0} > {1}", lngNumber1, lngNumber2);
      }
      else
        // (lngNumber1 <= lngNumber2) 
      {
      }
      // (lngNumber1 > lngNumber2) 

      if (lngNumber1 <= lngNumber2)
      {
        Console.WriteLine("{0} <= {1}", lngNumber1, lngNumber2);
      }
      else
        // (lngNumber1 > lngNumber2) 
      {
      }
      // (lngNumber1 <= lngNumber2) 
      
      if (lngNumber1 >= lngNumber2)
      {
        Console.WriteLine("{0} >= {1}", lngNumber1, lngNumber2);
      }
      else
        // (lngNumber1 < lngNumber2) 
      {
      }      
      // (lngNumber1 >= lngNumber2) 
      
      Console.ReadLine();
		}
    // Main()

  }
  // cpComparison

}
// Comparison