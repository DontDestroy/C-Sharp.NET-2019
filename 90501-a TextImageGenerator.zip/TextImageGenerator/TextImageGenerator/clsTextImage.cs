﻿//***
// Action
//   - Definition of a cpTextImage
// Created
//   - CopyPaste – 20260805 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260805 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Web;

namespace CopyPaste.Toolkit.UserInterface
{

  public class cpTextImage
  {

    #region "Constructors / Destructors"

    public cpTextImage(int intLeft, int intTop)
    //***
    // Action
    //   - Set the Left and Top properties to the given values of the constructor
    // Called by
    //   - cpPictureBoxWithText(int, int)
    //   - frmExample.frmExample_Load(System.Object, System.EventArgs) Handles this.Load
    //   - wfrmExample.Page_Load(System.Object, System.EventArgs) Handles this.Load
    // Calls
    //   - Left(int) (Set)
    //   - Top(int) (Set)
    // Created
    //   - CopyPaste – 20260805 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260805 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Left = intLeft;
      Top = intTop;
    }
    // cpTextImage(int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

      private Bitmap mbitText;
      private int mintLeft;
      private int mintTop;

    #endregion

    #region "Properties"

    public Bitmap Image
    {

      get
      //***
      // Action Get
      //   - Return the value of mbitText
      // Called by
      //   - WriteTo(HttpResponse, Imaging.ImageFormat)
      //   - WriteTo(String, System.Drawing.Imaging.ImageFormat)
      //   - WriteTo(System.IO.Stream, System.Drawing.Imaging.ImageFormat)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260805 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260805 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return mbitText;
      }
      // Bitmap Image (Get)

      set
      //***
      // Action Set
      //   - mbitText becomes value
      // Called by
      //   - cpPictureBoxWithText.DrawImage(int, int, Color, Color)
      //   - DrawImage(int, int, Color, Color)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260805 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260805 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        mbitText = value;
      }
      // Image(Bitmap) (Set)

    }
    // Bitmap Image

    public int Left
    {

      get
      //***
      // Action Get
      //   - Return the value of mintLeft
      // Called by
      //   - cpPictureBoxWithText.DrawImage(int, int, Color, Color)
      //   - DrawImage(int, int, Color, Color)
      //   - DrawTextOnImage(string, Color, int, int, string, int)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260805 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260805 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return mintLeft;
      }
      // int Left (Get)

      set
      //***
      // Action Set
      //   - If value is negative
      //     - mintLeft becomes 0
      //   - If not
      //     - mintLeft becomes value
      // Called by
      //   - cpTextImage(int, int)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260805 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260805 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if (value < 0)
        {
          mintLeft = 0;
        }
        else
          // value >= 0
        {
          mintLeft = value;
        }
        // value < 0

      }
      // Left(int) (Set)

    }
    // int Left

    public int Top
    {

      get
      //***
      // Action Get
      //   - Return the value of mintTop
      // Called by
      //   - cpPictureBoxWithText.DrawImage(int, int, Color, Color)
      //   - DrawImage(int, int, Color, Color)
      //   - DrawTextOnImage(string, Color, int, int, string, int)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260805 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260805 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return mintTop;
      }
      // int Top (Get)

      set
      //***
      // Action Set
      //   - If value is negative
      //     - mintTop becomes 0
      //   - If not
      //     - mintTop becomes value
      // Called by
      //   - cpTextImage(int, int)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260805 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260805 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if (value < 0)
        {
          mintTop = 0;
        }
        else
          // value >= 0
        {
          mintTop = value;
        }
        // value < 0

      }
      // Top(int) (Set)

    }
    // int Top

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public virtual void DrawImage(int intImageWidth, int intImageHeight, Color clrImageFore, Color clrImageBack)
    //***
    // Action
    //   - Define a bitmap
    //   - Define a brush
    //   - Define a drawing graphics
    //   - Define a pen
    //   - Initialize a new bitmap with a left added to the width and a top added to the height
    //   - Set the graphics based on the bitmap
    //   - Initialize a brush with a given back color
    //   - Fill the rectangle of the graphics with that back color
    //   - Initialize a pen with a given fore color and width 1
    //   - Draw four lines to set the border of that graphics
    //   - Set the image with the bitmap
    // Called by
    //   - frmExample.frmExample_Load(System.Object, System.EventArgs) Handles this.Load
    //   - wfrmExample.Page_Load(System.Object, System.EventArgs) Handles this.Load
    // Calls
    //   - Image(Bitmap) (Set)
    //   - int Left (Get)
    //   - int Top (Get)
    // Created
    //   - CopyPaste – 20260805 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260805 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Bitmap bitPicture;
      Brush theBrush;
      Graphics theGraphics;
      Pen thePen;

      bitPicture = new Bitmap(Left + intImageWidth, Top + intImageHeight);
      theGraphics = Graphics.FromImage(bitPicture);
      theBrush = new SolidBrush(clrImageBack);
      theGraphics.FillRectangle(theBrush, Left, Top, intImageWidth, intImageHeight);
      thePen = new Pen(clrImageFore, 1);
      theGraphics.DrawLine(thePen, Left, Top, Left + intImageWidth, Top);
      theGraphics.DrawLine(thePen, Left, Top + intImageHeight - 1, Left + intImageWidth, Top + intImageHeight - 1);
      theGraphics.DrawLine(thePen, Left, Top, Left, Top + intImageHeight);
      theGraphics.DrawLine(thePen, Left + intImageWidth - 1, Top, Left + intImageWidth - 1, Top + intImageHeight - 1);
      Image = bitPicture;
    }
    // DrawImage(int, int, Color, Color)

    public void DrawTextOnImage(string strText, Color clrImageFore, int intImageLeftMargin, int intImageTopMargin, string strImageFontName, int intImageFontSize)
    //***
    // Action
    //   - Define a brush
    //   - Define a font
    //   - Define a drawing graphics
    //   - Set the graphics based on the mbitText (bitmap)
    //   - Initialize a font with the given information
    //   - Initialize a brush with a given fore color
    //   - Draw the string on the graphic
    // Called by
    //   - frmExample.frmExample_Load(System.Object, System.EventArgs) Handles this.Load
    //   - wfrmExample.Page_Load(System.Object, System.EventArgs) Handles this.Load
    // Calls
    //   - int Left (Get)
    //   - int Top (Get)
    // Created
    //   - CopyPaste – 20260805 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260805 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Brush theBrush;
      Font theFont;
      Graphics theGraphics;
      
      theGraphics = Graphics.FromImage(mbitText);
      theFont = new Font(strImageFontName, intImageFontSize, FontStyle.Bold);
      theBrush = new SolidBrush(clrImageFore);
      theGraphics.DrawString(strText, theFont, theBrush, Left + intImageLeftMargin, Top + intImageTopMargin);
    }
    // DrawTextOnImage(string, Color, int, int, string, int)

    public void WriteTo(string strFileName, System.Drawing.Imaging.ImageFormat theImageFormat)
    //***
    // Action
    //   - Save a bitmap to a given filename and format
    // Called by
    //   - frmExample.frmExample_Load(System.Object, System.EventArgs) Handles this.Load
    // Calls
    //   - Bitmap Image (Get) 
    // Created
    //   - CopyPaste – 20260805 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260805 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Image.Save(strFileName, theImageFormat);
    }
    // WriteTo(string, System.Drawing.Imaging.ImageFormat)

    public void WriteTo(HttpResponse theResponse, System.Drawing.Imaging.ImageFormat theImageFormat)
    //***
    // Action
    //   - Save an image to a given response of a webpage and format
    //   - Clear the response
    //   - If image format is gif
    //     - Set the content type of the response to image/gif
    //   - If not
    //     - If image Format Is jpep
    //       - Set the content type of the response to image/jpg
    //     - If not
    //       - Set the error variable to true 
    //   - If there is an error
    //     - Throw an new out of range exception with a given title and message
    //   - If not
    //     - Save the bitmap to the output stream of the response
    //     - End the response
    // Called by
    //   - wfrmExample.Page_Load(System.Object, System.EventArgs) Handles this.Load
    // Calls
    //   - Bitmap Image (Get)
    // Created
    //   - CopyPaste – 20260805 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260805 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnError = false;
            
      theResponse.Clear();
      
      if (theImageFormat.Equals(System.Drawing.Imaging.ImageFormat.Gif))
      {
        theResponse.ContentType = "image/gif";
      }
      else if (theImageFormat.Equals(System.Drawing.Imaging.ImageFormat.Jpeg))
        // Not theImageFormat.Equals(System.Drawing.Imaging.ImageFormat.Gif)
      {
        theResponse.ContentType = "image/jpeg";
      }
      else
        // Not theImageFormat.Equals(System.Drawing.Imaging.ImageFormat.Jpeg)
      {
        blnError = true;
      }
      // theImageFormat.Equals(System.Drawing.Imaging.ImageFormat.Gif)
      // theImageFormat.Equals(System.Drawing.Imaging.ImageFormat.Jpeg)
      
      if (blnError)
      {
        throw new System.ArgumentOutOfRangeException("Format", theImageFormat, "Only Jpeg or Gif allowed by current implementation.");
      }
      else
        // Not blnError 
      {
        Image.Save(theResponse.OutputStream, theImageFormat);
        theResponse.End();
      }
      // blnError 

    }
    // WriteTo(HttpResponse, System.Drawing.Imaging.ImageFormat)

    #endregion

    #endregion

    #endregion

    #region "Not used"

    public void WriteTo(System.IO.Stream theStream, System.Drawing.Imaging.ImageFormat theImageFormat)
    //***
    // Action
    //   - Save an image to a stream and format
    // Called by
    //   - System action (Save bitmap)
    // Calls
    //   - Bitmap Image (Get) 
    // Created
    //   - CopyPaste – 20260805 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260805 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Image.Save(theStream, theImageFormat);
    }
    // WriteTo(System.IO.Stream, System.Drawing.Imaging.ImageFormat)

    #endregion

  }
  // cpTextImage

}
// CopyPaste.Toolkit.UserInterface