//***
// Action
//   - Working with an optional variable
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Optional
{

  class cpOptional
	{

    static void Main()
    //***
    // Action
    //   - Write some messages at the console screen, using a procedure with an opitonal value
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - Line(byte)
    //   - Line(byte, char)
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Main menu");
      Line(9);
      Console.WriteLine("1. From cm to inch.");
      Console.WriteLine("2. From inch to cm.");
      Line(19);
      Console.WriteLine();
      Console.WriteLine("Make your choice:");
      Line(17, '~');
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

    static void Line(byte bytNumber, char chrCharacter = '-')
    //***
    // Action
    //   - Write a character 'chrCharacter' 'bytNumber' times at console screen
    //   - Loop from 1 to 'bytNumber' (bytCounter)
    //     - Write character at console screen
    //   - Goto new line
    // Called by
    //   - Main()
    // Calls
    //   - Line(Byte, Char)
    //   - System.Console.ReadLine() As String
    //   - System.Console.WriteLine()
    //   - System.Console.WriteLine(String)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   - In later versions the code below is possible
    //   - static void Line(byte bytNumber, char chrCharacter = '-')
    //***
    {
      byte bytCounter;

      for (bytCounter = 1; bytCounter <= bytNumber; bytCounter++)
      {
        Console.Write(chrCharacter);
      }
      // bytCounter = bytNumber + 1
      
      Console.WriteLine();
    }
    // Line(byte, char)

	}
  // cpOptional

}
// Optional