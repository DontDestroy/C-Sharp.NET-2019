//***
// Action
//   - Demo of And (&), Or (|), AndAlso (&&), OrElse (||)
// Created
//   - CopyPaste � 20240220 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240220 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    static cpProgram()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240220 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240220 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - lngNumber becomes 2
      //   - A test with Or
      //     - Both tests are executed
      //   - A test with And
      //     - Both tests are executed
      //   - lngNumber becomes 0
      //   - A test with OrElse
      //     - Only the first tests is executed if the result is true
      //   - A test with AndAlso
      //     - Only the first tests is executed if the result is false
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - int PossibleDivisionByZero(int)
      // Created
      //   - CopyPaste � 20240220 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240220 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngNumber = 2;

      if ((lngNumber == 0) | (PossibleDivisionByZero(lngNumber) == 2))
      {
        Console.WriteLine("The condition is true");
      }
      else
        // (lngNumber <> 0) And (PossibleDivisionByZero(lngNumber) <> 2)
      {
        Console.WriteLine("The condition is false");
      }
      // (lngNumber = 0) Or (PossibleDivisionByZero(lngNumber) = 2)

      if ((lngNumber > 0) & (PossibleDivisionByZero(lngNumber) == 2))
      {
        Console.WriteLine("The condition is true");
      }
      else
        // (lngNumber <= 0) Or (PossibleDivisionByZero(lngNumber) <> 2)
      {
        Console.WriteLine("The condition is false");
      }
      // (lngNumber > 0) And (PossibleDivisionByZero(lngNumber) = 2)

      lngNumber = 0;

      if ((lngNumber == 0) || (PossibleDivisionByZero(lngNumber) == 2))
      {
        Console.WriteLine("The condition is true");
      }
      else
        // (lngNumber <> 0) AndAlso PossibleDivisionByZero(lngNumber) <> 2
      {
        Console.WriteLine("The condition is false");
      }
      // (lngNumber = 0) OrElse PossibleDivisionByZero(lngNumber) = 2

      if ((lngNumber > 0) && (PossibleDivisionByZero(lngNumber) == 2))
      {
        Console.WriteLine("The condition is true");
      }
      else
        // (lngNumber <= 0) OrElse PossibleDivisionByZero(lngNumber) <> 2
      {
        Console.WriteLine("The condition is false");
      }
      // (lngNumber > 0) AndAlso PossibleDivisionByZero(lngNumber) = 2

      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

    public static int PossibleDivisionByZero(int lngNumber)
      //***
      // Action
      //   - Divide 4 by lngNumber
      //   - Return the result
      //   - This will crash if lngNumber is 0
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240220 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240220 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Convert.ToInt32(4 / lngNumber);
    }
    // int PossibleDivisionByZero(int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning