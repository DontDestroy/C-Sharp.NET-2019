//***
// Action
//   - Overriding and setting some events on the application
// Created
//   - CopyPaste � 20220815 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220815 � VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace PreventSessionEnd
{

  public partial class App : Application
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private bool blnUnsavedData = false;

    #endregion

    #region "Properties"

    public bool UnsavedData
    {

      get
      //***
      // Action Get
      //   - Return blnUnsavedDate
      // Called by
      //   - OnSessionEnding(System.Windows.SessionEndingCancelEventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220815 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220815 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - An auto property can be used here
      //***
      {
        return blnUnsavedData;
      }
      // bool UnsavedData (Get)

      set
      //***
      // Action Set
      //   - blnUnsavedDate becomes value
      // Called by
      //   - OnStartup(System.Windows.StartupEventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220815 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220815 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - An auto property can be used here
      //***
      {
        blnUnsavedData = value;
      }
      // UnsavedData(bool) (Set)

    }
    // bool UnsavedData 

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    protected override void OnSessionEnding(System.Windows.SessionEndingCancelEventArgs theSessionEndingCancelEventArguments)
    //***
    // Action
    //   - The code that must be runned when the sessions end (mostly when there is an error)
    //   - Do the base functionality
    //   - If UnsavedData
    //     - Cancel the event (Session ending is stopped)
    //     - Show a message (normally you do here some decision making, really stopping or not)
    // Called by
    //   - Event (Session Ending, why you for example try to shut down Windows operating system)
    // Calls
    //   - UnsavedData(bool) (Set)
    // Created
    //   - CopyPaste � 20220815 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220815 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      base.OnSessionEnding(theSessionEndingCancelEventArguments);

      if (UnsavedData)
      {
        theSessionEndingCancelEventArguments.Cancel = true;

        MessageBox.Show("The application attempted to close as a result of " +
            theSessionEndingCancelEventArguments.ReasonSessionEnding.ToString() +
            ". This is not allowed, as you have unsaved data.");
      }
      // UnsavedData

    }
    // OnSessionEnding(System.Windows.SessionEndingCancelEventArgs)

    protected override void OnStartup(System.Windows.StartupEventArgs theStartupEventArguments)
    //***
    // Action
    //   - The code that must be runned on startup
    //   - Do the base functionality
    //   - Set UnsavedData to true
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - UnsavedData(bool) (Set)
    // Created
    //   - CopyPaste � 20220815 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220815 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - An auto property can be used here
    //***
    {
      base.OnStartup(theStartupEventArguments);

      UnsavedData = true;
    }
    // OnStartup(System.Windows.StartupEventArgs)

    #endregion

    #region "Sub / Function"

    private void ApplicationDispatcherUnhandledException(System.Object theSender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs theDispatcherUnhandledExceptionEventArguments)
    //***
    // Action
    //   - This is connected with an event handler using an attribute in the XAML file
    //   - Alternatively you can use delegates to trigger the event handling (not done here)
    // Called by
    //   - Event (There was an unhandled exception)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220815 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220815 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Check when you pass this code
    //***
    {
      MessageBox.Show("An unhandled " + 
        theDispatcherUnhandledExceptionEventArguments.Exception.GetType().ToString() +
        ". Exception was caught and ignored.");
      theDispatcherUnhandledExceptionEventArguments.Handled = true;
    }
    // ApplicationDispatcherUnhandledException(System.Object, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // App

}
// PreventSessionEnd