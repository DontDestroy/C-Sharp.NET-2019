//***
// Action
//   - Example of exceptions
//   - A Class and some Exception classes
// Created
//   - CopyPaste � 20231226 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231226 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Company
{

	namespace Material
	{

		#region "Class"

		public class cpCopyMachine
		{

			#region "Constructors / Destructors"

			public cpCopyMachine()
				//***
				// Action
				//   - Empty constructor of a cpCopyMachine
				// Called by
				//   - cpProgram.Main()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231226 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231226 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
			}
			// cpCopyMachine()

			#endregion

			//#region "Designer"
			//#endregion

			//#region "Structures"
			//#endregion

			#region "Fields"

			private decimal mdecPageCost;
			private int mlngNumberOfPages;

			#endregion

			#region "Properties"

			public int NumberOfPages
			{

				get
					//***
					// Action Get
					//   - Returns Number of Pages
					// Called by
					//   - 
					// Calls
					//   - 
					// Created
					//   - CopyPaste � 20231226 � VVDW
					// Changed
					//   - CopyPaste � yyyymmdd � VVDW � What changed
					// Tested
					//   - CopyPaste � 20231226 � VVDW
					// Keyboard key
					//   - 
					// Proposal (To Do)
					//   - 
					//***
				{
					return mlngNumberOfPages;
				}
				// int NumberOfPages (Get)

				set
					//***
					// Action Set
					//   - If value is zero or positive
					//     - mlngNumberOfPages becomes zero or a positive value
					//   - If not (in all other cases) (lngValue is negative)
					//     - A cpNumberPagesException is thrown
					// Called by
					//   - cpProgram.Main()
					// Calls
					//   - cpNumberOfPagesException(string, int)
					// Created
					//   - CopyPaste � 20231226 � VVDW
					// Changed
					//   - CopyPaste � yyyymmdd � VVDW � What changed
					// Tested
					//   - CopyPaste � 20231226 � VVDW
					// Keyboard key
					//   - 
					// Proposal (To Do)
					//   - 
					//***
	    	{

					if (value >= 0)
					{
					  mlngNumberOfPages = value;
          }
          else
            // value < 0
					{
						throw new cpNumberOfPagesException("Number of pages must not be negative", value);
  				}
          // value >= 0

				}
				// NumberOfPages(int) (Set)

			}
			// int NumberOfPages

			public decimal PageCost
			{

				get
					//***
					// Action Get
					//   - Returns the Page Cost
					// Called by
					//   - 
					// Calls
					//   - 
					// Created
					//   - CopyPaste � 20231226 � VVDW
					// Changed
					//   - CopyPaste � yyyymmdd � VVDW � What changed
					// Tested
					//   - CopyPaste � 20231226 � VVDW
					// Keyboard key
					//   - 
					// Proposal (To Do)
					//   - 
					//***
				{
					return mdecPageCost;
				}
				// decimal PageCost (Get)

				set
					//***
					// Action Set
					//   - If value is positive
					//     - mdecPageCost becomes a positive value
					//   - If not (in all other cases) (lngValue is negative or zero)
					//     - A cpCostPerPageException is thrown
					// Called by
					//   - cpProgram.Main()
					// Calls
					//   - cpCostPerPageException(string, int)
					// Created
					//   - CopyPaste � 20231226 � VVDW
					// Changed
					//   - CopyPaste � yyyymmdd � VVDW � What changed
					// Tested
					//   - CopyPaste � 20231226 � VVDW
					// Keyboard key
					//   - 
					// Proposal (To Do)
					//   - 
					//***
      		{

					if (value > 0)
					{
						mdecPageCost = value;
					}
					else
						// value <= 0
					{
						throw new cpCostPerPageException("Cost per page must be larger than 0", value);
					}
						// value > 0

				}
				// PageCost(decimal) (Set)

			}
			// int NumberOfPages
			
			
			#endregion

			//#region "Methods"

			//#region "Overrides"
			//#endregion

			//#region "Controls"
			//#endregion

			//#region "Functionality"

			//#region "Event"
			//#endregion

			//#region "Sub / Function"
			//#endregion

			//#endregion

			//#endregion

			//#region "Not used"
			//#endregion

		}
		// cpCopyMachine
		
		#endregion

		#region "Exceptions"

		public class cpCostPerPageException : ApplicationException
		{

			#region "Constructors / Destructors"

			public cpCostPerPageException(string strMessage, decimal decWrongCost) : base(strMessage)
				//***
				// Action
				//   - Constructor of a cpCostPerPageException
				//   - Sets the message and the wrong cost
				// Called by
				//   - cpCopyMachine.PageCost(decimal) (Set)
				// Calls
				//   - WrongCost(decimal) (Set)
				// Created
				//   - CopyPaste � 20231226 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231226 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				WrongCost = decWrongCost;
			}
			// cpCostPerPageException(string, decimal)

			#endregion

			//#region "Designer"
			//#endregion

			//#region "Structures"
			//#endregion

			#region "Fields"

			private decimal mdecWrongCost;

			#endregion

			#region "Properties"

			public decimal WrongCost
			{
			
				get
					//***
					// Action Get
					//   - Returns the Wrong Cost (as part of the error message)
					// Called by
					//   - cpProgram.Main()
					// Calls
					//   - 
					// Created
					//   - CopyPaste � 20231226 � VVDW
					// Changed
					//   - CopyPaste � yyyymmdd � VVDW � What changed
					// Tested
					//   - CopyPaste � 20231226 � VVDW
					// Keyboard key
					//   - 
					// Proposal (To Do)
					//   - 
					//***
		    {
					return mdecWrongCost;
				}
				// decimal WrongCost (Get)

				set
					//***
					// Action Set
					//   - mdecWrongCost becomes value
					// Called by
					//   - cpCopyMachine(string, decimal)
					// Calls
					//   - 
					// Created
					//   - CopyPaste � 20231226 � VVDW
					// Changed
					//   - CopyPaste � yyyymmdd � VVDW � What changed
					// Tested
					//   - CopyPaste � 20231226 � VVDW
					// Keyboard key
					//   - 
					// Proposal (To Do)
					//   - 
					//***
     		{
					mdecWrongCost = value;
				}
				// WrongCost(decimal) (Set)

			}
			// decimal WrongCost

			#endregion

			//#region "Methods"

			//#region "Overrides"
			//#endregion

			//#region "Controls"
			//#endregion

			//#region "Functionality"

			//#region "Event"
			//#endregion

			//#region "Sub / Function"
			//#endregion

			//#endregion

			//#endregion

			//#region "Not used"
			//#endregion

		}
		// cpCostPerPageException 

		public class cpNumberOfPagesException : ApplicationException
		{

			#region "Constructors / Destructors"

			public cpNumberOfPagesException(string strMessage, int lngWrongNumber) : base(strMessage)
				//***
				// Action
				//   - Constructor of a cpNumberOfPagesException
				//   - Sets the message and the wrong number of pages
				// Called by
				//   - cpCopyMachine.NumberOfPages(int) (Set)
				// Calls
				//   - WrongNumber(int) (Set)
				// Created
				//   - CopyPaste � 20231226 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231226 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				WrongNumber = lngWrongNumber;
			}
			// cpNumberOfPagesException(string, decimal)

			#endregion

			//#region "Designer"
			//#endregion

			//#region "Structures"
			//#endregion

			#region "Fields"

			private int mlngWrongNumber;

			#endregion

			#region "Properties"

			public int WrongNumber
			{
			
				get
					//***
					// Action Get
					//   - Returns the Wrong Number (as part of the error message)
					// Called by
					//   - cpProgram.Main()
					// Calls
					//   - 
					// Created
					//   - CopyPaste � 20231226 � VVDW
					// Changed
					//   - CopyPaste � yyyymmdd � VVDW � What changed
					// Tested
					//   - CopyPaste � 20231226 � VVDW
					// Keyboard key
					//   - 
					// Proposal (To Do)
					//   - 
					//***
				{
					return mlngWrongNumber;
				}
				// int WrongNumber (Get)

				set
					//***
					// Action Set
					//   - mlngWrongNumber becomes value
					// Called by
					//   - cpCopyMachine(string, decimal)
					// Calls
					//   - 
					// Created
					//   - CopyPaste � 20231226 � VVDW
					// Changed
					//   - CopyPaste � yyyymmdd � VVDW � What changed
					// Tested
					//   - CopyPaste � 20231226 � VVDW
					// Keyboard key
					//   - 
					// Proposal (To Do)
					//   - 
					//***
				{
					mlngWrongNumber = value;
				}
				// WrongNumber(int) (Set)

			}
			// int WrongNumber

			#endregion

			//#region "Methods"

			//#region "Overrides"
			//#endregion

			//#region "Controls"
			//#endregion

			//#region "Functionality"

			//***
			// Action
			//   - Explanation of the code in this module or class
			// Called by
			//   - List of code that uses this procedure
			// Calls
			//   - List of procedures that are called by this piece of code
			// Created
			//   - CopyPaste � yyyymmdd � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � yyyymmdd � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - List of actions that can be added to the functionality
			//***

			//#region "Event"
			//#endregion

			//#region "Sub / Function"
			//#endregion

			//#endregion

			//#endregion

			//#region "Not used"
			//#endregion

		}
		// cpCostPerPageException 

		#endregion

	}
	// Material

}
// Company