//***
// Action
//   - A screen with four options
// Created
//   - CopyPaste � 20251211 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251211 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMain: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdGenericSearch;
    internal System.Windows.Forms.ToolTip ttpInfo;
    internal System.Windows.Forms.Button cmdPointAndClickQuery;
    internal System.Windows.Forms.Button cmdUpdateMultipleLookupTable;
    internal System.Windows.Forms.Button cmdMultiSelectList;
    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMain));
      this.cmdGenericSearch = new System.Windows.Forms.Button();
      this.ttpInfo = new System.Windows.Forms.ToolTip(this.components);
      this.cmdPointAndClickQuery = new System.Windows.Forms.Button();
      this.cmdUpdateMultipleLookupTable = new System.Windows.Forms.Button();
      this.cmdMultiSelectList = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdGenericSearch
      // 
      this.cmdGenericSearch.Location = new System.Drawing.Point(8, 154);
      this.cmdGenericSearch.Name = "cmdGenericSearch";
      this.cmdGenericSearch.Size = new System.Drawing.Size(200, 32);
      this.cmdGenericSearch.TabIndex = 7;
      this.cmdGenericSearch.Text = "Generic Search";
      this.cmdGenericSearch.Click += new System.EventHandler(this.cmdGenericSearch_Click);
      // 
      // cmdPointAndClickQuery
      // 
      this.cmdPointAndClickQuery.Location = new System.Drawing.Point(8, 106);
      this.cmdPointAndClickQuery.Name = "cmdPointAndClickQuery";
      this.cmdPointAndClickQuery.Size = new System.Drawing.Size(200, 32);
      this.cmdPointAndClickQuery.TabIndex = 6;
      this.cmdPointAndClickQuery.Text = "Point and Click Query";
      this.cmdPointAndClickQuery.Click += new System.EventHandler(this.cmdPointAndClickQuery_Click);
      // 
      // cmdUpdateMultipleLookupTable
      // 
      this.cmdUpdateMultipleLookupTable.Location = new System.Drawing.Point(8, 58);
      this.cmdUpdateMultipleLookupTable.Name = "cmdUpdateMultipleLookupTable";
      this.cmdUpdateMultipleLookupTable.Size = new System.Drawing.Size(200, 32);
      this.cmdUpdateMultipleLookupTable.TabIndex = 5;
      this.cmdUpdateMultipleLookupTable.Text = "Multiple Update Lookup Table";
      this.cmdUpdateMultipleLookupTable.Click += new System.EventHandler(this.cmdUpdateMultipleLookupTable_Click);
      // 
      // cmdMultiSelectList
      // 
      this.cmdMultiSelectList.Location = new System.Drawing.Point(8, 10);
      this.cmdMultiSelectList.Name = "cmdMultiSelectList";
      this.cmdMultiSelectList.Size = new System.Drawing.Size(200, 32);
      this.cmdMultiSelectList.TabIndex = 4;
      this.cmdMultiSelectList.Text = "Multi-Select List";
      this.cmdMultiSelectList.Click += new System.EventHandler(this.cmdMultiSelectList_Click);
      // 
      // frmMain
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(216, 197);
      this.Controls.Add(this.cmdPointAndClickQuery);
      this.Controls.Add(this.cmdUpdateMultipleLookupTable);
      this.Controls.Add(this.cmdMultiSelectList);
      this.Controls.Add(this.cmdGenericSearch);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMain";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Data Driven Main Form";
      this.Load += new System.EventHandler(this.frmMain_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMain'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMain()
      //***
      // Action
      //   - Create instance of 'frmMain'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMain()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdGenericSearch_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmTrySearch'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmTrySearch()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmTrySearch theForm = new frmTrySearch();

      theForm.Show();
    }
    // cmdGenericSearch_Click(System.Object, System.EventArgs) Handles cmdGenericSearch.Click

    private void cmdMultiSelectList_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmMultiSelectList'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmMultiSelectList()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmMultiSelectList theForm = new frmMultiSelectList();

      theForm.Show();
    }
    // cmdMultiSelectList_Click(System.Object, System.EventArgs) Handles cmdMultiSelectList.Click

    private void cmdPointAndClickQuery_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmPointAndClickQuery'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmPointAndClickQuery()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmPointAndClickQuery theForm = new frmPointAndClickQuery();

      theForm.Show();
    }
    // cmdPointAndClickQuery_Click(System.Object, System.EventArgs) Handles cmdPointAndClickQuery.Click

    private void cmdUpdateMultipleLookupTable_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmUpdateMultipleLookupTable'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmUpdateMultipleLookupTable()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmUpdateMultipleLookupTable theForm = new frmUpdateMultipleLookupTable();

      theForm.Show();
    }
    // cmdUpdateMultipleLookupTable_Click(System.Object, System.EventArgs) Handles cmdUpdateMultipleLookupTable.Click
    
    private void frmMain_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set tooltips with the buttons
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ttpInfo.SetToolTip(cmdMultiSelectList, "Work with data bound multi-select ListBoxes using Windows Forms");
      ttpInfo.SetToolTip(cmdUpdateMultipleLookupTable, "Use a single Windows form to update multiple lookup tables");
      ttpInfo.SetToolTip(cmdPointAndClickQuery, "Create a point and click query tool for users using a Windows Form");
      ttpInfo.SetToolTip(cmdGenericSearch, "Make a generic search form in a Visual Basic .NET desktop application");
    }
    // frmMain_Load(System.Object theSender, System.EventArgs theEventArguments) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMain
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmMain()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMain());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMain

}
// CopyPaste.Learning