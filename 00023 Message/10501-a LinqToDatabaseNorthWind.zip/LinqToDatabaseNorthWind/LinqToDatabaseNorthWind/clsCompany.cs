﻿//***
// Action
//   - The definition of a cpCompany
//   - The company has a list of cpEmployees
// Created
//   - CopyPaste – 20230329 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230329 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;

namespace CopyPaste.HumanResources
{

  public class cpCompany
  {

    #region "Constructors / Destructors"

    public cpCompany(string strCompanyName)
    //***
    // Action
    //   - Creating an instance of a cpCompany
    //   - Creating a list of cpEmployees for that company
    // Called by
    //   - cpProgram.BasicLinqCasting()
    // Calls
    //   - cpEmployee(int, string, string)
    //   - CompanyName(string) (Set)
    // Created
    //   - CopyPaste – 20230329 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230329 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - This is normally done by a database query
    //***
    {
      colEmployees = new ArrayList();

      colEmployees.Add(new cpEmployee(1, "Vincent", "Van De Walle"));
      colEmployees.Add(new cpEmployee(2, "Hilde", "Saelens"));
      colEmployees.Add(new cpEmployee(3, "Gertrude", "Gryson"));
      CompanyName = strCompanyName;
    }
    // cpCompany(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private ArrayList colEmployees;

    #endregion

    #region "Properties"

    public ArrayList AllEmployees
    {
      //***
      // Action Get
      //   - Returning a list of cpEmployees
      // Called by
      //   - cpProgram.BasicLinqCasting()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20230329 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20230329 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      get
      {
        return colEmployees;
      }

    }
    // ArrayList AllEmployees

    public string CompanyName { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpCompany

}
// CopyPaste.HumanResources