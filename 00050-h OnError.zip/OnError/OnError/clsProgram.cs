//***
// Action
//   - Test on the specific error number
//   - There is no equivalent code to the Visual Basic On Error statement
// Created
//   - CopyPaste � 20230808 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230808 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Enter an old name
      //   - Enter a new name
      //   - Rename the old name file into the new name
      //   - If there is an error
      //     - Show the corresponding error (depending on the error number)
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strNewName;
      string strOldName;

      strOldName = Interaction.InputBox("Enter the filename to rename.", "Copy Paste", "", 0, 0);
      strNewName = Interaction.InputBox("Enter the new filename.", "Copy Paste", "", 0, 0);
      
      try
      {
        FileSystem.Rename("T:\\" + strOldName, "T:\\" + strNewName);
      }
      catch (ArgumentException theArgumentException)
      {
        MessageBox.Show("File " + strOldName + " not found.");
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.ToString());
      }

    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning