//***
// Action
//   - Definition of a derived class cpDerived
// Created
//   - CopyPaste � 20240617 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240617 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpDerived : cpBase
  {

    #region "Constructors / Destructors"

    public cpDerived() : base()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpProgram.Main() 
      // Calls
      //   - cpBase()
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDerived()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void FunctionTestDerived()
      //***
      // Action
      //   - Test derived functionroutines
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - FunctionInternal()
      //   - Functionrotected()
      //   - FunctionProtectedInternal()
      //   - FunctionPublic()
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;

      blnResult = FunctionInternal();
      Console.WriteLine("Result of FunctionInternal: {0}", blnResult);

      // FunctionPrivate();
      blnResult = FunctionProtected();
      Console.WriteLine("Result of FunctionProtected: {0}", blnResult);
      blnResult = FunctionProtectedInternal();
      Console.WriteLine("Result of FunctionProtectedInternal: {0}", blnResult);
      blnResult = FunctionPublic();
      Console.WriteLine("Result of FunctionPublic: {0}", blnResult);
    }
    // FunctionTestDerived()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDerived

}
// CopyPaste.Learning