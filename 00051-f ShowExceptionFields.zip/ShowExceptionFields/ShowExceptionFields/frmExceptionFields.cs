//***
// Action
//   - An exception has properties. Here we use them
// Created
//   - CopyPaste � 20240515 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240515 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmExceptionFields: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdGenerate;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmExceptionFields));
      this.cmdGenerate = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdGenerate
      // 
      this.cmdGenerate.Location = new System.Drawing.Point(76, 64);
      this.cmdGenerate.Name = "cmdGenerate";
      this.cmdGenerate.Size = new System.Drawing.Size(120, 40);
      this.cmdGenerate.TabIndex = 1;
      this.cmdGenerate.Text = "Generate Exception";
      this.cmdGenerate.Click += new System.EventHandler(this.cmdGenerate_Click);
      // 
      // frmExceptionFields
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(272, 197);
      this.Controls.Add(this.cmdGenerate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmExceptionFields";
      this.Text = "Show Exception Fields";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmExceptionFields'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmExceptionFields()
      //***
      // Action
      //   - Create instance of 'frmExceptionFields'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmExceptionFields()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdGenerate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try
      //     - To read an non existing file
      //   - When it fails
      //     - Show the error message
      //     - Show the error source
      //     - Show the StackTrace
      //     - Show the TargitSite.Name
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      StreamReader strReader;

      try
      {
        strReader = new StreamReader("FilenameISBad.XXX");
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
        MessageBox.Show(theException.Source, "Source", MessageBoxButtons.OK, MessageBoxIcon.Information);
        MessageBox.Show(theException.StackTrace, "StackTrace", MessageBoxButtons.OK, MessageBoxIcon.Information);
        MessageBox.Show(theException.TargetSite.Name, "TargetSite.Name", MessageBoxButtons.OK, MessageBoxIcon.Information);
      }
      finally
      {
      }

    }
    // cmdGenerate_Click(System.Object, System.EventArgs) Handles cmdGenerate_Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmExceptionFields
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmExceptionFields()
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmExceptionFields());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmExceptionFields

}
// CopyPaste.Learning