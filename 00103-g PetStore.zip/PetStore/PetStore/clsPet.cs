//***
// Action
//   - A pet store, the definition of a pet (base class, but inherits from cpAnimal)
//   - Working with properties (Get and Set) and methods in several classes, that can be reused
// Created
//   - CopyPaste � 20220316 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW
// Tested
//   - CopyPaste � 20220316 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace CopyPaste.Pet
{

  public class cpPet : cpAnimal
  {

    #region "Constructors / Destructors"

    public cpPet() : base ()
    //***
    // Action
    //   - Creating an instance of cpPet with parameters set to default
    //   - Creating an instance of cpAnimal
    //   - mstrFood becomes empty string
    // Called by
    //   - 
    // Calls
    //   - base() 
    // Created
    //   - CopyPaste � 20220316 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20220316 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      mstrFood = "";
    }
    // cpPet()

    public cpPet(string strSpecies, int intLegs) : base (strSpecies, intLegs)
    //***
    // Action
    //   - Creating an instance of cpPet with parameters strSpecies and lngLegs
    //   - Creating an instance of cpAnimal with parameters strSpecies and lngLegs
    // Called by
    //   - CopyPaste.Pet.cpBird()
    //   - CopyPaste.Pet.cpCat()
    //   - CopyPaste.Pet.cpDog()
    // Calls
    //   - base(string, int)
    // Created
    //   - CopyPaste � 20220316 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20220316 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      // check what happens with mstrFood
    }
    // cpPet()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrFood;

    #endregion

    #region "Properties"

    public string Food
    {

      get
      //***
      // Action Get
      //   - Return the food of the pet (mstrFood)
      // Called by
      //   - frmPetStore.Display(CopyPaste.Pet.cpPet)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return mstrFood;
      }
      // string Food (Get)

      set
      //***
      // Action Set
      //   - Set the food of the pet (mstrFood becomes strValue)
      // Called by
      //   - CopyPaste.Pet.cpBird()
      //   - CopyPaste.Pet.cpCat()
      //   - CopyPaste.Pet.cpDog()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        mstrFood = value;
      }
      // Food(string) (Set)

    }
    // string Food

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpPet

}
// CopyPaste.Pet