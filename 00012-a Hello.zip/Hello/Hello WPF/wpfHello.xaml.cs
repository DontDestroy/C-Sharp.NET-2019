﻿//***
// Action
//   - An example of a WPF form
// Created
//   - CopyPaste – 20230615 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230615 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Hello_WPF
{

  public partial class wpfHello : Window
  {

    #region "Constructors / Destructors"

    public wpfHello()
    //***
    // Action
    //   - Create instance of 'wpfHello'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230615 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230615 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfHello()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void cmdOK_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Place text in a textbox
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230615 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230615 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      txtText.Text = "Hello, world!";
    }
    // cmdOK_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdOK.Click

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfHello

}
// Hello_WPF