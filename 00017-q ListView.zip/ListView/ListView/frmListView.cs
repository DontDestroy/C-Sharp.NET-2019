//***
// Action
//   - Example of a listview
// Created
//   - CopyPaste � 20240330 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240330 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmListView: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdShow;
    internal System.Windows.Forms.ListView lsvList;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmListView));
      this.cmdShow = new System.Windows.Forms.Button();
      this.lsvList = new System.Windows.Forms.ListView();
      this.SuspendLayout();
      // 
      // cmdShow
      // 
      this.cmdShow.Location = new System.Drawing.Point(98, 224);
      this.cmdShow.Name = "cmdShow";
      this.cmdShow.Size = new System.Drawing.Size(96, 23);
      this.cmdShow.TabIndex = 3;
      this.cmdShow.Text = "Show Files";
      this.cmdShow.Click += new System.EventHandler(this.cmdShow_Click);
      // 
      // lsvList
      // 
      this.lsvList.Location = new System.Drawing.Point(34, 32);
      this.lsvList.Name = "lsvList";
      this.lsvList.Size = new System.Drawing.Size(224, 168);
      this.lsvList.TabIndex = 2;
      this.lsvList.View = System.Windows.Forms.View.List;
      // 
      // frmListView
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdShow);
      this.Controls.Add(this.lsvList);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmListView";
      this.Text = "ListView";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmListView'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmListView()
      //***
      // Action
      //   - Create instance of 'frmListView'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmListView()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdShow_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Fill an array with all the files at a certain location
      //   - Define the listview as a list
      //     - There are 3 other options in comment
      //   - Loop thru all the elements of the array
      //     - Add item the listview
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string[] arrstrFile = Directory.GetFiles("C:\\");
      
      // lsvList.View = View.Details;
      // lsvList.View = View.LargeIcon;
      lsvList.View = View.List;
      // lsvList.View = View.SmallIcon;

      foreach (string strFileName in arrstrFile)
      {
        lsvList.BeginUpdate();
        lsvList.Items.Add(strFileName);
        lsvList.EndUpdate();
        lsvList.Refresh();
      }
      // in arrstrFile

    }
    // cmdShow_Click(System.Object, System.EventArgs) Handles cmdShow.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmListView
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmListView());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmListView

}
// CopyPaste.Learning