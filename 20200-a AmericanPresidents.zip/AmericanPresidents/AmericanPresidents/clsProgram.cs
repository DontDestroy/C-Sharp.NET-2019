﻿//***
// Action
//   - A Linq example with the American Presidents
// Created
//   - CopyPaste – 20230413 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230413 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace AmericanPresidents
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Creating an array with all the American presidents
    //   - Querying the array with a Linq Lambda dot notation
    //   - Looping the result
    //   - Querying the array with a Linq expression 
    //   - Looping the result
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230413 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230413 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      string strCurrentMethodName;
      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      string[] arrAmericanPresidents = {
        "George Washington", "John Adams", "Thomas Jefferson", "James Madison",
        "James Monroe", "John Quincy Adams", "Andrew Jackson", "Martin Van Buren",
        "William Henry Harrison", "John Tyler", "James K. Polk", "Zachary Taylor",
        "Millard Fillmore", "Franklin Pierce", "James Buchanan", "Abraham Lincoln",
        "Andrew Johnson", "Ulysses S. Grant", "Rutherford B. Hayes", "James A. Garfield",
        "Chester A. Arthur", "Grover Cleveland", "Benjamin Harrison", "William McKinley",
        "Theodore Roosevelt", "William Howard Taft", "Woordrow Wilson", "Warren G. Harding",
        "Calvin Coolidge", "Herbert Hoover", "Franklin D. Roosevelt", "Harry S. Truman",
        "Dwight D. Eisenhower", "John F. Kennedy", "Lyndon B. Johnson", "Richard Nixon",
        "Gerald Ford", "Jimmy Carter", "Ronald Reagan", "George H. W. Bush", "Bill Clinton",
        "George W. Bush", "Barack Obama", "Donald Trump", "Joe Biden"};

      IEnumerable<string> colResultLambda = arrAmericanPresidents
        .Where(aPresident => aPresident.Length < 13)
        .Select(aPresident => aPresident);

      Console.WriteLine("The List of American Presidents (names shorter than 13): (Lambda Linq dot notation)");
      
      foreach (string aPresident in colResultLambda)
      {
        Console.WriteLine(aPresident);
      }
      // in colResultLambda

      IEnumerable<string> colResultExpression = from aPresident in arrAmericanPresidents
                                                where aPresident.Length >= 13
                                                select aPresident;

      Console.WriteLine("\nThe List of American Presidents (names equal or longer than 13): (Linq Expression)");

      foreach (string aPresident in colResultExpression)
      {
        Console.WriteLine(aPresident);
      }
      // in colResultExpression

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram 

}
// AmericanPresidents