﻿//***
// Action
//   - Demo of reading an XML file as info for a webpage
// Created
//   - CopyPaste – 20260710 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260710 – VVDW
// Proposal (To Do)
//   -
//***


using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Resources;
using System.Web;
using System.Web.SessionState;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Xml;

namespace CopyPaste.Learning
{

  public partial class wfrmViewBookInfo: System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cmdCSharp.Click += new System.EventHandler(this.cmdButton_Click);
      this.cmdHTML.Click += new System.EventHandler(this.cmdButton_Click);
      this.cmdUpgrade.Click += new System.EventHandler(this.cmdButton_Click);
      this.cmdVisualBasic.Click += new System.EventHandler(this.cmdButton_Click);
      this.ID = "wfrmViewBookInfo";
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static DataSet mtheDataSet;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when initializing the page
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdButton_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a counter, to determine what record must be shown
    //   - Depending on the button clicked, a corresponding number is put in the counter
    //   - Fill the textbox with the corrrect record from the dataset
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intCounter = 0;

      if (Equals(theSender, cmdCSharp))
      {
        intCounter = 0;
      }
      else if (Equals(theSender, cmdVisualBasic))
      // Not Equals(theSender, cmdCSharp)
      {
        intCounter = 1;
      }
      else if (Equals(theSender, cmdHTML))
      // Not Equals(theSender, cmdVisualBasic)
      {
        intCounter = 2;
      }
      else if (Equals(theSender, cmdUpgrade))
      // Not Equals(theSender, cmdHTML)
      {
        intCounter = 3;
      }
      else
      // Not Equals(theSender, cmdUpgrade)
      {
      }
      // Equals(theSender, cmdCSharp)

      txtResult.Text = mtheDataSet.Tables["Table"].Rows[intCounter]["Title"].ToString();
      txtResult.Text += Environment.NewLine + mtheDataSet.Tables["Table"].Rows[intCounter]["Author"].ToString();
      txtResult.Text += Environment.NewLine + mtheDataSet.Tables["Table"].Rows[intCounter]["Publisher"].ToString();
      txtResult.Text += Environment.NewLine + mtheDataSet.Tables["Table"].Rows[intCounter]["Price"].ToString();
    }
    // cmdButton_Click(System.Object, System.EventArgs) Handles cmdCSharp.Click, cmdHTML.Click, cmdVisualBasic.Click, cmdUpgrade.Click

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - If it is the first time the page is loading
    //     - Create a new dataset
    //     - Read a specific XML file into the dataset
    //   - If Not
    //     - Do nothing
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (Page.IsPostBack)
      {
      }
      else
      // Not Page.IsPostBack
      {
        mtheDataSet = new DataSet();
        mtheDataSet.ReadXml(Server.MapPath("authors.xml"));
      }
      // Page.IsPostBack

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmViewBookInfo

}
// CopyPaste.Learning