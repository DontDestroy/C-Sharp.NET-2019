//***
// Action
//   - Example of Overloading Functions
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Overload
{

  public class frmOverload : System.Windows.Forms.Form
  {
    internal System.Windows.Forms.Label lblOutput;

    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    System.ComponentModel.Container components;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOverload));
      this.lblOutput = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // lblOutput
      // 
      this.lblOutput.Location = new System.Drawing.Point(8, 8);
      this.lblOutput.Name = "lblOutput";
      this.lblOutput.Size = new System.Drawing.Size(224, 40);
      this.lblOutput.TabIndex = 1;
      // 
      // frmOverload
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(240, 53);
      this.Controls.Add(this.lblOutput);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmOverload";
      this.Text = "Overload";
      this.Load += new System.EventHandler(this.frmOverload_Load);
      this.ResumeLayout(false);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmOverload'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing)
      {

        if (components == null)
        {
        }
        else
        // (components != null)
        {
          components.Dispose();
        }
        // (components == null)

      }
      else
      // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmOverload()
    //***
    // Action
    //   - Create instance of 'frmOverload'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmOverload()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmOverload_Load(System.Object theSender, System.EventArgs theSystemEventArguments)
    //***
    // Action
    //   - Show the squares of an integer of an double
    // Called by
    //   - System action (Loading a form)
    // Calls
    //   - double Square(double)
    //   - Environment.NewLine()
    //   - long Square(long)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      lblOutput.Text = "The square of Integer 7 is " + Square(7) + Environment.NewLine +
        "The square of Double 7.5 is " + Square(7.5);
    }
    // frmOverload_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmOverload
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmOverload());
    }
    // Main() 

    static long Square(long lngValue)
    //***
    // Action
    //   - Multiply a long with itself
    // Called by
    //   - frmOverload_Load(System.Object, System.EventArgs) Handles this.Load
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return lngValue ^ 2;
    }
    // long Square(long)

    static double Square(double dblValue)
    //***
    // Action
    //   - Multiply a double with itself
    // Called by
    //   - frmOverload_Load(System.Object, System.EventArgs) Handles this.Load
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return dblValue * dblValue;
    }
    // double Square(double)

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmOverload

}
// Overload