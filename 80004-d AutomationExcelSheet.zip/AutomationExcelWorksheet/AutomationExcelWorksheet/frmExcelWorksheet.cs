//***
// Action
//   - Doing some actions on a Excel sheet
// Created
//   - CopyPaste � 20251228 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251228 � VVDW
// Proposal (To Do)
//   - 
//***

using Microsoft.Office.Interop;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;


namespace CopyPaste.Learning
{

  public class frmExcelWorksheet: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdCreate;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmExcelWorksheet));
      this.cmdCreate = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdCreate
      // 
      this.cmdCreate.Location = new System.Drawing.Point(96, 64);
      this.cmdCreate.Name = "cmdCreate";
      this.cmdCreate.Size = new System.Drawing.Size(104, 32);
      this.cmdCreate.TabIndex = 1;
      this.cmdCreate.Text = "Create worksheet";
      this.cmdCreate.Click += new System.EventHandler(this.cmdCreate_Click);
      // 
      // frmExcelWorksheet
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 213);
      this.Controls.Add(this.cmdCreate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmExcelWorksheet";
      this.Text = "Excel Worksheet";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmExcelWorksheet'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmExcelWorksheet()
      //***
      // Action
      //   - Create instance of 'frmExcelWorksheet'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdCreate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //'***
      //' Action
      //'   - Define and create an Excel application
      //'   - Define an Excel workbook
      //'   - Define an Excel worksheet
      //'   - Set the culture of a thread to English (English version of Excel)
      //'   - Create a new Excel workbook
      //'   - Define the first worksheet of that workbook
      //'   - Put some values into the sheet
      //'   - Calculate a total
      //'   - Set some cells bold
      //'   - Show the application
      //'   - Save the workbook
      //' Called by
      //'   - User action (Clicking a button)
      //' Calls
      //'   - 
      //' Created
      //'   - CopyPaste � 20251228 � VVDW
      //' Changed
      //'   - CopyPaste � yyyymmdd � VVDW � What changed
      //' Tested
      //'   - CopyPaste � 20251228 � VVDW
      //' Keyboard key
      //'   -
      //' Proposal (To Do)
      //'   -
      //'***
    {
      Microsoft.Office.Interop.Excel.Application theExcelApplication = new Microsoft.Office.Interop.Excel.Application();
      Microsoft.Office.Interop.Excel.Range theExcelRange;
      Microsoft.Office.Interop.Excel.Workbook theExcelBook;
      Microsoft.Office.Interop.Excel.Worksheet theExcelSheet;

      System.Threading.Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("en-US");

      theExcelBook = theExcelApplication.Workbooks.Add();
      theExcelSheet = (Microsoft.Office.Interop.Excel.Worksheet)theExcelBook.ActiveSheet;
      theExcelSheet.Cells[1, 1] = "Drinks";
      theExcelSheet.Cells[1, 2] = 5000;
      theExcelSheet.Cells[2, 1] = "Tips";
      theExcelSheet.Cells[2, 2] = 750;
      theExcelSheet.Cells[3, 1] = "Total";
      
      theExcelRange = theExcelSheet.Range[theExcelSheet.Cells[3, 2], theExcelSheet.Cells[3, 2]];
      theExcelRange.Formula = "=Sum(R1C2:R2C2)";

      theExcelRange = theExcelSheet.Range[theExcelSheet.Cells[3, 1], theExcelSheet.Cells[3, 2]];
      theExcelRange.Font.Bold = true;

      theExcelApplication.Application.Visible = true;
      theExcelBook.SaveAs2("T:\\DemoExcel.xlsx", Microsoft.Office.Interop.Excel.XlFileFormat.xlWorkbookDefault);
    }
    // cmdCreate_Click(System.Object, System.EventArgs) Handles cmdCreate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmExcelWorksheet
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmExcelWorksheet()
      // Created
      //   - CopyPaste � 20251228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmExcelWorksheet());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmExcelWorksheet

}
// CopyPaste.Learning