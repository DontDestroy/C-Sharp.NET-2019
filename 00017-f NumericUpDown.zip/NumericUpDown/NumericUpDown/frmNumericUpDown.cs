//***
// Action
//   - Basic functionalities of a NumericUpDown control
// Created
//   - CopyPaste � 20240312 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240312 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmNumericUpDown: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdDone;
    internal System.Windows.Forms.Label lblValue;
    internal System.Windows.Forms.NumericUpDown nudValue;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmNumericUpDown));
      this.cmdDone = new System.Windows.Forms.Button();
      this.lblValue = new System.Windows.Forms.Label();
      this.nudValue = new System.Windows.Forms.NumericUpDown();
      ((System.ComponentModel.ISupportInitialize)(this.nudValue)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdDone
      // 
      this.cmdDone.Location = new System.Drawing.Point(104, 71);
      this.cmdDone.Name = "cmdDone";
      this.cmdDone.TabIndex = 5;
      this.cmdDone.Text = "Done";
      this.cmdDone.Click += new System.EventHandler(this.cmdDone_Click);
      // 
      // lblValue
      // 
      this.lblValue.Location = new System.Drawing.Point(16, 23);
      this.lblValue.Name = "lblValue";
      this.lblValue.Size = new System.Drawing.Size(72, 23);
      this.lblValue.TabIndex = 3;
      this.lblValue.Text = "Value";
      // 
      // nudValue
      // 
      this.nudValue.Location = new System.Drawing.Point(104, 23);
      this.nudValue.Name = "nudValue";
      this.nudValue.TabIndex = 4;
      // 
      // frmNumericUpDown
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 117);
      this.Controls.Add(this.cmdDone);
      this.Controls.Add(this.lblValue);
      this.Controls.Add(this.nudValue);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmNumericUpDown";
      this.Text = "Numeric Up Down";
      this.Load += new System.EventHandler(this.frmNumericUpDown_Load);
      ((System.ComponentModel.ISupportInitialize)(this.nudValue)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmNumericUpDown'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmNumericUpDown()
      //***
      // Action
      //   - Create instance of 'frmNumericUpDown'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmNumericUpDown()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    
    private void cmdDone_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a message with the current value of the numeric up down control
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show("Value is " + nudValue.Value);
    }
    // cmdDone_Click(System.Object, System.EventArgs) Handling cmdDone.Click

    private void frmNumericUpDown_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the increment of the numeric up down control to 5
      //   - Set the maximum value of the numeric up down control to 1000
      //   - Set the minimum value of the numeric up down control to 0
      //   - Set the start value of the numeric up down control to 500
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      nudValue.Increment = 5;
      nudValue.Maximum = 1000;
      nudValue.Minimum = 0;
      nudValue.Value = 500;
    }
    // frmNumericUpDown_Load(System.Object, System.EventArgs) Handles MyBase.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmNumericUpDown
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmNumericUpDown());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmNumericUpDown

}
// CopyPaste.Learning