//***
// Action
//   - Show some messages
// Created
//   - CopyPaste � 20211018 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20211018 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Output
{

  class cpOutput
	{

    static void Main()
    //***
    // Action
    //   - Write some message at the console screen
    //   - Wait for user interaction
    // Called by
    //   - 
    // Calls
    //   - System.Console.ReadLine()
    //   - System.Console.WriteLine(Double)
    //   - System.Console.WriteLine(Int32)
    //   - System.Console.WriteLine(String)
    // Created
    //   - CopyPaste � 20211018 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20211018 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      double dblNumber = 0.123456789;
      int intNumber = 100;
      string strMessage = "Hello, C# World!";

      Console.WriteLine(intNumber);
      Console.WriteLine("The value of Number is " + intNumber);
      Console.WriteLine(dblNumber);
      Console.WriteLine(dblNumber + " plus " + intNumber + " = " + (dblNumber + intNumber));
      Console.WriteLine(strMessage);
      Console.ReadLine();
    }
    // Main()

  }
  // cpOutput

}
// Output
