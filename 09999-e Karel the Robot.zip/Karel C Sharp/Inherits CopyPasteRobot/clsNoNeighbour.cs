﻿//***
// Action
//   - A definition of a NoNeighbour
// Created
//   - CopyPaste – 20251028 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251028 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpNoNeighbour : cpCopyPasteRobot, cpinfBeeperPutter
	{

    #region "Constructors / Destructors"

    public cpNoNeighbour(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpNoNeighbour starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpNoNeighbour(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpNoNeighbour(int, int, Directions.Direction, int) 

    public cpNoNeighbour(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpNoNeighbour starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    // Called by
    //   - cpNoNeighbour(int, int, Directions.Direction, int)
    //   - cpProgram.TwoDifferentRobotsInterface()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpNoNeighbour(int, int, Directions.Direction, int, Color) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void DistributeBeepers()
    //***
    // Action
    //   - Implementation of method from cpinfBeeperPutter
    //   - Put a beeper down
    //   - Move one forward
    // Called by
    //   - cpProgram.TwoDifferentRobotsInterface()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      putBeeper();
      move();
      SwitchOff();
    }
    // DistributeBeepers()

    public void SwitchOff()
    //***
    // Action
    //   - Implementation of method from cpinfBeeperPutter
    //   - Turn off the robot
    // Called by
    //   - cpProgram.TwoDifferentRobotsInterface()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      base.turnOff();
    }
    // SwitchOff()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpNoNeighbour

}
// cpKarelTheRobot