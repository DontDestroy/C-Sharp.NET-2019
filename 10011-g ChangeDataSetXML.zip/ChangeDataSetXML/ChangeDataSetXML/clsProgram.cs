﻿//***
// Action
//   - Reading and updating an XML file thru a data set
// Created
//   - CopyPaste – 20251127 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251127 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Try to
      //     - Create a new data set
      //     - Read information from XML file into data set
      //     - Loop thru the records
      //       - Update author into upper case
      //     - Loop thru the records
      //       - Show Title, Author, Publisher and Price information
      //     - Save the updated dataset to another XML file
      //   - When something fails
      //     - Show error information
      //   - Wait for user interaction
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251127 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251127 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        DataSet theDataSet = new DataSet();

        theDataSet.ReadXml("Authors.XML");
        
        for (int lngCounter = 0; lngCounter < theDataSet.Tables[0].Rows.Count; lngCounter++)
        {
          theDataSet.Tables[0].Rows[lngCounter]["Author"] = theDataSet.Tables[0].Rows[lngCounter]["Author"].ToString().ToUpper();
        }
        // lngCounter = theDataSet.Tables(0).Rows.Count 
        
        for (int lngCounter = 0; lngCounter < theDataSet.Tables[0].Rows.Count; lngCounter++)
        {
          Console.WriteLine(theDataSet.Tables[0].Rows[lngCounter]["Title"]);
          Console.WriteLine(theDataSet.Tables[0].Rows[lngCounter]["Author"]);
          Console.WriteLine(theDataSet.Tables[0].Rows[lngCounter]["Publisher"]);
          Console.WriteLine(theDataSet.Tables[0].Rows[lngCounter]["Price"]);
        }
        // lngCounter = theDataSet.Tables(0).Rows.Count 
        
        theDataSet.WriteXml("NewAuthors.xml");
      }
      catch (Exception theException)
      {
        Console.WriteLine("Exception: " + theException.Message);
        Console.WriteLine(theException.ToString());
      }
      finally
      {
        Console.ReadLine();
      }

    }
		// Main()

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning