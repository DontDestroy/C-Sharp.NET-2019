﻿//***
// Action
//   - Definition of a cpSquare
// Created
//   - CopyPaste – 20251222 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251222 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpSquare
  {

    #region "Constructors / Destructors"

    public cpSquare(int intSide, string strDescription)
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - Description(string) (Set)
    //   - Side(int) (Set)
    // Created
    //   - CopyPaste – 20251222 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251222 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Side = intSide;
      Description = strDescription ?? throw new ArgumentNullException(nameof(strDescription));

      // VVDW - Alternative

      // if (strDescription == null)
      // {
      //   throw new ArgumentNullException(nameof(strDescription));
      // }
      // else
      // {
      //   Description = strDescription;
      // }

    }
    // cpSquare(int, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public string Description { get; private set; }
    // cpSquare(int, string)

    public int Side { get; private set; }
    // cpSquare(int, string)

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpSquare

}
// CopyPaste.Learning