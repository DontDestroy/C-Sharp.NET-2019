//***
// Action
//   - Demo of threading, suspending, resuming and abording
// Created
//   - CopyPaste � 20250707 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250707 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Threading;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static Thread thrLotOfA;
    private static Thread thrLotOfB;
    private static Thread thrLotOfC;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void DisplayLotOfA()
      //***
      // Action
      //   - Try to
      //     - Suspend the thread
      //     - Display 10001 times "A"
      //   - On error of state exception
      //     - Show the exception
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        thrLotOfA.Suspend(); 

        for (int lngCounter = 0; lngCounter <= 10000; lngCounter++)
        {
          Console.Write("A");
        }
        // lngCounter = 10001

      }
      catch (ThreadStateException theThreadStateException)
      {
        Console.WriteLine();
        Console.WriteLine("Thread A - Expection. " + theThreadStateException.ToString());
        Console.WriteLine();
      }
      finally
      {
      }

    }
    // DisplayLotOfA()

    public static void DisplayLotOfB()
      //***
      // Action
      //   - Try to
      //     - Display 10001 times "B"
      //   - On error abort exception
      //     - Show that the thread was aborted
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {

        for (int lngCounter = 0; lngCounter <= 10000; lngCounter++)
        {
          Console.Write("B");
        }
        // lngCounter = 10001
      
      }
      catch
      {
        Console.WriteLine();
        Console.Write("Thread B has been aborted");
        Console.WriteLine();
      }
      finally
      {
      }

    }
    // DisplayLotOfB()

    public static void DisplayLotOfC()
      //***
      // Action
      //   - Try to
      //     - Abort thread that displays B
      //     - Display 10001 times "C"
      //       - If thread that displays A is suspended, resume it
      //   - On error of state exception
      //     - Show the exception
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {

        if (thrLotOfB.IsAlive)
        {
          thrLotOfB.Abort();
        }
        else
        {
        }

        for (int lngCounter = 0; lngCounter <= 10000; lngCounter++)
        {

          if (thrLotOfA.ThreadState == ThreadState.Suspended)
          {
            thrLotOfA.Resume();
          }
          else
            // thrLotOfA.ThreadState <> ThreadState.Suspended
          {
          }
          // thrLotOfA.ThreadState = ThreadState.Suspended

          Console.Write("C");
        }
        // lngCounter = 10001

      }
      catch
      {
      }
      finally
      {
      }

    }
    // DisplayLotOfC()

    public static void Main()
      //***
      // Action
      //   - Display 10001 times "A", "B" and "C" using threading
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - DisplayLotOfA()
      //   - DisplayLotOfB()
      //   - DisplayLotOfC()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      thrLotOfA = new Thread(new ThreadStart(DisplayLotOfA));
      thrLotOfB = new Thread(new ThreadStart(DisplayLotOfB));
      thrLotOfC = new Thread(new ThreadStart(DisplayLotOfC));

      thrLotOfA.Start();
      thrLotOfB.Start();
      thrLotOfC.Start();

      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning