﻿//***
// Action
//   - Implementation of cpMatrix
//   - The goal is to demo the creation of an operator
// Created
//   - CopyPaste – 20220531 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220531 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Text;

namespace CopyPaste.Learning.MatrixCalculation
{

  public class cpMatrix
  {

    #region "Constructors / Destructors"

    public cpMatrix(int numberOfRows, int numberOfColumns)
    //***
    // Action
    //   - Constructor with 2 inputs
    //     - Number of rows
    //     - Number of columns
    //   - Number of rows are set
    //   - Number of columns are set
    //   - The matrix is created as a two dimentional table
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - int Columns (Get)
    //   - int Rows (Get)
    //   - Columns(int) (Set)
    //   - Rows(int) (Set)
    // Created
    //   - CopyPaste – 20220531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220531 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Rows = Math.Abs(numberOfRows);
      Columns = Math.Abs(numberOfColumns);

      aMatrix = new int[Rows, Columns];
    }
    // cpMatrix(int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int[,] aMatrix;

    #endregion

    #region "Properties"

    public int Columns { get; set; }
    // cpMatrix +(cpMatrix, cpMatrix)
    // cpMatrix(int, int)
    // string ToString()

    public int Rows { get; set; }
    // cpMatrix +(cpMatrix, cpMatrix)
    // cpMatrix(int, int)
    // string ToString()

    public int this[int theRow, int theColumn]
    {

      get
      //***
      // Action Get
      //   - Getting the value of a certain item in the array (thru indexer)
      //   - Return a position in the array
      // Called by
      //   - cpMatrix +(cpMatrix, cpMatrix)
      //   - string ToString()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220531 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220531 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - Some checks if you are still inside the matrix should be added
      //***
      {
        return this.aMatrix[Math.Abs(theRow), Math.Abs(theColumn)];
      }
      // int this[int, int] (Get)

      set
      //***
      // Action Set
      //   - Setting the value of a certain item in the array (thru indexer)
      //   - Put a value into a position in the array
      // Called by
      //   - cpMatrix +(cpMatrix, cpMatrix)
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220531 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220531 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - Some checks if you are still inside the matrix should be added
      //***
      {
        this.aMatrix[Math.Abs(theRow), Math.Abs(theColumn)] = value;
      }
      // this[int, int](int) (Set)

    }
    // int this[int, int]

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
    //***
    // Action
    //   - Create a new instance of a string builder
    //   - Loop thru the rows of the matrix
    //     - Loop thru the columns of the matrix
    //       - Build the string with the current column of that row
    //     - Build the string with a a new line
    //   - Return the builded string
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - int Columns (Get)
    //   - int Rows (Get)
    //   - int this[int, int] (Get)
    // Created
    //   - CopyPaste – 20220531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220531 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      StringBuilder matrixVisualisation = new StringBuilder();

      for (int theRow = 0; theRow < Rows; theRow++)
      {

        for (int theColumn = 0; theColumn < Columns; theColumn++)
        {
          matrixVisualisation.AppendFormat("{0}\t", this[theRow, theColumn]);
          // matrixVisualisation.AppendFormat("{0}\t", this.aMatrix[theRow, theColumn]);
        }
        // theColumn = Columns

        matrixVisualisation.AppendLine();
      }
      // theRow = Rows

      return matrixVisualisation.ToString();
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private static bool AllOnes(cpMatrix theMatrix)
    //***
    // Action
    //   - Define a result set to true
    //   - Loop thru all the items of the array
    //     - If value of item is different from 1
    //       - Result becomes false
    //       - Exit the loop  
    //     - If not
    //       - Do nothing
    //   - Return result
    // Called by
    //   - bool false(cpMatrix)
    //   - bool true(cpMatrix)
    // Calls
    //   - int Columns (Get)
    //   - int Rows (Get)
    //   - int this[int, int] (Get)
    // Created
    //   - CopyPaste – 20220531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220531 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnResult = true;

      foreach (int matrixItem in theMatrix.aMatrix)
      {

        if (matrixItem != 1)
        {
          blnResult = false;
          break;
        }
        // matrixItem != 1

      }
      // in theMatrix.aMatrix

      return blnResult;
    }
    // bool AllOnes(cpMatrix)

    public static cpMatrix operator +(cpMatrix matrix1, cpMatrix matrix2)
    //***
    // Action
    //   - Given two matrixes
    //     - matrix1
    //     - matrix2
    //   - Create a new instance of a cpMatrix
    //   - Loop thru the rows of the matrix
    //     - Loop thru the columns of the matrix
    //       - Build the string with the current column of that row
    //     - Build the string with a a new line
    //   - Return the builded string
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - int Columns (Get)
    //   - int Rows (Get)
    //   - int this[int, int] (Get)
    //   - this[int, int](int) (Set)
    // Created
    //   - CopyPaste – 20220531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220531 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - There must be a check if both matrixes have the same size
    //***
    {
      cpMatrix matrixResult = new cpMatrix(matrix1.Rows, matrix1.Columns);

      for (int theRow = 0; theRow < matrixResult.Rows; theRow++)
      {

          for (int theColumn = 0; theColumn < matrixResult.Columns; theColumn++)
          {
            matrixResult[theRow, theColumn] = matrix1[theRow, theColumn] + matrix2[theRow, theColumn];
          }
        // theColumn = matrixResult.Columns

      }
      // theRow = matrixResult.Rows

      return matrixResult;
    }
    // cpMatrix +(cpMatrix, cpMatrix)

    public static bool operator false(cpMatrix matrix1)
    //***
    // Action
    //   - False is true if the matrix contains one item that is not one
    //   - Return if there are not all ones
    // Called by
    //   - 
    // Calls
    //   - bool AllOnes(cpMatrix)
    // Created
    //   - CopyPaste – 20220531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220531 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return AllOnes(matrix1);
    }
    // bool false(cpMatrix)

    public static bool operator true(cpMatrix matrix1)
    //***
    // Action
    //   - True is true if the matrix contains all ones
    //   - Return if there are all ones
    // Called by
    //   - 
    // Calls
    //   - bool AllOnes(cpMatrix)
    // Created
    //   - CopyPaste – 20220531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220531 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return AllOnes(matrix1);
    }
    // bool true(cpMatrix)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpMatrix

}
// CopyPaste.Learning.MatrixCalculation