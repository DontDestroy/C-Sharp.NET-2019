﻿//***
// Action
//   - Implementation of a TwoBlockStrategy
// Created
//   - CopyPaste – 20251028 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251028 – VVDW
// Proposal (To Do)
//   -
//***

using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpTwoBlockStrategy : cpinfStrategy
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void DoIt(cpCopyPasteRobot aRobot)
    //***
    // Action
    //   - Implementation of DoIt
    //     - Two block moves forward and turn left
    // Called by
    //   - cpProgram.BlockWalker()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      aRobot.move();
      aRobot.move();
      aRobot.turnLeft();
    }
    // DoIt(cpCopyPasteRobot)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpTwoBlockStrategy

}
// cpKarelTheRobot