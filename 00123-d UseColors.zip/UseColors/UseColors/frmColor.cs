//***
// Action
//   - Demo of color dialog
// Created
//   - CopyPaste � 20240715 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240715 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmColor: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtText;
    internal System.Windows.Forms.Button cmdBack;
    internal System.Windows.Forms.Button cmdFore;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmColor));
      this.txtText = new System.Windows.Forms.TextBox();
      this.cmdBack = new System.Windows.Forms.Button();
      this.cmdFore = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(29, 64);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(234, 188);
      this.txtText.TabIndex = 5;
      this.txtText.Text = "";
      // 
      // cmdBack
      // 
      this.cmdBack.Location = new System.Drawing.Point(179, 24);
      this.cmdBack.Name = "cmdBack";
      this.cmdBack.TabIndex = 4;
      this.cmdBack.Text = "Background";
      this.cmdBack.Click += new System.EventHandler(this.cmdBack_Click);
      // 
      // cmdFore
      // 
      this.cmdFore.Location = new System.Drawing.Point(29, 24);
      this.cmdFore.Name = "cmdFore";
      this.cmdFore.TabIndex = 3;
      this.cmdFore.Text = "Foreground";
      this.cmdFore.Click += new System.EventHandler(this.cmdFore_Click);
      // 
      // frmColor
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.txtText);
      this.Controls.Add(this.cmdBack);
      this.Controls.Add(this.cmdFore);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmColor";
      this.Text = "Colors";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmColor'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240715 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmColor()
      //***
      // Action
      //   - Create instance of 'frmColor'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240715 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      mdlgColor.CustomColors = new Int32[]
        {0xFF00FF, 0xFF0000, 0xF0F0F0, 0xF0F0F0, 
         0xAAAAAA, 0xBBBBBB, 0xCCCCCC, 0xDDDDDD, 
         0xEEEEEE, 0xAAA0A0, 0xBBB0B0, 0xCCC0C0, 
         0xDDD0D0, 0x111111, 0x333333, 0x888888};
    }
    // frmColor()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    ColorDialog mdlgColor = new ColorDialog();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdBack_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the color dialog
      //   - If clicked on OK
      //     - The choosen color becomes the backcolor of the textbox
      //   - If not
      //     - Nothing happens
      // Called by
      //   - User action (Clicking a buttonb)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (mdlgColor.ShowDialog() == DialogResult.OK)
      {
        txtText.BackColor = mdlgColor.Color;
      }
      else
        // mdlgColor.ShowDialog() <> DialogResult.OK
      {
      }
      // mdlgColor.ShowDialog() = DialogResult.OK
    
    }
    // cmdBack_Click(System.Object, System.EventArgs) Handles cmdBack.Click

    private void cmdFore_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the color dialog
      //   - If clicked on OK
      //     - The choosen color becomes the forecolor of the textbox
      //   - If not
      //     - Nothing happens
      // Called by
      //   - User action (Clicking a buttonb)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (mdlgColor.ShowDialog() == DialogResult.OK)
      {
        txtText.ForeColor = mdlgColor.Color;
      }
      else
        // mdlgColor.ShowDialog() <> DialogResult.OK
      {
      }
      // mdlgColor.ShowDialog() = DialogResult.OK

    }
    // cmdFore_Click(System.Object, System.EventArgs) Handles cmdFore.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmColor
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmColor()
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240715 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmColor());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmColor

}
// CopyPaste.Learning