//***
// Action
//   - Testroutine for cpiEmployee and cpSalaried
// Created
//   - CopyPaste � 20240628 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240628 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define 2 instances of cpSalaried
      //   - Define one instance of cpiEmployee
      //   - Set the name and salary of first salaried
      //   - Show information of first salaried
      //   - Convert the first salaried to the instance cpiEmployee
      //   - Show the information of the instance of cpiEmployee
      //   - Convert the instance of cpiEmployee to the second salaried 
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpSalaried.Name(string) (Set)
      //   - cpSalaried()
      //   - cpSalaried.Salary(decimal) (Set)
      //   - decimal cpSalaried.Salary (Get)
      //   - string cpSalaried.Name (Get)
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpSalaried cpFirstEmployee = new cpSalaried();
      cpSalaried cpSecondEmployee = new cpSalaried();
      cpiEmployee cpEmployee;

      cpFirstEmployee.Name = "John Doe";
      cpFirstEmployee.Salary = 30000;

      Console.WriteLine(cpFirstEmployee.Name + " - " + cpFirstEmployee.Salary);

      cpEmployee = (cpiEmployee)cpFirstEmployee;
      Console.WriteLine(cpEmployee.Name + " - " + cpEmployee.Salary);

      cpSecondEmployee = (cpSalaried)cpEmployee;
      Console.WriteLine(cpSecondEmployee.Name + " - " + cpSecondEmployee.Salary);
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning