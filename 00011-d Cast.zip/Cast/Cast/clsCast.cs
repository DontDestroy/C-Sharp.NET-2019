//***
// Action
//   - Casting values into variables of different types
// Created
//   - CopyPaste � 20220128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220128 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Cast
{

  class cpCast
	{

    static void Main()
    //***
    // Action
    //   - Define 4 variables
    //   - Initialize variables
    //   - Write values at the console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(short)
    //   - System.Console.WriteLine(single)
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   - Uncomment some code and try again
    //***
    {
      byte bytLittle;
      double dblBig = 0.123456789;
      float fltLittle;
      int intBig = 10000;
      
      bytLittle = (byte) intBig;
      fltLittle = (float) dblBig;

      Console.WriteLine(intBig + " becomes " + bytLittle);
      Console.WriteLine(dblBig + " becomes " + fltLittle);

      // bytLittle = Convert.ToByte(intBig);
      // fltLittle = Convert.ToSingle(dblBig);

      // Console.WriteLine(intBig + " converts to " + bytLittle);
      // Console.WriteLine(dblBig + " converts to " + fltLittle);

      Console.ReadLine();
    }
    // Main()

  }
  // cpCast

}
// Cast