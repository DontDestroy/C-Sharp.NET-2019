//***
// Action
//   - Startup routine of the duck game
// Created
//   - CopyPaste � 20240726 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240726 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Game.Duck.Library;

namespace CopyPaste.Game.Duck
{

	internal static class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		///  The main entry point for the application
		/// </summary>
		[STAThreadAttribute]
		public static void Main()
		//***
		// Action
		//   - Start application
		//   - Depending on the choice
		//     - Showing frmDuckGame
		//     - Showing frmDuckGameTryout
		// Called by
		//   - User action (Starting the application)
		// Calls
		//   - frmDuckGame()
		//   - frmDuckGameTryout()
		// Created
		//   - CopyPaste � 20240726 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20240726 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			ApplicationConfiguration.Initialize();
			Application.Run(new frmDuckGame());
			// Application.Run(new frmDuckGameTryout());
		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#Region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.Game.Duck