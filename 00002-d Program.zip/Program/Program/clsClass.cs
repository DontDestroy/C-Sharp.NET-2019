//***
// Action
//   - Show message
// Created
//   - CopyPaste � 20211018 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20211018 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Program
{

  class cpClass
	{

    static void Main()
    //***
    // Action
    //   - Show message on the console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(String)
    // Created
    //   - CopyPaste � 20211018 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20211018 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("My first C# Program");
      Console.ReadLine();
    }
    // Main()

  }
  // cpClass

}
// Program