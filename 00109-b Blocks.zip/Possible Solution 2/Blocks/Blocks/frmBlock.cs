//***
// Action
//   - A block game
//   - Working with properties (Get and Set) and methods in a class
//   - Possible Solution 2
// Created
//   - CopyPaste � 20240214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240214 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Learning.Games;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBlock: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.IContainer components;
    internal System.Windows.Forms.Timer tmrTimer;
    internal System.Windows.Forms.Panel panMovingArea;
    internal System.Windows.Forms.Label lblScore;
    internal System.Windows.Forms.Label lblLives;
    internal System.Windows.Forms.PictureBox picBall;
    internal System.Windows.Forms.PictureBox picBlue05;
    internal System.Windows.Forms.PictureBox picBlue04;
    internal System.Windows.Forms.PictureBox picBlue03;
    internal System.Windows.Forms.PictureBox picBlue02;
    internal System.Windows.Forms.PictureBox picBlue01;
    internal System.Windows.Forms.PictureBox picGreen05;
    internal System.Windows.Forms.PictureBox picGreen04;
    internal System.Windows.Forms.PictureBox picGreen03;
    internal System.Windows.Forms.PictureBox picGreen02;
    internal System.Windows.Forms.PictureBox picGreen01;
    internal System.Windows.Forms.PictureBox picYellow05;
    internal System.Windows.Forms.PictureBox picYellow04;
    internal System.Windows.Forms.PictureBox picYellow03;
    internal System.Windows.Forms.PictureBox picYellow02;
    internal System.Windows.Forms.PictureBox picYellow01;
    internal System.Windows.Forms.PictureBox picRed05;
    internal System.Windows.Forms.PictureBox picRed04;
    internal System.Windows.Forms.PictureBox picRed03;
    internal System.Windows.Forms.PictureBox picRed02;
    internal System.Windows.Forms.PictureBox picPaddle;
    internal System.Windows.Forms.PictureBox picRed01;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBlock));
      this.tmrTimer = new System.Windows.Forms.Timer(this.components);
      this.panMovingArea = new System.Windows.Forms.Panel();
      this.lblScore = new System.Windows.Forms.Label();
      this.lblLives = new System.Windows.Forms.Label();
      this.picBall = new System.Windows.Forms.PictureBox();
      this.picBlue05 = new System.Windows.Forms.PictureBox();
      this.picBlue04 = new System.Windows.Forms.PictureBox();
      this.picBlue03 = new System.Windows.Forms.PictureBox();
      this.picBlue02 = new System.Windows.Forms.PictureBox();
      this.picBlue01 = new System.Windows.Forms.PictureBox();
      this.picGreen05 = new System.Windows.Forms.PictureBox();
      this.picGreen04 = new System.Windows.Forms.PictureBox();
      this.picGreen03 = new System.Windows.Forms.PictureBox();
      this.picGreen02 = new System.Windows.Forms.PictureBox();
      this.picGreen01 = new System.Windows.Forms.PictureBox();
      this.picYellow05 = new System.Windows.Forms.PictureBox();
      this.picYellow04 = new System.Windows.Forms.PictureBox();
      this.picYellow03 = new System.Windows.Forms.PictureBox();
      this.picYellow02 = new System.Windows.Forms.PictureBox();
      this.picYellow01 = new System.Windows.Forms.PictureBox();
      this.picRed05 = new System.Windows.Forms.PictureBox();
      this.picRed04 = new System.Windows.Forms.PictureBox();
      this.picRed03 = new System.Windows.Forms.PictureBox();
      this.picRed02 = new System.Windows.Forms.PictureBox();
      this.picPaddle = new System.Windows.Forms.PictureBox();
      this.picRed01 = new System.Windows.Forms.PictureBox();
      this.panMovingArea.SuspendLayout();
      this.SuspendLayout();
      // 
      // tmrTimer
      // 
      this.tmrTimer.Interval = 20;
      this.tmrTimer.Tick += new System.EventHandler(this.tmrTimer_Tick);
      // 
      // panMovingArea
      // 
      this.panMovingArea.Controls.Add(this.lblScore);
      this.panMovingArea.Controls.Add(this.lblLives);
      this.panMovingArea.Controls.Add(this.picBall);
      this.panMovingArea.Controls.Add(this.picBlue05);
      this.panMovingArea.Controls.Add(this.picBlue04);
      this.panMovingArea.Controls.Add(this.picBlue03);
      this.panMovingArea.Controls.Add(this.picBlue02);
      this.panMovingArea.Controls.Add(this.picBlue01);
      this.panMovingArea.Controls.Add(this.picGreen05);
      this.panMovingArea.Controls.Add(this.picGreen04);
      this.panMovingArea.Controls.Add(this.picGreen03);
      this.panMovingArea.Controls.Add(this.picGreen02);
      this.panMovingArea.Controls.Add(this.picGreen01);
      this.panMovingArea.Controls.Add(this.picYellow05);
      this.panMovingArea.Controls.Add(this.picYellow04);
      this.panMovingArea.Controls.Add(this.picYellow03);
      this.panMovingArea.Controls.Add(this.picYellow02);
      this.panMovingArea.Controls.Add(this.picYellow01);
      this.panMovingArea.Controls.Add(this.picRed05);
      this.panMovingArea.Controls.Add(this.picRed04);
      this.panMovingArea.Controls.Add(this.picRed03);
      this.panMovingArea.Controls.Add(this.picRed02);
      this.panMovingArea.Controls.Add(this.picPaddle);
      this.panMovingArea.Controls.Add(this.picRed01);
      this.panMovingArea.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panMovingArea.Location = new System.Drawing.Point(0, 0);
      this.panMovingArea.Name = "panMovingArea";
      this.panMovingArea.Size = new System.Drawing.Size(520, 464);
      this.panMovingArea.TabIndex = 3;
      this.panMovingArea.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panMovingArea_MouseMove);
      // 
      // lblScore
      // 
      this.lblScore.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblScore.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblScore.Location = new System.Drawing.Point(408, 8);
      this.lblScore.Name = "lblScore";
      this.lblScore.Size = new System.Drawing.Size(104, 24);
      this.lblScore.TabIndex = 45;
      this.lblScore.Text = "Score: 0";
      this.lblScore.TextAlign = System.Drawing.ContentAlignment.TopRight;
      // 
      // lblLives
      // 
      this.lblLives.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblLives.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblLives.Location = new System.Drawing.Point(8, 8);
      this.lblLives.Name = "lblLives";
      this.lblLives.Size = new System.Drawing.Size(104, 24);
      this.lblLives.TabIndex = 44;
      this.lblLives.Text = "Lives: 3";
      // 
      // picBall
      // 
      this.picBall.BackColor = System.Drawing.Color.White;
      this.picBall.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBall.Location = new System.Drawing.Point(248, 392);
      this.picBall.Name = "picBall";
      this.picBall.Size = new System.Drawing.Size(16, 16);
      this.picBall.TabIndex = 43;
      this.picBall.TabStop = false;
      // 
      // picBlue05
      // 
      this.picBlue05.BackColor = System.Drawing.Color.Blue;
      this.picBlue05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBlue05.Location = new System.Drawing.Point(408, 184);
      this.picBlue05.Name = "picBlue05";
      this.picBlue05.Size = new System.Drawing.Size(88, 32);
      this.picBlue05.TabIndex = 42;
      this.picBlue05.TabStop = false;
      // 
      // picBlue04
      // 
      this.picBlue04.BackColor = System.Drawing.Color.Blue;
      this.picBlue04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBlue04.Location = new System.Drawing.Point(312, 184);
      this.picBlue04.Name = "picBlue04";
      this.picBlue04.Size = new System.Drawing.Size(88, 32);
      this.picBlue04.TabIndex = 41;
      this.picBlue04.TabStop = false;
      // 
      // picBlue03
      // 
      this.picBlue03.BackColor = System.Drawing.Color.Blue;
      this.picBlue03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBlue03.Location = new System.Drawing.Point(216, 184);
      this.picBlue03.Name = "picBlue03";
      this.picBlue03.Size = new System.Drawing.Size(88, 32);
      this.picBlue03.TabIndex = 40;
      this.picBlue03.TabStop = false;
      // 
      // picBlue02
      // 
      this.picBlue02.BackColor = System.Drawing.Color.Blue;
      this.picBlue02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBlue02.Location = new System.Drawing.Point(120, 184);
      this.picBlue02.Name = "picBlue02";
      this.picBlue02.Size = new System.Drawing.Size(88, 32);
      this.picBlue02.TabIndex = 39;
      this.picBlue02.TabStop = false;
      // 
      // picBlue01
      // 
      this.picBlue01.BackColor = System.Drawing.Color.Blue;
      this.picBlue01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBlue01.Location = new System.Drawing.Point(24, 184);
      this.picBlue01.Name = "picBlue01";
      this.picBlue01.Size = new System.Drawing.Size(88, 32);
      this.picBlue01.TabIndex = 38;
      this.picBlue01.TabStop = false;
      // 
      // picGreen05
      // 
      this.picGreen05.BackColor = System.Drawing.Color.Lime;
      this.picGreen05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picGreen05.Location = new System.Drawing.Point(408, 144);
      this.picGreen05.Name = "picGreen05";
      this.picGreen05.Size = new System.Drawing.Size(88, 32);
      this.picGreen05.TabIndex = 37;
      this.picGreen05.TabStop = false;
      // 
      // picGreen04
      // 
      this.picGreen04.BackColor = System.Drawing.Color.Lime;
      this.picGreen04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picGreen04.Location = new System.Drawing.Point(312, 144);
      this.picGreen04.Name = "picGreen04";
      this.picGreen04.Size = new System.Drawing.Size(88, 32);
      this.picGreen04.TabIndex = 36;
      this.picGreen04.TabStop = false;
      // 
      // picGreen03
      // 
      this.picGreen03.BackColor = System.Drawing.Color.Lime;
      this.picGreen03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picGreen03.Location = new System.Drawing.Point(216, 144);
      this.picGreen03.Name = "picGreen03";
      this.picGreen03.Size = new System.Drawing.Size(88, 32);
      this.picGreen03.TabIndex = 35;
      this.picGreen03.TabStop = false;
      // 
      // picGreen02
      // 
      this.picGreen02.BackColor = System.Drawing.Color.Lime;
      this.picGreen02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picGreen02.Location = new System.Drawing.Point(120, 144);
      this.picGreen02.Name = "picGreen02";
      this.picGreen02.Size = new System.Drawing.Size(88, 32);
      this.picGreen02.TabIndex = 34;
      this.picGreen02.TabStop = false;
      // 
      // picGreen01
      // 
      this.picGreen01.BackColor = System.Drawing.Color.Lime;
      this.picGreen01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picGreen01.Location = new System.Drawing.Point(24, 144);
      this.picGreen01.Name = "picGreen01";
      this.picGreen01.Size = new System.Drawing.Size(88, 32);
      this.picGreen01.TabIndex = 33;
      this.picGreen01.TabStop = false;
      // 
      // picYellow05
      // 
      this.picYellow05.BackColor = System.Drawing.Color.Yellow;
      this.picYellow05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picYellow05.Location = new System.Drawing.Point(408, 104);
      this.picYellow05.Name = "picYellow05";
      this.picYellow05.Size = new System.Drawing.Size(88, 32);
      this.picYellow05.TabIndex = 32;
      this.picYellow05.TabStop = false;
      // 
      // picYellow04
      // 
      this.picYellow04.BackColor = System.Drawing.Color.Yellow;
      this.picYellow04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picYellow04.Location = new System.Drawing.Point(312, 104);
      this.picYellow04.Name = "picYellow04";
      this.picYellow04.Size = new System.Drawing.Size(88, 32);
      this.picYellow04.TabIndex = 31;
      this.picYellow04.TabStop = false;
      // 
      // picYellow03
      // 
      this.picYellow03.BackColor = System.Drawing.Color.Yellow;
      this.picYellow03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picYellow03.Location = new System.Drawing.Point(216, 104);
      this.picYellow03.Name = "picYellow03";
      this.picYellow03.Size = new System.Drawing.Size(88, 32);
      this.picYellow03.TabIndex = 30;
      this.picYellow03.TabStop = false;
      // 
      // picYellow02
      // 
      this.picYellow02.BackColor = System.Drawing.Color.Yellow;
      this.picYellow02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picYellow02.Location = new System.Drawing.Point(120, 104);
      this.picYellow02.Name = "picYellow02";
      this.picYellow02.Size = new System.Drawing.Size(88, 32);
      this.picYellow02.TabIndex = 29;
      this.picYellow02.TabStop = false;
      // 
      // picYellow01
      // 
      this.picYellow01.BackColor = System.Drawing.Color.Yellow;
      this.picYellow01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picYellow01.Location = new System.Drawing.Point(24, 104);
      this.picYellow01.Name = "picYellow01";
      this.picYellow01.Size = new System.Drawing.Size(88, 32);
      this.picYellow01.TabIndex = 28;
      this.picYellow01.TabStop = false;
      // 
      // picRed05
      // 
      this.picRed05.BackColor = System.Drawing.Color.Red;
      this.picRed05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picRed05.Location = new System.Drawing.Point(408, 64);
      this.picRed05.Name = "picRed05";
      this.picRed05.Size = new System.Drawing.Size(88, 32);
      this.picRed05.TabIndex = 27;
      this.picRed05.TabStop = false;
      // 
      // picRed04
      // 
      this.picRed04.BackColor = System.Drawing.Color.Red;
      this.picRed04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picRed04.Location = new System.Drawing.Point(312, 64);
      this.picRed04.Name = "picRed04";
      this.picRed04.Size = new System.Drawing.Size(88, 32);
      this.picRed04.TabIndex = 26;
      this.picRed04.TabStop = false;
      // 
      // picRed03
      // 
      this.picRed03.BackColor = System.Drawing.Color.Red;
      this.picRed03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picRed03.Location = new System.Drawing.Point(216, 64);
      this.picRed03.Name = "picRed03";
      this.picRed03.Size = new System.Drawing.Size(88, 32);
      this.picRed03.TabIndex = 25;
      this.picRed03.TabStop = false;
      // 
      // picRed02
      // 
      this.picRed02.BackColor = System.Drawing.Color.Red;
      this.picRed02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picRed02.Location = new System.Drawing.Point(120, 64);
      this.picRed02.Name = "picRed02";
      this.picRed02.Size = new System.Drawing.Size(88, 32);
      this.picRed02.TabIndex = 24;
      this.picRed02.TabStop = false;
      // 
      // picPaddle
      // 
      this.picPaddle.BackColor = System.Drawing.Color.White;
      this.picPaddle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picPaddle.Location = new System.Drawing.Point(208, 432);
      this.picPaddle.Name = "picPaddle";
      this.picPaddle.Size = new System.Drawing.Size(96, 16);
      this.picPaddle.TabIndex = 23;
      this.picPaddle.TabStop = false;
      // 
      // picRed01
      // 
      this.picRed01.BackColor = System.Drawing.Color.Red;
      this.picRed01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picRed01.Location = new System.Drawing.Point(24, 64);
      this.picRed01.Name = "picRed01";
      this.picRed01.Size = new System.Drawing.Size(88, 32);
      this.picRed01.TabIndex = 22;
      this.picRed01.TabStop = false;
      // 
      // frmBlock
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(520, 464);
      this.Controls.Add(this.panMovingArea);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBlock";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Blocks";
      this.Load += new System.EventHandler(this.frmBlock_Load);
      this.panMovingArea.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBlock'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBlock()
      //***
      // Action
      //   - Create instance of 'frmBlock'
      //   - Initialize the components of that form
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmBlock()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpBlockGame mthecpBlockGame = new cpBlockGame(2, 0, 20);
    private cpCollision mcpCollision = new cpCollision();
    private cpMove mcpBall;
    private cpMove mcpBlue01;
    private cpMove mcpBlue02;
    private cpMove mcpBlue03;
    private cpMove mcpBlue04;
    private cpMove mcpBlue05;
    private cpMove mcpGreen01;
    private cpMove mcpGreen02;
    private cpMove mcpGreen03;
    private cpMove mcpGreen04;
    private cpMove mcpGreen05;
    private cpMove mcpPaddle;
    private cpMove mcpRed01;
    private cpMove mcpRed02;
    private cpMove mcpRed03;
    private cpMove mcpRed04;
    private cpMove mcpRed05;
    private cpMove mcpYellow01;
    private cpMove mcpYellow02;
    private cpMove mcpYellow03;
    private cpMove mcpYellow04;
    private cpMove mcpYellow05;
    private Point mpntStartingPosition;
    private Rectangle mrecMovingArea;

    #endregion

    #region "Properties"

    private Rectangle MovingArea
    {
      
      get
        //***
        // Action Get
        //   - Return the MovingArea for the moving object (mrecMovingArea)
        // Called by
        //   - frmBlock.frmBlock_Load(System.Object, System.EventArgs) Handles this.Load
        //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mrecMovingArea;
      }
      // Rectangle MovingArea (Get)
 
      set
        //***
        // Action Set
        //   - Set the MovingArea for the moving object (mrecMovingArea becomes value)
        // Called by
        //   - frmBlock.frmBlock_Load(System.Object, System.EventArgs) Handles this.Load
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mrecMovingArea = value;
      }
      // MovingArea(Rectangle) (Set)

    }
    // Rectangle MovingArea

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmBlock_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Preparing the startup of the game
      //   - Determine a moving area (movements can't go outside this)
      //   - Determine the movement of the ball
      //   - Determine the starting position of the ball
      //   - Paddle does not move
      //   - All Red, Yellow, Green and Blue boxes don't move
      //   - Show the lives left
      //   - Show the score
      //   - Enable the timer
      // Called by
      //   - User action, starting the application (when this form is marked as startup object)
      // Calls
      //   - cpMove(Control, Rectangle, double, int)
      //   - int cpBlockGame.Lives (Get)
      //   - int cpBlockGame.Score (Get)
      //   - MovingArea(Rectangle) (Set)
      //   - Rectangle MovingArea (Get)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MovingArea = new Rectangle(0, 0, panMovingArea.Width, panMovingArea.Height);

      mcpBall = new cpMove(picBall, MovingArea, 60, 3);
      mpntStartingPosition = new Point(picBall.Left, picBall.Top);
      mcpPaddle = new cpMove(picPaddle, MovingArea, 0, 0);
      mcpRed01 = new cpMove(picRed01, MovingArea, 0, 0);
      mcpRed02 = new cpMove(picRed02, MovingArea, 0, 0);
      mcpRed03 = new cpMove(picRed03, MovingArea, 0, 0);
      mcpRed04 = new cpMove(picRed04, MovingArea, 0, 0);
      mcpRed05 = new cpMove(picRed05, MovingArea, 0, 0);
      mcpYellow01 = new cpMove(picYellow01, MovingArea, 0, 0);
      mcpYellow02 = new cpMove(picYellow02, MovingArea, 0, 0);
      mcpYellow03 = new cpMove(picYellow03, MovingArea, 0, 0);
      mcpYellow04 = new cpMove(picYellow04, MovingArea, 0, 0);
      mcpYellow05 = new cpMove(picYellow05, MovingArea, 0, 0);
      mcpGreen01 = new cpMove(picGreen01, MovingArea, 0, 0);
      mcpGreen02 = new cpMove(picGreen02, MovingArea, 0, 0);
      mcpGreen03 = new cpMove(picGreen03, MovingArea, 0, 0);
      mcpGreen04 = new cpMove(picGreen04, MovingArea, 0, 0);
      mcpGreen05 = new cpMove(picGreen05, MovingArea, 0, 0);
      mcpBlue01 = new cpMove(picBlue01, MovingArea, 0, 0);
      mcpBlue02 = new cpMove(picBlue02, MovingArea, 0, 0);
      mcpBlue03 = new cpMove(picBlue03, MovingArea, 0, 0);
      mcpBlue04 = new cpMove(picBlue04, MovingArea, 0, 0);
      mcpBlue05 = new cpMove(picBlue05, MovingArea, 0, 0);

      lblLives.Text = "Lives: " + mthecpBlockGame.Lives;
      lblScore.Text = "Score: " + mthecpBlockGame.Score;
      tmrTimer.Enabled = true;
    }
    // frmBlock_Load(System.Object, System.EventArgs) Handles this.Load

    private void panMovingArea_MouseMove(System.Object theSender, System.Windows.Forms.MouseEventArgs theMouseEventArguments)
      //***
      // Action
      //   - Place the position of the paddle where the mouse pointer is, horizontally
      // Called by
      //   - User action (Moving the mouse over the form)
      // Calls
      //   - cpMove.MovingObject(Control) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      picPaddle.Left = theMouseEventArguments.X - picPaddle.Width / 2;
      mcpPaddle.MovingObject = picPaddle;
    }
    // panMovingArea_MouseMove(System.Object, System.Windows.Forms.MouseEventArgs) Handles panMovingArea.MouseMove
    
    private void tmrTimer_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Actions to be taken every time the games progresses
      //   - Move the ball
      //   - All blocks are checked on collision
      //   - Stop timer
      //   - If the ball passes the paddle
      //     - Update the lives
      //     - Set LostBall to True
      //     - If number of lives is lower than 1
      //       - Show messagebox that you lost the game
      //     - If Not
      //       - Show messagebox that you have lost a live
      //       - Put ball in starting position
      //       - Enable timer
      //   - If Not
      //     - If GameFinished
      //       - Show messagebox that you have finished the game
      //     - If Not
      //       - Enable timer
      // Called by
      //   - Program action (The beating heart of the game)
      // Calls
      //   - bool cpBlockGame.GameFinished (Get)
      //   - CheckCollision()
      //   - cpBlockGame.LostBall(bool) (Set)
      //   - cpMove.Move()
      //   - cpMove(Control, Rectangle, double, int)
      //   - int cpBlockGame.Lives (Get)
      //   - Rectangle MovingArea (Get)
      //   - UpdateLives()
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mcpBall.Move();
      CheckCollision();
      tmrTimer.Enabled = false;

      if (picBall.Top > picPaddle.Top)
      {
        UpdateLives();
        mthecpBlockGame.LostBall = true;
        
        if (mthecpBlockGame.Lives < 1)
        {
          MessageBox.Show("OH NO! You have lost the game", "GAME OVER");
        }
        else
          // Lives >= 1
        {
          MessageBox.Show("OH NO! You have lost a live", "BE CAREFULL");
          picBall.Left = mpntStartingPosition.X;
          picBall.Top = mpntStartingPosition.Y;
          mcpBall = new cpMove(picBall, MovingArea, 60, 3);
          tmrTimer.Enabled = true;
        }
        // Lives < 1

      }
      else
        // picBall.Top <= picPaddle.Top
      {
        
        if (mthecpBlockGame.GameFinished)
        {
          MessageBox.Show("You finished the game!", "CONGRATULATIONS");
        }
        else
          // Not mthecpBlockGame.GameFinished
        {
          tmrTimer.Enabled = true;
        }
        // mthecpBlockGame.GameFinished 

      }
      // picBall.Top > picPaddle.Top

    }
    // tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void CheckCollision()
      //***
      // Action
      //   - Check if the ball is hitting something
      //   - If the ball hits the paddle
      //     - Update the score
      //   - If Not
      //     - Do Nothing
      //   - If the ball hits another object (Red, Yellow, Green, Blue box)
      //     - Box that was hit, becomes invisible
      //     - 1 is subtracted of the total number of blocks left
      //     - Update the score
      //   - If Not
      //     - Do Nothing
      // Called by
      //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - bool cpCollision.Hit(cpMove, cpMove)
      //   - int cpBlockGame.NumberOfBlocks (Get)
      //   - cpBlockGame.NumberOfBlocks(int) (Set)
      //   - UpdateScore()
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (mcpCollision.Hit(mcpBall, mcpPaddle))
      {
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpPaddle)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpPaddle) 

      if (mcpCollision.Hit(mcpBall, mcpRed01))
      {
        picRed01.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpRed01)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpRed01)

      if (mcpCollision.Hit(mcpBall, mcpRed02))
      {
        picRed02.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpRed02)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpRed02)

      if (mcpCollision.Hit(mcpBall, mcpRed03))
      {
        picRed03.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpRed03)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpRed03)

      if (mcpCollision.Hit(mcpBall, mcpRed04))
      {
        picRed04.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpRed04)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpRed04)

      if (mcpCollision.Hit(mcpBall, mcpRed05))
      {
        picRed05.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpRed05)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpRed05)

      if (mcpCollision.Hit(mcpBall, mcpYellow01))
      {
        picYellow01.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpYellow01)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpYellow01)

      if (mcpCollision.Hit(mcpBall, mcpYellow02))
      {
        picYellow02.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpYellow02)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpYellow02)

      if (mcpCollision.Hit(mcpBall, mcpYellow03))
      {
        picYellow03.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpYellow03)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpYellow03)

      if (mcpCollision.Hit(mcpBall, mcpYellow04))
      {
        picYellow04.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpYellow04)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpYellow04)

      if (mcpCollision.Hit(mcpBall, mcpYellow05))
      {
        picYellow05.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpYellow05)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpYellow05)

      if (mcpCollision.Hit(mcpBall, mcpGreen01))
      {
        picGreen01.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpGreen01)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpGreen01)

      if (mcpCollision.Hit(mcpBall, mcpGreen02))
      {
        picGreen02.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpGreen02)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpGreen02)

      if (mcpCollision.Hit(mcpBall, mcpGreen03))
      {
        picGreen03.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpGreen03)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpGreen03)

      if (mcpCollision.Hit(mcpBall, mcpGreen04))
      {
        picGreen04.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpGreen04)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpGreen04)

      if (mcpCollision.Hit(mcpBall, mcpGreen05))
      {
        picGreen05.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpGreen05)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpGreen05)

      if (mcpCollision.Hit(mcpBall, mcpBlue01))
      {
        picBlue01.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpBlue01)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpBlue01)

      if (mcpCollision.Hit(mcpBall, mcpBlue02))
      {
        picBlue02.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpBlue02)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpBlue02)

      if (mcpCollision.Hit(mcpBall, mcpBlue03))
      {
        picBlue03.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpBlue03)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpBlue03)

      if (mcpCollision.Hit(mcpBall, mcpBlue04))
      {
        picBlue04.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpBlue04)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpBlue04)

      if (mcpCollision.Hit(mcpBall, mcpBlue05))
      {
        picBlue05.Visible = false;
        mthecpBlockGame.NumberOfBlocks -= 1;
        UpdateScore();
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpBlue05)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpBlue05)

    }
    // CheckCollision()

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmBlock
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmBlock());
    }
    // Main() 

    public void UpdateLives()
      //***
      // Action
      //   - Subtract 1 from Lives
      //   - Show Number of Lives
      // Called by
      //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - cpBlockGame.Lives(int) (Set)
      //   - int cpBlockGame.Lives (Get)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mthecpBlockGame.Lives -= 1;
      lblLives.Text = "Lives: " + mthecpBlockGame.Lives;
    }
    // UpdateLives()

    public void UpdateScore()
      //***
      // Action
      //   - Add 10 to Score
      //   - Show Score
      // Called by
      //   - CheckCollision()
      // Calls
      //   - cpBlockGame.Score(int) (Set)
      //   - int cpBlockGame.Score (Get)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mthecpBlockGame.Score += 10;
      lblScore.Text = "Score: " + mthecpBlockGame.Score;
    }
    // UpdateScore()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBlock

}
// CopyPaste.Learning