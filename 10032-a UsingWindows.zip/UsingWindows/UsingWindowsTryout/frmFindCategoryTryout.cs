//***
// Action
//   - Demo to find a record (with the key or the text)
// Created
//   - CopyPaste � 20260113 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260113 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFindCategoryTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtName;
    internal System.Windows.Forms.Label lblName;
    internal System.Windows.Forms.TextBox txtKey;
    internal System.Windows.Forms.Label lblKey;
    internal System.Windows.Forms.Button cmdCancel;
    internal System.Windows.Forms.Button cmdFind;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFindCategoryTryout));
      this.txtName = new System.Windows.Forms.TextBox();
      this.lblName = new System.Windows.Forms.Label();
      this.txtKey = new System.Windows.Forms.TextBox();
      this.lblKey = new System.Windows.Forms.Label();
      this.cmdCancel = new System.Windows.Forms.Button();
      this.cmdFind = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // txtName
      // 
      this.txtName.Location = new System.Drawing.Point(56, 40);
      this.txtName.Name = "txtName";
      this.txtName.Size = new System.Drawing.Size(200, 20);
      this.txtName.TabIndex = 9;
      this.txtName.Text = "";
      // 
      // lblName
      // 
      this.lblName.AutoSize = true;
      this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblName.Location = new System.Drawing.Point(8, 40);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(39, 16);
      this.lblName.TabIndex = 8;
      this.lblName.Text = "Name:";
      // 
      // txtKey
      // 
      this.txtKey.Location = new System.Drawing.Point(56, 16);
      this.txtKey.Name = "txtKey";
      this.txtKey.Size = new System.Drawing.Size(104, 20);
      this.txtKey.TabIndex = 7;
      this.txtKey.Text = "";
      // 
      // lblKey
      // 
      this.lblKey.AutoSize = true;
      this.lblKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblKey.Location = new System.Drawing.Point(8, 16);
      this.lblKey.Name = "lblKey";
      this.lblKey.Size = new System.Drawing.Size(28, 16);
      this.lblKey.TabIndex = 6;
      this.lblKey.Text = "Key:";
      // 
      // cmdCancel
      // 
      this.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.cmdCancel.Location = new System.Drawing.Point(272, 40);
      this.cmdCancel.Name = "cmdCancel";
      this.cmdCancel.TabIndex = 11;
      this.cmdCancel.Text = "Cancel";
      // 
      // cmdFind
      // 
      this.cmdFind.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.cmdFind.Location = new System.Drawing.Point(272, 8);
      this.cmdFind.Name = "cmdFind";
      this.cmdFind.TabIndex = 10;
      this.cmdFind.Text = "Find";
      // 
      // frmFindCategoryTryout
      // 
      this.AcceptButton = this.cmdFind;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.CancelButton = this.cmdCancel;
      this.ClientSize = new System.Drawing.Size(354, 71);
      this.ControlBox = false;
      this.Controls.Add(this.txtName);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.txtKey);
      this.Controls.Add(this.lblKey);
      this.Controls.Add(this.cmdCancel);
      this.Controls.Add(this.cmdFind);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "frmFindCategoryTryout";
      this.Text = "Find Category Tryout";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFindCategoryTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFindCategoryTryout()
      //***
      // Action
      //   - Create instance of 'frmFindCategoryTryout'
      // Called by
      //   - frmMasterTryout.cmdFindCategory_Click(System.Object, System.EventArgs) Handles cmdFindCategory.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFindCategoryTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public int GetKey
    {

      get
        //***
        // Action Get
        //   - If there is no key typed
        //     - Return 0
        //   - If not
        //     - Return the typed key 
        // Called by
        //   - frmMasterTryout.cmdFindCategory_Click(System.Object, System.EventArgs) Handles cmdFindCategory.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260113 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260113 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   - There is no logging if the key was not a number
        //***
      {
        return 0;
      }
      // int GetKey (Get)

    }
    // int GetKey

    public string GetName
    {

      get
        //***
        // Action Get
        //   - Return the typed text in the name
        // Called by
        //   - frmMasterTryout.cmdFindCategory_Click(System.Object, System.EventArgs) Handles cmdFindCategory.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260113 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260113 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   - There is no logging if the key was not a number
        //***
      {
        return "";
      }
      // string GetName (Get)

    }
    // string GetName

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmFindCategoryTryout

}
// CopyPaste.Learning