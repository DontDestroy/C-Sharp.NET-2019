//***
// Action
//   - An example of a queue
// Created
//   - CopyPaste � 20240228 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240228 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.Diagnostics;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Add 3 items in a queue
      //   - Check if an item is in it
      //   - Remove the first item
      //   - Peek to the first item
      //   - Put the queue into an array
      //   - Loop thru the items of the array
      //     - Show the items in the debug window (not on the console)
      //   - Make the queue empty
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngCounter;
      Queue theQueue = new Queue();

      theQueue.Enqueue("Chopin");
      theQueue.Enqueue("Mozart");
      theQueue.Enqueue("Beethoven");

      MessageBox.Show("Beethoven in queue: " + theQueue.Contains("Beethoven").ToString());
      MessageBox.Show("First item in queue (and pick it): " + theQueue.Dequeue().ToString());
      MessageBox.Show("First item in queue (only peek): " + theQueue.Peek().ToString());

      Object[] arrObjects = theQueue.ToArray();

      for (lngCounter = 0; lngCounter < arrObjects.Length; lngCounter++)
      {
        Debug.WriteLine(arrObjects[lngCounter].ToString());
      }
      // lngCounter = arrObjects.GetUpperBound(0)

      theQueue.Clear();
      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning