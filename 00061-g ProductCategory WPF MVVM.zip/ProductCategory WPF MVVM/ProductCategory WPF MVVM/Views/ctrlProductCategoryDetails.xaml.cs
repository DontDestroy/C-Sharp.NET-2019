﻿//***
// Action
//   - Show the details of Product Category
// Created
//   - CopyPaste – 20260403 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260403 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Controls;

namespace ProductCategory_WPF_MVVM.Views
{

  public partial class ctrlProductCategoryDetails : UserControl
  {

    #region "Constructors / Destructors"

    public ctrlProductCategoryDetails()
    //***
    // Action
    //   - Create an instance of ctrlProductCategoryDetails
    // Called by
    //   - wpfStartupScreen
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260403 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260403 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***

    {
      InitializeComponent();
    }
    // ctrlProductCategoryDetails()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // ctrlProductCategoryDetails

}
// ProductCategory_WPF_MVVM.Views