//***
// Action
//   - Getting the data set and showing the XML information
// Created
//   - CopyPaste � 20251125 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251125 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSqlXMLTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdUpdate;
    internal System.Windows.Forms.Button cmdRetrieve;
    internal System.Windows.Forms.TabControl tabData;
    internal System.Windows.Forms.TabPage pagData;
    internal System.Windows.Forms.DataGrid dgrDataGrid;
    internal System.Windows.Forms.TabPage pagXML;
    internal System.Windows.Forms.TextBox txtXML;
    internal System.Windows.Forms.TabPage tabXMLSchema;
    internal System.Windows.Forms.TextBox txtXMLSchema;
    internal System.Windows.Forms.Button cmdWriteXML;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSqlXMLTryout));
      this.cmdUpdate = new System.Windows.Forms.Button();
      this.cmdRetrieve = new System.Windows.Forms.Button();
      this.tabData = new System.Windows.Forms.TabControl();
      this.pagData = new System.Windows.Forms.TabPage();
      this.dgrDataGrid = new System.Windows.Forms.DataGrid();
      this.pagXML = new System.Windows.Forms.TabPage();
      this.txtXML = new System.Windows.Forms.TextBox();
      this.tabXMLSchema = new System.Windows.Forms.TabPage();
      this.txtXMLSchema = new System.Windows.Forms.TextBox();
      this.cmdWriteXML = new System.Windows.Forms.Button();
      this.tabData.SuspendLayout();
      this.pagData.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgrDataGrid)).BeginInit();
      this.pagXML.SuspendLayout();
      this.tabXMLSchema.SuspendLayout();
      this.SuspendLayout();
      // 
      // cmdUpdate
      // 
      this.cmdUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdUpdate.Location = new System.Drawing.Point(374, 173);
      this.cmdUpdate.Name = "cmdUpdate";
      this.cmdUpdate.Size = new System.Drawing.Size(312, 76);
      this.cmdUpdate.TabIndex = 6;
      this.cmdUpdate.Text = "&Update Datasource";
      this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
      // 
      // cmdRetrieve
      // 
      this.cmdRetrieve.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdRetrieve.Location = new System.Drawing.Point(42, 173);
      this.cmdRetrieve.Name = "cmdRetrieve";
      this.cmdRetrieve.Size = new System.Drawing.Size(291, 76);
      this.cmdRetrieve.TabIndex = 5;
      this.cmdRetrieve.Text = "&Retrieve Data";
      this.cmdRetrieve.Click += new System.EventHandler(this.cmdRetrieve_Click);
      // 
      // tabData
      // 
      this.tabData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.tabData.Controls.Add(this.pagData);
      this.tabData.Controls.Add(this.pagXML);
      this.tabData.Controls.Add(this.tabXMLSchema);
      this.tabData.Location = new System.Drawing.Point(42, 33);
      this.tabData.Name = "tabData";
      this.tabData.SelectedIndex = 0;
      this.tabData.Size = new System.Drawing.Size(316, 82);
      this.tabData.TabIndex = 4;
      // 
      // pagData
      // 
      this.pagData.Controls.Add(this.dgrDataGrid);
      this.pagData.Location = new System.Drawing.Point(10, 48);
      this.pagData.Name = "pagData";
      this.pagData.Size = new System.Drawing.Size(296, 24);
      this.pagData.TabIndex = 0;
      this.pagData.Text = "Data";
      // 
      // dgrDataGrid
      // 
      this.dgrDataGrid.DataMember = "";
      this.dgrDataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgrDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrDataGrid.Location = new System.Drawing.Point(0, 0);
      this.dgrDataGrid.Name = "dgrDataGrid";
      this.dgrDataGrid.Size = new System.Drawing.Size(296, 24);
      this.dgrDataGrid.TabIndex = 0;
      // 
      // pagXML
      // 
      this.pagXML.Controls.Add(this.txtXML);
      this.pagXML.Location = new System.Drawing.Point(10, 48);
      this.pagXML.Name = "pagXML";
      this.pagXML.Size = new System.Drawing.Size(936, 419);
      this.pagXML.TabIndex = 1;
      this.pagXML.Text = "XML";
      this.pagXML.Visible = false;
      // 
      // txtXML
      // 
      this.txtXML.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtXML.Location = new System.Drawing.Point(0, 0);
      this.txtXML.Multiline = true;
      this.txtXML.Name = "txtXML";
      this.txtXML.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtXML.Size = new System.Drawing.Size(936, 419);
      this.txtXML.TabIndex = 0;
      this.txtXML.Text = "TextBox1";
      // 
      // tabXMLSchema
      // 
      this.tabXMLSchema.Controls.Add(this.txtXMLSchema);
      this.tabXMLSchema.Location = new System.Drawing.Point(10, 48);
      this.tabXMLSchema.Name = "tabXMLSchema";
      this.tabXMLSchema.Size = new System.Drawing.Size(936, 419);
      this.tabXMLSchema.TabIndex = 2;
      this.tabXMLSchema.Text = "XML Schema";
      this.tabXMLSchema.Visible = false;
      // 
      // txtXMLSchema
      // 
      this.txtXMLSchema.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtXMLSchema.Location = new System.Drawing.Point(0, 0);
      this.txtXMLSchema.Multiline = true;
      this.txtXMLSchema.Name = "txtXMLSchema";
      this.txtXMLSchema.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtXMLSchema.Size = new System.Drawing.Size(936, 419);
      this.txtXMLSchema.TabIndex = 0;
      this.txtXMLSchema.Text = "TextBox2";
      // 
      // cmdWriteXML
      // 
      this.cmdWriteXML.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdWriteXML.Location = new System.Drawing.Point(728, 173);
      this.cmdWriteXML.Name = "cmdWriteXML";
      this.cmdWriteXML.Size = new System.Drawing.Size(270, 76);
      this.cmdWriteXML.TabIndex = 7;
      this.cmdWriteXML.Text = "&Write XML";
      this.cmdWriteXML.Click += new System.EventHandler(this.cmdWriteXML_Click);
      // 
      // frmSqlXMLTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(13, 31);
      this.ClientSize = new System.Drawing.Size(400, 285);
      this.Controls.Add(this.cmdWriteXML);
      this.Controls.Add(this.cmdUpdate);
      this.Controls.Add(this.cmdRetrieve);
      this.Controls.Add(this.tabData);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSqlXMLTryout";
      this.Text = "Datasets and XML Tryout";
      this.tabData.ResumeLayout(false);
      this.pagData.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgrDataGrid)).EndInit();
      this.pagXML.ResumeLayout(false);
      this.pagXML.PerformLayout();
      this.tabXMLSchema.ResumeLayout(false);
      this.tabXMLSchema.PerformLayout();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSqlXMLTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251125 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251125 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSqlXMLTryout()
      //***
      // Action
      //   - Create instance of 'frmSqlXMLTryout'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251125 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251125 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSqlXMLTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdRetrieve_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If Data is added
      //     - Do nothing
      //   - If not
      //     - Try to
      //       - Fill the data set with Category info
      //       - Fill the data set with Product info
      //       - Set the datagrid with a caption, a data source, a sort allowance, a backcolor and a data binding
      //       - Generate the XML of the data
      //       - Generate the XML of the schema
      //       - Mark that the data is added
      //     - If an error occurs, show the error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251125 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251125 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click

    private void cmdUpdate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Update the data grid
      //     - Update the data set with Category info
      //     - Update the data set with Product info
      //   - If an error occurs, show the error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251125 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251125 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdUpdate_Click(System.Object, System.EventArgs) Handles cmdUpdate.Click

    private void cmdWriteXML_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Write the schema in XML to a file 
      //   - Write the Changes in XML to a file 
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251125 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251125 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdWriteXML_Click(System.Object, System.EventArgs) Handles cmdWriteXML.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSqlXMLTryout
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSqlXML()
      // Created
      //   - CopyPaste � 20251125 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251125 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSqlXMLTryout());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSqlXMLTryout

}
// CopyPaste.Learning