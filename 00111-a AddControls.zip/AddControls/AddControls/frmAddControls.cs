//***
// Action
//   - Shows a form on the screen with a button
//   - When the button is clicked, another form is created from scratch
//   - A cancel button and the current date time is shown
// Created
//   - CopyPaste � 20240520 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240520 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmAddControls: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdShowDate;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmAddControls));
      this.cmdShowDate = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdShowDate
      // 
      this.cmdShowDate.Location = new System.Drawing.Point(32, 24);
      this.cmdShowDate.Name = "cmdShowDate";
      this.cmdShowDate.Size = new System.Drawing.Size(96, 32);
      this.cmdShowDate.TabIndex = 1;
      this.cmdShowDate.Text = "&Show Date";
      this.cmdShowDate.Click += new System.EventHandler(this.cmdShowDate_Click);
      // 
      // frmAddControls
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdShowDate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmAddControls";
      this.Text = "Add Controls";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmAddControls'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmAddControls()
      //***
      // Action
      //   - Create instance of 'frmAddControls'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmAddControls()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdShowDate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a button, form and a label
      //   - Set text of label to the current date
      //   - Define the size of the label
      //   - Define the location of the label
      //   - Set the text of the button
      //   - Define the location of the button
      //   - Define the title of the form
      //   - Define that escape will trigger the button
      //   - Set the position of the form in the center of the screen
      //   - Add the label to the form
      //   - Add the button to the form
      //   - Show the form as dialog (original form will be blocked till form is closed)
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Button cmdCancel = new Button();
      Form frmDate = new Form();
      Label lblDate = new Label();

      lblDate.Text = "Current date is: " + DateTime.Now.ToString("dd/MM/yyyy");
      lblDate.Size = new Size(200, 50);
      lblDate.Location = new Point(50, 50);
      cmdCancel.Text = "&Cancel";
      cmdCancel.Location = new Point(110, 100);
      frmDate.Text = "Actual date";
      frmDate.CancelButton = cmdCancel;
      frmDate.StartPosition = FormStartPosition.CenterScreen;
      frmDate.Controls.Add(lblDate);
      frmDate.Controls.Add(cmdCancel);
      frmDate.ShowDialog();    
    }
    // cmdShowDate_Click(System.Object, System.EventArgs) Handles cmdShowDate.Click
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmAddControls
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmAddControls()
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmAddControls());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmAddControls

}
// CopyPaste.Learning