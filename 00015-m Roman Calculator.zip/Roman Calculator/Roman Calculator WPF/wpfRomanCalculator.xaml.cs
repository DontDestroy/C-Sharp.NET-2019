﻿//***
// Action
//   - Working with basic arrays
//   - Recalculate a number towards a Roman Number
// Created
//   - CopyPaste – 20220902 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220902 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Roman_Calculator_WPF
{

  public partial class wpfRomanCalculator : Window
  {

    #region "Constructors / Destructors"

    public wpfRomanCalculator()
    //***
    // Action
    //   - Create instance of 'wpfRomanCalculator'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220902 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220902 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfRomanCalculator()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    const string mstrProgramName = "Copy Paste Tryout : Roman Calculator";

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCalculate_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Setting an array of Arabic numbers
    //   - Setting an array of Roman numbers
    //   - Getting the lower and upper bound
    //   - Getting the number from the form
    //   - Loop from upperbound to lowerbound of the array
    //     - As long as the number is bigger than the Arabic number in the array
    //       - Add a roman digit
    //   - Show the Roman number on the form
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - int Array.GetLowerBound(int)
    //   - int Array.GetUpperBound(int)
    // Created
    //   - CopyPaste – 20220902 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220902 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      int[] arrArabics = new int[] { 1, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000 };
      long lngArabicLower = arrArabics.GetLowerBound(0);
      long lngArabicUpper = arrArabics.GetUpperBound(0);
      long lngCounter;
      long lngInput;
      string[] arrRomans = new string[] { "I", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M" };
      string strInput = txtInput.Text;
      string strOutPut = "";

      lblResult.Content = "";
      lngInput = long.Parse(txtInput.Text);

      for (lngCounter = arrArabics.GetUpperBound(0); lngCounter >= arrArabics.GetLowerBound(0); lngCounter--)
      {

        while (lngInput >= arrArabics[lngCounter])
        {
          lngInput -= arrArabics[lngCounter];
          strOutPut += arrRomans[lngCounter];
        }
        // (lngInput < arrArabics[lngCounter])

      }
      // lngCounter = arrArabics.GetLowerBound(0) - 1

      lblResult.Content = strInput + " = " + strOutPut;
    }
    // cmdCalculate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCalculate.Click

    private void Window_Loaded(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Set the title of the form
    // Called by
    //   - User action (Starting the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220902 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220902 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      this.Title = mstrProgramName;
    }
    // Window_Loaded(System.Object, System.Windows.RoutedEventArgs) Handles Window.Loaded

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfRomanCalculator

}
// Roman_Calculator_WPF