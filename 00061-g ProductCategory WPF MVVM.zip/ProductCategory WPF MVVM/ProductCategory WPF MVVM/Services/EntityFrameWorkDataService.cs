﻿//***
// Action
//   - Create a service that handles data using Entity FrameWork commands
// Created
//   - CopyPaste – 20260407 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260407 – VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.EntityFrameworkCore;
using ProductCategory_WPF_MVVM.Models;
using ProductCategory_WPF_MVVM.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ProductCategory_WPF_MVVM.Services
{

  public class EntityFrameWorkDataService : IDataService
  {

    #region "Constructors / Destructors"

    public EntityFrameWorkDataService()
    //***
    // Action
    //   - Create an instance of "EntityFrameWorkDataService"
    //   - Fill Product Category list with actual data (from SQL Server)
    //   - Fill Product list with actual data (from SQL Server)
    // Called by
    //   - StartupViewModel()
    // Calls
    //   - cpApplicationDatabaseContext()
    //   - FillProduct(cpApplicationDatabaseContext)
    //   - FillProductCategory(cpApplicationDatabaseContext)
    //   - ReadData()
    // Created
    //   - CopyPaste – 20260407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      using (cpApplicationDatabaseContext theDatabaseContext = new cpApplicationDatabaseContext())
      {
        theDatabaseContext.Database.EnsureDeleted();
        // Delete the database thru the context if it already exists
        theDatabaseContext.Database.EnsureCreated();
        // Create a new databse thru the context

        FillProductCategory(theDatabaseContext);
        FillProduct(theDatabaseContext);
        ReadData();
      }
      // cpApplicationDatabaseContext theDatabaseContext

    }
    // EntityFrameWorkDataService()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private IList<Product> _lstProducts;
    private IList<ProductCategory> _lstProductCategories;
    private ProductCategory productCategoryDevelopment;
    private ProductCategory productCategorySoftSkills;
    private ProductCategory productCategoryDevOps;

    #endregion

    #region "Properties"

    public IList<ProductCategory> AllProductCategories
    {

      get
      //***
      // Action Get
      //   - Return all the product categories
      // Called by
      //   - IList<ProductCategory> AddProductCategory(ProductCategory)
      //   - IList<ProductCategory> DeleteProductCategory(ProductCategory)
      //   - ProductCategoryViewModel(IDataService)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260407 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260407 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _lstProductCategories;
      }
      // IList<ProductCategory> AllProductCategories (Get)

    }
    // IList<ProductCategory> AllProductCategories

    public IList<Product> AllProducts
    {

      get
      //***
      // Action Get
      //   - Return all the products
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260407 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260407 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _lstProducts;
      }
      // IList<Product> AllProducts (Get)

    }
    // IList<Product> AllProducts

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public IList<ProductCategory> AddProductCategory(ProductCategory theProductCategory)
    //***
    // Action
    //   - Try to
    //     - Determine the product category key, depending on the biggest number already in the list
    //     - If there is none, it will be 1
    //     - Change the key of the given product category
    //     - Add the given product category to the context
    //     - Save all the changes
    //   - On possible error
    //     - Do nothing
    //   - Read Data (put in comments, activate when multiple users)
    //   - Return the list
    // Called by
    //   - ProductCategoryViewModel.AddProductCategory()
    // Calls
    //   - cpApplicationDatabaseContext()
    //   - IList<ProductCategory> AllProductCategories (Get)
    //   - ReadData()
    // Created
    //   - CopyPaste – 20260407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260404 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      try
      {
        int intProductCategoryKey;

        if (AllProductCategories.Count > 0)
        {
          intProductCategoryKey = AllProductCategories.Max(theProductCategory => theProductCategory.ProductCategoryId) + 1;
        }
        else
        // AllProductCategories.Count = 0
        {
          intProductCategoryKey = 1;
        }
        // AllProductCategories.Count > 0

        theProductCategory.ProductCategoryId = intProductCategoryKey;
        AllProductCategories.Add(theProductCategory);

        using (cpApplicationDatabaseContext theDatabaseContext = new cpApplicationDatabaseContext())
        {
          theDatabaseContext.ProductCategory.Add(theProductCategory);
          theDatabaseContext.SaveChanges();
        }
        // cpApplicationDatabaseContext theDatabaseContext
      }
      catch
      {
      }
      finally
      {
        // ReadData();
      }
      
      return AllProductCategories;
    }
    // IList<ProductCategory> AddProductCategory(ProductCategory)

    public IList<ProductCategory> DeleteProductCategory(ProductCategory theProductCategory)
    //***
    // Action
    //   - Try to
    //     - Delete a given product category from the list
    //     - Delete a given product category from the context
    //     - Save the changes
    //   - On possible error
    //     - Do nothing
    //   - Read Data
    //   - Return the list
    // Called by
    //   - ProductCategoryViewModel.AddProductCategory()
    // Calls
    //   - cpApplicationDatabaseContext()
    //   - IList<ProductCategory> AllProductCategories (Get)
    //   - ReadData()
    // Created
    //   - CopyPaste – 20260407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      try
      {
        AllProductCategories.Remove(theProductCategory);

        using (cpApplicationDatabaseContext theDatabaseContext = new cpApplicationDatabaseContext())
        {
          theDatabaseContext.ProductCategory.Remove(theProductCategory);
          theDatabaseContext.SaveChanges();
        }
        // cpApplicationDatabaseContext theDatabaseContext

      }
      catch
      {
      }
      finally
      {
        ReadData();
      }

      return AllProductCategories;
    }
    // IList<ProductCategory> DeleteProductCategory(ProductCategory)

    private void FillProduct(cpApplicationDatabaseContext theDatabaseContext)
    //***
    // Action
    //   - Fill Product list with actual data
    // Called by
    //   - EntityFrameWorkDataService()
    // Calls
    //   - Product(int, string, DateTime, string, decimal, DateTime?, ProductCategory?)
    // Created
    //   - CopyPaste – 20260407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      Product firstProduct = new Product(1, "Extending Bootstrap with CSS, JavaScript and jQuery", new DateTime(2015, 06, 11, 00, 0, 0), "http://bit.ly/1SNzc0i", 23, null, productCategoryDevelopment);
      Product secondProduct = new Product(2, "Build your own Bootstrap Business Application Template in MVC", new DateTime(2015, 01, 29, 00, 0, 0), "http://bit.ly/1SNzc0i", 21, null, productCategoryDevelopment);
      Product thirdProduct = new Product(3, "Building Mobile Web Sites Using Web Forms, Bootstrap, and HTML5", new DateTime(2014, 08, 28, 00, 0, 0), "http://bit.ly/1J2dcrj", 19, null, productCategoryDevelopment);
      Product fourthProduct = new Product(4, "How to Start and Run A Consulting Business", new DateTime(2013, 09, 12, 00, 0, 0), "http://bit.ly/1L8kOwd", 9.99M, null, null);
      Product fifthProduct = new Product(5, "The Many Approaches to XML Processing in .NET Applications", new DateTime(2013, 07, 22, 00, 0, 0), "http://bit.ly/1DBfUqd", 9, new DateTime(2019, 03, 20, 00, 0, 0), productCategoryDevelopment);
      Product sixthProduct = new Product(6, "WPF for the Business Programmer", new DateTime(2009, 06, 12, 00, 0, 0), "http://bit.ly/1UF858z", 29, null, productCategoryDevelopment);
      Product seventhProduct = new Product(7, "WPF for the Visual Basic Programmer - Part 1", new DateTime(2013, 12, 16, 00, 0, 0), "http://bit.ly/1uFxS7C", 29, null, productCategoryDevelopment);
      Product eighthProduct = new Product(8, "WPF for the Visual Basic Programmer - Part 2", new DateTime(2014, 02, 18, 00, 0, 0), "http://bit.ly/1MjQ9NG", 29, null, productCategoryDevelopment);
      Product ninethProduct = new Product(10, "Practical Team Management for Software Engineers", new DateTime(2017, 05, 19, 00, 0, 0), "http://bit.ly/2qcWO5m", 15, null, productCategorySoftSkills);
      Product tenthProduct = new Product(11, "Leadership and Communication Skills for Software Engineers", new DateTime(2016, 05, 13, 00, 0, 0), "http://bit.ly/2aq2i4F", 15, null, productCategorySoftSkills);
      Product eleventhProduct = new Product(12, "Best Practices for Project Estimation	", new DateTime(2014, 12, 08, 00, 0, 0), "http://bit.ly/1ulLVJK", 15, null, productCategorySoftSkills);
      Product twelvethProduct = new Product(23, "Using PowerShell", new DateTime(2019, 05, 28, 12, 40, 3), "www.fairwaytech.com", 100, new DateTime(2019, 08, 28, 12, 40, 3), productCategoryDevOps);

      _lstProducts = new List<Product>();

      _lstProducts.Add(firstProduct);
      _lstProducts.Add(secondProduct);
      _lstProducts.Add(thirdProduct);
      _lstProducts.Add(fourthProduct);
      _lstProducts.Add(fifthProduct);
      _lstProducts.Add(sixthProduct);
      _lstProducts.Add(seventhProduct);
      _lstProducts.Add(eighthProduct);
      _lstProducts.Add(ninethProduct);
      _lstProducts.Add(tenthProduct);
      _lstProducts.Add(eleventhProduct);
      _lstProducts.Add(twelvethProduct);
      theDatabaseContext.Product.AddRange(_lstProducts);
      theDatabaseContext.SaveChanges();
    }
    // FillProduct(cpApplicationDatabaseContext)

    private void FillProductCategory(cpApplicationDatabaseContext theDatabaseContext)
    //***
    // Action
    //   - Fill Product Category list with actual data
    // Called by
    //   - EntityFrameWorkDataService()
    // Calls
    //   - ProductCategory(int, string)
    // Created
    //   - CopyPaste – 20260407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      productCategoryDevelopment = new ProductCategory(1, "Development");
      productCategorySoftSkills = new ProductCategory(2, "Soft Skills");
      productCategoryDevOps = new ProductCategory(4, "DevOps");

      _lstProductCategories = new List<ProductCategory>();

      _lstProductCategories.Add(productCategoryDevelopment);
      _lstProductCategories.Add(productCategorySoftSkills);
      _lstProductCategories.Add(productCategoryDevOps);
    }
    // FillProductCategory(cpApplicationDatabaseContext)

    private void ReadData()
    //***
    // Action
    //   - Clear all the products
    //   - Clear all the product categories
    // Called by
    //   - EntityFrameWorkDataService()
    //   - IList<ProductCategory> AddProductCategory(ProductCategory)
    //   - IList<ProductCategory> DeleteProductCategory(ProductCategory)
    //   - UpdateProductCategory(ProductCategory)
    // Calls
    //   - cpApplicationDatabaseContext()
    // Created
    //   - CopyPaste – 20260407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      AllProducts.Clear();
      AllProductCategories.Clear();

      using (cpApplicationDatabaseContext theDatabaseContext = new cpApplicationDatabaseContext())
      {

        foreach (Product aProduct in theDatabaseContext.Product)
        {
          AllProducts.Add(aProduct);
        }
        // in theDatabaseContext.Product

        foreach (ProductCategory aProductCategory in theDatabaseContext.ProductCategory)
        {
          AllProductCategories.Add(aProductCategory);
        }
        // in theDatabaseContext.ProductCategory

      }
      // cpApplicationDatabaseContext theDatabaseContext

    }
    // ReadData()

    public void UpdateProductCategory(ProductCategory theProductCategory)
    //***
    // Action
    //   - Try to
    //     - Update a given product category from the list thru the screens
    //     - Update a given product category from the list thru the context
    //     - Save the changes
    //   - On possible error
    //     - Do nothing
    //   - Read Data (put in comments, activate when multiple users)
    // Called by
    //   -
    // Calls
    //   - cpApplicationDatabaseContext()
    //   - ReadData()
    // Created
    //   - CopyPaste – 20260407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      try
      {

        using (cpApplicationDatabaseContext theDatabaseContext = new cpApplicationDatabaseContext())
        {
          theDatabaseContext.ProductCategory.Update(theProductCategory);
          theDatabaseContext.SaveChanges();
        }
        // cpApplicationDatabaseContext theDatabaseContext

      }
      catch
      {
      }
      finally
      {
        // ReadData();
      }

    }
    // UpdateProductCategory(ProductCategory)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // EntityFrameWorkDataService

}
// ProductCategory_WPF_MVVM.Services