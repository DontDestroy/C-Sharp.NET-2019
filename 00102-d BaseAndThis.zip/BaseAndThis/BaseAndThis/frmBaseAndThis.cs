//***
// Action
//   - Demo screen for cpBaseClass and cpDerivedClass
// Created
//   - CopyPaste � 20220610 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220610 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Teaching
{

  public class frmBaseAndThis : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdExample;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBaseAndThis));
      this.cmdExample = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdExample
      // 
      this.cmdExample.Location = new System.Drawing.Point(24, 24);
      this.cmdExample.Name = "cmdExample";
      this.cmdExample.TabIndex = 1;
      this.cmdExample.Text = "Example";
      this.cmdExample.Click += new System.EventHandler(this.cmdExample_Click);
      // 
      // frmBaseAndThis
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdExample);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBaseAndThis";
      this.Text = "Base and This";
      this.Load += new System.EventHandler(this.frmBaseAndThis_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBaseAndThis'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBaseAndThis()
      //***
      // Action
      //   - Create instance of 'frmBaseAndThis'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdExample_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Showing the functionality of a clas and a derived class
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpBaseClass()
      //   - cpBaseClass.ShowIncrementSalaryDerived(float)
      //   - cpDerivedClass()
      //   - cpDerivedClass.ShowIncrementSalaryDerived(float)
      // Created
      //   - CopyPaste � 20220610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBaseClass theBase = new cpBaseClass();
      cpBaseClass theBaseClass;
      cpDerivedClass theDerived = new cpDerivedClass();
      cpDerivedClass theDerivedClass;
      
      theBaseClass = theBase;
      theBaseClass.ShowIncrementSalary(10000);
      theBaseClass = theDerived;
      // theDerived = theBaseClass;
      // this line gives an error
      theBaseClass.ShowIncrementSalary(10000);
      theDerivedClass = theDerived;
      theDerivedClass.ShowIncrementSalaryDerived(10000);
    }
    // cmdExample_Click(System.Object, System.EventArgs) Handles cmdExample.Click

    private void frmBaseAndThis_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - 
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220610 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmBaseAndThis_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmBaseAndThis
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmBaseAndThis());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmBaseAndThis

}
// CopyPaste.Teaching