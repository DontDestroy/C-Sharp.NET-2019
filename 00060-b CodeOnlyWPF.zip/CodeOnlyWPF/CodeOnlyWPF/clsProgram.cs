﻿//***
// Action
//   - Starting application
// Created
//   - CopyPaste – 20220814 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220814 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows;

namespace CodeOnlyWPF
{
  public class cpProgram : Application
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute] // Single Threaded Apartment 
    public static void Main()
    //***
    // Action
    //   - Create an instance of the program
    //   - Create an instance of the startup screen
    //   - Show the startup screen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpProgram()
    //   - cpStartupScreen()
    // Created
    //   - CopyPaste – 20220814 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220814 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpProgram theApp = new cpProgram();

      theApp.MainWindow = new cpStartupScreen();
      theApp.MainWindow.ShowDialog();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram 

}
// CodeOnlyWPF