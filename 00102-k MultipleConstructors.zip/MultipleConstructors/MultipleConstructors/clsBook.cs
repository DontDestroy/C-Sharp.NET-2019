//***
// Action
//   - Class definition of cpBookDetails
// Created
//   - CopyPaste � 20230420 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230420 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpBookDetails
  {

    #region "Constructors / Destructors"
    
    public cpBookDetails(string strTitle, double dblPrice)
    //***
    // Action
    //   - Constructor of cpBookDetails with 2 parameters
    //   - Parameters with values for title and price
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230420 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230420 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      mstrTitle = strTitle;
      mdblPrice = dblPrice;
      mstrAuthor = "";
      mlngChapterCount = 0;
      mstrPublisher = "";
      mstrCopyright = "";
    }
    // cpBookDetails(string, double)

    public cpBookDetails(string strTitle, string strAuthor, string strPublisher, double dblPrice)
    //***
    // Action
    //   - Constructor of cpBookDetails with 4 parameters
    //   - Parameters with values for title, author, publisher and price
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230420 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230420 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      mstrTitle = strTitle;
      mstrAuthor = strAuthor;
      mstrPublisher = strPublisher;
      mdblPrice = dblPrice;
      mlngChapterCount = 0;
      mstrCopyright = "";
    }
    // cpBookDetails(string, string, string, double)

    public cpBookDetails(string strTitle, string strAuthor, string strPublisher, double dblPrice, long lngChapterCount, string strCopyright)
    //***
    // Action
    //   - Constructor of cpBookDetails with 6 parameters
    //   - Parameters with values for title, author, publisher, price, number of chapters and copyright
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230420 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230420 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      mstrTitle = strTitle;
      mstrAuthor = strAuthor;
      mstrPublisher = strPublisher;
      mdblPrice = dblPrice;
      mlngChapterCount = lngChapterCount;
      mstrCopyright = strCopyright;
    }
    // cpBookDetails(string, string, string, double, long, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public double mdblPrice;
    public long mlngChapterCount;
    public string mstrAuthor;
    public string mstrCopyright;
    public string mstrPublisher;
    public string mstrTitle;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ShowInfo()
    //***
    // Action
    //   - Show the title
    //   - Show the author (if there is one)
    //   - Show the publisher (if there is one)
    //   - Show the price (if there is one)
    //   - Show the number of chapters (if there is one)
    //   - Show the copyright (if there is one)
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230420 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230420 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      Console.WriteLine(mstrTitle);
      
      if (mstrAuthor.Length > 0)
      {
        Console.WriteLine(mstrAuthor);
      }
      else
        // mstrAuthor.Length <= 0
      {
      }
      // mstrAuthor.Length > 0

      if (mstrPublisher.Length > 0)
      {
        Console.WriteLine(mstrPublisher);
      }
      else
        // mstrPublisher.Length <= 0
      {
      }
      // mstrPublisher.Length > 0

      if (mdblPrice > 0.0)
      {
        Console.WriteLine(mdblPrice);
        }
      else
        // mdblPrice <= 0.0 
      {
      }
      // mdblPrice > 0.0 

      if (mlngChapterCount > 0)
      {
        Console.WriteLine(mlngChapterCount);
      }
      else
        // mlngChapterCount <= 0
      {
      }
      // mlngChapterCount > 0

      if (mstrCopyright.Length > 0)
      {
        Console.WriteLine(mstrCopyright);
      }
      else
        // mstrCopyright.Length <= 0
      {
      }
      // mstrCopyright.Length > 0

    }
    // ShowInfo()
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBookDetails

}
// CopyPaste.Learning