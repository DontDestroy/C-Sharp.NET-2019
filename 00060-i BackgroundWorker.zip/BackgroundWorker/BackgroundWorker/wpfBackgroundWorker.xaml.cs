﻿//***
// Action
//   - Demo of a BackgroundWorker
// Created
//   - CopyPaste – 20220823 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220823 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace BackgroundWorker
{

  public partial class wpfBackgroundWorker : Window
  {

    #region "Constructors / Destructors"

    public wpfBackgroundWorker()
    //***
    // Action
    //   - Create an instance of wpfBackgroundWorker
    //   - Setting the support of cancellation to true for theBackgroundWorker
    //   - Assign what code must be runned in the background
    //   - Assign what must be done when the background is finished
    // Called by
    //   - User action (Starting the form)
    // Calls
    //   - theBackgroundWorker_DoWork(System.Object, System.ComponentModel.DoWorkEventArgs)
    //   - theBackgroundWorker_RunWorkerCompleted(System.Object, System.ComponentModel.RunWorkerCompletedEventArgs)
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      theBackgroundWorker.WorkerSupportsCancellation = true;
      theBackgroundWorker.DoWork += theBackgroundWorker_DoWork;
      theBackgroundWorker.RunWorkerCompleted += theBackgroundWorker_RunWorkerCompleted;
    }
    // wpfBackgroundWorker()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public System.ComponentModel.BackgroundWorker theBackgroundWorker = new System.ComponentModel.BackgroundWorker();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCancel_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Cancel the thread of a BackgroundWorker
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      theBackgroundWorker.CancelAsync();
    }
    // cmdCancel_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCancel.Click

    private void cmdStart_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Start the thread of a BackgroundWorker
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - theBackgroundWorker_DoWork(System.Object, System.ComponentModel.DoWorkEventArgs)
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lblResult.Content = "";
      theBackgroundWorker.RunWorkerAsync();
    }
    // cmdStart_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdStart.Click

    private void theBackgroundWorker_DoWork(System.Object theSender, System.ComponentModel.DoWorkEventArgs theDoWorkEventArguments)
    //***
    // Action
    //   - Loop from 1 till 500
    //     - Loop from 1 till 10.000.000
    //     - Check if Cancel was clicked
    //     - Update label on screen
    // Called by
    //   - wpfBackgroundWorker()
    // Calls
    //   - UpdateLabel(int)
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      UpdateDelegate updateScreen = new UpdateDelegate(UpdateLabel);

      for (int intOuterCounter = 1; intOuterCounter <= 500; intOuterCounter++)
      {

        for (int intInnerCounter = 1; intInnerCounter <= 10000000; intInnerCounter++)
        {
        }
        // intInnerCounter = 10000001

        if (theBackgroundWorker.CancellationPending)
        {
          theDoWorkEventArguments.Cancel = true;
          return;
        }
        else
          // Not theBackgroundWorker.CancellationPending
        {
        }
        // theBackgroundWorker.CancellationPending

        lblCycles.Dispatcher.BeginInvoke(updateScreen, System.Windows.Threading.DispatcherPriority.Normal, intOuterCounter);
      }
      // intOuterCounter = 501

    }
    // theBackgroundWorker_DoWork(System.Object, System.ComponentModel.DoWorkEventArgs) Handles theBackgroundWorker.DoWork

    private void theBackgroundWorker_RunWorkerCompleted(System.Object theSender, System.ComponentModel.RunWorkerCompletedEventArgs theRunWorkerCompletedEventArguments)
    //***
    // Action
    //   - Show result if Cancel was clicked or not
    // Called by
    //   - System action (DoWork is finished, cancelled or in error state)
    //   - wpfBackgroundWorker()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (theRunWorkerCompletedEventArguments.Cancelled)
      {
        lblResult.Content = "Run Cancelled!";
      }
      else
        // Not theRunWorkerCompletedEventArguments.Cancelled
      {
        lblResult.Content = "Run Completed!";
      }
      // theRunWorkerCompletedEventArguments.Cancelled

    }
    // theBackgroundWorker_RunWorkerCompleted(System.Object, System.ComponentModel.RunWorkerCompletedEventArgs) Handles theBackgroundWorker_RunWorkerCompleted

    #endregion

    #region "Functionality"

    #region "Event"

    private delegate void UpdateDelegate(int intValue);

    #endregion

    #region "Sub / Function"

    private void UpdateLabel(int intValue)
    //***
    // Action
    //   - Change the label on the screen with value intValue
    // Called by
    //   - theBackgroundWorker_DoWork(System.Object, System.ComponentModel.DoWorkEventArgs)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lblCycles.Content = "Cycles: " + intValue.ToString();
    }
    // UpdateLabel(int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfBackgroundWorker

}
// BackgroundWorker