//***
// Action
//   - Define constants to calculate with circles
// Created
//   - CopyPaste � 20220308 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220308 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Toolkit
{

  public class cpCircleConstants
	{

    #region "Constructors / Destructors"

    public cpCircleConstants(int intRadius)
      //***
      // Action
      //   - Create a new instance of cpCircleConstants
      //   - Define a radius
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220308 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220308 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      rointRadius = intRadius;
    }
    // cpCircleConstants(int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public const double cdblPI = Math.PI;
    public readonly int rointRadius;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

	}
  // cpCircleConstants

}
// CopyPaste.Learning.Toolkit