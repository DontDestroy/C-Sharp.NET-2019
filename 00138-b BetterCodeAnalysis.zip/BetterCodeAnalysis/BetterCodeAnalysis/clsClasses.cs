//***
// Action
//   - Implementation of cpClasses
// Created
//   - CopyPaste � 20240124 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240124 � VVDW
// Proposal (To Do)
//   - This is a small exercise
//   - It counts only the public classes
//***

using Microsoft.VisualBasic;
using System.Collections;
using System.IO;

namespace CopyPaste.Learning
{

  /// <summary>
  /// cpClasses is a collection of cpOneClass
  /// </summary>
  public class cpClasses
  {

    #region "Constructors / Destructors"

    /// <summary>
    /// Constructor of cpClasses
    /// </summary>
    public cpClasses()
      //***
      // Action
      //   - Empty constructor
      // Called by
      //   - frmCodeAnalysis
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240124 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240124 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpClasses()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private ArrayList marrClassName = new ArrayList();
    private int mlngLinesOfCode = 0;

    #endregion

    #region "Properties"

    /// <summary>
    /// The number of classes in the collection of cpClasses (Get only)
    /// </summary>
    public int Count
    {

      get
        //***
        // Action Get
        //   - Returns the number of elements in marrClassName
        // Called by
        //   - frmCodeAnalysis.DisplayClass()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240124 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240124 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return marrClassName.Count;
      }
      // int Count (Get)

    }
    // int Count

    /// <summary>
    /// Default property / indexer
    /// </summary>
    public cpOneClass this[int lngIndex]
    {

      get
        //***
        // Action Get
        //   - If lngIndex is positive and smaller than the number of classes
        //     - Returns the lngIndex element of the array as a cpOneClass
        //   - If Not
        //     - An error is thrown
        // Called by
        //   - frmCodeAnalysis.DisplayClass()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240124 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240124 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if ((lngIndex >= 0) && (lngIndex < marrClassName.Count))
        {
          return (cpOneClass) marrClassName[lngIndex];
        }
        else
          // (lngIndex < 0 Or lngIndex >= marrClassName.Count-
        {
          throw new System.IndexOutOfRangeException("Index must be between 0 and " + marrClassName.Count.ToString() + ".");
        }
        // (lngIndex >= 0 And lngIndex < marrClassName.Count)

      }
      // cpOneClass cpClasses.this(int) (Get)

      set
        //***
        // Action Set
        //   - If lngIndex is positive and smaller than the number of classes
        //     - The lngIndex element of the array becomes value
        //   - If Not
        //     - An error is thrown
        // Called by
        //   - Not used at this moment
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240124 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240124 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        
        if ((lngIndex >= 0) && (lngIndex < marrClassName.Count))
        {
          marrClassName[lngIndex] = value;
        }
        else
          // (lngIndex < 0 Or lngIndex >= marrClassName.Count-
        {
          throw new System.IndexOutOfRangeException("Index must be between 0 and " + marrClassName.Count.ToString() + ".");
        }
        // (lngIndex >= 0 And lngIndex < marrClassName.Count)

      }
      // this(int, cpOneClass) (Set)

    }
    // cpOneClass cpClasses.this(int)

    /// <summary>
    /// The number of lines of code in a cpClasses (Get only)
    /// </summary>
    public int LinesOfCode
    {

      get
        //***
        // Action Get
        //   - Returns the number of lines of code
        // Called by
        //   - frmCodeAnalysis.DisplayClass()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240124 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240124 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngLinesOfCode;
      }
      // int LinesOfCode (Get)

    }
    // int LinesOfCode

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    /// <summary>
    /// Reading a source file (a textfile that contains programming code
    /// </summary>
    /// <param name="strFullPath">Full path to the source of the code</param>
    public void ReadFromFile(string strFullPath)
      //***
      // Action
      //   - Read the content of a file defined by a full path
      //   - Try to do something
      //     - Read the file defined by 'strFullPath'
      //     - Loop thru the lines
      //       - Remove spaces in front and at the back
      //       - Check if it is an empty line or comment
      //       - If Not
      //         - Add 1 to the line counter of code
      //       - If it starts with "Public Class"
      //         - Find the class name
      //         - Define it as a cpOneClass
      //         - Add it to the arraylist
      //   - When it fails
      //     - Throw a new exception
      // Called by
      //   - frmCodeAnalysis.cmdBrowse_Click(System.Object, System.EventArgs) Handles cmdBrowse.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240124 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240124 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      StreamReader theStreamReader = new StreamReader(strFullPath);

      try
      {
        int lngNameStart;
        string strLine;

        strLine = theStreamReader.ReadLine();

        while (strLine != null)
        {
          strLine = strLine.Trim();

          if ((strLine == "") || (strLine.StartsWith("//")))
          {
            // Don �t count blank lines and comment lines
          }
          else
            // strLine <> "" And Not strLine.StartsWith("//") 
          {
            mlngLinesOfCode++;
          }
          // strLine = "" Or strLine.StartsWith("//")

          if (strLine.StartsWith("public class "))
          {
            string[] arrstrName;
            char[] arrstrSeparator = {ControlChars.Tab, ' '};
            
            lngNameStart = strLine.IndexOf("class ") + 6;
            arrstrName = strLine.Substring(lngNameStart).Trim().Split(arrstrSeparator);
            
            string strClassName = arrstrName[0].Trim();

            marrClassName.Add(new cpOneClass(strClassName, strFullPath));
          }
          else
            // Not strLine.StartsWith("Public Class ")
          {
          }
          // strLine.StartsWith("Public Class ")
          
          strLine = theStreamReader.ReadLine();
        }
        // strLine is null

      }
      catch (System.Exception theException)
      {
        throw new System.Exception("Problems parsing source file:" + theException.Message);
      }
      finally
      {
        theStreamReader.Close();
      }

    }
    // ReadFromFile(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpClasses

}
// CopyPaste.Learning