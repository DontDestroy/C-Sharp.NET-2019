﻿//***
// Action
//   - An example of using Entity Framework
// Created
//   - CopyPaste – 20210701 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210701 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

namespace DataEntityFrameWork
{

    partial class frmCategoryAndProducts
    {

    #region Windows Form Designer generated code

    /// <summary>
    /// Required designer variable.
    /// </summary>
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private System.Windows.Forms.BindingSource tblCPCategoryBindingSource;
    private System.Windows.Forms.BindingNavigator tblCPCategoryBindingNavigator;
    private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
    private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
    private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
    private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
    private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
    private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
    private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
    private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
    private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
    private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
    private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
    private System.Windows.Forms.ToolStripButton tblCPCategoryBindingNavigatorSaveItem;
    private System.Windows.Forms.DataGridView tblCPCategoryDataGridView;
    private System.Windows.Forms.BindingSource tblCPProductBindingSource;
    private System.Windows.Forms.DataGridView tblCPProductDataGridView;
    private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
    private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    private System.Windows.Forms.DataGridViewTextBoxColumn intUnitsInStock;
    private System.Windows.Forms.DataGridViewTextBoxColumn intIdCategoryDataGridViewTextBoxColumn;
    private System.Windows.Forms.DataGridViewTextBoxColumn strCategoryNameDataGridViewTextBoxColumn;
    private System.Windows.Forms.DataGridViewTextBoxColumn memDescriptionDataGridViewTextBoxColumn;
    private System.ComponentModel.IContainer components = null;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCategoryAndProducts));
      this.tblCPCategoryBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
      this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
      this.tblCPCategoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
      this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
      this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
      this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
      this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
      this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
      this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
      this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
      this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
      this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.tblCPCategoryBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
      this.tblCPCategoryDataGridView = new System.Windows.Forms.DataGridView();
      this.tblCPProductBindingSource = new System.Windows.Forms.BindingSource(this.components);
      this.tblCPProductDataGridView = new System.Windows.Forms.DataGridView();
      this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.intUnitsInStock = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.intIdCategoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.strCategoryNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
      this.memDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
      ((System.ComponentModel.ISupportInitialize)(this.tblCPCategoryBindingNavigator)).BeginInit();
      this.tblCPCategoryBindingNavigator.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.tblCPCategoryBindingSource)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.tblCPCategoryDataGridView)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.tblCPProductBindingSource)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.tblCPProductDataGridView)).BeginInit();
      this.SuspendLayout();
      // 
      // tblCPCategoryBindingNavigator
      // 
      this.tblCPCategoryBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
      this.tblCPCategoryBindingNavigator.BindingSource = this.tblCPCategoryBindingSource;
      this.tblCPCategoryBindingNavigator.CountItem = this.bindingNavigatorCountItem;
      this.tblCPCategoryBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
      this.tblCPCategoryBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.tblCPCategoryBindingNavigatorSaveItem});
      this.tblCPCategoryBindingNavigator.Location = new System.Drawing.Point(0, 0);
      this.tblCPCategoryBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
      this.tblCPCategoryBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
      this.tblCPCategoryBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
      this.tblCPCategoryBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
      this.tblCPCategoryBindingNavigator.Name = "tblCPCategoryBindingNavigator";
      this.tblCPCategoryBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
      this.tblCPCategoryBindingNavigator.Size = new System.Drawing.Size(800, 25);
      this.tblCPCategoryBindingNavigator.TabIndex = 0;
      this.tblCPCategoryBindingNavigator.Text = "bindingNavigator1";
      // 
      // bindingNavigatorAddNewItem
      // 
      this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
      this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
      this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
      this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
      this.bindingNavigatorAddNewItem.Text = "Add new";
      // 
      // tblCPCategoryBindingSource
      // 
      this.tblCPCategoryBindingSource.DataSource = typeof(DataEntityFrameWork.tblCPCategory);
      // 
      // bindingNavigatorCountItem
      // 
      this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
      this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
      this.bindingNavigatorCountItem.Text = "of {0}";
      this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
      // 
      // bindingNavigatorDeleteItem
      // 
      this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
      this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
      this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
      this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
      this.bindingNavigatorDeleteItem.Text = "Delete";
      // 
      // bindingNavigatorMoveFirstItem
      // 
      this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
      this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
      this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
      this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
      this.bindingNavigatorMoveFirstItem.Text = "Move first";
      // 
      // bindingNavigatorMovePreviousItem
      // 
      this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
      this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
      this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
      this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
      this.bindingNavigatorMovePreviousItem.Text = "Move previous";
      // 
      // bindingNavigatorSeparator
      // 
      this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
      this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
      // 
      // bindingNavigatorPositionItem
      // 
      this.bindingNavigatorPositionItem.AccessibleName = "Position";
      this.bindingNavigatorPositionItem.AutoSize = false;
      this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
      this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
      this.bindingNavigatorPositionItem.Text = "0";
      this.bindingNavigatorPositionItem.ToolTipText = "Current position";
      // 
      // bindingNavigatorSeparator1
      // 
      this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
      this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
      // 
      // bindingNavigatorMoveNextItem
      // 
      this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
      this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
      this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
      this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
      this.bindingNavigatorMoveNextItem.Text = "Move next";
      // 
      // bindingNavigatorMoveLastItem
      // 
      this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
      this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
      this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
      this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
      this.bindingNavigatorMoveLastItem.Text = "Move last";
      // 
      // bindingNavigatorSeparator2
      // 
      this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
      this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
      // 
      // tblCPCategoryBindingNavigatorSaveItem
      // 
      this.tblCPCategoryBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.tblCPCategoryBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("tblCPCategoryBindingNavigatorSaveItem.Image")));
      this.tblCPCategoryBindingNavigatorSaveItem.Name = "tblCPCategoryBindingNavigatorSaveItem";
      this.tblCPCategoryBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
      this.tblCPCategoryBindingNavigatorSaveItem.Text = "Save Data";
      this.tblCPCategoryBindingNavigatorSaveItem.Click += new System.EventHandler(this.tblCPCategoryBindingNavigatorSaveItem_Click);
      // 
      // tblCPCategoryDataGridView
      // 
      this.tblCPCategoryDataGridView.AutoGenerateColumns = false;
      this.tblCPCategoryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.tblCPCategoryDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.intIdCategoryDataGridViewTextBoxColumn,
            this.strCategoryNameDataGridViewTextBoxColumn,
            this.memDescriptionDataGridViewTextBoxColumn});
      this.tblCPCategoryDataGridView.DataSource = this.tblCPCategoryBindingSource;
      this.tblCPCategoryDataGridView.Location = new System.Drawing.Point(27, 28);
      this.tblCPCategoryDataGridView.Name = "tblCPCategoryDataGridView";
      this.tblCPCategoryDataGridView.Size = new System.Drawing.Size(646, 170);
      this.tblCPCategoryDataGridView.TabIndex = 1;
      // 
      // tblCPProductBindingSource
      // 
      this.tblCPProductBindingSource.DataMember = "tblCPProduct";
      this.tblCPProductBindingSource.DataSource = this.tblCPCategoryBindingSource;
      // 
      // tblCPProductDataGridView
      // 
      this.tblCPProductDataGridView.AllowUserToAddRows = false;
      this.tblCPProductDataGridView.AllowUserToDeleteRows = false;
      this.tblCPProductDataGridView.AutoGenerateColumns = false;
      this.tblCPProductDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.tblCPProductDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.intUnitsInStock});
      this.tblCPProductDataGridView.DataSource = this.tblCPProductBindingSource;
      this.tblCPProductDataGridView.Location = new System.Drawing.Point(27, 213);
      this.tblCPProductDataGridView.Name = "tblCPProductDataGridView";
      this.tblCPProductDataGridView.ReadOnly = true;
      this.tblCPProductDataGridView.Size = new System.Drawing.Size(750, 220);
      this.tblCPProductDataGridView.TabIndex = 2;
      // 
      // dataGridViewTextBoxColumn4
      // 
      this.dataGridViewTextBoxColumn4.DataPropertyName = "intIdProduct";
      this.dataGridViewTextBoxColumn4.HeaderText = "intIdProduct";
      this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
      this.dataGridViewTextBoxColumn4.ReadOnly = true;
      // 
      // dataGridViewTextBoxColumn5
      // 
      this.dataGridViewTextBoxColumn5.DataPropertyName = "strProductName";
      this.dataGridViewTextBoxColumn5.HeaderText = "strProductName";
      this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
      this.dataGridViewTextBoxColumn5.ReadOnly = true;
      // 
      // intUnitsInStock
      // 
      this.intUnitsInStock.DataPropertyName = "intUnitsInStock";
      this.intUnitsInStock.HeaderText = "intUnitsInStock";
      this.intUnitsInStock.Name = "intUnitsInStock";
      this.intUnitsInStock.ReadOnly = true;
      // 
      // intIdCategoryDataGridViewTextBoxColumn
      // 
      this.intIdCategoryDataGridViewTextBoxColumn.DataPropertyName = "intIdCategory";
      this.intIdCategoryDataGridViewTextBoxColumn.HeaderText = "intIdCategory";
      this.intIdCategoryDataGridViewTextBoxColumn.Name = "intIdCategoryDataGridViewTextBoxColumn";
      // 
      // strCategoryNameDataGridViewTextBoxColumn
      // 
      this.strCategoryNameDataGridViewTextBoxColumn.DataPropertyName = "strCategoryName";
      this.strCategoryNameDataGridViewTextBoxColumn.HeaderText = "strCategoryName";
      this.strCategoryNameDataGridViewTextBoxColumn.Name = "strCategoryNameDataGridViewTextBoxColumn";
      // 
      // memDescriptionDataGridViewTextBoxColumn
      // 
      this.memDescriptionDataGridViewTextBoxColumn.DataPropertyName = "memDescription";
      this.memDescriptionDataGridViewTextBoxColumn.HeaderText = "memDescription";
      this.memDescriptionDataGridViewTextBoxColumn.Name = "memDescriptionDataGridViewTextBoxColumn";
      // 
      // frmCategoryAndProducts
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(800, 505);
      this.Controls.Add(this.tblCPProductDataGridView);
      this.Controls.Add(this.tblCPCategoryDataGridView);
      this.Controls.Add(this.tblCPCategoryBindingNavigator);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCategoryAndProducts";
      this.Text = "Category and Products";
      ((System.ComponentModel.ISupportInitialize)(this.tblCPCategoryBindingNavigator)).EndInit();
      this.tblCPCategoryBindingNavigator.ResumeLayout(false);
      this.tblCPCategoryBindingNavigator.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.tblCPCategoryBindingSource)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.tblCPCategoryDataGridView)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.tblCPProductBindingSource)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.tblCPProductDataGridView)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 2007202107010503 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing && (components != null))
      {
        components.Dispose();
      }
      // (disposing && (components != null))

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmCategoryAndProducts

}
// DataEntityFrameWork