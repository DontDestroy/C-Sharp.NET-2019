//***
// Action
//   - Testroutine for cpWorker
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Teaching
{

  public class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Create two cpWorkers
      //   - Assign the name of the first with one method
      //   - Assign the name of the second with an overloaded method
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpWorker()
      //   - cpWorker.AssignName(string)
      //   - cpWorker.AssignName(string, string)
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpWorker theWorkerJoe = new cpWorker();
      cpWorker theWorkerBilly = new cpWorker();

      theWorkerJoe.AssignName("Joe Smith");
      theWorkerBilly.AssignName("William", "Jones");

      Console.WriteLine(theWorkerJoe.mstrFullName);
      Console.WriteLine(theWorkerBilly.mstrFullName);
      Console.ReadLine();
    }
    // Main()

    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Teaching
