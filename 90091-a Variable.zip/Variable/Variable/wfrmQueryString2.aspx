﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmQueryString2.aspx.cs" Inherits="CopyPaste.Learning.wfrmQueryString2" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>QueryString</title>
</head>
<body>
  <form id="wfrmQueryString2" method="post" runat="server">
    <asp:Label ID="lblEmail" Style="z-index: 101; position: absolute; top: 120px; left: 120px"
      runat="server"></asp:Label>
    <asp:Label ID="lblName" Style="z-index: 102; position: absolute; top: 80px; left: 120px" runat="server"></asp:Label>
  </form>
</body>
</html>
