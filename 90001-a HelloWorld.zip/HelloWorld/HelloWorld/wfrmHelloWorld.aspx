﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmHelloWorld.aspx.cs" Inherits="CopyPaste.Learning.wfrmHelloWorld" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Hello World</title>
      <script type="text/javascript">
      function ClientAction()
      {
        // Executed when button is clicked (Client side)
        document.getElementById("txtClient").value = "txtClient (cmdClient_onclick)";
      }
      // cmdClient_onclick()
      </script>
</head>
<body>
    <form id="wfrmHelloWorld" runat="server" method="post">
        <div>
        </div>
        <asp:label id="lblText" style="Z-INDEX: 101; POSITION: absolute; TOP: 48px; LEFT: 24px" runat="server"
          Width="145px" Height="29px">Hello World !</asp:label>
        <input id="cmdClient" style="Z-INDEX: 106; POSITION: absolute; WIDTH: 56px; HEIGHT: 24px; TOP: 120px; LEFT: 216px"
          type="button" value="Client" onclick="ClientAction()"/>
        <asp:button id="cmdServer" style="Z-INDEX: 105; POSITION: absolute; TOP: 152px; LEFT: 216px"
          runat="server" Width="56px" Text="Server"></asp:button>
        <input id="txtClassic" style="Z-INDEX: 102; POSITION: absolute; TOP: 88px; LEFT: 48px; width: 128px;"
          value="Klassieke HTML tag" name="txtClassic"/>
        <input id="txtClient" style="Z-INDEX: 103; POSITION: absolute; TOP: 120px; LEFT: 48px; width: 128px;"
          value="HTML Text Field" name="txtHTML"/>
        <asp:textbox id="txtServer" style="Z-INDEX: 104; POSITION: absolute; TOP: 152px; LEFT: 48px"
          runat="server" width="128px">WebForm Text Field</asp:textbox>
    </form>
</body>
</html>
