//***
// Action
//   - Show some pixels on the screen
// Created
//   - CopyPaste � 20230614 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230614 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Pixels
{

  public class frmPixels : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    internal System.Windows.Forms.PictureBox picPicture;
    internal System.Windows.Forms.Button cmdPixels;
    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPixels));
      this.picPicture = new System.Windows.Forms.PictureBox();
      this.cmdPixels = new System.Windows.Forms.Button();
      ((System.ComponentModel.ISupportInitialize)(this.picPicture)).BeginInit();
      this.SuspendLayout();
      // 
      // picPicture
      // 
      this.picPicture.Location = new System.Drawing.Point(100, 0);
      this.picPicture.Name = "picPicture";
      this.picPicture.Size = new System.Drawing.Size(300, 300);
      this.picPicture.TabIndex = 3;
      this.picPicture.TabStop = false;
      // 
      // cmdPixels
      // 
      this.cmdPixels.Location = new System.Drawing.Point(8, 8);
      this.cmdPixels.Name = "cmdPixels";
      this.cmdPixels.Size = new System.Drawing.Size(80, 40);
      this.cmdPixels.TabIndex = 2;
      this.cmdPixels.Text = "&Color pixels";
      this.cmdPixels.Click += new System.EventHandler(this.cmdPixels_Click);
      // 
      // frmPixels
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(392, 298);
      this.Controls.Add(this.picPicture);
      this.Controls.Add(this.cmdPixels);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPixels";
      this.Text = "Pixels";
      ((System.ComponentModel.ISupportInitialize)(this.picPicture)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPixels'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPixels()
      //***
      // Action
      //   - Create instance of 'frmPixels'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPixels()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    Graphics mtheGraphics;
    Pen mtheColor = new Pen(System.Drawing.Color.Black);
    Random mrndRandom;
    Rectangle mtheRectangle = new Rectangle();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdPixels_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a randomizer
    //   - Define a graphic tool
    //   - There is a loop till 10000
    //     - An X and Y coordinate are calculated
    //     - At that point a pixel (rectangle of size 1) is drawn
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      short shtCounter;
      short shtX;
      short shtY;

      mrndRandom = new Random(DateTime.Now.Millisecond);
      mtheGraphics = picPicture.CreateGraphics();

      for (shtCounter = 1; shtCounter <= 10000; shtCounter++)
      {
        shtX = Convert.ToInt16(mrndRandom.Next(300));
        shtY = Convert.ToInt16(mrndRandom.Next(300));

        mtheRectangle.Size = new Size(1, 1);
        mtheRectangle.Location = new Point(shtX, shtY);
        mtheGraphics.DrawRectangle(mtheColor, mtheRectangle);
      }
      // shtCounter = 10001
    
    }
    // cmdPixels_Click(System.Object, System.EventArgs) Handles cmdPixels.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPixels
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPixels());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmPixels

}
// Pixels