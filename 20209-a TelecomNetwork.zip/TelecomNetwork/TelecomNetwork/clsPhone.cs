﻿//***
// Action
//   - The definition of a cpPhone
// Created
//   - CopyPaste – 20230614 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230614 – VVDW
// Proposal (To Do)
//   - There is no check on duplicated phonenumbers
//***

using System;

namespace CopyPaste.TelecomNetwork
{

  public class cpPhone
  {

    #region "Constructors / Destructors"

    public cpPhone(string strPhoneNumber, string strName)
    //***
    // Action
    //   - Constructor of a phone with phonenumber and name
    // Called by
    //   - frmNetwork.cmdCreate_Click(System.Object, System.EventArgs) Handles cmdCreate.Click
    //   - frmNetwork.frmNetwork_Load(System.Object, System.EventArgs) Handles frmNetwork.Load
    // Calls
    //   - Name(string) (Set)
    //   - PhoneNumber(string) (Set)
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - There is no check on duplicated phonenumbers
    //***
    {
      intIdentifier++;
      Identifier = intIdentifier;
      Name = strName;
      PhoneNumber = strPhoneNumber;
    }
    // cpPhone(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public event EventHandler ReceiveCall;
    public event MessageEventHandler ReceiveMessage;
    static int intIdentifier;

    #endregion

    #region "Properties"

    public int Identifier { get; set; }
    public bool IsOpen { get; set; }
    public string Name { get; set; }
    public string PhoneNumber { get; set; }

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
    //***
    // Action
    //   - Show information of a cpPhone
    // Called by
    //   - Used in the combobox to visualise the cpPhone
    //   - frmPhone(cpNetwork<cpPhone>, cpPhone)
    // Calls
    //   - string Name (Get)
    //   - string PhoneNumber (Get)
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      return PhoneNumber + " - " + Name;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate void MessageEventHandler(string strPhoneNumber, string strMessage);

    #endregion

    #region "Sub / Function"

    public void Called()
    //***
    // Action
    //   - Actions to execute when cpPhone is called
    //   - Starts the event ReceiveCall, when the cpPhone is open / shown
    // Called by
    //   - 
    // Calls
    //   - ReceiveCall()
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      if (IsOpen)
      {
        ReceiveCall.Invoke(this, null);
      }
      // Not IsOpen
      else
      {
      }
      // IsOpen

    }
    // Called()

    public void Messaged(string strCallerPhone, string strMessage)
    //***
    // Action
    //   - Actions to execute when cpPhone is messaged
    //   - Starts the event ReceiveMessage, when the cpPhone is open / shown
    // Called by
    //   - 
    // Calls
    //   - ReceiveMessage()
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      if (IsOpen)
      {
        ReceiveMessage.Invoke(strCallerPhone, strMessage);
      }
      // Not IsOpen
      else
      {
      }
      // IsOpen

    }
    // Messaged(string, string)

    public string SearchString()
    //***
    // Action
    //   - Define a search string used to find a cpPhone
    //   - The name and the phone number is used to search a cpPhone
    // Called by
    //   - frmNetWork.FillPhoneCombobox()
    // Calls
    //   - string Name (Get)
    //   - string PhoneNumber (Get)
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      return $"{Name}{PhoneNumber}".ToLower();
    }
    // string SearchString()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPhone

}
// CopyPaste.TelecomNetwork