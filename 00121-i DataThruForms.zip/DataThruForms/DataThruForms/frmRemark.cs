//***
// Action
//   - Testroutine for a property used in an instance of cpCountry
// Created
//   - CopyPaste � 20240702 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240702 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmRemark: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdCancel;
    internal System.Windows.Forms.Button cmdOK;
    internal System.Windows.Forms.TextBox txtRemark;
    internal System.Windows.Forms.Label lblCapital;
    protected System.Windows.Forms.Label lblSize;
    internal System.Windows.Forms.Label lblCountry;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmRemark));
      this.cmdCancel = new System.Windows.Forms.Button();
      this.cmdOK = new System.Windows.Forms.Button();
      this.txtRemark = new System.Windows.Forms.TextBox();
      this.lblCapital = new System.Windows.Forms.Label();
      this.lblCountry = new System.Windows.Forms.Label();
      this.lblSize = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdCancel
      // 
      this.cmdCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.cmdCancel.Location = new System.Drawing.Point(71, 128);
      this.cmdCancel.Name = "cmdCancel";
      this.cmdCancel.TabIndex = 8;
      this.cmdCancel.Text = "Cancel";
      // 
      // cmdOK
      // 
      this.cmdOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdOK.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.cmdOK.Location = new System.Drawing.Point(159, 128);
      this.cmdOK.Name = "cmdOK";
      this.cmdOK.TabIndex = 9;
      this.cmdOK.Text = "OK";
      this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
      // 
      // txtRemark
      // 
      this.txtRemark.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.txtRemark.Location = new System.Drawing.Point(15, 64);
      this.txtRemark.Multiline = true;
      this.txtRemark.Name = "txtRemark";
      this.txtRemark.Size = new System.Drawing.Size(216, 48);
      this.txtRemark.TabIndex = 7;
      this.txtRemark.Text = "";
      // 
      // lblCapital
      // 
      this.lblCapital.Location = new System.Drawing.Point(127, 11);
      this.lblCapital.Name = "lblCapital";
      this.lblCapital.TabIndex = 6;
      // 
      // lblCountry
      // 
      this.lblCountry.Location = new System.Drawing.Point(15, 11);
      this.lblCountry.Name = "lblCountry";
      this.lblCountry.TabIndex = 5;
      // 
      // lblSize
      // 
      this.lblSize.Location = new System.Drawing.Point(74, 40);
      this.lblSize.Name = "lblSize";
      this.lblSize.Size = new System.Drawing.Size(100, 16);
      this.lblSize.TabIndex = 10;
      // 
      // frmRemark
      // 
      this.AcceptButton = this.cmdOK;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.CancelButton = this.cmdCancel;
      this.ClientSize = new System.Drawing.Size(248, 157);
      this.Controls.Add(this.lblSize);
      this.Controls.Add(this.cmdCancel);
      this.Controls.Add(this.cmdOK);
      this.Controls.Add(this.txtRemark);
      this.Controls.Add(this.lblCapital);
      this.Controls.Add(this.lblCountry);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmRemark";
      this.ShowInTaskbar = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.Text = "Remark";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmRemark'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmRemark(cpCountry thecpCountry)
      //***
      // Action
      //   - Create instance of 'frmRemark' with a given cpCountry
      // Called by
      //   - frmDataThruForms.cmdRemark_Click(System.Object, System.EventArgs) Handles cmdRemark.Click
      // Calls
      //   - InitializeComponent()
      //   - int cpCountry.Size (Get)
      //   - string cpCountry.Capital (Get)
      //   - string cpCountry.Name (Get)
      //   - string cpCountry.Remark (Get)
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();

      mcpCountry = thecpCountry;
      lblCountry.Text = mcpCountry.Name;
      lblCapital.Text = mcpCountry.Capital;
      lblSize.Text = mcpCountry.Size.ToString();
      txtRemark.Text = mcpCountry.Remark;
    }
    // frmRemark()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpCountry mcpCountry;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdOK_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Put the given text in the remark property of a cpCountry
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpCountry.Remark(String) (Set)
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpCountry.Remark = txtRemark.Text;    
    }
    // cmdOK_Click(System.Object, System.EventArgs) Handles cmdOK.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmRemark

}
// CopyPaste.Learning