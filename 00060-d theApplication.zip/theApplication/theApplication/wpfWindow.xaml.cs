﻿//***
// Action
//   - Startup the application
// Created
//   - CopyPaste – 20220815 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220815 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace theApplication
{

  public partial class wpfWindow : Window
  {

    #region "Constructors / Destructors"

    public wpfWindow()
    //***
    // Action
    //   - Empty constructor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220815 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220815 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfWindow()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // wpfWindow  

}
// theApplication