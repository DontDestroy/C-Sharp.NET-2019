//***
// Action
//   - Define a Rich TextBox KeyWord
// Created
//   - CopyPaste � 20250721 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250721 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.UserInterface
{

  public sealed class cpctlRichTextBoxKeyWord : RichTextBox
  {

    #region "Constructors / Destructors"

    public cpctlRichTextBoxKeyWord()
      //***
      // Action
      //   - Create an instance of cpctlRichTextBoxKeyWord
      //   - Create an instance of cpKeyWordCollection
      //   - Set a list of separators
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - cpKeyWordCollection()
      //   - KeyWord(cpKeyWordCollection) (Set)
      //   - Separator(Char[]) (Set)
      // Created
      //   - CopyPaste � 20250721 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250721 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      KeyWord = new cpKeyWordCollection();
      Separator = new char[] {';', ' ', ',', ':', '!', '@', '#', '$', '%', '^', '&', 
                              '*', '(', ')', '[', ']', '<', '>', '/', '"', (char)Keys.LineFeed};
    }
    // cpctlRichTextBoxKeyWord()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private char[] marrchrWordSeparator;
    private cpKeyWordCollection mcpKeyWordCollection;

    #endregion

    #region "Properties"

    public cpKeyWordCollection KeyWord
    {

      get
        //***
        // Action Get
        //   - Return mcpKeyWordCollection
        // Called by
        //   - SetWordAttributes(int, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250721 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250721 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mcpKeyWordCollection;
      }
      // cpKeyWordCollection KeyWord (Get)

      set
        //***
        // Action Set
        //   - If value is nothing
        //     - Throw argumentnull exception
        //   - If not
        //     - mcpKeyWordCollection becomes value
        // Called by
        //   - cpctlRichTextBoxKeyWord()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250721 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250721 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (value == null)
        {
          throw new ArgumentNullException();
        }
        else
          // value <> null
        {
          mcpKeyWordCollection = value;
        }
        // value = null

      }
      // KeyWord(cpKeyWordCollection) (Set)

    }
    // cpKeyWordCollection KeyWord

    public char[] Separator
    {

      get
        //***
        // Action Get
        //   - Return marrchrWordSeparator
        // Called by
        //   - FindWord(int, �int, �int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250721 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250721 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return marrchrWordSeparator;
      }
      // char[] Separator (Get)

      set
        //***
        // Action Set
        //   - If value is null
        //     - Throw argumentnull exception
        //   - If not
        //     - If value has no elements
        //       - Throw argument exception that there must be 1 character
        //     - If not
        //       - mcpKeyWordCollection becomes value 
        // Called by
        //   - cpctlRichTextBoxKeyWord()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250721 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250721 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (value == null)
        {
          throw new ArgumentNullException();
        }
        else if (value.Length == 0)
          // value <> null
        {
          throw new ArgumentException("The array must contain at least one character.");
        }
        else
          // value <> null
          // value.Length <>0
        {
          marrchrWordSeparator = value;
        }
        // value = null
        // value.Length = 0

      }
      // Separator(char[]) (Set)

    }
    // char[] Separator

    #endregion

    #region "Methods"

    #region "Overrides"

    protected override void OnTextChanged(EventArgs theEventArguments)
      //***
      // Action
      //   - If there is no text
      //     - Do nothing
      //   - If not
      //     - Find the word in the text that you are typing (changing)
      //       - Selection start is the current cursor position
      //       - lngStartPosition is by reference and so changed by the function
      //       - lngLength is also by reference and so changed by the function
      //     - If there is a word selected
      //       - Set the attributes to that word
      // Called by
      //   - 
      // Calls
      //   - FindWord(int, �int, �int)
      //   - SetWordAttributes(int, int)
      // Created
      //   - CopyPaste � 20250721 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250721 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngLength = 0;
      int lngStartPosition = 0;

      if (base.Text.Length == 0)
      {
      }
      else
        // base.Text.Length <> 0
      {
        FindWord(base.SelectionStart, ref lngStartPosition, ref lngLength);

        if (lngLength == 0)
        {
        }
        else
          // lngLength <> 0
        {
          SetWordAttributes(lngStartPosition, lngLength);
        }
        // lngLength = 0

        if (base.SelectionStart > 0 && Array.IndexOf(Separator, base.Text[base.SelectionStart - 1]) != -1 )
        {
          FormatText(base.SelectionStart - 1, 1, base.ForeColor, base.Font);
          FindWord(base.SelectionStart - 1, ref lngStartPosition, ref lngLength);
          
          if (lngLength == 0)
          {
            SetWordAttributes(lngStartPosition, lngLength);
          }
          else
            // lngLength <> 0
          {
          }
          // lngLength = 0

        }        
        else
          // base.SelectionStart <= 0 Or Array.IndexOf(Separator, base.Text[base.SelectionStart - 1]) = -1
        {
        }
          // base.SelectionStart > 0 And Array.IndexOf(Separator, base.Text[base.SelectionStart - 1]) <> -1

      }
      // base.Text.Length = 0
    }
    // OnTextChanged(EventArgs)

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void FindWord(int lngSearchPosition, ref int lngPosition, ref int lngLength)
      //***
      // Action
      //   - Position and Length are by reference
      //   - If lngSearchPosition is zero
      //     - lngPreviousPosition becomes zero (start of the text)
      //   - If not
      //     - Find start of the word using the list of separators (lngPreviousPosition)
      //     - If lngPreviousPosition is negative (possible in extreme cases)
      //       - lngPreviousPosition becomes zero
      //   - If lngPreviousPosition is the length of the text (you are at the end of the text)
      //     - lngNextPosition is at the end of the text
      //     - Find end of the word using the list of separators (lngNextPosition)
      //     - If lngNextPosition is negative (possible in extreme cases)
      //       - lngNextPosition becomes end of the text
      //   - lngPosition becomes the start of the word
      //   - lngLength becomes the length of the changed word
      // Called by
      //   - cpRichTextBoxKeyword_TextChanged(System.Object, System.EventArgs) Handles MyBase.TextChanged
      // Calls
      //   - Separator() As Char() (Get)
      // Created
      //   - CopyPaste � 20250721 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250721 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngNextPosition;
      int lngPreviousPosition;

      if (lngSearchPosition == 0)
      {
        lngPreviousPosition = 0;
      }
      else
        // lngSearchPosition <> 0
      {
        lngPreviousPosition = base.Text.LastIndexOfAny(Separator, lngSearchPosition - 1) + 1;

        if (lngPreviousPosition == -1)
        {
          lngPreviousPosition = 0;
        }
        else
          // lngPreviousPosition <> -1
        {
        }
        // lngPreviousPosition = -1

      }
      // lngSearchPosition == 0

      if (lngSearchPosition == base.Text.Length)
      {
        lngNextPosition = base.Text.Length;
      }
      else
        // lngSearchPosition <> base.Text.Length
      {
        lngNextPosition = base.Text.IndexOfAny(Separator, lngSearchPosition);

        if (lngNextPosition == -1)
        {
          lngNextPosition = base.Text.Length;
        }
        else
          // lngNextPosition <> -1
        {
        }
        // lngNextPosition = -1

      }
      // lngSearchPosition <> base.Text.Length

      lngPosition = lngPreviousPosition;
      lngLength = lngNextPosition - lngPreviousPosition;
    }
    // FindWord(int, �int, �int)

    private void FormatText(int lngStartPosition, int lngLength, Color clrText, Font fntText)
      //***
      // Action
      //   - Select the specific word, and find the start and the length
      //   - If there is a text color
      //     - The selection color becomes the given color
      //   - If not
      //     - The selection color becomes the fore color
      //   - If there is text font
      //     - The selection font becomes the given font
      //   - If not
      //     - The selection font becomes the font
      //   - Select the specific word (with the found start and length)
      //   - Set the font and the color
      // Called by
      //   - SetWordAttributes(int, int)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250721 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250721 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngSaveSelectionStart = base.SelectionStart;
      int lngSaveSelectionLength = base.SelectionLength;

      base.Select(lngStartPosition, lngLength);

      if (clrText.IsEmpty)
      {
        base.SelectionColor = base.ForeColor;
      }
      else
        // Not clrText.IsEmpty
      {
        base.SelectionColor = clrText;
      }
      // clrText.IsEmpty

      if (fntText == null)
      {
        base.SelectionFont = base.Font;
      }
      else
        // fntText <> null
      {
        base.SelectionFont = fntText;
      }
      // fntText == null

      base.Select(lngSaveSelectionStart, lngSaveSelectionLength);
      base.SelectionColor = base.ForeColor;
      base.SelectionFont = base.Font;
    }
    // FormatText(int, int, Color, Font)

    private void SetWordAttributes(int lngStartPosition, int lngLength)
      //***
      // Action
      //   - Check if the word currently changed is one of the keywords
      //   - If so
      //     - Change format to the decided format for that keyword
      //   - If not
      //     - Change format to normal
      // Called by
      //   - Item(String) As cpKeyWordFormat (Get)
      //   - KeyWord() As cpKeyWordCollection (Get)
      // Calls
      //   - Color cpKeyWordFormat.Color (Get)
      //   - Font cpKeyWordFormat.Font (Get)
      //   - FormatText(int, int, Color, Font)
      // Created
      //   - CopyPaste � 20250721 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250721 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpKeyWordFormat thecpKeyWordFormat = KeyWord[base.Text.Substring(lngStartPosition, lngLength)];

      if (thecpKeyWordFormat == null)
      {
        FormatText(lngStartPosition, lngLength, base.ForeColor, base.Font);
      }
      else
        // thecpKeyWordFormat <> null
      {
        FormatText(lngStartPosition, lngLength, thecpKeyWordFormat.Color, thecpKeyWordFormat.Font);
      }
      // thecpKeyWordFormat = null

    }
    // SetWordAttributes(int, int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpctlRichTextBoxKeyWord

}
// CopyPaste.Learning.UserInterface
