﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmGuess.aspx.cs" Inherits="CopyPaste.Learning.wfrmGuess" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>wfrmGuess</title>
</head>
<body ms_positioning="GridLayout">
  <form id="wfrmGuess" method="post" runat="server">
    <asp:TextBox ID="txtGuess" Style="z-index: 101; position: absolute; top: 24px; left: 32px" runat="server"
      Width="56px"></asp:TextBox>
    <asp:Button ID="cmdGuess" Style="z-index: 106; position: absolute; top: 56px; left: 56px" runat="server"
      Text="Guess"></asp:Button>
    <asp:Label ID="lblInfo" Style="z-index: 105; position: absolute; top: 56px; left: 120px" runat="server"
      Width="176px"></asp:Label>
    <asp:Label ID="lblNumberOfGuesses" Style="z-index: 104; position: absolute; top: 96px; left: 56px"
      runat="server">Number of guesses: 0</asp:Label>
    <asp:RangeValidator ID="rgvGuess" Style="z-index: 103; position: absolute; top: 24px; left: 104px" runat="server"
      ErrorMessage="The number must be between 0 and 100" ControlToValidate="txtGuess" MaximumValue="100"
      MinimumValue="0" Type="Integer"></asp:RangeValidator>
    <asp:RequiredFieldValidator ID="rfvGuess" Style="z-index: 102; position: absolute; top: 24px; left: 104px" runat="server"
      ErrorMessage="Type a number between 0 and 100" ControlToValidate="txtGuess"></asp:RequiredFieldValidator>
  </form>
</body>
</html>
