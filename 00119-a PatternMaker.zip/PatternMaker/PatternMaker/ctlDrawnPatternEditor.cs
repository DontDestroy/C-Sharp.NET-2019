//***
// Action
//   - Control pattern editor for drawings
//     - Event save must be triggered, but is implemented where it is used
// Created
//   - CopyPaste � 20240330 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240330 � VVDW
// Proposal (To Do)
//   -
//***

using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpctlDrawnPatternEditor : cpctlPatternEditor
  {

    #region Component Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdSave;
    internal System.Windows.Forms.Label lblText;
    internal System.Windows.Forms.PictureBox picBox;

    private void InitializeComponent()
    {
      this.cmdSave = new System.Windows.Forms.Button();
      this.lblText = new System.Windows.Forms.Label();
      this.picBox = new System.Windows.Forms.PictureBox();
      this.SuspendLayout();
      // 
      // cmdSave
      // 
      this.cmdSave.Location = new System.Drawing.Point(8, 120);
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.TabIndex = 5;
      this.cmdSave.Text = "Save";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // lblText
      // 
      this.lblText.Location = new System.Drawing.Point(8, 88);
      this.lblText.Name = "lblText";
      this.lblText.TabIndex = 4;
      // 
      // picBox
      // 
      this.picBox.Location = new System.Drawing.Point(8, 16);
      this.picBox.Name = "picBox";
      this.picBox.Size = new System.Drawing.Size(62, 62);
      this.picBox.TabIndex = 3;
      this.picBox.TabStop = false;
      this.picBox.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picBox_MouseMove);
      this.picBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picBox_MouseDown);
      // 
      // cpctlDrawnPatternEditor
      // 
      this.Controls.Add(this.cmdSave);
      this.Controls.Add(this.lblText);
      this.Controls.Add(this.picBox);
      this.Name = "cpctlDrawnPatternEditor";
      this.Size = new System.Drawing.Size(175, 150);
      this.ResumeLayout(false);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpctlDrawnPatternEditor'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpctlDrawnPatternEditor(cpDrawnPattern thePattern) : base()
      //***
      // Action
      //   - Create new instance of 'cpctlDrawnPatternEditor', a cpDrawnPattern is given
      //   - Redefine the length of marrPoints
      //   - All points are copied towards the points of the patters
      //   - A draw method is assigned as handler for the paint action in the picBox
      //   - cpDrawnPattern is assigned to the variable of the class
      // Called by
      //   - cpctlPatternEditor cpDrawnPattern.cpGetEditor()
      //   - cpctlPatternEditor(cpDrawnPattern)
      //   - User action (Starting the control)
      // Calls
      //   - cpDrawnPattern.Points() (Get)
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();

      this.marrPoints = new Point[thePattern.Points.Length];

      thePattern.Points.CopyTo(this.marrPoints, 0);
      this.picBox.Paint += new PaintEventHandler(this.cpDraw);
      mcpPattern = thePattern;
    }
    // cpctlDrawnPatternEditor()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private Point[] marrPoints = new Point[] {};
    private cpDrawnPattern mcpPattern;
    public override event cpSavedEventHandler cpSaved;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The array of points is saved into the pattern
      //   - Trigger the save event
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpctlPatternEdit.cpRaiseSaved(System.Object, System.EventArgs)
      //   - cpDrawnPattern.Points(Points()) (Set)
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpPattern.Points = marrPoints;

      if (this.cpSaved == null)
      {
      }
      else
        // this.cpSaved <> null
      {
        this.cpSaved(this, new System.EventArgs());
      }
      // this.cpSaved = null

    }
    // cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdSave.Click

    private void picBox_MouseDown(System.Object theSender, System.Windows.Forms.MouseEventArgs theMouseEventArguments)
      //***
      // Action
      //   - When the picture box is clicked
      //   - A point is added to the array of points
      //   - The last element of the array is filled with a new point
      // Called by
      //   - User action (Clicking the picture box)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Point[] marrNewPoints = new Point[marrPoints.Length + 1];

      marrPoints.CopyTo(marrNewPoints, 0);
      marrNewPoints[marrNewPoints.Length - 1] = new Point(theMouseEventArguments.X, theMouseEventArguments.Y);
      marrPoints = marrNewPoints;
      this.Refresh();
    }
    // picBox_MouseDown(System.Object, System.Windows.Forms.MouseEventArgs) Handles picBox.MouseDown

    private void picBox_MouseMove(System.Object theSender, System.Windows.Forms.MouseEventArgs theMouseEventArguments)
      //***
      // Action
      //   - Show the coordinates of the position where you are
      // Called by
      //   - User action (Move mouse over picture box)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblText.Text = string.Format("({0},{1})", theMouseEventArguments.X, theMouseEventArguments.Y);
    }
    // picBox_MouseMove(System.Object, System.Windows.Forms.MouseEventArgs) Handles picBox.MouseMove
    
    #endregion

    #region "Functionality"

    #region "Event"

    public void cpDraw(System.Object theSender, System.Windows.Forms.PaintEventArgs thePaintEventArguments)
      //***
      // Action
      //   - A rectangle is drawn of 60 by 60 pixels
      //   - For every pair of points in the array
      //     - A line is drawn using the pair or coordinates
      // Called by
      //   - cpctlPatternEditor.cpRaiseSaved(System.Object, System.EventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int intPoint;
      
      thePaintEventArguments.Graphics.DrawRectangle(new Pen(Brushes.Black, 1), 0, 0, 60, 60);

      for (intPoint = 0; intPoint < marrPoints.Length - 1; intPoint++)
      {
        Point thePointOne = marrPoints[intPoint];
        Point thePointTwo = marrPoints[intPoint + 1];
        
        thePaintEventArguments.Graphics.DrawLine(Pens.Black, thePointOne, thePointTwo);
      }
      // intPoint = marrPoints.Length - 1

    }
    // cpDraw(System.Object, System.Windows.Forms.PaintEventArgs)

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpctlDrawnPatternEditor

}
// CopyPaste.Learning