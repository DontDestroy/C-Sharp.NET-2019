'***
' Action
'   - Possible variable types
' Created
'   - CopyPaste � 20210824 � VVDW
' Changed
'   - Organisation � yyyymmdd � Initials of programmer � What changed
' Tested
'   - CopyPaste � 20210824 � VVDW
' Changed
'   - CopyPaste � yyyymmdd � VVDW � What changed
' Proposal (To Do)
'   -
'***

Option Explicit On 
Option Strict On

Public Module modVariables
  Dim blnMarried As Boolean
  Dim bytAsciiCode As Byte
  Dim chrMiddleInitial As Char
  Dim dblCarLoan As Double
  Dim decHomeLoan As Decimal
  Dim dtmBirthDate As Date
  Dim intShoeSize As Integer
  Dim lngWeight As Long
  Dim objSomething As Object
  Dim shtAge As Short
  Dim sngAnnualIncome As Single
  Dim strAddress As String

  Public Sub Main()
    '***
    ' Action
    '   - Set some variables with values
    '   - Show the variable contents
    ' Called by
    '   - 
    ' Calls
    '   - System.Console.ReadLine()
    '   - System.Console.WriteLine(String)
    '   - System.Console.WriteLine(String, System.Object)
    ' Created
    '   - CopyPaste � 20210824 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210824 � VVDW
    ' Keyboard key
    '   -
    ' Proposal (To Do)
    '   -
    '***

    blnMarried = True
    bytAsciiCode = 17
    chrMiddleInitial = "V"c
    dblCarLoan = 23752.65
    decHomeLoan = 137240.25D
    dtmBirthDate = #5/6/1970#
    intShoeSize = 42
    lngWeight = 179
    objSomething = "a nice message"
    shtAge = 50
    sngAnnualIncome = 12345.67
    strAddress = "C. Ameyestraat"

    Console.WriteLine("THE VARIABLES PROGRAM")
    Console.WriteLine("---------------------")
    Console.WriteLine("The Boolean is {0}.", blnMarried)
    Console.WriteLine("The Byte is {0}.", bytAsciiCode)
    Console.WriteLine("The Char is {0}.", chrMiddleInitial)
    Console.WriteLine("The Double is {0}.", dblCarLoan)
    Console.WriteLine("The Decimal is {0}.", decHomeLoan)
    Console.WriteLine("The Date is {0}.", dtmBirthDate)
    Console.WriteLine("The Integer is {0}.", intShoeSize)
    Console.WriteLine("The Long is {0}.", lngWeight)
    Console.WriteLine("The Object is {0}.", objSomething)
    Console.WriteLine("The Short is {0}.", shtAge)
    Console.WriteLine("The Single is {0}.", sngAnnualIncome)
    Console.WriteLine("The String is {0}.", strAddress)
    Console.WriteLine("")
    Console.WriteLine("Press Enter...")
    Console.ReadLine()
  End Sub
  ' Main()

End Module
' modVariables