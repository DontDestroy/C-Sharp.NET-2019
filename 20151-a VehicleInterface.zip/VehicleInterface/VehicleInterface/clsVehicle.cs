﻿//***
// Action
//   - Implementation of an abstract class cpVehicle
//     - There are internal classes, methods, properties, indexers or events not implemented (defined as abstract)
//     - This means, this class can't be instantiated
//     - To use the functionality, it must be inherited
// Created
//   - CopyPaste – 20260128 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260128 – VVDW
// Proposal (To Do)
//   - Pay attention to the modifier abstract
//   - Pay attention to the access modifier protected
//***

namespace CopyPaste.Learning
{

  public abstract class cpVehicle
  {

    #region "Constructors / Destructors"

    public cpVehicle()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpRoadVehicle((string, int, int, int)
    //   - User action (Creating an instance thru inheritance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpVehicle()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    protected bool _drivingForward;
    protected uint _currentSpeed;
    protected uint _maximumSpeedBackward;
    protected uint _maximumSpeedForward;
    protected uint _wheelCount;
    protected string _vehicleIdentificationNumber;

    #endregion

    #region "Properties"

    public abstract uint CurrentSpeed { get; set; }
    // This is a virtual property that must be implemented by the child class (downwards inheritance)
    // uint cpRoadVehicle.CurrentSpeed
    // string ToString()

    public abstract bool DirectionForward { get; set; }
    // This is a virtual property that must be implemented by the child class (downwards inheritance)
    // bool cpRoadVehicle.DirectionForward 
    // string ToString()

    public abstract uint MaximumSpeedBackward { get; set; }
    // This is a virtual property that must be implemented by the child class (downwards inheritance)
    // uint cpRoadVehicle.MaximumSpeedBackward
    // string ToString()

    public abstract uint MaximumSpeedForward { get; set; }
    // This is a virtual property that must be implemented by the child class (downwards inheritance)
    // uint cpRoadVehicle.MaximumSpeedForward 
    // string ToString()

    public abstract string VehicleIdentificationNumber { get; set; }
    // This is a virtual property that must be implemented by the child class (downwards inheritance)
    // string cpRoadVehicle.VehicleIdentificationNumber 
    // string ToString()

    public abstract uint WheelCount { get; set; }
    // This is a virtual property that must be implemented by the child class (downwards inheritance)
    // uint cpRoadVehicle.WheelCount
    // string ToString()

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
    //***
    // Action
    //   - Visualization of a cpVehicle
    // Called by
    //   - cpProgram.Main() (thru inheritance)
    // Calls
    //   - bool DirectionForward (Get) (thru inheritance)
    //   - string VehicleIdentificationNumber (Get) (thru inheritance)
    //   - uint CurrentSpeed (Get) (thru inheritance)
    //   - uint MaximumSpeedBackward (Get) (thru inheritance)
    //   - uint MaximumSpeedForward (Get) (thru inheritance)
    //   - uint WheelCount (Get) (thru inheritance)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strMessage;

      strMessage = $"VIN Number             : {VehicleIdentificationNumber}\n" +
                   $"Wheel count            : {WheelCount}\n" +
                   $"Direction forward      : {DirectionForward}\n" +
                   $"Current speed          : {CurrentSpeed}\n" +
                   $"Maximum speed forward  : {MaximumSpeedForward}\n" +
                   $"Maximum speed backward : {MaximumSpeedBackward}\n";

      return strMessage;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public abstract void BreakingDown(uint intVelocity);
    // This is a virtual method that must be implemented by the child class (downwards inheritance)

    public abstract void ChangeDirection();
    // This is a virtual method that must be implemented by the child class (downwards inheritance)

    public abstract void SpeedingUp(uint intVelocity);
    // This is a virtual method that must be implemented by the child class (downwards inheritance)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpVehicle

}
// CopyPaste.Learning