﻿//***
// Action
//   - Create a delegate that will compare 2 values
//   - Create 2 sortroutines (bubble sort) that uses those compare
// Created
//   - CopyPaste – 20250712 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250712 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpSort
  {

    #region "Constructors / Destructors"

    public cpSort()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - frmDelegate.cmdDelegate_Click(System.Object, System.EventArgs) Handles cmdDelegate.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250712 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250712 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpSort()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate bool CompareFunction(int lngX, int lngY);

    #endregion

    #region "Sub / Function"

    public bool CompareFunctionAscending(int lngX, int lngY)
      // Action
      //   - Compare 2 values
      //     - If first is bigger than second
      //       - Return true
      //     - If not
      //       - Return false
      // Called by
      //   - frmDelegate.cmdDelegate_Click(System.Object, System.EventArgs) Handles cmdDelegate.Click
      //   - KindOfBubbleSort(CompareFunction, int[])
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250712 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250712 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;
      
      if (lngX > lngY)
      {
        blnResult = true;
      }
      else
        // lngX <= lngY
      {
        blnResult = false;
      }
      // lngX > lngY

      return blnResult;
    }
    // bool CompareFunctionAscending(int, int)

    public bool CompareFunctionDescending(int lngX, int lngY)
      // Action
      //   - Compare 2 values
      //     - If first is smaller than second
      //       - Return true
      //     - If not
      //       - Return false
      // Called by
      //   - frmDelegate.cmdDelegate_Click(System.Object, System.EventArgs) Handles cmdDelegate.Click
      //   - KindOfBubbleSort(CompareFunction, int[])
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250712 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250712 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;
      
      if (lngX < lngY)
      {
        blnResult = true;
      }
      else
        // lngX >= lngY
      {
        blnResult = false;
      }
      // lngX < lngY

      return blnResult;
    }
    // bool CompareFunctionAscending(int, int)

    public void KindOfBubbleSort(CompareFunction theCompareFunction, int[] arrInteger)
      //***
      // Action
      //   - Loop thru all elements of the array (lngCounter01)
      //     - Loop thru all elements of the array starting from the next lngCounter01 (lngCounter02)
      //       - Execute a comparefunction between element lngCounter01 and lngCounter02 (Returns in True or False)
      //       - If True
      //        - Swap the elements on position lngCounter01 and lngCounter02
      //       - If not
      //         - Do nothing
      // Called by
      //   - 
      // Calls
      //   - bool CompareFunctionAscending(int, int) (thru delegate)
      //   - bool CompareFunctionDescending(int, int) (thru delegate)
      //   - frmDelegate.cmdDelegate_Click(System.Object, System.EventArgs) Handles cmdDelegate.Click
      // Created
      //   - CopyPaste – 20250712 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250712 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngCounter01;
      int lngCounterTill;
      int lngCounter02;
      int lngTemp;
      
      lngCounterTill = arrInteger.GetUpperBound(0);

      for (lngCounter01 = 0; lngCounter01 <= lngCounterTill; lngCounter01++)
      {

        for (lngCounter02 = lngCounter01 + 1; lngCounter02 <= lngCounterTill; lngCounter02++)
        {

          if (theCompareFunction(arrInteger[lngCounter01], arrInteger[lngCounter02]))
          {
            lngTemp = arrInteger[lngCounter02];
            arrInteger[lngCounter02] = arrInteger[lngCounter01];
            arrInteger[lngCounter01] = lngTemp;
          }
          else
            // Not theCompareFunction.Invoke(arrInteger[lngCounter01], arrInteger[lngCounter02])
          {
          }
          // theCompareMethod.Invoke(arrInteger[lngCounter01], arrInteger[lngCounter02])
            
        }
        // lngCounter02 = arrInteger.GetUpperBound(0)
        
      }
      // lngCounter01 = arrInteger.GetUpperBound(0) + 1

    }
    // KindOfBubbleSort(CompareFunction, Int32())

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpSort

}
// CopyPaste.Learning