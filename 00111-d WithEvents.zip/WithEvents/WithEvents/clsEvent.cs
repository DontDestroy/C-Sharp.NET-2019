//***
// Action
//   - Implementation of cpEvent
// Created
//   - CopyPaste � 20240520 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240520 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning.Event
{

  public class cpEvent
  {

    #region "Constructors / Destructors"

    public cpEvent()
      //***
      // Action
      //   - Empty Constructor
      // Called by
      //   - frmWithEvent()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpEvent()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public delegate void cpDelegate(int lngEventParameter);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public event cpDelegate theEvent;

    #endregion

    #region "Sub / Function"

    public void RaiseTheEvent(int lngEventNumber)
      //***
      // Action
      //   - Executes the event handled by "RaiseTheEvent"
      //   - The actual code to run is defined in the frmWithEvents
      // Called by
      //   - frmWithEvents.cmdRaiseEvent_Click(System.Object, System.EventArgs) Handles cmdRaiseEvent.Click
      // Calls
      //   - theEvent(Int32)
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (theEvent == null)
      {
      }
      else
        // theEvent <> null
      {
        theEvent(lngEventNumber);
      }
      // theEvent = null
      
    }
		// RaiseTheEvent(int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx