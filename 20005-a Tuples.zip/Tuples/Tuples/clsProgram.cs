﻿//***
// Action
//   - An example of working with Tuples
// Created
//   - CopyPaste – 20251129 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251130 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void CompareTuples()
    //***
    // Action
    //   - Create a first instrument (a guitar)
    //   - Create a second instrument (a violin)
    //   - Create a guitar tuple with 6 strings
    //   - Create a violin tuple with 4 strings
    //   - Compare some values of the tuple
    //   - Compare the tuples with equal
    //   - Compare the tuples with ==
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251130 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string aMessage;
      StringInstrumentType firstInstrumentType = StringInstrumentType.guitar;
      StringInstrumentType secondInstrumentType = StringInstrumentType.violin;

      (StringInstrumentType TypeOfInstrument, int NumberOfStrings) aGuitar = (firstInstrumentType, 6);
      (StringInstrumentType TypeOfInstrument, int NumberOfStrings) aViolin = (secondInstrumentType, 4);

      Console.WriteLine("Compare values of the tuple");

      if (aGuitar.NumberOfStrings == aViolin.NumberOfStrings)
      {
        aMessage = $"A {aGuitar.TypeOfInstrument} does have the same number of strings as a {aViolin.TypeOfInstrument}";
      }
      else
      // aGuitar.NumberOfStrings <> aViolin.NumberOfStrings
      {
        aMessage = $"A {aGuitar.TypeOfInstrument} does not have the same number of strings as a {aViolin.TypeOfInstrument}";
      }
      // aGuitar.NumberOfStrings = aViolin.NumberOfStrings

      Console.WriteLine(aMessage);
      Console.WriteLine();
      Console.WriteLine("Compare the tuples");

      if (aGuitar.Equals(aViolin))
      {
        aMessage = "The two instruments to compare are the same";
      }
      else
      // Not aGuitar.Equals(aViolin)
      {
        aMessage = "The two instruments to compare are different";
      }
      // aGuitar.Equals(aViolin)

      Console.WriteLine(aMessage);
      Console.WriteLine();
      Console.WriteLine("Compare the tuples (works only from C# 7.3 !");

      if (aGuitar == aViolin)
      {
        aMessage = "The two instruments to compare are the same";
      }
      else
      // aGuitar <> aViolin
      {
        aMessage = "The two instruments to compare are different";
      }
      // aGuitar = aViolin

      Console.WriteLine(aMessage);
      Console.WriteLine();
    }
    // CompareTuples()

    public static void DeconstructTuples()
    //***
    // Action
    //   - Deconstructing a tuple in 4 ways
    //    - Explicit deconstructing
    //    - Inferring deconstructing
    //    - Individual inferring deconstructing
    //    - Deconstruct into variables
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251130 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      {
        int theGuitarStringCount = 0;
        string theGuitarType = "";

        Console.WriteLine("Deconstructing into variables");

        cpTuple theTuple = new cpTuple();

        (theGuitarType, theGuitarStringCount) = theTuple.GetGuitarType();

        Console.WriteLine("Values: {0} - {1}", theGuitarType, theGuitarStringCount);
        Console.WriteLine();
      }
      // Define a scope

      {
        Console.WriteLine("Explicit deconstructing");

        cpTuple theTuple = new cpTuple();
        (string GuitarType, int GuitarStringCount) = theTuple.GetGuitarType();

        Console.WriteLine("Values: {0} - {1}", GuitarType, GuitarStringCount);
        Console.WriteLine();
      }
      // Define a scope

      {
        Console.WriteLine("Inferring deconstructing");

        cpTuple theTuple = new cpTuple();
        var (GuitarType, GuitarStringCount) = theTuple.GetGuitarType();

        Console.WriteLine("Values: {0} - {1}", GuitarType, GuitarStringCount);
        Console.WriteLine();
      }
      // Define a scope

      {
        Console.WriteLine("Individual Inferring deconstructing");

        cpTuple theTuple = new cpTuple();
        (var GuitarType, var GuitarStringCount) = theTuple.GetGuitarType();

        Console.WriteLine("Values: {0} - {1}", GuitarType, GuitarStringCount);
        Console.WriteLine();
      }
      // Define a scope

    }
    // DeconstructTuples()

    public static void InstanceTuple()
    //***
    // Action
    //   - Define a string instrument
    //   - Define the number of strings
    //   - Create a tuple as argument
    //   - Play that string instrument
    // Called by
    //   - Main()
    // Calls
    //   - PlayInstrument((string, int))
    // Created
    //   - CopyPaste – 20251130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251130 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int numberOfStrings = 12;
      StringInstrumentType instrumentType = StringInstrumentType.guitar;

      // string instrumentType = nameof(StringInstrumentType.guitar);
      // string instrumentType = StringInstrumentType.guitar.ToString();
      // VVDW - Alternative, but then you have to change the data types of the variables in the following code

      (StringInstrumentType TypeOfInstrument, int NumberOfStrings) anInstrument = (instrumentType, numberOfStrings);
      PlayInstrument(anInstrument);
    }
    // InstanceTuple()

    public static void Main()
    //***
    // Action
    //   - Starting point of the example of tuples
    //   - Get the guitar type as a tuple
    //   - Show the values of the items
    //   - Get the guitar type as a tuple with names
    //   - Show the named items
    //   - Get the guitar type as a tuple with names with var definition for the tuple
    //   - Show the named items
    //   - Get the guitar type as a tuple with names with var definition for the tuple items
    //   - Show the named items
    //   - Get the guitar type as a tuple
    //   - Show the values of the items
    //   - Get the guitar type as a tuple with names
    //   - Show the named items
    //   - Get the guitar type as a tuple with names with var definition for the tuple
    //   - Show the named items
    //   - Get the guitar type as a tuple with names with var definition for the tuple items
    //   - Show the named items
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - TupleWithItems()
    //   - TupleWithNamedItems()
    //   - InstanceTuple()
    //   - CompareTuples()
    // Created
    //   - CopyPaste – 20251129 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251129 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      TupleWithItems();
      TupleWithNamedItems();
      InstanceTuple();
      CompareTuples();
      DeconstructTuples();

      Console.WriteLine("Hit any key");
      Console.ReadLine();
    }
    // Main()

    public static void PlayInstrument((StringInstrumentType InstrumentKind, int InstrumentNumberOfStrings) instrumentToPlay)
    //***
    // Action
    //   - Playing a string instrument, parameter is a tuple
    // Called by
    //   - InstanceTuple()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251130 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine("You are playing a string instrument");
      Console.WriteLine($"I am playing a {instrumentToPlay.InstrumentKind} with {instrumentToPlay.InstrumentNumberOfStrings} strings");
      Console.WriteLine();
    }
    // PlayInstrument((string, int))

    public static void TupleWithItems()
    //***
    // Action
    //   - Starting point of the example of tuples
    //   - Get the guitar type as a tuple
    //   - Show the values of the items
    //   - Get the guitar type as a tuple with discrete variables
    //   - Show the named items
    //   - Get the guitar type as a tuple with local names with var definition for the tuple
    //   - Show the named items
    //   - Get the guitar type as a tuple with local names with var definition for the tuple items
    //   - Show the named items
    // Called by
    //   - Main()
    // Calls
    //   - cpTuple()
    //   - cpTuple.GetGuitarType()
    // Created
    //   - CopyPaste – 20251130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251130 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpTuple theClassicGuitar = new cpTuple();

      {
        (string, int) theGuitarType = theClassicGuitar.GetGuitarType();
        // A variable of a tuple type

        Console.WriteLine("Show values of the items");
        Console.WriteLine(theGuitarType.Item1);
        Console.WriteLine(theGuitarType.Item2);
        Console.WriteLine();
      }
      // Define a scope

      {
        (string GuitarType, int GuitarStringCount) = theClassicGuitar.GetGuitarType();
        // The tuple is the variable with discrete variables (using deconstructor)

        Console.WriteLine("Show values of the named items");
        Console.WriteLine(GuitarType);
        Console.WriteLine(GuitarStringCount);
        Console.WriteLine();
      }
      // Define a scope

      {
        var (aGuitarType, aGuitarStringCount) = theClassicGuitar.GetGuitarType();
        // The tuple is the variable with changed local item names (var definition of the tuple) (using deconstructor)

        Console.WriteLine("Show values of the named items exact data type");
        Console.WriteLine(aGuitarType);
        Console.WriteLine(aGuitarStringCount);
        Console.WriteLine();
      }
      // Define a scope

      {
        (var aGuitarType, var aGuitarStringCount) = theClassicGuitar.GetGuitarType();
        // The tuple is the variable with changed local item names (var definition of the items of the tuple) (using deconstructor)

        Console.WriteLine("Show values of the named items variable data type");
        Console.WriteLine(aGuitarType);
        Console.WriteLine(aGuitarStringCount);
        Console.WriteLine();
      }
      // Define a scope

    }
    // TupleWithItems()

    public static void TupleWithNamedItems()
    //***
    // Action
    //   - Get the guitar type as a tuple
    //   - Show the values of the items
    //   - Get the guitar type as a tuple with discrete variables
    //   - Show the named items
    //   - Get the guitar type as a tuple with local names with var definition for the tuple
    //   - Show the named items
    //   - Get the guitar type as a tuple with local names with var definition for the tuple items
    //   - Show the named items
    // Called by
    //   - Main()
    // Calls
    //   - cpTupleNamedItems()
    //   - cpTupleNamedItems.GetGuitarType()
    // Created
    //   - CopyPaste – 20251130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251130 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpTupleNamedItems theBassGuitar = new cpTupleNamedItems();

      {
        (string, int) theGuitarType = theBassGuitar.GetGuitarType();
        // A variable of a tuple type

        Console.WriteLine("Show values of the items");
        Console.WriteLine(theGuitarType.Item1);
        Console.WriteLine(theGuitarType.Item2);
        Console.WriteLine();
      }
      // Define a scope

      {
        (string GuitarType, int GuitarStringCount) = theBassGuitar.GetGuitarType();
        // The tuple is the variable with discrete variables (using deconstructor)

        Console.WriteLine("Show values of the named items");
        Console.WriteLine(GuitarType);
        Console.WriteLine(GuitarStringCount);
        Console.WriteLine();
      }
      // Define a scope

      {
        var (aGuitarType, aGuitarStringCount) = theBassGuitar.GetGuitarType();
        // The tuple is the variable with changed local item names (var definition of the tuple) (using deconstructor)

        Console.WriteLine("Show values of the named items exact data type");
        Console.WriteLine(aGuitarType);
        Console.WriteLine(aGuitarStringCount);
        Console.WriteLine();
      }
      // Define a scope

      {
        (var aGuitarType, var aGuitarStringCount) = theBassGuitar.GetGuitarType();
        // The tuple is the variable with changed local item names (var definition of the items of the tuple) (using deconstructor)

        Console.WriteLine("Show values of the named items variable data type");
        Console.WriteLine(aGuitarType);
        Console.WriteLine(aGuitarStringCount);
        Console.WriteLine();
      }
      // Define a scope

    }
    // TupleWithNamedItems()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning