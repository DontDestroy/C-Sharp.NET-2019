﻿//***
// Action
//   - Implementation of a cpSqueak
//		 - The way a thing makes a Squeak sound
// Created
//   - CopyPaste – 20240721 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240721 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Animal.Library
{

	public class cpSqueak : cpiMakeNoise
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpSqueak
		/// </summary>
		public cpSqueak()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240721 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240721 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpSqueak()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing makes a squeak sound
		/// </summary>
		public void MakeNoise()
		//***
		// Action
		//   - Define how something is making a squeak sound
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240721 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240721 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Something is making a squeak sound");
		}
		// MakeNoise()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpSqueak

}
// CopyPaste.Game.Animal.Library