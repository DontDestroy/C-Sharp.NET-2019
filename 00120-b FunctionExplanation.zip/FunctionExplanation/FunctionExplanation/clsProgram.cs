//***
// Action
//   - Testroutine for cpBase and cpDerived
// Created
//   - CopyPaste � 20240617 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240617 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using CopyPaste.Learning;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create an instance of cpBase
      //   - Try to execute all routines that are possible
      //   - Create an instance of cpDerived
      //   - Try to execute all routines that are possible
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - bool cpBase.FunctionFriend()
      //   - bool cpBase.FunctionPrivate()
      //   - bool cpBase.FunctionProtected()
      //   - bool cpBase.FunctionProtectedFriend()
      //   - bool cpBase.FunctionPublic()
      //   - bool cpDerived.FunctionFriend()
      //   - bool cpDerived.FunctionProtectedFriend()
      //   - bool cpDerived.FunctionPublic()
      //   - cpBase.New()
      //   - cpBase.FunctionTestBase()
      //   - cpDerived.New()
      //   - cpDerived.FunctionTestDerived()
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;
      cpBase thecpBase = new cpBase();
      cpDerived thecpDerived = new cpDerived();

      Console.WriteLine("Default startroutine in a module");
      Console.WriteLine();

      Console.WriteLine("Routines in base class");

      blnResult = thecpBase.FunctionInternal();
      Console.WriteLine("Result of base FunctionInternal: {0}", blnResult);
      // thecpBase.FunctionPrivate();
      // thecpBase.FunctionProtected();
      blnResult = thecpBase.FunctionProtectedInternal();
      Console.WriteLine("Result of base FunctionProtectedInternal: {0}", blnResult);

      blnResult = thecpBase.FunctionPublic();
      Console.WriteLine("Result of base FunctionPublic: {0}", blnResult);
      Console.WriteLine();
      thecpBase.FunctionTestBase();
      Console.WriteLine();

      Console.WriteLine("Routines in derived class");
      blnResult = thecpDerived.FunctionInternal();
      Console.WriteLine("Result of derived FunctionInternal: {0}", blnResult);
      // theDerived.FunctionPrivate();
      // theDerived.FunctionProtected();
      blnResult = thecpDerived.FunctionProtectedInternal();
      Console.WriteLine("Result of derived FunctionProtectedInternal: {0}", blnResult);
      blnResult = thecpDerived.FunctionPublic();
      Console.WriteLine("Result of derived FunctionPublic: {0}", blnResult);
      Console.WriteLine();
      thecpDerived.FunctionTestDerived();
      Console.WriteLine();

      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning