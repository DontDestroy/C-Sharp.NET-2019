//***
// Action
//   - Explanation of the code in this module or class
// Created
//   - CopyPaste � 20240426 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240426 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - There is a text that contains the typed taxnumber
      //   - The text is converted to a number
      //   - The number is splitted in 2 parts
      //     - The first part is all except the last 2 digits
      //     - The second part are the last 2 digits
      //   - The first part is divided by 97 and the rest is taken
      //   - You calculate 97 minus the rest
      //   - That result is compared with the second part
      //   - When it is equal, the taxnumber is correct
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240426 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240426 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      const string strBTWNumber = "0213252520";

      int lngBTWNumber;
      int lngRest;
      int lngResult;
      int lngControl;

      lngBTWNumber = Convert.ToInt32(strBTWNumber);
      lngResult = lngBTWNumber / 100;
      lngRest = Convert.ToInt32(lngResult % 97);
      lngControl = lngBTWNumber % 100;

      Console.WriteLine(lngControl == 97 - lngRest);
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning