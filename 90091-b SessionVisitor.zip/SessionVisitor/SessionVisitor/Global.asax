﻿<%@ Application Codebehind="Global.asax.cs" Inherits="CopyPaste.Learning.Global" Language="C#" %>
