//***
// Action
//   - TestRoutine for the custom exception
// Created
//   - CopyPaste � 20240508 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240508 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmCustomException: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdGenerate;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCustomException));
      this.cmdGenerate = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdGenerate
      // 
      this.cmdGenerate.Location = new System.Drawing.Point(88, 40);
      this.cmdGenerate.Name = "cmdGenerate";
      this.cmdGenerate.Size = new System.Drawing.Size(120, 40);
      this.cmdGenerate.TabIndex = 1;
      this.cmdGenerate.Text = "Generate Exception";
      this.cmdGenerate.Click += new System.EventHandler(this.cmdGenerate_Click);
      // 
      // frmCustomException
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(296, 149);
      this.Controls.Add(this.cmdGenerate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCustomException";
      this.Text = "Custom Exception";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmCustomException'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmCustomException()
      //***
      // Action
      //   - Create instance of 'frmCustomException'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmCustomException()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdGenerate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Throw a custom exception and catch it
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpException.New(String)
      // Created
      //   - CopyPaste � 20240508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        MessageBox.Show("About to generate custom exception");
        throw new cpException("** Custom Message **");
      }
      catch (cpException theException)
      {
        MessageBox.Show("Custom Exception thrown " + theException.Message);
      }
      finally
      {
      }

    
    }
    // cmdGenerate_Click(System.Object, System.EventArgs) Handles cmdGenerate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmCustomException
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmCustomException()
      // Created
      //   - CopyPaste � 20240508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmCustomException());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmCustomException

}
// CopyPaste.Learning