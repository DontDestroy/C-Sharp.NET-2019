﻿//***
// Action
//   - Demo of an object pool
//   - Goal is to reuse the memory for every cpMessageParser routine
//   - Given data type T is a class with a basic constructor
// Created
//   - CopyPaste – 20260608 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260608 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Concurrent;

namespace CopyPaste.Learning
{

  public class cpObjectPool<T> where T : class, new()
  {

    #region "Constructors / Destructors"

    public cpObjectPool()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260607 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260607 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      _cbgItems = new ConcurrentBag<T>();
    }
    // cpObjectPool(T)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private readonly ConcurrentBag<T> _cbgItems;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public T Rent()
    //***
    // Action
    //   - Rent some memory, and after used, it will be returned to the memorypool
    //   - Define a variable to return
    //   - Try to take an item an put it in theItem
    //   - If successful
    //     - Assign the taken item into theReturn
    //   - If not
    //     - Assign a new T to theReturn
    // Called by
    //   -
    // Calls
    //   - base.new() (constructor of base data type)
    // Created
    //   - CopyPaste – 20260607 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260607 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      T theReturn;

      if (_cbgItems.TryTake(out T theItem))
      {
        theReturn = theItem;
      }
      else
      // Not _cbgItems.TryTake(out T theItem) (not successful)
      {
        theReturn = new T();
      }
      // _cbgItems.TryTake(out T theItem) (successful)

      return theReturn;
    }
    // T Rent()

    public void Return(T theItem)
    //***
    // Action
    //   - The given item is added to a ConcurrentBag
    //   - It will be used in a pool, so the memory is marked as "can be reused again"
    // Called by
    //   -
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260607 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260607 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      _cbgItems.Add(theItem);
    }
    // Return(T)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpObjectPool

}
// CopyPaste.Learning