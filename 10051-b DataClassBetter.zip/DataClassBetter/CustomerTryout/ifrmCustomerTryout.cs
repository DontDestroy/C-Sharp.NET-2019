//***
// Action
//   - Interface for customer screens
//   - Every change of a text box triggers a text box change
// Created
//   - CopyPaste � 20050508 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20050508 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class ifrmCustomerTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.GroupBox grpCustomerInfo;
    protected System.Windows.Forms.Button cmdNew;
    protected System.Windows.Forms.Button cmdDelete;
    protected System.Windows.Forms.Button cmdSave;
    protected System.Windows.Forms.Button cmdRetrieve;
    protected System.Windows.Forms.TextBox txtFax;
    protected System.Windows.Forms.TextBox txtPhone;
    protected System.Windows.Forms.TextBox txtRegion;
    protected System.Windows.Forms.TextBox txtCountry;
    protected System.Windows.Forms.TextBox txtZip;
    protected System.Windows.Forms.TextBox txtCity;
    protected System.Windows.Forms.TextBox txtAddress;
    protected System.Windows.Forms.TextBox txtContactTitle;
    protected System.Windows.Forms.TextBox txtIdCustomer;
    internal System.Windows.Forms.Label lblFax;
    internal System.Windows.Forms.Label lblPhone;
    internal System.Windows.Forms.Label lblRegion;
    internal System.Windows.Forms.Label lblCountry;
    internal System.Windows.Forms.Label lblZip;
    internal System.Windows.Forms.Label lblCity;
    internal System.Windows.Forms.Label lblAddress;
    internal System.Windows.Forms.Label lblContactTitle;
    internal System.Windows.Forms.Label lblContactName;
    internal System.Windows.Forms.Label lblCompanyName;
    internal System.Windows.Forms.Label lblToString;
    internal System.Windows.Forms.RichTextBox rtxtToString;
    internal System.Windows.Forms.Label lblIdCustomer;
    protected System.Windows.Forms.TextBox txtContactName;
    protected System.Windows.Forms.TextBox txtCompanyName;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ifrmCustomerTryout));
      this.grpCustomerInfo = new System.Windows.Forms.GroupBox();
      this.cmdNew = new System.Windows.Forms.Button();
      this.cmdDelete = new System.Windows.Forms.Button();
      this.cmdSave = new System.Windows.Forms.Button();
      this.cmdRetrieve = new System.Windows.Forms.Button();
      this.txtFax = new System.Windows.Forms.TextBox();
      this.txtPhone = new System.Windows.Forms.TextBox();
      this.txtRegion = new System.Windows.Forms.TextBox();
      this.txtCountry = new System.Windows.Forms.TextBox();
      this.txtZip = new System.Windows.Forms.TextBox();
      this.txtCity = new System.Windows.Forms.TextBox();
      this.txtAddress = new System.Windows.Forms.TextBox();
      this.txtContactTitle = new System.Windows.Forms.TextBox();
      this.txtIdCustomer = new System.Windows.Forms.TextBox();
      this.lblFax = new System.Windows.Forms.Label();
      this.lblPhone = new System.Windows.Forms.Label();
      this.lblRegion = new System.Windows.Forms.Label();
      this.lblCountry = new System.Windows.Forms.Label();
      this.lblZip = new System.Windows.Forms.Label();
      this.lblCity = new System.Windows.Forms.Label();
      this.lblAddress = new System.Windows.Forms.Label();
      this.lblContactTitle = new System.Windows.Forms.Label();
      this.lblContactName = new System.Windows.Forms.Label();
      this.lblCompanyName = new System.Windows.Forms.Label();
      this.lblToString = new System.Windows.Forms.Label();
      this.rtxtToString = new System.Windows.Forms.RichTextBox();
      this.lblIdCustomer = new System.Windows.Forms.Label();
      this.txtContactName = new System.Windows.Forms.TextBox();
      this.txtCompanyName = new System.Windows.Forms.TextBox();
      this.grpCustomerInfo.SuspendLayout();
      this.SuspendLayout();
      // 
      // grpCustomerInfo
      // 
      this.grpCustomerInfo.Controls.Add(this.cmdNew);
      this.grpCustomerInfo.Controls.Add(this.cmdDelete);
      this.grpCustomerInfo.Controls.Add(this.cmdSave);
      this.grpCustomerInfo.Controls.Add(this.cmdRetrieve);
      this.grpCustomerInfo.Controls.Add(this.txtFax);
      this.grpCustomerInfo.Controls.Add(this.txtPhone);
      this.grpCustomerInfo.Controls.Add(this.txtRegion);
      this.grpCustomerInfo.Controls.Add(this.txtCountry);
      this.grpCustomerInfo.Controls.Add(this.txtZip);
      this.grpCustomerInfo.Controls.Add(this.txtCity);
      this.grpCustomerInfo.Controls.Add(this.txtAddress);
      this.grpCustomerInfo.Controls.Add(this.txtContactTitle);
      this.grpCustomerInfo.Controls.Add(this.txtIdCustomer);
      this.grpCustomerInfo.Controls.Add(this.lblFax);
      this.grpCustomerInfo.Controls.Add(this.lblPhone);
      this.grpCustomerInfo.Controls.Add(this.lblRegion);
      this.grpCustomerInfo.Controls.Add(this.lblCountry);
      this.grpCustomerInfo.Controls.Add(this.lblZip);
      this.grpCustomerInfo.Controls.Add(this.lblCity);
      this.grpCustomerInfo.Controls.Add(this.lblAddress);
      this.grpCustomerInfo.Controls.Add(this.lblContactTitle);
      this.grpCustomerInfo.Controls.Add(this.lblContactName);
      this.grpCustomerInfo.Controls.Add(this.lblCompanyName);
      this.grpCustomerInfo.Controls.Add(this.lblToString);
      this.grpCustomerInfo.Controls.Add(this.rtxtToString);
      this.grpCustomerInfo.Controls.Add(this.lblIdCustomer);
      this.grpCustomerInfo.Controls.Add(this.txtContactName);
      this.grpCustomerInfo.Controls.Add(this.txtCompanyName);
      this.grpCustomerInfo.Location = new System.Drawing.Point(8, 8);
      this.grpCustomerInfo.Name = "grpCustomerInfo";
      this.grpCustomerInfo.Size = new System.Drawing.Size(672, 304);
      this.grpCustomerInfo.TabIndex = 1;
      this.grpCustomerInfo.TabStop = false;
      this.grpCustomerInfo.Text = "Customer Info";
      // 
      // cmdNew
      // 
      this.cmdNew.Enabled = false;
      this.cmdNew.Location = new System.Drawing.Point(384, 256);
      this.cmdNew.Name = "cmdNew";
      this.cmdNew.Size = new System.Drawing.Size(72, 24);
      this.cmdNew.TabIndex = 25;
      this.cmdNew.Text = "New";
      // 
      // cmdDelete
      // 
      this.cmdDelete.Enabled = false;
      this.cmdDelete.Location = new System.Drawing.Point(560, 256);
      this.cmdDelete.Name = "cmdDelete";
      this.cmdDelete.Size = new System.Drawing.Size(72, 23);
      this.cmdDelete.TabIndex = 27;
      this.cmdDelete.Text = "Delete";
      // 
      // cmdSave
      // 
      this.cmdSave.Enabled = false;
      this.cmdSave.Location = new System.Drawing.Point(472, 256);
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.Size = new System.Drawing.Size(72, 23);
      this.cmdSave.TabIndex = 26;
      this.cmdSave.Text = "Save";
      // 
      // cmdRetrieve
      // 
      this.cmdRetrieve.Enabled = false;
      this.cmdRetrieve.Location = new System.Drawing.Point(224, 24);
      this.cmdRetrieve.Name = "cmdRetrieve";
      this.cmdRetrieve.Size = new System.Drawing.Size(56, 24);
      this.cmdRetrieve.TabIndex = 2;
      this.cmdRetrieve.Text = "Retrieve";
      // 
      // txtFax
      // 
      this.txtFax.Location = new System.Drawing.Point(112, 272);
      this.txtFax.Name = "txtFax";
      this.txtFax.Size = new System.Drawing.Size(232, 20);
      this.txtFax.TabIndex = 22;
      this.txtFax.Text = "";
      this.txtFax.TextChanged += new System.EventHandler(this.txtFax_TextChanged);
      // 
      // txtPhone
      // 
      this.txtPhone.Location = new System.Drawing.Point(112, 248);
      this.txtPhone.Name = "txtPhone";
      this.txtPhone.Size = new System.Drawing.Size(232, 20);
      this.txtPhone.TabIndex = 20;
      this.txtPhone.Text = "";
      this.txtPhone.TextChanged += new System.EventHandler(this.txtPhone_TextChanged);
      // 
      // txtRegion
      // 
      this.txtRegion.Location = new System.Drawing.Point(112, 224);
      this.txtRegion.Name = "txtRegion";
      this.txtRegion.Size = new System.Drawing.Size(232, 20);
      this.txtRegion.TabIndex = 18;
      this.txtRegion.Text = "";
      this.txtRegion.TextChanged += new System.EventHandler(this.txtRegion_TextChanged);
      // 
      // txtCountry
      // 
      this.txtCountry.Location = new System.Drawing.Point(112, 200);
      this.txtCountry.Name = "txtCountry";
      this.txtCountry.Size = new System.Drawing.Size(232, 20);
      this.txtCountry.TabIndex = 16;
      this.txtCountry.Text = "";
      this.txtCountry.TextChanged += new System.EventHandler(this.txtCountry_TextChanged);
      // 
      // txtZip
      // 
      this.txtZip.Location = new System.Drawing.Point(112, 176);
      this.txtZip.Name = "txtZip";
      this.txtZip.Size = new System.Drawing.Size(232, 20);
      this.txtZip.TabIndex = 14;
      this.txtZip.Text = "";
      this.txtZip.TextChanged += new System.EventHandler(this.txtZip_TextChanged);
      // 
      // txtCity
      // 
      this.txtCity.Location = new System.Drawing.Point(112, 152);
      this.txtCity.Name = "txtCity";
      this.txtCity.Size = new System.Drawing.Size(232, 20);
      this.txtCity.TabIndex = 12;
      this.txtCity.Text = "";
      this.txtCity.TextChanged += new System.EventHandler(this.txtCity_TextChanged);
      // 
      // txtAddress
      // 
      this.txtAddress.Location = new System.Drawing.Point(112, 128);
      this.txtAddress.Name = "txtAddress";
      this.txtAddress.Size = new System.Drawing.Size(232, 20);
      this.txtAddress.TabIndex = 10;
      this.txtAddress.Text = "";
      this.txtAddress.TextChanged += new System.EventHandler(this.txtAddress_TextChanged);
      // 
      // txtContactTitle
      // 
      this.txtContactTitle.Location = new System.Drawing.Point(112, 104);
      this.txtContactTitle.Name = "txtContactTitle";
      this.txtContactTitle.Size = new System.Drawing.Size(232, 20);
      this.txtContactTitle.TabIndex = 8;
      this.txtContactTitle.Text = "";
      this.txtContactTitle.TextChanged += new System.EventHandler(this.txtContactTitle_TextChanged);
      // 
      // txtIdCustomer
      // 
      this.txtIdCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.txtIdCustomer.Location = new System.Drawing.Point(112, 24);
      this.txtIdCustomer.Name = "txtIdCustomer";
      this.txtIdCustomer.Size = new System.Drawing.Size(104, 20);
      this.txtIdCustomer.TabIndex = 1;
      this.txtIdCustomer.Text = "";
      // 
      // lblFax
      // 
      this.lblFax.Location = new System.Drawing.Point(8, 272);
      this.lblFax.Name = "lblFax";
      this.lblFax.TabIndex = 21;
      this.lblFax.Text = "Fax";
      // 
      // lblPhone
      // 
      this.lblPhone.Location = new System.Drawing.Point(8, 248);
      this.lblPhone.Name = "lblPhone";
      this.lblPhone.TabIndex = 19;
      this.lblPhone.Text = "Phone";
      // 
      // lblRegion
      // 
      this.lblRegion.Location = new System.Drawing.Point(8, 224);
      this.lblRegion.Name = "lblRegion";
      this.lblRegion.TabIndex = 17;
      this.lblRegion.Text = "Region";
      // 
      // lblCountry
      // 
      this.lblCountry.Location = new System.Drawing.Point(8, 200);
      this.lblCountry.Name = "lblCountry";
      this.lblCountry.TabIndex = 15;
      this.lblCountry.Text = "Country";
      // 
      // lblZip
      // 
      this.lblZip.Location = new System.Drawing.Point(8, 176);
      this.lblZip.Name = "lblZip";
      this.lblZip.TabIndex = 13;
      this.lblZip.Text = "Zip";
      // 
      // lblCity
      // 
      this.lblCity.Location = new System.Drawing.Point(8, 152);
      this.lblCity.Name = "lblCity";
      this.lblCity.TabIndex = 11;
      this.lblCity.Text = "City";
      // 
      // lblAddress
      // 
      this.lblAddress.Location = new System.Drawing.Point(8, 128);
      this.lblAddress.Name = "lblAddress";
      this.lblAddress.TabIndex = 9;
      this.lblAddress.Text = "Address";
      // 
      // lblContactTitle
      // 
      this.lblContactTitle.Location = new System.Drawing.Point(8, 104);
      this.lblContactTitle.Name = "lblContactTitle";
      this.lblContactTitle.TabIndex = 7;
      this.lblContactTitle.Text = "Contact Title";
      // 
      // lblContactName
      // 
      this.lblContactName.Location = new System.Drawing.Point(8, 80);
      this.lblContactName.Name = "lblContactName";
      this.lblContactName.TabIndex = 5;
      this.lblContactName.Text = "Contact Name";
      // 
      // lblCompanyName
      // 
      this.lblCompanyName.Location = new System.Drawing.Point(8, 56);
      this.lblCompanyName.Name = "lblCompanyName";
      this.lblCompanyName.TabIndex = 3;
      this.lblCompanyName.Text = "Company Name";
      // 
      // lblToString
      // 
      this.lblToString.Location = new System.Drawing.Point(352, 16);
      this.lblToString.Name = "lblToString";
      this.lblToString.TabIndex = 23;
      this.lblToString.Text = "ToString";
      // 
      // rtxtToString
      // 
      this.rtxtToString.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.rtxtToString.Location = new System.Drawing.Point(352, 40);
      this.rtxtToString.Name = "rtxtToString";
      this.rtxtToString.Size = new System.Drawing.Size(310, 200);
      this.rtxtToString.TabIndex = 24;
      this.rtxtToString.TabStop = false;
      this.rtxtToString.Text = "";
      // 
      // lblIdCustomer
      // 
      this.lblIdCustomer.Location = new System.Drawing.Point(8, 24);
      this.lblIdCustomer.Name = "lblIdCustomer";
      this.lblIdCustomer.TabIndex = 0;
      this.lblIdCustomer.Text = "Key Customer";
      // 
      // txtContactName
      // 
      this.txtContactName.Location = new System.Drawing.Point(112, 80);
      this.txtContactName.Name = "txtContactName";
      this.txtContactName.Size = new System.Drawing.Size(232, 20);
      this.txtContactName.TabIndex = 6;
      this.txtContactName.Text = "";
      this.txtContactName.TextChanged += new System.EventHandler(this.txtContactName_TextChanged);
      // 
      // txtCompanyName
      // 
      this.txtCompanyName.Location = new System.Drawing.Point(112, 56);
      this.txtCompanyName.Name = "txtCompanyName";
      this.txtCompanyName.Size = new System.Drawing.Size(232, 20);
      this.txtCompanyName.TabIndex = 4;
      this.txtCompanyName.Text = "";
      this.txtCompanyName.TextChanged += new System.EventHandler(this.txtCompanyName_TextChanged);
      // 
      // ifrmCustomerTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(688, 325);
      this.Controls.Add(this.grpCustomerInfo);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "ifrmCustomerTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Test Class Customer Tryout";
      this.grpCustomerInfo.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'ifrmCustomerTryout'
      // Called by
      //   - frmCustomerValidationBetterTryout.Dispose(bool)
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public ifrmCustomerTryout()
      //***
      // Action
      //   - Create instance of 'ifrmCustomerTryout'
      // Called by
      //   - frmCustomerValidationBetterTryout()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // ifrmCustomer()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected virtual void TextBoxChange(string strProperty, string strValue)
      //***
      // Action
      //   - Placeholder for code when you changed a text box
      // Called by
      //   - txtAddress_TextChanged(System.Object, System.EventArgs) Handles txtAddress.TextChanged
      //   - txtCity_TextChanged(System.Object, System.EventArgs) Handles txtCity.TextChanged
      //   - txtCompanyName_TextChanged(System.Object, System.EventArgs) Handles txtCompanyName.TextChanged
      //   - txtContactName_TextChanged(System.Object, System.EventArgs) Handles txtContactName.TextChanged
      //   - txtContactTitle_TextChanged(System.Object, System.EventArgs) Handles txtContactTitle.TextChanged
      //   - txtCountry_TextChanged(System.Object, System.EventArgs) Handles txtCountry.TextChanged
      //   - txtFax_TextChanged(System.Object, System.EventArgs) Handles txtFax.TextChanged
      //   - txtPhone_TextChanged(System.Object, System.EventArgs) Handles txtPhone.TextChanged
      //   - txtRegion_TextChanged(System.Object, System.EventArgs) Handles txtRegion.TextChanged
      //   - txtZip_TextChanged(System.Object, System.EventArgs) Handles txtZip.TextChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // TextBoxChange(string, string)

    #endregion

    #region "Controls"
    
    private void txtAddress_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Execute the text box changed code
      // Called by
      //   - User action (Changing a text box)
      // Calls
      //   - TextBoxChange(string, string)
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // txtAddress_TextChanged(System.Object, System.EventArgs) Handles txtAddress.TextChanged

    private void txtCity_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Execute the text box changed code
      // Called by
      //   - User action (Changing a text box)
      // Calls
      //   - TextBoxChange(string, string)
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // txtCity_TextChanged(System.Object, System.EventArgs) Handles txtCity.TextChanged

    private void txtCompanyName_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Execute the text box changed code
      // Called by
      //   - User action (Changing a text box)
      // Calls
      //   - TextBoxChange(string, string)
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // txtCompanyName_TextChanged(System.Object, System.EventArgs) Handles txtCompanyName.TextChanged

    private void txtContactName_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Execute the text box changed code
      // Called by
      //   - User action (Changing a text box)
      // Calls
      //   - TextBoxChange(string, string)
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // txtContactName_TextChanged(System.Object, System.EventArgs) Handles txtContactName.TextChanged

    private void txtContactTitle_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Execute the text box changed code
      // Called by
      //   - User action (Changing a text box)
      // Calls
      //   - TextBoxChange(string, string)
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // txtContactTitle_TextChanged(System.Object, System.EventArgs) Handles txtContactTitle.TextChanged

    private void txtCountry_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Execute the text box changed code
      // Called by
      //   - User action (Changing a text box)
      // Calls
      //   - TextBoxChange(string, string)
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // txtCountry_TextChanged(System.Object, System.EventArgs) Handles txtCountry.TextChanged

    private void txtFax_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Execute the text box changed code
      // Called by
      //   - User action (Changing a text box)
      // Calls
      //   - TextBoxChange(string, string)
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // txtFax_TextChanged(System.Object, System.EventArgs) Handles txtFax.TextChanged

    private void txtPhone_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Execute the text box changed code
      // Called by
      //   - User action (Changing a text box)
      // Calls
      //   - TextBoxChange(string, string)
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // txtPhone_TextChanged(System.Object, System.EventArgs) Handles txtPhone.TextChanged

    private void txtRegion_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Execute the text box changed code
      // Called by
      //   - User action (Changing a text box)
      // Calls
      //   - TextBoxChange(string, string)
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // txtRegion_TextChanged(System.Object, System.EventArgs) Handles txtRegion.TextChanged

    private void txtZip_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Execute the text box changed code
      // Called by
      //   - User action (Changing a text box)
      // Calls
      //   - TextBoxChange(string, string)
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // txtZip_TextChanged(System.Object, System.EventArgs) Handles txtZip.TextChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    protected void ClearAllTextBoxes()
      //***
      // Action
      //   - Clear all textboxes
      // Called by
      //   - frmCustomerValidationBetterTryout.cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click
      //   - frmCustomerValidationBetterTryout.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // ClearAllTextBoxes()
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // ifrmCustomerTryout

}
// CopyPaste.Learning