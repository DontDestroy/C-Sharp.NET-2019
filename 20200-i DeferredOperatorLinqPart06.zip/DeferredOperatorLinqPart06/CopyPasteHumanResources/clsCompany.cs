﻿//***
// Action
//   - The definition of a cpCompany
//   - The company has a list of cpEmployees
//   - The company has a list of cpInvestments
// Created
//   - CopyPaste – 20230427 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230427 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;

namespace CopyPaste.HumanResources
{

  public class cpCompany
  {

    #region "Constructors / Destructors"

    public cpCompany(string strCompanyName)
    //***
    // Action
    //   - Creating an instance of a cpCompany
    //   - Creating a list of cpEmployees for that company
    //   - Creating an array of cpInvestments for that company
    //     - An investment is done by an employee
    //   - It is on purpose that there are 2 diffent data types for the information
    //     - The list of employees is an array list
    //     - The list of investments is an array
    // Called by
    //   - cpProgram.BasicLinqCasting()
    // Calls
    //   - cpEmployee(int, string, string)
    //   - CompanyName(string) (Set)
    // Created
    //   - CopyPaste – 20230427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230427 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - This is normally done by a database query
    //***
    {
      CompanyName = strCompanyName;

      colEmployees = new ArrayList();
      colEmployees.Add(new cpEmployee(1, "Vincent", "Van De Walle"));
      colEmployees.Add(new cpEmployee(2, "Hilde", "Saelens"));
      colEmployees.Add(new cpEmployee(3, "Gertrude", "Gryson"));
      colEmployees.Add(new cpEmployee(4, "Petra", "Cuppens"));
      colEmployees.Add(new cpEmployee(5, "Vanhoorelbeke", "Filip"));
      colEmployees.Add(new cpEmployee(6, "Vandesteene", "Ellen"));

      arrInvestments = new cpInvestment[]{
                new cpInvestment { EmployeeNumber = 1,
                  Amount = 22500,
                  DatePayment = DateTime.Parse("2016/12/31") },
                new cpInvestment { EmployeeNumber = 2,
                  Amount = 5000,
                  DatePayment = DateTime.Parse("2022/06/30") },
                new cpInvestment { EmployeeNumber = 2,
                  Amount = 2500,
                  DatePayment = DateTime.Parse("2020/01/01") },
                new cpInvestment { EmployeeNumber = 3,
                  Amount = 5000,
                  DatePayment = DateTime.Parse("2019/09/30") },
                new cpInvestment { EmployeeNumber = 3,
                  Amount = 7500,
                  DatePayment = DateTime.Parse("2019/09/30") },
                new cpInvestment { EmployeeNumber = 4,
                  Amount = 1000,
                  DatePayment = DateTime.Parse("2022/06/30") },
                new cpInvestment { EmployeeNumber = 5,
                  Amount = 1500,
                  DatePayment = DateTime.Parse("2022/06/30") },
                new cpInvestment { EmployeeNumber = 4,
                  Amount = 2500,
                  DatePayment = DateTime.Parse("2018/09/30") },
                new cpInvestment { EmployeeNumber = 1,
                  Amount = 12500,
                  DatePayment = DateTime.Parse("2020/12/31") }
              };

    }
    // cpCompany(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpInvestment[] arrInvestments;
    private ArrayList colEmployees;

    #endregion

    #region "Properties"

    public ArrayList AllEmployees
    {
      //***
      // Action Get
      //   - Returning a list of cpEmployees
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20230427 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20230427 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      get
      {
        return colEmployees;
      }
      // ArrayList AllEmployees (Get)

    }
    // ArrayList AllEmployees

    public cpInvestment[] AllInvestments
    {
      //***
      // Action Get
      //   - Returning an array of cpInvestments
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20230427 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20230427 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      get
      {
        return arrInvestments;
      }
      // cpInvestment[] AllInvestments (Get)

    }
    // cpInvestment[] AllInvestments

    public string CompanyName { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpCompany

}
// CopyPaste.HumanResources