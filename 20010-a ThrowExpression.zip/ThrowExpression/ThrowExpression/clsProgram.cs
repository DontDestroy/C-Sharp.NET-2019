﻿//***
// Action
//   - Demo of Throw Expression
// Created
//   - CopyPaste – 20251222 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251222 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using static System.Console;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251222 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251222 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Try to
    //     - Create a successful instance of a square
    //     - Create an unsuccessful instance of a square
    //   - When error occurs
    //     - Show exception message
    //   - Wait for user input
    //   - Try to
    //     - Create a successful instance of a rectangle
    //     - Create an unsuccessful instance of a rectangle
    //   - When error occurs
    //     - Show exception message
    //   - Wait for user input
    //   - Try to
    //     - Create a successful instance of a rectangle
    //     - Create an unsuccessful instance of a rectangle
    //   - When error occurs
    //     - Show exception message
    //   - Wait for user input
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpRectangle(int, int, string)
    //   - cpRectangle(string)
    //   - cpSquare(int, string)
    // Created
    //   - CopyPaste – 20251222 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251222 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      try
      {
        cpSquare theSuccessful = new cpSquare(5, "First Square");
        cpSquare theUnsuccessful = new cpSquare(5, null);
      }
      catch (ArgumentNullException theException)
      {
        WriteLine(theException.Message);
      }
      finally
      {
        WriteLine();
        WriteLine("Hit any key to continue");
        ReadLine();
      }

      try
      {
        cpRectangle theSuccessful = new cpRectangle(5, 4, "First Rectange");
        cpRectangle theUnsuccessful = new cpRectangle(5, 4, null);
      }
      catch (ArgumentNullException theException)
      {
        WriteLine(theException.Message);
      }
      finally
      {
        WriteLine();
        WriteLine("Hit any key to continue");
        ReadLine();
      }

      try
      {
        cpRectangle theSuccessful = new cpRectangle("First Rectange");
        cpRectangle theUnsuccessful = new cpRectangle(null);
      }
      catch (ArgumentNullException theException)
      {
        WriteLine(theException.Message);
      }
      finally
      {
        WriteLine();
        WriteLine("Hit any key");
        ReadLine();
      }

    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning