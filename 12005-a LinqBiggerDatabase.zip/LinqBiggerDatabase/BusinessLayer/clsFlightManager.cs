﻿//***
// Action
//   - Flight Manager
// Created
//   - CopyPaste – 20230719 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230719 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.BusinessObjects;
using CopyPaste.DataAccess;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CopyPaste.BusinessLayer
{

  public class cpFlightManager : IDisposable
  {

    #region "Constructors / Destructors"

    public cpFlightManager()
    //***
    // Action
    //   - Default Constructor of cpFlightManager
    // Called by
    //   - cpFlightManager(cpWingsContext)
    //   - FlightRepositoryPattern(cpWingsContext)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpFlightManagerSimple()

    public cpFlightManager(cpWingsContext theDatabaseContext) : this()
    //***
    // Action
    //   - Constructor of cpFlightManager with a cpWingsContext as parameter
    // Called by
    //   - FlightRepositoryPatternBookableFlights(cpWingsContext)
    // Calls
    //   - cpFlightManager()
    //   - theContext(cpWingsContext) (Set)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theContext = theDatabaseContext;
    }
    // cpFlightManager(cpWingsContext)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private bool _blnDispose;
    private cpWingsContext _theContext;

    #endregion

    #region "Properties"

    public cpWingsContext theContext
    {

      private get
      //***
      // Action Get
      //   - If _theContext is nothing
      //     - _theContext becomes an instance op cpWingsContext
      //   - Returns _theContext
      // Called by
      //   - Add(Flight)
      //   - Flight GetFlight(int)
      //   - FlightRepositoryPatternBookableFlights(cpWingsContext)
      //   - int Save()
      //   - int Save(List<Flight>)
      //   - IQueryable<Flight> BookableFlights()
      //   - Remove(Flight)
      // Calls
      //   - cpWingsContext()
      // Created
      //   - CopyPaste – 20230719 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20230719 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if (_theContext == null)
        {
          _theContext = new cpWingsContext();
          _blnDispose = true;
        }
        else
        // _theContext <> null
        {
        }
        // _theContext = null

        return _theContext;
      }
      //cpWingsContext theContext (Get)

      set
      //***
      // Action Set
      //   - _theContext becomes value
      // Called by
      //   - cpFlightManager(cpWingsContext)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20230719 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20230719 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        _theContext = value;
      }
      // theContext(cpWingsContext) (Set)

    }
    // cpWingsContext theContext

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public IQueryable<string> AirportsBookableFlightsNextMonth()
    //***
    // Action
    //   - Return all airports (Departure and Destination) of the bookable Flights between today and the next month (borders included)
    //   - Solution is given with the Lambda Linq Dot Notation
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //     - The second solution is too complex to be a good solution
    // Called by
    //   - cpQuery.FlightRepositoryPatternAirportsBookableFlightsNextMonth(cpWingsContext)
    // Calls
    //   - IQueryable<Flight> BookableFlightsNextMonth()
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    // Created
    //   - CopyPaste – 20230720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IQueryable<string> lstUniqueDeparturesLambda;
      IQueryable<string> lstUniqueDestinationsLambda;
      IQueryable<string> lstUniqueAirportsLambda;

      lstUniqueDeparturesLambda = BookableFlightsNextMonth().Select(aFlight => aFlight.Departure).Distinct();
      lstUniqueDestinationsLambda = BookableFlightsNextMonth().Select(aFlight => aFlight.Destination).Distinct();
      lstUniqueAirportsLambda = lstUniqueDeparturesLambda.Union(lstUniqueDestinationsLambda).Distinct();
      return lstUniqueAirportsLambda;

      // // The returned Data Type for the expression solution is a List<string>
      // // Change the code where needed

      // IEnumerable<IGrouping<string, Flight>> colUniqueDeparturesExpression;
      // IEnumerable<IGrouping<string, Flight>> colUniqueDestinationsExpression;
      // Dictionary<string, string> dicUniqueAirportsExpression;
      // List<string> lstUniqueAirportsExpression;

      // colUniqueDeparturesExpression = from aFlight in BookableFlightsNextMonth().AsEnumerable<Flight>()
      //                                 group aFlight by aFlight.Departure;
      // colUniqueDestinationsExpression = from aFlight in BookableFlightsNextMonth().AsEnumerable<Flight>()
      //                                   group aFlight by aFlight.Destination;

      // dicUniqueAirportsExpression = new Dictionary<string, string>();
      // arrlstUniqueAirportsExpression = new List<string>();

      // foreach (IGrouping<string, Flight> aDeparture in colUniqueDeparturesExpression)
      // {

      //   if (dicUniqueAirportsExpression.ContainsKey(aDeparture.Key))
      //   {
      //   }
      //   else
      //   // Not dicUniqueAirportsExpression.ContainsKey(aDeparture.Key)
      //   {
      //     dicUniqueAirportsExpression.Add(aDeparture.Key, aDeparture.Key);
      //   }
      //   // dicUniqueAirportsExpression.ContainsKey(aDeparture.Key)

      // }
      // // in colUniqueDeparturesExpression

      // foreach (IGrouping<string, Flight> aDestination in colUniqueDestinationsExpression)
      // {

      //   if (dicUniqueAirportsExpression.ContainsKey(aDestination.Key))
      //   {
      //   }
      //   else
      //   // Not dicUniqueAirportsExpression.ContainsKey(aDeparture.Key)
      //   {
      //     dicUniqueAirportsExpression.Add(aDestination.Key, aDestination.Key);
      //   }
      //   // dicUniqueAirportsExpression.ContainsKey(aDeparture.Key)

      // }
      // // in colUniqueDestinationsExpression

      // lstUniqueAirportsExpression = dicUniqueAirportsExpression.Keys.ToList();
      // return lstUniqueAirportsExpression;
    }
    // IQueryable<string> AirportsBookableFlightsNextMonth()

    public IQueryable<Flight> BookableFlights()
    //***
    // Action
    //   - Return all the Flights with free seats (so that are bookable)
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    // Called by
    //   - cpQuery.FlightRepositoryPatternBookableFlights(cpWingsContext)
    //   - IQueryable<Flight> BookableFlightsNextMonth()
    // Calls
    //   - cpWingsContext theContext (Get)
    //   - DbSet<Flight> cpWingsContext.Flight (Get)
    //   - short Flight.FreeSeats (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IQueryable<Flight> colResultExpression;

      colResultExpression = from aFlight in theContext.Flight
                            where aFlight.FreeSeats > 0
                            select aFlight;

      // IQueryable<Flight> colResultLambda;
      // colResultLambda = theContext.Flight.Where(aFlight => aFlight.FreeSeats > 0);

      return colResultExpression;
    }
    // IQueryable<Flight> BookableFlights()

    public IQueryable<Flight> BookableFlightsNextMonth()
    //***
    // Action
    //   - Return all the bookable Flights between today and the next month (borders included)
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    // Called by
    //   - IQueryable<string> AirportsBookableFlightsNextMonth()
    //   - IQueryable<Flight> BookableFlightsNextMonthPaging(int, int)
    //   - cpQuery.FlightRepositoryPatternBookableFlightsNextMonth(cpWingsContext)
    //   - IQueryable<Flight> BookableFlightsNextMonthDepartureSortedOnDate(string)
    // Calls
    //   - DateTime Flight.Date (Get)
    //   - IQueryable<Flight> BookableFlights()
    // Created
    //   - CopyPaste – 20230720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      DateTime dtmToday = DateTime.Today;
      DateTime dtmNextMonths = DateTime.Today.AddMonths(1);

      IQueryable<Flight> colResultExpression;

      colResultExpression = from aFlight in BookableFlights()
                            where aFlight.Date >= dtmToday && aFlight.Date <= dtmNextMonths
                            select aFlight;

      // IQueryable<Flight> colResultLambda;
      // colResultLambda = BookableFlights().Where(aFlight => aFlight.Date >= dtmToday && aFlight.Date <= dtmNextMonths);

      return colResultExpression;
    }
    // IQueryable<Flight> BookableFlightsNextMonth()

    public IQueryable<Flight> BookableFlightsNextMonthDepartureSortedOnDate(string strDeparture)
    //***
    // Action
    //   - Return all unbooked Flights with a specific departure (can be empty
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    //   - Pay attention how the sort is executed in the Lambda Linq Dot Notation
    // Called by
    //   - cpQuery.FlightRepositoryPatternBookableFlightsNextMonthDepartureSortedOnDate(cpWingsContext, string)
    // Calls
    //   - DateTime Flight.Date (Get)
    //   - IQueryable<Flight> BookableFlightsNextMonth()
    //   - string Flight.Departure (Get)
    // Created
    //   - CopyPaste – 20230720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IQueryable<Flight> colResultExpression;

      colResultExpression = from aFlight in BookableFlightsNextMonth()
                            orderby aFlight.Date
                            select aFlight;

      if (String.IsNullOrEmpty(strDeparture))
      {
      }
      else
      // Not String.IsNullOrEmpty(strDeparture)
      {
        colResultExpression = from aFlight in colResultExpression
                              where aFlight.Departure == strDeparture
                              select aFlight;
      }
      // String.IsNullOrEmpty(strCityDeparture)

      // IQueryable<Flight> colTempResultLambda;
      // IOrderedQueryable<Flight> colResultLambda;

      // colTempResultLambda = BookableFlightsNextMonth()
      //   .Select(aFlight => aFlight);

      // if (String.IsNullOrEmpty(strDeparture))
      // {
      // }
      // else
      // // Not String.IsNullOrEmpty(strCityDeparture)
      // {
      //   colTempResultLambda = colTempResultLambda.Where(aFlight => aFlight.Departure == strDeparture);
      // }
      // // String.IsNullOrEmpty(strCityDeparture)

      // colResultLambda = colTempResultLambda.OrderBy(aFlight => aFlight.Date);
      return colResultExpression;
    }
    // IQueryable<Flight> BookableFlightsNextMonthDepartureSortedOnDate(string)

    public IQueryable<Flight> BookableFlightsNextMonthPaging(int intStartingPoint, int intNumberOfRecords)
    //***
    // Action
    //   - Return all the bookable Flights between today and the next month (borders included) ordered by date
    //   - Show only a specific number of records, starting with the starting point
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    // Called by
    //   - FlightRepositoryPatternBookableFlightsNextMonthPaging(cpWingsContext, int, int)
    // Calls
    //   - DateTime Flight.Date (Get)
    //   - IQueryable<Flight> BookableFlightsNextMonth()
    // Created
    //   - CopyPaste – 20230720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intStartingPointZeroBased;
      IQueryable<Flight> colResultExpression;

      if (intStartingPoint <= 0)
      {
        intStartingPointZeroBased = 0;
      }
      else
      // intStartingPoint > 0
      {
        intStartingPointZeroBased = intStartingPoint - 1;
      }
      // intStartingPoint <= 0

      colResultExpression = (from aFlight in BookableFlightsNextMonth()
                             orderby aFlight.Date
                             select aFlight)
                             .Skip(intStartingPointZeroBased)
                             .Take(intNumberOfRecords);

      // IQueryable<Flight> colResultLambda;
      // colResultLambda = BookableFlightsNextMonth().OrderBy(Flight => Flight.Date)
      //  .Skip(intStartingPointZeroBased).Take(intNumberOfRecords);

      return colResultExpression;
    }
    // IQueryable<Flight> BookableFlightsNextMonthPaging(int, int)

    public void Dispose()
    //***
    // Action
    //   - Clean up the cpFlightManager
    // Called by
    //   - System action (not using the instance anymore)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (_blnDispose)
      {
        _theContext.Dispose();
      }
      else
      // Not _blnDispose
      {
      }
      // _blnDispose

    }
    // Dispose()

    public Flight GetFlight(int theKeyOfFlight)
    //***
    // Action
    //   - Return the Flights with a specific key
    // Called by
    //   - cpQuery.FlightRepositoryPatternFlight(cpWingsContext, int)
    //   - ReduceFreeSeats(int, short)
    // Calls
    //   - cpWingsContext theContext (Get)
    //   - DbSet<Flight> cpWingsContext.Flight (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return theContext.Flight.Find(theKeyOfFlight);
    }
    // Flight GetFlight(int)

    #endregion

    #endregion

    #endregion

    #region "Not used"

    public void Add(Flight theFlight)
    //***
    // Action
    //   - Add a Flight to the context
    // Called by
    //   - 
    // Calls
    //   - cpWingsContext theContext (Get)
    // Created
    //   - CopyPaste – 20230720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theContext.Add(theFlight);
    }
    // Add(Flight)

    public bool ReduceFreeSeats(int theKeyOfFlight, short intNumberOfSeats)
    //***
    // Action
    //   - Reduces the number of free seats (e.g. in the case of a booking)
    //   - Only done when the needed number of seats are still available
    //   - Returns true if successful, false otherwise
    // Called by
    //   - 
    // Calls
    //   - cpWingsContext theContext (Get)
    //   - Flight GetFlight(int)
    //   - short Flight.FreeSeats (Get)
    //   - Flight.FreeSeats(short) (Set)
    //   - int Save()
    // Created
    //   - CopyPaste – 20230720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Flight theFlight = GetFlight(theKeyOfFlight);

      if (theFlight == null)
      { 
      }
      else
      // theFlight <> null
      {

        if (theFlight.FreeSeats >= intNumberOfSeats)
        {
          theFlight.FreeSeats -= intNumberOfSeats;
          Save();
          return true;
        }
        else
        // theFlight.FreeSeats < intNumberOfSeats
        {
        }
        // theFlight.FreeSeats >= intNumberOfSeats

      }
      // theFlight = null

      return false;
    }
    // ReduceFreeSeats(int, short)

    public void Remove(Flight theFlight)
    //***
    // Action
    //   - Remove a Flight from the context
    // Called by
    //   - 
    // Calls
    //   - cpWingsContext theContext (Get)
    // Created
    //   - CopyPaste – 20230720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theContext.Add(theFlight);
    }
    // Remove(Flight)

    public int Save()
    //***
    // Action
    //   - Save what must be saved in the context
    // Called by
    //   - int Save(List<Flight>)
    //   - ReduceFreeSeats(int, short)
    // Calls
    //   - cpWingsContext theContext (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return theContext.SaveChanges();
    }
    // int Save()

    public int Save(List<Flight> lstFlight)
    //***
    // Action
    //   - Checks if there are objects in the list that do not belong to the context
    //   - The found objects are inserted with Add()
    // Called by
    //   - int Save(List<Flight>)
    // Calls
    //   - cpWingsContext theContext (Get)
    //   - DbSet<Flight> cpWingsContext.Flight (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      foreach (Flight aFlight in lstFlight)
      {

        if (theContext.Entry(aFlight).State == EntityState.Detached)
        {
          theContext.Flight.Add(aFlight);
        }
        else
        // theContext.Entry(aFlight).State <> EntityState.Detached
        {
        }
        // theContext.Entry(aFlight).State = EntityState.Detached

      }
      // in lstFlight

      return Save();
    }
    // int Save(List<Flight>)

    #endregion

  }
  // cpFlightManager

}
// CopyPaste.BusinessLayer