//***
// Action
//   - Implementation of a cpXYPoint that is serializable
// Created
//   - CopyPaste � 20240408 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240408 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;
using System.Runtime.Serialization;

namespace CopyPaste.Learning
{

  // The Serializable attritube marks the class to be serializable
  [SerializableAttribute()]
  public class cpXYPoint : ISerializable
  {

    #region "Constructors / Destructors"

    public cpXYPoint()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - Array of cpTriable
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpXYPoint()

    public cpXYPoint(int lngX, int lngY)
      //***
      // Action
      //   - Constructor of a point with X and Y coordinate
      // Called by
      //   - frmSerialize.frmSerialize_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - X(int) (Set)
      //   - Y(int) (Set)
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      X = lngX;
      Y = lngY;
    }
    // cpXYPoint(int, int)

    public cpXYPoint(SerializationInfo theSerializationInfo, StreamingContext theStreamingContext)
      //***
      // Action
      //   - Constructor of a point with X and Y coordinate when deserialize an informationstream
      // Called by
      //   - frmSerialize.frmSerialize_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - X(int) (Set)
      //   - Y(int) (Set)
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      X = theSerializationInfo.GetInt32("X");
      Y = theSerializationInfo.GetInt32("Y");
    }
    // cpXYPoint(SerializationInfo, StreamingContext)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    int mlngX;
    int mlngY;

    #endregion

    #region "Properties"

    public int X
    {

      get
        //***
        // Action Get
        //   - Returns mlngX
        // Called by
        //   - GetObjectData(SerializationInfo, StreamingContext)
        //   - ToString() As String
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240408 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240408 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngX;
      }
      // int X (Get)

      set
        //***
        // Action Set
        //   - mlngX becomes value
        // Called by
        //   - cpXYPoint(int, int)
        //   - cpXYPoint(SerializationInfo, StreamingContext)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240408 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240408 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngX = value;
      }
      // X(int) (Set)

    }
    // int X

    public int Y
    {

      get
        //***
        // Action Get
        //   - Returns mlngY
        // Called by
        //   - GetObjectData(SerializationInfo, StreamingContext)
        //   - ToString() As String
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240408 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240408 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngY;
      }
      // int Y (Get)

      set
        //***
        // Action Set
        //   - mlngY becomes value
        // Called by
        //   - cpXYPoint(int, int)
        //   - cpXYPoint(SerializationInfo, StreamingContext)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240408 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240408 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngY = value;
      }
      // Y(int) (Set)

    }
    // int Y

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Visualisation of a cpXYPoint
      // Called by
      //   - string cpTriangle.ToString()
      // Calls
      //   - int X (Get) 
      //   - int Y (Get) 
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return string.Format("({0}; {1})", X, Y);
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void GetObjectData(SerializationInfo theSerializationInfo, StreamingContext theStreamingContext)
      //***
      // Action
      //   - Set the X and Y coordinate value into the correct key for serialization
      // Called by
      //   - frmSerialize.cmdSaveBinary_Click(System.Object, System.EventArgs) Handles cmdSaveBinary.Click
      // Calls
      //   - int X (Get) 
      //   - int Y (Get) 
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      theSerializationInfo.AddValue("X", X);
      theSerializationInfo.AddValue("Y", Y);
    }
    // GetObjectData(SerializationInfo, StreamingContext)
	
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpXYPoint

}
// CopyPaste.Learning