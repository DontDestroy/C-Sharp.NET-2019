﻿//***
// Action
//   - Having DataCommands and DataReaders towards a database
// Created
//   - CopyPaste – 20210701 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210701 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataCommands
{
  public partial class frmDataCommands : Form
  {

    #region "Constructors / Destructors"

    public frmDataCommands()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Setting command with 2 parameters for Select Order
    //   - Set properties for mcmmSelectCustomer
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //  - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
      this.mcmmSelectCustomer = new System.Data.SqlClient.SqlCommand();
      this.mcmmSelectOrder = new System.Data.SqlClient.SqlCommand();
      this.mcmmSelectCustomer.CommandText = "SELECT * FROM tblCPCustomer";
      this.mcmmSelectCustomer.CommandType = CommandType.Text;
      this.mcmmSelectCustomer.Connection = this.cnncpNorthwindScript;
      this.mcmmSelectOrder.Parameters.Add("@KeyCustomer", SqlDbType.VarChar);
      this.mcmmSelectOrder.Parameters.Add("@KeyEmployee", SqlDbType.Int);
    }
    // frmDataCommands()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    internal System.Data.SqlClient.SqlCommand mcmmSelectCustomer;
    internal System.Data.SqlClient.SqlCommand mcmmSelectOrder;
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    private void cmdFillLists_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Open connection
    //   - Execute Select Employee (drdEmployee)
    //   - Clear Dataset
    //   - While there are datarows
    //     - Create new datarow
    //     - Fill 3 columns
    //     - Add Datarow to Dataset
    //   - Close connection
    //   - Open connection
    //   - Execute Select Customer (drdCustomer)
    //   - Clear Dataset
    //   - While there are datarows
    //     - Create new datarow
    //     - Fill 2 columns
    //     - Add Datarow to Dataset
    //   - Close connection
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      System.Data.SqlClient.SqlDataReader drdCustomer;
      System.Data.SqlClient.SqlDataReader drdEmployee;
      System.Data.DataRow theDataRow;

      this.cnncpNorthwindScript.Open();
      drdEmployee = this.cmmSelectEmployee.ExecuteReader();
      dsData.Clear();

      while (drdEmployee.Read())
      {
        theDataRow = this.dsData.EmployeeList.NewRow();
        theDataRow[0] = drdEmployee.GetInt32(0);
        theDataRow[1] = drdEmployee.GetString(1);
        theDataRow[2] = drdEmployee.GetString(2);
        this.dsData.EmployeeList.Rows.Add(theDataRow);
      }
      // (drdEmployee.Read())

      drdEmployee.Close();
      this.cnncpNorthwindScript.Close();

      this.cnncpNorthwindScript.Open();
      drdCustomer = this.mcmmSelectCustomer.ExecuteReader();

      while (drdCustomer.Read())
      {
        theDataRow = this.dsData.CustomerList.NewRow();
        theDataRow[0] = drdCustomer.GetString(0);
        theDataRow[1] = drdCustomer.GetString(1);
        this.dsData.CustomerList.Rows.Add(theDataRow);
      }
      // (drdCustomer.Read())

      drdCustomer.Close();
      this.cnncpNorthwindScript.Close();
    }
    // cmdFillLists_Click(System.Object, System.EventArgs)

    private void cmdGetOrders_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Clear dsData.OrderTotals
    //   - Open connection
    //   - Define 2 parameters for mcmmSelectOrder
    //   - Define connection for mcmmSelectOrder
    //   - Define SQLSTatement for mcmmSelectOrder
    //   - Execute Select Orders (drdOrder)
    //   - While there are datarows
    //     - Create new datarow
    //     - Fill 5 columns
    //     - Add Datarow to Dataset
    //   - Close connection
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      System.Data.SqlClient.SqlDataReader drdOrder;
      System.Data.DataRowView drvCustomer;
      System.Data.DataRowView drvEmployee;
      System.Data.DataRow theDataRow;

      this.dsData.OrderTotals.Clear();

      drvEmployee = (System.Data.DataRowView)this.lstEmployee.SelectedItem;
      this.mcmmSelectOrder.Parameters["@KeyEmployee"].Value = drvEmployee["intIdEmployee"];
      drvCustomer = (System.Data.DataRowView)this.lstClient.SelectedItem;
      this.mcmmSelectOrder.Parameters["@KeyCustomer"].Value = drvCustomer["strIdCustomer"];

      this.mcmmSelectOrder.Connection = this.cnncpNorthwindScript;
      this.mcmmSelectOrder.CommandText = "SELECT * FROM tblCPOrder ";
      this.mcmmSelectOrder.CommandText += "WHERE (strCustomerId = @KeyCustomer) AND (intEmployeeId = @KeyEmployee)";

      this.cnncpNorthwindScript.Open();
      drdOrder = this.mcmmSelectOrder.ExecuteReader();

      while (drdOrder.Read())
      {
        theDataRow = this.dsData.OrderTotals.NewRow();
        theDataRow["intEmployeeId"] = drdOrder.GetInt32(2);
        theDataRow["strCustomerId"] = drdOrder.GetString(1);
        theDataRow["intOrderId"] = drdOrder.GetInt32(0);
        theDataRow["dtmOrderDate"] = drdOrder.GetDateTime(3);
        theDataRow["dblFreight"] = drdOrder.GetDecimal(7);
        this.dsData.OrderTotals.Rows.Add(theDataRow);
      }
      // Not (drdOrder.Read())

      drdOrder.Close();
      this.cnncpNorthwindScript.Close();
    }
    // cmdGetOrders_Click(System.Object, System.EventArgs)

    private void cmdOrderCount_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Open connection
    //   - Define 2 parameters for mcmmSelectOrder
    //   - Execute Count Orders (lngCounter)
    //   - Close connection
    //   - Show message
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      System.Data.DataRowView drvCustomer;
      System.Data.DataRowView drvEmployee;
      int lngCounter;
      string strMessage;

      drvEmployee = (System.Data.DataRowView)this.lstEmployee.SelectedItem;
      this.cmmCountOrder.Parameters["@KeyEmployee"].Value = drvEmployee["intIdEmployee"];
      drvCustomer = (System.Data.DataRowView)this.lstClient.SelectedItem;
      this.cmmCountOrder.Parameters["@KeyCustomer"].Value = drvCustomer["strIdCustomer"];

      this.cnncpNorthwindScript.Open();
      lngCounter = (int)this.cmmCountOrder.ExecuteScalar();
      this.cnncpNorthwindScript.Close();

      strMessage = "There are " + lngCounter.ToString() + " Orders for this ";
      strMessage += "Employee/Customer combination.";
      MessageBox.Show(strMessage);
    }
    // cmdOrderCount_Click(System.Object, System.EventArgs)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataCommands
}
// DataCommands