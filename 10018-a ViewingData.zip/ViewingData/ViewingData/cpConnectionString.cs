﻿//***
// Action
//   - Working with a fixed connectionstring
// Created
//   - CopyPaste – 20251205 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251205 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpConnectionString
  {

    #region "Constructors / Destructors"

    public cpConnectionString()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - frmDataReader.cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click
      //   - frmDataTable.cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click
      //   - frmLocateRecord.frmLocateRecord_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmFilterRecord.frmFilterRecord_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251205 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251205 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpConnectionString()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string BuildConnectionString()
      //***
      // Action
      //   - Returning a hardcoded connectionstring
      // Called by
      //   - frmDataReader.cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click
      //   - frmDataTable.cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click
      //   - frmLocateRecord.frmLocateRecord_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmFilterRecord.frmFilterRecord_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251205 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251205 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {     
      return "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integrated Security=True";
    }
    // BuildConnectionString()
		
		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpConnectionString

}
// CopyPaste.Learning