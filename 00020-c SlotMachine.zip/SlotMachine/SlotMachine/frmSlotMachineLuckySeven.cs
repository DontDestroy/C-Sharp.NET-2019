//***
// Action
//   - A simulation of a slotmachine
//   - When there is a seven you win
// Created
//   - CopyPaste � 20240409 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240409 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSlotMachineLuckySeven: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.PictureBox picWon;
    internal System.Windows.Forms.Label lblTitle;
    internal System.Windows.Forms.Label lblNumber3;
    internal System.Windows.Forms.Label lblNumber2;
    internal System.Windows.Forms.Label lblNumber1;
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.Button cmdNewAttempt;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSlotMachineLuckySeven));
      this.picWon = new System.Windows.Forms.PictureBox();
      this.lblTitle = new System.Windows.Forms.Label();
      this.lblNumber3 = new System.Windows.Forms.Label();
      this.lblNumber2 = new System.Windows.Forms.Label();
      this.lblNumber1 = new System.Windows.Forms.Label();
      this.cmdExit = new System.Windows.Forms.Button();
      this.cmdNewAttempt = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // picWon
      // 
      this.picWon.Image = ((System.Drawing.Image)(resources.GetObject("picWon.Image")));
      this.picWon.Location = new System.Drawing.Point(208, 110);
      this.picWon.Name = "picWon";
      this.picWon.Size = new System.Drawing.Size(160, 152);
      this.picWon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picWon.TabIndex = 13;
      this.picWon.TabStop = false;
      this.picWon.Visible = false;
      // 
      // lblTitle
      // 
      this.lblTitle.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblTitle.ForeColor = System.Drawing.Color.Purple;
      this.lblTitle.Location = new System.Drawing.Point(24, 110);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(176, 72);
      this.lblTitle.TabIndex = 11;
      this.lblTitle.Text = "Lucky Seven";
      // 
      // lblNumber3
      // 
      this.lblNumber3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblNumber3.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblNumber3.Location = new System.Drawing.Point(304, 22);
      this.lblNumber3.Name = "lblNumber3";
      this.lblNumber3.Size = new System.Drawing.Size(64, 64);
      this.lblNumber3.TabIndex = 10;
      this.lblNumber3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblNumber2
      // 
      this.lblNumber2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblNumber2.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblNumber2.Location = new System.Drawing.Point(216, 22);
      this.lblNumber2.Name = "lblNumber2";
      this.lblNumber2.Size = new System.Drawing.Size(64, 64);
      this.lblNumber2.TabIndex = 9;
      this.lblNumber2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblNumber1
      // 
      this.lblNumber1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblNumber1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblNumber1.Location = new System.Drawing.Point(128, 22);
      this.lblNumber1.Name = "lblNumber1";
      this.lblNumber1.Size = new System.Drawing.Size(64, 64);
      this.lblNumber1.TabIndex = 8;
      this.lblNumber1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cmdExit
      // 
      this.cmdExit.Location = new System.Drawing.Point(24, 222);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.Size = new System.Drawing.Size(72, 40);
      this.cmdExit.TabIndex = 12;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // cmdNewAttempt
      // 
      this.cmdNewAttempt.Location = new System.Drawing.Point(24, 22);
      this.cmdNewAttempt.Name = "cmdNewAttempt";
      this.cmdNewAttempt.Size = new System.Drawing.Size(72, 40);
      this.cmdNewAttempt.TabIndex = 7;
      this.cmdNewAttempt.Text = "&New Attempt";
      this.cmdNewAttempt.Click += new System.EventHandler(this.cmdNewAttempt_Click);
      // 
      // frmSlotMachineLuckySeven
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(400, 285);
      this.Controls.Add(this.picWon);
      this.Controls.Add(this.lblTitle);
      this.Controls.Add(this.lblNumber3);
      this.Controls.Add(this.lblNumber2);
      this.Controls.Add(this.lblNumber1);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.cmdNewAttempt);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSlotMachineLuckySeven";
      this.Text = "Lucky Seven Slot Machine";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSlotMachineLuckySeven'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSlotMachineLuckySeven()
      //***
      // Action
      //   - Create instance of 'frmSlotMachineLuckySeven'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSlotMachineLuckySeven()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Application stops
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit.Click

    private void cmdNewAttempt_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Generate 3 random numbers
      //   - Visualize them
      //   - If one of them is 7
      //     - You win
      //   - If not
      //     - You don't win
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Random nrndRandom = new Random(DateTime.Now.Millisecond);

      picWon.Visible = false;
      lblTitle.Text = "Lucky Seven";

      lblNumber1.Text = nrndRandom.Next(10).ToString();
      lblNumber2.Text = nrndRandom.Next(10).ToString();
      lblNumber3.Text = nrndRandom.Next(10).ToString();

      if ((lblNumber1.Text == "7") || (lblNumber2.Text == "7") || (lblNumber3.Text == "7"))
      {
        picWon.Visible = true;
        lblTitle.Text = "You have won !!!";
      }
      else
        // (lblNumber1.Text <> "7") AndAlso (lblNumber2.Text <> "7") AndAlso (lblNumber3.Text <> "7")
      {
      }
      // (lblNumber1.Text = "7") OrElse (lblNumber2.Text = "7") OrElse (lblNumber3.Text = "7")
    
    }
    // cmdNewAttempt_Click(System.Object, System.EventArgs) Handles cmdNewAttempt.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSlotMachineLuckySeven
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSlotMachineLuckySeven()
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSlotMachineLuckySeven());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSlotMachineLuckySeven

}
// CopyPaste.Learning