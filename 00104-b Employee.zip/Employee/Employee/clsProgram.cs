//***
// Action
//   - Testroutines for cpBoss, cpCommissionWorker, cpEmployee, cpHourlyWorker and cpPieceWorker
// Created
//   - CopyPaste � 20230817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230817 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Company;
using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{
  
  public class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static string GetString(cpEmployee thecpWorker)
      //***
      // Action
      //   - Return information about a cpEmployee
      //   - The ToString information together with the earnings
      // Called by
      //   - Main()
      // Calls
      //   - decimal cpEmployee.Earnings()
      //   - string cpEmployee.ToString()
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return thecpWorker.ToString() + " earned " + thecpWorker.Earnings().ToString("� #,##0");
    }
    // string GetString(cpEmployee)

    static void Main()
      //***
      // Action
      //   - Return information about a cpEmployee
      //   - The ToString information together with the earnings for every inheritance of a cpEmployee
      //     - cpBoss
      //     - cpCommissionWorker
      //     - cpPieceWorker
      //     - cpHourlyWorker
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpBoss(string, string, decimal)
      //   - cpCommissionWorker(string, string, decimal, decimal, int)
      //   - cpHourlyWorker(string, string, decimal, double)
      //   - cpPieceWorker(string, string, decimal, int)
      //   - string GetString(cpEmployee)
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strOutput;
      cpEmployee thecpEmployee;

      cpBoss thecpBoss = new cpBoss("John", "Smith", 1800);
      cpCommissionWorker thecpCommissionWorker = new cpCommissionWorker("Sue", "Jones", 1200, 3, 150);
      cpPieceWorker thecpPieceWorker = new cpPieceWorker("Bob", "Lewis", Convert.ToDecimal(3.5), 200);
      cpHourlyWorker thecpHourlyWorker = new cpHourlyWorker("Karen", "Price", Convert.ToDecimal(17.75), 40);

      thecpEmployee = thecpBoss;
      strOutput = GetString(thecpBoss);
      MessageBox.Show(strOutput, "Demonstrating Polymorphism", MessageBoxButtons.OK, MessageBoxIcon.Information);
      strOutput = GetString(thecpEmployee);
      MessageBox.Show(strOutput, "Demonstrating Polymorphism", MessageBoxButtons.OK, MessageBoxIcon.Information);

      thecpEmployee = thecpCommissionWorker;
      strOutput = GetString(thecpCommissionWorker);
      MessageBox.Show(strOutput, "Demonstrating Polymorphism", MessageBoxButtons.OK, MessageBoxIcon.Information);
      strOutput = GetString(thecpEmployee);
      MessageBox.Show(strOutput, "Demonstrating Polymorphism", MessageBoxButtons.OK, MessageBoxIcon.Information);

      thecpEmployee = thecpHourlyWorker;
      strOutput = GetString(thecpHourlyWorker);
      MessageBox.Show(strOutput, "Demonstrating Polymorphism", MessageBoxButtons.OK, MessageBoxIcon.Information);
      strOutput = GetString(thecpEmployee);
      MessageBox.Show(strOutput, "Demonstrating Polymorphism", MessageBoxButtons.OK, MessageBoxIcon.Information);

      thecpEmployee = thecpPieceWorker;
      strOutput = GetString(thecpPieceWorker);
      MessageBox.Show(strOutput, "Demonstrating Polymorphism", MessageBoxButtons.OK, MessageBoxIcon.Information);
      strOutput = GetString(thecpEmployee);
      MessageBox.Show(strOutput, "Demonstrating Polymorphism", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram
  
}
// CopyPaste.Learning