﻿//***
// Action
//   - StartupViewModel class (in ViewModels)
// Created
//   - CopyPaste – 20220824 – VVDW
// Changed
//   - CopyPaste – 20220907  – VVDW – Added Constructor, Fields and Properties
// Tested
//   - CopyPaste – 20220824 – VVDW
// Proposal (To Do)
//   -
//***

using ProductCategory_WPF_MVVM.Models;
using ProductCategory_WPF_MVVM.Services;
using ProductCategory_WPF_MVVM.Utilities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace ProductCategory_WPF_MVVM.ViewModels
{

  public class ProductCategoryViewModel : ObservableObject
  {

    #region "Constructors / Destructors"

    public ProductCategoryViewModel(IDataService theDataService)
    //***
    // Action
    //   - Define the DataService that will be used
    //   - Fill the Product Category Collection with all the Product Categories
    // Called by
    //   - 
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      _dataService = theDataService;
      ProductCategoryCollection = new ObservableCollection<ProductCategory>(_dataService.AllProductCategories());
    }
    // ProductCategoryViewModel(IDataService)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private IDataService _dataService;
    private ObservableCollection<ProductCategory> _colProductCategory;
    private ProductCategory _selectedProductCategory;

    #endregion

    #region "Properties"

    public ObservableCollection<ProductCategory> ProductCategoryCollection
    {

      get
      //***
      // Action Get
      //   - Return _colProductCategory
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220907 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220907 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _colProductCategory;
      }
      // ObservableCollection<ProductCategory> ProductCategoryCollection (Get)

      set
      //***
      // Action Set
      //   - Sets _colProductCategory with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - 
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220907 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220907 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        OnPropertyChanged(ref _colProductCategory, value);
      }
      // ProductCategoryCollection(ObservableCollection<ProductCategory>) (Set)

    }
    // ObservableCollection<ProductCategory> ProductCategoryCollection

    public ProductCategory SelectedProductCategory
    {

      get
      //***
      // Action Get
      //   - Return _selectedProductCategory
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220907 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220907 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _selectedProductCategory;
      }
      // ProductCategory SelectedProductCategory (Get)

      set
      //***
      // Action Set
      //   - Sets _selectedProductCategory with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - 
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220907 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220907 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        OnPropertyChanged(ref _selectedProductCategory, value);
      }
      // SelectedProductCategory(ProductCategory) (Set)

    }
    // ProductCategory SelectedProductCategory

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // ProductCategoryViewModel

}
// ProductCategory_WPF_MVVM.ViewModels