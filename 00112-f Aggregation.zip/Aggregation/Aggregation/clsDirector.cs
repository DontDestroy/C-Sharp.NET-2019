//***
// Action
//   - Implementation of a cpManager
//   - Inherits from cpOfficeWorker
// Created
//   - CopyPaste � 20240409 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240409 � VVDW
// Proposal (To Do)
//   - There is an exercise where you can change the inheritance
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpDirector : cpOfficeWorker
    // : cpManager
  {

    #region "Constructors / Destructors"

    public cpDirector(string strName) : base(strName)
      //***
      // Action
      //   - Constructor with Name
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpOfficeWorker(string)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpDirector(string)

    public cpDirector(string strName, cpDepartment thecpDepartment) : base(strName, thecpDepartment)
      //***
      // Action
      //   - Constructor with Name and Department
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpOfficeWorker(string, cpDepartment)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpDirector(string, cpDepartment)
 
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override void ShowInfo()
      //***
      // Action
      //   - Shows information to the console
      //     - Director + Name
      //     - Departmenet
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpDepartment cpEmployee.Department (Get)
      //   - cpEmployee.Department.ShowInfo() (Get)
      //   - string cpEmployee.Name (Get)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Director - Name: {0}", Name);

      if (Department == null) 
      {
      }
      else
        // Department <> null
      {
        Department.ShowInfo();
      }
      // Department = null

    }
    // ShowInfo()

    public override string ToString()
      //***
      // Action
      //   - Returns the Name (Department) and that the person is a director
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee.cpDepartment Department (Get)
      //   - string cpDepartment.Name (Get)
      //   - string cpEmployee.Name (Get)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Name + "(" + Department.Name + ") is a director.";
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDirector

}
// CopyPaste.Learning.Employee