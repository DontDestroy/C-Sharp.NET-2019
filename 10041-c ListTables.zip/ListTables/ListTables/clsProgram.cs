//***
// Action
//   - Loop thru tables and loop thru the fields of that tables
// Created
//   - CopyPaste � 20251125 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251125 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Try to
      //     - Define a counter
      //     - Define a connection string
      //     - Create a connection
      //     - Open the connection
      //     - Show some information about the connection
      //     - Define a command string to find the tables
      //     - Define a data adapter
      //     - Define a data set
      //     - Fill the data set
      //     - Loop thru the tables
      //       - Show the table name
      //       - Define a command string to find the fields
      //       - Define a data adapter
      //       - Define a data set
      //       - Loop thru the fields
      //         - Show the field name
      //   - When an error occurs
      //     - Show information about that error
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251125 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251125 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        string strConnection = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integrated Security=True";
        SqlConnection theConnection = new SqlConnection(strConnection);

        theConnection.Open();
        Console.WriteLine("Database: " + theConnection.Database);
        Console.WriteLine("Server Version: " + theConnection.ServerVersion);
        Console.WriteLine("Data Source: " + theConnection.DataSource);
        
        string theCommand = "SELECT table_name From Information_Schema.Tables";
        SqlDataAdapter theDataAdapter = new SqlDataAdapter(theCommand, theConnection);
        DataSet theDataset = new DataSet();
        
        theDataAdapter.Fill(theDataset);
        
        for (int lngCounter = 0; lngCounter < theDataset.Tables[0].Rows.Count; lngCounter++)
        {
          string strTableName;

          Console.WriteLine();
          strTableName = theDataset.Tables[0].Rows[lngCounter][0].ToString();
          Console.WriteLine(strTableName);
          
          string strSQLCommand = "SELECT * From " + strTableName;
          SqlDataAdapter dtaTableList = new SqlDataAdapter(strSQLCommand, theConnection);
          DataSet dsTableList = new DataSet();
          
          dtaTableList.Fill(dsTableList);
          
          for (int lngCounter2 = 0; lngCounter2 < dsTableList.Tables[0].Columns.Count; lngCounter2++)
          {
            Console.WriteLine("   " + dsTableList.Tables[0].Columns[lngCounter2].ToString());
          }
          // lngCounter2 = theDataset.Tables[0].Columns.Count
          
        }
        // lngCounter = theDataset.Tables[0].Rows.Count

      }
      catch (Exception theException)
      {
        Console.WriteLine("Exception: " + theException.Message);
        Console.WriteLine(theException.ToString());
      }
      finally
      {
        Console.ReadLine();
      }
      
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning