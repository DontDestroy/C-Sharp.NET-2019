﻿//***
// Action
//   - Interface for the behaviour (method) Fly
// Created
//   - CopyPaste – 20240726 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240726 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Game.Animal.Library
{

	public interface cpiFly
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing can move in the air
		/// </summary>
		public void Fly();
		// Fly()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpiFly

}
// CopyPaste.Game.Animal.Library