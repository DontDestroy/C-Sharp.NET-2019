//***
// Action
//   - Implementation of a cpHandWorker
//   - Inherits from cpEmployee
// Created
//   - CopyPaste � 20240405 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240405 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpHandWorker : cpEmployee
  {

    #region "Constructors / Destructors"

    public cpHandWorker(string strName) : base(strName)
      //***
      // Action
      //   - Constructor with Name
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee(string)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpHandWorker(string)
 
    public cpHandWorker(string strName, string strDepartment) : base(strName, strDepartment)
      //***
      // Action
      //   - Constructor with Name and Department
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee(string, string)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpHandWorker(string, string)
 
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override void ShowInfo()
      //***
      // Action
      //   - Shows information to the console
      //     - Handworker + Name
      //     - Department
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - string cpEmployee.Department (Get)
      //   - string cpEmployee.Name (Get)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Handworker - Name: {0}", Name);
      Console.WriteLine("Department: {0}", Department);
    }
    // ShowInfo()

    public override string ToString()
      //***
      // Action
      //   - Returns the Name (Department) and that the person is a handworker
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - string cpEmployee.Department(Get)
      //   - string cpEmployee.Name (Get)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Name + "(" + Department + ") is a handworker.";
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpHandWorker

}
// CopyPaste.Learning.Employee