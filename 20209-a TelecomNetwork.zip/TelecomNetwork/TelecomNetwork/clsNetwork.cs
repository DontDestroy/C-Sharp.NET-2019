﻿//***
// Action
//   - The definition of a network
// Created
//   - CopyPaste – 20230614 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230614 – VVDW
// Proposal (To Do)
//   -
//***

using System.Collections.Generic;
using System.Linq;

namespace CopyPaste.TelecomNetwork
{

  public class cpNetwork<T> where T : cpPhone
  {

    #region "Constructors / Destructors"

    public cpNetwork()
    //***
    // Action
    //   - cpNetwork constructor
    //   - Create a list of cpPhones
    // Called by
    //   - frmNetwork()
    // Calls
    //   - cpPhones(List<T>) (Set)
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      cpPhones = new List<T>();
    }
    // cpNetwork()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public List<T> cpPhones { get; set; }

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Add(T aPhone)
    //***
    // Action
    //   - Add a cpPhone (or inherited class) to the cpNetwork
    // Called by
    //   - frmNetwork_Load(System.Object, System.EventArgs) Handles frmNetwork.Load
    // Calls
    //   - List<T> cpPhones (Get)
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      cpPhones.Add(aPhone);
    }
    // Add(T) (T : cpPhone)

    public void CallPhone(string strPhoneNumber)
    //***
    // Action
    //   - Find the phone to call to (must be open and in the list)
    //   - That cpPhone is being called
    // Called by
    //   - frmPhone.cmdCall_Click(System.Object, System.EventArgs) Handles cmdCall.Click
    // Calls
    //   - bool cpPhone.IsOpen (Get)
    //   - cpPhone.Called()
    //   - List<T> cpPhones (Get)
    //   - string cpPhone.PhoneNumber (Get)
    // Created
    //   - CopyPaste – 20230615 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230615 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***

    {
      cpPhone thePhoneToCallTo = cpPhones.Where(aPhone => (aPhone.PhoneNumber == strPhoneNumber && aPhone.IsOpen)).FirstOrDefault();

      if (thePhoneToCallTo == null)
      {
      }
      else
      // thePhoneToCallTo <> null
      {
        thePhoneToCallTo.Called();
      }
      // thePhoneToCallTo = null

    }
    // CallPhone(string)

    public void MessagePhone(string strPhoneNumber, string strPhoneFrom, string strMessage)
    //***
    // Action
    //   - Find the phone to message to (must be open and in the list)
    //   - That cpPhone is being messaged
    // Called by
    //   - frmNetwork.cmdSend_Click(System.Object, System.EventArgs) Handles cmdSend.Click
    // Calls
    //   - bool cpPhone.IsOpen (Get)
    //   - cpPhone.Messaged(string, string)
    //   - List<T> cpPhones (Get)
    //   - string cpPhone.PhoneNumber (Get)
    // Created
    //   - CopyPaste – 20230615 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230615 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***

    {
      cpPhone thePhoneToMessageTo = cpPhones.Where(aPhone => (aPhone.PhoneNumber == strPhoneNumber && aPhone.IsOpen)).FirstOrDefault();

      if (thePhoneToMessageTo == null)
      {
      }
      else
      // thePhoneToMessageTo  <> null
      {
        thePhoneToMessageTo.Messaged(strPhoneFrom, strMessage);
      }
      // thePhoneToMessageTo  = null

    }
    // MessagePhone(string, string, string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpNetwork

}
// CopyPaste.TelecomNetwork