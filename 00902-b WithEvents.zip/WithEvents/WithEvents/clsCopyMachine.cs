﻿//***
// Action
//   - Definition of a cpCopyMachine
//     - Has a cost and an number of pages
//     - Has also a number of runs (a set of pages that are printed)
//     - A maintenance can happen on the machine (Delegate)
//       - here is an event "NeedsMaintenance" that is triggered after every 100000 printed pages
// Created
//   - CopyPaste – 20250716 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250716 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  namespace Material
  {

    public class cpCopyMachine
    {

      #region "Constructors / Destructors"

      public cpCopyMachine()
        //***
        // Action
        //   - Empty constructor
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20250716 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250716 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // cpCopyMachine()

      public cpCopyMachine(decimal decCost, int lngNumberOfPages)
        //***
        // Action
        //   - Constructor with a given cost and number of pages
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - Cost(decimal) (Set)
        //   - NumberOfPages(int) (Set)
        // Created
        //   - CopyPaste – 20250716 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250716 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        Cost = decCost;
        NumberOfPages = lngNumberOfPages;
      }
      // cpCopyMachine(decimal, int)

      #endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      #region "Fields"

      private decimal mdecCost;
      private int mlngNumberOfPages;
      private int mlngRuns;
      public event Maintenance NeedsMaintenance;

      #endregion

      #region "Properties"

      public decimal Cost
      {

        get
          //***
          // Action Get
          //   - Returns mdecCost
          // Called by
          //   - cpEmployee.DoMaintenance(cpCopyMachine)
          // Calls
          //   - 
          // Created
          //   - CopyPaste – 20250716 – VVDW
          // Changed
          //   - CopyPaste – yyyymmdd – VVDW – What changed
          // Tested
          //   - CopyPaste – 20250716 – VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {
          return mdecCost;
        }
        // decimal Cost (Get)

        set
          //***
          // Action Set
          //   - mdecCost becomes value
          // Called by
          //   - cpCopyMachine(decimal, int)
          // Calls
          //   - 
          // Created
          //   - CopyPaste – 20250716 – VVDW
          // Changed
          //   - CopyPaste – yyyymmdd – VVDW – What changed
          // Tested
          //   - CopyPaste – 20250716 – VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {
          mdecCost = value;
        }
        // Cost(decimal) (Set)

      }
      // decimal Cost

      public int NumberOfPages
      {

        get
          //***
          // Action Get
          //   - Returns mlngNumberOfPages
          // Called by
          //   - cpEmployee.DoMaintenance(cpCopyMachine)
          //   - NumberOfPages(int) (Set)
          // Calls
          //   - 
          // Created
          //   - CopyPaste – 20250716 – VVDW
          // Changed
          //   - CopyPaste – yyyymmdd – VVDW – What changed
          // Tested
          //   - CopyPaste – 20250716 – VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {
          return mlngNumberOfPages;
        }
        // int NumberOfPages (Get)

        set
          //***
          // Action Set
          //   - If value is 0 or larger
          //     - Increment mlngRuns with 1
          //     - mlngNumberOfPages is incremented with value
          //     - If number of pages is larger than 100000
          //       - A event NeedsMaintenance with the given copy machine is triggered
          //       - mlngNumberOfPages becomes 0
          //     - If not
          //       - Do nothing
          //   - If not
          //     - Do nothing
          // Called by
          //   - cpProgram.Main() (thru delegate)
          //   - cpCopyMachine(decimal, int)
          // Calls
          //   - int NumberOfPages (Get)
          //   - NeedsMaintenance(cpCopyMachine)
          // Created
          //   - CopyPaste – 20250716 – VVDW
          // Changed
          //   - CopyPaste – yyyymmdd – VVDW – What changed
          // Tested
          //   - CopyPaste – 20250716 – VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {

          if (value >= 0)
          {
            mlngRuns += 1;
            mlngNumberOfPages += value;

            if (NumberOfPages >= 100000)
            {
              NeedsMaintenance(this);
              mlngNumberOfPages = 0;
            }
            else
              // NumberOfPages < 100000
            {
            }
            // NumberOfPages >= 100000

          }
          else
            // value < 0
          {
          }
          // value >= 0

        }
        // NumberOfPages(int) (Set)

      }
      // int NumberOfPages

      public int NumberOfRuns
      {

        get
          //***
          // Action Get
          //   - Returns mlngRuns
          // Called by
          //   - cpEmployee.DoMaintenance(cpCopyMachine)
          // Calls
          //   - 
          // Created
          //   - CopyPaste – 20250716 – VVDW
          // Changed
          //   - CopyPaste – yyyymmdd – VVDW – What changed
          // Tested
          //   - CopyPaste – 20250716 – VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {
          return mlngRuns;
        }
        // int NumberOfRuns (Get)

      }
      // int NumberOfRuns

      #endregion

      #region "Methods"

      //#region "Overrides"
      //#endregion

      //#region "Controls"
      //#endregion

      #region "Functionality"

      #region "Event"

      public delegate void Maintenance(cpCopyMachine cpErrorMachine);

      #endregion

      //#region "Sub / Function"
      //#endregion

      #endregion

      #endregion

      //#region "Not used"
      //#endregion

    }
    // cpCopyMachine

  }
  // Material

}
// CopyPaste.Learning