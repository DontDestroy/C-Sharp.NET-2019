//***
// Action
//   - Implementation of cpBook
// Created
//   - CopyPaste � 20240710 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240710 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpBook
  {

    #region "Constructors / Destructors"

    public cpBook()
      //***
      // Action
      //   - Default constructor
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpBook()

    public cpBook(string strTitle, string strAuthor, string strPublisher, double dblPrice)
      //***
      // Action
      //   - Basic constructor with a given Title, Author, Publisher and Price
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrTitle = strTitle;
      mstrAuthor = strAuthor;
      mstrPublisher = strPublisher;
      mdblPrice = dblPrice;
    }
    // cpBook(string, string, string, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public double mdblPrice;
    public string mstrAuthor;
    public string mstrPublisher;
    public string mstrTitle;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ShowAuthor()
      //***
      // Action
      //   - Show Author of the cpBook
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Author: " + mstrAuthor);
    }
    // ShowAuthor()

    public void ShowValues()
      //***
      // Action
      //   - Show values of the cpBook
      // Called by
      //   - cpProgram.LateBinding(System.Object)
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Title: " + mstrTitle);
      Console.WriteLine("Author: " + mstrAuthor);
      Console.WriteLine("Publisher: " + mstrPublisher);
      Console.WriteLine("Price: " + mdblPrice);
    }
    // ShowValues()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBook

}
// CopyPaste.Learning