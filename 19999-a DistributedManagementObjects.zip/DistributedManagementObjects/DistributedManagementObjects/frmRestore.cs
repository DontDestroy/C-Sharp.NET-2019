//***
// Action
//   - Form to select a SQL Server
//     - Load the different servers
//     - Load the databases from the selected server
//     - Select a backup device
//   - The goal is to restore the selections 
// Created
//   - CopyPaste � 20260717 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260717 � VVDW
// Proposal (To Do)
//   - 
//***

using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmRestore: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdClose;
    internal System.Windows.Forms.Label lblOptions;
    internal System.Windows.Forms.Label lblBackupDevice;
    internal System.Windows.Forms.ListBox lstBackupDevice;
    internal System.Windows.Forms.Button cmdRestore;
    internal System.Windows.Forms.Label lblDatabase;
    internal System.Windows.Forms.ListBox lstDatabase;
    internal System.Windows.Forms.Label lblSQLServer;
    internal System.Windows.Forms.ListBox lstSQLServer;
    internal System.Windows.Forms.Panel panOptions;
    internal System.Windows.Forms.CheckBox chkReplaceDatabase;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmRestore));
      this.cmdClose = new System.Windows.Forms.Button();
      this.lblOptions = new System.Windows.Forms.Label();
      this.lblBackupDevice = new System.Windows.Forms.Label();
      this.lstBackupDevice = new System.Windows.Forms.ListBox();
      this.cmdRestore = new System.Windows.Forms.Button();
      this.lblDatabase = new System.Windows.Forms.Label();
      this.lstDatabase = new System.Windows.Forms.ListBox();
      this.lblSQLServer = new System.Windows.Forms.Label();
      this.lstSQLServer = new System.Windows.Forms.ListBox();
      this.panOptions = new System.Windows.Forms.Panel();
      this.chkReplaceDatabase = new System.Windows.Forms.CheckBox();
      this.panOptions.SuspendLayout();
      this.SuspendLayout();
      // 
      // cmdClose
      // 
      this.cmdClose.Location = new System.Drawing.Point(368, 240);
      this.cmdClose.Name = "cmdClose";
      this.cmdClose.Size = new System.Drawing.Size(80, 32);
      this.cmdClose.TabIndex = 19;
      this.cmdClose.Text = "&Close";
      this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
      // 
      // lblOptions
      // 
      this.lblOptions.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblOptions.Location = new System.Drawing.Point(8, 128);
      this.lblOptions.Name = "lblOptions";
      this.lblOptions.Size = new System.Drawing.Size(48, 16);
      this.lblOptions.TabIndex = 17;
      this.lblOptions.Text = "Options";
      // 
      // lblBackupDevice
      // 
      this.lblBackupDevice.Location = new System.Drawing.Point(248, 24);
      this.lblBackupDevice.Name = "lblBackupDevice";
      this.lblBackupDevice.Size = new System.Drawing.Size(120, 16);
      this.lblBackupDevice.TabIndex = 14;
      this.lblBackupDevice.Text = "Backup Devices";
      // 
      // lstBackupDevice
      // 
      this.lstBackupDevice.Location = new System.Drawing.Point(248, 40);
      this.lstBackupDevice.Name = "lstBackupDevice";
      this.lstBackupDevice.Size = new System.Drawing.Size(112, 82);
      this.lstBackupDevice.TabIndex = 15;
      // 
      // cmdRestore
      // 
      this.cmdRestore.Location = new System.Drawing.Point(368, 40);
      this.cmdRestore.Name = "cmdRestore";
      this.cmdRestore.Size = new System.Drawing.Size(80, 32);
      this.cmdRestore.TabIndex = 16;
      this.cmdRestore.Text = "&Restore";
      this.cmdRestore.Click += new System.EventHandler(this.cmdRestore_Click);
      // 
      // lblDatabase
      // 
      this.lblDatabase.Location = new System.Drawing.Point(128, 24);
      this.lblDatabase.Name = "lblDatabase";
      this.lblDatabase.Size = new System.Drawing.Size(120, 16);
      this.lblDatabase.TabIndex = 12;
      this.lblDatabase.Text = "Database to Restore";
      // 
      // lstDatabase
      // 
      this.lstDatabase.Location = new System.Drawing.Point(128, 40);
      this.lstDatabase.Name = "lstDatabase";
      this.lstDatabase.Size = new System.Drawing.Size(104, 82);
      this.lstDatabase.TabIndex = 13;
      // 
      // lblSQLServer
      // 
      this.lblSQLServer.Location = new System.Drawing.Point(8, 24);
      this.lblSQLServer.Name = "lblSQLServer";
      this.lblSQLServer.Size = new System.Drawing.Size(104, 16);
      this.lblSQLServer.TabIndex = 10;
      this.lblSQLServer.Text = "SQL Servers";
      // 
      // lstSQLServer
      // 
      this.lstSQLServer.Location = new System.Drawing.Point(8, 40);
      this.lstSQLServer.Name = "lstSQLServer";
      this.lstSQLServer.Size = new System.Drawing.Size(104, 82);
      this.lstSQLServer.TabIndex = 11;
      this.lstSQLServer.SelectedIndexChanged += new System.EventHandler(this.lstSQLServer_SelectedIndexChanged);
      // 
      // panOptions
      // 
      this.panOptions.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panOptions.Controls.Add(this.chkReplaceDatabase);
      this.panOptions.Location = new System.Drawing.Point(8, 152);
      this.panOptions.Name = "panOptions";
      this.panOptions.Size = new System.Drawing.Size(440, 80);
      this.panOptions.TabIndex = 18;
      // 
      // chkReplaceDatabase
      // 
      this.chkReplaceDatabase.Checked = true;
      this.chkReplaceDatabase.CheckState = System.Windows.Forms.CheckState.Checked;
      this.chkReplaceDatabase.Location = new System.Drawing.Point(8, 8);
      this.chkReplaceDatabase.Name = "chkReplaceDatabase";
      this.chkReplaceDatabase.Size = new System.Drawing.Size(128, 24);
      this.chkReplaceDatabase.TabIndex = 0;
      this.chkReplaceDatabase.Text = "Replace Database?";
      // 
      // frmRestore
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(456, 277);
      this.Controls.Add(this.cmdClose);
      this.Controls.Add(this.lblOptions);
      this.Controls.Add(this.lblBackupDevice);
      this.Controls.Add(this.lstBackupDevice);
      this.Controls.Add(this.cmdRestore);
      this.Controls.Add(this.lblDatabase);
      this.Controls.Add(this.lstDatabase);
      this.Controls.Add(this.lblSQLServer);
      this.Controls.Add(this.lstSQLServer);
      this.Controls.Add(this.panOptions);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmRestore";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Restoring a SQL Server Database";
      this.Load += new System.EventHandler(this.frmRestore_Load);
      this.panOptions.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmRestore'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmRestore()
      //***
      // Action
      //   - Create instance of 'frmRestore'
      // Called by
      //   - 
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmRestore()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdClose_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Close the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // cmdClose_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdClose.Click

    private void cmdRestore_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Restore from a selected backup device
      //   - Define and initialize a new restore
      //   - Define and initialize a SQLServer
      //   - Try to
      //     - Connect to the SQL Server with Windows Security
      //     - Set action
      //     - Set database
      //     - Set device
      //     - Set replace database (or not)
      //     - Restore
      //     - Disconnect from the server
      //     - Show messagebox that restore is successful
      //   - On possible error
      //     - Show messageboxes with corresponding info 
      //   - Set the server to nothing
      //   - Set the restore to nothing
       // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpSQLDMORoutines.LoadSQLServer(�ListBox)
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Restore theRestore = new Restore();
      Server theSQLServer;

      try
      {
        theSQLServer = new Server(lstSQLServer.SelectedItem.ToString());
        theSQLServer.ConnectionContext.Connect();
      
        theRestore.Action = RestoreActionType.Database;
        theRestore.Database = lstDatabase.SelectedItem.ToString();
        theRestore.Devices.AddDevice(lstBackupDevice.SelectedItem.ToString() + ".bak", DeviceType.File);
        theRestore.ReplaceDatabase = chkReplaceDatabase.Checked;
        theRestore.SqlRestore(theSQLServer);
        theSQLServer.ConnectionContext.Disconnect();
        MessageBox.Show("Database Restored", "Task Completed", MessageBoxButtons.OK);
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
        MessageBox.Show("There is a problem retrieving databases for this server. " +
          "Please check the name and try again. ", "Error with Server", MessageBoxButtons.OK, MessageBoxIcon.Information);
      }
      finally
      {
        theSQLServer = null;
        theRestore = null;
      }
      
    }
    // cmdRestore_Click(System.Object, System.EventArgs) Handles cmdRestore.Click

    private void frmRestore_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Load the list of SQL Servers
      // Called by
      //   - User action (Starting a form)
      // Calls
      //   - cpSQLDMORoutines.LoadSQLServer(�ListBox)
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpSQLDMORoutines.LoadSQLServer(ref lstSQLServer);
    }
    // frmRestore_Load(System.Object, System.EventArgs) Handles MyBase.Load

    private void lstSQLServer_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Get SQL databases
      //   - Get the backup devices
      // Called by
      //   - User action (Choosing an option)
      // Calls
      //   - cpSQLDMORoutines.GetSQLDatabase(String, �ListBox)
      //   - cpSQLDMORoutines.GetBackupDevice(String, �ListBox)
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpSQLDMORoutines.GetSQLDatabase(lstSQLServer.SelectedItem.ToString(), ref lstDatabase);
      cpSQLDMORoutines.GetBackupDevice(lstSQLServer.SelectedItem.ToString(), ref lstBackupDevice);
    }
    // lstSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstSQLServer.SelectedIndexChanged

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmRestore

}
// CopyPaste.Learning