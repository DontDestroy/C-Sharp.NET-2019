//***
// Action
//   - Implementation of cpLibrary
//   - A cpBookCollection is used to simulate a library
// Created
//   - CopyPaste � 20240227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240227 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpLibrary
  {

    #region "Constructors / Destructors"

    public cpLibrary()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpLibrary()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public cpBookCollection mcpBookShelf = new cpBookCollection();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void CheckIn(cpBook thecpBook)
      //***
      // Action 
      //   - Add a cpBook to a cpBookCollection
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpBookCollection.Add(cpBook)
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mcpBookShelf.Add(thecpBook);
    }
    // CheckIn(cpBook)

    public cpBook CheckOut(string strTitle)
      //***
      // Action 
      //   - Find the book in a cpBookCollection
      //   - Remove it from the cpBookCollection
      //   - Return the book (It is going out from the collection to somewhere else)
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpBook cpBookCollection.this[string]
      //   - cpBookCollection.Remove(string)
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBook thecpBook = mcpBookShelf[strTitle];

      mcpBookShelf.Remove(strTitle);
      return thecpBook;
    }
    // cpBook CheckOut(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx