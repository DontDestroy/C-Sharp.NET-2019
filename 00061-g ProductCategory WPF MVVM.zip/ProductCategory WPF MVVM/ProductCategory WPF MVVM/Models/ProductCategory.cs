﻿//***
// Action
//   - ProductCategory class (in Models)
//   - Will be used to create a table in a SQL Server database
//   - None of the namings are according to the Copy Paste naming conventions
// Created
//   - CopyPaste – 20220824 – VVDW
// Changed
//   - CopyPaste – 20260407 – VVDW – Added some comments for connection to SQL Server Database
// Tested
//   - CopyPaste – 20220824 – VVDW
// Proposal (To Do)
//   -
//***

using ProductCategory_WPF_MVVM.Utilities;

namespace ProductCategory_WPF_MVVM.Models
{

  public class ProductCategory : ObservableObject
  {

    #region "Constructors / Destructors"

    public ProductCategory()
    //***
    // Action
    //   - Create an instance of 'ProductCategory'
    // Called by
    //   - ProductCategory(int, string)
    //   - ProductCategoryViewModel.AddProductCategory()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // ProductCategory()

    public ProductCategory(int intIdProductCategory, string strCategoryName) : this()
    //***
    // Action
    //   - Create an instance of 'ProductCategory'
    //     - Fill the property Key
    //     - Fill the property Name
    // Called by
    //   - MockDataService.FillProductCategory()
    //   - EntityFrameWorkDataService.FillProductCategory(cpApplicationDatabaseContext)
    // Calls
    //   - Name(string) (Set)
    //   - ProductCategory()
    //   - ProductCategoryId(int) (Set)
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      ProductCategoryId = intIdProductCategory;
      Name = strCategoryName;
    }
    // ProductCategory(int, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int _intIdProductCategory;
    private string _strCategoryName;

    #endregion

    #region "Properties"

    public string Name
    {

      get
      //***
      // Action Get
      //   - Return _strCategoryName
      // Called by
      //   - ctrlProductCategoryDetails
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _strCategoryName;
      }
      // string Name (Get)

      set
      //***
      // Action Set
      //   - Sets _strCategoryName with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - ProductCategory(int, string)
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        OnPropertyChanged(ref _strCategoryName, value);
      }
      // Name(string) (Set)

    }
    // string Name

    public int ProductCategoryId
    {

      get
      //***
      // Action Get
      //   - Return _intIdProductCategory
      // Called by
      //   - ctrlProductCategoryDetails
      //   - IList<ProductCategory> MockDataService.AddProductCategory(ProductCategory)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _intIdProductCategory;
      }
      // int ProductCategoryId (Get)

      set
      //***
      // Action Set
      //   - Sets _intIdProductCategory with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - IList<ProductCategory> MockDataService.AddProductCategory(ProductCategory)
      //   - ProductCategory(int, string)
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        OnPropertyChanged(ref _intIdProductCategory, value);
      }
      // ProductCategoryId(int) (Set)

    }
    // int ProductCategoryId

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // ProductCategory

}
// ProductCategory_WPF_MVVM.Models