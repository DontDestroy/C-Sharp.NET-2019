//***
// Action
//   - Show difference in precision
// Created
//   - CopyPaste � 20220128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220128 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace ShowPrecision
{

  class cpShowPrecision
	{

    static void Main()
    //***
    // Action
    //   - Initialize a double and single variable
    //   - Show values at console screen
    //   - Do same calculation on double and single variable
    //   - Show result at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      double dblNumber = 0.123456789012345;
      decimal decNumber = 0.123456789012345M;
      float fltNumber = 0.123456789012345F;

      Console.WriteLine("Decimal: " + decNumber);
      Console.WriteLine("Double:  " + dblNumber);
      Console.WriteLine("Float:   " + fltNumber);
      Console.WriteLine();
      Console.WriteLine("After using it in a calucation");
      Console.WriteLine();
      Console.WriteLine("Decimal: " + (double) decNumber * System.Math.Pow(10, 13));
      Console.WriteLine("Double:  " + dblNumber * System.Math.Pow(10, 13));
      Console.WriteLine("Float:  " + fltNumber * System.Math.Pow(10, 13));
      Console.ReadLine();
    }
    // Main()

	}
  // cpShowPrecision

}
// ShowPrecision