//***
// Action
//   - A block game
//   - Working with properties (Get and Set) and methods in a class, that can be used in another game
//   - Possible Solution 1
// Created
//   - CopyPaste � 20240214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240214 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning.Games
{

	public class cpBlock
  {

    #region "Constructors / Destructors"

    public cpBlock()
      //***
      // Action
      //   - Creating an instance of cpBlock with default values
      // Called by
      //   - frmBlock
      //   - frmBlock2
      // Calls
      //   - Lives(int) (Set)
      //   - Score(int) (Set)
      //   - SpeedX(int) (Set)
      //   - SpeedY(int) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Lives = 3;
      Score = 0;
      SpeedX = 2;
      SpeedY = -2;
    }
    // cpBlock()

    public cpBlock(int lngLives, int lngScore, int lngSpeedX, int lngSpeedY)
      //***
      // Action
      //   - Creating an instance of cpBlock with default values
      // Called by
      //   - frmBlock
      //   - frmBlock2
      // Calls
      //   - Lives(int) (Set)
      //   - Score(int) (Set)
      //   - SpeedX(int) (Set)
      //   - SpeedY(int) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Lives = lngLives;
      Score = lngScore;
      SpeedX = lngSpeedX;
      SpeedY = lngSpeedY;
    }
    // cpBlock(int, int, int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private bool mblnLostBall;
    private int mlngAllGone;
    private int mlngLives;
    private int mlngScore;
    private int mlngSpeedX;
    private int mlngSpeedY;

    #endregion

    #region "Properties"

    public int AllGone
    {

      get
        //***
        // Action Get
        //   - Return the number of boxes that are visible in the game (mlngAllGone)
        // Called by 
        //   - bool GameFinished()
        //   - frmBlock.CheckCollision(PictureBox, bool)
        //   - frmBlock2.CheckCollision(PictureBox, bool)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngAllGone;
      }
      // int AllGone (Get)

      set
        //***
        // Action Set
        //   - Sets the number of boxes that are visible in the game (mlngAllGone becomes value)
        // Called by
        //   - frmBlock.CheckCollision(PictureBox, bool)
        //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        //   - frmBlock2.CheckCollision(PictureBox, bool)
        //   - frmBlock2.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngAllGone = value;
      }
      // AllGone(int) (Set)

    }
    // int AllGone

    public bool GameFinished
    {
      
      get
        //***
        // Action Get
        //   - Check if the game is finished (True or False)
        //   - If AllGone equals 1
        //     - Show message that the game is finished
        //     - Return True
        //   - If Not
        //     - If LostBall
        //       - If Lives are less than 1
        //         - Show message that you lost the game
        //         - Return True
        //       - If Not
        //         - Show message that you have lost a live
        //         - Return False
        //     - If Not
        //       - Do Nothing
        // Called by
        //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        //   - frmBlock2.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - int AllGone (Get)
        //   - int Lives (Get)
        //   - int LostBall (Get)
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        bool blnResult = false;

        if (AllGone == 1)
        {
          MessageBox.Show("You finished the game!", "CONGRATULATIONS");
          blnResult = true;
        }
        else
          // AllGone <> 1
        {
          
          if (LostBall)
          {
            
            if (Lives < 1)
            {
              MessageBox.Show("You have lost the game.", "OH NO!");
              blnResult = true;
            }
            else
              // Lives >= 1
            {
              MessageBox.Show("You missed!", "OH NO");
              blnResult = false;
            }
            // Lives < 1

          }
          else
            // Not LostBall
          {
          }
          // LostBall
       
        }
        // AllGone = 1

        return blnResult;
      }
      // bool GameFinished (Get)

    }
    // bool GameFinished 

    public int Lives
    {

      get
        //***
        // Action Get
        //   - Return the number of lives you still have in the game (mlngLives)
        // Called by
        //   - bool GameFinished (Get)
        //   - frmBlock.frmBlock_Load(System.Object, System.EventArgs) Handles this.Load
        //   - frmBlock.UpdateLives()
        //   - frmBlock2.frmBlock2_Load(System.Object, System.EventArgs) Handles this.Load
        //   - frmBlock2.UpdateLives()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngLives;
      }
      // int Lives (Get)

      set
        //***
        // Action Set
        //   - Set the number of lives you still have in the game (mlngLives becomes value)
        // Called by
        //   - cpBlock()
        //   - cpBlock(int, int, int, int)
        //   - frmBlock.UpdateLives()
        //   - frmBlock2.UpdateLives()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngLives = value;
      }
      // Lives(int) (Set)

    }
    // int Lives

    public bool LostBall
    {

      get
        //***
        // Action Get
        //   - Return the lost ball status (mblnLostBall)
        // Called by
        //   - bool GameFinished (Get)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mblnLostBall;
      }
      // bool LostBall (Get)

      set
        //***
        // Action Set
        //   - Set the lost ball status (mblnLostBall becomes value)
        // Called by 
        //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        //   - frmBlock2.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mblnLostBall = value;
      }
      // LostBall(bool) (Set)

    }
    // bool LostBall

    public int Score
    {

      get
        //***
        // Action Get
        //   - Return the score of the game (mlngScore)
        // Called by
        //   - frmBlock.frmBlock_Load(System.Object, System.EventArgs) Handles this.Load
        //   - frmBlock.UpdateScore()
        //   - frmBlock2.frmBlock2_Load(System.Object, System.EventArgs) Handles this.Load
        //   - frmBlock2.UpdateScore()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngScore;
      }
      // int Score (Get)

      set
        //***
        // Action Set
        //   - Set the score of the game (mlngScore becomes value)
        // Called by
        //   - cpBlock()
        //   - cpBlock(int, int, int, int)
        //   - frmBlock.UpdateScore()
        //   - frmBlock2.UpdateScore()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngScore = value;
      }
      // Score(int) (Set)

    }
    // int Score

    public int SpeedX
    {

      get
        //***
        // Action Get
        //   - Return the speed of the ball horizontally (mlngSpeedX)
        // Called by
        //   - cpBlock(int, int, int, int)
        //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        //   - frmBlock2.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngSpeedX;
      }
      // int SpeedX (Get)

      set
        //***
        // Action Set
        //   - Set the speed of the ball horizontally (mlngSpeedX becomes value)
        // Called by
        //   - cpBlock()
        //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        //   - frmBlock2.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngSpeedX = value;
      }
      // SpeedX(int) (Set)

    }
    // int SpeedX

    public int SpeedY
    {

      get
        //***
        // Action Get
        //   - Return the speed of the ball vertically (mlngSpeedY)
        // Called by 
        //   - cpBlock(int, int, int, int)
        //   - frmBlock.CheckCollision(PictureBox, bool)
        //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        //   - frmBlock2.CheckCollision(PictureBox, bool)
        //   - frmBlock2.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngSpeedY;
      }
      // int SpeedY (Get)

      set
        //***
        // Action Set
        //   - Set the speed of the ball vertically (mlngSpeedY becomes value)
        // Called by
        //   - cpBlock()
        //   - frmBlock.CheckCollision(PictureBox, bool)
        //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        //   - frmBlock2.CheckCollision(PictureBox, bool)
        //   - frmBlock2.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngSpeedY = value;
      }
      // SpeedY(int) (Get)

    }
    // int SpeedY (Get)

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

	}
  // cpBlock

}
// CopyPaste.Learning.Games