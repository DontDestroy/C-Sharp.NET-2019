//***
// Action
//   - 
// Created
//   - CopyPaste � 20240808 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240808 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Show the size of the heap
      //   - Fill 50000 bytes
      //   - Show the size of the heap
      //   - Fill 250000 bytes
      //   - Show the size of the heap
      //   - Loop 5 times
      //     - Remove 50000 bytes
      //     - Show the size of the heap no cleanup
      //     - Show the size of the heap cleanup
      //     - Remove 250000 bytes
      //     - Show the size of the heap no cleanup
      //     - Show the size of the heap cleanup
      //     - Fill 50000 bytes
      //     - Show the size of the heap
      //     - Fill 250000 bytes
      //     - Show the size of the heap
      //   - Remove 50000 bytes
      //   - Show the size of the heap no cleanup
      //   - Show the size of the heap cleanup
      //   - Remove 250000 bytes
      //   - Show the size of the heap no cleanup
      //   - Show the size of the heap cleanup
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Starting Heap Space: " + GC.GetTotalMemory(false) + " bytes");

      byte[] arrbytBig = new byte[50000];
      Console.WriteLine("Heap Space (Extra 50000 bytes): " + GC.GetTotalMemory(false) + " bytes");

      byte[] arrbytBigger = new byte[250000];
      Console.WriteLine("Heap Space (Extra 250000 bytes): " + GC.GetTotalMemory(false) + " bytes");

      for (int lngCounter = 0; lngCounter < 5; lngCounter++)
      {
        arrbytBig = null;
        Console.WriteLine("Heap Space (Minus 50000 bytes, no cleanup): " + GC.GetTotalMemory(false) + " bytes");
        Console.WriteLine("Heap Space (cleanup): " + GC.GetTotalMemory(true) + " bytes");
        
        arrbytBigger = null;
        Console.WriteLine("Heap Space (Minus 250000 bytes, no cleanup): " + GC.GetTotalMemory(false) + " bytes");
        Console.WriteLine("Heap Space (cleanup): " + GC.GetTotalMemory(true) + " bytes");
        
        arrbytBig = new byte[50000];
        Console.WriteLine("Heap Space (Extra 50000 bytes): " + GC.GetTotalMemory(false) + " bytes");
        arrbytBigger = new byte[250000];
        Console.WriteLine("Heap Space (Extra 250000 bytes): " + GC.GetTotalMemory(false) + " bytes");
      }
      // lngCounter = 5

      arrbytBig = null;
      Console.WriteLine("Heap Space (Minus 50000 bytes, no cleanup): " + GC.GetTotalMemory(false) + " bytes");
      Console.WriteLine("Heap Space (cleanup): " + GC.GetTotalMemory(true) + " bytes");
        
      arrbytBigger = null;
      Console.WriteLine("Heap Space (Minus 250000 bytes, no cleanup): " + GC.GetTotalMemory(false) + " bytes");
      Console.WriteLine("Heap Space (cleanup): " + GC.GetTotalMemory(true) + " bytes");

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning