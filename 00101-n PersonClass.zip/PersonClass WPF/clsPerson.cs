//***
// Action
//   - Define a cpPerson (FirstName, LastName)
//   - A constructor and some properties
// Created
//   - CopyPaste � 20230324 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230324 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Toolkit
{

  public class cpPerson
  {

    #region "Constructors / Destructors"

    public cpPerson()
    {
    }
    // cpPerson()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrFirstName;
    private string mstrLastName;

    #endregion

    #region "Properties"

    public string FirstName
    {

      get
      //***
      // Action Get
      //   - Return mstrFirstName
      // Called by
      //   - wpfEmployee.cmdDisplay_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdDisplay.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230324 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230324 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return mstrFirstName;
      }
      // string FirstName (Get)

      set
      //***
      // Action Set
      //   - Define mstrFirstName
      // Called by
      //   - wpfEmployee.cmdDisplay_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdDisplay.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230324 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230324 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        mstrFirstName = value;
      }
      // FirstName(string) (Set)

    }
    // string FirstName

    public string LastName
    {

      get
      //***
      // Action Get
      //   - Return mstrLastName
      // Called by
      //   - wpfEmployee.cmdDisplay_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdDisplay.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230324 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230324 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return mstrLastName;
      }
      // string LastName (Get)

      set
      //***
      // Action Set
      //   - Define mstrLastName
      // Called by
      //   - wpfEmployee.cmdDisplay_Click(System.Object, System.Windwos.RoutedEventArgs) Handles cmdDisplay.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230324 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230324 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        mstrLastName = value;
      }
      // LastName(string) (Set)

    }
    // string LastName

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int Age(DateTime dtmBirthDate)
    //***
    // Action
    //   - Calculate the age of a person given a birthdate
    // Called by
    //   - wpfEmployee.cmdDisplay_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdDisplay.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230324 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230324 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return Convert.ToInt32(Math.Floor(DateTime.Now.Subtract(dtmBirthDate).Days / 365.25 + 0.001));
    }
    // int Age(DateTime)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPerson

}
// CopyPaste.Learning.Toolkit