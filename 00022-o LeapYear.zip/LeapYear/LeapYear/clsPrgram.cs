//***
// Action
//   - A year is asked, it is calculated if it is a leap year
// Created
//   - CopyPaste � 20240502 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240502 � VVDW
// Proposal (To Do)
//   - Alternative, you can determine using a date if it is a leapyear
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Ask a year as text
      //   - Convert it to a number
      //   - If it is divisible by 4
      //     - If is it divisible by 100 and not by 400
      //       - It is a not leap year
      //     - If not
      //       - It is a leap year
      //   - If not
      //     - It is not a leap year
      //   - Show the result
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240502 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240502 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnLeapYear;
      int lngYear;

      Console.Write("Enter a year: ");
      lngYear = Convert.ToInt32(Console.ReadLine());
      blnLeapYear = false;

      if (lngYear % 4 == 0)
      {

        if ((lngYear % 100 == 0) && (lngYear % 400 != 0))
        {
        }
        else
          // lngYear % 100 <> 0 OrElse lngYear % 400 = 0
        {
          blnLeapYear = true;
        }
        // lngYear % 100 = 0 AndAlso lngYear % 400 <> 0

      }
      else
        // lngYear % 4 <> 0
      {
      }
      // lngYear % 4 = 0

      if (blnLeapYear)
      {
        Console.WriteLine("The year {0} is a leap year", lngYear);
      }
      else
        // Not blnLeapYear
      {
        Console.WriteLine("The year {0} is not a leap year", lngYear);
      }
      // blnLeapYear

      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning