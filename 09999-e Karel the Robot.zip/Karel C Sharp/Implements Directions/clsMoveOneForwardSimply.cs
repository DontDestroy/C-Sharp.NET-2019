﻿//***
// Action
//   - Create a class cpMoveOneForwardSimple that uses the interface Directions
// Created
//   - CopyPaste – 20251010 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251010 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpMoveOneForwardSimply : Directions
	{

		#region "Constructors / Destructors"

		public cpMoveOneForwardSimply()
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Reset the world
		//   - Build the world according to the One Wall Segment specifications
		//   - Set the delay (speed) to 100
		//   - Make the world visible
		//   - Karel becomes a blue robot starting at position (1, 1), looking to the right with no beepers in the bag
		//   - Karel will move one forward (and succeed)
		//   - Karel shuts down
		// Called by
		//   - cpProgram.MoveOneForwardSimply()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251010 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251010 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			World.reset();
			World.readWorld("Worlds\\02.01a One Wall Segment.kwld");
			World.setVisible(true);
			
			UrRobot karel = new UrRobot(1, 1, Directions.East, 0, Color.blue);
			
			karel.move();
			karel.turnOff();
		}
		// cpMoveOneForwardSimply()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// cpMoveOneForwardSimply

}
// cpKarelTheRobot