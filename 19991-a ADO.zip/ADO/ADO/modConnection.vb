'***
' Action
'   - ADO code about connections
' Created
'   - CopyPaste � 20260331 � VVDW
' Changed
'   - CopyPaste � yyyymmdd � VVDW � What changed
' Tested
'   - CopyPaste � 20260331 � VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On 
Option Strict On

Imports Microsoft.VisualBasic.ControlChars
Imports System.Windows.Forms

Namespace CopyPaste.Learning

  Public Module modConnection

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

    '#Region "Fields"
    '#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

    '#Region "Controls"
    '#End Region

#Region "Functionality"

    '#Region "Event"
    '#End Region

#Region "Sub / Function"

    Public Sub OpenAndDisplayADOConnection(ByVal txtResult As TextBox)
      '***
      ' Action
      '   - Create a new instance of ADODB connection
      '   - Create and initialize a connection string
      '   - Open the connection
      '   - Show some info (using txtResult)
      '   - Close the connection
      ' Called by
      '   - frmMain.cmdOpenConnection_Click(System.Object, System.EventArgs) Handles cmdOpenConnection.Click
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      Dim theConnection As New ADODB.Connection
      Dim strConnection As String = "Provider=SQLNCLI11;Data Source=copypastepower\copypaste;Integrated Security=SSPI;Initial Catalog=cpNorthWindScript2019"

      theConnection.Open(strConnection)
      txtResult.Text = "New connection string : " & CrLf & CrLf & theConnection.ConnectionString
      theConnection.Close()
    End Sub
    ' OpenAndDisplayADOConnection(TextBox)

    Public Sub OpencpNorthwindScriptADOConnection(ByRef theConnection As ADODB.Connection)
      '***
      ' Action
      '   - Given an ADODB connection
      '   - Create and initialize a connection string
      '   - Try to
      '     - Open the connection
      '     - Show some info (using txtResult)
      '   - On possible error
      '     - Show the exception message
      '   - Close the connection (is in comments, because the connection will be used)
      ' Called by
      '   - modCommand.ExecuteABatchCommand(TextBox)
      '   - modCommand.UseAStoredProcedureWithAParameter(TextBox)
      '   - modRecordset.OpenRecordsetWithEditing(TextBox)
      '   - modRecordset.PersistingARecordset(TextBox)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      Dim strConnection As String = "Provider=SQLNCLI11;Data Source=copypastepower\copypaste;Integrated Security=SSPI;Initial Catalog=cpNorthWindScript2019"

      Try
        theConnection.Open(strConnection)
      Catch theException As Exception
        MessageBox.Show("The following error occured: " & theException.Message)
      Finally
        ' theConnection.Close()
      End Try

    End Sub
    ' OpencpNorthwindScriptADOConnection(�ADODB.Connection)

#End Region

#End Region

#End Region

#Region "Not used"

    Public Sub DisplayProviderAndSecuredAccessDB(ByVal txtResult As TextBox)
      '***
      ' Action
      '   - Having an Access Database with security using the Jet OLEDB 4.0 engine
      ' Called by
      '   - 
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      Dim theConnection As New ADODB.Connection

      theConnection.Provider = "Microsoft.Jet.OLEDB.4.0"
      theConnection.Properties("Jet OLEDB:System database").Value = "E:\Data\MySystem.mdw"
      theConnection.Open("Data Source=E:\Data\MyMDB.mdb;User Id=Admin;Password=MyPassword")
      txtResult.Text = theConnection.ConnectionString
    End Sub
    ' DisplayProviderAndSecuredAccessDB(TextBox)

#End Region

  End Module
  ' modConnection

End Namespace
' CopyPaste.Learning