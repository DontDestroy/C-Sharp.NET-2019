//***
// Action
//   - If ... Then ... Else ... End If (3 times)
// Created
//   - CopyPaste � 20220119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220119 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Condition
{

  class cpCondition
	{

    static void Main()
    //***
    // Action
    //   - Define 3 boolean variables
    //   - If not 'owns a pet', show message at console screen
    //   - If has at least one pet, show message at console screen
    //   - If have two pets, show message at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(String)
    // Created
    //   - CopyPaste � 20220119 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220119 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      bool blnOwnsACat = true;
      bool blnOwnsADog = true;
      bool blnOwnsAPet = false;
      
      if (blnOwnsAPet)
      {
      }
      else
        // Not blnOwnsAPet
      {
        Console.WriteLine("You need a pet");
      }
      // blnOwnsAPet

      if (blnOwnsADog | blnOwnsACat)
      {
        Console.WriteLine("Dogs and Cats are great");
      }
      else
        // Not (blnOwnsADog Or blnOwnsACat)
      {
      }
      //(blnOwnsADog Or blnOwnsACat)

      if (blnOwnsADog & blnOwnsACat)
      {
        Console.WriteLine("Do the dog and cat get along?");
      }
      else
        // Not (blnOwnsADog And blnOwnsACat)
      {
      }
      // (blnOwnsADog And blnOwnsACat)

      Console.ReadLine();
    }
    // Main()

  }
  // cpCondition

}
// Condition