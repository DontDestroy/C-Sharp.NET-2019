//***
// Action
//   - Creating a cpTime
// Created
//   - CopyPaste � 20220301 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220301 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Toolkit.Time
{

  public class cpTime
	{

    #region "Constructors / Destructors"

    public cpTime()
    //***
    // Action
    //   - Creating an instance of cpTime
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - SetTime(int, int, int)
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      SetTime(0, 0, 0);
    }
    // cpTime()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mintHour;
    private int mintMinute;
    private int mintSecond;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void SetTime(int intHour, int intMinute, int intSecond)
    //***
    // Action
    //   - Set new time value using universal time
    //   - Define the time of cpTime, by the hour, minutes and seconds
    //   - Perform validity checks on data
    //   - Set invalid values to zero
    //   - If hour is wrong, by default 0 is placed
    //   - If minute is wrong, by default 0 is placed
    //   - If second is wrong, by default 0 is placed
    // Called by
    //   - cpProgram.Main()
    //   - cpTime.New()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (intHour >= 0 && intHour < 24)
      {
        mintHour = intHour;
      }
      else
        // intHour < 0 || intHour >= 24
      {
        mintHour = 0;
      }
      // (lngHour >= 0 && lngHour < 24)
      
      if (intMinute >= 0 && intMinute < 60)
      {
        mintMinute = intMinute;
      }
      else
        // (intMinute < 0 || intMinute >= 60)
      {
        mintMinute = 0;
      }
      // (intMinute >= 0 && intMinute < 60)
      
      if (intSecond >= 0 && intSecond < 60)
      {
        mintSecond = intSecond ;
      }
      else
        // (intSecond < 0 || intSecond >= 60)
      {
        intSecond  = 0;
      }
      // (intSecond >= 0 && intSecond < 60)

    }
    // SetTime(int, int, int)

    public string ToAmericanString()
    //***
    // Action
    //   - Show the time in American format
    //   - Show the time in American format
    //   - Is it AM or is it PM
    //   - How is the hour shown
    // Called by
    //   - 
    // Calls
    //   - string string.Format(string, System.Object, System.Object, System.Object)
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intStandardHour;
      string strFormat = "{0}:{1:D2}:{2:D2}";
      string strSuffix;

      // Determine whether time is AM or PM
      
      if (mintHour < 12)
      {
        strSuffix = " AM";
      }      
      else
        // mintHour >= 12 
      {
        strSuffix = " PM";
      }
      // mintHour < 12 
      
      if (mintHour == 12 || mintHour == 0)
      {
        intStandardHour = 12;
      }
      else
        // (mintHour = 12 && mintHour = 0)
      {
        intStandardHour = mintHour % 12;
      }
      
      return string.Format(strFormat, intStandardHour, mintMinute, mintSecond) + strSuffix;
    }
    // string ToAmericanString()

    public string ToUniversalString()
    //***
    // Action
    //   - Show the time in Universal format
    // Called by
    //   - 
    // Calls
    //   - string string.Format(string, System.Object, System.Object, System.Object)
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return String.Format("{0}:{1:D2}:{2:D2}", mintHour, mintMinute, mintSecond);
    }
    // string ToUniversalString()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpTime

}
// CopyPaste.Learning.Toolkit.Time