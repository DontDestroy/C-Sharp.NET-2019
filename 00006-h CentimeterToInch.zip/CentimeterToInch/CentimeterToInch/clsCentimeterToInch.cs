//'***
//' Action
//'   - Recalculate a distance in centimeter to inch
//' Created
//'   - CopyPaste � 20220111 � VVDW
//' Changed
//'   - CopyPaste � yyyymmdd � VVDW � What changed
//' Tested
//'   - CopyPaste � 20220111 � VVDW
//' Proposal (To Do)
//'   -
//'***
//

using System;

namespace CentimeterToInch
{

  class cpCentimeterToInch
	{

    static void Main()
    //***
    // Action
    //   - Initialise variables
    //   - Calculate
    //   - Show result at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - System.Console.WriteLine(Single)
    //   - System.Console.ReadLine()
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      const decimal cdecCmInch = 2.54M;

      decimal decCm = 100;
      decimal decInch;
      
      decInch = decCm / cdecCmInch;
      Console.WriteLine(decCm);
      Console.WriteLine(decInch);
      Console.ReadLine();
    }
    // Main()

  }
  // cpCentimeterToInch

}
// CentimeterToInch