﻿//***
// Action
//   - Implementation of a cpKnight
//     - Inherits from cpGameCharacter
//   - The way a cpKnight can fight given thru a delegate and an event
// Created
//   - CopyPaste – 20240806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240806 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Weapon.Library;

namespace CopyPaste.Game.Character.Library
{

	public class cpKnight : cpGameCharacter
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpKnight
		/// </summary>
		public cpKnight() : base()
		//***
		// Action
		//   - Basic constructor
		//   - Define how a cpKnight fights (with a weapon)
		// Called by
		//   - CopyPaste.Game.Character.Test.cpProgram.Main()
		// Calls
		//   - CopyPaste.Game.Weapon.Library.cpSword()
		//   - cpGameCharacter()
		//   - cpGameCharacter.HowToFight(cpiWeapon) (Set)
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			HowToFight = new cpSword();
		}
		// cpKnight()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// cpKnight

}
// CopyPaste.Game.Character.Library