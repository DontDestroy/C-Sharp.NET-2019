//***
// Action
//   - Write data in a binary format
// Created
//   - CopyPaste � 20240621 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240621 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Try
      //     - Create a file stream
      //   - When an error occurs
      //     - Show personal error message
      //     - Show technical error message
      //   - Create binary writer
      //   - Try
      //     - Write a double, integer and string to the file
      //   - When an error occurs
      //     - Show personal error message
      //     - Show technical error message
      //   - Close the file
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240621 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240621 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      FileStream theFileStream = null;

      try
      {
        theFileStream = new FileStream("T:\\Binary.dat", FileMode.Create);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error creating T:\\Binary.Dat");
        Console.WriteLine("Error {0}", theException.Message);
      }
      finally
      {
      }

      BinaryWriter theBinaryWriter = new BinaryWriter(theFileStream);

      double dblSalary = 1000000.0D;
      int lngAge = 21;
      string strName = "Kris";

      try
      {
        theBinaryWriter.Write(lngAge);
        theBinaryWriter.Write(dblSalary);
        theBinaryWriter.Write(strName);
        Console.WriteLine("Data written to T:\\Binary.dat");
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error writing to T:\\Binary.Dat");
        Console.WriteLine("Error {0}", theException.Message);
      }
      finally
      {
        theFileStream.Close();
      }

      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning