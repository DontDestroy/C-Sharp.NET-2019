//***
// Action
//   - Testroutine for cpPerson
// Created
//   - CopyPaste � 20220308 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220308 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning.Toolkit
{

  public class frmEmployee : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code
    internal System.Windows.Forms.DateTimePicker dtpBirthDay;
    internal System.Windows.Forms.Label lblText;
    internal System.Windows.Forms.TextBox txtName;
    internal System.Windows.Forms.TextBox txtFirstName;
    internal System.Windows.Forms.Button cmdDisplay;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmEmployee));
      this.dtpBirthDay = new System.Windows.Forms.DateTimePicker();
      this.lblText = new System.Windows.Forms.Label();
      this.txtName = new System.Windows.Forms.TextBox();
      this.txtFirstName = new System.Windows.Forms.TextBox();
      this.cmdDisplay = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // dtpBirthDay
      // 
      this.dtpBirthDay.Location = new System.Drawing.Point(50, 144);
      this.dtpBirthDay.Name = "dtpBirthDay";
      this.dtpBirthDay.Size = new System.Drawing.Size(184, 20);
      this.dtpBirthDay.TabIndex = 8;
      this.dtpBirthDay.Value = new System.DateTime(1970, 5, 6, 1, 35, 0, 0);
      // 
      // lblText
      // 
      this.lblText.Location = new System.Drawing.Point(10, 16);
      this.lblText.Name = "lblText";
      this.lblText.Size = new System.Drawing.Size(272, 32);
      this.lblText.TabIndex = 5;
      this.lblText.Text = "Type name, firstname and birthday of the employee.";
      // 
      // txtName
      // 
      this.txtName.Location = new System.Drawing.Point(50, 104);
      this.txtName.Name = "txtName";
      this.txtName.Size = new System.Drawing.Size(184, 20);
      this.txtName.TabIndex = 7;
      this.txtName.Text = "Name";
      // 
      // txtFirstName
      // 
      this.txtFirstName.Location = new System.Drawing.Point(50, 64);
      this.txtFirstName.Name = "txtFirstName";
      this.txtFirstName.Size = new System.Drawing.Size(184, 20);
      this.txtFirstName.TabIndex = 6;
      this.txtFirstName.Text = "Firstname";
      // 
      // cmdDisplay
      // 
      this.cmdDisplay.Location = new System.Drawing.Point(98, 200);
      this.cmdDisplay.Name = "cmdDisplay";
      this.cmdDisplay.Size = new System.Drawing.Size(96, 32);
      this.cmdDisplay.TabIndex = 9;
      this.cmdDisplay.Text = "&Show data";
      this.cmdDisplay.Click += new System.EventHandler(this.cmdDisplay_Click);
      // 
      // frmEmployee
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.dtpBirthDay);
      this.Controls.Add(this.lblText);
      this.Controls.Add(this.txtName);
      this.Controls.Add(this.txtFirstName);
      this.Controls.Add(this.cmdDisplay);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmEmployee";
      this.Text = "Employee";
      this.Load += new System.EventHandler(this.frmEmployee_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmEmployee'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220308 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220308 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmEmployee()
      //***
      // Action
      //   - Create instance of 'frmEmployee'
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220308 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220308 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmEmployee()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdDisplay_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Reading the information from the form controls
      //   - Defining a cpPerson
      //   - Using the method / function to show the age
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpPerson.FirstName(string) (Set)
      //   - cpPerson.LastName(string) (Set)
      //   - int cpPerson.Age()
      //   - string cpPerson.FirstName() (Get)
      //   - string cpPerson.LastName() (Get)
      // Created
      //   - CopyPaste � 20220308 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220308 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      DateTime dtmDateOfBirth;
      cpPerson theEmployee = new cpPerson();

      theEmployee.FirstName = txtFirstName.Text;
      theEmployee.LastName = txtName.Text;
      dtmDateOfBirth = dtpBirthDay.Value.Date;
      
      MessageBox.Show(theEmployee.FirstName + " " + theEmployee.LastName +
        " is " + theEmployee.Age(dtmDateOfBirth) + " years old.", "Copy Paste");
    }
    // cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click

    private void frmEmployee_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - 
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmEmployee_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmEmployee
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmEmployee());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmEmployee

}
// CopyPaste.Learning.Toolkit