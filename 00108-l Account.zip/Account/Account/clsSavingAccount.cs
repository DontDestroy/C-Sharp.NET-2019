//***
// Action
//   - Definition of a cpSavingAccount
// Created
//   - CopyPaste � 20240105 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240105 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

	public class cpSavingAccount : cpAccount
	{

		#region "Constructors / Destructors"

		public cpSavingAccount(long lngAccountNumber, decimal decAmount, DateTime dtmCreation, decimal decIntrest) : base(lngAccountNumber, decAmount, dtmCreation)
			//***
			// Action
			//   - Constructor with 4 arguments
			//   - An accountnumber, an amount, the creation date and an intrestrate
			//   - Set the 3 properties thru the base class
			//   - Set the intrest rate with the given argument
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - cpAccount(long, decimal, DateTime)
			//   - Intrest(decimal) (Set)
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Intrest = decIntrest;
		}
		// cpSavingAccount(long, decimal, DateTime, decimal)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private decimal mdecIntrest;

		#endregion

		#region "Properties"

		public decimal Intrest
		{
			
			get
				//***
				// Action Get
				//   - Returns mdecIntrest
				// Called by
				//   - Show()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mdecIntrest;
			}
			// decimal Intrest (Get)

			set
				//***
				// Action Set
				//   - Checks if value is positive or zero
				//	 - If check is correct
				//     - mdecIntrest becomes value
				//   - If not
				//     - Throw error message
				// Called by
				//   - cpSavingAccount(long, decimal, DateTime, decimal)
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{

				if (value >= 0)
				{
					mdecIntrest = value;
				}
					// value < 0
				else
				{
					throw new ApplicationException("Intrest % is not acceptable");
				}
				// value >= 0

			}
			// Intrest(decimal) (Set)

		}
		// decimal Intrest

		#endregion

		#region "Methods"

		#region "Overrides"

		public override void Show()
			//***
			// Action
			//   - Show the accountnumber, the amount, the creation date and empty line of the base class
      //   - Show the intrest rate
			//   - Show an empty line
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - cpAccount.Show()
			//   - decimal Intrest (Get)
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			base.Show();
			Console.WriteLine("Intrest: {0}", Intrest);
			Console.WriteLine("");
		}
		// Show()

		#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpSavingAccount

}
// CopyPaste.Learning