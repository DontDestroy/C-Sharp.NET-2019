//***
// Action
//   - Having a chat with a fake Psychiatrist
// Created
//   - CopyPaste � 20220216 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220216 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Eliza
{

  public class frmPsychiatrist : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code
    internal System.Windows.Forms.TextBox txtQuestion;
    internal System.Windows.Forms.Label lblInstructions;
    internal System.Windows.Forms.Label lblDoctor;
    internal System.Windows.Forms.Label lblCaption;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPsychiatrist));
      this.txtQuestion = new System.Windows.Forms.TextBox();
      this.lblInstructions = new System.Windows.Forms.Label();
      this.lblDoctor = new System.Windows.Forms.Label();
      this.lblCaption = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // txtQuestion
      // 
      this.txtQuestion.Location = new System.Drawing.Point(15, 192);
      this.txtQuestion.Name = "txtQuestion";
      this.txtQuestion.Size = new System.Drawing.Size(256, 20);
      this.txtQuestion.TabIndex = 7;
      this.txtQuestion.Text = "";
      this.txtQuestion.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtQuestion_KeyDown);
      // 
      // lblInstructions
      // 
      this.lblInstructions.Location = new System.Drawing.Point(15, 152);
      this.lblInstructions.Name = "lblInstructions";
      this.lblInstructions.Size = new System.Drawing.Size(264, 23);
      this.lblInstructions.TabIndex = 6;
      this.lblInstructions.Text = "Type your response and press ENTER";
      // 
      // lblDoctor
      // 
      this.lblDoctor.BackColor = System.Drawing.Color.Lime;
      this.lblDoctor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblDoctor.Location = new System.Drawing.Point(15, 64);
      this.lblDoctor.Name = "lblDoctor";
      this.lblDoctor.Size = new System.Drawing.Size(256, 72);
      this.lblDoctor.TabIndex = 5;
      // 
      // lblCaption
      // 
      this.lblCaption.Font = new System.Drawing.Font("Comic Sans MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblCaption.Location = new System.Drawing.Point(15, 24);
      this.lblCaption.Name = "lblCaption";
      this.lblCaption.Size = new System.Drawing.Size(256, 23);
      this.lblCaption.TabIndex = 4;
      this.lblCaption.Text = "The Computer Psychiatrist";
      this.lblCaption.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // frmPsychiatrist
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(294, 247);
      this.Controls.Add(this.txtQuestion);
      this.Controls.Add(this.lblInstructions);
      this.Controls.Add(this.lblDoctor);
      this.Controls.Add(this.lblCaption);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "frmPsychiatrist";
      this.Text = "E L I Z A   the computer doctor";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPsychiatrist'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPsychiatrist()
      //***
      // Action
      //   - Create instance of 'frmPsychiatrist'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      lblDoctor.Text = "What would you like to talk about this beautiful day?";
    }
    // frmPsychiatrist()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    cpDialog aDialog = new cpDialog();
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void txtQuestion_KeyDown(System.Object theSender, System.Windows.Forms.KeyEventArgs theKeyEventArguments) 
      //***
      // Action
      //   - When you hit enter in the Question textbox
      //     - Find a response by Eliza 
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool theKeyEventArguments.KeyCode.Equals(int)
      //   - Keys Enumeration
      //   - string modDialog.GetElizaResponse(string)
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (theKeyEventArguments.KeyCode.Equals(Keys.Enter))
      {
        lblDoctor.Text = aDialog.GetElizaResponse(txtQuestion.Text);
        txtQuestion.Text = "";
      }
      else
        // Not theKeyEventArguments.KeyCode.Equals(Keys.Enter)
      {
      }
      // theKeyEventArguments.KeyCode.Equals(Keys.Enter)
    
    }
    // txtQuestion_KeyDown(System.Object, System.Windows.Forms.KeyEventArgs) Handles txtQuestion.KeyDown

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPsychiatrist
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPsychiatrist());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmPsychiatrist

}
// Psychiatrist