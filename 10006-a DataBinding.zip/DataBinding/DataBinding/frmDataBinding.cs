//***
// Action
//   - Bind the data set information to controls on the form
// Created
//   - CopyPaste � 20251119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251119 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDataBinding: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.DataGrid dgrDataGrid;
    internal System.Data.SqlClient.SqlCommand cmmInsertOrder;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwindScript;
    internal System.Data.SqlClient.SqlCommand cmmDeleteEmployee;
    internal System.Data.SqlClient.SqlCommand cmmUpdateEmployee;
    internal System.Windows.Forms.TextBox txtIdEmployee;
    internal System.Windows.Forms.TextBox txtTitle;
    internal System.Data.SqlClient.SqlDataAdapter dtaOrder;
    internal System.Data.SqlClient.SqlCommand cmmDeleteOrder;
    internal System.Data.SqlClient.SqlCommand cmmSelectOrder;
    internal System.Data.SqlClient.SqlCommand cmmUpdateOrder;
    internal System.Data.SqlClient.SqlCommand cmmSelectEmployee;
    internal System.Data.SqlClient.SqlDataAdapter dtaEmployee;
    internal System.Data.SqlClient.SqlCommand cmmInsertEmployee;
    private DataBinding.dsData dsData;
    internal System.Windows.Forms.ComboBox cmbEmployee;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataBinding));
      this.dgrDataGrid = new System.Windows.Forms.DataGrid();
      this.cmmInsertOrder = new System.Data.SqlClient.SqlCommand();
      this.cnncpNorthwindScript = new System.Data.SqlClient.SqlConnection();
      this.cmmDeleteEmployee = new System.Data.SqlClient.SqlCommand();
      this.cmmUpdateEmployee = new System.Data.SqlClient.SqlCommand();
      this.txtIdEmployee = new System.Windows.Forms.TextBox();
      this.txtTitle = new System.Windows.Forms.TextBox();
      this.dtaOrder = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmDeleteOrder = new System.Data.SqlClient.SqlCommand();
      this.cmmSelectOrder = new System.Data.SqlClient.SqlCommand();
      this.cmmUpdateOrder = new System.Data.SqlClient.SqlCommand();
      this.cmmSelectEmployee = new System.Data.SqlClient.SqlCommand();
      this.dtaEmployee = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmInsertEmployee = new System.Data.SqlClient.SqlCommand();
      this.cmbEmployee = new System.Windows.Forms.ComboBox();
      this.dsData = new DataBinding.dsData();
      ((System.ComponentModel.ISupportInitialize)(this.dgrDataGrid)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.SuspendLayout();
      // 
      // dgrDataGrid
      // 
      this.dgrDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrDataGrid.DataMember = "";
      this.dgrDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrDataGrid.Location = new System.Drawing.Point(8, 52);
      this.dgrDataGrid.Name = "dgrDataGrid";
      this.dgrDataGrid.Size = new System.Drawing.Size(392, 208);
      this.dgrDataGrid.TabIndex = 7;
      // 
      // cmmInsertOrder
      // 
      this.cmmInsertOrder.CommandText = resources.GetString("cmmInsertOrder.CommandText");
      this.cmmInsertOrder.Connection = this.cnncpNorthwindScript;
      this.cmmInsertOrder.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@strCustomerId", System.Data.SqlDbType.VarChar, 5, "strCustomerId"),
            new System.Data.SqlClient.SqlParameter("@intEmployeeId", System.Data.SqlDbType.Int, 4, "intEmployeeId"),
            new System.Data.SqlClient.SqlParameter("@dtmOrderDate", System.Data.SqlDbType.DateTime, 8, "dtmOrderDate"),
            new System.Data.SqlClient.SqlParameter("@dtmRequiredDate", System.Data.SqlDbType.DateTime, 8, "dtmRequiredDate"),
            new System.Data.SqlClient.SqlParameter("@dtmShippedDate", System.Data.SqlDbType.DateTime, 8, "dtmShippedDate"),
            new System.Data.SqlClient.SqlParameter("@intShipVia", System.Data.SqlDbType.Int, 4, "intShipVia"),
            new System.Data.SqlClient.SqlParameter("@dblFreight", System.Data.SqlDbType.Money, 8, "dblFreight"),
            new System.Data.SqlClient.SqlParameter("@strShipName", System.Data.SqlDbType.VarChar, 40, "strShipName"),
            new System.Data.SqlClient.SqlParameter("@strShipAddress", System.Data.SqlDbType.VarChar, 60, "strShipAddress"),
            new System.Data.SqlClient.SqlParameter("@strShipCity", System.Data.SqlDbType.VarChar, 15, "strShipCity"),
            new System.Data.SqlClient.SqlParameter("@strShipRegion", System.Data.SqlDbType.VarChar, 15, "strShipRegion"),
            new System.Data.SqlClient.SqlParameter("@strShipPostalCode", System.Data.SqlDbType.VarChar, 10, "strShipPostalCode"),
            new System.Data.SqlClient.SqlParameter("@strShipCountry", System.Data.SqlDbType.VarChar, 15, "strShipCountry")});
      // 
      // cnncpNorthwindScript
      // 
      this.cnncpNorthwindScript.ConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthwindScript.FireInfoMessageEventOnUserErrors = false;
      // 
      // cmmDeleteEmployee
      // 
      this.cmmDeleteEmployee.CommandText = resources.GetString("cmmDeleteEmployee.CommandText");
      this.cmmDeleteEmployee.Connection = this.cnncpNorthwindScript;
      this.cmmDeleteEmployee.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_intIdEmployee", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdEmployee", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dtmBirthDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dtmBirthDate", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dtmHireDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dtmHireDate", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intReportsTo", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReportsTo", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strAddress", System.Data.SqlDbType.VarChar, 60, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCity", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCity", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCountry", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCountry", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strExtension", System.Data.SqlDbType.VarChar, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strExtension", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strFirstName", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strFirstName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strHomePhone", System.Data.SqlDbType.VarChar, 24, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strHomePhone", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strLastName", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strLastName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strPhotoPath", System.Data.SqlDbType.VarChar, 255, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strPhotoPath", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strPostalCode", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strPostalCode", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strRegion", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strRegion", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strTitle", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strTitle", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strTitleOfCourtesy", System.Data.SqlDbType.VarChar, 25, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strTitleOfCourtesy", System.Data.DataRowVersion.Original, null)});
      // 
      // cmmUpdateEmployee
      // 
      this.cmmUpdateEmployee.CommandText = resources.GetString("cmmUpdateEmployee.CommandText");
      this.cmmUpdateEmployee.Connection = this.cnncpNorthwindScript;
      this.cmmUpdateEmployee.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@strLastName", System.Data.SqlDbType.VarChar, 20, "strLastName"),
            new System.Data.SqlClient.SqlParameter("@strFirstName", System.Data.SqlDbType.VarChar, 10, "strFirstName"),
            new System.Data.SqlClient.SqlParameter("@strTitle", System.Data.SqlDbType.VarChar, 30, "strTitle"),
            new System.Data.SqlClient.SqlParameter("@strTitleOfCourtesy", System.Data.SqlDbType.VarChar, 25, "strTitleOfCourtesy"),
            new System.Data.SqlClient.SqlParameter("@dtmBirthDate", System.Data.SqlDbType.DateTime, 8, "dtmBirthDate"),
            new System.Data.SqlClient.SqlParameter("@dtmHireDate", System.Data.SqlDbType.DateTime, 8, "dtmHireDate"),
            new System.Data.SqlClient.SqlParameter("@strAddress", System.Data.SqlDbType.VarChar, 60, "strAddress"),
            new System.Data.SqlClient.SqlParameter("@strCity", System.Data.SqlDbType.VarChar, 15, "strCity"),
            new System.Data.SqlClient.SqlParameter("@strRegion", System.Data.SqlDbType.VarChar, 15, "strRegion"),
            new System.Data.SqlClient.SqlParameter("@strPostalCode", System.Data.SqlDbType.VarChar, 10, "strPostalCode"),
            new System.Data.SqlClient.SqlParameter("@strCountry", System.Data.SqlDbType.VarChar, 15, "strCountry"),
            new System.Data.SqlClient.SqlParameter("@strHomePhone", System.Data.SqlDbType.VarChar, 24, "strHomePhone"),
            new System.Data.SqlClient.SqlParameter("@strExtension", System.Data.SqlDbType.VarChar, 4, "strExtension"),
            new System.Data.SqlClient.SqlParameter("@imgPhoto", System.Data.SqlDbType.VarBinary, 16, "imgPhoto"),
            new System.Data.SqlClient.SqlParameter("@memNotes", System.Data.SqlDbType.VarChar, 2147483647, "memNotes"),
            new System.Data.SqlClient.SqlParameter("@intReportsTo", System.Data.SqlDbType.Int, 4, "intReportsTo"),
            new System.Data.SqlClient.SqlParameter("@strPhotoPath", System.Data.SqlDbType.VarChar, 255, "strPhotoPath"),
            new System.Data.SqlClient.SqlParameter("@Original_intIdEmployee", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdEmployee", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dtmBirthDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dtmBirthDate", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dtmHireDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dtmHireDate", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intReportsTo", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReportsTo", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strAddress", System.Data.SqlDbType.VarChar, 60, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCity", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCity", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCountry", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCountry", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strExtension", System.Data.SqlDbType.VarChar, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strExtension", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strFirstName", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strFirstName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strHomePhone", System.Data.SqlDbType.VarChar, 24, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strHomePhone", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strLastName", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strLastName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strPhotoPath", System.Data.SqlDbType.VarChar, 255, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strPhotoPath", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strPostalCode", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strPostalCode", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strRegion", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strRegion", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strTitle", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strTitle", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strTitleOfCourtesy", System.Data.SqlDbType.VarChar, 25, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strTitleOfCourtesy", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@intIdEmployee", System.Data.SqlDbType.Int, 4, "intIdEmployee")});
      // 
      // txtIdEmployee
      // 
      this.txtIdEmployee.Location = new System.Drawing.Point(336, 12);
      this.txtIdEmployee.Name = "txtIdEmployee";
      this.txtIdEmployee.Size = new System.Drawing.Size(64, 20);
      this.txtIdEmployee.TabIndex = 6;
      this.txtIdEmployee.TextChanged += new System.EventHandler(this.txtIdEmployee_TextChanged);
      // 
      // txtTitle
      // 
      this.txtTitle.Location = new System.Drawing.Point(168, 12);
      this.txtTitle.Name = "txtTitle";
      this.txtTitle.Size = new System.Drawing.Size(160, 20);
      this.txtTitle.TabIndex = 5;
      // 
      // dtaOrder
      // 
      this.dtaOrder.DeleteCommand = this.cmmDeleteOrder;
      this.dtaOrder.InsertCommand = this.cmmInsertOrder;
      this.dtaOrder.SelectCommand = this.cmmSelectOrder;
      this.dtaOrder.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPOrder", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdOrder", "intIdOrder"),
                        new System.Data.Common.DataColumnMapping("strCustomerId", "strCustomerId"),
                        new System.Data.Common.DataColumnMapping("intEmployeeId", "intEmployeeId"),
                        new System.Data.Common.DataColumnMapping("dtmOrderDate", "dtmOrderDate"),
                        new System.Data.Common.DataColumnMapping("dtmRequiredDate", "dtmRequiredDate"),
                        new System.Data.Common.DataColumnMapping("dtmShippedDate", "dtmShippedDate"),
                        new System.Data.Common.DataColumnMapping("intShipVia", "intShipVia"),
                        new System.Data.Common.DataColumnMapping("dblFreight", "dblFreight"),
                        new System.Data.Common.DataColumnMapping("strShipName", "strShipName"),
                        new System.Data.Common.DataColumnMapping("strShipAddress", "strShipAddress"),
                        new System.Data.Common.DataColumnMapping("strShipCity", "strShipCity"),
                        new System.Data.Common.DataColumnMapping("strShipRegion", "strShipRegion"),
                        new System.Data.Common.DataColumnMapping("strShipPostalCode", "strShipPostalCode"),
                        new System.Data.Common.DataColumnMapping("strShipCountry", "strShipCountry")})});
      this.dtaOrder.UpdateCommand = this.cmmUpdateOrder;
      // 
      // cmmDeleteOrder
      // 
      this.cmmDeleteOrder.CommandText = resources.GetString("cmmDeleteOrder.CommandText");
      this.cmmDeleteOrder.Connection = this.cnncpNorthwindScript;
      this.cmmDeleteOrder.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_intIdOrder", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dblFreight", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblFreight", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dtmOrderDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dtmOrderDate", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dtmRequiredDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dtmRequiredDate", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dtmShippedDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dtmShippedDate", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intEmployeeId", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intEmployeeId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intShipVia", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intShipVia", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCustomerId", System.Data.SqlDbType.VarChar, 5, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCustomerId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strShipAddress", System.Data.SqlDbType.VarChar, 60, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strShipAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strShipCity", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strShipCity", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strShipCountry", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strShipCountry", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strShipName", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strShipName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strShipPostalCode", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strShipPostalCode", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strShipRegion", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strShipRegion", System.Data.DataRowVersion.Original, null)});
      // 
      // cmmSelectOrder
      // 
      this.cmmSelectOrder.CommandText = resources.GetString("cmmSelectOrder.CommandText");
      this.cmmSelectOrder.Connection = this.cnncpNorthwindScript;
      // 
      // cmmUpdateOrder
      // 
      this.cmmUpdateOrder.CommandText = resources.GetString("cmmUpdateOrder.CommandText");
      this.cmmUpdateOrder.Connection = this.cnncpNorthwindScript;
      this.cmmUpdateOrder.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@strCustomerId", System.Data.SqlDbType.VarChar, 5, "strCustomerId"),
            new System.Data.SqlClient.SqlParameter("@intEmployeeId", System.Data.SqlDbType.Int, 4, "intEmployeeId"),
            new System.Data.SqlClient.SqlParameter("@dtmOrderDate", System.Data.SqlDbType.DateTime, 8, "dtmOrderDate"),
            new System.Data.SqlClient.SqlParameter("@dtmRequiredDate", System.Data.SqlDbType.DateTime, 8, "dtmRequiredDate"),
            new System.Data.SqlClient.SqlParameter("@dtmShippedDate", System.Data.SqlDbType.DateTime, 8, "dtmShippedDate"),
            new System.Data.SqlClient.SqlParameter("@intShipVia", System.Data.SqlDbType.Int, 4, "intShipVia"),
            new System.Data.SqlClient.SqlParameter("@dblFreight", System.Data.SqlDbType.Money, 8, "dblFreight"),
            new System.Data.SqlClient.SqlParameter("@strShipName", System.Data.SqlDbType.VarChar, 40, "strShipName"),
            new System.Data.SqlClient.SqlParameter("@strShipAddress", System.Data.SqlDbType.VarChar, 60, "strShipAddress"),
            new System.Data.SqlClient.SqlParameter("@strShipCity", System.Data.SqlDbType.VarChar, 15, "strShipCity"),
            new System.Data.SqlClient.SqlParameter("@strShipRegion", System.Data.SqlDbType.VarChar, 15, "strShipRegion"),
            new System.Data.SqlClient.SqlParameter("@strShipPostalCode", System.Data.SqlDbType.VarChar, 10, "strShipPostalCode"),
            new System.Data.SqlClient.SqlParameter("@strShipCountry", System.Data.SqlDbType.VarChar, 15, "strShipCountry"),
            new System.Data.SqlClient.SqlParameter("@Original_intIdOrder", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dblFreight", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblFreight", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dtmOrderDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dtmOrderDate", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dtmRequiredDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dtmRequiredDate", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dtmShippedDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dtmShippedDate", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intEmployeeId", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intEmployeeId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intShipVia", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intShipVia", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCustomerId", System.Data.SqlDbType.VarChar, 5, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCustomerId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strShipAddress", System.Data.SqlDbType.VarChar, 60, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strShipAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strShipCity", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strShipCity", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strShipCountry", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strShipCountry", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strShipName", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strShipName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strShipPostalCode", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strShipPostalCode", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strShipRegion", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strShipRegion", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@intIdOrder", System.Data.SqlDbType.Int, 4, "intIdOrder")});
      // 
      // cmmSelectEmployee
      // 
      this.cmmSelectEmployee.CommandText = resources.GetString("cmmSelectEmployee.CommandText");
      this.cmmSelectEmployee.Connection = this.cnncpNorthwindScript;
      // 
      // dtaEmployee
      // 
      this.dtaEmployee.DeleteCommand = this.cmmDeleteEmployee;
      this.dtaEmployee.InsertCommand = this.cmmInsertEmployee;
      this.dtaEmployee.SelectCommand = this.cmmSelectEmployee;
      this.dtaEmployee.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPEmployee", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdEmployee", "intIdEmployee"),
                        new System.Data.Common.DataColumnMapping("strLastName", "strLastName"),
                        new System.Data.Common.DataColumnMapping("strFirstName", "strFirstName"),
                        new System.Data.Common.DataColumnMapping("strTitle", "strTitle"),
                        new System.Data.Common.DataColumnMapping("strTitleOfCourtesy", "strTitleOfCourtesy"),
                        new System.Data.Common.DataColumnMapping("dtmBirthDate", "dtmBirthDate"),
                        new System.Data.Common.DataColumnMapping("dtmHireDate", "dtmHireDate"),
                        new System.Data.Common.DataColumnMapping("strAddress", "strAddress"),
                        new System.Data.Common.DataColumnMapping("strCity", "strCity"),
                        new System.Data.Common.DataColumnMapping("strRegion", "strRegion"),
                        new System.Data.Common.DataColumnMapping("strPostalCode", "strPostalCode"),
                        new System.Data.Common.DataColumnMapping("strCountry", "strCountry"),
                        new System.Data.Common.DataColumnMapping("strHomePhone", "strHomePhone"),
                        new System.Data.Common.DataColumnMapping("strExtension", "strExtension"),
                        new System.Data.Common.DataColumnMapping("imgPhoto", "imgPhoto"),
                        new System.Data.Common.DataColumnMapping("memNotes", "memNotes"),
                        new System.Data.Common.DataColumnMapping("intReportsTo", "intReportsTo"),
                        new System.Data.Common.DataColumnMapping("strPhotoPath", "strPhotoPath")})});
      this.dtaEmployee.UpdateCommand = this.cmmUpdateEmployee;
      // 
      // cmmInsertEmployee
      // 
      this.cmmInsertEmployee.CommandText = resources.GetString("cmmInsertEmployee.CommandText");
      this.cmmInsertEmployee.Connection = this.cnncpNorthwindScript;
      this.cmmInsertEmployee.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@strLastName", System.Data.SqlDbType.VarChar, 20, "strLastName"),
            new System.Data.SqlClient.SqlParameter("@strFirstName", System.Data.SqlDbType.VarChar, 10, "strFirstName"),
            new System.Data.SqlClient.SqlParameter("@strTitle", System.Data.SqlDbType.VarChar, 30, "strTitle"),
            new System.Data.SqlClient.SqlParameter("@strTitleOfCourtesy", System.Data.SqlDbType.VarChar, 25, "strTitleOfCourtesy"),
            new System.Data.SqlClient.SqlParameter("@dtmBirthDate", System.Data.SqlDbType.DateTime, 8, "dtmBirthDate"),
            new System.Data.SqlClient.SqlParameter("@dtmHireDate", System.Data.SqlDbType.DateTime, 8, "dtmHireDate"),
            new System.Data.SqlClient.SqlParameter("@strAddress", System.Data.SqlDbType.VarChar, 60, "strAddress"),
            new System.Data.SqlClient.SqlParameter("@strCity", System.Data.SqlDbType.VarChar, 15, "strCity"),
            new System.Data.SqlClient.SqlParameter("@strRegion", System.Data.SqlDbType.VarChar, 15, "strRegion"),
            new System.Data.SqlClient.SqlParameter("@strPostalCode", System.Data.SqlDbType.VarChar, 10, "strPostalCode"),
            new System.Data.SqlClient.SqlParameter("@strCountry", System.Data.SqlDbType.VarChar, 15, "strCountry"),
            new System.Data.SqlClient.SqlParameter("@strHomePhone", System.Data.SqlDbType.VarChar, 24, "strHomePhone"),
            new System.Data.SqlClient.SqlParameter("@strExtension", System.Data.SqlDbType.VarChar, 4, "strExtension"),
            new System.Data.SqlClient.SqlParameter("@imgPhoto", System.Data.SqlDbType.VarBinary, 2147483647, "imgPhoto"),
            new System.Data.SqlClient.SqlParameter("@memNotes", System.Data.SqlDbType.VarChar, 2147483647, "memNotes"),
            new System.Data.SqlClient.SqlParameter("@intReportsTo", System.Data.SqlDbType.Int, 4, "intReportsTo"),
            new System.Data.SqlClient.SqlParameter("@strPhotoPath", System.Data.SqlDbType.VarChar, 255, "strPhotoPath")});
      // 
      // cmbEmployee
      // 
      this.cmbEmployee.Location = new System.Drawing.Point(8, 12);
      this.cmbEmployee.Name = "cmbEmployee";
      this.cmbEmployee.Size = new System.Drawing.Size(152, 21);
      this.cmbEmployee.TabIndex = 4;
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // frmDataBinding
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(408, 273);
      this.Controls.Add(this.cmbEmployee);
      this.Controls.Add(this.dgrDataGrid);
      this.Controls.Add(this.txtIdEmployee);
      this.Controls.Add(this.txtTitle);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataBinding";
      this.Text = "ADO Binding Example";
      this.Activated += new System.EventHandler(this.frmDataBinding_Activated);
      ((System.ComponentModel.ISupportInitialize)(this.dgrDataGrid)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDataBinding'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDataBinding()
      //***
      // Action
      //   - Create instance of 'frmDataBinding'
      //   - Setup the data
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      //   - SetUpData
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      SetUpData();
    }
    // frmDataBinding()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    DataView mdvDataView;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmDataBinding_Activated(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The setup of the grid is executed
      // Called by
      //   - User action (The form is activated)
      // Calls
      //   - SetUpGrid()
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      SetUpGrid();
    }
    // frmDataBinding_Activated(System.Object, System.EventArgs) Handles frmDataBinding.Activated

    private void txtIdEmployee_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The setup of the grid is executed
      // Called by
      //   - User action or system action (Text of the key of the employee is changed)
      // Calls
      //   - SetUpGrid()
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      SetUpGrid();
      // MessageBox.Show(dsData.tblCPEmployee[cmbEmployee.SelectedIndex].intIdEmployee.ToString());
    }
    // txtIdEmployee_TextChanged(System.Object, System.EventArgs) Handles txtIdEmployee.TextChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDataBinding
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDataBinding()
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDataBinding());
    }
    // Main() 
    
    private void SetUpData()
      //***
      // Action
      //   - Define two data tables (one for employees, one for orders
      //   - Define a relation
      //   - Define two data columns (one for the master (one), one for the child (many)
      //   - Fill the information of tblCPEmployee in the data set
      //   - Fill the information of tblCPOrder in the data set
      //   - Initialize the table for the employees
      //   - Initialize the table for the orders
      //   - Initialize the master column
      //   - Initialize the child column
      //   - Create the relation between the two tables using the master and child column
      //   - Add the relation to the data set
      //   - Bind the employee table to the combobox of employees
      //   - Show the last name
      //   - Bind the title of the employee to the textbox txtTitle
      //   - Bind the key of the employee to the textbox txtIdEmployee
      //   - Create a new data view on orders
      // Called by
      //   - frmDataBinding()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DataColumn dclMaster;
      DataColumn dclChild;
      DataRelation drDataRelation;
      DataTable dtEmployee;
      DataTable dtOrder;
      
      dtaEmployee.Fill(dsData, "tblCPEmployee");
      dtaOrder.Fill(dsData, "tblCPOrder");
      dtEmployee = dsData.Tables["tblCPEmployee"];
      dtOrder = dsData.Tables["tblCPOrder"];
      
      dclMaster = dsData.tblCPEmployee.intIdEmployeeColumn;
      // dclMaster = dsData.Tables["tblCPEmployee"].Columns["intIdEmployee"];
      dclChild = dsData.tblCPOrder.intEmployeeIdColumn;
      // dclChild = dsData.Tables["tblCPOrder"].Columns["intEmployeeId"];

      drDataRelation = new DataRelation("OrderEmployee", dclMaster, dclChild);
      dsData.Relations.Add(drDataRelation);
      cmbEmployee.DataSource = dtEmployee;
      cmbEmployee.DisplayMember = "strLastName";
      txtTitle.DataBindings.Add("Text", dtEmployee, "strTitle");
      txtIdEmployee.DataBindings.Add("Text", dtEmployee, "intIdEmployee");
      mdvDataView = new DataView(dtOrder);
    }
    // SetUpData()

    private void SetUpGrid()
      //***
      // Action
      //   - A rowfilter on the data view is triggered
      //     - Filter is the key of the employee
      //   - The data source of the data grid becomes the filtered data
      // Called by
      //   - frmDataBinding_Activated(System.Object, System.EventArgs) Handles MyBase.Activated
      //   - txtIdEmployee_TextChanged(System.Object, System.EventArgs) Handles txtIdEmployee.TextChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdvDataView.RowFilter = "intEmployeeId = " + txtIdEmployee.Text;
      dgrDataGrid.DataSource = mdvDataView;
    }
    // SetUpGrid()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataBinding

}
// CopyPaste.Learning