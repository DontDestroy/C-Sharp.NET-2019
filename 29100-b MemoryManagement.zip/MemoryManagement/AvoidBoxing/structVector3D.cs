﻿//***
// Action
//   - Definition of a cpVector3D
//     - There is a x, y and z coordinate
//     - There is a constructor
//     - There is a distance calculation between two cpVector3D
//     - There is a second distance calculation between two cpVector3D (in parameter)
//     - There is a calculation for the magnitude
// Created
//   - CopyPaste – 20260611 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260611 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections;
using System.Collections.Generic;

namespace CopyPaste.Learning
{

  public struct cpVector3D
  {

    #region "Constructors / Destructors"

    public cpVector3D(float xCoordinate, float yCoordinate, float zCoordinate)
    //***
    // Action
    //   - Basic constructor wiht 3 coordinates (x, y and z) --> 3 dimensions
    //   - The values are stored in the structure
    // Called by
    //   - float DemoDistance()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260611 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260611 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      xCoord = xCoordinate;
      yCoord = yCoordinate;
      zCoord = zCoordinate;
    }
    // cpVector3D(float, float, float)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private float xCoord;
    private float yCoord;
    private float zCoord;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static float Distance(cpVector3D cpFirst, cpVector3D cpSecond)
    //***
    // Action
    //   - Square the 3 coordinates
    //   - Add the three results
    //   - Take the squareroot of the result
    //   - The three arguments are defined as in, garanteeing that they will not be modified
    // Called by    
    //   - cpProgram.Main()
    //   - float cpDemoStruct.DemoDistance(cpVector3D, cpVector3D)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260611 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260611 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      float dx = cpSecond.xCoord - cpFirst.xCoord;
      float dy = cpSecond.yCoord - cpFirst.yCoord;
      float dz = cpSecond.zCoord - cpFirst.zCoord;

      return MathF.Sqrt(dx * dx + dy * dy + dz * dz);
    }
    // float Distance(cpVector3D, cpVector3D)

    public static float DistanceIn(in cpVector3D cpFirst, in cpVector3D cpSecond)
    //***
    // Action
    //   - Square the 3 coordinates
    //   - Add the three results
    //   - Take the squareroot of the result
    //   - The three arguments are defined as in, garanteeing that they will not be modified
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - float cpDemoStruct.DemoDistanceIn(cpVector3D, cpVector3D)
    // Created
    //   - CopyPaste – 20260611 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260611 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      float dx = cpSecond.xCoord - cpFirst.xCoord;
      float dy = cpSecond.yCoord - cpFirst.yCoord;
      float dz = cpSecond.zCoord - cpFirst.zCoord;

      return MathF.Sqrt(dx * dx + dy * dy + dz * dz);
    }
    // float Distance(cpVector3D, cpVector3D)

    public float Magnitude()
    //***
    // Action
    //   - Square the 3 coordinates
    //   - Add the three results
    //   - Take the squareroot of the result
    // Called by    
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260611 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260611 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return MathF.Sqrt(xCoord * xCoord + yCoord * yCoord + zCoord * zCoord);
    }
    // Magnitude()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpVector3D

}
// CopyPaste.Learning