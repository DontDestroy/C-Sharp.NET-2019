//***
// Action
//   - Testroutine for cpBook
// Created
//   - CopyPaste � 20230421 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230421 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;

namespace ConstructorOverload
{

  public class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    static void Main()
    //***
    // Action
    //   - Define three new cpBook using different constructors
    //   - Show the information on the screen of the three books
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpBook(string)
    //   - cpBook(string, string)
    //   - cpBook(string, string, string)
    //   - cpBook(string, string, string, double)
    //   - cpBook.ShowBook()
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpBook theBookA = new cpBook("Palm OS Developer's Guide");
      cpBook theBookB = new cpBook("Visual Basic .Net Programming Tips & Techniques", "Jamsa");
      cpBook theBookC = new cpBook("C# Programming Tips & Techniques", "Wright", "McGraw-Hill/Osborne");
      cpBook theBookD = new cpBook("HTML & Web Design Tips & Techniques", "King", "McGraw-Hill/Osborne", 49.99);

      theBookA.ShowBook();
      theBookB.ShowBook();
      theBookC.ShowBook();
      theBookD.ShowBook();
      Console.ReadLine();
    }
    // Main()
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// ConstructorOverload