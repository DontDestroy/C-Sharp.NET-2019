//***
// Action
//   - Show continent and country in 2 listboxes, with a splitter
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmContinentCountry: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.ListBox lstCountry;
    internal System.Windows.Forms.Splitter splVertical;
    internal System.Windows.Forms.ListBox lstContinent;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmContinentCountry));
      this.lstCountry = new System.Windows.Forms.ListBox();
      this.splVertical = new System.Windows.Forms.Splitter();
      this.lstContinent = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // lstCountry
      // 
      this.lstCountry.Dock = System.Windows.Forms.DockStyle.Fill;
      this.lstCountry.IntegralHeight = false;
      this.lstCountry.Location = new System.Drawing.Point(155, 0);
      this.lstCountry.Name = "lstCountry";
      this.lstCountry.Size = new System.Drawing.Size(477, 273);
      this.lstCountry.TabIndex = 5;
      // 
      // splVertical
      // 
      this.splVertical.Location = new System.Drawing.Point(152, 0);
      this.splVertical.Name = "splVertical";
      this.splVertical.Size = new System.Drawing.Size(3, 273);
      this.splVertical.TabIndex = 4;
      this.splVertical.TabStop = false;
      // 
      // lstContinent
      // 
      this.lstContinent.Dock = System.Windows.Forms.DockStyle.Left;
      this.lstContinent.IntegralHeight = false;
      this.lstContinent.Location = new System.Drawing.Point(0, 0);
      this.lstContinent.Name = "lstContinent";
      this.lstContinent.Size = new System.Drawing.Size(152, 273);
      this.lstContinent.TabIndex = 3;
      // 
      // frmContinentCountry
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(632, 273);
      this.Controls.Add(this.lstCountry);
      this.Controls.Add(this.splVertical);
      this.Controls.Add(this.lstContinent);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmContinentCountry";
      this.Text = "Continent Country";
      this.Load += new System.EventHandler(this.frmContinentCountry_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmContinentCountry'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmContinentCountry()
      //***
      // Action
      //   - Create instance of 'frmContinentCountry'
      // Called by
      //   - frmMain.cmdContinentCountry_Click(System.Object, System.EventArgs) Handles cmdContinentCountry.Click
      //   - User action (Starting the form)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmContinentCountry()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmContinentCountry_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create an instance of cpCountry
      //   - Create the country data set
      //   - Set the datasource of the continent list box to the country data set
      //   - Display the name of the continent in the list box
      //   - Set the datasource of the country list box to the country data set
      //   - Display the names of the countries in the list box that are of the chosen continent
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCountry()
      //   - thecpCountry.CreateCountryDataSet()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpCountry thecpCountry = new cpCountry();
      DataSet dsCountry = thecpCountry.CreateCountryDataSet();

      lstContinent.DataSource = dsCountry;
      lstContinent.DisplayMember = "Continent.strContinent";
      lstCountry.DataSource = dsCountry;
      lstCountry.DisplayMember = "Continent.CountryContinent.strCountry";
    }
    // frmContinentCountry_Load(System.Object, System.EventArgs) Handles MyBase.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmContinentCountry

}
// CopyPaste.Learning