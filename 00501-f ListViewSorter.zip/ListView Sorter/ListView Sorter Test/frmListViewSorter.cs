//***
// Action
//   - Test of sorting a list view
//   - cpListViewItemCompare is used clicking the header of a column
//   - cpctlListViewSorter is used clicking the buttons to sort a column
// Created
//   - CopyPaste � 20250722 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250722 � VVDW
// Proposal (To Do)
//   - Pay attention here
//     - The comparing when using the headers is not using data types (so alphabetically)
//     - The comparing when using hte buttons is using data types (so alphabetically or numeric)
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.UserInterface
{

  public class frmListViewSorter: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdBirthdateSort;
    internal System.Windows.Forms.Button cmdEmployeeNumberSort;
    internal System.Windows.Forms.Button cmdNameSort;
    internal System.Windows.Forms.ListView lsvListView;
    public System.Windows.Forms.ColumnHeader EmployeeName;
    internal System.Windows.Forms.ColumnHeader EmployeeNumber;
    internal System.Windows.Forms.ColumnHeader Birthdate;

    private void InitializeComponent()
    {
      System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {
                                                                                                             "Debra",
                                                                                                             "46",
                                                                                                             "10/09/1955"}, -1);
      System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem(new string[] {
                                                                                                             "Jeff",
                                                                                                             "34",
                                                                                                             "01/11/1967"}, -1);
      System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem(new string[] {
                                                                                                             "Julie",
                                                                                                             "32",
                                                                                                             "06/02/1969"}, -1);
      System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem(new string[] {
                                                                                                             "Mike",
                                                                                                             "47",
                                                                                                             "25/09/1954"}, -1);
      System.Windows.Forms.ListViewItem listViewItem5 = new System.Windows.Forms.ListViewItem(new string[] {
                                                                                                             "Tom",
                                                                                                             "50",
                                                                                                             "26/06/1951"}, -1);
      System.Configuration.AppSettingsReader configurationAppSettings = new System.Configuration.AppSettingsReader();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmListViewSorter));
      this.cmdBirthdateSort = new System.Windows.Forms.Button();
      this.cmdEmployeeNumberSort = new System.Windows.Forms.Button();
      this.cmdNameSort = new System.Windows.Forms.Button();
      this.lsvListView = new System.Windows.Forms.ListView();
      this.EmployeeName = new System.Windows.Forms.ColumnHeader();
      this.EmployeeNumber = new System.Windows.Forms.ColumnHeader();
      this.Birthdate = new System.Windows.Forms.ColumnHeader();
      this.SuspendLayout();
      // 
      // cmdBirthdateSort
      // 
      this.cmdBirthdateSort.Location = new System.Drawing.Point(248, 272);
      this.cmdBirthdateSort.Name = "cmdBirthdateSort";
      this.cmdBirthdateSort.Size = new System.Drawing.Size(88, 23);
      this.cmdBirthdateSort.TabIndex = 7;
      this.cmdBirthdateSort.Text = "Birthdate Sort";
      this.cmdBirthdateSort.Click += new System.EventHandler(this.cmdBirthdateSort_Click);
      // 
      // cmdEmployeeNumberSort
      // 
      this.cmdEmployeeNumberSort.Location = new System.Drawing.Point(128, 272);
      this.cmdEmployeeNumberSort.Name = "cmdEmployeeNumberSort";
      this.cmdEmployeeNumberSort.Size = new System.Drawing.Size(88, 23);
      this.cmdEmployeeNumberSort.TabIndex = 6;
      this.cmdEmployeeNumberSort.Text = "Number Sort";
      this.cmdEmployeeNumberSort.Click += new System.EventHandler(this.cmdEmployeeNumberSort_Click);
      // 
      // cmdNameSort
      // 
      this.cmdNameSort.Location = new System.Drawing.Point(8, 272);
      this.cmdNameSort.Name = "cmdNameSort";
      this.cmdNameSort.Size = new System.Drawing.Size(88, 23);
      this.cmdNameSort.TabIndex = 5;
      this.cmdNameSort.Text = "Name Sort";
      this.cmdNameSort.Click += new System.EventHandler(this.cmdNameSort_Click);
      // 
      // lsvListView
      // 
      this.lsvListView.CausesValidation = false;
      this.lsvListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
                                                                                  this.EmployeeName,
                                                                                  this.EmployeeNumber,
                                                                                  this.Birthdate});
      this.lsvListView.GridLines = true;
      this.lsvListView.HideSelection = false;
      this.lsvListView.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
                                                                                listViewItem1,
                                                                                listViewItem2,
                                                                                listViewItem3,
                                                                                listViewItem4,
                                                                                listViewItem5});
      this.lsvListView.Location = new System.Drawing.Point(8, 8);
      this.lsvListView.Name = "lsvListView";
      this.lsvListView.Size = new System.Drawing.Size(328, 248);
      this.lsvListView.TabIndex = 4;
      this.lsvListView.View = System.Windows.Forms.View.Details;
      this.lsvListView.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.lsvListView_ColumnClick);
      // 
      // EmployeeName
      // 
      this.EmployeeName.Text = ((string)(configurationAppSettings.GetValue("EmployeeName.Text", typeof(string))));
      this.EmployeeName.Width = 129;
      // 
      // EmployeeNumber
      // 
      this.EmployeeNumber.Text = ((string)(configurationAppSettings.GetValue("EmployeeNumber.Text", typeof(string))));
      this.EmployeeNumber.Width = 114;
      // 
      // Birthdate
      // 
      this.Birthdate.Text = ((string)(configurationAppSettings.GetValue("Birthdate.Text", typeof(string))));
      this.Birthdate.Width = 78;
      // 
      // frmListViewSorter
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(344, 302);
      this.Controls.Add(this.cmdBirthdateSort);
      this.Controls.Add(this.cmdEmployeeNumberSort);
      this.Controls.Add(this.cmdNameSort);
      this.Controls.Add(this.lsvListView);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmListViewSorter";
      this.Text = "ListView Sorter (Sorting with columnheaders and with buttons is different)";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmListViewSorter'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250722 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmListViewSorter()
      //***
      // Action
      //   - Create instance of 'frmListViewSorter'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250722 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmListViewSorter()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    cpctlListViewSorter mcpctlListViewSorter = new cpctlListViewSorter();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdBirthdateSort_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the list of the cpctlListViewSorter
      //   - Set the column of the cpctlListViewSorter
      //   - Set the data type of the cpctlListViewSorter
      //   - Execute the sort
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250722 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpctlListViewSorter.List = lsvListView;
      mcpctlListViewSorter.SortColumn = 2;
      mcpctlListViewSorter.SortType = Type.GetType("System.DateTime");
      lsvListView.Sort();
    }
    // cmdBirthdateSort_Click(System.Object, System.EventArgs) Handles cmdBirthdateSort.Click

    private void cmdNameSort_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the list of the cpctlListViewSorter
      //   - Set the column of the cpctlListViewSorter
      //   - Set the data type of the cpctlListViewSorter
      //   - Execute the sort
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250722 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpctlListViewSorter.List = lsvListView;
      mcpctlListViewSorter.SortColumn = 0;
      mcpctlListViewSorter.SortType = Type.GetType("System.String");
      lsvListView.Sort();
    }
    // cmdNameSort_Click(System.Object, System.EventArgs) Handles cmdNameSort.Click
    
    private void cmdEmployeeNumberSort_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the list of the cpctlListViewSorter
      //   - Set the column of the cpctlListViewSorter
      //   - Set the data type of the cpctlListViewSorter
      //   - Execute the sort
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250722 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpctlListViewSorter.List = lsvListView;
      mcpctlListViewSorter.SortColumn = 1;
      mcpctlListViewSorter.SortType = Type.GetType("System.Int32");
      lsvListView.Sort();
    }
    // cmdEmployeeNumberSort_Click(System.Object, System.EventArgs) Handles cmdEmployeeNumberSort.Click

    private void lsvListView_ColumnClick(System.Object theSender, System.Windows.Forms.ColumnClickEventArgs theColumnClickEventArguments)
      //***
      // Action
      //   - Set the sorter routine of the list view to cpListViewItemComparer
      //   - Execute the sort
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250722 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lsvListView.ListViewItemSorter = new cpListViewItemComparer(theColumnClickEventArguments.Column);
      lsvListView.Sort();
    }
    // lsvListView_ColumnClick(System.Object, System.Windows.Forms.ColumnClickEventArgs) Handles lsvListView.ColumnClick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmListViewSorter
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmListViewSorter()
      // Created
      //   - CopyPaste � 20250722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250722 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmListViewSorter());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmListViewSorter

}
// CopyPaste.Learning.UserInterface