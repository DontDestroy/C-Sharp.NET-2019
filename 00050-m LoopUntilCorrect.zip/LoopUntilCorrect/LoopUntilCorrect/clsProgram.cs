//***
// Action
//   - Reask a question till the input is correct
// Created
//   - CopyPaste � 20230808 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230808 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - As long as 'lngDataCount" is bigger than 0
      //     - Input a number
      //     - If it not a number, the exception is catched
      //     - If it is not bigger than 0, an exception is thrown
      //     - User can cancel the input
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngDataCount = -1;

      while (lngDataCount <= 0)
      {

        try
        {
          lngDataCount = Convert.ToInt32(Interaction.InputBox("Enter positive number of items.", "Copy Paste", "", 0, 0));

          if (lngDataCount > 0)
          {}
          else
            // lngDataCount <= 0
          {
            throw new Exception();
          }
          // lngDataCount > 0

        }
        catch
        {

          if (MessageBox.Show("Number must be a positive integer." + Environment.NewLine + Environment.NewLine + "Try again or cancel."
            , "Copy Paste", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning) == DialogResult.Cancel)
          {
            System.Environment.Exit(1);
          }
          else
            // Messagebox.Show(xxx) <> DialogResult.Cancel
          {
            lngDataCount = -1;
          }
          // Messagebox.Show(xxx) = DialogResult.Cancel
                  
        }

      };
      // ngDataCount > 0

    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// CopyPaste.Learning