﻿//***
// Action
//   - A definition of a DeadLock
// Created
//   - CopyPaste – 20251106 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251106 – VVDW
// Proposal (To Do)
//   -
//***

using ikvm.runtime;
using java.awt;
using java.awt.geom;
using java.lang;
using kareltherobot;
using sun.font;
using System.Security.Policy;
using static System.Net.Mime.MediaTypeNames;

namespace cpKarelTheRobot
{

	public class cpDeadLock : cpCopyPasteRobot, Runnable
	{

		#region "Constructors / Destructors"

		public cpDeadLock(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpDeadLock starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - A new thread of the cpDeadLock is defined
    //   - The thread is started
    // Called by
    //   - cpProgram.DeadLock()
    //   - cpDeadLock(int, int, Directions.Direction, int) 
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Thread theRobotRunnerThread = new Thread(this);

      theRobotRunnerThread.start();
    }
    // cpDeadLock(int, int, Directions.Direction, int, Color) 

    public cpDeadLock(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpDeadLock starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpDeadLock(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpDeadLock(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpDie theDie = new cpDie(6); // Randomizer

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void Eat(int time)
    //***
    // Action
    //   - To simulate a time to eat
    //   - Loop time (parameter) times
    //     - Robot moves forward
    //     - Robot goes one back
    // Called by
    //   - run()
    // Calls
    //   - cpCopyPasteRobot.GoOneBack()
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      for (int counter = 0; counter < time; counter++)
      {
        move();
        GoOneBack();
      }
      // counter = time

    }
    // Eat(int)


    private void GetForks()
    //***
    // Action
    //   - Turn left
    //   - Move one forward
    //   - As long there are no beepers in the bag
    //     - As long you are not next to a beeper
    //       - Do nothing
    //     - Pick beeper
    //   - Turn around
    //   - Move one forward
    //   - Put beeper
    //   - Move one forward
    //     - As long you are not next to a beeper
    //       - Do nothing
    //     - Pick beeper
    //   - Turn around
    //   - Move one forward
    //   - Put beeper
    //   - Turn right
    //   - Show the state that you are eating
    // Called by
    //   - run()
    // Calls
    //   - cpCopyPasteRobot.TurnAround()
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      turnLeft();
      move();

      while (!anyBeepersInBeeperBag())
      {

        while (!nextToABeeper())
        {
          // nothing
        }

        pickBeeper();
      }

      TurnAround();
      move();
      putBeeper();
      move();

      while (!anyBeepersInBeeperBag())
      {

        while (!nextToABeeper())
        {
          // nothing
        }

        pickBeeper();
      }

      TurnAround();
      move();
      putBeeper();
      TurnRight();
      showState("Eat ");
    }
    // GetForks()

    private void PutForks()
    //***
    // Action
    //   - Pick two beepers
    //   - Turn left
    //   - Move one forward
    //   - Put beeper
    //   - Turn around
    //   - Move two forward
    //   - Put beeper
    //   - Turn around
    //   - Move one forward
    //   - Turn right
    //   - Show the state that you are thinking
    // Called by
    //   - run()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      pickBeeper();
      pickBeeper();
      turnLeft();
      move();
      putBeeper();
      TurnAround();
      move();
      move();
      putBeeper();
      TurnAround();
      move();
      TurnRight();
      showState("Think ");
    }
    // PutForks()

    public override void run()
    //***
    // Action
    //   - Define what must be runned
    //   - Always continue with
    //   - Robot waits a random time
    //   - Robot picks up the two forks (beepers) next to him/her
    //     - Robot tries to pick up 1 fork (beeper) next to him/her
    //     - When the fork is occupied by another robot, the robot waits until the fork is put back
    //     - Then the other fork is picked up, also with waiting
    //   - Robot eats a random time
    //   - Robot puts down the two forks (beepers) next to him/her (one at the time)
    //     - It is possible that there is a dead lock
    //       - When everybody has one fork and everybody wants to start eating
    //         - You have a situation that is completely blocked
    // Called by
    //   - cpDeadLock(int, int, Directions.Direction, int, Color) 
    // Calls
    //   - Eat(int)
    //   - GetForks()
    //   - int cpDie.Roll()
    //   - PutForks()
    //   - Think(int)
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (true)
      {
        Think(theDie.Roll());
        GetForks();
        Eat(theDie.Roll());
        PutForks();
      }
      // true

    }
    // run()

    private void Think(int time)
    //***
    // Action
    //   - To simulate a time to think
    //   - Loop time (parameter) times
    //     - Robot goes one back
    //     - Robot moves forward
    // Called by
    //   - run()
    // Calls
    //   - cpCopyPasteRobot.GoOneBack()
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      for (int counter = 0; counter < time; counter++)
      {
        GoOneBack();
        move();
      }
      // counter = time

    }
    // Think(int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDeadLock

}
// cpKarelTheRobot