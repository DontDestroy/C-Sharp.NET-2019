//***
// Action
//   - Example of subroutines
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace ThreeSubs
{

  class cpThreeSubs
	{

    static void Main()
    //***
    // Action
    //   - Show variables at console screen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - OneValue(string)
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine()
    //   - ThreeValues(string, int, double)
    //   - TwoValues(int, string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      OneValue("Mr. Van De Walle");
      Console.WriteLine();
      TwoValues(52, "Mr. Van De Walle");
      Console.WriteLine();
      ThreeValues("Mr. Van De Walle", 52, 2500.0);
      Console.ReadLine();
    }
    // Main()

    static void OneValue(string strName)
    //***
    // Action
    //   - Show the result of one variable at the console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Hello, " + strName);
    }
    // OneValue(string)

    static void TwoValues(int intAge, string strName)
    //***
    // Action
    //   - Show the result of two variables at the console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Age: " + intAge);
      Console.WriteLine("Name: " + strName);
    }
    // TwoValues(int, string)

    static void ThreeValues(string strName, int intAge, double dblSalary)
    //***
    // Action
    //   - Show the result of three variables at the console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Name: " + strName);
      Console.WriteLine("Age: " + intAge);
      Console.WriteLine("Salary: " + dblSalary);
    }
    // ThreeValues(string, int, double)

  }
  // cpThreeSubs

}
// ThreeSubs