//***
// Action
//   - Loop thru the 4 icons that are on the same file location as the application
// Created
//   - CopyPaste � 20230807 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230807 � VVDW
// Proposal (To Do)
//   - There is a better solution to do this, use resources, but this exercise is a demo of a loop
//   - Application fails if the icons are not in the current location
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmLoopIcons : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    internal System.Windows.Forms.Button cmdShow;
    internal System.Windows.Forms.PictureBox picIcon;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.cmdShow = new System.Windows.Forms.Button();
      this.picIcon = new System.Windows.Forms.PictureBox();
      this.SuspendLayout();
      // 
      // cmdShow
      // 
      this.cmdShow.Location = new System.Drawing.Point(76, 158);
      this.cmdShow.Name = "cmdShow";
      this.cmdShow.Size = new System.Drawing.Size(104, 32);
      this.cmdShow.TabIndex = 3;
      this.cmdShow.Text = "&Show";
      this.cmdShow.Click += new System.EventHandler(this.cmdShow_Click);
      // 
      // picIcon
      // 
      this.picIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.picIcon.Location = new System.Drawing.Point(76, 30);
      this.picIcon.Name = "picIcon";
      this.picIcon.Size = new System.Drawing.Size(104, 96);
      this.picIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picIcon.TabIndex = 2;
      this.picIcon.TabStop = false;
      // 
      // frmLoopIcons
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(256, 221);
      this.Controls.Add(this.cmdShow);
      this.Controls.Add(this.picIcon);
      this.Name = "frmLoopIcons";
      this.Text = "For ... Next";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmLoopIcons'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmLoopIcons()
      //***
      // Action
      //   - Create instance of 'frmLoopIcons'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmLoopIcons()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdShow_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Loop from 1 till 4
      //     - Find a file with a specific name on the current path
      //     - Show that icon on the screen
      //     - If you are not on the last icon
      //       - Show a button to go to the next icon
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int intCounter;

      for (intCounter = 1; intCounter <= 4; intCounter++)
      {
        picIcon.Image = Image.FromFile(Environment.CurrentDirectory + "\\face0" + intCounter + ".ico");
    
        if (intCounter == 4)
        {
        }
        else
          // intCounter <> 4
        {
          MessageBox.Show("Next", "Copy Paste");
        }
        // intCounter = 4

      }
      // intCounter = 5
    }
    // cmdShow_Click(System.Object, System.EventArgs) Handles cmdShow.Click
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmLoopIcons
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmLoopIcons());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmLoopIcons

}
// CopyPaste.Learning