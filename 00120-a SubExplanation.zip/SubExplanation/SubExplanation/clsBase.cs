//***
// Action
//   - Definition of a base class cpBase
// Created
//   - CopyPaste � 20240617 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240617 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpBase
  {

    #region "Constructors / Destructors"

    public cpBase()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpDerived()
      //   - cpProgram.Main() 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpBase()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    internal void SubInternal()
      //***
      // Action
      //   - Internal SubRoutine
      //   - Internal elements are accessible from within the program
      //     that contains their declaration and from anywhere else 
      //     in the same assembly
      // Called by
      //   - cpProgram.Main()
      //   - SubTestBase()
      //   - SubTestDerived()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Sub Internal");
    }
    // SubInternal()

    private void SubPrivate()
      //***
      // Action
      //   - Private SubRoutine
      //   - Private elements are accessible only from within their
      //     declaration context, including from members of any nested types,
      //     for example from within a nested procedure or from
      //     an assignment expression in a nested enumeration
      // Called by
      //   - cpProgram.Main()
      //   - SubTestBase()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Sub Private");
    }
    // SubPrivate()

    protected void SubProtected()
      //***
      // Action
      //   - Protected SubRoutine
      //   - Protected elements are accessible only from within their
      //     own class or from a derived class
      //   - Protected access is not a superset of friend access
      // Called by
      //   - cpProgram.Main()
      //   - SubTestBase()
      //   - SubTestDerived()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Sub Protected");
    }
    // SubProtected()

    protected internal void SubProtectedInternal()
      //***
      // Action
      //   - Protected Friend SubRoutine
      //   - This combination confers both friend and protected access
      //     on the declared elements, so they are accessible from
      //     the same assembly, from their own class,
      //     and from any derived classes
      // Called by
      //   - cpProgram.Main()
      //   - SubTestBase()
      //   - SubTestDerived()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Sub Protected Internal");
    }
    // SubProtectedInternal()

    public void SubPublic()
      //***
      // Action
      //   - Public SubRoutine
      //   - There are no restrictions on the accessibility of public elements
      // Called by
      //   - cpProgram.Main()
      //   - SubTestBase()
      //   - SubTestDerived()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Sub Public");
    }
    // SubPublic()

    public void SubTestBase()
      //***
      // Action
      //   - Test base subroutines
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - SubInternal()
      //   - SubPrivate()
      //   - SubProtected()
      //   - SubProtectedInternal()
      //   - SubPublic()
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      SubInternal();
      SubPrivate();
      SubProtected();
      SubProtectedInternal();
      SubPublic();
    }
    // SubTestBase()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBase

}
// CopyPaste.Learning