﻿//***
// Action
//   - Routines for generating random data in the forward engineered database
// Created
//   - CopyPaste – 20230712 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230712 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.BusinessObjects;
using CopyPaste.DataAccess;
using CopyPaste.Toolkit;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace ForwardEngineerDatabase
{
  public class cpDataGeneration
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    static string[] arrstrAirports =
      {"Berlin", "Brussels", "Chicago", "Dallas", "Frankfurt", "Hamburg", "Kaapstad", "London", "Madrid", "Milan", "Moscow", "Munich", "New York", "Paris", "Prague", "Rome", "Seattle", "Vienna" };
    static string[] arrstrFirstNames =
      {"Alois", "Ann", "Anna", "Astrid", "August", "Bernadette", "Dries", "Ellen", "Elvire", "Ernest", "Gertrude", "Hannah", "Hilde", "Jan", "Jowan", "Leon", "Liesbeth", "Lukas", "Marie", "Martijn", "Roberto", "Roger", "Vincent"};
    static string[] arrstrFirstNameForPilots =
      {"Angela", "Bianca", "Christian", "Christine", "Frank", "Gregor", "Julia", "Martin", "Stella"};
    static string[] arrstrLastNames =
      {"Aerts", "Bertrand", "Claes", "Claeys", "De Clercq", "De Smet", "De Vos", "Deprez", "Desmet", "Devos", "Dubois", "Dupont", "Goossens", "Hendrickx", "Hermans", "Jacobs", "Janssen", "Janssens", "Lambert", "Maes", "Martens", "Mertens", "Michiels", "Pauwels", "Peeters", "Smets", "Stevens", "Van Damme", "Vermeulen", "Willems", "Wouters", "Wuyts" };
    static string[] arrstrLastNameForPilots =
      {"Bogaerts", "Carlier", "Fontaine", "Jansen", "Michel", "Noël", "Van De Walle", "Van Dyck", "Willaert"};
    static Random theRandom = new Random(DateTime.Now.Millisecond);

    const int intNumberOfFlights = 100;
    const int intNumberOfPilots = 20;
    const int intNumberOfPassengers = 5000;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void CreateBookings(cpWingsContext theDatabaseContext)
    //***
    // Action
    //   - Create a list of random Bookings
    //   - Create a list of all existing flights
    //   - Create a list of all existing passengers
    //   - Loop thru all the flights
    //     - Calculate how many seats that are occupied (theAmount)
    //     - Assign the next 'theAmount' passengers to that flight by creating a booking for that flight
    //     - Show every 997 an added booking
    //   - Save all changes
    // Called by
    //   - CreateTestData(cpWingsContext)
    // Calls
    //   - Booking()
    //   - Booking.Flight(Flight) (Set)
    //   - Booking.Passenger(Passenger) (Set)
    //   - cpConsole.PrintSuccess(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DbSet<Booking> cpWingsContext.Booking (Get)
    //   - DbSet<Flight> cpWingsContext.Flight (Get)
    //   - DbSet<Passenger> cpWingsContext.Passenger (Get)
    //   - short Flight.Seats (Get)
    //   - short Flight.FreeSeats (Get)
    //   - string Flight.ToString()
    //   - string Passenger.FullName (Get)
    // Created
    //   - CopyPaste – 20230712 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230712 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intCountBookings = 0;
      int intLoopPassengers;
      int intOccupiedSeats;
      int intCountPassengers;

      IQueryable<Flight> lstFlights =
        from Flight in theDatabaseContext.Flight
        select Flight;
      IQueryable<Passenger> lstPassengers =
        from Passenger in theDatabaseContext.Passenger
        select Passenger;
      Passenger[] arrPassengers = lstPassengers.ToArray();

      cpConsole.PrintWithTime("Start Booking Generation ...");
      intCountPassengers = arrPassengers.Count();

      foreach (Flight theFligth in lstFlights)
      {
        intOccupiedSeats = theFligth.Seats - theFligth.FreeSeats;
        
        for (int intCounter = 0; intCounter < intOccupiedSeats; intCounter++)
        {
          Booking newBooking = new Booking();

          intLoopPassengers = intCountBookings % intCountPassengers;
          intCountBookings++;

          newBooking.Flight = theFligth;
          newBooking.Passenger = arrPassengers[intLoopPassengers];
          theDatabaseContext.Booking.Add(newBooking);

          if (intCountBookings % 997 == 0)
          {
            cpConsole.PrintSuccess("Added booking (one of 997): for " + newBooking.Passenger.FullName + " " + newBooking.Flight.ToString());
          }
          else
          // (intCounter % 997 <> 0)
          {
          }
          // (intCounter % 997 = 0)

        }
        // intCounter = intOccupiedSeats

      }
      // in lstFlights

      theDatabaseContext.SaveChanges();
      cpConsole.PrintWithTime("... Booking Generation Finished");
    }
    // CreateBookings(cpWingsContext)

    public static void CreateFlights(cpWingsContext theDatabaseContext)
    //***
    // Action
    //   - Create a list of random Flights
    //   - Create a list of all existing pilots
    //   - Loop intNumberOfFlights times
    //     - Create a new flight
    //     - Give some information to the fligth
    //       - An unique number
    //       - A different departure and destination
    //       - Number of seats, free seats, date and pilot
    //     - Add pilot to the list of pilots in the context
    //     - Show every 10 an added flight
    //   - Save all changes
    // Called by
    //   - CreateTestData(cpWingsContext)
    // Calls
    //   - cpConsole.PrintSuccess(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DbSet<Flight> cpWingsContext.Flight (Get)
    //   - Flight()
    //   - Flight.Date(DateTime) (Set)
    //   - Flight.Departure(string) (Set)
    //   - Flight.Destination(string) (Set)
    //   - Flight.FlightNo(int) (Set)
    //   - Flight.FreeSeats(short) (Set)
    //   - Flight.Pilot(Pilot) (Set)
    //   - Flight.Seats(short) (Set)
    //   - string Flight.ToString()
    // Created
    //   - CopyPaste – 20230712 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230712 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intLengthOfAirports = arrstrAirports.Length - 1;
      Pilot[] arrPilots = theDatabaseContext.Pilot.ToArray();
      int intLengthOfPilots = arrPilots.Length - 1;
      string strDeparture;
      string strDestination;

      cpConsole.PrintWithTime("Start Flight Generation ...");

      for (int intCounter = 0; intCounter < intNumberOfFlights; intCounter++)
      {
        Flight newFlight = new Flight();

        newFlight.FlightNo = intCounter;
        strDeparture = arrstrAirports[theRandom.Next(0, intLengthOfAirports)];
        strDestination = strDeparture;

        while (strDestination == strDeparture)
        {
          strDestination = arrstrAirports[theRandom.Next(0, intLengthOfAirports)];
        }
        // strDestination <> strDeparture

        newFlight.Departure = strDeparture;
        newFlight.Destination = strDestination;
        newFlight.Seats = 250;
        newFlight.FreeSeats = Convert.ToInt16(theRandom.Next(0, 50));
        newFlight.Date = DateTime.Now.AddDays(theRandom.Next(300)).AddMinutes(theRandom.Next(10000));
        newFlight.Pilot = arrPilots[theRandom.Next(0, intLengthOfPilots)];
        theDatabaseContext.Flight.Add(newFlight);

        if (intCounter % 10 == 0)
        {
          cpConsole.PrintSuccess("Added flight (one of 10): " + newFlight.ToString());
        }
        else
        // (intCounter % 10 <> 0)
        {
        }
        // (intCounter % 10 = 0)

      }
      // intCounter = intNumberOfFlights

      theDatabaseContext.SaveChanges();
      cpConsole.PrintWithTime("... Flight Generation Finished");
    }
    // CreateFlights(cpWingsContext)

    public static void CreatePassengers(cpWingsContext theDatabaseContext)
    //***
    // Action
    //   - Create a list of random names
    //   - Loop intNumberOfPassengers times
    //     - Create a new Passenger
    //     - Give some information to the Passenger (name, birthday, status, ...)
    //     - Add Passenger to the list of passengers in the context
    //     - Show every 500 an added passenger
    //   - Save all changes
    // Called by
    //   - CreateTestData(cpWingsContext)
    // Calls
    //   - cpConsole.PrintSuccess(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DbSet<Passenger> cpWingsContext.Passenger (Get)
    //   - Passenger()
    //   - Passenger.BirthDay(DateTime) (Set)
    //   - Passenger.GivenName(string) (Set)
    //   - Passenger.Status(string) (Set)
    //   - Passenger.Surname(string) (Set)
    //   - string Passenger.FullName (Get)
    // Created
    //   - CopyPaste – 20230712 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230712 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strFirstName;
      string strLastName;
      int intLengthOfPassengerFirstNames = arrstrFirstNames.Length - 1;
      int intLengthOfPassengerLastNames = arrstrLastNames.Length - 1;

      cpConsole.PrintWithTime("Start Passenger Generation ...");

      for (int intCounter = 0; intCounter < intNumberOfPassengers; intCounter++)
      {
        Passenger newPassenger = new Passenger();

        strFirstName = arrstrFirstNames[theRandom.Next(0, intLengthOfPassengerFirstNames)];
        strLastName = arrstrLastNames[theRandom.Next(0, intLengthOfPassengerLastNames)];

        newPassenger.GivenName = strFirstName;
        newPassenger.Surname = strLastName;
        newPassenger.BirthDay = new DateTime(1960, 1, 1).AddDays(theRandom.Next(20000));
        newPassenger.Status = "A";
        theDatabaseContext.Passenger.Add(newPassenger);

        if (intCounter % 500 == 0)
        {
          cpConsole.PrintSuccess("Added passenger (one of 500): " + newPassenger.FullName);
        }
        else
        // (intCounter % 500 <> 0)
        {
        }
        // (intCounter % 500 = 0)

      }
      // intCounter = intNumberOfPassengerss

      theDatabaseContext.SaveChanges();
      cpConsole.PrintWithTime("... Passenger Generation Finished");
    }
    // CreatePassenger(cpWingsContext)

    public static void CreatePilots(cpWingsContext theDatabaseContext)
    //***
    // Action
    //   - Create a list of random names
    //   - Loop intNumberOfPilots times
    //     - Create a new Pilot
    //     - Give some information to the Pilot (name, salary, birthday, ...)
    //     - Add Pilot to the list of pilots in the context
    //     - Show the added pilot
    //   - Save all changes
    // Called by
    //   - CreateTestData(cpWingsContext)
    // Calls
    //   - cpConsole.PrintSuccess(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DbSet<Pilot> cpWingsContext.Pilot (Get)
    //   - Pilot()
    //   - Pilot.BirthDay(DateTime) (Set)
    //   - Pilot.GivenName(string) (Set)
    //   - Pilot.Salary(float) (Set)
    //   - Pilot.Surname(string) (Set)
    //   - string Pilot.FullName (Get)
    // Created
    //   - CopyPaste – 20230712 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230712 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strFirstName;
      string strLastName;
      int intLengthOfPilotFirstNames = arrstrFirstNameForPilots.Length - 1;
      int intLengthOfPilotLastNames = arrstrLastNameForPilots.Length - 1;

      cpConsole.PrintWithTime("Start Pilot Generation ...");

      for (int intCounter = 0; intCounter < intNumberOfPilots; intCounter++)
      {
        Pilot newPilot = new Pilot();

        strFirstName = arrstrFirstNameForPilots[theRandom.Next(0, intLengthOfPilotFirstNames)];
        strLastName = arrstrLastNameForPilots[theRandom.Next(0, intLengthOfPilotLastNames)];

        newPilot.GivenName = strFirstName;
        newPilot.Surname = strLastName;
        newPilot.Salary = 5000;
        newPilot.BirthDay = new DateTime(1955, 1, 1).AddDays(theRandom.Next(15000));
        theDatabaseContext.Pilot.Add(newPilot);
                
        cpConsole.PrintSuccess("Added pilot: " + newPilot.FullName);
      }
      // intCounter = intNumberOfPilots

      theDatabaseContext.SaveChanges();
      cpConsole.PrintWithTime("... Pilot Generation Finished");
    }
    // CreatePilots(cpWingsContext)

    public static void CreateTestData(cpWingsContext theDatabaseContext)
    //***
    // Action
    //   - Create a list of random pilots
    // Called by
    //   - Main()
    // Calls
    //   - cpConsole.PrintMainHeadLine(string)
    //   - CreateBookings(cpWingsContext)
    //   - CreateFlights(cpWingsContext)
    //   - CreatePassengers(cpWingsContext)
    //   - CreatePilots(cpWingsContext)
    // Created
    //   - CopyPaste – 20230712 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230712 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpConsole.PrintMainHeadLine("Start Data Generation ...");
      CreatePilots(theDatabaseContext);
      CreatePassengers(theDatabaseContext);
      CreateFlights(theDatabaseContext);
      CreateBookings(theDatabaseContext);
      cpConsole.PrintMainHeadLine("... Data Generation Finished");
    }
    // CreateTestData(cpWingsContext)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDataGeneration

}
// ForwardEngineerDatabase