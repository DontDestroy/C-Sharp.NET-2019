//***
// Action
//   - Testroutine of the clsEmployee
// Created
//   - CopyPaste � 20230419 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230419 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Define a new cpEmployee with basic constructor
    //   - Define a new cpEmployee with constructor and parameters
    //   - Show the information on the screen of the first cpEmployee
    //   - Show the information on the screen of the second cpEmployee
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpEmployee()
    //   - cpEmployee(string, aSex, DateTime)
    // Created
    //   - CopyPaste � 20230419 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230419 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpEmployee thecpEmployee01 = new cpEmployee();
      cpEmployee thecpEmployee02 = new cpEmployee("Vincent", cpEmployee.aSex.Male, new DateTime(2001, 1, 1));
      thecpEmployee01.ShowInfo();
      Console.WriteLine();
      thecpEmployee02.ShowInfo();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// CopyPaste.Learning