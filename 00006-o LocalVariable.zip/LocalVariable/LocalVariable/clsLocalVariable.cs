//***
// Action
//   - Working with local variables
// Created
//   - CopyPaste � 20220112 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220112 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace LocalVariable
{

  class cpLocalVariable
	{

    static void BookInfo()
    //***
    // Action
    //   - Set some variables
    //   - Show values at console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220112 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220112 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      double dblPrice = 49.99;
      long lngNumber = 0;
      string strName = "C# .NET Programming Tips & Techniques";
      
      Console.WriteLine("In BookInfo");
      Console.WriteLine("Name: " + strName);
      Console.WriteLine("Price: " + dblPrice);
      Console.WriteLine("Number: " + lngNumber);
    }
    // BookInfo()

    static void Main()
    //***
    // Action
    //   - Call sub routines
    // Called by
    //   - User action
    // Calls
    //   - BookInfo()
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine()
    //   - YahooInfo()
    // Created
    //   - CopyPaste � 20220112 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220112 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      YahooInfo();
      Console.WriteLine();
      BookInfo();
      Console.ReadLine();
    }
    // Main()

    static void YahooInfo()
    //'***
    //' Action
    //'   - Set some variables (the same as in BookInfo)
    //'   - Show values at console screen
    //' Called by
    //'   - Main()
    //' Calls
    //'   - System.Console.WriteLine(string)
    //' Created
    //'   - CopyPaste � 20220112 � VVDW
    //' Changed
    //'   - CopyPaste � yyyymmdd � VVDW � What changed
    //' Tested
    //'   - CopyPaste � 20220112 � VVDW
    //' Keyboard key
    //'   -
    //' Proposal (To Do)
    //'   -
    //'***
    {
      double dblPrice = 17.45;
      long lngNumber = 1001;
      string strName = "Yahoo";

      Console.WriteLine("In YahooInfo");
      Console.WriteLine("Name: " + strName);
      Console.WriteLine("Price: " + dblPrice);
      Console.WriteLine("Number: " + lngNumber);
    }
    // YahooInfo()

  }
  // cpLocalVariable

}
// LocalVariable