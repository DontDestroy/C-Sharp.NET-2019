﻿//***
// Action
//   - Implementation of a ExtraTurnLeftBlockStrategy
// Created
//   - CopyPaste – 20251028 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251028 – VVDW
// Proposal (To Do)
//   -
//***

using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpExtraTurnLeftBlockStrategy : cpinfStrategy
	{

    #region "Constructors / Destructors"

    public cpExtraTurnLeftBlockStrategy(cpinfStrategy theDecorated)
    //***
    // Action
    //   - Constructor of the start situation
    //   - A given cpinfStrategy is the input
    // Called by
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theInternalDecorated = theDecorated;
    }
    // cpExtraTurnLeftBlockStrategy(cpinfStrategy)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpinfStrategy theInternalDecorated = new cpNullStrategy();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void DoIt(cpCopyPasteRobot aRobot)
    //***
    // Action
    //   - Implementation of DoIt
    //     - Extra turn left (the decoration)
    //     - Do the action for the decorated (which is unknown here)
    // Called by
    //   - 
    // Calls
    //   - cpinfStrategy.DoIt(cpCopyPasteRobot)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      aRobot.turnLeft();
      theInternalDecorated.DoIt(aRobot);
    }
    // DoIt(cpCopyPasteRobot)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpExtraTurnLeftBlockStrategy

}
// cpKarelTheRobot