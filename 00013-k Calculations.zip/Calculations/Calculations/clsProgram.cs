//***
// Action
//   - Some basic calculation
// Created
//   - CopyPaste � 20240119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240119 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Calculations
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Do some calculations
      //   - Write results at console screen
      //   - Write results of comparisons at console screen
      //   - Wait for user interaction
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - string System.Console.ReadLine()
      //   - System.Console.WriteLine()
      //   - System.Console.WriteLine(string, int)
      //   - System.Console.WriteLine(single)
      //   - System.Console.WriteLine(boolean)
      //   - long System.Convert.ToInt64(int)
      // Created
      //   - CopyPaste � 20240119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240119 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      long lngAccountNumber;
      long lngFirstTen;
      long lngLastTwo;

      lngAccountNumber = Convert.ToInt64(63154756360);
      lngFirstTen = lngAccountNumber / 100;
      lngLastTwo = lngAccountNumber % 100;
      Console.WriteLine("BankAccount check: {0}", lngFirstTen % 97);
      Console.WriteLine("BankAccount last 2: {0}", lngLastTwo);
      Console.WriteLine();

      const float fltCmInch = 2.54F;
      float fltDistance = 100000.0F;
      float fltDistanceInInch;
      
      fltDistanceInInch = fltDistance / fltCmInch;
      Console.WriteLine("{0} cm / {1} = {2} inch", fltDistance, fltCmInch, fltDistanceInInch);
      Console.WriteLine();
      
      Console.WriteLine("4 = 3 -> {0}", 4 == 3);
      Console.WriteLine("4.2 <> 4 -> {0}", 4.2 != 4);
      Console.WriteLine("#8/31/2001# > #8/30/2001#", new DateTime(2001, 8, 31) > new DateTime(2001, 8, 30));
      Console.WriteLine("A < C -> {0}", 'A' < '0');
      Console.WriteLine();

      bool blnMarried = true;

      Console.WriteLine("Not blnMarried -> {0}", !blnMarried);
      Console.WriteLine("4 < 3 And 1 > 2 -> {0}", 4 < 3 & 1 > 2);
      Console.WriteLine("4 < 3 AndAlso 1 > 2 -> {0}", 4 < 3 && 1 > 2);
      Console.WriteLine("4 > 3 Or 1 > 2 -> {0}", 4 > 3 | 1 > 2);
      Console.WriteLine("4 > 3 OrElse 1 > 2 -> {0}", 4 > 3 || 1 > 2);
      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// Calculations