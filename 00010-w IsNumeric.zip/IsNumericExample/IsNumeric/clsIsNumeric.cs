//***
// Action
//   - Example of IsNumeric function
//   - In C# this function does not exist, so you must get it from somewhere else
//   - or create it by yourself
//   - The goal is to give a demo, not to explain how it is done
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;

namespace IsNumericExample
{

  class cpIsNumeric
	{

    static void Main()
    //***
    // Action
    //   - Ask for a number (strNumber)
    //   - Check if 'strNumber' is numeric
    // Called by
    //   - User action (Starting the application)
    // Calls
    //'   - bool Microsoft.VisualBasic.Information.IsNumeric(string)
    //'   - double System.Convert.ToDouble(String)
    //'   - double System.Math.Ceiling(Double)
    //'   - MsgBoxResult Microsoft.VisualBasic.Interaction MsgBox(string, MsgBoxStyle, object) 
    //'   - string Microsoft.VisualBasic.Interaction.InputBox(string, string, string, int, int)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      string strNumber;

      strNumber = Interaction.InputBox("Give me a decimal number", "Copy Paste", "0", 0, 0);

      if (Information.IsNumeric(strNumber))
      {
        Interaction.MsgBox("Ceiling of " + strNumber + " is " + Math.Ceiling(Convert.ToDouble(strNumber)), 0, "");
      }
      else
        // Not (Information.IsNumeric(strNumber))
      {
        Interaction.MsgBox(strNumber + " is not a number", 0, "");
      }
      // (Information.IsNumeric(strNumber))

    }
    // Main()

  }
  // cpIsNumeric

}
// IsNumeric