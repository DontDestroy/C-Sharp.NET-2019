﻿//***
// Action
//   - Having a command towards a database
//   - Using the SqlCommand to submit queries, with and without parameters
//     - ExecuteScalar
//     - ExecuteScalar with Parameter
//     - Insert
//     - Insert with Parameter
//     - Output Parameter
//     - Transaction Processing
//   - Interaction logic for MainWindow.xaml
// Created
//   - CopyPaste – 20210809 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210809 – VVDW
// Proposal(To Do)
//   - List of actions that can be added to the functionality
//***

using System.Windows;
using WPFCommand.cpUserControl;

namespace WPFCommand
{

  public partial class MainWindow : Window
  {

  #region "Constructors / Destructors"

    public MainWindow()
    //***
    // Action
    //   - Creating an instance of the WPF form
    //   - Initialize the components of that form
    // Called by
    //   - User Action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // MainWindow()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void mnuCommand_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action()
    //   - Clear the content of grdContentArea
    //   - Set grdContentArea to a new instance of ctrlCommand
    // Called by
    //   - User Action(Clicking on a menu item)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard Key
    //   - 
    // Proposal(To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      grdContentArea.Children.Clear();
      grdContentArea.Children.Add(new ctrlCommand());
    }
    // mnuCommand_Click(System.Object, System.Windows.RoutedEventArgs)

    private void mnuExit_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action()
    //       - Closing the application
    // Called by
    //   - User Action(Clicking on a menu item)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard Key
    //   - 
    // Proposal(To Do)
    //   - List of actions that can be added to the functionality
    //***

    {
      this.Close();
    }
    // mnuExit_Click(System.Object, System.Windows.RoutedEventArgs)

    private void mnuFile_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action()
    //   -
    // Called by
    //   - User Action(Clicking on a menu item)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard Key
    //   - 
    // Proposal(To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

    }
    // mnuFile_Click(System.Object, System.Windows.RoutedEventArgs)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

  }
  // MainWindow 

}
// WPFCommand