//***
// Action
//   - A window that will be created several times from the startup screen
// Created
//   - CopyPaste � 20220817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220817 � VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace WindowTrackerEventsDelegates
{

  public partial class wpfWindow : Window
  {

    #region "Constructors / Destructors"

    public wpfWindow()
    //***
    // Action
    //   - Create instance of 'wpfWindow'
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfWindow()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public event cpwpfWindowRoutedEventHandler ActionWithWindow;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate void cpwpfWindowRoutedEventHandler(System.Object theSender, cpwpfWindowRoutedEventArguments thewpfWindowRoutedEventArguments);

    #endregion

    #region "Sub / Function"

    public void SomeActionsOnTheWindow(string strTitle, string strContent)
    //***
    // Action
    //   - Change the content of the Window thru event
    // Called by
    //   - cmdUpdate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdUpdate.Click
    // Calls
    //   - cpwpfWindowRoutedEventArguments(string, string)
    //   - cpwpfWindowRoutedEventHandler ActionWithWindow
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpwpfWindowRoutedEventArguments thewpfWindowRoutedEventArguments = new cpwpfWindowRoutedEventArguments(strTitle, strContent);

      ActionWithWindow.Invoke(this, thewpfWindowRoutedEventArguments);
      
      // Alterative
      // ActionWithWindow(this, thewpfWindowRoutedEventArguments);
    }
    // SomeActionsOnTheWindow(string, string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfWindow

}
// WindowTrackerEventsDelegates