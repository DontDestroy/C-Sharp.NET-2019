//***
// Action
//   - Reading information in a data set and update it towards the database
// Created
//   - CopyPaste � 20251125 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251125 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Try to
      //     - Define a counter
      //     - Define a connection string
      //     - Create the connection
      //     - Open the connection
      //     - Show some info about the connection
      //     - Create a command string (select all employees)
      //     - Create a data set
      //     - Create a data adapter (the sql statement with the connection)
      //     - Create a command building (using the data adapter)
      //     - Fill the data set
      //     - Loop thru the rows
      //       - Change the second column into upper
      //       - To put back the original info, uncomment the code here
      //     - Set the update command in the data adapter
      //     - Update the only table that there is
      //     - Show that the update is complete
      //     - Wait for user action
      //   - When there are problems
      //     - Show the error information
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251125 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251125 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - The code changes the data
      //   - Uncomment the code to set the data back to the original
      //***
    {

      try
      {
        string strConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integrated Security=True";
        SqlConnection theConnection = new SqlConnection(strConnectionString);

        theConnection.Open();
        Console.WriteLine("Database: " + theConnection.Database);
        Console.WriteLine("Server Version: " + theConnection.ServerVersion);
        Console.WriteLine("Data Source: " + theConnection.DataSource);
        Console.WriteLine();

        string theCommand = "SELECT * From tblCPEmployee";
        DataSet theDataSet = new DataSet();
        SqlDataAdapter theDataAdapter = new SqlDataAdapter(theCommand, theConnection);
        SqlCommandBuilder theCommandBuilder = new SqlCommandBuilder(theDataAdapter);

        theDataAdapter.Fill(theDataSet);

        for (int lngCounter = 0; lngCounter < theDataSet.Tables[0].Rows.Count; lngCounter++)
        {
          theDataSet.Tables[0].Rows[lngCounter][1] = Convert.ToString(theDataSet.Tables[0].Rows[lngCounter][1]).ToUpper();
        }
        // lngCounter = theDataSet.Tables(0).Rows.Count

        // for (int lngCounter = 0; lngCounter < theDataSet.Tables[0].Rows.Count; lngCounter++)
        // {
        //   string strHelp;
        // 
        //   strHelp = Convert.ToString(theDataSet.Tables[0].Rows[lngCounter][1]).ToLower();
        //   strHelp = strHelp.Substring(0, 1).ToUpper() + strHelp.Substring(1);
        //   theDataSet.Tables[0].Rows[lngCounter][1] = strHelp;
        // }
        // // theDataSet.Tables(0).Rows.Count

        theDataAdapter.UpdateCommand = theCommandBuilder.GetUpdateCommand();
        theDataAdapter.Update(theDataSet.Tables[0]);
        Console.WriteLine("Update Complete");

        Console.ReadLine();
      }
      catch (Exception theException)
      {
        Console.WriteLine("Exception: " + theException.Message);
        Console.WriteLine(theException.ToString());
        Console.ReadLine();
      }
      finally
      {
      }

    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning