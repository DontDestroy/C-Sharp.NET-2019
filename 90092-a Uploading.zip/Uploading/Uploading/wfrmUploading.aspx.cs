﻿//***
// Action
//   - Loading an image into a webpage
// Created
//   - CopyPaste – 20260723 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260723 – VVDW
// Proposal (To Do)
//   - You need to give access to the save path by security
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmUploading: System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cmdUpload.Click += new System.EventHandler(this.cmdUpload_Click);
      this.ID = "wfrmUploading";
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when initializing the page
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260723 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260723 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdUpload_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Take the filename from the file field and show it on the form
    //   - Set the path for a gif file (with a thumbnail)
    //   - Set the path for a jpeg file (without a thumbnail)
    //   - Depending on the content type
    //     - On gif file
    //       - Save the selected gif file towards the path of gif
    //       - Create a thumbnail of half the size
    //       - Show successful on the screen
    //     - On jpeg file
    //       - Save the selected jpeg file towards the path of jpeg
    //       - Show successful on the screen
    //     - On something else
    //       - Show unsuccessful on the screen by given the wrong data type
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - ThumbNailAbort() As Boolean
    // Created
    //   - CopyPaste – 20051123 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20051123 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***      
    {
      string strPhotoGif;
      string strPhotoJpg;
      string strPhotoThumbNail;
      string strValue;

      strValue = ffdUploadFile.Value;
      strValue = strValue.Substring(strValue.LastIndexOf("\\") + 1);
      strValue = strValue.Substring(0, strValue.LastIndexOf("."));
      txtName.Text = strValue;

      strPhotoGif = Server.MapPath("Photo\\") + txtName.Text + ".gif";
      strPhotoJpg = Server.MapPath("Photo\\") + txtName.Text + ".jpg";
      strPhotoThumbNail = Server.MapPath("Photo\\") + txtName.Text + "Thumb.gif";

      switch (ffdUploadFile.PostedFile.ContentType)
      {
        case "image/gif":
          ffdUploadFile.PostedFile.SaveAs(strPhotoGif);

          Bitmap bitPhoto = new Bitmap(strPhotoGif, true);
          System.Drawing.Image.GetThumbnailImageAbort theCallback = new System.Drawing.Image.GetThumbnailImageAbort(ThumbNailAbort);
          Bitmap bitThumbNail = new Bitmap(bitPhoto.GetThumbnailImage(bitPhoto.Width / 2, bitPhoto.Height / 2, theCallback, IntPtr.Zero));

          bitThumbNail.Save(strPhotoThumbNail, System.Drawing.Imaging.ImageFormat.Gif);
          lblInfo.Text = "Successful";
          break;
        case "image/jpeg":
          ffdUploadFile.PostedFile.SaveAs(strPhotoJpg);
          lblInfo.Text = "Successful";
          break;
        default:
          lblInfo.Text = "Unsuccessful. Wrong data type: " + ffdUploadFile.PostedFile.ContentType;
          break;
      }
      // ffdUploadFile.PostedFile.ContentType

    }
    // cmdUpload_Click(System.Object, System.EventArgs) Handles cmdUpload.Click

    protected void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when loading the page
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260723 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260723 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    #region "Event"

    private bool ThumbNailAbort()
    //***
    // Action
    //   - Action executed when there was an abort on the save of the thumbnail
    // Called by
    //   - cmdUpload_Click(System.Object, System.EventArgs) Handles cmdUpload.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260723 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260723 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return false;
    }
    // bool ThumbNailAbort()

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmUploading

}
// CopyPaste.Learning