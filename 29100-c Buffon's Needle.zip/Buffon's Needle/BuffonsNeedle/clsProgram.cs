﻿//***
// Action
//   - Calculate an estimation of Pi by using the Buffons Needle algorithm
//   - Look on the website for the explanation of Buffons Needle
// Created
//   - CopyPaste – 20260811 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260811 – VVDW
// Proposal (To Do)
//   - We decided to calculate the crossing of a line with the cosinus
//   - In most documentations the middle of the needle is taken and then a calculation with 1/2 sin(angle)
//   - We used the top of the needle and a cosinus of the angle to calculated if there is a crossing
//***

using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260811 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260811 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    const int intAngleCount = 36_000;
    private static double[] dblarrcosTable = new double[intAngleCount];
    private static double dblValue;
    private static uint uintSeed = (uint)DateTime.Now.Ticks;
    private static ulong ulngBits;
    private static ulong ulngProduct;
    private static ulong ulngSeed = (ulong)DateTime.Now.Ticks;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private static void DisplayInfo(long lngDrops, long lngHits)
    //***
    // Action
    //   - Showing the calculation of the estimation of PI
    //   - Pi becomes two times the number of drops divided by the number of hits (crossing a line)
    //   - Console is cleared
    //   - Number of drops is shown
    //   - Number of hits is shown
    //   - Estimation of PI is shown
    //   - The delta of the real PI is shown
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260811 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260811 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      double dblPi;

      dblPi = 2.0D * lngDrops / lngHits;
      Console.Clear();
      Console.WriteLine("Drops :  {0}", lngDrops.ToString("N0"));
      Console.WriteLine("Hits  :  {0}", lngHits.ToString("N0"));
      Console.WriteLine("Pi    :  {0}", dblPi);
      Console.WriteLine("Pi dt  :  {0:#,##0.0000000000}", Math.Abs(dblPi - Math.PI));
    }
    // DisplayInfo(long, long)

    private static void FillCosTable()
    //***
    // Action
    //   - 36_000 cosinus angles were calculated in advance and placed in a table
    //   - This is faster than calculate the cosinus 500_000_000 times
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260811 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260811 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      const double dblStep = 2.0 * Math.PI / intAngleCount;
      int intCounter;

      for (intCounter = 0; intCounter < intAngleCount; intCounter++)
      {
        dblarrcosTable[intCounter] = Math.Cos(intCounter * dblStep);
      }
      // intCounter = intAngleCount

    }
    // FillCosTable()

    static void Main()
    //***
    // Action
    //   - Set the number of drops to a half billion (miljard)
    //   - Decide that there will be 5 displays
    //   - Calculate how many calculations there will in one display
    //   - Start a stopwatch
    //   - Fill the table of all cosinus calculations
    //   - Loop thru the number of displays
    //     - Calculate the from till to
    //     - Loop thru from till to
    //       - Commented out the calculations with Random() (too slow)
    //       - Get a random double (to have the top of the position where the needle fell)
    //       - Get a random integer (to have the angle of the needle)
    //       - Calculation the position of the end of the needle to see if it crosses a line
    //       - If calculation is <= 0 or >= 1 (then is crosses a line)
    //         - Increment number of hits
    //     - Display the current information
    //   - Stop the stopwatch
    //   - Show the elapsed seconds
    //   - Wait for user interaction
    // Called by
    //   - 
    // Calls
    //   - DisplayInfo(long, long)
    //   - double NextDoubleRandomPersonal() (Commented)
    //   - FillCosTable()
    //   - int NextIntegerRandomPersonal() (Commented)
    // Created
    //   - CopyPaste – 20260811 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260811 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Code in comment is informative
    //     - Compare the functionality using Random()
    //***
    {
      const long lngAmountOfDrops = 500_000_000;
      double dblAngle;
      double dblX1;
      double dblX2;
      int intAngle;
      long lngDrops;
      long lngHits;
      long lngNumberOfDisplays = 5;
      long lngDisplayInfo = lngAmountOfDrops / lngNumberOfDisplays;
      long lngStartDrop;
      long lngEndDrop;

      Stopwatch swWatch = new Stopwatch();
      swWatch.Start();
      FillCosTable();

      lngHits = 0;

      for (long lngDisplayLoop = 0; lngDisplayLoop < lngNumberOfDisplays; lngDisplayLoop++)
      {
        lngStartDrop = lngDisplayInfo * lngDisplayLoop;
        lngEndDrop = lngStartDrop + lngDisplayInfo;

        for (lngDrops = lngStartDrop; lngDrops < lngEndDrop; lngDrops++)
        {
          // Random theRandom = new Random();
          // double dblTwoPI = 2.0D * Math.PI;

          // dblX1 = theRandom.NextDouble();
          // dblAngle = theRandom.NextDouble() * dblTwoPI;

          // VVDW - Solution with methods --> Methods are slower than copied code below
          // dblX1 = NextRandomPersonal();
          // dblAngle = NextDoubleRandomPersonal() * dblTwoPI;
          // intAngle = NextIntegerRandomPersonal();

          // VVDW - Attempt to kill Random() :-)
          ulngSeed ^= ulngSeed << 13;
          ulngSeed ^= ulngSeed >> 7;
          ulngSeed ^= ulngSeed << 17;
          ulngBits = 0x3FF0000000000000UL | (ulngSeed & 0x000FFFFFFFFFFFFFUL);
          dblValue = Unsafe.As<ulong, double>(ref ulngBits);
          dblX1 = dblValue - 1.0D;

          uintSeed ^= uintSeed << 13;
          uintSeed ^= uintSeed >> 17;
          uintSeed ^= uintSeed << 5;
          ulngProduct = (ulong)uintSeed * intAngleCount;
          // VVDW - The biggest number you can get is intAngleCount - 1
          intAngle = (int)(ulngProduct >> 32);

          dblX2 = dblX1 + dblarrcosTable[intAngle];

          if (dblX2 <= 0 || dblX2 >= 1)
          {
            lngHits++;
          }
          else
          // dblX2 > 0 And dblX2 < 1
          {
          }
          // dblX2 <= 0 Or dblX2 >= 1

        }
        // lngDrops = lngEndDrop

        DisplayInfo(lngDrops, lngHits);
      }
      // lngDisplayLoop = lngNumberOfDisplays

      swWatch.Stop();

      Console.WriteLine("Elapsed : {0} seconds", swWatch.ElapsedMilliseconds / 1000D);
      Console.ReadKey();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    #region "Not used"

    private static double NextDoubleRandomPersonal()
    //***
    // Action
    //   - Not used in the actual code
    //   - Method to get a double random without using Random()
    //   - Code is copied into the Main()
    //   - Rest is documented inside the code
    // Called by
    //   - Main() (Commented)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260811 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260811 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - You could get rid of the -1
    //***
    {
      // VVDW - Source Donald E. Knuth --> The art of Programming (Volume 2)
      // VVDW - This is the code I've used to dismiss random()
      // VVDW - I did not use a method, because using methods is slower
      // VVDW - I've copied the code

      // 1.Xorshift64 integer generation(1 or 2 CPU cycles)
      ulngSeed ^= ulngSeed << 13;
      ulngSeed ^= ulngSeed >> 7;
      ulngSeed ^= ulngSeed << 17;

      // 2. Bit manipulation trick to format a double between 1.0 and 2.0
      // 0x3FF0000000000000UL is the raw bit representation of 1.0 as a double
      // 0x000FFFFFFFFFFFFFUL masks out exactly 52 bits for the mantissa (decimal part)
      ulngBits = 0x3FF0000000000000UL | (ulngSeed & 0x000FFFFFFFFFFFFFUL);

      // 3. Reinterpret ulong bits directly as double without conversion overhead
      // VVDW - This line was found using AI (ChatGPT)
      dblValue = Unsafe.As<ulong, double>(ref ulngBits);

      // 4. Subtract 1.0 to shift the final range to [0.0, 1.0)
      return dblValue - 1.0D;
    }
    // double NextDoubleRandomPersonal()

    private static int NextIntegerRandomPersonal()
    //***
    // Action
    //   - Not used in the actual code
    //   - Method to get a integer random without using Random()
    //   - Code is copied into the Main()
    //   - Rest is documented inside the code
    // Called by
    //   - Main() (Commented)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260811 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260811 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      // VVDW - Source Donald E. Knuth --> The art of Programming (Volume 2)
      // VVDW - This is the code I've used to dismiss random()
      // VVDW - I did not use a method, because using methods is slower
      // VVDW - I've copied the code

      // 1.Xorshift64 integer generation(1 or 2 CPU cycles)
      uintSeed ^= uintSeed << 13;
      uintSeed ^= uintSeed >> 17;
      uintSeed ^= uintSeed << 5;

      // 2. Lemire's Fast Range Reduction (No division, 1 or 2 CPU cycles)
      // Widening to 64-bit ulong prevents arithmetic overflow during multiplication
      ulngProduct = uintSeed * intAngleCount;

      // 3. Shift right by 32 bits to divide by 2^32, leaving the high 32 bits
      return (int)(ulngProduct >> 32);
    }
    // int NextIntegerRandomPersonal()

    #endregion

  }
  // cpProgram

}
// CopyPaste.Learning