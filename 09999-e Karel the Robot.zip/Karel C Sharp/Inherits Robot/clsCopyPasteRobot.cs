﻿//***
// Action
//   - A definition of a CopyPasteRobot
// Created
//   - CopyPaste – 20251014 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251014 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpCopyPasteRobot : kareltherobot.Robot
	{

    #region "Constructors / Destructors"

    public cpCopyPasteRobot() : base(1, 1, Directions.East, 0, Color.green)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a green cpCopyPasteRobot starting at position (1, 1), looking to the right with 0 beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpLeftTurnController()
    //   - cpRightTurnController()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpCopyPasteRobot() 

    public cpCopyPasteRobot(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpCopyPasteRobot starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpAbstractBeeperLayer(int, int, Directions.Direction, int, Color)
    //   - cpAccompliceRobot(int, int, Directions.Direction, int, Color, cpinfStrategy) 
    //   - cpBeeperFinder(int, int, Directions.Direction, int, Color) 
    //   - cpBlockWalker(int, int, Directions.Direction, int, Color)
    //   - cpCalculator(int, int, Directions.Direction, int, Color) 
    //   - cpCarpenter(int, int, Directions.Direction, int, Color) 
    //   - cpCarrier(int, int, Directions.Direction, int, Color)
    //   - cpChecker(int, int, Directions.Direction, int, Color)
    //   - cpContractor(int, int, Directions.Direction, int, Color)
    //   - cpControllerStrategyVersion01(int, int, Directions.Direction, int, Color, cpinfStrategy) 
    //   - cpControllerStrategyVersion02(int, int, Directions.Direction, int, Color, cpinfStrategy) 
    //   - cpCopyPasteRobot() 
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int)
    //   - cpDeadLock(int, int, Directions.Direction, int, Color)
    //   - cpGetter(int, int, Directions.Direction, int, Color) 
    //   - cpGuardAField(int, int, Directions.Direction, int, Color) 
    //   - cpLeftTurnController(cpCopyPasteRobot)
    //   - cpLeftTurnControllerInside(cpCopyPasteRobot)
    //   - cpMason(int, int, Directions.Direction, int, Color) 
    //   - cpMoveTwoBlocksListener(int, int, Directions.Direction, int, Color) 
    //   - cpNeighbourTalker(int, int, Directions.Direction, int, Color, cpinfBeeperPutter) 
    //   - cpObservablePicker(int, int, Directions.Direction, int, Color)
    //   - cpPutter(int, int, Directions.Direction, int, Color) 
    //   - cpProgram.SearchBeeper()
    //   - cpRecursionFindBeeper(int, int, Directions.Direction, int, Color)
    //   - cpRelayRacer(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersTillWall(int, int, Directions.Direction, int, Color) 
    //   - cpRemoveBeepersTillWallError01(int, int, Directions.Direction, int, Color) 
    //   - cpRemoveBeepersTillWallError02(int, int, Directions.Direction, int, Color) 
    //   - cpReplanter(int, int, Directions.Direction, int, Color)
    //   - cpRightTurnController(cpCopyPasteRobot)
    //   - cpRightTurnControllerInside(cpCopyPasteRobot)
    //   - cpRoofer(int, int, Directions.Direction, int, Color) 
    //   - cpSpyRobot(int, int, Directions.Direction, int, Color, cpinfStrategy)
    //   - cpThiefRobotFail(int, int, Directions.Direction, int, Color) 
    //   - cpThreadCarpenter(int, int, Directions.Direction, int, Color) 
    //   - cpThreadContractor(int, int, Directions.Direction, int, Color)
    //   - cpThreadMason(int, int, Directions.Direction, int, Color)
    //   - cpThreadRobot(int, int, Directions.Direction, int, Color) 
    //   - cpThreadRobotFail(int, int, Directions.Direction, int, Color) 
    //   - cpThreadRoofer(int, int, Directions.Direction, int, Color) 
    //   - cpTwoMeterHurdlesRace(int, int, Directions.Direction, int, Color)
    //   - cpWhile(int, int, Directions.Direction, int, Color)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
		// cpCopyPasteRobot(int, int, Directions.Direction, int, Color) 

		public cpCopyPasteRobot(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Robot becomes a cpCopyPasteRobot starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
		//   - Nothing else happens
		// Called by
		//   - 
		// Calls
		//   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
		// Created
		//   - CopyPaste – 20251014 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251014 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
		}
		// cpCopyPasteRobot(int, int, Directions.Direction, int) 

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		private void CollectAllBeepersInFront()
		//***
		// Action
		//   - Define a variable that robot can continue
		//   - As long robot is not blocked and can continue
		//   - Move one forward (first beeper must stay)
		//   - Move to a beeper (in the direction you are looking)
		//   - If found
		//     - Pick beeper
		//     - Turn around
		//     - Go to wall
		//     - Turn around
		//     - Put beeper
		//   - If not
		//     - Turn around
		//     - Go to wall
		//     - Turn around
		//     - Robot can't continue and must stop
		// Called by
		//   -
		// Calls
		//   - GoAsFarAsPossible()
		//   - MoveToBeeper()
		//   - TurnAround()
		// Created
		//   - CopyPaste – 20251014 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251014 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			bool robotCanContinue = true;

			while (frontIsClear() && robotCanContinue)
			{
				move();
				MoveToBeeper();

				if (nextToABeeper())
				{
					pickBeeper();
					TurnAround();
					GoAsFarAsPossible();
					TurnAround();
					putBeeper();
				}
				else
        // Not nextToABeeper()
        {
          TurnAround();
					GoAsFarAsPossible();
					TurnAround();
					robotCanContinue = false;
				}
        // nextToABeeper()

      }
      // frontIsClear() && robotCanContinue

    }
    // CollectAllBeepersInFront()

    private void DiagonalLeft()
    //***
    // Action
    //   - Ends up looking in the same direction
    //     - At the same location if all moves are blocked
    //     - At the position left if first move is blocked
    //     - At the position forward is second move is blocked
    //     - At the position diagonal left if none is blocked
    //   - This can be used for
    //     - Looking to the South and front is clear, to find the South wall
    //   - Move forward if possible
    //   - Turn to the left
    //   - Move forward if possible
    //   - Turn to the right
    // Called by
    //   - MoveDiagonalLeft()
    // Calls
    //   - MoveIfPossible()
    //   - TurnRight()
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      MoveIfPossible();
      turnLeft();
      MoveIfPossible();
      TurnRight();
    }
    // DiagonalLeft()

    public void DiagonalRight()
    //***
    // Action
    //   - Ends up looking in the same direction
    //     - At the same location if all moves are blocked
    //     - At the position right if first move is blocked
    //     - At the position forward is second move is blocked
    //     - At the position diagonal right if none is blocked
    //   - This can be used for
    //     - Looking to the West and front is clear, to find the West wall
    //   - Move forward if possible
    //   - Turn to the right
    //   - Move forward if possible
    //   - Turn to the left
    // Called by
    //   - cpRoofer.BuildRoof()
    //   - cpThreadRoofer.BuildRoof()
    //   - MoveDiagonalRight()
    // Calls
    //   - MoveIfPossible()
    //   - TurnRight()
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      MoveIfPossible();
      TurnRight();
      MoveIfPossible();
      turnLeft();
    }
    // DiagonalRight()

    private void EmptyBeeperBag()
    //***
    // Action
    //   - As long there are beepers in the bag
    //     - Put them down
    //   - Attention: Infinite loop when there are an infinite number of beepers in the bag
    // Called by
    //   -
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (anyBeepersInBeeperBag())
      {
        putBeeper();
      }
      // anyBeepersInBeeperBag()

    }
    // EmptyBeeperBag()

    private void EmptyBeeperBagInARow()
    //***
    // Action
    //   - As long there are beepers in the bag
    //     - Put one down
    //     - Move forward if possible
    //   - Attention: When facing a wall all beepers in the bag will be put on a pile
    //   - Attention: Infinite loop when there are an infinite number of beepers in the bag
    // Called by
    //   -
    // Calls
    //   - MoveIfPossible();
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (anyBeepersInBeeperBag())
      {
        putBeeper();
        MoveIfPossible();
      }
      // anyBeepersInBeeperBag()

    }
    // EmptyBeeperBagInARow()

    public void FaceEast()
    //***
    // Action
    //   - Repeat till facing East
    //     - Turn left
    // Called by
    //   - cpGuardAField.MoveToSouthEastCorner()
    //   - cpCarpenter.BuildDoor()
    //   - cpRoofer.BuildRoof()
    //   - cpThreadCarpenter.BuildDoor()
    //   - cpThreadRoofer.BuildRoof()
    //   - FillRoomWithBeepers()
    //   - GoToStartPosition()
    //   - GoToNextDiagonalAwayFromWalls()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (!facingEast())
      {
        turnLeft();
      }
      // Not facingEast()

    }
    // FaceEast()

    public void FaceNorth()
    //***
    // Action
    //   - Repeat till facing North
    //     - Turn left
    // Called by
    //   - cpCalculator.TurnHelpersOff()
    //   - cpGuardAField.MoveToSouthEastCorner()
    //   - cpCarpenter.BuildDoor()
    //   - cpCarpenter.BuildWindow()
    //   - cpCarpenter.GoToStartFirstWindow()
    //   - cpCarpenter.GoToStartSecondWindow()
    //   - cpMason.BuildWall()
    //   - cpProgram.Calculator()
    //   - cpRoofer.BuildRoof()
    //   - cpRoofer.GoToStartRoof()
    //   - cpThreadCarpenter.BuildDoor()
    //   - cpThreadCarpenter.BuildWindow()
    //   - cpThreadCarpenter.GoToStartFirstWindow()
    //   - cpThreadCarpenter.GoToStartSecondWindow()
    //   - cpThreadMason.BuildWall()
    //   - cpThreadRoofer.BuildRoof()
    //   - FillRoomWithBeepers()
    //   - GoToNextDiagonalAwayFromWalls()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (!facingNorth())
      {
        turnLeft();
      }
      // Not facingNorth()

    }
    // FaceNorth()

    public void FaceSouth()
    //***
    // Action
    //   - Repeat till facing South
    //     - Turn left
    // Called by
    //   - cpCarpenter.BuildDoor()
    //   - cpGuardAField.MoveToSouthEastCorner()
    //   - cpThreadCarpenter.BuildDoor()
    //   - GoToStartPosition()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (!facingSouth())
      {
        turnLeft();
      }
      // Not facingSouth()

    }
    // FaceSouth()

    private void FaceWest()
    //***
    // Action
    //   - Repeat till facing West
    //     - Turn left
    // Called by
    //   - FillRoomWithBeepers()
    //   - GoToStartPosition()
    //   - SearchBeeperSomewhereInWorld()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (!facingWest())
      {
        turnLeft();
      }
      // Not facingWest()

    }
    // FaceWest()

    private void FillRoomWithBeepers()
    //***
    // Action
    //   - Fill street with beepers
    //   - Face to the North
    //   - As long robot can
    //     - Move one forward
    //     - Determine the looking direction
    //       - If right is blocked
    //         - Look to the West
    //       - If not
    //         - Look to the East
    //     - Fill street with beepers
    //   - Face to the North
    // Called by
    //   - 
    // Calls
    //   - bool RightIsBlocked()
    //   - FaceEast()
    //   - FaceNorth()
    //   - FaceWest()
    //   - FillStreetWithBeepers()
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FillStreetWithBeepers();
      FaceNorth();

      while (frontIsClear())
      {
        move();

        if (RightIsBlocked())
        {
          FaceWest();
        }
        // Not RightIsBlocked()
        else
        {
          FaceEast();
        }
        // RightIsBlocked()

        FillStreetWithBeepers();
        FaceNorth();
      }
      // frontIsClear()

    }
    // FillRoomWithBeepers()

    private void FillStreetWithBeepers()
    //***
    // Action
    //   - Put a beeper
    //   - Repeat till facing wall
    //     - Move one forward
    //     - Put a beeper
    // Called by
    //   - FillRoomWithBeepers()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      putBeeper();

      while (frontIsClear())
      {
        move();
        putBeeper();
      }
      // frontIsClear()

    }
    // FillStreetWithBeepers()

    private bool FrontIsBlocked()
    //***
    // Action
    //   - Negate frontIsClear
    // Called by
    //   - SolveMazeLeft()
    //   - SolveMazeRight()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return !frontIsClear();
    }
    // bool FrontIsBlocked()

    public void GoAsFarAsPossible()
    //***
    // Action
    //   - As long robot is not blocked
    //     - Move one forward
    // Called by
    //   - CollectAllBeepersInFront()
    //   - GoToStartPosition()
    //   - PickAllBeepersInFrontAndGoToBottom()
    //   - PickAllBeepersXHighAndGoToBottom(int)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (frontIsClear())
			{
				move();
			}
      // frontIsClear()

    }
    // GoAsFarAsPossible()

    public void GoOneBack()
    //***
    // Action
    //   - Turn around
    //   - Move one forward
    //   - Turn around
    // Called by
    //   - cpDeadLock.Eat(int)
    //   - cpDeadLock.Think(int)
    // Calls
    //   - TurnAround()
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      TurnAround();
      move();
      TurnAround();
    }
    // GoOneBack()

    private void GoToNextDiagonalAwayFromWalls()
    //***
    // Action
    //   - If robot looks to the West
    //     - Face to the North
    //   - If not
    //     - Face to the East
    //   - Move one forward
    //   - Turn around
    // Called by
    //   - MoveDiagonalLeft()
    //   - MoveDiagonalRight()
    // Calls
    //   - FaceEast()
    //   - FaceNorth()
    //   - TurnAround()
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (facingWest())
      {
        FaceNorth();
      }
      else
      // Not facingWest()
      {
        FaceEast();
      }
      // facingWest()

      move();  
      TurnAround();
    }
    // GoToNextDiagonalAwayFromWalls()

    public void GoToStartPosition()
    //***
    // Action
    //   - Look to the South
    //   -  Go as far as possible
    //   -  Look to the West
    //   - Go as far as possible
    //   - Look to the East
    // Called by
    //   - cpCalculator.TurnHelpersOff()
    //   - cpContractor.GatherTeam()
    //   - cpProgram.Calculator()
    //   - cpProgram.Decorator()
    //   - cpProgram.Enumeration()
    //   - cpBeeperFinder.RetrieveBeeper()
    //   - cpMason.GetToWork()
    //   - cpRecursionFindBeeper.RetrieveTreasure()
    //   - cpRoofer.GetToWork()
    //   - cpThreadContractor.BuildHouse()
    //   - cpThreadContractor.CarpenterTask()
    //   - PickAllBeepersInFrontAndGoToOrigin()
    //   - SearchBeeperSomewhereInWorld()
    // Calls
    //   - FaceEast()
    //   - FaceSouth()
    //   - FaceWest()
    //   - GoAsFarAsPossible()
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FaceSouth();
      GoAsFarAsPossible();
      FaceWest();
      GoAsFarAsPossible();
      FaceEast();
    }
    // GoToStartPosition()

    private bool LeftIsBlocked()
    //***
    // Action
    //   - Negate LeftIsClear
    // Called by
    //   - bool LeftIsClear()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return !LeftIsClear();
    }
    // bool LeftIsBlocked()

    private bool LeftIsClear()
    //***
    // Action
    //   - Turn left
    //   - Remember if front is clear into blnResult
    //   - Turn right
    //   - Return blnResult
    // Called by
    //   - bool LeftIsBlocked()
    // Calls
    //   - TurnRight()
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnResult;

      turnLeft();
      blnResult = frontIsClear();
      TurnRight();
      return blnResult;
    }
    // bool LeftIsClear()

    private void MoveDiagonalLeft()
    //***
    // Action
    //   - If front is clear
    //     - Move diagonal one to the left
    //   - If not
    //     - Start a new diagonal movement
    // Called by
    //   - SearchBeeperSomewhereInWorld()
    // Calls
    //   - DiagonalLeft()
    //   - GoToNextDiagonalAwayFromWalls()
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (frontIsClear())
      {
        DiagonalLeft();
      }
      else
      // Not frontIsClear()
      {
        GoToNextDiagonalAwayFromWalls();
      }
      // frontIsClear()

    }
    // MoveDiagonalLeft()

    private void MoveDiagonalRight()
    //***
    // Action
    //   - If front is clear
    //     - Move diagonal one to the right
    //   - If not
    //     - Start a new diagonal movement
    // Called by
    //   - SearchBeeperSomewhereInWorld()
    // Calls
    //   - DiagonalRight()
    //   - GoToNextDiagonalAwayFromWalls()
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (frontIsClear())
      {
        DiagonalRight();
      }
      else
      // Not frontIsClear()
      {
        GoToNextDiagonalAwayFromWalls();
      }
      // frontIsClear()

    }
    // MoveDiagonalRight()

    private void MoveIfPossible()
    //***
    // Action
    //   - If front is clear
    //     - Move on forward
    //   - If not
    //     - Do nothing
    // Called by
    //   - DiagonalLeft()
    //   - DiagonalRight()
    //   - EmptyBeeperBagInARow()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (frontIsClear())
      {
        move();
      }
      // frontIsClear()

    }
    // MoveIfPossible()

    public void MoveToBeeper()
    //***
    // Action
    //   - Move to beeper in front
    //   - As long robot is not next to a beeper and has a clear front
    //     - Move one forward
    // Called by
    //   - CollectAllBeepersInFront()
    //   - cpThreadRobot.run()
    //   - cpThreadRobotFail.run()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (!nextToABeeper() && frontIsClear())
			{
				move();
			}
      // Not nextToABeeper() && frontIsClear()

    }
    // MoveToBeeper()

    private void MoveToNoBeeper()
    //***
    // Action
    //   - Move to first corner with no beeper in front
    //   - As long robot is next to a beeper and has a clear front
    //     - Move one forward
    // Called by
    //   -
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (nextToABeeper() && frontIsClear())
      {
        move();
      }
      // nextToABeeper() && frontIsClear()

    }
    // MoveToNoBeeper()

    public void MoveToRobot()
    //***
    // Action
    //   - Move to robot in front
    //   - As long robot is not next to another robot and has a clear front
    //     - Move one forward
    // Called by
    //   - cpCalculator.GatherHelpers()
    //   - cpRelayRacer.run()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (!nextToARobot() && frontIsClear())
      {
        move();
      }
      // Not nextToARobot() && frontIsClear()

    }
    // MoveToRobot()

    public void PickAllBeepers()
    //***
    // Action
    //   - All beepers at current position will be picked
    // Called by
    //   - cpGetter.move()
    // Calls
    //   - cpRemoveAllBeepersTillWall.RemoveAllBeepersTillWall()
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (nextToABeeper())
      {
        pickBeeper();
      }
      // nextToABeeper()

    }
    // PickAllBeepers()

    private void PickAllBeepersInFront()
    //***
    // Action
    //   - As long robot is on a beeper
    //     - Pick beeper
    //   - If last was picked
    //     - Move one forward
    // Called by
    //   - PickAllBeepersInFrontAndGoToBottom()
    //   - PickAllBeepersInFrontAndGoToOrigin()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251102 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251102 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (nextToABeeper())
      {
        pickBeeper();

        if (nextToABeeper())
        {
        }
        else
        // Not nextToABeeper()
        {
          move();
        }
        // nextToABeeper()

      }
      // nextToABeeper()

    }
    // PickAllBeepersInFront()

    public void PickAllBeepersInFrontAndGoToBottom()
    //***
    // Action
    //   - Pick all beepers in front
    //   - Turn around
    //   - Go back to wall
    //   - Turn around
    // Called by
    //   - cpCalculator.AddColumn()
    //   - cpCalculator.SlideAll()
    // Calls
    //   - GoAsFarAsPossible()
    //   - PickAllBeepersInFront()
    //   - TurnAround()
    // Created
    //   - CopyPaste – 20251102 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251102 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      PickAllBeepersInFront();
      TurnAround();
      GoAsFarAsPossible();
      TurnAround();
    }
    // PickAllBeepersInFrontAndGoToBottom()

    private void PickAllBeepersInFrontAndGoToOrigin()
    //***
    // Action
    //   - Pick all beepers in front
    //   - Go back to origin
    // Called by
    //   - 
    // Calls
    //   - GoToStartPosition()
    //   - PickAllBeepersInFront()
    // Created
    //   - CopyPaste – 20251103 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251103 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      PickAllBeepersInFront();
      GoToStartPosition();
    }
    // PickAllBeepersInFrontAndGoToOrigin()

    private void PickAllBeepersInFrontTillWall()
    //***
    // Action
    //   - As long robot is not blocked by a wall
    //     - Pick beeper if present
    //     - Move one forward
    //   - Pick beeper if present
    // Called by
    //   - 
    // Calls
    //   - PickBeeperIfPresent()
    // Created
    //   - CopyPaste – 20251102 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251102 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (frontIsClear())
      {
        PickBeeperIfPresent();
        move();
      }
      // frontIsClear()

      PickBeeperIfPresent();
    }
    // PickAllBeepersInFrontAndGoToBottom()

    private void PickAllBeepersXHighAndGoToBottom(int theNumberOfStreets)
    //***
    // Action
    //   - Pick all beepers in front (theNumberOfStreets high)
    //   - Turn around
    //   - Go back to wall
    //   - Turn around
    // Called by
    //   - 
    // Calls
    //   - GoAsFarAsPossible()
    //   - TurnAround()
    // Created
    //   - CopyPaste – 20251102 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251102 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      for (int counter = 0; counter < theNumberOfStreets; counter++)
      {

        while (nextToABeeper())
        {
          pickBeeper();
        }
        // nextToABeeper()

        move();
      }
      // counter = theNumberOfStreets

      TurnAround();
      GoAsFarAsPossible();
      TurnAround();
    }
    // PickAllBeepersXHighAndGoToBottom(int)

    private void PickBeeperIfPresent()
    //***
    // Action
    //   - Pick the beeper at the position (if there is one)
    // Called by
    //   - PickAllBeepersInFrontAndGoToBottom()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251102 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251102 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (nextToABeeper())
      {
        pickBeeper();
      }
      else
      // Not nextToABeeper()
      { 
      }
      // nextToABeeper()

        PickBeeperIfPresent();
    }
    // PickAllBeepersInFrontAndGoToBottom()

    public void PutAllBeepers()
    //***
    // Action
    //   - Remove all beepers from the bag (if there are any)
    // Called by
    //   - cpCalculator.AddColumn()
    //   - cpChecker.EnoughToCarry()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251102 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251102 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (anyBeepersInBeeperBag())
      {
        putBeeper();
      }
      // anyBeepersInBeeperBag()

    }
    // PutAllBeepers()

    private bool RightIsBlocked()
    //***
    // Action
    //   - Negate RightIsClear
    // Called by
    //   - 
    // Calls
    //   - bool RightIsClear()
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return !RightIsClear();
    }
    // bool RightIsBlocked()

    private bool RightIsClear()
    //***
    // Action
    //   - Turn right
    //   - Remember if front is clear into blnResult
    //   - Turn left
    //   - Return blnResult
    // Called by
    //   - bool RightIsBlocked()
    // Calls
    //   - TurnRight()
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnResult;

      TurnRight();
      blnResult = frontIsClear();
      turnLeft();
      return blnResult;
    }
    // bool RightIsClear()

    public void SearchBeeperSomewhereInWorld()
    //***
    // Action
    //   - Look for a beeper somewhere in the world
    //   - Start at the origin
    //   - Look to the West
    //   - As long robot haven't found a beeper
    //     - If robot is facing West
    //       - Move diagonal right
    //     - If not
    //       - Move diagonal left
    // Called by
    //   - cpProgram.SearchBeeper()
    // Calls
    //   - FaceWest()
    //   - GoToStartPosition()
    //   - MoveDiagonalLeft()
    //   - MoveDiagonalRight()
    // Created
    //   - CopyPaste – 20251102 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251102 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      GoToStartPosition();
      FaceWest();

      while (!nextToABeeper())
      {

        if (facingWest())
        {
          MoveDiagonalRight();
        }
        else
        // Not facingWest()
        {
          MoveDiagonalLeft();
        }
        // facingWest()

      }
      // Not nextToABeeper()

    }
    // SearchBeeperSomewhereInWorld()

    private void SolveMazeLeft()
    //***
    // Action
    //   - Find the exit (beeper) in a maze following the left wall
    //   - As long there is no beeper (the exit)
    //     - Turn left
    //   - As long the front is blocked
    //     - Turn right
    //   - Move one forward
    // Called by
    //   - 
    // Calls
    //   - FrontIsBlocked()
    //   - TurnRight()
    // Created
    //   - CopyPaste – 20251102 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251102 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (!nextToABeeper())
      {
        turnLeft();
        
        while (FrontIsBlocked())
        {
          TurnRight();
        }
        // FrontIsBlocked()

        move();
      }
      // Not nextToABeeper()

    }
    // SolveMazeLeft()

    private void SolveMazeRight()
    //***
    // Action
    //   - Find the exit (beeper) in a maze following the right wall
    //   - As long there is no beeper (the exit)
    //     - Turn right
    //   - As long the front is blocked
    //     - Turn left
    //   - Move one forward
    // Called by
    //   - 
    // Calls
    //   - FrontIsBlocked()
    //   - TurnRight()
    // Created
    //   - CopyPaste – 20251102 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251102 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (!nextToABeeper())
      {
        TurnRight();

        while (FrontIsBlocked())
        {
          turnLeft();
        }
        // FrontIsBlocked()

        move();
      }
      // Not nextToABeeper()

    }
    // SolveMazeRight()

    public void Spin()
    //***
    // Action
    //   - Turn 360 degrees
    // Called by
    //   - cpRelayRacer.run()
    // Calls
    //   - TurnAround()
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      TurnAround();
      TurnAround();
    }
    // Spin()

    public void TurnAround()
    //***
    // Action
    //   - Turn 180 degrees
    // Called by
    //   - CollectAllBeepersInFront()
    //   - cpCalculator.OnSecondAvenue()
    //   - cpCarrier.CarryOne()
    //   - cpChecker.EnoughToCarry()
    //   - cpDeadLock.GetForks()
    //   - cpDeadLock.PutForks()
    //   - cpGuardAField.BackUp()
    //   - cpThiefRobotFail.run()
    //   - GoOneBack()
    //   - GoToNextDiagonalAwayFromWalls()
    //   - PickAllBeepersInFrontAndGoToBottom()
    //   - PickAllBeepersXHighAndGoToBottom(int)
    //   - Spin()
    //   - TurnRight() 
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      turnLeft();
			turnLeft();
		}
    // TurnAround()

    public void TurnRight()
    //***
    // Action
    //   - Turns to the right by turning 3 times to the left
    // Called by
    //   - bool LeftIsClear()
    //   - bool RightIsClear()
    //   - cpBlockStrategyExtraTurnRight.DoIt(cpCopyPasteRobot)
    //   - cpCalculator.SlideAll()
    //   - cpDeadLock.GetForks()
    //   - cpDeadLock.PutForks()
    //   - cpReplanter.PositionForNextReplant()
    //   - cpRightTurnController.ControlIt()
    //   - cpRightTurnControllerInside.ControlIt()
    //   - cpTwoBlockSpyStrategy.DoIt(cpCopyPasteRobot)
    //   - cpTwoMeterHurdlesRace.GlideDown()
    //   - cpTwoMeterHurdlesRace.JumpUp()
    //   - DiagonalLeft()
    //   - DiagonalRight()
    //   - SolveMazeLeft()
    //   - SolveMazeRight()
    // Calls
    //   - TurnAround()
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      TurnAround();
      turnLeft();
    }
    // TurnRight()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCopyPasteRobot

}
// cpKarelTheRobot