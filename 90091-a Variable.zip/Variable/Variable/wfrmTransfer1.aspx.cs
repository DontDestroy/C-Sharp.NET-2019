﻿//***
// Action
//   - Demo of using transfer (class based)
//   - Using the transfer is in wfrmTransfer2
// Created
//   - CopyPaste – 20260720 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260720 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmTransfer1 : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
      this.ID = "wfrmTransfer1";
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public string Email
    {

      get
      //***
      // Action Get
      //   - Return the text value of txtEmail
      // Called by
      //   - wfrmTransfer2.Page_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260720 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260720 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return txtEmail.Text;
      }
      // string Email (Get)

    }
    // string Email

    public string Name
    {

      get
      //***
      // Action Get
      //   - Return the text value of txtName
      // Called by
      //   - wfrmTransfer2.Page_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260720 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260720 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return txtName.Text;
      }
      // string Name (Get)

    }
    // string Name

    #endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when the page is initialized
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdOK_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Start wfrmTransfer2.aspx on the server
    //   - Use transfer of this class towards the new page
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Server.Transfer("wfrmTransfer2.aspx");
    }
    // cmdOK_Click(System.Object, System.EventArgs) Handles cmdOK.Click

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when the page is loaded
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmTransfer1

}
// CopyPaste.Learning