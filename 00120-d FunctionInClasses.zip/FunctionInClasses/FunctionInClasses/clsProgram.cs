//***
// Action
//   - Testroutine for cpBase and cpDerived
// Created
//   - CopyPaste � 20240618 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240618 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create a new instance of cpBase
      //   - Create a new instance of cpDerived
      //   - Execute all possible subroutines
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - bool cpBase.FunctionMustOverride()
      //   - bool cpBase.FunctionNotOverridable() 
      //   - bool cpBase.FunctionOverLoad() 
      //   - bool cpBase.FunctionOverLoad(string) 
      //   - bool cpBase.FunctionOverridable() 
      //   - bool cpBase.FunctionShadows() 
      //   - bool cpBase.FunctionStatic() 
      //   - bool cpDerived.FunctionOverridable() 
      //   - bool cpDerived.FunctionShadows() 
      //   - cpBase()
      //   - cpBase.FunctionTestBase()
      //   - cpDerived()
      //   - cpDerived.FunctionTestDerived()
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;
      cpBase thecpBase = new cpBase();
      cpDerived thecpDerived = new cpDerived();

      Console.WriteLine("Default startroutine in a module");
      Console.WriteLine();

      Console.WriteLine("Routines in base class");
      blnResult = thecpBase.FunctionOverLoad();
      Console.WriteLine("Result is {0}", blnResult);
      blnResult = thecpBase.FunctionOverLoad("This is overloaded");
      Console.WriteLine("Result is {0}", blnResult);
      blnResult = thecpBase.FunctionOverridable();
      Console.WriteLine("Result is {0}", blnResult);
      // blnResult = thecpBase.FunctionNotOverridable();
      // Console.WriteLine("Result is {0}", blnResult);
      // blnResult = thecpBase.FunctionSubMustOverride();
      // Console.WriteLine("Result is {0}", blnResult);
      blnResult = thecpBase.FunctionShadows();
      Console.WriteLine("Result is {0}", blnResult);
      blnResult = cpBase.FunctionStatic();
      Console.WriteLine("Result is {0}", blnResult);

      Console.WriteLine();
      thecpBase.FunctionTestBase();
      Console.WriteLine();

      Console.WriteLine("Routines in derived class");
      blnResult = thecpDerived.FunctionOverLoad();
      Console.WriteLine("Result is {0}", blnResult);
      blnResult = thecpDerived.FunctionOverLoad("This is overloaded");
      Console.WriteLine("Result is {0}", blnResult);
      blnResult = thecpDerived.FunctionOverridable();
      Console.WriteLine("Result is {0}", blnResult);
      // blnResult = thecpDerived.FunctionNotOverridable();
      // Console.WriteLine("Result is {0}", blnResult);
      // blnResult = thecpDerived.FunctionMustOverride();
      // Console.WriteLine("Result is {0}", blnResult);
      blnResult = thecpDerived.FunctionShadows();
      Console.WriteLine("Result is {0}", blnResult);
      blnResult = cpDerived.FunctionStatic();
      Console.WriteLine("Result is {0}", blnResult);
      Console.WriteLine();
      thecpDerived.FunctionTestDerived();
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning