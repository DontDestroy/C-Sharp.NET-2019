//***
// Action
//   - Showing a photo on the screen
// Created
//   - CopyPaste � 20240215 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240215 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPhotos: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdStart;
    internal System.Windows.Forms.PictureBox picPhoto;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPhotos));
      this.cmdStart = new System.Windows.Forms.Button();
      this.picPhoto = new System.Windows.Forms.PictureBox();
      ((System.ComponentModel.ISupportInitialize)(this.picPhoto)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdStart
      // 
      this.cmdStart.Location = new System.Drawing.Point(106, 264);
      this.cmdStart.Name = "cmdStart";
      this.cmdStart.Size = new System.Drawing.Size(80, 23);
      this.cmdStart.TabIndex = 3;
      this.cmdStart.Text = "Start";
      this.cmdStart.Click += new System.EventHandler(this.cmdStart_Click);
      // 
      // picPhoto
      // 
      this.picPhoto.Location = new System.Drawing.Point(34, 32);
      this.picPhoto.Name = "picPhoto";
      this.picPhoto.Size = new System.Drawing.Size(224, 216);
      this.picPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picPhoto.TabIndex = 2;
      this.picPhoto.TabStop = false;
      // 
      // frmPhotos
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 309);
      this.Controls.Add(this.cmdStart);
      this.Controls.Add(this.picPhoto);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPhotos";
      this.Text = "Photos";
      ((System.ComponentModel.ISupportInitialize)(this.picPhoto)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPhotos'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPhotos()
      //***
      // Action
      //   - Create instance of 'frmPhotos'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPhotos()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string[] marrstrImage;
    private int mlngIndex;
    private Thread mthrDisplay;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdStart_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The button has a caption "Start"
      //   - When clicked
      //     - If the caption is "Start"
      //       - Change it to "End"
      //       - Start a thread to show images
      //     - If Not
      //       - End the Thread
      //       - Stop the program
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ShowImages()
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (cmdStart.Text == "End")
      {
        mthrDisplay.Abort();
        this.Close();
      }
      else
        // cmdStart.Text <> "End"
      {
        cmdStart.Text = "End";
        mthrDisplay = new System.Threading.Thread(new ThreadStart(ShowImages));
        mthrDisplay.SetApartmentState(ApartmentState.STA);
        mthrDisplay.Start();
      }
      // cmdStart.Text = "End"
    
    }
    // cmdStart_Click(System.Object, System.EventArgs) Handles cmdStart.Click 

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPhotos
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPhotos());
    }
    // Main() 
    
    public void ShowImages()
      //***
      // Action
      //   - Show a file open dialog
      //   - If you clicked "OK"
      //     - Fill an array of selected filenames
      //     - If the length of the array is zero
      //       - Show a warning
      //     - If Not
      //       - Change the caption of the button to "End"
      //       - Set an index to zero
      //       - Loop thru the array
      //         - Check if filename ends on "JPG", "BMP" or "GIF"
      //           - If so, show the picture for 5 seconds
      //           - If Not
      //             - Do nothing
      //         - Add 1 to the index
      //         - If index is equal than size of array
      //           - index becomes zero
      //   - If Not
      //     - Show a warning
      // Called by
      //   - cmdStart_Click(System.Object, System.EventArgs) Handles cmdStart.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      OpenFileDialog dlgFileOpen = new OpenFileDialog();

      dlgFileOpen.Multiselect = true;

      if (dlgFileOpen.ShowDialog() == DialogResult.OK)
      {
        marrstrImage = dlgFileOpen.FileNames;

        if (marrstrImage.Length == 0)
        {
          MessageBox.Show("No files selected");
        }
        else
          // marrstrImage.Length <> 0
        {
          bool blnIsImage;
          Image theImage;
          
          cmdStart.Text = "End";
          mlngIndex = 0;

          do
          {
            blnIsImage = false;

            if (marrstrImage[mlngIndex].ToUpper().EndsWith("JPG"))
            {
              blnIsImage = true;
            }
            else
              // Not marrstrImage[mlngIndex].ToUpper.EndsWith("JPG")
            {
            }
            // marrstrImage[mlngIndex].ToUpper.EndsWith("JPG")
            
            if (marrstrImage[mlngIndex].ToUpper().EndsWith("BMP"))
            {
              blnIsImage = true;
            }
            else
              // Not marrstrImage[mlngIndex].ToUpper.EndsWith("BMP")
            {
            }
            // marrstrImage[mlngIndex].ToUpper.EndsWith("BMP")

            if (marrstrImage[mlngIndex].ToUpper().EndsWith("GIF"))
            {
              blnIsImage = true;
            }
            else
              // Not marrstrImage[mlngIndex].ToUpper.EndsWith("GIF")
            {
            }
            // marrstrImage[mlngIndex].ToUpper.EndsWith("GIF")

            if (blnIsImage)
            {
              
              try
              {
                theImage = Image.FromFile(marrstrImage[mlngIndex]);
                picPhoto.Image = theImage;
                Thread.Sleep(5000);
              }
              catch (Exception theException)
              {
              }

            }
            else
              // Not blnIsImage
            {
            }
            // blnIsImage

            mlngIndex += 1;


            if (mlngIndex == marrstrImage.Length)
            {
              mlngIndex = 0;
            }
            else
              // mlngIndex <> marrstrImage.Length
            {
            }
            // mlngIndex = marrstrImage.Length

          }
          while (true);

        }
        // marrstrImage.Length = 0

      }
      else
        // dlgFileOpen.ShowDialog() <> DialogResult.OK
      {
        MessageBox.Show("User selected Cancel");
      }
      // dlgFileOpen.ShowDialog() = DialogResult.OK

    }
    // ShowImages()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPhotos

}
// CopyPaste.Learning