//***
// Action
//   - Master window in the MDI application
//   - There is a File New and File Exit menu
//   - Windows can be organised by icon, cascade, horizontal and vertical
//   - Selecting a child window changes the title of the master window
// Created
//   - CopyPaste � 20250707 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250707 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMaster: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.MenuItem mnuFileNew;
    internal System.Windows.Forms.MenuItem mnuFile;
    internal System.Windows.Forms.MenuItem mnuFileExit;
    internal System.Windows.Forms.MenuItem mnuWindows;
    internal System.Windows.Forms.MenuItem mnuWindowsTileHorizontally;
    internal System.Windows.Forms.MenuItem mnuWindowsTileVertically;
    internal System.Windows.Forms.MenuItem mnuWindowsCascade;
    internal System.Windows.Forms.MenuItem mnuWindowsArrangeIcons;
    internal System.Windows.Forms.MainMenu mnuMain;


    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMaster));
      this.mnuFileNew = new System.Windows.Forms.MenuItem();
      this.mnuFile = new System.Windows.Forms.MenuItem();
      this.mnuFileExit = new System.Windows.Forms.MenuItem();
      this.mnuWindows = new System.Windows.Forms.MenuItem();
      this.mnuWindowsTileHorizontally = new System.Windows.Forms.MenuItem();
      this.mnuWindowsTileVertically = new System.Windows.Forms.MenuItem();
      this.mnuWindowsCascade = new System.Windows.Forms.MenuItem();
      this.mnuWindowsArrangeIcons = new System.Windows.Forms.MenuItem();
      this.mnuMain = new System.Windows.Forms.MainMenu();
      // 
      // mnuFileNew
      // 
      this.mnuFileNew.Index = 0;
      this.mnuFileNew.Shortcut = System.Windows.Forms.Shortcut.CtrlN;
      this.mnuFileNew.Text = "&New";
      this.mnuFileNew.Click += new System.EventHandler(this.mnuFileNew_Click);
      // 
      // mnuFile
      // 
      this.mnuFile.Index = 0;
      this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFileNew,
                                                                            this.mnuFileExit});
      this.mnuFile.Text = "&File";
      // 
      // mnuFileExit
      // 
      this.mnuFileExit.Index = 1;
      this.mnuFileExit.Text = "E&xit";
      this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
      // 
      // mnuWindows
      // 
      this.mnuWindows.Enabled = false;
      this.mnuWindows.Index = 1;
      this.mnuWindows.MdiList = true;
      this.mnuWindows.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                               this.mnuWindowsTileHorizontally,
                                                                               this.mnuWindowsTileVertically,
                                                                               this.mnuWindowsCascade,
                                                                               this.mnuWindowsArrangeIcons});
      this.mnuWindows.Text = "&Windows";
      // 
      // mnuWindowsTileHorizontally
      // 
      this.mnuWindowsTileHorizontally.Index = 0;
      this.mnuWindowsTileHorizontally.Text = "T&ile Horizontally";
      this.mnuWindowsTileHorizontally.Click += new System.EventHandler(this.mnuWindowsTileHorizontally_Click);
      // 
      // mnuWindowsTileVertically
      // 
      this.mnuWindowsTileVertically.Index = 1;
      this.mnuWindowsTileVertically.Text = "&Tile Vertically";
      this.mnuWindowsTileVertically.Click += new System.EventHandler(this.mnuWindowsTileVertically_Click);
      // 
      // mnuWindowsCascade
      // 
      this.mnuWindowsCascade.Index = 2;
      this.mnuWindowsCascade.Text = "&Cascade";
      this.mnuWindowsCascade.Click += new System.EventHandler(this.mnuWindowsCascade_Click);
      // 
      // mnuWindowsArrangeIcons
      // 
      this.mnuWindowsArrangeIcons.Index = 3;
      this.mnuWindowsArrangeIcons.Text = "&Arrange Icons";
      this.mnuWindowsArrangeIcons.Click += new System.EventHandler(this.mnuWindowsArrangeIcons_Click);
      // 
      // mnuMain
      // 
      this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFile,
                                                                            this.mnuWindows});
      // 
      // frmMaster
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.IsMdiContainer = true;
      this.Menu = this.mnuMain;
      this.Name = "frmMaster";
      this.Text = "Master Program";
      this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
      this.MdiChildActivate += new System.EventHandler(this.frmMaster_MdiChildActivate);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMaster'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMaster()
      //***
      // Action
      //   - Create instance of 'frmMaster'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMaster()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
        
    private void frmMaster_MdiChildActivate(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there is a child window
      //     - Menu Windows is available
      //     - Title of master window is changed into title of child window
      //   - If not
      //     - Menu Windows is not available
      //     - Title of master window is changed into default title
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (ActiveMdiChild == null)
      {
        mnuWindows.Enabled = false;
        this.Text = "Master Program";
      }
      else
        // ActiveMdiChild <> null
      {
        mnuWindows.Enabled = true;
        this.Text = "Todo items - " + ActiveMdiChild.Text;
      }
      // ActiveMdiChild = null
    
    }
    // frmMaster_MdiChildActivate(System.Object, System.EventArgs) Handles this.MdiChildActivate

    private void mnuFileExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Close application
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // mnuFileExit_Click(System.Object, System.EventArgs) Handles mnuFileExit.Click
    
    private void mnuFileNew_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new child window
      //   - The master window becomes the parent of the child window
      //   - Show the child window
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - frmChild()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmChild theChildFrom = new frmChild();

      theChildFrom.MdiParent = this;
      theChildFrom.Show();
    }
    // mnuFileNew_Click(System.Object, System.EventArgs) Handles mnuFileNew.Click

    private void mnuWindowsArrangeIcons_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Arrange all the child windows that are icons at the bottom of the master window
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      LayoutMdi(MdiLayout.ArrangeIcons);
    }
    // mnuWindowsArrangeIcons_Click(System.Object, System.EventArgs) Handles mnuWindowsArrangeIcons.Click

    private void mnuWindowsCascade_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Arrange all the child windows that are not icons in cascasde in the master window
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      LayoutMdi(MdiLayout.Cascade);
    }
    // mnuWindowsCascade_Click(System.Object, System.EventArgs) Handles mnuWindowsCascade.Click

    private void mnuWindowsTileHorizontally_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Arrange all the child windows that are not icons in horizontal view in the master window
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      LayoutMdi(MdiLayout.TileHorizontal);
    }
    // mnuWindowsTileHorizontally_Click(System.Object, System.EventArgs) Handles mnuWindowsTileHorizontally.Click

    private void mnuWindowsTileVertically_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Arrange all the child windows that are not icons in horizontal view in the master window
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      LayoutMdi(MdiLayout.TileVertical);
    }
    // mnuWindowsTileVertically_Click(System.Object, System.EventArgs) Handles mnuWindowsTileVertically.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMaster
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmMaster()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMaster());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMaster

}
// CopyPaste.Learning