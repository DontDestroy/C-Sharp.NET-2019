//***
// Action
//   - A basic class
// Created
//   - CopyPaste � 20240423 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240423 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpClass
  {

    #region "Constructors / Destructors"

    public cpClass()
      //***
      // Action
      //   - Empty constructor
      // Called by
      //   - frmValueAndReferenceTypes.cmdClass_Click(System.Object, System.EventArgs) Handles cmdClass.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpClass()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public byte mbytAge;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpClass

}
// CopyPaste.Learning