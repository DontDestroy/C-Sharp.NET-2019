'***
' Action
'   - Explanation of the code in this module or class
' Created
'   - CopyPaste � 20260123 � VVDW
' Changed
'   - CopyPaste � yyyymmdd � VVDW � What changed
' Tested
'   - CopyPaste � 20260123 � VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On 
Option Strict On

Imports System.Math

Namespace CopyPaste.Learning

  Public Class wfrmCarLoan
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    Protected WithEvents cmdCalculate As System.Web.UI.WebControls.Button
    Protected WithEvents hypHelpDutch As System.Web.UI.WebControls.HyperLink
    Protected WithEvents hypHelpEnglish As System.Web.UI.WebControls.HyperLink
    Protected WithEvents lblAmount As System.Web.UI.WebControls.Label
    Protected WithEvents lblInterest As System.Web.UI.WebControls.Label
    Protected WithEvents lblPayment As System.Web.UI.WebControls.Label
    Protected WithEvents txtAmount As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtInterest As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtPayment As System.Web.UI.WebControls.TextBox

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

#End Region

#Region "Constructors"

    Private Sub Page_Init(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Init
      '***
      ' Action
      '   - Basic constructor
      ' Called by
      '   - User action (Starting the page)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste � 20260123 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260123 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      InitializeComponent()
    End Sub
    ' Page_Init(System.Object, System.EventArgs) Handles MyBase.Init

#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

    '#Region "Fields"
    '#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

#Region "Controls"

    Private Sub cmdCalculate_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdCalculate.Click
      '***
      ' Action
      '   - Define a result variable
      '   - Calculate the monthly payment of the typed amount with the yearly typed interest over 48 months
      '   - Assign the result
      '   - Show the result on the webpage
      ' Called by
      '   - User action (Clicking a button)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste � 20260123 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260123 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      Dim sngLoanPayment As Single

      sngLoanPayment = Convert.ToSingle(Pmt(Convert.ToDouble(txtInterest.Text) / 12, 48, Convert.ToDouble(txtAmount.Text)))
      txtPayment.Text = Format(Abs(sngLoanPayment), "� 0.00")
    End Sub
    ' cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click

    Private Sub Page_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Load
      '***
      ' Action
      '   - 
      ' Called by
      '   - User action (Loading the page)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste � 20260123 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260123 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

    End Sub
    ' Page_Load(System.Object, System.EventArgs) Handles MyBase.Load

#End Region

    '#Region "Functionality"

    '#Region "Event"
    '#End Region

    '#Region "Sub / Function"
    '#End Region

    '#End Region

#End Region

    '#Region "Not used"
    '#End Region

  End Class
  ' wfrmCarLoad

End Namespace
' CopyPaste.Learning