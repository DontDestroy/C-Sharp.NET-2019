//***
// Action
//   - A listener is added to the debug window
// Created
//   - CopyPaste � 20240424 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240424 � VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define a filestream (T:\Log.txt)
      //   - Define a TextWriterTraceListener
      //   - Define a streamwriter for the trace
      //   - Add the trace as listener of debug
      //   - Write a message to debug
      //   - Write a message to debug
      //   - Close debug
      //   - Close filestream
      //   - Remove the listener
      //   - Write a message to debug
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240424 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240424 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - Only the 2 first writelines are in the logfile
      //***
    {
      FileStream theFileStream = new FileStream("T:\\Log.txt", FileMode.Append, FileAccess.Write);
      TextWriterTraceListener theTrace = new TextWriterTraceListener();

      theTrace.Writer = new StreamWriter(theFileStream);

      Debug.Listeners.Add(theTrace);
      Debug.WriteLine("First debug line");
      Debug.WriteLine("Second debug line");
      Debug.Close();
      theFileStream.Close();
      Debug.Listeners.Remove(theTrace);
      Debug.WriteLine("Third debug line");
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning