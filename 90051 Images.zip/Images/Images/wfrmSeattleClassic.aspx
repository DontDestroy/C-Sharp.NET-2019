﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmSeattleClassic.aspx.cs" Inherits="CopyPaste.Learning.wfrmSeattleClassic" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>myPod: Classic iPod</title>
  <style type="text/css">
    body {
      background-color: #eaf3da;
    }
  </style>
</head>
<body>
  <form id="wfrmSeattleClassic" runat="server">
    <h1>Classic iPod on the ferry</h1>
    <p>
      <img src="../Resources/Seattle_Classic_Medium.jpg" alt="A classic iPod in Seattle" />
    </p>
  </form>
</body>
</html>
