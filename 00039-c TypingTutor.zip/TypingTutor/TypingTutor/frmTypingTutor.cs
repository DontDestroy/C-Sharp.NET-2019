//***
// Action
//   - Creating a typing tutor. This is form as startpoint of the exercise.
// Created
//   - CopyPaste � 20240201 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240201 � VVDW
// Proposal (To Do)
//   - A lot of refactorings / improvements can be done
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTypingTutor: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdStart;
    internal System.Windows.Forms.Button cmdQuit;
    internal System.Windows.Forms.Label lblScore;
    internal System.Windows.Forms.TextBox txtType;
    internal System.Windows.Forms.Label lblWord05;
    internal System.Windows.Forms.Label lblWord04;
    internal System.Windows.Forms.Label lblWord03;
    internal System.Windows.Forms.Label lblWord02;
    internal System.Windows.Forms.Label lblWord01;
    internal System.Windows.Forms.Timer tmrTimer;
    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTypingTutor));
      this.cmdStart = new System.Windows.Forms.Button();
      this.cmdQuit = new System.Windows.Forms.Button();
      this.lblScore = new System.Windows.Forms.Label();
      this.txtType = new System.Windows.Forms.TextBox();
      this.lblWord05 = new System.Windows.Forms.Label();
      this.lblWord04 = new System.Windows.Forms.Label();
      this.lblWord03 = new System.Windows.Forms.Label();
      this.lblWord02 = new System.Windows.Forms.Label();
      this.lblWord01 = new System.Windows.Forms.Label();
      this.tmrTimer = new System.Windows.Forms.Timer(this.components);
      this.SuspendLayout();
      // 
      // cmdStart
      // 
      this.cmdStart.Location = new System.Drawing.Point(7, 343);
      this.cmdStart.Name = "cmdStart";
      this.cmdStart.TabIndex = 19;
      this.cmdStart.Text = "Start";
      this.cmdStart.Click += new System.EventHandler(this.cmdStart_Click);
      // 
      // cmdQuit
      // 
      this.cmdQuit.Location = new System.Drawing.Point(367, 343);
      this.cmdQuit.Name = "cmdQuit";
      this.cmdQuit.TabIndex = 18;
      this.cmdQuit.Text = "Quit";
      this.cmdQuit.Click += new System.EventHandler(this.cmdQuit_Click);
      // 
      // lblScore
      // 
      this.lblScore.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
      this.lblScore.ForeColor = System.Drawing.Color.Blue;
      this.lblScore.Location = new System.Drawing.Point(7, 7);
      this.lblScore.Name = "lblScore";
      this.lblScore.Size = new System.Drawing.Size(432, 23);
      this.lblScore.TabIndex = 17;
      this.lblScore.Text = "SCORE:";
      this.lblScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // txtType
      // 
      this.txtType.Enabled = false;
      this.txtType.Location = new System.Drawing.Point(7, 311);
      this.txtType.Name = "txtType";
      this.txtType.Size = new System.Drawing.Size(432, 20);
      this.txtType.TabIndex = 16;
      this.txtType.Text = "";
      this.txtType.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
      this.txtType.WordWrap = false;
      this.txtType.TextChanged += new System.EventHandler(this.txtType_TextChanged);
      // 
      // lblWord05
      // 
      this.lblWord05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblWord05.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblWord05.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(128)), ((System.Byte)(0)));
      this.lblWord05.Location = new System.Drawing.Point(367, 39);
      this.lblWord05.Name = "lblWord05";
      this.lblWord05.Size = new System.Drawing.Size(64, 24);
      this.lblWord05.TabIndex = 15;
      this.lblWord05.Text = "turtle";
      this.lblWord05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblWord04
      // 
      this.lblWord04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblWord04.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblWord04.ForeColor = System.Drawing.Color.Magenta;
      this.lblWord04.Location = new System.Drawing.Point(279, 39);
      this.lblWord04.Name = "lblWord04";
      this.lblWord04.Size = new System.Drawing.Size(64, 24);
      this.lblWord04.TabIndex = 14;
      this.lblWord04.Text = "bird";
      this.lblWord04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblWord03
      // 
      this.lblWord03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblWord03.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblWord03.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(192)), ((System.Byte)(0)));
      this.lblWord03.Location = new System.Drawing.Point(191, 39);
      this.lblWord03.Name = "lblWord03";
      this.lblWord03.Size = new System.Drawing.Size(64, 24);
      this.lblWord03.TabIndex = 13;
      this.lblWord03.Text = "fish";
      this.lblWord03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblWord02
      // 
      this.lblWord02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblWord02.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblWord02.ForeColor = System.Drawing.Color.Teal;
      this.lblWord02.Location = new System.Drawing.Point(103, 39);
      this.lblWord02.Name = "lblWord02";
      this.lblWord02.Size = new System.Drawing.Size(64, 24);
      this.lblWord02.TabIndex = 12;
      this.lblWord02.Text = "dog";
      this.lblWord02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblWord01
      // 
      this.lblWord01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblWord01.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblWord01.ForeColor = System.Drawing.Color.Red;
      this.lblWord01.Location = new System.Drawing.Point(15, 39);
      this.lblWord01.Name = "lblWord01";
      this.lblWord01.Size = new System.Drawing.Size(64, 24);
      this.lblWord01.TabIndex = 11;
      this.lblWord01.Text = "cat";
      this.lblWord01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // tmrTimer
      // 
      this.tmrTimer.Interval = 600;
      this.tmrTimer.Tick += new System.EventHandler(this.tmrTimer_Tick);
      // 
      // frmTypingTutor
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(448, 373);
      this.Controls.Add(this.cmdQuit);
      this.Controls.Add(this.lblScore);
      this.Controls.Add(this.txtType);
      this.Controls.Add(this.lblWord05);
      this.Controls.Add(this.lblWord04);
      this.Controls.Add(this.lblWord03);
      this.Controls.Add(this.lblWord02);
      this.Controls.Add(this.lblWord01);
      this.Controls.Add(this.cmdStart);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTypingTutor";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Typing Tutor";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTypingTutor'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTypingTutor()
      //***
      // Action
      //   - Create instance of 'frmTypingTutor'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTypingTutor()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    int mlngScore = 0;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdQuit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Ends the program
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Exit();
    }
    // cmdQuit_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdQuit.Click
    
    private void cmdStart_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Initialize the program
      //   - If button text is "Start"
      //     - Button text becomes stop
      //     - Score is set to zero
      //     - Score is shown on the screen
      //     - Timer is enabled
      //     - Textbox is enabled
      //     - Focus is set to the typing textbox
      //   - If Not
      //     - Button text is "Stop"
      //     - Textobx is disabled
      //     - Timer is disabled
      //     - All textboxes are put on the top of the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    
      if (cmdStart.Text == "Start")
      {
        cmdStart.Text = "Stop";
        mlngScore = 0;
        lblScore.Text = "SCORE: " + mlngScore;
        tmrTimer.Enabled = true;
        txtType.Enabled = true;
        txtType.Focus();
      }
      else
        // cmdStart.Text <> "Start"
      {
        cmdStart.Text = "Start";
        tmrTimer.Enabled = false;
        txtType.Enabled = false;
        lblWord01.Top = 40;
        lblWord02.Top = 40;
        lblWord03.Top = 40;
        lblWord04.Top = 40;
        lblWord05.Top = 40;
      }
      // cmdStart.Text = "Start"

    }
    // cmdStart_Click(System.Object, System.EventArgs) Handles cmdStart.Click

    private void tmrTimer_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - First word goes 10 down
      //     - Check if word is at bottom
      //       - If So
      //         - Put word at the top
      //         - Subtract 10 from the score
      //         - Show the score
      //   - Same thing for
      //     - Second, Third, Fourth and Fifth word
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      lblWord01.Top += 10;
      
      if (lblWord01.Top > 280)
      {
        lblWord01.Top = 40;
        mlngScore -= 10;
        lblScore.Text = "SCORE: " + mlngScore;
      }
      else
        // lblWord01.Top <= 280
      {
      }
      // lblWord01.Top > 280

      lblWord02.Top += 10;

      if (lblWord02.Top > 280)
      {
        lblWord02.Top = 40;
        mlngScore -= 10;
        lblScore.Text = "SCORE: " + mlngScore;
      }
      else
        // lblWord02.Top <= 280
      {
      }
      // lblWord02.Top > 280

      lblWord03.Top += 10;

      if (lblWord03.Top > 280)
      {
        lblWord03.Top = 40;
        mlngScore -= 10;
        lblScore.Text = "SCORE: " + mlngScore;
      }
      else
        // lblWord03.Top <= 280
      {
      }
      // lblWord03.Top > 280
 
      lblWord04.Top += 10;

      if (lblWord04.Top > 280)
      {
        lblWord04.Top = 40;
        mlngScore -= 10;
        lblScore.Text = "SCORE: " + mlngScore;
      }
      else
        // lblWord04.Top <= 280
      {
      }
      // lblWord04.Top > 280

      lblWord05.Top += 10;
      
      if (lblWord05.Top > 280)
      {
        lblWord05.Top = 40;
        mlngScore -= 10;
        lblScore.Text = "SCORE: " + mlngScore;
      }
      else
        // lblWord05.Top <= 280
      {
      }
      // lblWord05.Top > 280
    
    }
    // tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
    
    private void txtType_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - You have change the type text of the tutor
      //   - If the text is empty or empty string
      //   - If not
      //     - Check if typed text is equal to the first word
      //     - If So
      //       - Clear type text
      //       - Put word at the top
      //       - Add 1 from the score
      //       - Show the score
      //     - Same thing for
      //       - Second, Third, Fourth and Fifth word
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      
      if (txtType.Text == "")
      {
      }
      else
        // txtType.Text <> ""
      {

        if (txtType.Text == lblWord01.Text)
        {
          txtType.Text = "";
          lblWord01.Top = 40;
          mlngScore += 1;
          lblScore.Text = "SCORE: " + mlngScore;
        }
        else
          // txtType.Text <> lblWord01.Text
        {
        }
        // txtType.Text = lblWord01.Text

        if (txtType.Text == lblWord02.Text)
        {
          txtType.Text = "";
          lblWord02.Top = 40;
          mlngScore += 1;
          lblScore.Text = "SCORE: " + mlngScore;
        }
        else
          // txtType.Text <> lblWord02.Text
        {
        }
        // txtType.Text = lblWord02.Text

        if (txtType.Text == lblWord03.Text)
        {
          txtType.Text = "";
          lblWord03.Top = 40;
          mlngScore += 1;
          lblScore.Text = "SCORE: " + mlngScore;
        }
        else
          // txtType.Text <> lblWord03.Text
        {
        }
        // txtType.Text = lblWord03.Text

        if (txtType.Text == lblWord04.Text)
        {
          txtType.Text = "";
          lblWord04.Top = 40;
          mlngScore += 1;
          lblScore.Text = "SCORE: " + mlngScore;
        }
        else
          // txtType.Text <> lblWord04.Text
        {
        }
        // txtType.Text = lblWord04.Text

        if (txtType.Text == lblWord05.Text)
        {
          txtType.Text = "";
          lblWord05.Top = 40;
          mlngScore += 1;
          lblScore.Text = "SCORE: " + mlngScore;
        }
        else
          // txtType.Text <> lblWord05.Text
        {
        }
        // txtType.Text = lblWord05.Text

      }
      // txtType.Text = ""
   
    }
    // txtType_TextChanged(System.Object, System.EventArgs) Handles txtType.TextChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTypingTutor
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTypingTutor());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTypingTutor

}
// CopyPaste.Learning