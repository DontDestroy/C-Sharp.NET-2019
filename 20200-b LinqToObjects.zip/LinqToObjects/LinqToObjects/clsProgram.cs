﻿//***
// Action
//   - A Linq example with the American Presidents
//   - Linq to Objects example
//   - IEnumerable<T>, permits to enumerate (loop thru) the collections elements
//     - You can call this a sequence
// Created
//   - CopyPaste – 20230413 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230413 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinqToObjects
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static string[] FillArray()
    //***
    // Action
    //   - Creating an array with all the American presidents
    // Called by
    //   - FilterAnArrayOnTheFirst(string)
    //   - FilterAnArrayHavingALetterOnPosition(int)
    //   - FilterAnArrayStartingWith(string)
    //   - LoopAnArrayThatChangesBetweenTwoQueries(string)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230413 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230413 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      string[] arrAmericanPresidents;

      arrAmericanPresidents = new string[] {
        "George Washington", "John Adams", "Thomas Jefferson", "James Madison",
        "James Monroe", "John Quincy Adams", "Andrew Jackson", "Martin Van Buren",
        "William Henry Harrison", "John Tyler", "James K. Polk", "Zachary Taylor",
        "Millard Fillmore", "Franklin Pierce", "James Buchanan", "Abraham Lincoln",
        "Andrew Johnson", "Ulysses S. Grant", "Rutherford B. Hayes", "James A. Garfield",
        "Chester A. Arthur", "Grover Cleveland", "Benjamin Harrison", "William McKinley",
        "Theodore Roosevelt", "William Howard Taft", "Woordrow Wilson", "Warren G. Harding",
        "Calvin Coolidge", "Herbert Hoover", "Franklin D. Roosevelt", "Harry S. Truman",
        "Dwight D. Eisenhower", "John F. Kennedy", "Lyndon B. Johnson", "Richard Nixon",
        "Gerald Ford", "Jimmy Carter", "Ronald Reagan", "George H. W. Bush", "Bill Clinton",
        "George W. Bush", "Barack Obama", "Donald Trump", "Joe Biden"};

      return arrAmericanPresidents;
    }
    // FillArray()

    static void FilterAnArrayOnTheFirst(string strStartsWith)
    //***
    // Action
    //   - Fill an array with all the American presidents
    //   - Every collection that has implemented with IEnumerable<T> or IENumerable can be queried with Linq
    //   - Give me the first president that starts with 'strStartWith' using Linq Lambda Expression (dot notation)
    //   - Show result
    // Called by
    //   - Main()
    // Calls
    //   - FillArray()
    // Created
    //   - CopyPaste – 20230413 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230413 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      string strCurrentMethodName;
      string strPresident;
      string[] arrAmericanPresidents;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      arrAmericanPresidents = FillArray();

      strPresident = arrAmericanPresidents
        .Where(aPresident => aPresident.StartsWith(strStartsWith))
        .First();
      // Consider here FirstOrDefault(), because when there is no answer, first will give a runtime error

      Console.WriteLine("The first president that starts with \"{0}\": (Lambda Linq dot notation)", strStartsWith);
      Console.WriteLine(strPresident);

      // The first statement is not covered by Linq Expressions

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // FilterAnArrayOnTheFirst(string)

    static void FilterAnArrayHavingALetterOnPosition(int intLetterNumber)
    //***
    // Action
    //   - Fill an array with all the American presidents
    //   - Every collection that has implemented with IEnumerable<T> or IENumerable can be queried with Linq
    //   - Give me the presidents that have not a space on position 'intLettterNumber' using Linq Lambda Expression (dot notation)
    //   - Show result
    //   - Make intLetterNumber one bigger
    //   - Give me the presidents that have not a space on position 'intLettterNumber' using Linq Fluent Expression
    //   - Show result
    // Called by
    //   - Main()
    // Calls
    //   - FillArray()
    //   - LoopResult<T>(IEnumerable<T>)
    // Created
    //   - CopyPaste – 20230413 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230413 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      IEnumerable<string> colPresidentsExpression;
      IEnumerable<string> colPresidentsLambda;
      string strCurrentMethodName;
      string[] arrAmericanPresidents;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      arrAmericanPresidents = FillArray();

      colPresidentsLambda = arrAmericanPresidents.Where(aPresident => Char.IsLower(aPresident[intLetterNumber]));

      if (intLetterNumber == 1)
      {
        Console.WriteLine("The presidents that have a " + intLetterNumber + "st character in the name that is not a space: (Lambda Linq dot notation)");
      }
      else if (intLetterNumber == 2)
      {
        Console.WriteLine("The presidents that have a " + intLetterNumber + "nd character in the name that is not a space: (Lambda Linq dot notation)");
      }
      else if (intLetterNumber == 3)
      {
        Console.WriteLine("The presidents that have a " + intLetterNumber + "rd character in the name that is not a space: (Lambda Linq dot notation)");
      }
      else
      {
        Console.WriteLine("The presidents that have a " + intLetterNumber + "th character in the name that is not a space: (Lambda Linq dot notation)");
      }
      // intLetterNumber == 1
      // intLetterNumber == 2
      // intLetterNumber == 3

      LoopResult(colPresidentsLambda);

      intLetterNumber += 1;

      colPresidentsExpression = from aPresident in arrAmericanPresidents
                                where Char.IsLower(aPresident[intLetterNumber])
                                select aPresident;

      if (intLetterNumber == 1)
      {
        Console.WriteLine("The presidents that have a " + intLetterNumber + "st character in the name that is not a space: (Lambda Linq dot notation)");
      }
      else if (intLetterNumber == 2)
      {
        Console.WriteLine("The presidents that have a " + intLetterNumber + "nd character in the name that is not a space: (Lambda Linq dot notation)");
      }
      else if (intLetterNumber == 3)
      {
        Console.WriteLine("The presidents that have a " + intLetterNumber + "rd character in the name that is not a space: (Lambda Linq dot notation)");
      }
      else
      {
        Console.WriteLine("The presidents that have a " + intLetterNumber + "th character in the name that is not a space: (Lambda Linq dot notation)");
      }
      // intLetterNumber == 1
      // intLetterNumber == 2
      // intLetterNumber == 3

      LoopResult(colPresidentsExpression);

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // FilterAnArrayHavingALetterOnPosition(int)

    static void FilterAnArrayStartingWith(string strStarting)
    //***
    // Action
    //   - Fill an array with all the American presidents
    //   - Every collection that has implemented with IEnumerable<T> or IENumerable can be queried with Linq
    //   - Give me the presidents that starts with 'strStarting' using Linq Lambda Expression (dot notation)
    //   - Show result
    //   - Give me the presidents that starts with 'strStarting' using Linq Fluent Expression
    //   - Show result
    // Called by
    //   - Main()
    // Calls
    //   - FillArray()
    //   - LoopResult<T>(IEnumerable<T>)
    // Created
    //   - CopyPaste – 20230413 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230413 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      IEnumerable<string> colPresidentsExpression;
      IEnumerable<string> colPresidentsLambda;
      string strCurrentMethodName;
      string[] arrAmericanPresidents;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      arrAmericanPresidents = FillArray();

      colPresidentsLambda = arrAmericanPresidents.Where(aPresident => aPresident.StartsWith(strStarting));

      Console.WriteLine("The presidents that starts with \"" + strStarting + "\": (Lambda Linq dot notation)");
      LoopResult(colPresidentsLambda);

      colPresidentsExpression = from aPresident in arrAmericanPresidents
                                where aPresident.StartsWith(strStarting)
                                select aPresident;

      Console.WriteLine("The presidents that starts with \"" + strStarting + "\": (Linq expression)");
      LoopResult(colPresidentsExpression);

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // FilterAnArrayStartingWith(string)

    static void LoopAnArrayThatChangesBetweenTwoQueries(string strStarting)
    //***
    // Action
    //   - Fill an array with all the American presidents
    //   - Every collection that has implemented with IEnumerable<T> or IENumerable can be queried with Linq
    //   - Give me the presidents that starts with 'strStarting' using Linq Lambda Expression (dot notation)
    //   - Show result
    //   - Change the array a bit
    //   - Give me the presidents that starts with 'strStarting' using Linq Fluent Expression
    //   - Show result
    // Called by
    //   - Main()
    // Calls
    //   - FillArray()
    //   - LoopResult<T>(IEnumerable<T>)
    // Created
    //   - CopyPaste – 20230413 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230413 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      IEnumerable<string> colPresidentsExpression;
      IEnumerable<string> colPresidentsLambda;
      string strCurrentMethodName;
      string[] arrAmericanPresidents;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      arrAmericanPresidents = FillArray();

      colPresidentsLambda = arrAmericanPresidents.Where(aPresident => aPresident.StartsWith(strStarting));

      Console.WriteLine("The presidents that starts with \"" + strStarting + "\": (Lambda Linq dot notation)");
      LoopResult(colPresidentsLambda);

      arrAmericanPresidents[0] = "Guido Van De Walle";

      colPresidentsExpression = from aPresident in arrAmericanPresidents
                                where aPresident.StartsWith(strStarting)
                                select aPresident;

      Console.WriteLine("The presidents that starts with \"" + strStarting + "\": (Linq expression)");
      LoopResult(colPresidentsExpression);

      arrAmericanPresidents[0] = "George Washington";

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // LoopAnArrayThatChangesBetweenTwoQueries(string)

    static void LoopResult<T>(IEnumerable<T> colResult)
    //***
    // Action
    //   - Loop thru the elements of a collection
    //     - Show result
    // Called by
    //   - FilterAnArrayStartingWith(string)
    //   - FilterAnArrayHavingALetterOnPosition(int)
    //   - LoopAnArrayThatChangesBetweenTwoQueries(string)
    //   - LoopTwiceAListThatIsAResultOfAQuery()
    //   - LoopTwiceAnArrayThatIsAResultOfAQuery()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230413 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230413 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      foreach (T theItem in colResult)
      {
        Console.WriteLine(theItem);
      }
      // in colResult

      Console.WriteLine("");
    }
    // LoopResult<T>(IEnumerable<T>)

    static void LoopTwiceAListThatIsAResultOfAQuery()
    //***
    // Action
    //   - Fill an array with numbers
    //   - Every collection that has implemented with IEnumerable<T> or IENumerable can be queried with Linq
    //   - Give me the numbers using Linq Lambda Expression (dot notation) (but as a list)
    //   - Show result
    //   - Change the array a bit
    //   - Show result
    //   - Give me the numbers using Linq Fluent Expression (but as a list)
    //   - Show result
    //   - Change the array a bit
    //   - Show result
    // Called by
    //   - Main()
    // Calls
    //   - LoopResult<T>(IEnumerable<T>)
    // Created
    //   - CopyPaste – 20230413 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230413 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      IEnumerable<int> colNumbersExpression;
      IEnumerable<int> colNumbersLambda;
      int[] intArray;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      intArray = new int[] { 1, 2, 3 };

      colNumbersLambda = intArray.Where(intNumber => intNumber % 2 == 1).ToList();

      Console.WriteLine("The numbers in the array that are odd: (Lambda Linq dot notation)");
      LoopResult(colNumbersLambda);

      intArray[0] = 4;

      Console.WriteLine("The numbers in the array that are odd: (Lambda Linq dot notation)");
      LoopResult(colNumbersLambda);

      colNumbersExpression = from intNumber in intArray
                             where intNumber % 2 == 0
                             select intNumber;
      colNumbersExpression = colNumbersExpression.ToList();

      Console.WriteLine("The numbers in the array that are even: (Linq expression)");
      LoopResult(colNumbersExpression);

      intArray[0] = 1;

      Console.WriteLine("The numbers in the array that are even: (Linq expression)");
      LoopResult(colNumbersExpression);

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // LoopTwiceAListThatIsAResultOfAQuery()

    static void LoopTwiceAnArrayThatIsAResultOfAQuery()
    //***
    // Action
    //   - Fill an array with numbers
    //   - Every collection that has implemented with IEnumerable<T> or IENumerable can be queried with Linq
    //   - Give me the numbers using Linq Lambda Expression (dot notation)
    //   - Show result
    //   - Change the array a bit
    //   - Show result
    //   - Give me the numbers using Linq Fluent Expression
    //   - Show result
    //   - Change the array a bit
    //   - Show result
    // Called by
    //   - Main()
    // Calls
    //   - LoopResult<T>(IEnumerable<T>)
    // Created
    //   - CopyPaste – 20230413 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230413 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      IEnumerable<int> colNumbersExpression;
      IEnumerable<int> colNumbersLambda;
      int[] intArray;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      intArray = new int[] { 1, 2, 3 };

      colNumbersLambda = intArray.Where(intNumber => intNumber % 2 == 1);

      Console.WriteLine("The numbers in the array that are odd: (Lambda Linq dot notation)");
      LoopResult(colNumbersLambda);

      intArray[0] = 4;

      Console.WriteLine("The numbers in the array that are odd: (Lambda Linq dot notation)");
      LoopResult(colNumbersLambda);

      colNumbersExpression = from intNumber in intArray
                             where intNumber % 2 == 0
                             select intNumber;

      Console.WriteLine("The numbers in the array that are even: (Linq expression)");
      LoopResult(colNumbersExpression);

      intArray[0] = 1;

      Console.WriteLine("The numbers in the array that are even: (Linq expression)");
      LoopResult(colNumbersExpression);

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // LoopTwiceAnArrayThatIsAResultOfAQuery()

    static void Main()
    //***
    // Action
    //   - Filter a basic array
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - FilterAnArrayOnTheFirst(string)
    //   - FilterAnArrayHavingALetterOnPosition(int)
    //   - FilterAnArrayStartingWith(string)
    //   - LoopAnArrayThatChangesBetweenTwoQueries(string)
    //   - LoopTwiceAListThatIsAResultOfAQuery()
    //   - LoopTwiceAnArrayThatIsAResultOfAQuery()
    // Created
    //   - CopyPaste – 20230413 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230413 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      FilterAnArrayStartingWith("J");
      // FilterAnArrayOnTheFirst("James");
      // FilterAnArrayHavingALetterOnPosition(5);
      // FilterAnArrayHavingALetterOnPosition(9);
      // // The line above will go wrong
      // LoopAnArrayThatChangesBetweenTwoQueries("G");
      // LoopTwiceAnArrayThatIsAResultOfAQuery();
      // LoopTwiceAListThatIsAResultOfAQuery();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram 

}
// LinqToObjects