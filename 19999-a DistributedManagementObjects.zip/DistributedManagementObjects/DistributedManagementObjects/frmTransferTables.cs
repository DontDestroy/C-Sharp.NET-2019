//***
// Action
//   - Form to transfer items (tables) from one database to another
// Created
//   - CopyPaste � 20260717 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260717 � VVDW
// Proposal (To Do)
//   - 
//***

using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTransferTables: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblSQLServerTo;
    internal System.Windows.Forms.ListBox lstToSQLServer;
    internal System.Windows.Forms.Label lblTables;
    internal System.Windows.Forms.ListBox lstTable;
    internal System.Windows.Forms.Label lblDatabaseTo;
    internal System.Windows.Forms.ListBox lstToDatabase;
    internal System.Windows.Forms.Button cmdTransfer;
    internal System.Windows.Forms.Label lblDatabaseFrom;
    internal System.Windows.Forms.ListBox lstFromDatabase;
    internal System.Windows.Forms.Label lblSQLServerFrom;
    internal System.Windows.Forms.ListBox lstFromSQLServer;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTransferTables));
      this.lblSQLServerTo = new System.Windows.Forms.Label();
      this.lstToSQLServer = new System.Windows.Forms.ListBox();
      this.lblTables = new System.Windows.Forms.Label();
      this.lstTable = new System.Windows.Forms.ListBox();
      this.lblDatabaseTo = new System.Windows.Forms.Label();
      this.lstToDatabase = new System.Windows.Forms.ListBox();
      this.cmdTransfer = new System.Windows.Forms.Button();
      this.lblDatabaseFrom = new System.Windows.Forms.Label();
      this.lstFromDatabase = new System.Windows.Forms.ListBox();
      this.lblSQLServerFrom = new System.Windows.Forms.Label();
      this.lstFromSQLServer = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // lblSQLServerTo
      // 
      this.lblSQLServerTo.Location = new System.Drawing.Point(8, 136);
      this.lblSQLServerTo.Name = "lblSQLServerTo";
      this.lblSQLServerTo.Size = new System.Drawing.Size(104, 16);
      this.lblSQLServerTo.TabIndex = 15;
      this.lblSQLServerTo.Text = "To SQL Server";
      // 
      // lstToSQLServer
      // 
      this.lstToSQLServer.Location = new System.Drawing.Point(8, 160);
      this.lstToSQLServer.Name = "lstToSQLServer";
      this.lstToSQLServer.Size = new System.Drawing.Size(104, 82);
      this.lstToSQLServer.TabIndex = 16;
      this.lstToSQLServer.SelectedIndexChanged += new System.EventHandler(this.lstToSQLServer_SelectedIndexChanged);
      // 
      // lblTables
      // 
      this.lblTables.Location = new System.Drawing.Point(288, 16);
      this.lblTables.Name = "lblTables";
      this.lblTables.Size = new System.Drawing.Size(120, 16);
      this.lblTables.TabIndex = 19;
      this.lblTables.Text = "Table(s) to Transfer";
      // 
      // lstTable
      // 
      this.lstTable.Location = new System.Drawing.Point(288, 40);
      this.lstTable.Name = "lstTable";
      this.lstTable.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
      this.lstTable.Size = new System.Drawing.Size(168, 199);
      this.lstTable.TabIndex = 20;
      this.lstTable.SelectedIndexChanged += new System.EventHandler(this.lstTable_SelectedIndexChanged);
      // 
      // lblDatabaseTo
      // 
      this.lblDatabaseTo.Location = new System.Drawing.Point(136, 136);
      this.lblDatabaseTo.Name = "lblDatabaseTo";
      this.lblDatabaseTo.Size = new System.Drawing.Size(120, 16);
      this.lblDatabaseTo.TabIndex = 17;
      this.lblDatabaseTo.Text = "Transfer To Database";
      // 
      // lstToDatabase
      // 
      this.lstToDatabase.Location = new System.Drawing.Point(136, 160);
      this.lstToDatabase.Name = "lstToDatabase";
      this.lstToDatabase.Size = new System.Drawing.Size(136, 82);
      this.lstToDatabase.TabIndex = 18;
      // 
      // cmdTransfer
      // 
      this.cmdTransfer.Enabled = false;
      this.cmdTransfer.Location = new System.Drawing.Point(336, 256);
      this.cmdTransfer.Name = "cmdTransfer";
      this.cmdTransfer.Size = new System.Drawing.Size(120, 32);
      this.cmdTransfer.TabIndex = 21;
      this.cmdTransfer.Text = "&Perform Transfer";
      this.cmdTransfer.Click += new System.EventHandler(this.cmdTransfer_Click);
      // 
      // lblDatabaseFrom
      // 
      this.lblDatabaseFrom.Location = new System.Drawing.Point(136, 16);
      this.lblDatabaseFrom.Name = "lblDatabaseFrom";
      this.lblDatabaseFrom.Size = new System.Drawing.Size(144, 16);
      this.lblDatabaseFrom.TabIndex = 13;
      this.lblDatabaseFrom.Text = "Transfer From Database";
      // 
      // lstFromDatabase
      // 
      this.lstFromDatabase.Location = new System.Drawing.Point(136, 40);
      this.lstFromDatabase.Name = "lstFromDatabase";
      this.lstFromDatabase.Size = new System.Drawing.Size(136, 82);
      this.lstFromDatabase.TabIndex = 14;
      this.lstFromDatabase.SelectedIndexChanged += new System.EventHandler(this.lstFromDatabase_SelectedIndexChanged);
      // 
      // lblSQLServerFrom
      // 
      this.lblSQLServerFrom.Location = new System.Drawing.Point(8, 16);
      this.lblSQLServerFrom.Name = "lblSQLServerFrom";
      this.lblSQLServerFrom.Size = new System.Drawing.Size(104, 16);
      this.lblSQLServerFrom.TabIndex = 11;
      this.lblSQLServerFrom.Text = "From SQL Server";
      // 
      // lstFromSQLServer
      // 
      this.lstFromSQLServer.Location = new System.Drawing.Point(8, 40);
      this.lstFromSQLServer.Name = "lstFromSQLServer";
      this.lstFromSQLServer.Size = new System.Drawing.Size(104, 82);
      this.lstFromSQLServer.TabIndex = 12;
      this.lstFromSQLServer.SelectedIndexChanged += new System.EventHandler(this.lstFromSQLServer_SelectedIndexChanged);
      // 
      // frmTransferTables
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(472, 301);
      this.Controls.Add(this.lblSQLServerTo);
      this.Controls.Add(this.lstToSQLServer);
      this.Controls.Add(this.lblTables);
      this.Controls.Add(this.lstTable);
      this.Controls.Add(this.lblDatabaseTo);
      this.Controls.Add(this.lstToDatabase);
      this.Controls.Add(this.cmdTransfer);
      this.Controls.Add(this.lblDatabaseFrom);
      this.Controls.Add(this.lstFromDatabase);
      this.Controls.Add(this.lblSQLServerFrom);
      this.Controls.Add(this.lstFromSQLServer);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTransferTables";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Transfer Objects Between SQL Server Databases";
      this.Load += new System.EventHandler(this.frmTransferTables_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTransferTables'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTransferTables()
      //***
      // Action
      //   - Create instance of 'frmTransferTables'
      // Called by
      //   - 
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTransferTables()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdTransfer_Click(System.Object theSender, System.EventArgs theEventArguments)
      //'***
      // Action
      //   - Define a number
      //   - Define a transfer
      //   - Define a server
      //   - Define a database
      //   - Try to
      //     - Create an instance to the SQL server from
      //     - Create an instance to the SQL database from
      //     - Create an instance for the transfer
      //     - Set the correct options for the transfer
      //     - Add the selected tables
      //     - Execute the transfer
      //   - On possible error
      //     - Show corresponding messagebox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Database theDatabaseFrom;
      int lngTable;
      Server theSQLServerFrom;
      Transfer theTransfer;

      try
      {
        theSQLServerFrom = new Server(lstFromSQLServer.SelectedItem.ToString());
        theDatabaseFrom = theSQLServerFrom.Databases[lstFromDatabase.SelectedItem.ToString()];
        theTransfer = new Transfer(theDatabaseFrom);

        theTransfer.DestinationServer = lstToSQLServer.SelectedItem.ToString();
        theTransfer.DestinationDatabase = lstToDatabase.SelectedItem.ToString();

        theTransfer.CopyAllObjects = false;
        theTransfer.Options.WithDependencies = true;
        theTransfer.CopySchema = true;
        theTransfer.DropDestinationObjectsFirst = false;
        theTransfer.CopyData = true;

        for (lngTable = 0; lngTable < lstTable.SelectedItems.Count; lngTable++)
        {
          theTransfer.ObjectList.Add(theDatabaseFrom.Tables[lstTable.SelectedItems[lngTable].ToString(), "dbo"]);
        }
        // lngTable = lstTable.SelectedItems.Count

        theTransfer.TransferData();
        MessageBox.Show("Tables Transferred");
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message, "Error Occurred");
      }
      finally
      {
      }

    }
    // cmdTransfer_Click(System.Object, System.EventArgs) Handles cmdTransfer.Click

    private void frmTransferTables_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Load the list of SQL Servers (From)
      //   - Load the list of SQL Servers (To)
      // Called by
      //   - User action (Starting a form)
      // Calls
      //   - cpSQLDMORoutines.LoadSQLServer(�ListBox)
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpSQLDMORoutines.LoadSQLServer(ref lstFromSQLServer);
      cpSQLDMORoutines.LoadSQLServer(ref lstToSQLServer);    
    }
    // frmTransferTables_Load(System.Object, System.EventArgs) Handles MyBase.Load

    private void lstFromDatabase_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Get the tables from the from selected SQL Server Database
      //   - Define and initialize SQL DMO application
      //   - Define a database
      //   - Define and initialize a SQL Server
      //   - Define a table
      //   - Try to
      //     - Set the login security to true
      //     - Connect to the SQL Server with Windows Security
      //     - Set the database to the selected one
      //     - Clear the list of the tables
      //     - Disable cmdTransfer button 
      //     - Loop thru the tables
      //       - If the table is a user table
      //         - Add the table to the list
      //       - If not
      //         - Do nothing
      //   - On possible error
      //     - Show messagebox with corresponding info 
      // Called by
      //   - User action (Choosing an option)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Database theDatabase;
      Server theSQLServer;

      try
      {
        theSQLServer = new Server(lstFromSQLServer.SelectedItem.ToString());
        theSQLServer.ConnectionContext.Connect();
        theDatabase = theSQLServer.Databases[lstFromDatabase.SelectedItem.ToString()];
        lstTable.Items.Clear();
        cmdTransfer.Enabled = false;

        foreach (Table theTable in theDatabase.Tables)
        {

          if (theTable.IsSystemObject)
          {
          }
          else
          // Not theTable.IsSystemObject
          {
            lstTable.Items.Add(theTable.Name);
          }
          // theTable.IsSystemObject

        }
        // in theDatabase.Tables

      }
      catch (Exception theException)
      {
        MessageBox.Show("Error Occurred: " + theException.Message);
      }
      finally
      {
      }

    }
    // lstFromDatabase_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstFromDatabase.SelectedIndexChanged

    private void lstFromSQLServer_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Get SQL databases from the from SQL Server
    // Called by
    //   - User action (Choosing an option)
    // Calls
    //   - cpSQLDMORoutines.GetSQLDatabase(String, �ListBox)
    // Created
    //   - CopyPaste � 20260717 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260717 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      cpSQLDMORoutines.GetSQLDatabase(lstFromSQLServer.SelectedItem.ToString(), ref lstFromDatabase);
    }
    // lstFromSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstFromSQLServer.SelectedIndexChanged

    private void lstTable_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Enable the button cmdTransfer
      // Called by
      //   - User action (Choosing an option)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cmdTransfer.Enabled = true;    
    }
    // lstTables_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstTable.SelectedIndexChanged

    private void lstToSQLServer_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Get SQL databases from the To SQL Server
      // Called by
      //   - User action (Choosing an option)
      // Calls
      //   - cpSQLDMORoutines.GetSQLDatabase(String, �ListBox)
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpSQLDMORoutines.GetSQLDatabase(lstToSQLServer.SelectedItem.ToString(), ref lstToDatabase);
    }
    // lstToSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstToSQLServer.SelectedIndexChanged

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTransferTables

}
// CopyPaste.Learning