﻿//***
// Action
//   - Having transactions in database actions
// Created
//   - CopyPaste – 20210707 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210707 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

namespace TransactionsWizard
{
  partial class frmTransactionsWizard
  {

    #region Windows Form Designer generated code
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    internal System.Windows.Forms.Button cmdRollback;
    internal System.Windows.Forms.Button cmdCommit;
    internal System.Windows.Forms.Button cmdCreate;
    internal System.Windows.Forms.Button cmdNested;
    internal System.Windows.Forms.DataGrid dgrOrder;
    internal System.Windows.Forms.Label lblOrder;
    internal System.Windows.Forms.ListBox lstCustomer;
    internal System.Windows.Forms.Button cmdLoad;
    internal System.Windows.Forms.Label lblCustomer;
    private TransactionsWizard.dsData dsData;
    private System.Windows.Forms.BindingSource bdsrcCustomer;
    private TransactionsWizard.dsDataTableAdapters.tbaCustomer tbaCustomer;
    private TransactionsWizard.dsDataTableAdapters.tbaOrder tbaOrder;
    private System.Windows.Forms.BindingSource bdsrcOrder;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTransactionsWizard));
      this.cmdRollback = new System.Windows.Forms.Button();
      this.cmdCommit = new System.Windows.Forms.Button();
      this.cmdCreate = new System.Windows.Forms.Button();
      this.cmdNested = new System.Windows.Forms.Button();
      this.dgrOrder = new System.Windows.Forms.DataGrid();
      this.bdsrcCustomer = new System.Windows.Forms.BindingSource(this.components);
      this.dsData = new TransactionsWizard.dsData();
      this.lblOrder = new System.Windows.Forms.Label();
      this.lstCustomer = new System.Windows.Forms.ListBox();
      this.cmdLoad = new System.Windows.Forms.Button();
      this.lblCustomer = new System.Windows.Forms.Label();
      this.tbaCustomer = new TransactionsWizard.dsDataTableAdapters.tbaCustomer();
      this.tbaOrder = new TransactionsWizard.dsDataTableAdapters.tbaOrder();
      this.bdsrcOrder = new System.Windows.Forms.BindingSource(this.components);
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCustomer)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcOrder)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdRollback
      // 
      this.cmdRollback.Location = new System.Drawing.Point(304, 138);
      this.cmdRollback.Name = "cmdRollback";
      this.cmdRollback.Size = new System.Drawing.Size(96, 23);
      this.cmdRollback.TabIndex = 17;
      this.cmdRollback.Text = "Rollback";
      this.cmdRollback.Click += new System.EventHandler(this.cmdRollback_Click);
      // 
      // cmdCommit
      // 
      this.cmdCommit.Location = new System.Drawing.Point(304, 106);
      this.cmdCommit.Name = "cmdCommit";
      this.cmdCommit.Size = new System.Drawing.Size(96, 23);
      this.cmdCommit.TabIndex = 16;
      this.cmdCommit.Text = "Commit";
      this.cmdCommit.Click += new System.EventHandler(this.cmdCommit_Click);
      // 
      // cmdCreate
      // 
      this.cmdCreate.Location = new System.Drawing.Point(304, 42);
      this.cmdCreate.Name = "cmdCreate";
      this.cmdCreate.Size = new System.Drawing.Size(96, 23);
      this.cmdCreate.TabIndex = 14;
      this.cmdCreate.Text = "Create";
      this.cmdCreate.Click += new System.EventHandler(this.cmdCreate_Click);
      // 
      // cmdNested
      // 
      this.cmdNested.Location = new System.Drawing.Point(304, 74);
      this.cmdNested.Name = "cmdNested";
      this.cmdNested.Size = new System.Drawing.Size(96, 23);
      this.cmdNested.TabIndex = 15;
      this.cmdNested.Text = "Create Nested";
      this.cmdNested.Click += new System.EventHandler(this.cmdNested_Click);
      // 
      // dgrOrder
      // 
      this.dgrOrder.DataMember = "";
      this.dgrOrder.DataSource = this.bdsrcOrder;
      this.dgrOrder.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrOrder.Location = new System.Drawing.Point(8, 146);
      this.dgrOrder.Name = "dgrOrder";
      this.dgrOrder.Size = new System.Drawing.Size(280, 128);
      this.dgrOrder.TabIndex = 12;
      // 
      // bdsrcCustomer
      // 
      this.bdsrcCustomer.DataMember = "tblCPCustomer";
      this.bdsrcCustomer.DataSource = this.dsData;
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // lblOrder
      // 
      this.lblOrder.AutoSize = true;
      this.lblOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOrder.Location = new System.Drawing.Point(8, 130);
      this.lblOrder.Name = "lblOrder";
      this.lblOrder.Size = new System.Drawing.Size(48, 13);
      this.lblOrder.TabIndex = 11;
      this.lblOrder.Text = "Orders:";
      // 
      // lstCustomer
      // 
      this.lstCustomer.DataSource = this.bdsrcCustomer;
      this.lstCustomer.DisplayMember = "strCompanyName";
      this.lstCustomer.Location = new System.Drawing.Point(8, 26);
      this.lstCustomer.Name = "lstCustomer";
      this.lstCustomer.Size = new System.Drawing.Size(280, 95);
      this.lstCustomer.TabIndex = 10;
      this.lstCustomer.ValueMember = "strIdCustomer";
      // 
      // cmdLoad
      // 
      this.cmdLoad.Location = new System.Drawing.Point(304, 10);
      this.cmdLoad.Name = "cmdLoad";
      this.cmdLoad.Size = new System.Drawing.Size(96, 23);
      this.cmdLoad.TabIndex = 13;
      this.cmdLoad.Text = "Load Data";
      this.cmdLoad.Click += new System.EventHandler(this.cmdLoad_Click);
      // 
      // lblCustomer
      // 
      this.lblCustomer.AutoSize = true;
      this.lblCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblCustomer.Location = new System.Drawing.Point(8, 10);
      this.lblCustomer.Name = "lblCustomer";
      this.lblCustomer.Size = new System.Drawing.Size(69, 13);
      this.lblCustomer.TabIndex = 9;
      this.lblCustomer.Text = "Customers:";
      // 
      // tbaCustomer
      // 
      this.tbaCustomer.ClearBeforeFill = true;
      // 
      // tbaOrder
      // 
      this.tbaOrder.ClearBeforeFill = true;
      // 
      // bdsrcOrder
      // 
      this.bdsrcOrder.DataMember = "FK_tblCPOrder_tblCPCustomer";
      this.bdsrcOrder.DataSource = this.bdsrcCustomer;
      // 
      // frmTransactionsWizard
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(408, 285);
      this.Controls.Add(this.cmdRollback);
      this.Controls.Add(this.cmdCommit);
      this.Controls.Add(this.cmdCreate);
      this.Controls.Add(this.cmdNested);
      this.Controls.Add(this.dgrOrder);
      this.Controls.Add(this.lblOrder);
      this.Controls.Add(this.lstCustomer);
      this.Controls.Add(this.cmdLoad);
      this.Controls.Add(this.lblCustomer);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTransactionsWizard";
      this.Text = "Transactions Wizard";
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCustomer)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcOrder)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210707 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      // (disposing && (components != null))

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmTransactionsWizard
}
// TransactionsWizard
