//***
// Action
//   - Find information abount bancaccounts
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFindAmountAccount: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdAddAccountClient;
    internal System.Windows.Forms.TextBox txtClientName;
    internal System.Windows.Forms.TextBox txtAccount;
    internal System.Windows.Forms.Label lblClientName;
    internal System.Windows.Forms.Button cmdFindInfo;
    internal System.Windows.Forms.Label lblStatus;
    internal System.Windows.Forms.Button cmdFindAmount;
    internal System.Windows.Forms.Label lblAccount;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFindAmountAccount));
      this.cmdAddAccountClient = new System.Windows.Forms.Button();
      this.txtClientName = new System.Windows.Forms.TextBox();
      this.txtAccount = new System.Windows.Forms.TextBox();
      this.lblClientName = new System.Windows.Forms.Label();
      this.cmdFindInfo = new System.Windows.Forms.Button();
      this.lblStatus = new System.Windows.Forms.Label();
      this.cmdFindAmount = new System.Windows.Forms.Button();
      this.lblAccount = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdAddAccountClient
      // 
      this.cmdAddAccountClient.Location = new System.Drawing.Point(288, 48);
      this.cmdAddAccountClient.Name = "cmdAddAccountClient";
      this.cmdAddAccountClient.Size = new System.Drawing.Size(104, 23);
      this.cmdAddAccountClient.TabIndex = 14;
      this.cmdAddAccountClient.Text = "Add Client";
      this.cmdAddAccountClient.Click += new System.EventHandler(this.cmdAddAccountClient_Click);
      // 
      // txtClientName
      // 
      this.txtClientName.Location = new System.Drawing.Point(288, 16);
      this.txtClientName.Name = "txtClientName";
      this.txtClientName.Size = new System.Drawing.Size(104, 20);
      this.txtClientName.TabIndex = 13;
      this.txtClientName.Text = "";
      // 
      // txtAccount
      // 
      this.txtAccount.Location = new System.Drawing.Point(72, 16);
      this.txtAccount.Name = "txtAccount";
      this.txtAccount.Size = new System.Drawing.Size(104, 20);
      this.txtAccount.TabIndex = 9;
      this.txtAccount.Text = "";
      // 
      // lblClientName
      // 
      this.lblClientName.Location = new System.Drawing.Point(208, 16);
      this.lblClientName.Name = "lblClientName";
      this.lblClientName.Size = new System.Drawing.Size(72, 23);
      this.lblClientName.TabIndex = 12;
      this.lblClientName.Text = "Client name";
      // 
      // cmdFindInfo
      // 
      this.cmdFindInfo.Location = new System.Drawing.Point(72, 80);
      this.cmdFindInfo.Name = "cmdFindInfo";
      this.cmdFindInfo.Size = new System.Drawing.Size(104, 23);
      this.cmdFindInfo.TabIndex = 11;
      this.cmdFindInfo.Text = "Find Info";
      this.cmdFindInfo.Click += new System.EventHandler(this.cmdFindInfo_Click);
      // 
      // lblStatus
      // 
      this.lblStatus.Location = new System.Drawing.Point(8, 208);
      this.lblStatus.Name = "lblStatus";
      this.lblStatus.Size = new System.Drawing.Size(304, 56);
      this.lblStatus.TabIndex = 15;
      // 
      // cmdFindAmount
      // 
      this.cmdFindAmount.Location = new System.Drawing.Point(72, 48);
      this.cmdFindAmount.Name = "cmdFindAmount";
      this.cmdFindAmount.Size = new System.Drawing.Size(104, 23);
      this.cmdFindAmount.TabIndex = 10;
      this.cmdFindAmount.Text = "Find Amount";
      this.cmdFindAmount.Click += new System.EventHandler(this.cmdFindAmount_Click);
      // 
      // lblAccount
      // 
      this.lblAccount.Location = new System.Drawing.Point(8, 16);
      this.lblAccount.Name = "lblAccount";
      this.lblAccount.Size = new System.Drawing.Size(64, 23);
      this.lblAccount.TabIndex = 8;
      this.lblAccount.Text = "Account";
      // 
      // frmFindAmountAccount
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(576, 273);
      this.Controls.Add(this.cmdAddAccountClient);
      this.Controls.Add(this.txtClientName);
      this.Controls.Add(this.txtAccount);
      this.Controls.Add(this.lblClientName);
      this.Controls.Add(this.cmdFindInfo);
      this.Controls.Add(this.lblStatus);
      this.Controls.Add(this.cmdFindAmount);
      this.Controls.Add(this.lblAccount);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFindAmountAccount";
      this.Text = "Find Amount Account";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFindAmountAccount'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFindAmountAccount()
      //***
      // Action
      //   - Create new instance of 'frmFindAmountAccount'
      // Called by
      //   - frmFindAmountAccount.cmdFindAmountAccount_Click(System.Object, System.EventArgs) Handles cmdFindAmountAccount.Click
      //   - User action (Starting the form)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
    }
    // frmFindAmountAccount()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAddAccountClient_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Create a new instance of cpCommand
      //     - If clientname textbox is empty
      //       - Show status on form that there is no clientname given
      //     - If not
      //       - Add the account
      //   - On possible error
      //     - Show exception message on the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpCommand()
      //   - System.Int32 cpCommand.AddAccountClient(string)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        cpCommand thecpCommand = new cpCommand();
        
        if (txtClientName.Text == "")
        {
          lblStatus.Text = "There is no clientname to add";
        }
        else
          // txtClientName.Text = ""
        {
          lblStatus.Text = thecpCommand.AddAccountClient(txtClientName.Text).ToString();
        }
        // txtClientName.Text = ""
           
      }
      catch (Exception theException)
      {
        lblStatus.Text = theException.Message;
      }
      finally
      {
      }
    
    }
    // cmdAddAccountClient_Click(System.Object, System.EventArgs) Handles cmdAddAccountClient.Click

    private void cmdFindAmount_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Create a new instance of cpCommand
      //     - Define a cpInfoAccount
      //     - If account textbox is empty
      //       - Show status on form that there is no account given
      //     - If not
      //       - Find the amount of the account
      //   - On possible error
      //     - Show exception message on the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpCommand()
      //   - cpCommand.FindAmountAccount(string)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        cpCommand thecpCommand = new cpCommand();

        if (txtAccount.Text == "")
        {
          lblStatus.Text = "There is no account";
        }
        else
          // txtAccount.Text <> ""
        {
          lblStatus.Text = thecpCommand.FindAmountAccount(txtAccount.Text).ToString();
        }
        // txtAccount.Text = ""

      }
      catch (Exception theException)
      {
        lblStatus.Text = theException.Message;
      }
      finally
      {
      }
    
    }
    // cmdFindAmount_Click(System.Object, System.EventArgs) Handles cmdFindAmount.Click

    private void cmdFindInfo_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Create a new instance of cpCommand
      //     - Define a cpInfoAccount
      //     - If account textbox is empty
      //       - Show status on form that there is no account given
      //   - On possible error
      //     - Show exception message on the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpCommand()
      //   - cpInfoAccount cpCommand.FindInfoAccount(string)
      //   - decimal cpInfoAccount.Amount (Get)
      //   - string cpInfoAccount.ClientName (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      
      try
      {
        cpCommand thecpCommand = new cpCommand();
        cpInfoAccount thecpInfoAccount;

        if (txtAccount.Text == "")
        {
          lblStatus.Text = "There is no account";
        }
        else
          // txtAccount.Text <> ""
        {
          thecpInfoAccount = thecpCommand.FindInfoAccount(txtAccount.Text);
          lblStatus.Text = thecpInfoAccount.ClientName + ": " + thecpInfoAccount.Amount;
        }
        // txtAccount.Text = ""

      }
      catch (Exception theException)
      {
        lblStatus.Text = theException.Message;
      }
      finally
      {
      }
    
    }
    // cmdFindInfo_Click(System.Object, System.EventArgs) Handles cmdFindInfo.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmFindAmountAccount

}
// CopyPaste.Learning