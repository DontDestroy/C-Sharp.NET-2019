﻿//***
// Action
//   - Demo of using a PostBackUrl
//   - The starting point is in wfrmPost1
// Created
//   - CopyPaste – 20260720 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260720 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmPost2 : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.ID = "wfrmPost2";
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when the page is initialized
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - If form is started the first time
    //       - Get the 2 values out of the request form and put them in the corresponding labels
    //     - If not
    //       - Show corresponding error message
    //   - On possible error
    //     - Show corresponding error message
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {


      try
      {

        if (IsPostBack || Request.Form["txtName"] == null)
        {
          lblName.Text = "Page not correctly loaded";
          lblEmail.Text = "";
        }
        else
        // Not IsPostBack And Request.Form["txtName"] <> null
        {
          lblName.Text = Request.Form["txtName"];
          lblEmail.Text = Request.Form["txtEmail"];
        }
        // IsPostBack Or Request.Form["txtName"] = null

      }
      catch
      {
        lblName.Text = "Page not correctly loaded";
        lblEmail.Text = "";
      }

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmPost2

}
// CopyPaste.Learning