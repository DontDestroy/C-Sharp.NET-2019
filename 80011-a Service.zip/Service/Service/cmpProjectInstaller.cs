//***
// Action
//   - Project installer of cpService
// Created
//   - CopyPaste � 20260831 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260831 � VVDW
// Proposal (To Do)
//   - To be able to install, Visual Studio must be started wit Administrator privileges
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;

namespace CopyPaste.Learning
{

	[RunInstallerAttribute(true)]
	public class cmpProjectInstaller : System.Configuration.Install.Installer
	{

    #region Component Designer generated code
    
    private System.ComponentModel.Container components = null;
    internal System.ServiceProcess.ServiceInstaller sicpService;
    private System.ServiceProcess.ServiceProcessInstaller spicpService;

    private void InitializeComponent()
    {
      this.sicpService = new System.ServiceProcess.ServiceInstaller();
      this.spicpService = new System.ServiceProcess.ServiceProcessInstaller();
      // 
      // sicpService
      // 
      this.sicpService.ServiceName = "cpService";
      // 
      // spicpService
      // 
      this.spicpService.Account = System.ServiceProcess.ServiceAccount.LocalSystem;
      this.spicpService.Password = "tryout123";
      this.spicpService.Username = "administrator";
      // 
      // cmpProjectInstaller
      // 
      this.Installers.AddRange(new System.Configuration.Install.Installer[] {
                                                                              this.sicpService,
                                                                              this.spicpService});

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cmpProjectInstaller'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260831 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260831 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cmpProjectInstaller()
      //***
      // Action
      //   - Create instance of 'cmpProjectInstaller'
      // Called by
      //   - User action (Starting the project installer)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260831 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260831 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

	}
  // cmpProjectInstaller

}
// CopyPaste.Learning