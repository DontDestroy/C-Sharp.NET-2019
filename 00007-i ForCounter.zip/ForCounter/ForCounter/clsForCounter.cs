//***
// Action
//   - For ... Next
// Created
//   - CopyPaste � 20220119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220119 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace ForCounter
{

  class cpForCounter
	{

    static void Main()
    //***
    // Action
    //   - Loop write 5 times
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.Write(String)
    // Created
    //   - CopyPaste � 20220119 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220119 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter;
      
      for (lngCounter = 2; lngCounter <= 10; lngCounter = lngCounter + 2)
      {
        Console.Write(lngCounter + " ");
      }
      // lngCounter = 12

      Console.ReadLine();
		}
    // Main()

  }
  // cpForCounter

}
// ForCounter