//***
// Action
//   - Implementation of cpBase
// Created
//   - CopyPaste � 20240531 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240531 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpBase
  {

    #region "Constructors / Destructors"

    public cpBase()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - cpDerived()
      //   - cpProgram.Main()
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpBase()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public virtual string Message()
      //***
      // Action
      //   - Shows a message from the base class
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "Hello, World from Base Class";
    }
		// string Message()

    public virtual string OtherMessage()
      //***
      // Action
      //   - Shows a message from the base class
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "Base Class Other Message";
    }
    // string Message()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBase

}
// CopyPaste.Learning