//***
// Action
//   - Show process information on the running program
// Created
//   - CopyPaste � 20250629 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250629 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Diagnostics;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - xxxx
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Show information about the current process
      //   - BasePriority, HandleCount, Id, MachineName, MainModule
      //   - MainWindowTitle, MaxWorkingSet, MinWorkingSet, Modules
      //   - NonpagedSystemMemorySize, PeakPagedMemorySize, PeakWorkingSet
      //   - PriorityBoostEnabled, PriorityClass, PrivateMemorySize
      //   - PrivilegedProcessorTime, ProcessName, ProcessorAffinity
      //   - StartTime, TotalProcessorTime, UserProcessorTime, VirtualMemorySize, WorkingSet
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - xxxx
      // Created
      //   - CopyPaste � 20250629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250629 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Process theProcess = new Process();

      theProcess = Process.GetCurrentProcess();
      
      Console.WriteLine("Base Priority: {0}", theProcess.BasePriority);
      Console.WriteLine("Handle count: {0}", theProcess.HandleCount);
      Console.WriteLine("Process ID (PID): {0}", theProcess.Id);
      Console.WriteLine("Machine Name: {0}", theProcess.MachineName);
      Console.WriteLine("Main Module: {0}", theProcess.MainModule);
      Console.WriteLine("Main Window Title: {0}", theProcess.MainWindowTitle);
      Console.WriteLine("Max Working Set: {0}", theProcess.MaxWorkingSet);
      Console.WriteLine("Min Working Set: {0}", theProcess.MinWorkingSet);
      Console.WriteLine("Modules: {0}", theProcess.Modules);
      Console.WriteLine("Nonpage System Memory Size: {0}", theProcess.NonpagedSystemMemorySize);
      Console.WriteLine("Paged Memory Size: {0}", theProcess.PagedMemorySize);
      Console.WriteLine("Paged System Memory Size: {0}", theProcess.PagedSystemMemorySize);
      Console.WriteLine("Peak Paged Memory Size: {0}", theProcess.PeakPagedMemorySize);
      Console.WriteLine("Peak Virtual Memory Size: {0}", theProcess.PeakVirtualMemorySize);
      Console.WriteLine("Peak Working Set: {0}", theProcess.PeakWorkingSet);
      Console.WriteLine("Priority Boost Enabled: {0}", theProcess.PriorityBoostEnabled);
      Console.WriteLine("Priority Class: {0}", theProcess.PriorityClass);
      Console.WriteLine("Private Memory Size: {0}", theProcess.PrivateMemorySize);
      Console.WriteLine("Priviledged Processsor Time: {0}", theProcess.PrivilegedProcessorTime);
      Console.WriteLine("Name: {0}", theProcess.ProcessName);
      Console.WriteLine("Processor Affinity: {0}", theProcess.ProcessorAffinity);
      Console.WriteLine("Start Time: {0}", theProcess.StartTime);
      Console.WriteLine("Total Processor Time: {0}", theProcess.TotalProcessorTime);
      Console.WriteLine("User Processor Time: {0}", theProcess.UserProcessorTime);
      Console.WriteLine("Virtual Memory Size: {0}", theProcess.VirtualMemorySize);
      Console.WriteLine("Working Set: {0}", theProcess.WorkingSet);

      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning