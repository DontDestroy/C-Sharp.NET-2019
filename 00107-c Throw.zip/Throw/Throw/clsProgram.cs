//***
// Action
//   - Testroutine for cpCopyMachine
// Created
//   - CopyPaste � 20230821 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230821 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Company.Material
{
	
  public class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Define a cpCopyMachine
      //   - On any error, show the error messages
      //   - End the program by hitting any key
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpCopyMachine()
      //   - PageCost(decimal) (Set)
      //   - NumberOfPages(int) (Set)
      // Created
      //   - CopyPaste � 20230821 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230821 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        cpCopyMachine thecpCopyMachine = new cpCopyMachine();

        thecpCopyMachine.PageCost = 0.025M;
        // thecpCopyMachine.PageCost = -0.025M;
        thecpCopyMachine.NumberOfPages = 100;
        // thecpCopyMachine.NumberOfPages = -10;
        Console.WriteLine("Machine is correct initialized");
      }
      catch (Exception theException)
      {
        Console.WriteLine();
        Console.WriteLine("Error: " + theException.Message);
      }
      finally
      {
        Console.WriteLine();
        Console.WriteLine("End Program");
        Console.ReadLine();
      }

    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion
    
	}
  // cpProgram

}
// Company.Material