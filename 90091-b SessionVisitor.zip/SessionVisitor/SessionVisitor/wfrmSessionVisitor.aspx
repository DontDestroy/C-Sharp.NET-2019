﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmSessionVisitor.aspx.cs" Inherits="CopyPaste.Learning.wfrmSessionVisitor" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/html">
<head runat="server">
    <title>Count the Visitors</title>
</head>
<body>
  <form id="wfrmSessionVisitor" method="post" runat="server">
    <asp:Label ID="lblNumberOfVisitors" Style="z-index: 101; left: 32px; position: absolute; top: 24px"
      runat="server"></asp:Label>
    <asp:Label ID="lblNumberOfVisitorsAtThisMoment" Style="z-index: 102; left: 32px; position: absolute; top: 64px"
      runat="server"></asp:Label>
  </form>
</body>
</html>
