﻿//***
// Action
//   - Implementation of a cpWeapon
//		 - The way an axe can be used
// Created
//   - CopyPaste – 20240806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240806 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Weapon.Library
{

	public class cpAxe : cpiWeapon
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpAxe
		/// </summary>
		public cpAxe()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - CopyPaste.Game.Character.Library.cpTroll()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpAxe()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how an axe is used to fight
		/// </summary>
		public void UseWeapon()
		//***
		// Action
		//   - Define how an axe is used to fight
		// Called by
		//   - cpKing() (indirectly, thru delegate)
		//   - cpKnight() (indirectly, thru delegate)
		//   - cpQueen() (indirectly, thru delegate)
		//   - cpTroll() (indirectly, thru delegate)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Chopping with an axe");
		}
		// UseWeapon()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpAxe

}
// CopyPaste.Game.Weapon.Library