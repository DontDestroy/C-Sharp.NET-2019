//***
// Action
//   - Read data from a binary format
// Created
//   - CopyPaste � 20240621 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240621 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Try
      //     - Create a file stream
      //   - When an error occurs
      //     - Show personal error message
      //     - Show technical error message
      //   - Create binary writer
      //   - Try
      //     - Read a double, integer and string from the file
      //     - Show the read information
      //   - When an error occurs
      //     - Show personal error message
      //     - Show technical error message
      //   - Close the file
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240621 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240621 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      FileStream theFileStream = null;

      try
      {
        theFileStream = new FileStream("T:\\Binary.dat", FileMode.Open);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error opening T:\\Binary.Dat");
        Console.WriteLine("Error {0}", theException.Message);
      }
      finally
      {
      }

      double dblSalary;
      int lngAge;
      string strName;
      BinaryReader theBinaryReader = new BinaryReader(theFileStream);

      try
      {
        lngAge = theBinaryReader.ReadInt32();
        dblSalary = theBinaryReader.ReadDouble();
        strName = theBinaryReader.ReadString();
        theBinaryReader.Close();

        Console.WriteLine("Age: {0}", lngAge);
        Console.WriteLine("Salary: {0}", dblSalary);
        Console.WriteLine("Name: {0}", strName);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error reading to T:\\Binary.Dat");
        Console.WriteLine("Error {0}", theException.Message);
      }
      finally
      {
      }

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx