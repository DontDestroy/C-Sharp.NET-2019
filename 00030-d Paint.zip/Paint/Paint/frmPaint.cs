//***
// Action
//   - Having a panel on top of the screen
//   - Having different options to draw stuff on the screen
// Created
//   - CopyPaste � 20230614 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230614 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Paint
{

  public class frmPaint : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

	  internal System.Windows.Forms.Panel panToolbar;
	  internal System.Windows.Forms.Button cmdQuit;
	  internal System.Windows.Forms.Button cmdClear;
	  internal System.Windows.Forms.ComboBox cmbSize;
	  internal System.Windows.Forms.ComboBox cmbFigure;
	  internal System.Windows.Forms.ComboBox cmbColor;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPaint));
      this.panToolbar = new System.Windows.Forms.Panel();
      this.cmdQuit = new System.Windows.Forms.Button();
      this.cmdClear = new System.Windows.Forms.Button();
      this.cmbSize = new System.Windows.Forms.ComboBox();
      this.cmbFigure = new System.Windows.Forms.ComboBox();
      this.cmbColor = new System.Windows.Forms.ComboBox();
      this.panToolbar.SuspendLayout();
      this.SuspendLayout();
      // 
      // panToolbar
      // 
      this.panToolbar.BackColor = System.Drawing.SystemColors.Control;
      this.panToolbar.Controls.Add(this.cmdQuit);
      this.panToolbar.Controls.Add(this.cmdClear);
      this.panToolbar.Controls.Add(this.cmbSize);
      this.panToolbar.Controls.Add(this.cmbFigure);
      this.panToolbar.Controls.Add(this.cmbColor);
      this.panToolbar.Dock = System.Windows.Forms.DockStyle.Top;
      this.panToolbar.Location = new System.Drawing.Point(0, 0);
      this.panToolbar.Name = "panToolbar";
      this.panToolbar.Size = new System.Drawing.Size(640, 40);
      this.panToolbar.TabIndex = 1;
      // 
      // cmdQuit
      // 
      this.cmdQuit.Location = new System.Drawing.Point(552, 8);
      this.cmdQuit.Name = "cmdQuit";
      this.cmdQuit.TabIndex = 4;
      this.cmdQuit.Text = "Quit";
      this.cmdQuit.Click += new System.EventHandler(this.cmdQuit_Click);
      // 
      // cmdClear
      // 
      this.cmdClear.Location = new System.Drawing.Point(464, 8);
      this.cmdClear.Name = "cmdClear";
      this.cmdClear.TabIndex = 3;
      this.cmdClear.Text = "Clear";
      this.cmdClear.Click += new System.EventHandler(this.cmdClear_Click);
      // 
      // cmbSize
      // 
      this.cmbSize.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbSize.Location = new System.Drawing.Point(280, 8);
      this.cmbSize.Name = "cmbSize";
      this.cmbSize.Size = new System.Drawing.Size(112, 21);
      this.cmbSize.TabIndex = 2;
      this.cmbSize.SelectedIndexChanged += new System.EventHandler(this.cmbSize_SelectedIndexChanged);
      // 
      // cmbFigure
      // 
      this.cmbFigure.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbFigure.Location = new System.Drawing.Point(8, 8);
      this.cmbFigure.Name = "cmbFigure";
      this.cmbFigure.Size = new System.Drawing.Size(121, 21);
      this.cmbFigure.TabIndex = 0;
      // 
      // cmbColor
      // 
      this.cmbColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
      this.cmbColor.Location = new System.Drawing.Point(144, 8);
      this.cmbColor.Name = "cmbColor";
      this.cmbColor.Size = new System.Drawing.Size(121, 21);
      this.cmbColor.TabIndex = 1;
      this.cmbColor.SelectedIndexChanged += new System.EventHandler(this.cmbColor_SelectedIndexChanged);
      // 
      // frmPaint
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(640, 509);
      this.Controls.Add(this.panToolbar);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPaint";
      this.Text = "Paint";
      this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.frmPaint_MouseDown);
      this.Load += new System.EventHandler(this.frmPaint_Load);
      this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.frmPaint_MouseMove);
      this.panToolbar.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPaint'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPaint()
      //***
      // Action
      //   - Create instance of 'frmPaint'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPaint()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
		Brush mtheBrush = Brushes.Black;
		int mlngDrawSize;
		Pen mthePen = Pens.Black;

	  #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

		private void cmbColor_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
		//***
		// Action
		//   - Depending on the chosen option
		//     - Change the color of the pen and brush 
		// Called by
		//   - User action (Selecting an option of the combobox)
		// Calls
		//   - 
		// Created
		//   - CopyPaste � 20230614 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20230614 � VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			switch (cmbColor.Text)
			{
			
				case "Black":
					mthePen = Pens.Black;
					mtheBrush = Brushes.Black;
					break;
				case "Blue":
					mthePen = Pens.Blue;
					mtheBrush = Brushes.Blue;
					break;
				case "Violet":
					mthePen = Pens.Violet;
					mtheBrush = Brushes.Violet;
					break;
				case "Green":
					mthePen = Pens.Green;
					mtheBrush = Brushes.Green;
					break;
				case "Red":
					mthePen = Pens.Red;
					mtheBrush = Brushes.Red;
					break;
				case "Orange":
					mthePen = Pens.Orange;
					mtheBrush = Brushes.Orange;
					break;
				case "Yellow":
					mthePen = Pens.Yellow;
					mtheBrush = Brushes.Yellow;
					break;
				case "White":
					mthePen = Pens.White;
					mtheBrush = Brushes.White;
					break;
			}
			// cmbColor.Text
		
		}
		// cmbColor_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbColor.SelectedIndexChanged

		private void cmbSize_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
		//***
		// Action
		//   - Change the draw size
		// Called by
		//   - User action (Selecting an option of the combobox)
		// Calls
		//   - 
		// Created
		//   - CopyPaste � 20230614 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20230614 � VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
	  {
  		mlngDrawSize = Convert.ToInt32(cmbSize.Text);
		}
		// cmbSize_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbSize.SelectedIndexChanged

    private void cmdClear_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Remove all the paint from the screen
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Graphics theGraphic = CreateGraphics();
 
      theGraphic.Clear(ActiveForm.BackColor);
      theGraphic.Dispose();
    }
    // cmdClear_Click(System.Object, System.EventArgs) Handles cmdClear.Click

    private void cmdQuit_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Stop the application
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      this.Close();
    }
    // cmdQuit_Click(System.Object, System.EventArgs) Handles cmdQuit.Click

		private void frmPaint_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Fill the options for the color
    //   - Select first option
    //   - Fill the options for the figure
    //   - Select first option
    //   - Fill the options for the size
    //   - Select first option
    // Called by
    //   - User action (Starting the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      cmbColor.Items.Add("Black");
      cmbColor.Items.Add("Blue");
      cmbColor.Items.Add("Violet");
      cmbColor.Items.Add("Green");
      cmbColor.Items.Add("Red");
      cmbColor.Items.Add("Orange");
      cmbColor.Items.Add("Yellow");
      cmbColor.Items.Add("White");
      cmbColor.SelectedIndex = 0;

      cmbFigure.Items.Add("Circle");
      cmbFigure.Items.Add("Square");
      cmbFigure.Items.Add("Pie");
      cmbFigure.Items.Add("FilledCircle");
      cmbFigure.Items.Add("FilledSquare");
      cmbFigure.Items.Add("FilledPie");
      cmbFigure.SelectedIndex = 0;

      cmbSize.Items.Add("2");
      cmbSize.Items.Add("4");
      cmbSize.Items.Add("8");
      cmbSize.Items.Add("16");
      cmbSize.Items.Add("32");
      cmbSize.Items.Add("64");
      cmbSize.SelectedIndex = 0;
    }
    // frmPaint_Load(System.Object, System.EventArgs) Handles this.Load
    
    private void frmPaint_MouseDown(System.Object theSender, System.Windows.Forms.MouseEventArgs theMouseEventArguments)
    //***
    // Action
    //   - If the user clicks with the left mousebutton (the normal button)
    //     - Start the event MouseMove
    // Called by
    //   - User action (Clicking the mouse)
    // Calls
    //   - frmPaint_MouseMove(System.Object, System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseMove
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      if (theMouseEventArguments.Button == MouseButtons.Left)
      {
        frmPaint_MouseMove(theSender, theMouseEventArguments);
      }
      else
        // theMouseEventArguments.Button <> MouseButtons.Left
      {
      }
      // theMouseEventArguments.Button = MouseButtons.Left
    
    }
    // frmPaint_MouseDown(System.Object, System.Windows.Forms.MouseEventArgs) Handles frmPaint.MouseDown

    private void frmPaint_MouseMove(System.Object theSender, System.Windows.Forms.MouseEventArgs theMouseEventArguments)
    //***
    // Action
    //   - If the user stops clicking with the left mousebutton (the normal button)
    //     - Exit the routine
    //   - Create a graphic
    //   - Depending on the option of the figure
    //     - Draw a Circle (only borders) in the selected color and size
    //     - Draw a Square (only borders) in the selected color and size
    //     - Draw a Pie (only borders) in the selected color and size
    //     - Draw a Circle (filled) in the selected color and size
    //     - Draw a Square (filled) in the selected color and size
    //     - Draw a Pie (filled) in the selected color and size
    // Called by
    //   - frmPaint_MouseDown(System.Object, System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
    //   - User action (Clicking the mouse)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      if (theMouseEventArguments.Button == MouseButtons.Left)
      {
      }
      else
        // theMouseEventArguments.Button <> MouseButtons.Left
      {
        return;
      }
      // theMouseEventArguments.Button = MouseButtons.Left

    Graphics theGraphic = CreateGraphics();

      switch (cmbFigure.Text)
      {
        case "Circle":
          theGraphic.DrawEllipse(mthePen, theMouseEventArguments.X, theMouseEventArguments.Y, mlngDrawSize, mlngDrawSize);
          break;
        case "Square":
          theGraphic.DrawRectangle(mthePen, theMouseEventArguments.X, theMouseEventArguments.Y, mlngDrawSize, mlngDrawSize);
          break;
        case "Pie":
          theGraphic.DrawPie(mthePen, theMouseEventArguments.X, theMouseEventArguments.Y, mlngDrawSize, mlngDrawSize, 90, 270);
          break;
        case "FilledCircle":
          theGraphic.FillEllipse(mtheBrush, theMouseEventArguments.X, theMouseEventArguments.Y, mlngDrawSize, mlngDrawSize);
          break;
        case "FilledSquare":
          theGraphic.FillRectangle(mtheBrush, theMouseEventArguments.X, theMouseEventArguments.Y, mlngDrawSize, mlngDrawSize);
          break;
        case "FilledPie":
          theGraphic.FillPie(mtheBrush, theMouseEventArguments.X, theMouseEventArguments.Y, mlngDrawSize, mlngDrawSize, 90, 270);
          break;
      }
      // cmbFigure.Text
   
    }
    // frmPaint_MouseMove(System.Object, System.Windows.Forms.MouseEventArgs) Handles frmPaint.MouseMove

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPaint
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPaint());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmPaint

}
// Paint