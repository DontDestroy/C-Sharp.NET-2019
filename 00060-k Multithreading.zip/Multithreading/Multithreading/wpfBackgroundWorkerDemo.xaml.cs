//***
// Action
//   - Code for wpfBackgroundWorkerDemo
//   - A test in threading, running some time consuming code in the background
// Created
//   - CopyPaste � 20220818 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220818 � VVDW
// Proposal (To Do)
//   -
//***

using System.ComponentModel;
using System.Windows;

namespace Multithreading
{

  public partial class wpfBackgroundWorkerDemo : System.Windows.Window
  {

    #region "Constructors / Destructors"

    public wpfBackgroundWorkerDemo()
    //***
    // Action
    //   - Create new instance of 'wpfBackgroundWorkerDemo'
    // Called by
    //   - User action (Starting the form)
    //   - wpfBackgroundWorkerDemo.cmdBackgroundWorker_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdBackgroundWorker.Click
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      InitializeComponent();

      // theBackgroundWorker is defined in the XAML
      theBackgroundWorker = ((BackgroundWorker)this.FindResource("backgroundWorkerDemo"));
    }
    // wpfBackgroundWorkerDemo()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private BackgroundWorker theBackgroundWorker;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void backgroundWorkerDemo_DoWork(System.Object theSender, System.ComponentModel.DoWorkEventArgs theDoWorkEventArguments)
    //***
    // Action
    //   - The work that must be done by the background worker
    //     - Get the input values
    //     - Start the search for primes and wait
    //     - Return the result
    //   - Work can be cancelled during the process
    // Called by
    //   - System action (The actual background worker work)
    // Calls
    //   - uint cpFindPrimesInput.From (Get)
    //   - uint cpFindPrimesInput.To (Get)
    //   - uint[] cpSieveOfEratosthenes.FindPrimes(uint, uint, System.ComponentModel.BackgroundWorker)
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpFindPrimesInput inputPrimesRange = (cpFindPrimesInput)theDoWorkEventArguments.Argument;

      uint[] arrintPrime = cpSieveOfEratosthenes.FindPrimes(inputPrimesRange.From, inputPrimesRange.To, theBackgroundWorker);

      if (theBackgroundWorker.CancellationPending)
      {
        theDoWorkEventArguments.Cancel = true;
        return;
      }
      // theBackgroundWorker.CancellationPending

      theDoWorkEventArguments.Result = arrintPrime;
    }
    // backgroundWorkerDemo_DoWork(System.Object, System.ComponentModel.DoWorkEventArgs) Handles backgroundWorkerDemo.DoWork

    private void backgroundWorkerDemo_ProgressChanged(System.Object theSender, System.ComponentModel.ProgressChangedEventArgs theProgressChangedEventArguments)
    //***
    // Action
    //   - Triggered when the progress of the background worker is changed
    //   - The change is visualisized in the progressbar on the form
    // Called by
    //   - System action (Background worker progress changed)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      prgBar.Value = theProgressChangedEventArguments.ProgressPercentage;
    }
    // backgroundWorkerDemo_ProgressChanged(System.Object, System.ComponentModel.ProgressChangedEventArgs) Handles backgroundWorkerDemo.ProgressChanged

    private void backgroundWorkerDemo_RunWorkerCompleted(System.Object theSender, System.ComponentModel.RunWorkerCompletedEventArgs theRunWorkerCompletedEventArguments)
    //***
    // Action
    //   - Code runned when the background worker is finished
    //   - If the routine was cancelled
    //     - Show corresponding message
    //   - If there are no errors
    //     - Get the array with the prime numbers
    //     - Loop them and add them to the listbox in the form
    //   - If Not
    //     - Show corresponding error message
    //   - Enable the Find button
    //   - Disable the Cancel button
    //   - Set progressbar to 0
    // Called by
    //   - System action (Background worker completed)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (theRunWorkerCompletedEventArguments.Cancelled)
      {
        MessageBox.Show("Search cancelled");
      }
      else if (theRunWorkerCompletedEventArguments.Error == null)
      {
        uint[] arrintPrime = (uint[])theRunWorkerCompletedEventArguments.Result;

        foreach (uint intPrime in arrintPrime)
        {
          lstPrimes.Items.Add(intPrime);
        }
        // in arrintPrime

      }
      else
      // theRunWorkerCompletedEventArguments.Error <> null
      // There was an error thrown by the DoWork event handler
      {
        MessageBox.Show(theRunWorkerCompletedEventArguments.Error.Message, "An Error Occurred");
      }
      // theRunWorkerCompletedEventArguments.Cancelled
      // theRunWorkerCompletedEventArguments.Error = null

      cmdFind.IsEnabled = true;
      cmdCancel.IsEnabled = false;
      prgBar.Value = 0;
    }
    // backgroundWorkerDemo_RunWorkerCompleted(System.Object, System.ComponentModel.RunWorkerCompletedEventArgs) Handles backgroundWorkerDemo.RunWorkerCompleted

    private void cmdCancel_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Stops the code that is working in a background
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theBackgroundWorker.CancelAsync();
    }
    // cmdCancel_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCancel.Click

    private void cmdFind_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Disable the Find button and clear previous results
    //   - Enable the Cancel button
    //   - Get the search range
    //   - Check if input From and To are integers
    //   - If Not
    //     - Show message
    //     - Stop routine
    //   - Start the search for primes using another thread
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - cpFindPrimesInput(uint, uint)
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      uint intFrom;
      uint intTo;

      cmdFind.IsEnabled = false;
      cmdCancel.IsEnabled = true;

      lstPrimes.Items.Clear();

      if (uint.TryParse(txtFrom.Text, out intFrom))
      {
      }
      else
      // Not uint.TryParse(txtFrom.Text, out intFrom)
      {
        MessageBox.Show("Invalid From value");
        cmdFind.IsEnabled = true;
        cmdCancel.IsEnabled = false;
        return;
      }
      // uint.TryParse(txtFrom.Text, out intFrom)

      if (uint.TryParse(txtTo.Text, out intTo))
      {
      }
      else
      // Not uint.TryParse(txtTo.Text, out intTo)
      {
        MessageBox.Show("Invalid To value");
        cmdFind.IsEnabled = true;
        cmdCancel.IsEnabled = false;
        return;
      }
      // uint.TryParse(txtTo.Text, out intTo)

      cpFindPrimesInput inputPrimesRange = new cpFindPrimesInput(intFrom, intTo);
      theBackgroundWorker.RunWorkerAsync(inputPrimesRange);
    }
    // cmdFind_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdFind.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfBackgroundWorkerDemo

}
// Multithreading