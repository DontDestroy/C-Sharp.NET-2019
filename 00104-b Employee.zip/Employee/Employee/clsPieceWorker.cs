//***
// Action
//   - Definition of a cpPieceWorker
// Created
//   - CopyPaste � 20230817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230817 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Company
{

  public class cpPieceWorker : cpEmployee
  {

    #region "Constructors / Destructors"
    
    public cpPieceWorker(string strFirstName, string strLastName, decimal decWagePerPiece, int lngQuantity) : base(strFirstName, strLastName)
      //***
      // Action
      //   - Creates an employee with strFirstName and strLastName
      //   - Set the wage per piece to decWagePerPiece
      //   - Set the quantity to lngQuantity
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee(string, string)
      //   - Quantity(int) (Set)
      //   - WagePerPiece(decimal) (Set)
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      WagePerPiece = decWagePerPiece;
      Quantity = lngQuantity;
    }
    // cpPieceWorker(string, string, decimal, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private decimal mdecAmountPerPiece;
    private int mlngQuantity;

    #endregion

    #region "Properties"

    public int Quantity
    {

      get
        //***
        // Action
        //   - Return the quantity
        // Called by
        //   - decimal Earnings()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngQuantity;
      }
      // int Quantity (Get)

      set
        //***
        // Action
        //   - Set the quantity to value
        //   - If quantity is negative, 0 becomes the value
        // Called by
        //   - cpPieceWorker(string, string, decimal, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value > 0)
        {
          mlngQuantity = value;
        }
        else
          // value <= 0
        {
          mlngQuantity = 0;
        }
        // value > 0

      }
      // Quantity(int) (Set)

    }
    // int Quantity
    
    public decimal WagePerPiece
    {

      get
        //***
        // Action
        //   - Return the wage per piece
        // Called by
        //   - decimal Earnings()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecAmountPerPiece;
      }
      // decimal WagePerPiece (Get)

      set
        //***
        // Action
        //   - Set the wage per piece to Value
        //   - If wage per piece is negative, 0 becomes the value
        // Called by
        //   - cpPieceWorker(string, string, decimal, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value > 0)
        {
          mdecAmountPerPiece = value;
        }
        else
          // value <= 0
        {
          mdecAmountPerPiece = 0;
        }
        // value > 0

      }
      // WagePerPiece(decimal) (Set)

    }
    // decimal WagePerPiece

    #endregion

    #region "Methods"

    #region "Overrides"

    public override decimal Earnings()
      //***
      // Action
      //   - Calculate and return the earnings
      //   - Calculation is the wage per piece multiplied by the quantity
      // Called by
      //   - 
      // Calls
      //   - Quantity() As Int32 (Get)
      //   - WagePerPiece() As Decimal (Get)
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Quantity * WagePerPiece;
    }
    // decimal Earnings()

    public override string ToString()
      //***
      // Action
      //   - Return description of a cpPieceWorker
      // Called by
      //   - 
      // Calls
      //   - cpEmployee.ToString() As String
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "cpPieceWorker: " + base.ToString();
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPieceWorker

}
// CopyPaste.Learning.Company