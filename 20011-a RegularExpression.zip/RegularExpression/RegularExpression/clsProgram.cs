//***
// Action
//   - Demo of regular expression
// Created
//   - CopyPaste � 20260502 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260502 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Text.RegularExpressions;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260502 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260502 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define a string
      //   - Define and create a Regex expression (must start with "Subject: ")
      //   - Define a match
      //   - Ask a text
      //   - Check if it matches
      //   - If success
      //     - The text after the match becomes the subject
      //   - If not
      //     - A default subject becomes the subject
      //   - Subject is shown
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260502 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260502 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strSubject;
      Regex theRegex = new Regex("^Subject: (.*)", RegexOptions.IgnoreCase);
      Match theMatch;

      Console.WriteLine("Type a command like: 'Subject: some text'");
      theMatch = theRegex.Match(Console.ReadLine());

      if (theMatch.Success)
      {
        strSubject = theMatch.Groups[1].Value;
      }
      else
        // Not theMatch.Success
      {
        strSubject = "Default subject";
      }
      // theMatch.Success

      Console.WriteLine(strSubject);
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning