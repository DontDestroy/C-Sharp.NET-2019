//***
// Action
//   - Use of checkboxes
// Created
//   - CopyPaste � 20230620 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230620 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CheckBox
{

  public class frmCheckBox : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    internal System.Windows.Forms.PictureBox picCopyMachine;
    internal System.Windows.Forms.PictureBox picCalculator;
    internal System.Windows.Forms.CheckBox chkCopyMachine;
    internal System.Windows.Forms.CheckBox chkCalculator;
    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCheckBox));
      this.picCopyMachine = new System.Windows.Forms.PictureBox();
      this.picCalculator = new System.Windows.Forms.PictureBox();
      this.chkCopyMachine = new System.Windows.Forms.CheckBox();
      this.chkCalculator = new System.Windows.Forms.CheckBox();
      this.SuspendLayout();
      // 
      // picCopyMachine
      // 
      this.picCopyMachine.Image = ((System.Drawing.Image)(resources.GetObject("picCopyMachine.Image")));
      this.picCopyMachine.Location = new System.Drawing.Point(158, 144);
      this.picCopyMachine.Name = "picCopyMachine";
      this.picCopyMachine.Size = new System.Drawing.Size(88, 80);
      this.picCopyMachine.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picCopyMachine.TabIndex = 7;
      this.picCopyMachine.TabStop = false;
      this.picCopyMachine.Visible = false;
      // 
      // picCalculator
      // 
      this.picCalculator.Image = ((System.Drawing.Image)(resources.GetObject("picCalculator.Image")));
      this.picCalculator.Location = new System.Drawing.Point(46, 144);
      this.picCalculator.Name = "picCalculator";
      this.picCalculator.Size = new System.Drawing.Size(88, 80);
      this.picCalculator.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picCalculator.TabIndex = 6;
      this.picCalculator.TabStop = false;
      // 
      // chkCopyMachine
      // 
      this.chkCopyMachine.Location = new System.Drawing.Point(54, 88);
      this.chkCopyMachine.Name = "chkCopyMachine";
      this.chkCopyMachine.Size = new System.Drawing.Size(176, 24);
      this.chkCopyMachine.TabIndex = 5;
      this.chkCopyMachine.Text = "Copy Machine";
      this.chkCopyMachine.CheckedChanged += new System.EventHandler(this.chkCopyMachine_CheckedChanged);
      // 
      // chkCalculator
      // 
      this.chkCalculator.Checked = true;
      this.chkCalculator.CheckState = System.Windows.Forms.CheckState.Checked;
      this.chkCalculator.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.chkCalculator.ForeColor = System.Drawing.SystemColors.ControlText;
      this.chkCalculator.Location = new System.Drawing.Point(54, 48);
      this.chkCalculator.Name = "chkCalculator";
      this.chkCalculator.Size = new System.Drawing.Size(176, 24);
      this.chkCalculator.TabIndex = 4;
      this.chkCalculator.Text = "Calculator";
      this.chkCalculator.CheckedChanged += new System.EventHandler(this.chkCalculator_CheckedChanged);
      // 
      // frmCheckBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.picCopyMachine);
      this.Controls.Add(this.picCalculator);
      this.Controls.Add(this.chkCopyMachine);
      this.Controls.Add(this.chkCalculator);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCheckBox";
      this.Text = "Choose one or more options";
      this.Load += new System.EventHandler(this.frmCheckBox_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmCheckBox'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmCheckBox()
    //***
    // Action
    //   - Create instance of 'frmCheckBox'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmCheckBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void chkCalculator_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Depending on 'chkCalculator'.'CheckState'
    //     - Show 'picCalculator' or not
    // Called by
    //   - User action (Clicking a checkbox)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      if (chkCalculator.CheckState == CheckState.Checked)
      {
        picCalculator.Visible = true;
      }
      else
        // chkCalculator.CheckState <> CheckState.Checked
      {
        picCalculator.Visible = false;
      }
      // chkCalculator.CheckState = CheckState.Checked

    }
    // chkCalculator_CheckedChanged(System.Object, System.EventArgs) Handles chkCalculator_CheckedChanged

    private void chkCopyMachine_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Depending on 'chkCopyMachine'.'CheckState'
    //     - Show 'picCopyMachine' or not
    // Called by
    //   - User action (Clicking a checkbox)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      if (chkCopyMachine.CheckState == CheckState.Checked)
      {
        picCopyMachine.Visible = true;
      }
      else
        // chkCopyMachine.CheckState <> CheckState.Checked
      {
        picCopyMachine.Visible = false;
      }
      // chkCopyMachine.CheckState = CheckState.Checked

    }
    // chkCopyMachine_CheckedChanged(System.Object, System.EventArgs) Handles chkCopyMachine_CheckedChanged

    private void frmCheckBox_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User action (Loading a form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // frmCheckBox_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmCheckBox
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmCheckBox());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmCheckBox

}
// CheckBox