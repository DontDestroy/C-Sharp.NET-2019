//***
// Action
//   - Implementation of cpBook
//   - All the information that is needed to define a cpBook
// Created
//   - CopyPaste � 20240227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240227 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpBook
  {

    #region "Constructors / Destructors"

    public cpBook(string strTitle, string strText)
      //***
      // Action
      //   - Constructor with 2 arguments
      //     - Title and Text are given
      //   - If an error occurs, the received exception is thrown
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Title = strTitle;
      Text = strText;
    }
    // cpBook()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    private string mstrText;
    private string mstrTitle;

    #endregion

    #region "Properties"

    public string Text
    {

      get
        //***
        // Action Get
        //   - Returns mstrText
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240227 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240227 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrText;
      }
      // string Text (Get)

      set
        //***
        // Action Set
        //   - If value is not empty string or null
        //     - mstrText becomes value
        //   - If Not
        //     - Throw error message
        // Called by
        //   - cpBook(string, string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240227 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240227 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if ((value == "") || (value == null))
        {
          throw new Exception("Text is an empty string or not filled in.");
        }
        else
          // (value <> "") And (value <> null)
        {
          mstrText = value;
        }
        // (value = "") Or (value = null)

      }
      // Text(string) (Set)

    }
    // string Text

    public string Title
    {

      get
        //***
        // Action Get
        //   - Returns mstrTitle
        // Called by
        //   - cpBookCollection.Add(cpBook)
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240227 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240227 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrTitle;
      }
      // string Title (Get)

      set
        //***
        // Action Set
        //   - If value is not empty string or null
        //     - mstrTitle becomes value
        //   - If Not
        //     - Throw error message
        // Called by
        //   - cpBook(string, string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240227 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240227 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if ((value == "") || (value == null))
        {
          throw new Exception("Title is an empty string or not filled in.");
        }
        else
          // (value <> "") And (value <> null)
        {
          mstrTitle = value;
        }
        // (value = "") Or (value = null)

      }
      // Title(string) (Set)

    }
    // string Title

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpBook

}
// CopyPaste.Learning