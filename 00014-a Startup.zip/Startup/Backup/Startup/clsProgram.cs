//***
// Action
//   - Showing some forms
// Created
//   - CopyPaste � 20070209 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20070209 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static frmFirst mfrmFirst = new frmFirst();
    public static frmSecond mfrmSecond = new frmSecond();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Show a messagebox with the location where the code is located that is running
      //   - Show the first form
      //   - Show the second form (when the first form is closed
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20070209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070209 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show("This is procedure Main");

      mfrmFirst.ShowDialog();
      mfrmSecond.ShowDialog();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning
