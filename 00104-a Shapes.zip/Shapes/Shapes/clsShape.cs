//***
// Action
//   - Definition of a cpShape
// Created
//   - CopyPaste � 20230818 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230818 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public abstract class cpShape
  {

    #region "Constructors / Destructors"

    public cpShape()
      //***
      // Action
      //   - Empty constructor of a cpShape
      // Called by
      //   - cpPoint()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpShape()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public abstract string Name {get;}
    // string Name (Get)

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public virtual double Area()
      //***
      // Action
      //   - Return 0
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return 0;
    }
    // double Area()

    public virtual double Volume()
      //***
      // Action
      //   - Return 0
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return 0;
    }
    // double Volume()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpShape

}
// CopyPaste.Learning