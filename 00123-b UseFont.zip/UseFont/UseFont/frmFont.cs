//***
// Action
//   - Choose a font and use it in a textbox
// Created
//   - CopyPaste � 20240715 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240715 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFont: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtText;
    internal System.Windows.Forms.Button cmdFont;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFont));
      this.txtText = new System.Windows.Forms.TextBox();
      this.cmdFont = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(20, 64);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(252, 184);
      this.txtText.TabIndex = 3;
      this.txtText.Text = "";
      // 
      // cmdFont
      // 
      this.cmdFont.Location = new System.Drawing.Point(104, 16);
      this.cmdFont.Name = "cmdFont";
      this.cmdFont.TabIndex = 2;
      this.cmdFont.Text = "Set Font";
      this.cmdFont.Click += new System.EventHandler(this.cmdFont_Click);
      // 
      // frmFont
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.txtText);
      this.Controls.Add(this.cmdFont);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFont";
      this.Text = "Font";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFont'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240715 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFont()
      //***
      // Action
      //   - Create instance of 'frmFont'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240715 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFont()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFont_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a font dialog
      //   - Show the dialog
      //   - If OK is clicked
      //     - Change the font of the textbox into the choosen font
      //   - If not
      //     - Nothing happens
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      FontDialog dlgFont = new FontDialog();

      if (dlgFont.ShowDialog() == DialogResult.OK)
      {
        txtText.Font = dlgFont.Font;
      }
      else
        // dlgFont.ShowDialog() <> DialogResult.OK
      {
      }
      // dlgFont.ShowDialog() = DialogResult.OK
    
    }
    // cmdFont_Click(System.Object, System.EventArgs) Handles cmdFont.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFont
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmFont()
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240715 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFont());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmFont

}
// CopyPaste.Learning