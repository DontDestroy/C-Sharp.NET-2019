﻿//***
// Action
//   - Testroutine for cpCopyMachine events
//     - The events triggers methods that are outside the class of cpCopyMachine
//     - The are given by the info in cpEmployee and cpOfficeWorker
// Created
//   - CopyPaste – 20250716 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250716 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using CopyPaste.Learning.Material;
using CopyPaste.Learning.Personnel;
using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create a cpEmployee (Vincent)
      //   - Create a cpOfficeWorker (Hilde)
      //   - Create a cpCopyMachine (0.025 cost)
      //   - Create a cpCopyMachine (0.03 cost)
      //   - Add Vincent as employee for the first copy machine
      //   - Add Vincent as employee and Hilde as office worker for the second copy machine
      //   - Run 12001 runs for the printer
      //     - Print between 1 (included) and 100 (excluded) pages on the first copy machine
      //     - Print between 1 (included) and 100 (excluded) pages on the second copy machine
      //   - While running events are triggered (you don't know in advance when)
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpCopyMachine.NeedsMaintenance(cpCopyMachine)
      //   - cpCopyMachine.New(Decimal, Int32)
      //   - cpCopyMachine.NumberOfPages(Int32) (Set)
      //   - cpEmployee.DoMaintenance(cpCopyMachine)
      //   - cpEmployee.New(String)
      //   - cpOfficeWorker.DoMaintenance(cpCopyMachine)
      //   - cpOfficeWorker.New(String)
      // Created
      //   - CopyPaste – 20250716 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250716 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpCopyMachine thecpMachine = new cpCopyMachine(0.025M, 0);
      cpCopyMachine thecpMachineOther = new cpCopyMachine(0.03M, 0);
      cpEmployee thecpEmployee = new cpEmployee("Vincent");
      cpOfficeWorker thecpOfficeWorker = new cpOfficeWorker("Hilde");
      Random rndNumber = new Random();
      int lngCounter;
     
      thecpMachine.NeedsMaintenance += new cpCopyMachine.Maintenance(thecpEmployee.DoMaintenance);
      thecpMachineOther.NeedsMaintenance += new cpCopyMachine.Maintenance(thecpEmployee.DoMaintenance);
      thecpMachineOther.NeedsMaintenance += new cpCopyMachine.Maintenance(thecpOfficeWorker.DoMaintenance);

      for (lngCounter = 0; lngCounter <= 12000; lngCounter++)
      {
        int intCopyPages;
        
        intCopyPages = rndNumber.Next(1, 100);
        thecpMachine.NumberOfPages = intCopyPages;
        intCopyPages = rndNumber.Next(1, 100);
        thecpMachineOther.NumberOfPages = intCopyPages;
      }
      // lngCounter = 12001

      Console.ReadLine();
    }
    // Main()

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning