﻿//***
// Action
//   - Implementation of Interface cpiValidationRestriction to validate a textbox on decimal number
//   - A negative decimal number starts with a "-" and can contain somewhere maximum 1 decimal sign
// Created
//   - CopyPaste – 20250718 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250718 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Globalization;

namespace CopyPaste.Learning
{

  public class cpValidationRestrictionNegativeDecimal: cpiValidationRestriction
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public bool Validate(cpctlValidationTextbox theSender, System.Windows.Forms.KeyPressEventArgs theKeyPressEventArgs )
      //***
      // Action
      //   - Test of a character typed can be part of a negative decimal number
      //   - Find the decimal separator on the settings of the operating system
      //   - Find the negative sign on the settings of the operating system
      //   - If the first typed character is the negative sign
      //        Or the typed character is the separator and it is the first time that it was typed
      //        Or the typed character is a number
      //     - Return True
      //   - If not
      //     - Return False
      // Called by
      //   - cpctlValidationTextbox.OnKeyPress(KeyPressEventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250718 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250718 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strNegativeSign = NumberFormatInfo.CurrentInfo.NegativeSign;
      string strSeparator = NumberFormatInfo.CurrentInfo.NumberDecimalSeparator;

      return (((theKeyPressEventArgs.KeyChar.ToString() == strSeparator) && 
        (theSender.Text.IndexOfAny(strSeparator.ToCharArray()) == -1)) ||
        Char.IsNumber(theKeyPressEventArgs.KeyChar) || 
        ((theKeyPressEventArgs.KeyChar.ToString() == strNegativeSign) &&
        (theSender.SelectionStart == 0)));
  }
    // Validate(cpctlValidationTextbox, System.Windows.Forms.KeyPressEventArgs) As Boolean Implements cpiValidationRestriction.Validate

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpValidationRestrictionNegativeDecimal

}
// CopyPaste.Learning