//***
// Action
//   - Handling a dice
// Created
//   - CopyPaste � 20230620 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230620 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.IO;

namespace CopyPaste.Game
{

  public class cpDice
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    static Random mrndObject = new Random();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    public static Image GetImage(int lngValue, string strBaseImageName)
    //***
    // Action
    //   - Gets an image of a dice
    // Called by
    //   - frmDice.cmdRollBlueDice_Click(System.Object, System.EventArgs) Handles cmdRollBlueDice.Click
    //   - frmDice.cmdRollRedDice_Click(System.Object, System.EventArgs) Handles cmdRollRedDice.Click
    // Calls
    //   - string System.IO.Directory.GetCurrentDirectory()
    //   - System.Drawing.Image System.Drawing.Image.FromFile(string)
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return Image.FromFile(Directory.GetCurrentDirectory() + "\\Images\\" + strBaseImageName + lngValue + ".png");
    }
    // Image GetImage(int, string)

    public static int Roll()
    //***
    // Action
    //   - Get a random number from 1 to 6
    // Called by
    //   - frmDice.cmdRollBlueDice_Click(System.Object, System.EventArgs) Handles cmdRollBlueDice.Click
    //   - frmDice.cmdRollRedDice_Click(System.Object, System.EventArgs) Handles cmdRollRedDice.Click
    //   - int RollAndSum(Int32)
    // Calls
    //   - int System.Random.Next(int, int)
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return mrndObject.Next(1, 7);
    }
    // int Roll()

    public static int RollAndSum(int lngDiceNumber)
    //***
    // Action
    //   - Loop from 1 to 'lngDiceNumber' (lngCounter)
    //     - 'lngSum' becomes 'lngSum' + dice roll value 
    // Called by
    //   - frmDice.cmdRollTen_Click(System.Object, System.EventArgs) Handles cmdRollTen.Click
    // Calls
    //   - int Roll()
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      int lngCounter;
      int lngSum = 0;

      for (lngCounter = 1; lngCounter <= lngDiceNumber; lngCounter++)
      {
        lngSum += Roll();
      }
      // lngCounter = lngDiceNumber + 1

      return lngSum;
    }
    // int RollAndSum(int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDice 

}
// CopyPaste.Game