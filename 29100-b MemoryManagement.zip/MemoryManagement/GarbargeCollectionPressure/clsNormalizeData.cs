﻿//***
// Action
//   - Take an array
//   - Find the maximum
//   - Recalculate all values of the array by dividing the value by the found maximum
// Created
//   - CopyPaste – 20260531 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260531 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Threading.Tasks;
using System.Buffers;
using System.Collections.Generic;
using System.IO;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpNormalizeData
  {

    #region "Constructors / Destructors"

    public cpNormalizeData()
    //***
    // Action
    //   - Basic constructor
    //   - Prepare the data
    //     - Create 2 arrays of 1024 doubles
    //       - Put a random value in it
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260531 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpNormalizeData()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    double[] arrDoubleFirst;
    double[] arrDoubleSecond;
    Memory<double> memDoubleSecond;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [BenchmarkAttribute]
    public void ArrayCalculations()
    //***
    // Action
    //   - Find the biggest value in a given array
    //   - Divide all items in the array by the biggest value
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260531 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      double dblMax = double.MinValue;
      int intLength;

      foreach (double theDouble in arrDoubleFirst)
      {

        if (theDouble > dblMax)
        {
          dblMax = theDouble;
        }
        else
        // theDouble <= dblMax
        { 
        }
        // theDouble > dblMax

      }
      // in arrDouble

      intLength = arrDoubleFirst.Length;

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {
        arrDoubleFirst[intCounter] /= dblMax;
      }
      // intCounter = intLength

    }
    // ArrayCalculations()

    [BenchmarkAttribute]
    public void MemoryCalculations()
    //***
    // Action
    //   - Find the biggest value in a given memory
    //   - Divide all items in the array by the biggest value
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260531 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      double dblMax = double.MinValue;
      int intLength;
      Span<double> spnDoubleSecond = memDoubleSecond.Span;

      foreach (double theDouble in spnDoubleSecond)
      {

        if (theDouble > dblMax)
        {
          dblMax = theDouble;
        }
        else
        // theDouble <= dblMax
        {
        }
        // theDouble > dblMax

      }
      // in arrDouble

      intLength = spnDoubleSecond.Length;

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {
        spnDoubleSecond[intCounter] /= dblMax;
      }
      // intCounter = intLength

    }
    // MemoryCalculations()

    [GlobalSetupAttribute]
    public void PrepareData()
    //***
    // Action
    //   - Define and assign an array with doubles twice
    //   - Loop thru all the items of an array
    //     - Put a random double as value in both arrays
    //   - Try to
    //     - Create a new Memory using teh second array of doubles
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260531 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      double dblNumber;
      int intLength = 1_024;
      Random rndRandomizer = new Random();

      arrDoubleFirst = new double[intLength];
      arrDoubleSecond = new double[intLength];

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {
        dblNumber = rndRandomizer.NextDouble();
        arrDoubleFirst[intCounter] = dblNumber;
        arrDoubleSecond[intCounter] = dblNumber;
      }
      // intCounter = intLength

      try
      {
        // VVDW - The code below can be used to share and rent an array into an ArrayPool, so allocation is not needed
        // ArrayPool<double> theArrayPool = ArrayPool<double>.Shared;
        // double[] theBuffer = theArrayPool.Rent(intLength);
        memDoubleSecond = new Memory<double>(arrDoubleSecond, 0, intLength);
      }
      finally
      {
        // theArrayPool.Return(theBuffer);
      }

    }
    // PrepareData()

    #endregion

    #endregion

    #endregion

    #region "Not used"

    private void ProcessPacket(ReadOnlySpan<byte> rospnPacked)
    //***
    // Action
    //   - Avoiding a bunch of intermediate buffers and ToArray() functionality
    //   - Given a span of bytes
    //     - The first 4 are converted by bits and put in an integer
    //     - The rest becomes a span of bytes as payload
    //   - Do something with the payload
    // Called by
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260603 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260603 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Take into account pipelines, sockets, memory mapped files to get rid of all transient allocations
    //***
    {
      int intHeader = BitConverter.ToInt32(rospnPacked[..4]);
      ReadOnlySpan<byte> rospnPayLoad = rospnPacked[4..];

      // Do something with the payload without copying it 
    }
    // ProcessPacket(ReadOnlySpan<byte>)

    private void TemporaryBuffer()
    //***
    // Action
    //   - The buffer is entirely on the stack
    //   - It disappears immediately after the exit of the method (no Garbage Collector cost)
    //   - A span is defined of 256 integers
    //   - Loop them
    //     - Assign a value to every integer
    //   - Take the first half
    //   - Take the second half
    // Called by
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260603 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260603 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Span<T> cannot cross asynchronous boundaries because it can reference stack data
    //   - When async is needed, Memory<T> should be used
    //***
    {
      Span<int> spnTemp = stackalloc int[256];

      for (int intCounter = 0; intCounter < spnTemp.Length; intCounter++)
      {
        spnTemp[intCounter] = intCounter * 2;
      }
      // intCounter = spnTemp.Length

      Span<int> spnFirstHalf = spnTemp[..128];
      Span<int> spnSecondHalf = spnTemp[128..];
    }
    // TemporaryBuffer()

    private async Task<int> TemporaryBufferAsync(Memory<byte> memBuffer, Stream theStream)
    //***
    // Action
    //   - This is heap based
    //   - Working on the heap is the obligatory way for async functionality
    // Called by
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260603 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260603 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      return await theStream.ReadAsync(memBuffer);
    }
    // TemporaryBufferAsync()

    #endregion

  }
  // cpSplitString

}
// CopyPaste.Learning