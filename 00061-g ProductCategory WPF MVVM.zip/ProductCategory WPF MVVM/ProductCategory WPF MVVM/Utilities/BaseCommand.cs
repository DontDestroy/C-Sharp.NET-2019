﻿//***
// Action
//   - Definition of a base command (inherits from BaseCommand<T>)
// Created
//   - CopyPaste – 20260404 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260404 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace ProductCategory_WPF_MVVM.Utilities
{

  public class BaseCommand : BaseCommand<System.Object>
  {

    #region "Constructors / Destructors"

    public BaseCommand(Action theAction) : base(_ => theAction())
    //***
    // Action
    //   - Execute the action
    // Called by
    //   - ProductCategoryViewModel(IDataService)
    // Calls
    //   - BaseCommand(Action<T>, Func<T, bool>)
    // Created
    //   - CopyPaste – 20260404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260404 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // BaseCommand(Action)

    public BaseCommand(Action theAction, Func<bool> theFunction) : base(_ => theAction(), _ => theFunction())
    //***
    // Action
    //   - Execute the action and the function
    // Called by
    //   - 
    // Calls
    //   - BaseCommand(Action<T>, Func<T, bool>)
    // Created
    //   - CopyPaste – 20260404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260404 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // BaseCommand(Action, Func<bool>)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // BaseCommand

}
// ProductCategory_WPF_MVVM.Utilities