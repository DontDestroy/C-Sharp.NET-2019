//***
// Action
//   - Implementation of a memory game, just to test cpCardGames toolkit
// Created
//   - CopyPaste � 20240310 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240310 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.CardGames;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.CardGames
{

  public class frmMemory: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.IContainer components;
    protected CopyPaste.CardGames.cpctlMemory theMemory;
    protected CopyPaste.CardGames.cpcmpDeck theDeck;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMemory));
      this.theMemory = new CopyPaste.CardGames.cpctlMemory();
      this.theDeck = new CopyPaste.CardGames.cpcmpDeck(this.components);
      this.SuspendLayout();
      // 
      // theMemory
      // 
      this.theMemory.Columns = 4;
      this.theMemory.Deck = this.theDeck;
      this.theMemory.Location = new System.Drawing.Point(16, 16);
      this.theMemory.Name = "theMemory";
      this.theMemory.Rows = 4;
      this.theMemory.Size = new System.Drawing.Size(290, 350);
      this.theMemory.TabIndex = 0;
      this.theMemory.GameOver += new CopyPaste.CardGames.cpctlMemory.GameOverHandler(this.theMemory_GameOver);
      // 
      // theDeck
      // 
      this.theDeck.FaceValues = new CopyPaste.CardGames.cpctlCard.cpFaceValue[] {
                                                                                  CopyPaste.CardGames.cpctlCard.cpFaceValue.Ace,
                                                                                  CopyPaste.CardGames.cpctlCard.cpFaceValue.Jack,
                                                                                  CopyPaste.CardGames.cpctlCard.cpFaceValue.Queen,
                                                                                  CopyPaste.CardGames.cpctlCard.cpFaceValue.King};
      this.theDeck.Suits = new CopyPaste.CardGames.cpctlCard.cpSuit[] {
                                                                        CopyPaste.CardGames.cpctlCard.cpSuit.Clubs,
                                                                        CopyPaste.CardGames.cpctlCard.cpSuit.Diamonds,
                                                                        CopyPaste.CardGames.cpctlCard.cpSuit.Hearts,
                                                                        CopyPaste.CardGames.cpctlCard.cpSuit.Spades};
      // 
      // frmMemory
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(328, 429);
      this.Controls.Add(this.theMemory);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMemory";
      this.Text = "Memory";
      this.Load += new System.EventHandler(this.frmMemory_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMemory'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMemory()
      //***
      // Action
      //   - Create instance of 'frmMemory'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMemory()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmMemory_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Play a memory game using the cpctlMemory control
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - cpctlMemory.Play()
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.theMemory.Play();
    }
    // frmMemory_Load(System.Object, System.EventArgs) Handles frmMemory.Load

    private void theMemory_GameOver(System.Object theSender, cpGameOverEventArguments thecpGameOverEventArguments)
      //***
      // Action
      //   - Implementation on how the memory games stops
      //   - Ask the user if another games must be started
      //   - If answer is yes
      //     - Play another game
      // Called by
      //   - User action (Playing the game, and all controls are removed)
      // Calls
      //   - cpctlMemory.Play()
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DialogResult dlgResult;

      dlgResult = MessageBox.Show("You win in " + thecpGameOverEventArguments.Clicks + " turns." + Environment.NewLine + "Play again?", "Game over", MessageBoxButtons.YesNo);

      if (dlgResult == DialogResult.Yes)
      {
        this.theMemory.Play();
      }
      else
        // dlgResult <> DialogResult.Yes
      {
      }
      // dlgResult = DialogResult.Yes

    }
    // theMemory_GameOver(System.Object, cpGameOverEventArguments) Handles theMemory.GameOver

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMemory
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMemory());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMemory

}
// CopyPaste.CardGames