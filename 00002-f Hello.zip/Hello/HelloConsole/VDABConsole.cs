//***
// Action
//   - Write some info at the console screen
// Created
//   - CopyPaste � 20211018 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20211018 � VVDW
// Proposal (To Do)
//   -
//***
using System;

namespace HelloConsole
{

  class VDABConsole
	{

    static void Main()
    //***
    // Action
    //   - Write some lines at the console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.Write(string)
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20211018 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20211018 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      // The Program starts with this routine
      Console.WriteLine("Hello");
      Console.WriteLine("-----");
      Console.Write("Asterix");
      Console.WriteLine(" and Obelix");
      Console.WriteLine("");
      Console.WriteLine(
        "This is a text and it is quite long.");
      Console.WriteLine("");
      Console.ReadLine();
		}
    // Main()

  }
  // VDABConsole

}
// HelloConsole