//***
// Action
//   - Testroutine of cpAccount, cpSavingAccount and cpUsingAccount
// Created
//   - CopyPaste � 20240105 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240105 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

	public class cpProgram
	{
	
		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public static void Main()
			//***
			// Action
			//   - Create a correct Belgian saving account
			//   - Show the information
			//   - Add 125 to the account
			//   - Show the information
			//   - Create a correct Belgian using account
			//   - Show the information
			//   - Add 1000 to the account
			//   - Show the information
			//   - Create a wrong Belgian saving account (intrest rate is wrong)
			//   - Create a wrong Belgian using account (maximum credit is wrong)
		// Called by
			//   - User action (Starting the application)
			// Calls
			//   - cpAccount(long, decimal, DateTime)
			//   - cpAccount.Show()
			//   - cpSavingAccount(long, decimal, DateTime, decimal)
			//   - cpSavingAccount.Show()
			//   - cpUsingAccount(long, decimal, DateTime, decimal)
			//   - cpUsingAccount.Show()
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - Not all properties are tested in this routine
			//***
	  {

			try
			{
	      // Happy flow
				cpSavingAccount thecpSavingAccount = new cpSavingAccount(83179377453, 0, new DateTime(2004, 12, 18), 4.5M);
	      cpUsingAccount thecpUsingAccount = new cpUsingAccount(63154756360, 0, new DateTime(2004, 12, 19), -1000);
	      cpAccount thecpWrongAccount; 
        cpAccount thecpWrongSavingAccount;
        cpAccount thecpWrongUsingAccount;

        thecpSavingAccount.Show();
        thecpSavingAccount.Add(125);
        thecpSavingAccount.Show();

        Console.WriteLine("-----");
        Console.WriteLine();

        thecpUsingAccount.Show();
        thecpUsingAccount.Add(1000);
        thecpUsingAccount.Show();

        // Not so happy flow
        thecpWrongSavingAccount = new cpSavingAccount(83179377453, 0, new DateTime(2004, 12, 18), -4.5M);
        thecpWrongUsingAccount = new cpUsingAccount(63154756360, 0, new DateTime(2004, 12, 19), 1000);
			}			
			catch (Exception theException)
			{
				Console.WriteLine(theException.Message);
			}
			finally
			{
				Console.ReadLine();
			}

		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.Learning