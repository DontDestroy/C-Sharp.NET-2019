﻿//***
// Action
//   - Demo of images on a screen
// Created
//   - CopyPaste – 20220923 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220923 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace WPFImage
{

  public partial class wpfImage : Window
  {

    #region "Constructors / Destructors"

    public wpfImage()
    //***
    // Action
    //   - Create an instance of 'wpfImage'
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220923 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220923 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfImage()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void ImageMouseUp(System.Object theSender, System.Windows.Input.MouseButtonEventArgs theMouseButtonEventArguments)
    //***
    // Action
    //   - Change the visibility of the 3 pictures
    //   - Do one of below
    //     - If imgAbstract01 is visible
    //       - Hide it and make imgAbstract02 visible
    //     - If imgAbstract02 is visible
    //       - Hide it and make imgMaze01 visible
    //     - If imgMaze01 is visible
    //       - Hide it and make imgAbstract01 visible
    // Called by
    //   - User action (Clicking a picture inside the grid)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220923 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220923 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (imgAbstract01.Visibility == Visibility.Visible)
      {
        imgAbstract01.Visibility = Visibility.Hidden;
        imgAbstract02.Visibility = Visibility.Visible;
      }
      else
      // imgAbstract01.Visibility <> Visibility.Visible
      {

        if (imgAbstract02.Visibility == Visibility.Visible)
        {
          imgAbstract02.Visibility = Visibility.Hidden;
          imgMaze01.Visibility = Visibility.Visible;
        }
        else
        // imgAbstract02.Visibility <> Visibility.Visible
        {
          imgMaze01.Visibility = Visibility.Hidden;
          imgAbstract01.Visibility = Visibility.Visible;
        }
        // imgAbstract02.Visibility = Visibility.Visible

      }
      // imgAbstract01.Visibility = Visibility.Visible

    }
    // ImageMouseUp(System.Object, System.Windows.MouseButtonEventArgs) Handles Image.MouseUp

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfImage

}
// WPFImage
