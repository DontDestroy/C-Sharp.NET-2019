//***
// Action
//   - A block game, the collision
//   - Working with properties (Get and Set) and methods in several classes, that can be used in another game
//   - Possible Solution 2
// Created
//   - CopyPaste � 20240214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240214 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.Games
{

  public class cpCollision
  {

    #region "Constructors / Destructors"

    public cpCollision()
      //***
      // Action
      //   - Do Nothing
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpCollision()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private Rectangle mrecFirstPosition;
    private Rectangle mrecSecondPosition;

    #endregion

    #region "Properties"

    public Rectangle FirstPosition
    {
      
      get
        //***
        // Action Get
        //   - Return the first rectangle (mrecFirstPosition)
        // Called by
        //   - bool Hit(cpMove, cpMove)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mrecFirstPosition;
      }
      // Rectangle FirstPosition (Get)

      set
        //***
        // Action Set
        //   - Set the first rectangle (mrecFirstPosition becomes value)
        // Called by
        //   - bool Hit(cpMove, cpMove)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mrecFirstPosition = value;
      }
      // FirstPosition(Rectangle) (Set)

    }
    // Rectangle FirstPosition

    public Rectangle SecondPosition
    {
      
      get
        //***
        // Action Get
        //   - Return the second rectangle (mrecSecondPosition)
        // Called by
        //   - bool Hit(cpMove, cpMove)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mrecSecondPosition;
      }
      // Rectangle SecondPosition (Get)

      set
        //***
        // Action Set
        //   - Set the second rectangle (mrecSecondPosition becomes value)
        // Called by
        //   - bool Hit(cpMove, cpMove)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mrecSecondPosition = value;
      }
      // SecondPosition(Rectangle) (Set)

    }
    // Rectangle SecondPosition

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public bool Hit(cpMove thecpMove01, cpMove thecpMove02)
      //***
      // Action Get
      //   - Hit thecpMove01 and thecpMove2 each other (True or False)
      //   - If the first moving object (the ball) is Nothing 
      //     - Return False
      //   - If Not
      //     - If the second moving object (a block) is visible
      //       - Determine the position of the ball (FirstPosition)
      //       - Determine the position of the block (SecondPosition)
      //       - If positions intersects (FirstPosition and SecondPosition overlaps)
      //         - Determine the intersection (recIntersection)
      //         - Depending on the with of recIntersection
      //           - Case larger or equal then the height of recIntersection
      //             - The ball bounces with parameter of 0 degrees (bounce will be calculated)
      //           - Case smaller then the height of recIntersection
      //             - The ball bounces with parameter of 90 degrees (bounce will be calculated)
      //           - Case else
      //             - Do Nothing
      //         - Return True
      //       - If Not
      //         - Return False
      //     - If Not
      //       - Return False
      // Called by
      //   - frmBlock.CheckCollision()
      //   - frmMoveTest.CheckCollision()
      // Calls
      //   - Control cpMove.MovingObject (Get)
      //   - cpMove.Bounce(double)
      //   - FirstPosition(Rectangle) (Set)
      //   - Rectangle cpMove.Boundaries (Get)
      //   - Rectangle FirstPosition (Get)
      //   - Rectangle SecondPosition (Get)
      //   - SecondPosition(Rectangle) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - When the hit is just on the corner, the behaviour of the bounce is incorrect (not implemented)
      //***
    {

      bool blnResult;

      if (thecpMove01 == null)
      {
        blnResult = false;
      }
      else
        // thecpMove01 <> null
      {

        if (thecpMove02.MovingObject.Visible)
        {
          FirstPosition = thecpMove01.Boundaries;
          SecondPosition = thecpMove02.Boundaries;
          
          if (FirstPosition.IntersectsWith(SecondPosition))
          {
            Rectangle recIntersection = Rectangle.Intersect(FirstPosition, SecondPosition);
            
            if (recIntersection.Width >= recIntersection.Height)
            {
              thecpMove01.Bounce(0);
              // thecpMove02.Bounce(0);
            }
            else
              // recIntersection.Width < recIntersection.Height
            {
              thecpMove01.Bounce(90);
              // thecpMove02.Bounce(90);
            }
            // recIntersection.Width >= recIntersection.Height

            // When you hit a box just on a corner,
            // it is possible that the ball bounces the wrong way
            // I did no research on that subject, but this routine is not correct for real games

            blnResult = true;
          }
          else
            // Not FirstPosition.IntersectsWith(SecondPosition)
          {
            blnResult = false;
          }
          // FirstPosition.IntersectsWith(SecondPosition)

        }
        else
          // Not thecpMove02.MovingObject.Visible 
        {
          blnResult = false;
        }
        // thecpMove02.MovingObject.Visible 

      }
      // thecpMove01 == null

      return blnResult;
    }
    // bool Hit(cpMove, cpMove)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCollision

}
// CopyPaste.Learning.Games