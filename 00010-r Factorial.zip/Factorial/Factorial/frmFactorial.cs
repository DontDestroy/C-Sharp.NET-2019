//***
// Action
//   - 
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Factorial
{

  public class frmFactorial : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    internal System.Windows.Forms.TextBox txtDisplay;
    internal System.Windows.Forms.Label lblFactorial;
    internal System.Windows.Forms.Button cmdCalculate;
    internal System.Windows.Forms.TextBox txtInput;
    internal System.Windows.Forms.Label lblEnter;
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFactorial));
      this.txtDisplay = new System.Windows.Forms.TextBox();
      this.lblFactorial = new System.Windows.Forms.Label();
      this.cmdCalculate = new System.Windows.Forms.Button();
      this.txtInput = new System.Windows.Forms.TextBox();
      this.lblEnter = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // txtDisplay
      // 
      this.txtDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.txtDisplay.Location = new System.Drawing.Point(16, 136);
      this.txtDisplay.Multiline = true;
      this.txtDisplay.Name = "txtDisplay";
      this.txtDisplay.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtDisplay.Size = new System.Drawing.Size(256, 168);
      this.txtDisplay.TabIndex = 9;
      this.txtDisplay.Text = "";
      // 
      // lblFactorial
      // 
      this.lblFactorial.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblFactorial.Location = new System.Drawing.Point(16, 112);
      this.lblFactorial.Name = "lblFactorial";
      this.lblFactorial.Size = new System.Drawing.Size(136, 24);
      this.lblFactorial.TabIndex = 8;
      this.lblFactorial.Text = "Factorial Values";
      // 
      // cmdCalculate
      // 
      this.cmdCalculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmdCalculate.Location = new System.Drawing.Point(80, 56);
      this.cmdCalculate.Name = "cmdCalculate";
      this.cmdCalculate.Size = new System.Drawing.Size(128, 40);
      this.cmdCalculate.TabIndex = 7;
      this.cmdCalculate.Text = "Calculate";
      this.cmdCalculate.Click += new System.EventHandler(this.cmdCalculate_Click);
      // 
      // txtInput
      // 
      this.txtInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.txtInput.Location = new System.Drawing.Point(184, 16);
      this.txtInput.Name = "txtInput";
      this.txtInput.Size = new System.Drawing.Size(80, 24);
      this.txtInput.TabIndex = 6;
      this.txtInput.Text = "";
      // 
      // lblEnter
      // 
      this.lblEnter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblEnter.Location = new System.Drawing.Point(8, 16);
      this.lblEnter.Name = "lblEnter";
      this.lblEnter.Size = new System.Drawing.Size(136, 24);
      this.lblEnter.TabIndex = 5;
      this.lblEnter.Text = "Enter an Integer:";
      this.lblEnter.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
      // 
      // frmFactorial
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(288, 317);
      this.Controls.Add(this.txtDisplay);
      this.Controls.Add(this.lblFactorial);
      this.Controls.Add(this.cmdCalculate);
      this.Controls.Add(this.txtInput);
      this.Controls.Add(this.lblEnter);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFactorial";
      this.Text = "Factorial Program";
      this.ResumeLayout(false);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose( bool disposing )
    //***
    // Action
    //   - Clean up instance of 'frmDefault'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if ( disposing )
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose( disposing );
    }
    // Dispose(bool)

    public frmFactorial()
    //***
    // Action
    //   - Create instance of 'frmFactorial'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmFactorial()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdCalculate_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Loop from 0 to 'lngValue' (lngCounter)
    //     - Calculate factorial of 'lngCounter'
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - string Environment.NewLine()
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter;
      long lngValue = Convert.ToInt64(txtInput.Text);

      txtDisplay.Text = "";

      for (lngCounter = 0; lngCounter <= lngValue; lngCounter++)
      {
        txtDisplay.Text += lngCounter + "! = " + Factorial(lngCounter) + Environment.NewLine;
      }
      // lngCounter = lngValue + 1
   
    }
    // cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click

    #endregion
    
    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmFactorial
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmFactorial());
    }
    // Main() 

    private long Factorial(long lngNumber)
    //***
    // Action
    //   - Recursively generates factorial of number
    // Called by
    //   - Factorial(Int64)
    // Calls
    //   - cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click
    //   - long Factorial(long)
    // Created
    //    - CopyPaste � 20220207 � VVDW
    // Changed
    //    - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //    - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //    -
    // Proposal (To Do)
    //    -
    //***
    {

      if (lngNumber <= 1)
      {
        return 1;
      }
      else
        // lngNumber > 1
      {
        return lngNumber * Factorial(lngNumber - 1);
      }
      // lngNumber <= 1

    }
    // long Factorial(long) 

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmFactorial

}
// Factorial