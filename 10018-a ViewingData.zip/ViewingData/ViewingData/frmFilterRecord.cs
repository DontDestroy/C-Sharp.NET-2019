//***
// Action
//   - Filter and sort records using the DataView object
// Created
//   - CopyPaste � 20251205 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251205 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFilterRecord: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.ComboBox cmbSort;
    internal System.Windows.Forms.Label lblSort;
    internal System.Windows.Forms.DataGrid dgrCustomer;
    internal System.Windows.Forms.GroupBox grpStartingLetter;
    internal System.Windows.Forms.Button cmdAll;
    internal System.Windows.Forms.Button cmdZ;
    internal System.Windows.Forms.Button cmdY;
    internal System.Windows.Forms.Button cmdX;
    internal System.Windows.Forms.Button cmdW;
    internal System.Windows.Forms.Button cmdV;
    internal System.Windows.Forms.Button cmdU;
    internal System.Windows.Forms.Button cmdT;
    internal System.Windows.Forms.Button cmdS;
    internal System.Windows.Forms.Button cmdR;
    internal System.Windows.Forms.Button cmdQ;
    internal System.Windows.Forms.Button cmdP;
    internal System.Windows.Forms.Button cmdO;
    internal System.Windows.Forms.Button cmdN;
    internal System.Windows.Forms.Button cmdM;
    internal System.Windows.Forms.Button cmdL;
    internal System.Windows.Forms.Button cmdK;
    internal System.Windows.Forms.Button cmdJ;
    internal System.Windows.Forms.Button cmdI;
    internal System.Windows.Forms.Button cmdH;
    internal System.Windows.Forms.Button cmdG;
    internal System.Windows.Forms.Button cmdF;
    internal System.Windows.Forms.Button cmdE;
    internal System.Windows.Forms.Button cmdD;
    internal System.Windows.Forms.Button cmdC;
    internal System.Windows.Forms.Button cmdB;
    internal System.Windows.Forms.Button cmdA;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFilterRecord));
      this.cmbSort = new System.Windows.Forms.ComboBox();
      this.lblSort = new System.Windows.Forms.Label();
      this.dgrCustomer = new System.Windows.Forms.DataGrid();
      this.grpStartingLetter = new System.Windows.Forms.GroupBox();
      this.cmdAll = new System.Windows.Forms.Button();
      this.cmdZ = new System.Windows.Forms.Button();
      this.cmdY = new System.Windows.Forms.Button();
      this.cmdX = new System.Windows.Forms.Button();
      this.cmdW = new System.Windows.Forms.Button();
      this.cmdV = new System.Windows.Forms.Button();
      this.cmdU = new System.Windows.Forms.Button();
      this.cmdT = new System.Windows.Forms.Button();
      this.cmdS = new System.Windows.Forms.Button();
      this.cmdR = new System.Windows.Forms.Button();
      this.cmdQ = new System.Windows.Forms.Button();
      this.cmdP = new System.Windows.Forms.Button();
      this.cmdO = new System.Windows.Forms.Button();
      this.cmdN = new System.Windows.Forms.Button();
      this.cmdM = new System.Windows.Forms.Button();
      this.cmdL = new System.Windows.Forms.Button();
      this.cmdK = new System.Windows.Forms.Button();
      this.cmdJ = new System.Windows.Forms.Button();
      this.cmdI = new System.Windows.Forms.Button();
      this.cmdH = new System.Windows.Forms.Button();
      this.cmdG = new System.Windows.Forms.Button();
      this.cmdF = new System.Windows.Forms.Button();
      this.cmdE = new System.Windows.Forms.Button();
      this.cmdD = new System.Windows.Forms.Button();
      this.cmdC = new System.Windows.Forms.Button();
      this.cmdB = new System.Windows.Forms.Button();
      this.cmdA = new System.Windows.Forms.Button();
      ((System.ComponentModel.ISupportInitialize)(this.dgrCustomer)).BeginInit();
      this.grpStartingLetter.SuspendLayout();
      this.SuspendLayout();
      // 
      // cmbSort
      // 
      this.cmbSort.Location = new System.Drawing.Point(128, 86);
      this.cmbSort.Name = "cmbSort";
      this.cmbSort.Size = new System.Drawing.Size(168, 21);
      this.cmbSort.TabIndex = 6;
      this.cmbSort.SelectedIndexChanged += new System.EventHandler(this.cmbSort_SelectedIndexChanged);
      // 
      // lblSort
      // 
      this.lblSort.Location = new System.Drawing.Point(16, 86);
      this.lblSort.Name = "lblSort";
      this.lblSort.Size = new System.Drawing.Size(104, 16);
      this.lblSort.TabIndex = 5;
      this.lblSort.Text = "Column to Sort On:";
      // 
      // dgrCustomer
      // 
      this.dgrCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrCustomer.DataMember = "";
      this.dgrCustomer.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrCustomer.Location = new System.Drawing.Point(8, 118);
      this.dgrCustomer.Name = "dgrCustomer";
      this.dgrCustomer.ReadOnly = true;
      this.dgrCustomer.Size = new System.Drawing.Size(464, 232);
      this.dgrCustomer.TabIndex = 7;
      // 
      // grpStartingLetter
      // 
      this.grpStartingLetter.Controls.Add(this.cmdAll);
      this.grpStartingLetter.Controls.Add(this.cmdZ);
      this.grpStartingLetter.Controls.Add(this.cmdY);
      this.grpStartingLetter.Controls.Add(this.cmdX);
      this.grpStartingLetter.Controls.Add(this.cmdW);
      this.grpStartingLetter.Controls.Add(this.cmdV);
      this.grpStartingLetter.Controls.Add(this.cmdU);
      this.grpStartingLetter.Controls.Add(this.cmdT);
      this.grpStartingLetter.Controls.Add(this.cmdS);
      this.grpStartingLetter.Controls.Add(this.cmdR);
      this.grpStartingLetter.Controls.Add(this.cmdQ);
      this.grpStartingLetter.Controls.Add(this.cmdP);
      this.grpStartingLetter.Controls.Add(this.cmdO);
      this.grpStartingLetter.Controls.Add(this.cmdN);
      this.grpStartingLetter.Controls.Add(this.cmdM);
      this.grpStartingLetter.Controls.Add(this.cmdL);
      this.grpStartingLetter.Controls.Add(this.cmdK);
      this.grpStartingLetter.Controls.Add(this.cmdJ);
      this.grpStartingLetter.Controls.Add(this.cmdI);
      this.grpStartingLetter.Controls.Add(this.cmdH);
      this.grpStartingLetter.Controls.Add(this.cmdG);
      this.grpStartingLetter.Controls.Add(this.cmdF);
      this.grpStartingLetter.Controls.Add(this.cmdE);
      this.grpStartingLetter.Controls.Add(this.cmdD);
      this.grpStartingLetter.Controls.Add(this.cmdC);
      this.grpStartingLetter.Controls.Add(this.cmdB);
      this.grpStartingLetter.Controls.Add(this.cmdA);
      this.grpStartingLetter.Location = new System.Drawing.Point(8, 6);
      this.grpStartingLetter.Name = "grpStartingLetter";
      this.grpStartingLetter.Size = new System.Drawing.Size(464, 72);
      this.grpStartingLetter.TabIndex = 4;
      this.grpStartingLetter.TabStop = false;
      this.grpStartingLetter.Text = "Click on a Letter";
      // 
      // cmdAll
      // 
      this.cmdAll.Location = new System.Drawing.Point(392, 40);
      this.cmdAll.Name = "cmdAll";
      this.cmdAll.Size = new System.Drawing.Size(64, 24);
      this.cmdAll.TabIndex = 27;
      this.cmdAll.Text = "All";
      this.cmdAll.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdZ
      // 
      this.cmdZ.Location = new System.Drawing.Point(360, 40);
      this.cmdZ.Name = "cmdZ";
      this.cmdZ.Size = new System.Drawing.Size(32, 24);
      this.cmdZ.TabIndex = 26;
      this.cmdZ.Text = "Z";
      this.cmdZ.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdY
      // 
      this.cmdY.Location = new System.Drawing.Point(328, 40);
      this.cmdY.Name = "cmdY";
      this.cmdY.Size = new System.Drawing.Size(32, 24);
      this.cmdY.TabIndex = 25;
      this.cmdY.Text = "Y";
      this.cmdY.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdX
      // 
      this.cmdX.Location = new System.Drawing.Point(296, 40);
      this.cmdX.Name = "cmdX";
      this.cmdX.Size = new System.Drawing.Size(32, 24);
      this.cmdX.TabIndex = 24;
      this.cmdX.Text = "X";
      this.cmdX.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdW
      // 
      this.cmdW.Location = new System.Drawing.Point(264, 40);
      this.cmdW.Name = "cmdW";
      this.cmdW.Size = new System.Drawing.Size(32, 24);
      this.cmdW.TabIndex = 23;
      this.cmdW.Text = "W";
      this.cmdW.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdV
      // 
      this.cmdV.Location = new System.Drawing.Point(232, 40);
      this.cmdV.Name = "cmdV";
      this.cmdV.Size = new System.Drawing.Size(32, 24);
      this.cmdV.TabIndex = 22;
      this.cmdV.Text = "V";
      this.cmdV.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdU
      // 
      this.cmdU.Location = new System.Drawing.Point(200, 40);
      this.cmdU.Name = "cmdU";
      this.cmdU.Size = new System.Drawing.Size(32, 24);
      this.cmdU.TabIndex = 21;
      this.cmdU.Text = "U";
      this.cmdU.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdT
      // 
      this.cmdT.Location = new System.Drawing.Point(168, 40);
      this.cmdT.Name = "cmdT";
      this.cmdT.Size = new System.Drawing.Size(32, 24);
      this.cmdT.TabIndex = 20;
      this.cmdT.Text = "T";
      this.cmdT.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdS
      // 
      this.cmdS.Location = new System.Drawing.Point(136, 40);
      this.cmdS.Name = "cmdS";
      this.cmdS.Size = new System.Drawing.Size(32, 24);
      this.cmdS.TabIndex = 19;
      this.cmdS.Text = "S";
      this.cmdS.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdR
      // 
      this.cmdR.Location = new System.Drawing.Point(104, 40);
      this.cmdR.Name = "cmdR";
      this.cmdR.Size = new System.Drawing.Size(32, 24);
      this.cmdR.TabIndex = 18;
      this.cmdR.Text = "R";
      this.cmdR.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdQ
      // 
      this.cmdQ.Location = new System.Drawing.Point(72, 40);
      this.cmdQ.Name = "cmdQ";
      this.cmdQ.Size = new System.Drawing.Size(32, 24);
      this.cmdQ.TabIndex = 17;
      this.cmdQ.Text = "Q";
      this.cmdQ.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdP
      // 
      this.cmdP.Location = new System.Drawing.Point(40, 40);
      this.cmdP.Name = "cmdP";
      this.cmdP.Size = new System.Drawing.Size(32, 24);
      this.cmdP.TabIndex = 16;
      this.cmdP.Text = "P";
      this.cmdP.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdO
      // 
      this.cmdO.Location = new System.Drawing.Point(8, 40);
      this.cmdO.Name = "cmdO";
      this.cmdO.Size = new System.Drawing.Size(32, 24);
      this.cmdO.TabIndex = 15;
      this.cmdO.Text = "O";
      this.cmdO.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdN
      // 
      this.cmdN.Location = new System.Drawing.Point(424, 16);
      this.cmdN.Name = "cmdN";
      this.cmdN.Size = new System.Drawing.Size(32, 24);
      this.cmdN.TabIndex = 14;
      this.cmdN.Text = "N";
      // 
      // cmdM
      // 
      this.cmdM.Location = new System.Drawing.Point(392, 16);
      this.cmdM.Name = "cmdM";
      this.cmdM.Size = new System.Drawing.Size(32, 24);
      this.cmdM.TabIndex = 13;
      this.cmdM.Text = "M";
      this.cmdM.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdL
      // 
      this.cmdL.Location = new System.Drawing.Point(360, 16);
      this.cmdL.Name = "cmdL";
      this.cmdL.Size = new System.Drawing.Size(32, 24);
      this.cmdL.TabIndex = 12;
      this.cmdL.Text = "L";
      this.cmdL.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdK
      // 
      this.cmdK.Location = new System.Drawing.Point(328, 16);
      this.cmdK.Name = "cmdK";
      this.cmdK.Size = new System.Drawing.Size(32, 24);
      this.cmdK.TabIndex = 11;
      this.cmdK.Text = "K";
      this.cmdK.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdJ
      // 
      this.cmdJ.Location = new System.Drawing.Point(296, 16);
      this.cmdJ.Name = "cmdJ";
      this.cmdJ.Size = new System.Drawing.Size(32, 24);
      this.cmdJ.TabIndex = 10;
      this.cmdJ.Text = "J";
      this.cmdJ.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdI
      // 
      this.cmdI.Location = new System.Drawing.Point(264, 16);
      this.cmdI.Name = "cmdI";
      this.cmdI.Size = new System.Drawing.Size(32, 24);
      this.cmdI.TabIndex = 9;
      this.cmdI.Text = "I";
      this.cmdI.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdH
      // 
      this.cmdH.Location = new System.Drawing.Point(232, 16);
      this.cmdH.Name = "cmdH";
      this.cmdH.Size = new System.Drawing.Size(32, 24);
      this.cmdH.TabIndex = 8;
      this.cmdH.Text = "H";
      this.cmdH.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdG
      // 
      this.cmdG.Location = new System.Drawing.Point(200, 16);
      this.cmdG.Name = "cmdG";
      this.cmdG.Size = new System.Drawing.Size(32, 24);
      this.cmdG.TabIndex = 7;
      this.cmdG.Text = "G";
      this.cmdG.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdF
      // 
      this.cmdF.Location = new System.Drawing.Point(168, 16);
      this.cmdF.Name = "cmdF";
      this.cmdF.Size = new System.Drawing.Size(32, 24);
      this.cmdF.TabIndex = 6;
      this.cmdF.Text = "F";
      this.cmdF.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdE
      // 
      this.cmdE.Location = new System.Drawing.Point(136, 16);
      this.cmdE.Name = "cmdE";
      this.cmdE.Size = new System.Drawing.Size(32, 24);
      this.cmdE.TabIndex = 5;
      this.cmdE.Text = "E";
      this.cmdE.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdD
      // 
      this.cmdD.Location = new System.Drawing.Point(104, 16);
      this.cmdD.Name = "cmdD";
      this.cmdD.Size = new System.Drawing.Size(32, 24);
      this.cmdD.TabIndex = 4;
      this.cmdD.Text = "D";
      this.cmdD.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdC
      // 
      this.cmdC.Location = new System.Drawing.Point(72, 16);
      this.cmdC.Name = "cmdC";
      this.cmdC.Size = new System.Drawing.Size(32, 24);
      this.cmdC.TabIndex = 3;
      this.cmdC.Text = "C";
      this.cmdC.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdB
      // 
      this.cmdB.Location = new System.Drawing.Point(40, 16);
      this.cmdB.Name = "cmdB";
      this.cmdB.Size = new System.Drawing.Size(32, 24);
      this.cmdB.TabIndex = 2;
      this.cmdB.Text = "B";
      this.cmdB.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdA
      // 
      this.cmdA.Location = new System.Drawing.Point(8, 16);
      this.cmdA.Name = "cmdA";
      this.cmdA.Size = new System.Drawing.Size(32, 24);
      this.cmdA.TabIndex = 0;
      this.cmdA.Text = "A";
      this.cmdA.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // frmFilterRecord
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(480, 357);
      this.Controls.Add(this.cmbSort);
      this.Controls.Add(this.lblSort);
      this.Controls.Add(this.dgrCustomer);
      this.Controls.Add(this.grpStartingLetter);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFilterRecord";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Filter and sort records using the DataView object";
      this.Load += new System.EventHandler(this.frmFilterRecord_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrCustomer)).EndInit();
      this.grpStartingLetter.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFilterRecord'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFilterRecord()
      //***
      // Action
      //   - Create instance of 'frmFilterRecord'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFilterRecord()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private DataTable mdtCustomer = new DataTable();
    private DataView mdvCustomer = new  DataView();
    private SqlDataAdapter mdtaCustomer;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdLetter_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Determine on what button was clicked
      //   - If the text on the button was 1 character long
      //     - Set a filter on that character
      //   - If not
      //     - Remove the filter
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - SetDataViewFilter(string)
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strButtonText = ((Button)theSender).Text;

      switch (strButtonText.Length)
      {
        case 1:
          SetDataViewFilter(strButtonText);
          break;
        default:
          SetDataViewFilter("");
          break;
      }
      // strButtonText.Length
    
    }
    // cmdLetter_Click(System.Object, System.EventArgs) Handles cmdLetter.Click

    private void cmbSort_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If Sort field of data view is the same as teh selected sort option
      //     - Sort the dataview on that column in decending order
      //   - If not
      //     - Sort the dataview on that column
      // Called by
      //   - User action (Selecting an option in combobox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (mdvCustomer.Sort == cmbSort.Text)
      {
        mdvCustomer.Sort = cmbSort.Text + " DESC";
      }
      else
        // mdvCustomer.Sort <> cmbSort.Text
      {
        mdvCustomer.Sort = cmbSort.Text;
      }
      // mdvCustomer.Sort = cmbSort.Text
    
    }
    // cmbSort_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbSort.SelectedIndexChanged

    private void frmFilterRecord_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a data column
      //   - Define a SQL statement
      //   - Try to
      //     - We select all information
      //     - Create a data adapter using the connection string and the SQL statement
      //     - Fill the data table with the data adapter result
      //     - Loop thru all the columns
      //       - Add the column name to the combobox (to sort on)
      //     - cmdAll is selected
      //     - Fill is set to no filter
      //   - On an exception (error)
      //     - Show the corresponding error message
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - cpConnectionString()
      //   - cpConnectionString.BuildConnectionString()
      //   - SetDataViewFilter(string)
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpConnectionString theConnection = new cpConnectionString();
      string strSQLStatement;

      try
      {
        strSQLStatement = "SELECT * FROM tblCPCustomer";
        mdtaCustomer = new SqlDataAdapter(strSQLStatement, theConnection.BuildConnectionString());
        mdtaCustomer.Fill(mdtCustomer);

        foreach (DataColumn dclCurrent in mdtCustomer.Columns)
        {
          cmbSort.Items.Add(dclCurrent.ColumnName);
        }
        // in mdtCustomer.Columns

        cmdAll.Select();
        SetDataViewFilter("");
      }
      catch (SqlException theSqlException)
      {
        MessageBox.Show(theSqlException.Message);
      }
      finally
      {
      }
    
    }
    // frmFilterRecord_Load(System.Object theSender, System.EventArgs theEventArguments) Handles this.Load
  
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    private void SetDataViewFilter(string strFilterLetter)
      //***
      // Action
      //   - The data view variable becomes the default view of data table customer
      //   - The row filter on the data view becomes a SQL statement
      //   - The data grid data source becomes the data view
      // Called by
      //   - cmdLetter_Click(System.Object, System.EventArgs) Handles cmdLetter.Click
      //   - frmFilterRecord_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdvCustomer = mdtCustomer.DefaultView;
      mdvCustomer.RowFilter = "strCompanyName LIKE '" + strFilterLetter + "%'";
      dgrCustomer.DataSource = mdvCustomer;
    }
    // SetDataViewFilter(string)
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmFilterRecord

}
// CopyPaste.Learning