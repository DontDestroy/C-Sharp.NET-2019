﻿//***
// Action
//   - Doing stuff with a delegate
// Created
//   - CopyPaste – 20230408 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230408 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;

namespace CompareDelegateWithLambda
{

  public class cpCommon
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate bool FilterNumbers(int intNumber);

    #endregion

    #region "Sub / Function"

    public static int[] FilterArrayOfNumbers(int[] arrintNumbers, FilterNumbers theFilter)
    //***
    // Action
    //   - Filter a given array 'arrintNumber' with a given method 'theFilter'
    //   - The given array is the input, all elements are checked using a delegate
    //   - The given method is also input, this is the way the filtering is done
    //   - All numbers that passing the filter are returned
    // Called by
    //   - cpProgram.DelegateExample()
    //   - cpProgram.LambdaExample()
    //   - cpProgram.UnnamedMethodExample()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230408 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230408 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***

    {
      ArrayList arrResultList = new ArrayList();

      foreach (int aNumber in arrintNumbers)
      {

        if (theFilter(aNumber))
        {
          arrResultList.Add(aNumber);
        }
        // theFilter(aNumber)

      }
      // in arrintNumbers

      return (int[]) arrResultList.ToArray(typeof(int));
    }
    // int[] FilterArrayOfNumbers(int[], FilterNumbers)

    public static void LoopArray(int[] arrintNumbers)
    //***
    // Action
    //   - Loop thru all the elements of an array
    // Called by
    //   - cpProgram.DelegateExample()
    //   - cpProgram.LambdaExample()
    //   - cpProgram.UnnamedMethodExample()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230408 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230408 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      foreach (int aNumber in arrintNumbers)
      {
        Console.Write(aNumber + " ");
      }
      // in arrintNumbers

      Console.WriteLine();
    }
    // LoopArray(int[])

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCommon

}
// CompareDelegateWithLambda
