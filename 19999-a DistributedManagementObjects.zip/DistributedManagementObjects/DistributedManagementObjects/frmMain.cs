//***
// Action
//   - Starting form of the application
//     - Five options are shown with tooltip information
// Created
//   - CopyPaste � 20260717 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260717 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMain: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdDetachAttach;
    internal System.Windows.Forms.Button cmdTransferTables;
    internal System.Windows.Forms.Button cmdRestore;
    internal System.Windows.Forms.ToolTip ttpInfo;
    internal System.Windows.Forms.Button cmdBackup;
    internal System.Windows.Forms.Button cmdSQLServer;
    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMain));
      this.cmdDetachAttach = new System.Windows.Forms.Button();
      this.cmdTransferTables = new System.Windows.Forms.Button();
      this.cmdRestore = new System.Windows.Forms.Button();
      this.ttpInfo = new System.Windows.Forms.ToolTip(this.components);
      this.cmdBackup = new System.Windows.Forms.Button();
      this.cmdSQLServer = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdDetachAttach
      // 
      this.cmdDetachAttach.Location = new System.Drawing.Point(24, 216);
      this.cmdDetachAttach.Name = "cmdDetachAttach";
      this.cmdDetachAttach.Size = new System.Drawing.Size(128, 40);
      this.cmdDetachAttach.TabIndex = 9;
      this.cmdDetachAttach.Text = "Detach / Attach";
      this.cmdDetachAttach.Click += new System.EventHandler(this.cmdDetachAttach_Click);
      // 
      // cmdTransferTables
      // 
      this.cmdTransferTables.Location = new System.Drawing.Point(24, 168);
      this.cmdTransferTables.Name = "cmdTransferTables";
      this.cmdTransferTables.Size = new System.Drawing.Size(128, 40);
      this.cmdTransferTables.TabIndex = 8;
      this.cmdTransferTables.Text = "Transfer Tables";
      this.cmdTransferTables.Click += new System.EventHandler(this.cmdTransferTables_Click);
      // 
      // cmdRestore
      // 
      this.cmdRestore.Location = new System.Drawing.Point(24, 120);
      this.cmdRestore.Name = "cmdRestore";
      this.cmdRestore.Size = new System.Drawing.Size(128, 40);
      this.cmdRestore.TabIndex = 7;
      this.cmdRestore.Text = "Restore";
      this.cmdRestore.Click += new System.EventHandler(this.cmdRestore_Click);
      // 
      // cmdBackup
      // 
      this.cmdBackup.Location = new System.Drawing.Point(24, 72);
      this.cmdBackup.Name = "cmdBackup";
      this.cmdBackup.Size = new System.Drawing.Size(128, 40);
      this.cmdBackup.TabIndex = 6;
      this.cmdBackup.Text = "Backup";
      this.cmdBackup.Click += new System.EventHandler(this.cmdBackup_Click);
      // 
      // cmdSQLServer
      // 
      this.cmdSQLServer.Location = new System.Drawing.Point(24, 24);
      this.cmdSQLServer.Name = "cmdSQLServer";
      this.cmdSQLServer.Size = new System.Drawing.Size(128, 40);
      this.cmdSQLServer.TabIndex = 5;
      this.cmdSQLServer.Text = "Select SQL Server";
      this.cmdSQLServer.Click += new System.EventHandler(this.cmdSQLServer_Click);
      // 
      // frmMain
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(176, 277);
      this.Controls.Add(this.cmdTransferTables);
      this.Controls.Add(this.cmdRestore);
      this.Controls.Add(this.cmdBackup);
      this.Controls.Add(this.cmdSQLServer);
      this.Controls.Add(this.cmdDetachAttach);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMain";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Main Form";
      this.Load += new System.EventHandler(this.frmMain_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMain'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMain()
      //***
      // Action
      //   - Create instance of 'frmMain'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMain()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdBackup_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmBackup
      //   - Show the instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmBackup()
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmBackup theForm = new frmBackup();

      theForm.Show();
    }
    // cmdBackup_Click(System.Object, System.EventArgs) Handles cmdBackup.Click
    
    private void cmdDetachAttach_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmDetachAttach
      //   - Show the instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmDetachAttach()
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmDetachAttach theForm = new frmDetachAttach();

      theForm.Show();
    }
    // cmdDetachAttach_Click(System.Object, System.EventArgs) Handles cmdDetachAttach.Click

    private void cmdRestore_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmRestore
      //   - Show the instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmRestore()
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmRestore theForm = new frmRestore();

      theForm.Show();
    }
    // cmdRestore_Click(System.Object, System.EventArgs) Handles cmdRestore.Click

    private void cmdSQLServer_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmSelectSQLServer
      //   - Show the instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmSelectSQLServer()
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmSelectSQLServer theForm = new frmSelectSQLServer();

      theForm.Show();
    }
    // cmdSQLServer_Click(System.Object, System.EventArgs) Handles cmdSQLServer.Click

    private void cmdTransferTables_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmTransferTables
      //   - Show the instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmTransferTables()
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmTransferTables theForm = new frmTransferTables();

      theForm.Show();
    }
    // cmdTransferTables_Click(System.Object, System.EventArgs) Handles cmdTransferTables.Click

    private void frmMain_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set for every button in the form a corresponding tooltip
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ttpInfo.SetToolTip(cmdSQLServer, "Create a Dialog to Connect to a New Database");
      ttpInfo.SetToolTip(cmdBackup, "Backing Up and Verifying a SQL Server Database");
      ttpInfo.SetToolTip(cmdRestore, "Restoring a SQL Server Database");
      ttpInfo.SetToolTip(cmdTransferTables, "Transfer Objects Between SQL Server Databases");
      ttpInfo.SetToolTip(cmdDetachAttach, "Creating a Detach/Attach Database Dialog");
    }
    // frmMain_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMain
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmMain()
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMain());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMain

}
// CopyPaste.Learning