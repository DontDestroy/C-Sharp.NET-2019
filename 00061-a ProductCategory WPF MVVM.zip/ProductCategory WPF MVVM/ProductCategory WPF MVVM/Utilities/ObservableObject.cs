﻿//***
// Action
//   - Class that handles the property changed code
// Created
//   - CopyPaste – 20220824 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220824 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;

namespace ProductCategory_WPF_MVVM.Utilities
{

  public class ObservableObject : INotifyPropertyChanged
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public event PropertyChangedEventHandler PropertyChanged;

    #endregion

    #region "Sub / Function"

    protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = "")
    //***
    // Action
    //   - Code that runs when a property is changed
    //   - CallerMemberNameAttribute allow you to obtain the property or method name of the caller
    //   - Invoke the change of the property (synchronous)
    // Called by
    //   - bool OnPropertyChanged<T>(°T, T, string)
    // Calls
    //   - CallerMemberNameAttribute
    // Created
    //   - CopyPaste – 20220824 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220824 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
    // OnPropertyChanged(string)

    protected virtual bool OnPropertyChanged<T>(ref T backingField, T value, [CallerMemberName] string propertyName = "")
    //***
    // Action
    //   - Code that runs when a property is changed
    //   - CallerMemberNameAttribute allow you to obtain the property or method name of the caller
    //   - Something changes into something else
    //   - If the change is not different
    //     - Return false
    //   - If Not
    //     - Remember the go back value
    //     - Execute the change
    //     - Return true
    // Called by
    //   - 
    // Calls
    //   - CallerMemberNameAttribute
    //   - OnPropertyChanged(string)
    // Created
    //   - CopyPaste – 20220824 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220824 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (EqualityComparer<T>.Default.Equals(backingField, value))
      {
        return false;
      }
      // Not EqualityComparer<T>.Default.Equals(backingField, value)
      else
      {
        backingField = value;
        OnPropertyChanged(propertyName);
        return true;
      }
      // EqualityComparer<T>.Default.Equals(backingField, value)

    }
    // bool OnPropertyChanged<T>(°T, T, string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // ObservableObject

}
// ProductCategory_WPF_MVVM.Utilities