//***
// Action
//   - Calculate intrest for the next 10 years
// Created
//   - CopyPaste � 20220119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220119 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace Interest
{

  class cpInterest
	{

    static void Main()
    //***
    // Action
    //   - Define some variables
    //   - Initialise some variables
    //   - Loop from 1 to 10 (lngYear)
    //     - Calculate intrest
    //     - Prepare 'strOutput'
    //   - Show 'strOutput' in message box
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - decimal System.Convert.ToDecimal(double)
    //   - DialogResult System.Windows.Forms.MessageBox.Show(String, String, System.Windows.Forms.MessageBoxButtons, System.Windows.Forms.MessageBoxIcon)
    //   - string System.String.Format(string, System.Object)
    // Created
    //   - CopyPaste � 20220119 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220119 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      decimal decAmount;
      double dblPrincipal;
      double dblRate;
      double dblYear;
      string strOutput;

      dblPrincipal = 1000;
      dblRate = 0.05;
      strOutput = "Year\tAmount on deposit\n";

      for (dblYear = 1; dblYear <= 10; dblYear++)
      {
        decAmount = Convert.ToDecimal(dblPrincipal * System.Math.Pow((1 + dblRate), dblYear));
        strOutput += dblYear + "\t" + String.Format("{0:#,##0.00}", decAmount) + "\n";
      }
      // lngYear = 11

      MessageBox.Show(strOutput, "Compound Interest", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // Main()

  }
  // cpInterest

}
// Interest