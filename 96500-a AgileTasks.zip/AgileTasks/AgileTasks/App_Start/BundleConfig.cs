﻿//***
// Action
//   - Implementation of Bundle Config
// Created
//   - CopyPaste – 20260427 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260427 – VVDW
// Proposal (To Do)
//   -
//***

using System.Web;
using System.Web.Optimization;

namespace AgileTasks
{
  public class BundleConfig
  {

    #region "Constructors / Destructors"

    public BundleConfig()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - xxxx
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // BundleConfig()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void RegisterBundles(BundleCollection bundles)
    //***
    // Action
    //   - Register bundles
    //   - Some defaults by the template
    //   - Changed jQuery scripts
    //   - Changed Content CSS
    // Called by
    //   - MvcApplication.Application_Start()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bundles.Add(new ScriptBundle("~/bundles/jqueryval")
        .Include("~/Scripts/jquery.validate*"));

      // Use the development version of Modernizr to develop with and learn from. Then, when you're
      // ready for production, use the build tool at https://modernizr.com to pick only the tests you need.
      bundles.Add(new ScriptBundle("~/bundles/modernizr")
        .Include("~/Scripts/modernizr-*"));

      bundles.Add(new ScriptBundle("~/bundles/bootstrap")
        .Include("~/Scripts/bootstrap.js"));

      bundles.Add(new ScriptBundle("~/bundles/jquery")
        .Include("~/Scripts/jquery-{version}.js")
        .Include("~/Scripts/jquery-ui.min.js"));

      bundles.Add(new StyleBundle("~/Content/css")
        .Include("~/Content/bootstrap.css", "~/Content/customstyles.css"));

      // VVDW - This is downloaded from https://istope;metafizzy.co/
      // VVDW - It can also be copied from the finished example
      bundles.Add(new ScriptBundle("~/bundles/isotope")
        .Include("~/Scripts/isotope.pkgd.min.js"));
    }
    // RegisterBundles(BundleCollection)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // BundleConfig

}
// AgileTasks