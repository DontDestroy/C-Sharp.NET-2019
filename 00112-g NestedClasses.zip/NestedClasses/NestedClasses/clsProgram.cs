//***
// Action
//   - Testroutine of nested classes
// Created
//   - CopyPaste � 20240409 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240409 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Create a new employee
      //   - Set the workregime to full time
      //   - Show the vacation days
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpEmployee.cpWorkRegime.New(cpWorkRegimeType)
      //   - cpEmployee.Regime(cpEmployee.cpWorkRegime) (Set)
      //   - cpEmployee.New(String)
      //   - cpEmployee.Regime() As cpEmployee.cpWorkRegime (Get)
      //   - cpEmployee.Regime.Vacation() As Integer (Get)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpEmployee thecpEmployee = new cpEmployee("Vincent");
      cpEmployee.cpWorkRegime thecpWorkRegime;

      thecpEmployee.Regime = new cpEmployee.cpWorkRegime(cpEmployee.cpWorkRegime.cpWorkRegimeType.FullTime);
      thecpWorkRegime = thecpEmployee.Regime;
      
      Console.WriteLine("Employee:    " + thecpEmployee.Name);
      Console.WriteLine("Work regime: " + thecpWorkRegime.ToString());
      Console.WriteLine("Vacation:    " + thecpEmployee.Regime.Vacation);
      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning