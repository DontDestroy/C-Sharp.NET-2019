//***
// Action
//   - Define a base class and a derived class
//   - A constructor and some functions
// Created
//   - CopyPaste � 20220610 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220610 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Teaching
{
  
  public class cpBaseClass
  {

    #region "Constructors / Destructors"

    public cpBaseClass()
      //***
      // Action
      //   - Creating a cpBaseClass
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
      // cpBaseClass()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public virtual float IncrementSalary(float fltSalary)
      //***
      // Action
      //   - Increment the salary with 10%
      // Called by
      //   - ShowIncrementSalary(float)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return fltSalary * 1.1F;
    }
      // float IncrementSalary(float)

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    public void ShowIncrementSalary(float fltSalary)
      //***
      // Action
      //   - Show the incremented salary
      //   - Show the incremented salary of this
      // Called by
      //   - 
      // Calls
      //   - IncrementSalary(float) As float
      // Created
      //   - CopyPaste � 20220610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show(IncrementSalary(fltSalary).ToString(), "Base class");
      MessageBox.Show("This: " + this.IncrementSalary(fltSalary), "Base class");
    }
      // ShowIncrementSalary(float)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBaseClass

  public class cpDerivedClass : cpBaseClass
  {

    #region "Constructors / Destructors"

    public cpDerivedClass()
      //***
      // Action
      //   - Creating a cpDerivedClass
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpDerivedClass()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override float IncrementSalary(float fltSalary)
      //***
      // Action
      //   - Increment the salary with 20%
      // Called by
      //   - ShowIncrementSalary(float)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return fltSalary * 1.2F;
    }
    // float IncrementSalary(float)

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    public void ShowIncrementSalaryDerived(float fltSalary)
      //***
      // Action
      //   - Show the incremented salary
      //   - Show the incremented salary of this
      //   - Show the incremented salary of base
      // Called by
      //   - 
      // Calls
      //   - IncrementSalary(float) As float
      // Created
      //   - CopyPaste � 20220610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show(IncrementSalary(fltSalary).ToString(), "Derived class");
      MessageBox.Show("This: " + this.IncrementSalary(fltSalary), "Derived class");
      MessageBox.Show("Base: " + base.IncrementSalary(fltSalary), "Derived class");
    }
    // ShowIncrementSalaryDerived(float)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBaseClass

}
// CopyPaste.Teaching