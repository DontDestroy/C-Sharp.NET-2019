﻿//***
// Action
//   - Having DataCommands and DataReaders towards a database
// Created
//   - CopyPaste – 20210701 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210701 – VVDW
// Proposal (To Do)
//   -
//***

namespace DataCommandsWizard
{

  partial class frmDataCommandsWizard
  {

    #region Windows Form Designer generated code

    internal dsData dsData;
    internal System.Windows.Forms.BindingSource bdsrcEmployee;
    internal dsDataTableAdapters.tbaOrder tbaOrder;
    internal System.Windows.Forms.BindingSource bdsrcOrder;
    internal dsDataTableAdapters.tbaCustomer tbaCustomer;
    internal System.Windows.Forms.BindingSource bdsrcCustomer;
    internal dsDataTableAdapters.tbaEmployee tbaEmployee;
    internal System.Windows.Forms.Button cmdOrderCount;
    internal System.Windows.Forms.ListBox lstEmployee;
    internal System.Windows.Forms.Button cmdGetOrders;
    internal System.Windows.Forms.Button cmdFillLists;
    internal System.Windows.Forms.DataGrid dgrOrders;
    internal System.Windows.Forms.ListBox lstClient;
    internal System.Windows.Forms.Label lblOrders;
    internal System.Windows.Forms.Label lblClients;
    internal System.Windows.Forms.Label lblEmployees;
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataCommandsWizard));
      this.cmdOrderCount = new System.Windows.Forms.Button();
      this.lstEmployee = new System.Windows.Forms.ListBox();
      this.cmdGetOrders = new System.Windows.Forms.Button();
      this.cmdFillLists = new System.Windows.Forms.Button();
      this.dgrOrders = new System.Windows.Forms.DataGrid();
      this.lstClient = new System.Windows.Forms.ListBox();
      this.lblOrders = new System.Windows.Forms.Label();
      this.lblClients = new System.Windows.Forms.Label();
      this.lblEmployees = new System.Windows.Forms.Label();
      this.dsData = new DataCommandsWizard.dsData();
      this.bdsrcEmployee = new System.Windows.Forms.BindingSource(this.components);
      this.tbaOrder = new DataCommandsWizard.dsDataTableAdapters.tbaOrder();
      this.bdsrcOrder = new System.Windows.Forms.BindingSource(this.components);
      this.tbaCustomer = new DataCommandsWizard.dsDataTableAdapters.tbaCustomer();
      this.bdsrcCustomer = new System.Windows.Forms.BindingSource(this.components);
      this.tbaEmployee = new DataCommandsWizard.dsDataTableAdapters.tbaEmployee();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrders)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcEmployee)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcOrder)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCustomer)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdOrderCount
      // 
      this.cmdOrderCount.Location = new System.Drawing.Point(408, 58);
      this.cmdOrderCount.Name = "cmdOrderCount";
      this.cmdOrderCount.Size = new System.Drawing.Size(104, 24);
      this.cmdOrderCount.TabIndex = 16;
      this.cmdOrderCount.Text = "Order Count";
      this.cmdOrderCount.Click += new System.EventHandler(this.cmdOrderCount_Click);
      // 
      // lstEmployee
      // 
      this.lstEmployee.DataSource = this.bdsrcEmployee;
      this.lstEmployee.DisplayMember = "strFullName";
      this.lstEmployee.Location = new System.Drawing.Point(8, 26);
      this.lstEmployee.Name = "lstEmployee";
      this.lstEmployee.Size = new System.Drawing.Size(184, 95);
      this.lstEmployee.TabIndex = 10;
      this.lstEmployee.ValueMember = "intIdEmployee";
      // 
      // cmdGetOrders
      // 
      this.cmdGetOrders.Location = new System.Drawing.Point(408, 90);
      this.cmdGetOrders.Name = "cmdGetOrders";
      this.cmdGetOrders.Size = new System.Drawing.Size(104, 24);
      this.cmdGetOrders.TabIndex = 17;
      this.cmdGetOrders.Text = "Get Orders";
      this.cmdGetOrders.Click += new System.EventHandler(this.cmdGetOrders_Click);
      // 
      // cmdFillLists
      // 
      this.cmdFillLists.Location = new System.Drawing.Point(408, 26);
      this.cmdFillLists.Name = "cmdFillLists";
      this.cmdFillLists.Size = new System.Drawing.Size(104, 24);
      this.cmdFillLists.TabIndex = 15;
      this.cmdFillLists.Text = "Fill Lists";
      this.cmdFillLists.Click += new System.EventHandler(this.cmdFillLists_Click);
      // 
      // dgrOrders
      // 
      this.dgrOrders.DataMember = "";
      this.dgrOrders.DataSource = this.bdsrcOrder;
      this.dgrOrders.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrOrders.Location = new System.Drawing.Point(8, 154);
      this.dgrOrders.Name = "dgrOrders";
      this.dgrOrders.Size = new System.Drawing.Size(504, 208);
      this.dgrOrders.TabIndex = 14;
      // 
      // lstClient
      // 
      this.lstClient.DataSource = this.bdsrcCustomer;
      this.lstClient.DisplayMember = "strCompanyName";
      this.lstClient.Location = new System.Drawing.Point(200, 26);
      this.lstClient.Name = "lstClient";
      this.lstClient.Size = new System.Drawing.Size(200, 95);
      this.lstClient.TabIndex = 12;
      this.lstClient.ValueMember = "CustomerList.strIdCustomer";
      // 
      // lblOrders
      // 
      this.lblOrders.AutoSize = true;
      this.lblOrders.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOrders.Location = new System.Drawing.Point(8, 138);
      this.lblOrders.Name = "lblOrders";
      this.lblOrders.Size = new System.Drawing.Size(48, 13);
      this.lblOrders.TabIndex = 13;
      this.lblOrders.Text = "Orders:";
      // 
      // lblClients
      // 
      this.lblClients.AutoSize = true;
      this.lblClients.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblClients.Location = new System.Drawing.Point(200, 10);
      this.lblClients.Name = "lblClients";
      this.lblClients.Size = new System.Drawing.Size(49, 13);
      this.lblClients.TabIndex = 11;
      this.lblClients.Text = "Clients:";
      // 
      // lblEmployees
      // 
      this.lblEmployees.AutoSize = true;
      this.lblEmployees.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblEmployees.Location = new System.Drawing.Point(8, 10);
      this.lblEmployees.Name = "lblEmployees";
      this.lblEmployees.Size = new System.Drawing.Size(71, 13);
      this.lblEmployees.TabIndex = 9;
      this.lblEmployees.Text = "Employees:";
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // bdsrcEmployee
      // 
      this.bdsrcEmployee.DataMember = "EmployeeList";
      this.bdsrcEmployee.DataSource = this.dsData;
      // 
      // tbaOrder
      // 
      this.tbaOrder.ClearBeforeFill = true;
      // 
      // bdsrcOrder
      // 
      this.bdsrcOrder.DataMember = "OrderTotals";
      this.bdsrcOrder.DataSource = this.dsData;
      // 
      // tbaCustomer
      // 
      this.tbaCustomer.ClearBeforeFill = true;
      // 
      // bdsrcCustomer
      // 
      this.bdsrcCustomer.DataMember = "CustomerList";
      this.bdsrcCustomer.DataSource = this.dsData;
      // 
      // tbaEmployee
      // 
      this.tbaEmployee.ClearBeforeFill = true;
      // 
      // frmDataCommandsWizard
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(520, 373);
      this.Controls.Add(this.cmdOrderCount);
      this.Controls.Add(this.lstEmployee);
      this.Controls.Add(this.cmdGetOrders);
      this.Controls.Add(this.cmdFillLists);
      this.Controls.Add(this.dgrOrders);
      this.Controls.Add(this.lstClient);
      this.Controls.Add(this.lblOrders);
      this.Controls.Add(this.lblClients);
      this.Controls.Add(this.lblEmployees);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataCommandsWizard";
      this.Text = "Data Commands Wizard";
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrders)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcEmployee)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcOrder)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCustomer)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      if (disposing && (components != null))
      {
        components.Dispose();
      }
      // (disposing && (components != null))

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataCommandsWizard

}
// DataCommandsWizard
