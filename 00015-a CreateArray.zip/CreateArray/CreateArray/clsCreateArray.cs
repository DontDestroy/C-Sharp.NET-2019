//***
// Action
//   - Examples of arrays
// Created
//   - CopyPaste � 20220210 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220210 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CreateArray
{

  class cpCreateArray
	{

    static void Main()
    //***
    // Action
    //   - 
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - int Array.GetUpperBound(int)
    //   - int Array.Length()
    //   - DialogResult MessageBox.Show(string, string, int, int) As DialogResult
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int intCounter;
      int[] arrNumberDefault;
      int[] arrNumberOne;
      int[] arrNumberTwo;
      string strOutput = "";

      arrNumberDefault = new int[9];
      arrNumberOne = new int[] {32, 27, 64, 18, 95, 14, 90, 70, 60, 37};
      arrNumberTwo = new int[arrNumberOne.GetUpperBound(0)];

      for (intCounter = 0; intCounter <= arrNumberTwo.GetUpperBound(0); intCounter++)
      {
        arrNumberTwo[intCounter] = 2 + 2 * intCounter;
      }
      // intCounter = arrNumberTwo.GetUpperBound(0) + 1

      strOutput += "Index\tArray\tArray1\tArray2\n";

      for (intCounter = 0; intCounter <= arrNumberTwo.GetUpperBound(0); intCounter++)
      {
        strOutput += intCounter + "\t" + arrNumberDefault[intCounter] + "\t" +
          arrNumberOne[intCounter] + "\t" + arrNumberTwo[intCounter] + "\n";
      }
      // intCounter = arrNumber.GetUpperBound(0) + 1

      strOutput += "\nThe array contains " + arrNumberDefault.Length + " elements.";
      MessageBox.Show(strOutput, "Array of Integer Values", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}
    // Main()

  }
  // cpCreateArray

}
// CreateArray