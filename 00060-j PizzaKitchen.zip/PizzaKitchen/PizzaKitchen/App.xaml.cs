﻿//***
// Action
//   - Starting the application
// Created
//   - CopyPaste – 20220819 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220819 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace PizzaKitchen
{

  public partial class App : Application
  {

      //#region "Constructors / Destructors"
      //#endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      //#region "Fields"
      //#endregion

      //#region "Properties"
      //#endregion

      //#region "Methods"

      //#region "Overrides"
      //#endregion

      //#region "Controls"
      //#endregion

      //#region "Functionality"

      //#region "Event"
      //#endregion

      //#region "Sub / Function"
      //#endregion

      //#endregion

      //#endregion

      //#region "Not used"
      //#endregion

  }
  // App

}
// PizzaKitchen

