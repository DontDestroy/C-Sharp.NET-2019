﻿//***
// Action
//   - Implementation of a cpCar
// Created
//   - CopyPaste – 20260128 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260128 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpCar : cpRoadVehicle, cpiCompareVehicle<cpCar>
  {

    #region "Constructors / Destructors"

    public cpCar(): base()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpRoadVehicle()
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpCar()

    public cpCar(string strVehicleIdentificationNumber, uint intWheelCount, uint intMaximumSpeedForward, uint intMaximumSpeedBackward) : base(strVehicleIdentificationNumber, intWheelCount, intMaximumSpeedForward, intMaximumSpeedBackward)
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpRoadVehicle(string, uint, uint, uint)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpCar(string, uint, uint, uint)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public bool VehicleIdentificationNumberCheck(cpCar theVehicle)
    //***
    // Action
    //   - Check the Vehicle Identification Numbers of two vehicles
    //   - If equal
    //     - Return true
    //   - If not
    //     - Return false 
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - string VehicleIdentificationNumber (Get)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return VehicleIdentificationNumber.Equals(theVehicle.VehicleIdentificationNumber);
    }
    // VehicleIdentificationNumberCheck(cpCar)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCar

}
// CopyPaste.Learning