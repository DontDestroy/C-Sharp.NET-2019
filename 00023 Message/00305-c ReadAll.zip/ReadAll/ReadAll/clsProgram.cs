//***
// Action
//   - Try to read a file
// Created
//   - CopyPaste � 20230809 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230809 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Try to read a file
      //   - If there was an error
      //     - Show error
      //     - 'blnFileError' becomes true
      //   - If there is no error
      //     - Try to read the file till end
      //   - If there was an error
      //     - Show error
      //   - If not
      //     - Show content of file in console
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnFileError = false;
      StreamReader strReader = null;

      try
      {
        strReader = new StreamReader("C:\\BookInfo.txt");
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error opening the file C:\\BookInfo.txt");
        Console.WriteLine("Error: {0}", theException.Message);
        blnFileError = true;
      }
      finally
      {
      }

      if (blnFileError)
      {
      }
      else
        // Not blnFileError
      {
        string strContent;

        try
        {
          strContent = strReader.ReadToEnd();
          Console.WriteLine(strContent);
        }
        catch (Exception theException)
        {
          Console.WriteLine("Error reading file");
          Console.WriteLine("Error: {0}", theException.Message);
        }
        finally
        {
          strReader.Close();
        }

      }
      // blnFileError

      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning