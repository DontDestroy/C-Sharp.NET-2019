//***
// Action
//   - Retrieve data using DataReader object, fully unbound
// Created
//   - CopyPaste � 20251205 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251205 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDataReaderTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdLoadList;
    internal System.Windows.Forms.TextBox txtCustomerLimit;
    internal System.Windows.Forms.Label lblCustomer;
    internal System.Windows.Forms.ListBox lstCustomer;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDataReaderTryout));
      this.cmdLoadList = new System.Windows.Forms.Button();
      this.txtCustomerLimit = new System.Windows.Forms.TextBox();
      this.lblCustomer = new System.Windows.Forms.Label();
      this.lstCustomer = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // cmdLoadList
      // 
      this.cmdLoadList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdLoadList.Location = new System.Drawing.Point(288, 8);
      this.cmdLoadList.Name = "cmdLoadList";
      this.cmdLoadList.Size = new System.Drawing.Size(88, 24);
      this.cmdLoadList.TabIndex = 6;
      this.cmdLoadList.Text = "Load List";
      this.cmdLoadList.Click += new System.EventHandler(this.cmdLoadList_Click);
      // 
      // txtCustomerLimit
      // 
      this.txtCustomerLimit.Location = new System.Drawing.Point(72, 8);
      this.txtCustomerLimit.Name = "txtCustomerLimit";
      this.txtCustomerLimit.Size = new System.Drawing.Size(200, 20);
      this.txtCustomerLimit.TabIndex = 5;
      this.txtCustomerLimit.Text = "A";
      // 
      // lblCustomer
      // 
      this.lblCustomer.Location = new System.Drawing.Point(8, 8);
      this.lblCustomer.Name = "lblCustomer";
      this.lblCustomer.Size = new System.Drawing.Size(56, 16);
      this.lblCustomer.TabIndex = 4;
      this.lblCustomer.Text = "Customer";
      // 
      // lstCustomer
      // 
      this.lstCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.lstCustomer.Location = new System.Drawing.Point(0, 40);
      this.lstCustomer.Name = "lstCustomer";
      this.lstCustomer.Size = new System.Drawing.Size(384, 225);
      this.lstCustomer.TabIndex = 7;
      // 
      // frmDataReaderTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(384, 273);
      this.Controls.Add(this.cmdLoadList);
      this.Controls.Add(this.txtCustomerLimit);
      this.Controls.Add(this.lblCustomer);
      this.Controls.Add(this.lstCustomer);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataReaderTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Retrieve data using DataReader object Tryout";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDataReaderTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDataReaderTryout()
      //***
      // Action
      //   - Create instance of 'frmDataReaderTryout'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDataReaderTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdLoadList_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - We define a command (an SQL statement)
      //   - We filter with a starting text (look at the % wildcard in the SQL statement)
      //   - Try to
      //     - Create a new connection using a hardcode connectionstring
      //     - The command uses that connection
      //     - Open the connection
      //     - Set the SQL statement to the command
      //     - Execute the command and put the result is a data reader
      //     - Clear all items from the list
      //     - Start updating the list
      //     - Loop thru all records of the data reader
      //       - Add the found companyname as text to the list
      //     - End updating the list
      //   - On an exception (error)
      //     - Show the corresponding error message
      //   - Close the connection
      //   - Clean the connection from memory
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpConnectionString()
      //   - cpConnectionString.BuildConnectionString()
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataReaderTryout

}
// CopyPaste.Learning