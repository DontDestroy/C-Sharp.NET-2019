﻿//***
// Action
//   - Implementation of a Carpenter
// Created
//   - CopyPaste – 20251104 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251104 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpThreadCarpenter : cpCopyPasteRobot
	{

    #region "Constructors / Destructors"

    public cpThreadCarpenter(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpThreadCarpenter starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpThreadCarpenter(int, int, Directions.Direction, int)
    //   - cpThreadContractor.CarpenterTask()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpThreadCarpenter(int, int, Directions.Direction, int, Color) 

    public cpThreadCarpenter(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpThreadCarpenter starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpThreadCarpenter(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpThreadCarpenter(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void BuildDoor()
    //***
    // Action
    //   - Face to the North
    //   - Repeat 2 times
    //     - Put beeper
    //     - Move one forward
    //   - Face to the East
    //   - Repeat 2 times
    //     - Put beeper
    //     - Move one forward
    //   - Face to the South
    //   - Repeat 2 times
    //     - Put beeper
    //     - Move one forward
    // Called by
    //   - cpThreadContractor.CarpenterTask()
    // Calls
    //   - cpCopyPasteRobot.FaceEast()
    //   - cpCopyPasteRobot.FaceNorth()
    //   - cpCopyPasteRobot.FaceSouth()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FaceNorth();

      for (int counter = 0; counter < 2; counter++)
      {
        putBeeper();
        move();
      }
      // counter = 2

      FaceEast();

      for (int counter = 0; counter < 2; counter++)
      {
        putBeeper();
        move();
      }
      // counter = 2

      FaceSouth();

      for (int counter = 0; counter < 2; counter++)
      {
        putBeeper();
        move();
      }
      // counter = 2

      putBeeper();
    }
    // BuildDoor()

    public void BuildWindow()
    //***
    // Action
    //   - Face to the North
    //   - Repeat 4 times
    //     - Put beeper
    //     - Turn left
    //     - Move one forward
    // Called by
    //   - cpThreadContractor.CarpenterTask()
    // Calls
    //   - cpCopyPasteRobot.FaceNorth()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FaceNorth();

      for (int counter = 0; counter < 4; counter++)
      {
        putBeeper();
        turnLeft();
        move();
      }
      // counter = 4

    }
    // BuildWindow()

    public void GoToStartDoor()
    //***
    // Action
    //   - Move four forward
    // Called by
    //   - cpThreadContractor.CarpenterTask()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      for (int counter = 0; counter < 4; counter++)
      {
        move();
      }
      // counter = 4

    }
    // GoToStartDoor()

    public void GoToStartFirstWindow()
    //***
    // Action
    //   - Move four forward
    //   - Face to the North
    //   - Move five forward
    // Called by
    //   - cpThreadContractor.CarpenterTask()
    // Calls
    //   - cpCopyPasteRobot.FaceNorth()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      for (int counter = 0; counter < 4; counter++)
      {
        move();
      }
      // counter = 4

      FaceNorth();

      for (int counter = 0; counter < 5; counter++)
      {
        move();
      }
      // counter = 5

    }
    // GoToStartFirstWindow()

    public void GoToStartSecondWindow()
    //***
    // Action
    //   - Move seven forward
    //   - Face to the North
    //   - Move five forward
    // Called by
    //   - cpThreadContractor.CarpenterTask()
    // Calls
    //   - cpCopyPasteRobot.FaceNorth()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      for (int counter = 0; counter < 7; counter++)
      {
        move();
      }
      // counter = 7

      FaceNorth();

      for (int counter = 0; counter < 5; counter++)
      {
        move();
      }
      // counter = 5

    }
    // GoToStartSecondWindow()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpThreadCarpenter

}
// cpKarelTheRobot