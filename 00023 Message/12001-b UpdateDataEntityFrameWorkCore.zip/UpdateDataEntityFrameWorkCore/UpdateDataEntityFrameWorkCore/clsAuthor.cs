﻿//***
// Action
//   - The class cpAuthor
//   - Will be used to read data from a table in a SQL Server database
//   - The primary key is by default setting in Entity FrameWork Core the <classname>Id notification --> cpAuthorId
//     - This is not according to Copy Paste naming conventions (it should be intIdAuthor)
// Created
//   - CopyPaste – 20230401 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230401 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace UpdateDataEntityFrameWorkCore
{

  public class cpAuthor
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"
    
    public int cpAuthorId { get; set; }
    public string strName { get; set; }
    public string strWebUrl { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpAuthor

}
// UpdateDataEntityFrameWorkCore