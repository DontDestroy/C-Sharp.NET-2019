﻿//***
// Action
//   - Having transactions in database actions
// Created
//   - CopyPaste – 20210707 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210707 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TransactionsWizard
{
  public partial class frmTransactionsWizard : Form
  {

    #region "Constructors / Destructors"

    public frmTransactionsWizard()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Define the connection
    //   - Make both TableAdapters the same connection
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210707 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
      mcnncpNorthwindScript = tbaCustomer.Connection;
      tbaOrder.Connection = mcnncpNorthwindScript;
    }
    // frmTransactionsWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    internal System.Data.SqlClient.SqlConnection mcnncpNorthwindScript;
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCommit_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Open connection
    //   - Begin transaction
    //   - Try
    //     - Assign transaction to TableAdapter Customer
    //     - Assign transaction to TableAdapter Order
    //     - Add a row with key "AAAA1"
    //     - Update DataAdapter Customer
    //     - Update DataAdapter Order
    //     - Commit transaction
    //     - Show message that transactions was committed
    //   - Catch OleDbException
    //     - Do rollback
    //     - Show message of exception
    //   - Catch Exception
    //     - Do rollback
    //     - Show message of exception
    //   - Finally
    //     - Close connection
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - AddRows(String)
    // Created
    //   - CopyPaste – 20210707 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      System.Data.SqlClient.SqlTransaction trnNew;

      mcnncpNorthwindScript.Open();
      trnNew = mcnncpNorthwindScript.BeginTransaction();

      try
      {
        this.tbaCustomer.Adapter.InsertCommand.Transaction = trnNew;
        this.tbaOrder.Adapter.InsertCommand.Transaction = trnNew;

        AddRows("AAAA1");

        this.tbaCustomer.Update(this.dsData.tblCPCustomer);
        this.tbaOrder.Update(this.dsData.tblCPOrder);
        trnNew.Commit();
        MessageBox.Show("Transaction Committed");
      }
      catch (System.Data.SqlClient.SqlException theSQLException)
      {
        trnNew.Rollback();
        MessageBox.Show(theSQLException.Message.ToString());
      }
      catch (System.Exception theException)
      {
        trnNew.Rollback();
        MessageBox.Show(theException.Message.ToString());
      }
      finally
      {
        mcnncpNorthwindScript.Close();
      }

    }
    // cmdCommit_Click(System.Object, System.EventArgs)

    private void cmdCreate_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Open connection
    //   - Begin transaction
    //   - Show IsolationLevel of the connection
    //   - Close connection
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210707 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      string strMessage;
      System.Data.SqlClient.SqlTransaction trnNew;

      mcnncpNorthwindScript.Open();
      trnNew = mcnncpNorthwindScript.BeginTransaction();
      strMessage = "Isolation Level: ";
      strMessage += trnNew.IsolationLevel.ToString();
      MessageBox.Show(strMessage);
      mcnncpNorthwindScript.Close();
    }
    // cmdCreate_Click(System.Object, System.EventArgs)

    private void cmdLoad_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Clear DataSet
    //   - Fill TableAdapter Customer
    //   - Fill TableAdapter Order
    //   - Select first item in lstCustomer
    //   - Execute some actions after selecting first
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20210707 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.dsData.Clear();
      this.tbaCustomer.Fill(this.dsData.tblCPCustomer);
      this.tbaOrder.Fill(this.dsData.tblCPOrder);
      this.lstCustomer.SelectedIndex = 0;
    }
    // cmdLoad_Click(System.Object, System.EventArgs)

    private void cmdNested_Click(System.Object theSender, System.EventArgs theEventArguments)
    //  '***
    //' Action
    //'   - Open connection
    //'   - Begin transaction
    //'   - Create a child transaction
    //'   - Show IsolationLevel of the child (does not exist in SQL Server, but in OleDB it exists)
    //'   - Close connection
    //' Called by
    //'   - User action (Clicking a button) 
    //' Calls
    //'   - 
    //' Created
    //'   - CopyPaste – 20210707 – VVDW
    //' Changed
    //'   - Organisation – yyyymmdd – Initials of programmer – What changed
    //' Tested
    //'   - CopyPaste – 20210707 – VVDW
    //' Keyboard key
    //'   - 
    //' Proposal (To Do)
    //'   - List of actions that can be added to the functionality
    //'***
    {
      string strMessage;
      System.Data.SqlClient.SqlTransaction trnMaster;
      // System.Data.SqlClient.SqlTransaction trnChild;

      mcnncpNorthwindScript.Open();
      trnMaster = mcnncpNorthwindScript.BeginTransaction();
      // trnChild = trnMaster.Begin
      // Does not exist in SQL Server
      strMessage = "Child Isolation Level: ";
      strMessage += trnMaster.IsolationLevel.ToString();
      // strMessage += trnChild.IsolationLevel.ToString
      MessageBox.Show(strMessage);
      mcnncpNorthwindScript.Close();
    }
    // cmdNested_Click(System.Object, System.EventArgs)

    private void cmdRollback_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Open connection
    //   - Begin transaction
    //   - Try
    //     - Add a row with key "AAAA2"
    //     - Assign transaction to TableAdapter Customer
    //     - Assign transaction to TableAdapter Order
    //     - Update TableAdapter Order
    //     - Update TableAdapter Customer (in the wrong order)
    //     - Commit transaction
    //     - Show message that transactions was committed
    //   - Catch OleDbException
    //     - Do rollback
    //     - Show message of exception
    //   - Catch Exception
    //     - Do rollback
    //     - Show message of exception
    //   - Finally
    //     - Close connection
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - AddRows(String)
    // Created
    //   - CopyPaste – 20210707 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      System.Data.SqlClient.SqlTransaction trnNew;

      mcnncpNorthwindScript.Open();
      trnNew = mcnncpNorthwindScript.BeginTransaction();

      try
      {
        this.tbaCustomer.Adapter.InsertCommand.Transaction = trnNew;
        this.tbaOrder.Adapter.InsertCommand.Transaction = trnNew;

        AddRows("AAAA2");

        this.tbaOrder.Update(this.dsData.tblCPOrder);
        this.tbaCustomer.Update(this.dsData.tblCPCustomer);
        // Switch the update command to be correct
        trnNew.Commit();
        MessageBox.Show("Transaction Committed");
      }
      catch (System.Data.SqlClient.SqlException theSQLException)
      {
        trnNew.Rollback();
        MessageBox.Show(theSQLException.Message.ToString());
      }
      catch (System.Exception theException)
      {
        trnNew.Rollback();
        MessageBox.Show(theException.Message.ToString());
      }
      finally
      {
        mcnncpNorthwindScript.Close();
      }

    }
    // cmdRollback_Click(System.Object, System.EventArgs)

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    private void AddRows(string strNewCustomer)
    //***
    // Action
    //   - Try
    //     - Define a row
    //     - Fill in 2 fields (strCompanyName and strIdCustomer)
    //     - Add the row to Customer Table in DataSet
    //     - Fill in 2 fields (strCustomerId and dtmOrderDate)
    //     - Add the row to Order Table in DataSet
    //   - Catch Exception
    //     - Throw that record already exist
    // Called by
    //   - cmdCommit_Click(System.Object, System.EventArgs) Handles cmdCommit.Click
    //   - cmdRollback_Click(System.Object, System.EventArgs) Handles cmdRollback.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210707 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      try
      {
        System.Data.DataRow drwRow;

        drwRow = this.dsData.tblCPCustomer.NewRow();
        drwRow["strCompanyName"] = "A New Customer Record";
        drwRow["strIdCustomer"] = strNewCustomer;
        this.dsData.tblCPCustomer.Rows.Add(drwRow);

        drwRow = this.dsData.tblCPOrder.NewRow();
        drwRow["strCustomerId"] = strNewCustomer;
        drwRow["dtmOrderDate"] = System.DateTime.Today;
        this.dsData.tblCPOrder.Rows.Add(drwRow);
      }
      catch (Exception theException)
      {
        throw new System.Exception("This record already exists in the table 'tblCPCustomer', within the dataset");
      }

    }
    // AddRows(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTransactionsWizard
}
// TransactionsWizard

