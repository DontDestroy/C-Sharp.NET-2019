//***
// Action
//   - Start an application that can start itself
// Created
//   - CopyPaste � 20250630 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250630 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSpawn: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdKill;
    internal System.Windows.Forms.Button cmdSpawn;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSpawn));
      this.cmdKill = new System.Windows.Forms.Button();
      this.cmdSpawn = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdKill
      // 
      this.cmdKill.Location = new System.Drawing.Point(109, 152);
      this.cmdKill.Name = "cmdKill";
      this.cmdKill.Size = new System.Drawing.Size(75, 32);
      this.cmdKill.TabIndex = 3;
      this.cmdKill.Text = "Kill";
      this.cmdKill.Click += new System.EventHandler(this.cmdKill_Click);
      // 
      // cmdSpawn
      // 
      this.cmdSpawn.Location = new System.Drawing.Point(109, 64);
      this.cmdSpawn.Name = "cmdSpawn";
      this.cmdSpawn.Size = new System.Drawing.Size(75, 32);
      this.cmdSpawn.TabIndex = 2;
      this.cmdSpawn.Text = "Spawn";
      this.cmdSpawn.Click += new System.EventHandler(this.cmdSpawn_Click);
      // 
      // frmSpawn
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdKill);
      this.Controls.Add(this.cmdSpawn);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSpawn";
      this.Text = "Spawn Kill";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSpawn'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250630 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250630 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSpawn()
      //***
      // Action
      //   - Create instance of 'frmSpawn'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250630 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250630 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSpawn()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdKill_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Kill the current process, so the current application will be stopped
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250630 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250630 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Process.GetCurrentProcess().Kill();
    }
    // cmdKill_Click(System.Object, System.EventArgs) Handles cmdKill.Click

    private void cmdSpawn_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Start the same process as the current process
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250630 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250630 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Process.Start(Process.GetCurrentProcess().MainModule.FileName);
    }
    // cmdSpawn_Click(System.Object, System.EventArgs) Handles cmdSpawn.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSpawn
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSpawn()
      // Created
      //   - CopyPaste � 20250630 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250630 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSpawn());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSpawn

}
// CopyPaste.Learning