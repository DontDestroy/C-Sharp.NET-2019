﻿//***
// Action
//   - A definition of a FindBeeperNextToWallInARoomError
// Created
//   - CopyPaste – 20251025 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251025 – VVDW
// Proposal (To Do)
//   - There is an error in this routine
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpFindBeeperNextToWallInARoomError : cpCopyPasteRobot
	{

    #region "Constructors / Destructors"

    public cpFindBeeperNextToWallInARoomError(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpFindBeeperNextToWallInARoomError starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpFindBeeperNextToWallInARoomError(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpFindBeeperNextToWallInARoomError(int, int, Directions.Direction, int) 

    public cpFindBeeperNextToWallInARoomError(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpFindBeeperNextToWallInARoom starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpFindBeeperNextToWallInARoomError(int, int, Directions.Direction, int)
    //   - cpProgram.FindBeeperNextToWallInARoomError()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpFindBeeperNextToWallInARoomError(int, int, Directions.Direction, int, Color) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void FindBeeperNextToWall()
    //***
    // Action
    //   - As long robot is not finding a beeper
    //     - While robot is not blocked
    //       - Move forward
    //     - Turn left
    //   - Pick beeper
    // Called by
    //   - cpProgram.FindBeeperNextToWallInARoomError()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - There is an error in this routine
    //***
    {

      while (!nextToABeeper())
      {

        while (frontIsClear())
        {
          move();
        }
        // frontIsClear()

        turnLeft();
      }
      // Not nextToABeeper()

      pickBeeper();
    }
    // FindBeeperNextToWall()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpFindBeeperNextToWallInARoomError

}
// cpKarelTheRobot