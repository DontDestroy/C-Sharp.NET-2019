//***
// Action
//   - Locate records with the DataTable object
// Created
//   - CopyPaste � 20251205 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251205 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmLocateRecordTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.ComboBox cmbCustomer;
    internal System.Windows.Forms.Label lblCity;
    internal System.Windows.Forms.TextBox txtCity;
    internal System.Windows.Forms.TextBox txtAddress;
    internal System.Windows.Forms.TextBox txtCompanyName;
    internal System.Windows.Forms.TextBox txtIdCustomer;
    internal System.Windows.Forms.Label lblAddress;
    internal System.Windows.Forms.Label lblCompanyName;
    internal System.Windows.Forms.Label lblIdCustomer;
    internal System.Windows.Forms.Label lblCustomer;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmLocateRecordTryout));
      this.cmbCustomer = new System.Windows.Forms.ComboBox();
      this.lblCity = new System.Windows.Forms.Label();
      this.txtCity = new System.Windows.Forms.TextBox();
      this.txtAddress = new System.Windows.Forms.TextBox();
      this.txtCompanyName = new System.Windows.Forms.TextBox();
      this.txtIdCustomer = new System.Windows.Forms.TextBox();
      this.lblAddress = new System.Windows.Forms.Label();
      this.lblCompanyName = new System.Windows.Forms.Label();
      this.lblIdCustomer = new System.Windows.Forms.Label();
      this.lblCustomer = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmbCustomer
      // 
      this.cmbCustomer.Location = new System.Drawing.Point(116, 16);
      this.cmbCustomer.Name = "cmbCustomer";
      this.cmbCustomer.Size = new System.Drawing.Size(264, 21);
      this.cmbCustomer.TabIndex = 11;
      this.cmbCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbCustomer_SelectedIndexChanged);
      // 
      // lblCity
      // 
      this.lblCity.Location = new System.Drawing.Point(12, 128);
      this.lblCity.Name = "lblCity";
      this.lblCity.Size = new System.Drawing.Size(96, 16);
      this.lblCity.TabIndex = 18;
      this.lblCity.Text = "City";
      // 
      // txtCity
      // 
      this.txtCity.BackColor = System.Drawing.SystemColors.Control;
      this.txtCity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCity.Location = new System.Drawing.Point(116, 128);
      this.txtCity.Name = "txtCity";
      this.txtCity.Size = new System.Drawing.Size(264, 20);
      this.txtCity.TabIndex = 19;
      this.txtCity.Text = "";
      // 
      // txtAddress
      // 
      this.txtAddress.BackColor = System.Drawing.SystemColors.Control;
      this.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtAddress.Location = new System.Drawing.Point(116, 104);
      this.txtAddress.Name = "txtAddress";
      this.txtAddress.Size = new System.Drawing.Size(264, 20);
      this.txtAddress.TabIndex = 17;
      this.txtAddress.Text = "";
      // 
      // txtCompanyName
      // 
      this.txtCompanyName.BackColor = System.Drawing.SystemColors.Control;
      this.txtCompanyName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCompanyName.Location = new System.Drawing.Point(116, 80);
      this.txtCompanyName.Name = "txtCompanyName";
      this.txtCompanyName.Size = new System.Drawing.Size(264, 20);
      this.txtCompanyName.TabIndex = 15;
      this.txtCompanyName.Text = "";
      // 
      // txtIdCustomer
      // 
      this.txtIdCustomer.BackColor = System.Drawing.SystemColors.Control;
      this.txtIdCustomer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtIdCustomer.Location = new System.Drawing.Point(116, 56);
      this.txtIdCustomer.Name = "txtIdCustomer";
      this.txtIdCustomer.Size = new System.Drawing.Size(264, 20);
      this.txtIdCustomer.TabIndex = 13;
      this.txtIdCustomer.Text = "";
      // 
      // lblAddress
      // 
      this.lblAddress.Location = new System.Drawing.Point(12, 104);
      this.lblAddress.Name = "lblAddress";
      this.lblAddress.Size = new System.Drawing.Size(96, 16);
      this.lblAddress.TabIndex = 16;
      this.lblAddress.Text = "Address";
      // 
      // lblCompanyName
      // 
      this.lblCompanyName.Location = new System.Drawing.Point(12, 80);
      this.lblCompanyName.Name = "lblCompanyName";
      this.lblCompanyName.Size = new System.Drawing.Size(96, 16);
      this.lblCompanyName.TabIndex = 14;
      this.lblCompanyName.Text = "Company Name";
      // 
      // lblIdCustomer
      // 
      this.lblIdCustomer.Location = new System.Drawing.Point(12, 56);
      this.lblIdCustomer.Name = "lblIdCustomer";
      this.lblIdCustomer.Size = new System.Drawing.Size(96, 16);
      this.lblIdCustomer.TabIndex = 12;
      this.lblIdCustomer.Text = "Customer number";
      // 
      // lblCustomer
      // 
      this.lblCustomer.Location = new System.Drawing.Point(12, 16);
      this.lblCustomer.Name = "lblCustomer";
      this.lblCustomer.Size = new System.Drawing.Size(96, 16);
      this.lblCustomer.TabIndex = 10;
      this.lblCustomer.Text = "Choose Customer";
      // 
      // frmLocateRecordTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(392, 173);
      this.Controls.Add(this.cmbCustomer);
      this.Controls.Add(this.lblCity);
      this.Controls.Add(this.txtCity);
      this.Controls.Add(this.txtAddress);
      this.Controls.Add(this.txtCompanyName);
      this.Controls.Add(this.txtIdCustomer);
      this.Controls.Add(this.lblAddress);
      this.Controls.Add(this.lblCompanyName);
      this.Controls.Add(this.lblIdCustomer);
      this.Controls.Add(this.lblCustomer);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmLocateRecordTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Locate records with the DataTable object Tryout";
      this.Load += new System.EventHandler(this.frmLocateRecord_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmLocateRecordTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmLocateRecordTryout()
      //***
      // Action
      //   - Create instance of 'frmLocateRecordTryout'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmLocateRecordTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmbCustomer_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a data row view
      //   - Cast the selected item of the combobox into a data row view
      //     - Put the cast into the data row view (you have a selected record)
      //   - Show the field "strAddress"
      //   - Show the field "strCompanyName"
      //   - Show the field "strCity"
      //   - Show the field "strIdCustomer"
      // Called by
      //   - User action (Selecting an item in a combobox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmbCustomers_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbCustomer.SelectedIndexChanged

    private void frmLocateRecord_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a SQL statement
      //     - We select all information
      //   - Try to
      //     - Create a data adapter using the connection string and the SQL statement
      //     - Fill the data table with the data adapter result
      //     - Bind the combobox with the data table information
      //       - Data source is the data table
      //       - Key (value member) is the field "strIdCustomer"
      //       - Value (display member) shown is the field "strCustomerName"
      //   - On an exception (error)
      //     - Show the corresponding error message
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - cpConnectionString()
      //   - cpConnectionString.BuildConnectionString()
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmLocateRecord_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmLocateRecordTryout

}
// CopyPaste.Learning