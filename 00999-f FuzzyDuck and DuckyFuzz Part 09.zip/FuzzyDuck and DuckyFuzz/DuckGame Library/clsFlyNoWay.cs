﻿//***
// Action
//   - Implementation of a cpFlyNoWay
//		 - The way a thing can't fly in the air
// Created
//   - CopyPaste – 20240727 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240727 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Animal.Library
{

	public class cpFlyNoWay : cpiFly
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpFlyNoWay
		/// </summary>
		public cpFlyNoWay() 
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - cpDecoyDuck()
		//   - cpPlasticRubberDuck()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpFlyNoWay()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing does not move in the air
		/// </summary>
		public void Fly()
		//***
		// Action
		//   - Define how something is not able to fly
		// Called by
		//   - cpDecoyDuck() (indirectly, thru delegate)
		//   - cpPlasticRubberDuck() (indirectly, thru delegate)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Something can't move around in the air");
		}
		// Fly()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpFlyNoWay

}
// CopyPaste.Game.Animal.Library