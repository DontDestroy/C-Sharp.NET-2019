﻿//***
// Action
//   - Implementation of a cpSignalItem
//		 - Something is on for a period of time
//     - Something is off for a period of time
// Created
//   - CopyPaste – 20241227 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20241227 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.MorseCode.Library
{

	public class cpSignalItem
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Basic constructor that accepts a signal in milliseconds
		/// </summary>
		/// <param name="blnSignal"></param>
		/// <param name="intLength"></param>
		public cpSignalItem(bool blnSignal, int intLength)
		//***
		// Action
		//   - Set the signal on or off for a specific length
		// Called by
		//   - CopyPaste.MorseCode.Test.cpProgram()
		//   - GenerateSignal()
		// Calls
		//   - Length(int) (Set)
		//   - Signal(bool) (Set)
		// Created
		//   - CopyPaste – 20241227 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20241227 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Length = intLength;
			Signal = blnSignal;
		}
		// cpSignalItem(bool, int)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private bool _blnThereIsSignal;
		private int _intMilliseconds;

		#endregion

		#region "Properties"

		public int Length
		{

			get
			//***
			// Action Get
			//   - Return _intMilliseconds
			// Called by
			//   - CopyPaste.MorseCode.Test.cpProgram()
			//   - cpMorseByOutputWindow.SendMessage(List<cpSignalItem>)
			//   - cpMorseByLight.SendMessage(List<cpSignalItem>)
			//   - cpMorseBySound.SendMessage(List<cpSignalItem>)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20241227 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20241227 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return _intMilliseconds;
			}
			// int Length (Get)

			set
			//***
			// Action Set
			//   - _intMilliseconds becomes value
			// Called by
			//   - CopyPaste.MorseCode.Test.cpProgram()
			//   - cpSignalItem(bool, int)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20241227 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20241227 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				_intMilliseconds = value;
			}
			// Length(int) (Set)

		}
		// int Length

		public bool Signal
		{

			get
			//***
			// Action Get
			//   - Return _blnThereIsSignal
			// Called by
			//   - CopyPaste.MorseCode.Test.cpProgram()
			//   - cpMorseByOutputWindow.SendMessage(List<cpSignalItem>)
			//   - cpMorseByLight.SendMessage(List<cpSignalItem>)
			//   - cpMorseBySound.SendMessage(List<cpSignalItem>)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20241227 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20241227 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return _blnThereIsSignal;
			}
			// bool Signal (Get)

			set
			//***
			// Action Set
			//   - _blnThereIsSignal becomes value
			// Called by
			//   - CopyPaste.MorseCode.Test.cpProgram()
			//   - cpSignalItem(bool, int)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20241227 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20241227 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				_blnThereIsSignal = value;
			}
			// Signal(bool) (Set)

		}
		// Signal

		#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// cpSignalItem

}
// CopyPaste.MorseCode.Library