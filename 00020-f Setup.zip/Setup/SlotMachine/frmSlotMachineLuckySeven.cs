//***
// Action
//   - A simulation of a slotmachine
//   - When there is a seven you win
//   - The number of times you win and the number of attempts are shown
//   - The percentage of wins is also shown
// Created
//   - CopyPaste � 20240411 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240411 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSlotMachineLuckySeven: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.PictureBox picWon;
    internal System.Windows.Forms.Label lblTitle;
    internal System.Windows.Forms.Label lblNumber3;
    internal System.Windows.Forms.Label lblNumber2;
    internal System.Windows.Forms.Label lblNumber1;
    internal System.Windows.Forms.Label lblTotalWins;
    internal System.Windows.Forms.Button cmdHelp;
    internal System.Windows.Forms.Label lblPercent;
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.Button cmdNewAttempt;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSlotMachineLuckySeven));
      this.picWon = new System.Windows.Forms.PictureBox();
      this.lblTitle = new System.Windows.Forms.Label();
      this.lblNumber3 = new System.Windows.Forms.Label();
      this.lblNumber2 = new System.Windows.Forms.Label();
      this.lblNumber1 = new System.Windows.Forms.Label();
      this.cmdNewAttempt = new System.Windows.Forms.Button();
      this.lblTotalWins = new System.Windows.Forms.Label();
      this.cmdHelp = new System.Windows.Forms.Button();
      this.lblPercent = new System.Windows.Forms.Label();
      this.cmdExit = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // picWon
      // 
      this.picWon.Image = ((System.Drawing.Image)(resources.GetObject("picWon.Image")));
      this.picWon.Location = new System.Drawing.Point(208, 110);
      this.picWon.Name = "picWon";
      this.picWon.Size = new System.Drawing.Size(160, 152);
      this.picWon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picWon.TabIndex = 13;
      this.picWon.TabStop = false;
      this.picWon.Visible = false;
      // 
      // lblTitle
      // 
      this.lblTitle.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblTitle.ForeColor = System.Drawing.Color.Purple;
      this.lblTitle.Location = new System.Drawing.Point(24, 110);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(176, 72);
      this.lblTitle.TabIndex = 11;
      this.lblTitle.Text = "Lucky Seven";
      // 
      // lblNumber3
      // 
      this.lblNumber3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblNumber3.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblNumber3.Location = new System.Drawing.Point(304, 22);
      this.lblNumber3.Name = "lblNumber3";
      this.lblNumber3.Size = new System.Drawing.Size(64, 64);
      this.lblNumber3.TabIndex = 10;
      this.lblNumber3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblNumber2
      // 
      this.lblNumber2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblNumber2.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblNumber2.Location = new System.Drawing.Point(216, 22);
      this.lblNumber2.Name = "lblNumber2";
      this.lblNumber2.Size = new System.Drawing.Size(64, 64);
      this.lblNumber2.TabIndex = 9;
      this.lblNumber2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblNumber1
      // 
      this.lblNumber1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblNumber1.Font = new System.Drawing.Font("Times New Roman", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblNumber1.Location = new System.Drawing.Point(128, 22);
      this.lblNumber1.Name = "lblNumber1";
      this.lblNumber1.Size = new System.Drawing.Size(64, 64);
      this.lblNumber1.TabIndex = 8;
      this.lblNumber1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cmdNewAttempt
      // 
      this.cmdNewAttempt.Location = new System.Drawing.Point(24, 22);
      this.cmdNewAttempt.Name = "cmdNewAttempt";
      this.cmdNewAttempt.Size = new System.Drawing.Size(72, 40);
      this.cmdNewAttempt.TabIndex = 7;
      this.cmdNewAttempt.Text = "&New Attempt";
      this.cmdNewAttempt.Click += new System.EventHandler(this.cmdNewAttempt_Click);
      // 
      // lblTotalWins
      // 
      this.lblTotalWins.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblTotalWins.ForeColor = System.Drawing.SystemColors.HotTrack;
      this.lblTotalWins.Location = new System.Drawing.Point(24, 192);
      this.lblTotalWins.Name = "lblTotalWins";
      this.lblTotalWins.Size = new System.Drawing.Size(176, 23);
      this.lblTotalWins.TabIndex = 14;
      this.lblTotalWins.Text = "Won : 0 of 0";
      this.lblTotalWins.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cmdHelp
      // 
      this.cmdHelp.Location = new System.Drawing.Point(16, 224);
      this.cmdHelp.Name = "cmdHelp";
      this.cmdHelp.Size = new System.Drawing.Size(72, 24);
      this.cmdHelp.TabIndex = 15;
      this.cmdHelp.Text = "&Help";
      this.cmdHelp.Click += new System.EventHandler(this.cmdHelp_Click);
      // 
      // lblPercent
      // 
      this.lblPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblPercent.ForeColor = System.Drawing.SystemColors.HotTrack;
      this.lblPercent.Location = new System.Drawing.Point(96, 224);
      this.lblPercent.Name = "lblPercent";
      this.lblPercent.Size = new System.Drawing.Size(96, 23);
      this.lblPercent.TabIndex = 17;
      this.lblPercent.Text = "0,00%";
      this.lblPercent.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cmdExit
      // 
      this.cmdExit.Location = new System.Drawing.Point(16, 256);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.Size = new System.Drawing.Size(72, 24);
      this.cmdExit.TabIndex = 16;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // frmSlotMachineLuckySeven
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(400, 285);
      this.Controls.Add(this.cmdHelp);
      this.Controls.Add(this.lblPercent);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.lblTotalWins);
      this.Controls.Add(this.picWon);
      this.Controls.Add(this.lblTitle);
      this.Controls.Add(this.lblNumber3);
      this.Controls.Add(this.lblNumber2);
      this.Controls.Add(this.lblNumber1);
      this.Controls.Add(this.cmdNewAttempt);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSlotMachineLuckySeven";
      this.Text = "Lucky Seven Slot Machine";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSlotMachineLuckySeven'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSlotMachineLuckySeven()
      //***
      // Action
      //   - Create instance of 'frmSlotMachineLuckySeven'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSlotMachineLuckySeven()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Application stops
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit.Click
    
    private void cmdHelp_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the help screen
      //   - Wait until the user stops the helpscreen
      //   - Check how the help screen is stopped
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmHelp.New()
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmHelp frmHelpDialog = new frmHelp();

      frmHelpDialog.ShowDialog();

      switch (frmHelpDialog.DialogResult)
      {
        case DialogResult.OK:
          break;
        default:
          MessageBox.Show("Next time, please, click on OK to stop the helpscreen.");
          break;
      }
      // frmHelpDialog.DialogResult
    
    }
    // cmdHelp_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdHelp.Click

    private void cmdNewAttempt_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Generate 3 random numbers
      //   - Increment the counter of attempts
      //   - Visualize them
      //   - If one of them is 7
      //     - You win
      //     - Increment the counter of wins
      //   - If not
      //     - You don't win
      //   - Visualize the number of wins and the number of attempts
      //   - Visualize the percentage of the wins
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - string modGlobal.strProcent(short, int)
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpGlobal.mlngCount += 1;
      picWon.Visible = false;
      lblTitle.Text = "Lucky Seven";

      lblNumber1.Text = cpGlobal.mrndRandom.Next(10).ToString();
      lblNumber2.Text = cpGlobal.mrndRandom.Next(10).ToString();
      lblNumber3.Text = cpGlobal.mrndRandom.Next(10).ToString();

      if ((lblNumber1.Text == "7") || (lblNumber2.Text == "7") || (lblNumber3.Text == "7"))
      {
        picWon.Visible = true;
        lblTitle.Text = "You have won !!!";
        cpGlobal.mshtWins += 1;
      }
      else
        // (lblNumber1.Text <> "7") AndAlso (lblNumber2.Text <> "7") AndAlso (lblNumber3.Text <> "7")
      {
      }
      // (lblNumber1.Text = "7") OrElse (lblNumber2.Text = "7") OrElse (lblNumber3.Text = "7")
    
      lblTotalWins.Text = "Won : " + cpGlobal.mshtWins + " of " + cpGlobal.mlngCount;
      lblPercent.Text = cpGlobal.strProcent(cpGlobal.mshtWins, cpGlobal.mlngCount);
    }
    // cmdNewAttempt_Click(System.Object, System.EventArgs) Handles cmdNewAttempt.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSlotMachineLuckySeven
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSlotMachineLuckySeven()
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSlotMachineLuckySeven());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSlotMachineLuckySeven

}
// CopyPaste.Learning