﻿//***
// Action
//   - Testroutine for cpDecoyDuck, cpDuck, cpiFlyable, cpiQuackable, cpiWalkable, cpPlasticRubberDuck, cpRedHeadDuck and cpWoodDuck
// Created
//   - CopyPaste – 20240718 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240718 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Duck.Library;
using System.Diagnostics;

namespace CopyPaste.Game.Duck.Test
{

	internal static class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		///  The main entry point for the test application
		/// </summary>
		public static void Main()
		//***
		// Action
		//   - Start application
		//   - Create a list of cpDuck
		//   - Add a cpDecoyDuck, cpMallardDuck, cpPlasticRubberDuck, cpRedHeadDuck and a cpWoodDuck to it
		//   - Loop thru all the ducks
		//     - Let the duck Display, Fly, Quack, Swim and Walk (if possible according to the data type)
		//   - Show some information on where to check if it was successful
		//   - Wait for the user to hit the keyboard
		// Called by
		//   - User action (Starting the application)
		// Calls
		//   - CopyPaste.Game.Duck.Library.cpDuck.Display()
		//   - CopyPaste.Game.Duck.Library.cpDuck.Swim()
		//   - CopyPaste.Game.Duck.Library.cpDecoyDuck()
		//   - CopyPaste.Game.Duck.Library.cpDecoyDuck.Display()
		//   - CopyPaste.Game.Duck.Library.cpDecoyDuck.Swim()
		//   - CopyPaste.Game.Duck.Library.cpMallardDuck()
		//   - CopyPaste.Game.Duck.Library.cpMallardDuck.Display()
		//   - CopyPaste.Game.Duck.Library.cpMallardDuck.Fly()
		//   - CopyPaste.Game.Duck.Library.cpMallardDuck.Quack()
		//   - CopyPaste.Game.Duck.Library.cpMallardDuck.Swim()
		//   - CopyPaste.Game.Duck.Library.cpMallardDuck.Walk()
		//   - CopyPaste.Game.Duck.Library.cpPlasticRubberDuck()
		//   - CopyPaste.Game.Duck.Library.cpPlasticRubberDuck.Display()
		//   - CopyPaste.Game.Duck.Library.cpPlasticRubberDuck.Quack()
		//   - CopyPaste.Game.Duck.Library.cpPlasticRubberDuck.Swim()
		//   - CopyPaste.Game.Duck.Library.cpRedHeadDuck()
		//   - CopyPaste.Game.Duck.Library.cpRedHeadDuck.Display()
		//   - CopyPaste.Game.Duck.Library.cpRedHeadDuck.Fly()
		//   - CopyPaste.Game.Duck.Library.cpRedHeadDuck.Quack()
		//   - CopyPaste.Game.Duck.Library.cpRedHeadDuck.Swim()
		//   - CopyPaste.Game.Duck.Library.cpRedHeadDuck.Walk()
		//   - CopyPaste.Game.Duck.Library.cpWoodDuck()
		//   - CopyPaste.Game.Duck.Library.cpWoodDuck.Display()
		//   - CopyPaste.Game.Duck.Library.cpWoodDuck.Fly()
		//   - CopyPaste.Game.Duck.Library.cpWoodDuck.Quack()
		//   - CopyPaste.Game.Duck.Library.cpWoodDuck.Swim()
		//   - CopyPaste.Game.Duck.Library.cpWoodDuck.Walk()
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			List<cpDuck> lstDucks = new List<cpDuck>();

			cpDecoyDuck aDecoyDuck = new cpDecoyDuck();
			cpMallardDuck aMallardDuck = new cpMallardDuck();
			cpPlasticRubberDuck aPlasticRubberDuck = new cpPlasticRubberDuck();
			cpRedHeadDuck aRedHeadDuck = new cpRedHeadDuck();
			cpWoodDuck aWoodDuck = new cpWoodDuck();

			lstDucks.Add(aDecoyDuck);
			lstDucks.Add(aMallardDuck);
			lstDucks.Add(aPlasticRubberDuck);
			lstDucks.Add(aRedHeadDuck);
			lstDucks.Add(aWoodDuck);

			foreach (cpDuck theDuck in lstDucks)
			{
				theDuck.Display();
				theDuck.Swim();

				if (theDuck is cpMallardDuck)
				{
					cpMallardDuck theMallardDuck = theDuck as cpMallardDuck;

					theMallardDuck.Fly();
					theMallardDuck.Quack();
					theMallardDuck.Walk();
				}
				else if (theDuck is cpPlasticRubberDuck)
				// Not (theDuck is cpMallardDuck)
				{
					cpPlasticRubberDuck thePlasticRubberDuck = theDuck as cpPlasticRubberDuck;

					thePlasticRubberDuck.Quack();
				}
				else if (theDuck is cpRedHeadDuck)
				// Not (theDuck is cpPlasticRubberDuck)
				{
					cpRedHeadDuck theRedHeadDuck = theDuck as cpRedHeadDuck;

					theRedHeadDuck.Fly();
					theRedHeadDuck.Quack();
					theRedHeadDuck.Walk();
				}
				else if (theDuck is cpWoodDuck)
				// Not (theDuck is cpRedHeadDuck)
				{
					cpWoodDuck theWoodDuck = theDuck as cpWoodDuck;

					theWoodDuck.Fly();
					theWoodDuck.Quack();
					theWoodDuck.Walk();
				}
				else
				// Not (theDuck is cpWood)
				{
				}
				// theDuck is cpMallardDuck
				// theDuck is cpPlasticRubberDuck
				// theDuck is cpRedHeadDuck
				// theDuck is cpWoodDuck

				Debug.Print("");
			}
			// in lstDucks

			Console.WriteLine("Information about the execution of methods can be found in the output window");
			Console.WriteLine();
			Console.WriteLine("Hit any key to exit the program ...");
			Console.ReadLine();
		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#Region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.Game.Duck.Test