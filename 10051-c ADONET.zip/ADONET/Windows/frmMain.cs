//***
// Action
//   - Start screen of the application
//   - A bunch of buttons to start some code
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMain: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdBeerAndBrewerFilteredDatagrid;
    internal System.Windows.Forms.Button cmdBeerAndBrewerTypedDatagrid;
    internal System.Windows.Forms.Button cmdBeerAndBrewerDatagrid;
    internal System.Windows.Forms.Button cmdBeerAndBrewer;
    internal System.Windows.Forms.Button cmdBrewerDatagridMultiuser;
    internal System.Windows.Forms.Button cmdBrewerDatagrid;
    internal System.Windows.Forms.Button cmdContinentCountry;
    internal System.Windows.Forms.Button cmdBrewer;
    internal System.Windows.Forms.Button cmdFindAmountAccount;
    internal System.Windows.Forms.Button cmdBeerAndAccount;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMain));
      this.cmdBeerAndBrewerFilteredDatagrid = new System.Windows.Forms.Button();
      this.cmdBeerAndBrewerTypedDatagrid = new System.Windows.Forms.Button();
      this.cmdBeerAndBrewerDatagrid = new System.Windows.Forms.Button();
      this.cmdBeerAndBrewer = new System.Windows.Forms.Button();
      this.cmdBrewerDatagridMultiuser = new System.Windows.Forms.Button();
      this.cmdBrewerDatagrid = new System.Windows.Forms.Button();
      this.cmdContinentCountry = new System.Windows.Forms.Button();
      this.cmdBrewer = new System.Windows.Forms.Button();
      this.cmdFindAmountAccount = new System.Windows.Forms.Button();
      this.cmdBeerAndAccount = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdBeerAndBrewerFilteredDatagrid
      // 
      this.cmdBeerAndBrewerFilteredDatagrid.Location = new System.Drawing.Point(184, 306);
      this.cmdBeerAndBrewerFilteredDatagrid.Name = "cmdBeerAndBrewerFilteredDatagrid";
      this.cmdBeerAndBrewerFilteredDatagrid.Size = new System.Drawing.Size(192, 32);
      this.cmdBeerAndBrewerFilteredDatagrid.TabIndex = 18;
      this.cmdBeerAndBrewerFilteredDatagrid.Text = "Beer and Brewer &Filtered Datagrid";
      this.cmdBeerAndBrewerFilteredDatagrid.Click += new System.EventHandler(this.cmdBeerAndBrewerFilteredDatagrid_Click);
      // 
      // cmdBeerAndBrewerTypedDatagrid
      // 
      this.cmdBeerAndBrewerTypedDatagrid.Location = new System.Drawing.Point(184, 258);
      this.cmdBeerAndBrewerTypedDatagrid.Name = "cmdBeerAndBrewerTypedDatagrid";
      this.cmdBeerAndBrewerTypedDatagrid.Size = new System.Drawing.Size(192, 32);
      this.cmdBeerAndBrewerTypedDatagrid.TabIndex = 17;
      this.cmdBeerAndBrewerTypedDatagrid.Text = "Beer and Brewer &Typed Datagrid";
      this.cmdBeerAndBrewerTypedDatagrid.Click += new System.EventHandler(this.cmdBeerAndBrewerTypedDatagrid_Click);
      // 
      // cmdBeerAndBrewerDatagrid
      // 
      this.cmdBeerAndBrewerDatagrid.Location = new System.Drawing.Point(184, 210);
      this.cmdBeerAndBrewerDatagrid.Name = "cmdBeerAndBrewerDatagrid";
      this.cmdBeerAndBrewerDatagrid.Size = new System.Drawing.Size(192, 32);
      this.cmdBeerAndBrewerDatagrid.TabIndex = 16;
      this.cmdBeerAndBrewerDatagrid.Text = "Beer and Brewer &Datagrid";
      this.cmdBeerAndBrewerDatagrid.Click += new System.EventHandler(this.cmdBeerAndBrewerDatagrid_Click);
      // 
      // cmdBeerAndBrewer
      // 
      this.cmdBeerAndBrewer.Location = new System.Drawing.Point(16, 210);
      this.cmdBeerAndBrewer.Name = "cmdBeerAndBrewer";
      this.cmdBeerAndBrewer.Size = new System.Drawing.Size(152, 32);
      this.cmdBeerAndBrewer.TabIndex = 15;
      this.cmdBeerAndBrewer.Text = "Beer and B&rewer";
      this.cmdBeerAndBrewer.Click += new System.EventHandler(this.cmdBeerAndBrewer_Click);
      // 
      // cmdBrewerDatagridMultiuser
      // 
      this.cmdBrewerDatagridMultiuser.Location = new System.Drawing.Point(184, 114);
      this.cmdBrewerDatagridMultiuser.Name = "cmdBrewerDatagridMultiuser";
      this.cmdBrewerDatagridMultiuser.Size = new System.Drawing.Size(192, 32);
      this.cmdBrewerDatagridMultiuser.TabIndex = 13;
      this.cmdBrewerDatagridMultiuser.Text = "Brewer Datagrid &MultiUser";
      this.cmdBrewerDatagridMultiuser.Click += new System.EventHandler(this.cmdBrewerDatagridMultiuser_Click);
      // 
      // cmdBrewerDatagrid
      // 
      this.cmdBrewerDatagrid.Location = new System.Drawing.Point(184, 66);
      this.cmdBrewerDatagrid.Name = "cmdBrewerDatagrid";
      this.cmdBrewerDatagrid.Size = new System.Drawing.Size(192, 32);
      this.cmdBrewerDatagrid.TabIndex = 12;
      this.cmdBrewerDatagrid.Text = "Brewer &Datagrid";
      this.cmdBrewerDatagrid.Click += new System.EventHandler(this.cmdBrewerDatagrid_Click);
      // 
      // cmdContinentCountry
      // 
      this.cmdContinentCountry.Location = new System.Drawing.Point(16, 18);
      this.cmdContinentCountry.Name = "cmdContinentCountry";
      this.cmdContinentCountry.Size = new System.Drawing.Size(152, 32);
      this.cmdContinentCountry.TabIndex = 10;
      this.cmdContinentCountry.Text = "&Continent and Country";
      this.cmdContinentCountry.Click += new System.EventHandler(this.cmdContinentCountry_Click);
      // 
      // cmdBrewer
      // 
      this.cmdBrewer.Location = new System.Drawing.Point(16, 66);
      this.cmdBrewer.Name = "cmdBrewer";
      this.cmdBrewer.Size = new System.Drawing.Size(152, 32);
      this.cmdBrewer.TabIndex = 11;
      this.cmdBrewer.Text = "&Brewer";
      this.cmdBrewer.Click += new System.EventHandler(this.cmdBrewer_Click);
      // 
      // cmdFindAmountAccount
      // 
      this.cmdFindAmountAccount.Location = new System.Drawing.Point(16, 354);
      this.cmdFindAmountAccount.Name = "cmdFindAmountAccount";
      this.cmdFindAmountAccount.Size = new System.Drawing.Size(152, 32);
      this.cmdFindAmountAccount.TabIndex = 19;
      this.cmdFindAmountAccount.Text = "&Find Amount Account";
      this.cmdFindAmountAccount.Click += new System.EventHandler(this.cmdFindAmountAccount_Click);
      // 
      // cmdBeerAndAccount
      // 
      this.cmdBeerAndAccount.Location = new System.Drawing.Point(16, 162);
      this.cmdBeerAndAccount.Name = "cmdBeerAndAccount";
      this.cmdBeerAndAccount.Size = new System.Drawing.Size(152, 32);
      this.cmdBeerAndAccount.TabIndex = 14;
      this.cmdBeerAndAccount.Text = "Beer and &Account";
      this.cmdBeerAndAccount.Click += new System.EventHandler(this.cmdBeerAndAccount_Click);
      // 
      // frmMain
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(400, 405);
      this.Controls.Add(this.cmdBeerAndBrewerFilteredDatagrid);
      this.Controls.Add(this.cmdBeerAndBrewerTypedDatagrid);
      this.Controls.Add(this.cmdBeerAndBrewerDatagrid);
      this.Controls.Add(this.cmdBeerAndBrewer);
      this.Controls.Add(this.cmdBrewerDatagridMultiuser);
      this.Controls.Add(this.cmdBrewerDatagrid);
      this.Controls.Add(this.cmdContinentCountry);
      this.Controls.Add(this.cmdBrewer);
      this.Controls.Add(this.cmdFindAmountAccount);
      this.Controls.Add(this.cmdBeerAndAccount);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMain";
      this.Text = "Selection screen Beer and Account";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMain'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMain()
      //***
      // Action
      //   - Create instance of 'frmMain'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMain()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdBeerAndAccount_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmBeerAndAccount'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmBeerAndAccount()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmBeerAndAccount theForm = new frmBeerAndAccount();

      theForm.Show();
    }
    // cmdBeerAndAccount_Click(System.Object, System.EventArgs) Handles cmdBeerAndAccount.Click

    private void cmdBeerAndBrewer_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmBeerBrewer'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmBeerBrewer()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmBeerBrewer theForm = new frmBeerBrewer();

      theForm.Show();
    }
    // cmdBeerAndBrewer_Click(System.Object, System.EventArgs) Handles cmdBeerAndBrewer.Click

    private void cmdBeerAndBrewerDatagrid_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmBeerBrewerDatagrid'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmBeerBrewerDatagrid()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmBeerBrewerDatagrid theForm = new frmBeerBrewerDatagrid();

      theForm.Show();
    }
    // cmdBeerAndBrewerDatagrid_Click(System.Object, System.EventArgs) Handles cmdBeerAndBrewerDatagrid.Click

    private void cmdBeerAndBrewerFilteredDatagrid_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmBeerBrewerTypedFilterDatagrid'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmBeerBrewerTypedFilterDatagrid.New()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmBeerBrewerTypedFilterDatagrid theForm = new frmBeerBrewerTypedFilterDatagrid();

      theForm.Show();
    }
    // cmdBeerAndBrewerFilteredDatagrid_Click(System.Object, System.EventArgs) Handles cmdBeerAndBrewerFilteredDatagrid.Click

    private void cmdBeerAndBrewerTypedDatagrid_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmBeerBrewerTypedDatagrid'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmBeerBrewerTypedDatagrid()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmBeerBrewerTypedDatagrid theForm = new frmBeerBrewerTypedDatagrid();

      theForm.Show();
    }
    // cmdBeerAndBrewerTypedDatagrid_Click(System.Object, System.EventArgs) Handles cmdBeerAndBrewerTypedDatagrid.Click

    private void cmdBrewer_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmBrewer'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmBrewer.New()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmBrewer theForm = new frmBrewer();

      theForm.Show();
    }
    // cmdBrewer_Click(System.Object, System.EventArgs) Handles cmdBrewer.Click

    private void cmdBrewerDatagrid_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmBrewerTypedDatagridUpdate'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmBrewerTypedDatagridUpdate()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmBrewerTypedDatagridUpdate theForm = new frmBrewerTypedDatagridUpdate();

      theForm.Show();
    }
    // cmdBrewerDatagrid_Click(System.Object, System.EventArgs) Handles cmdBrewerDatagrid.Click

    private void cmdBrewerDatagridMultiuser_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmBrewerMultiUser'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmBrewerMultiUser()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmBrewerMultiUser theForm = new frmBrewerMultiUser();

      theForm.Show();
    }
    // cmdBrewerDatagridMultiuser_Click(System.Object, System.EventArgs) Handles cmdBrewerDatagridMultiuser.Click

    private void cmdContinentCountry_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmContinentCountry'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmContinentCountry()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmContinentCountry theForm = new frmContinentCountry();

      theForm.Show();
    }
    // cmdContinentCountry_Click(System.Object, System.EventArgs) Handles cmdContinentCountry.Click

    private void cmdFindAmountAccount_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmFindAmountAccount'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmFindAmountAccount.New()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmFindAmountAccount theForm = new frmFindAmountAccount();

      theForm.Show();
    }
    // cmdFindAmountAccount_Click(System.Object, System.EventArgs) Handles cmdFindAmountAccount.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMain
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmMain()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMain());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMain

}
// CopyPaste.Learning