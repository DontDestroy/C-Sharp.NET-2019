//***
// Action
//   - 
// Created
//   - CopyPaste � yyyymmdd � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � yyyymmdd � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Define a cpTouchTonePhone
      //   - Define a cpRotaryPhone
      //   - Define a cpPhone
      //   - Dial with the 3 phones
      //   - The cpPhone becomes the cpRotaryPhone
      //   - Dial with the cpPhone
      //   - The cpPhone becomes the cpTouchTonePhone
      //   - Dial with the cpPhone
      // Called by
      //   - 
      // Calls
      //   - cpPhone(string)
      //   - cpPhone.Dial()
      //   - cpRotaryPhone(string)
      //   - cpRotaryPhone.Dial()
      //   - cpTouchTonePhone(string)
      //   - cpTouchTonePhone.Dial()
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpPhone thecpPolyPhone = new cpPhone("123-4567");
      cpRotaryPhone thecpOldPhone = new cpRotaryPhone("555-1212");
      cpTouchTonePhone thecpKidsPhone = new cpTouchTonePhone("800-555-1212");

      Console.WriteLine("Using standard objects");
      thecpPolyPhone.Dial();
      thecpOldPhone.Dial();
      thecpKidsPhone.Dial();
      
      Console.WriteLine();
      Console.WriteLine("Using polymorphic phone");
      Console.WriteLine();
      thecpPolyPhone = thecpOldPhone;
      thecpPolyPhone.Dial();
      thecpPolyPhone = thecpKidsPhone;
      thecpPolyPhone.Dial();
      
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning