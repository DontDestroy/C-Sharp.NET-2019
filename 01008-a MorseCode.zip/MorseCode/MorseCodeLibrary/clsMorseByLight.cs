﻿//***
// Action
//   - Implementation of a cpMessageMorseByLight
//		 - The way a Morse code is send by light (flash)
// Created
//   - CopyPaste – 20241227 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20241227 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;
using System.Windows.Forms;

namespace CopyPaste.MorseCode.Library
{

	public class cpMorseByLight : cpiMessageMorse
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpMorseByLight
		/// </summary>
		public cpMorseByLight(PictureBox thePictureBox)
		//***
		// Action
		//   - Basic constructor
		//   - Set the PictureBox
		// Called by
		//   - CopyPaste.MorseCode.frmMorseCode.cmdSend_Click(System.Object, EventArgs) Handles cmdSend.Click
		//   - CopyPaste.MorseCode.Test.cpProgram()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20241227 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20241227 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			_thePictureBox = thePictureBox;
		}
		// cpMorseByLight(PictureBox)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private PictureBox _thePictureBox;

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		///  Define how a list of signal items is send by light
		/// </summary>
		/// <param name="lstMessage"></param>
		/// <returns>A list of cpSignalItem</returns>
		public void SendMessage(List<cpSignalItem> lstMessage)
		//***
		// Action
		//   - Define how a message is send in Morse (by light)
		//   - Loop for all the signals
		//     - If there is a signal
		//       - Make the picture box visible
		//     - If not
		//       - Make the picture box invisible
		//     - Wait a specific length
		// Called by
		//   - cpMorse() (indirectly, thru delegates)
		// Calls
		//   - int cpSignalItem.Length (Get)
		//   - string cpSignalItem.Signal (Get)
		// Created
		//   - CopyPaste – 20241227 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20241227 – VVDW
		// Keyboard ke7
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Message of {0} items is send by light", lstMessage.Count);

			foreach (cpSignalItem theSignalItem in lstMessage)
			{
				Debug.Print("Send {0} for {1} milliseconds by light", theSignalItem.Signal, theSignalItem.Length);

				if (theSignalItem.Signal)
				{
					_thePictureBox.Visible = true;
				}
				// Not theSignalItem.Signal
				else
				{
					_thePictureBox.Visible = false;
				}
				// theSignalItem.Signal

				_thePictureBox.Update();
				Thread.Sleep(theSignalItem.Length);
			}
			// in lstMessage

		}
		// SendMessage(List<cpSignalItem>)

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpMorseByLight

}
// CopyPaste.MorseCode.Library