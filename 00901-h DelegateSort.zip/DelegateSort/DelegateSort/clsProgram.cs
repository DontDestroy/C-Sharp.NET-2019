﻿//***
// Action
//   - Using a delegate to create a generic sort routine
// Created
//   - CopyPaste – 20250715 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250715 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static Compare mCompareMethod = new Compare(CompareAuthor);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private delegate bool Compare(cpBook theFirstBook, cpBook theSecondBook);

    #endregion

    #region "Sub / Function"

    private static bool CompareAuthor(cpBook theFirstBook, cpBook theSecondBook)
      //***
      // Action
      //   - If author of first book is after author of second book
      //     - Return True
      //   - If not
      //     - Return False
      // Called by
      //   - SortList(cpBook[])
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250715 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250715 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;

      if (theFirstBook.mstrAuthor.CompareTo(theSecondBook.mstrAuthor) > 0)
      {
        blnResult = true;
      }
      else
        // theFirstBook.mstrAuthor.CompareTo(theSecondBook.mstrAuthor) <= 0
      {
        blnResult = false;
      }
      // theFirstBook.mstrAuthor.CompareTo(theSecondBook.mstrAuthor) > 0

      return blnResult;
    }
    // CompareAuthor(cpBook, cpBook) As Boolean

    private static bool ComparePrice(cpBook theFirstBook, cpBook theSecondBook)
      //***
      // Action
      //   - If price of first book is larger than price of second book
      //     - Return True
      //   - If not
      //     - Return False
      // Called by
      //   - SortList(cpBook[])
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250715 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250715 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;

      if (theFirstBook.mdblPrice > theSecondBook.mdblPrice)
      {
        blnResult = true;
      }
      else
        // theFirstBook.mdblPrice <= theSecondBook.mdblPrice
      {
        blnResult = false;
      }
      // theFirstBook.mdblPrice > theSecondBook.mdblPrice

      return blnResult;
    }
    // CompareTitle(cpBook, cpBook) As Boolean

    private static bool CompareTitle(cpBook theFirstBook, cpBook theSecondBook)
      //***
      // Action
      //   - If title of first book is after title of second book
      //     - Return True
      //   - If not
      //     - Return False
      // Called by
      //   - SortList(cpBook[])
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250715 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250715 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;

      if (theFirstBook.mstrTitle.CompareTo(theSecondBook.mstrTitle) > 0)
      {
        blnResult = true;
      }
      else
        // theFirstBook.mstrTitle.CompareTo(theSecondBook.mstrTitle) <= 0
      {
        blnResult = false;
      }
      // theFirstBook.mstrTitle.CompareTo(theSecondBook.mstrTitle) > 0

      return blnResult;
    }
    // CompareTitle(cpBook, cpBook) As Boolean

    public static void Main()
      //'***
      //' Action
      //'   - Define an array of 4 cpBook
      //'   - Fill the array
      //'   - Sort the list (by author)
      //'     - Show info of the books by order
      //'   - Sort the list (by title)
      //'     - Show info of the books by order
      //'   - Sort the list (by price)
      //'     - Show info of the books by order
      //' Called by
      //'   - User action (Starting the application)
      //' Calls
      //'   - cpBook(string, string, string, double)
      //'   - SortList(cpBook[])
      //' Created
      //'   - CopyPaste – 20250715 – VVDW
      //' Changed
      //'   - CopyPaste – yyyymmdd – VVDW – What changed
      //' Tested
      //'   - CopyPaste – 20250715 – VVDW
      //' Keyboard key
      //'   - 
      //' Proposal (To Do)
      //'   - 
      //'***
    {
      cpBook[] arrcpBook = new cpBook[4];

      arrcpBook[0] = new cpBook("C# Programming Tips & Techniques", "McGraw-Hill/Osborne", "Wright", 49.99);
      arrcpBook[1] = new cpBook("Visual Basic .Net Programming Tips & Techniques", "McGraw-Hill/Osborne", "Jamsa", 34.99);
      arrcpBook[2] = new cpBook("HTML & Web Design Tips & Techniques", "McGraw-Hill/Osborne", "King", 29.99);
      arrcpBook[3] = new cpBook("PC Performance Tuning & Upgrading Tips & Techniques", "McGraw-Hill/Osborne", "Jamsa", 39.99);

      Console.WriteLine("By Author");

      SortList(arrcpBook);

      foreach (cpBook thecpBook in arrcpBook)
      {
        Console.WriteLine(thecpBook.mstrTitle + " - " + thecpBook.mstrAuthor + " - " + thecpBook.mdblPrice);
      }
      // in arrcpBook

      Console.WriteLine();
      Console.WriteLine("By Title");

      mCompareMethod = new Compare(CompareTitle);
      
      SortList(arrcpBook);

      foreach (cpBook thecpBook in arrcpBook)
      {
        Console.WriteLine(thecpBook.mstrTitle + " - " + thecpBook.mstrAuthor + " - " + thecpBook.mdblPrice);
      }
      // in arrcpBook

      Console.WriteLine();
      Console.WriteLine("By Price");
      
      mCompareMethod = new Compare(ComparePrice);
      
      SortList(arrcpBook);

      foreach (cpBook thecpBook in arrcpBook)
      {
        Console.WriteLine(thecpBook.mstrTitle + " - " + thecpBook.mstrAuthor + " - " + thecpBook.mdblPrice);
      }
      // in arrcpBook

      Console.ReadLine();
    }
    // Main()

    private static void SortList(cpBook[] arrcpBook)
      //***
      // Action
      //   - Sorting the list using a kind of bubblesort
      //   - Loop from 0 till the length of the array minus 2 (lngCounter01)
      //     - Loop from lngCounter01 + 1 till the length of the array minus 1 (lngCounter02)
      //       - Compare the elements with indexes lngCounter01 and lngCounter02
      //       - If result is true
      //         - Swap the elements
      //       - If not
      //         - Do nothing
      // Called by
      //   - Main()
      // Calls
      //   - bool mCompareMethod(cpBook, cpBook)
      //   - bool CompareAuthor(cpBook, cpBook) (thru delegate)
      //   - bool ComparePrice(cpBook, cpBook) (thru delegate)
      //   - bool CompareTitle(cpBook, cpBook) (thru delegate)
      // Created
      //   - CopyPaste – 20250715 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250715 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBook aBook;
      int lngCounter01;
      int lngCounter01Till;
      int lngCounter02;
      int lngCounter02Till;

      lngCounter01Till = arrcpBook.Length - 2;

      for (lngCounter01 = 0; lngCounter01 <= lngCounter01Till; lngCounter01++)
      {
        lngCounter02Till = arrcpBook.Length - 1;

        for (lngCounter02 = lngCounter01 + 1; lngCounter02 <= lngCounter02Till; lngCounter02++)
        {
          
          if (mCompareMethod(arrcpBook[lngCounter01], arrcpBook[lngCounter02]))
          {
            aBook = arrcpBook[lngCounter01];
            arrcpBook[lngCounter01] = arrcpBook[lngCounter02];
            arrcpBook[lngCounter02] = aBook;
          }
          else
            // Not mCompareMethod(arrcpBook[lngCounter01], arrcpBook[lngCounter02])
          {
          }
          // mCompareMethod(arrcpBook[lngCounter01], arrcpBook[lngCounter02])
      
        }
        // lngCounter02 > lngCounter02Till

      }
      // lngCounter01 > lngCounter01Till

    }
    // SortList(cpBook())

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning