﻿//***
// Action
//   - There is a database cpWings
//     - The script can be found in the folder 'SQL Script'
//   - The database is used to reverse engineer classes with Entity FrameWork Core
//   - The commands used for doing this can be found in the folder 'Executed Commands'
//   - The testroutine uses methods from classes that were generated
// Created
//   - CopyPaste – 20230710 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230710 – VVDW
// Proposal (To Do)
//   -
//***

using ReverseEngineerLibraryNETCore;
// using ReverseEngineerLibraryNETStandard;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CopyPaste.Toolkit
{

  class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Testroutine for the generated classes, to prove that it works
    //   - Show a start heading
    //   - Count all the passengers (persons that are passengers)
    //   - Look for strSurName "Koch" in the list of persons
    //   - Create a new person "Gertrude Gryson"
    //   - Create a new passenger using the newly created person "Gertrude Gryson"
    //   - Show an end heading
    //   - Wait for user action
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpWingsV1Context()
    //   - int TblCpperson.IntIdPassengerNavigation (Get)
    //   - int TblCpperson.IntIdPerson (Get)
    //   - string TblCpperson.StrGivenName (Get)
    //   - string TblCpperson.StrSurname (Get)
    //   - TblCppassenger()
    //   - TblCppassenger.IntIdPassengerNavigation(TblCpperson) (Set)
    //   - TblCppassenger.StrPassengerStatus(string) (Set)
    //   - TblCpperson()
    //   - TblCpperson.StrGivenName(string) (Set)
    //   - TblCpperson.StrSurname(string) (Set)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpConsole.PrintMainHeadLine("Start ...");

      using (cpWingsV1Context theContext = new cpWingsV1Context())
      {
        cpConsole.PrintMainHeadLine("Count all Passengers");

        List<TblCpperson> lstPersons = theContext.TblCppassengers.Select(aPerson => aPerson.IntIdPassengerNavigation).ToList();
        cpConsole.Print($"Number of Passengers: {lstPersons.Count}");

        cpConsole.PrintMainHeadLine("Show all Passengers with name 'Koch'");

        foreach (TblCpperson theCPPerson in lstPersons.Where(aPerson => aPerson.StrSurname == "Koch"))
        {
          cpConsole.Print($"{theCPPerson.IntIdPerson}: {theCPPerson.StrSurname}, {theCPPerson.StrGivenName}");
        }
        // in lstPersons.Where(aPerson => aPerson.StrSurname == "Koch")

        //// Create a new person
        //TblCpperson newPerson = new TblCpperson();
        //newPerson.StrGivenName = "Gertrude";
        //newPerson.StrSurname = "Gryson";

        //// Create a new passenger
        //TblCppassenger newPassenger = new TblCppassenger();
        //newPassenger.IntIdPassengerNavigation = newPerson;
        //newPassenger.StrPassengerStatus = "A";

        //// Add the passenger to the table tblCPPassenger and save
        //theContext.TblCppassengers.Add(newPassenger);
        //int intCounter = theContext.SaveChanges();

        //cpConsole.PrintMainHeadLine("There are some changes");
        //cpConsole.Print($"Number of changes: {intCounter}");
        //cpConsole.PrintMainHeadLine("Count all Passengers");

        //lstPersons = theContext.TblCppassengers.Select(aPerson => aPerson.IntIdPassengerNavigation).ToList();
        //cpConsole.Print($"Number of Passengers: {lstPersons.Count}");

        //cpConsole.PrintMainHeadLine("Show all Passengers with name 'Gryson'");

        //foreach (TblCpperson theCPPerson in lstPersons.Where(aPerson => aPerson.StrSurname == "Gryson"))
        //{
        //  cpConsole.Print($"{theCPPerson.IntIdPerson}: {theCPPerson.StrSurname}, {theCPPerson.StrGivenName}");
        //}
        //// in lstPersons.Where(aPerson => aPerson.StrSurname == "Gryson")

      }
      // cpWingsV1Context

      cpConsole.PrintMainHeadLine("... Done");

      Console.WriteLine("Hit any key ...");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Toolkit