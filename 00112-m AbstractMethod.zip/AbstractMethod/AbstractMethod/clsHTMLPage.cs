//***
// Action
//   - Implementation of a HTML Page Content
// Created
//   - CopyPaste � 20240412 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240412 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Page
{

  public class cpHTMLPage : cpPageContent
  {

    #region "Constructors / Destructors"

    public cpHTMLPage(string strMessage) : base(strMessage)
      //***
      // Action
      //   - Constructor with Message
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpPageContent(string)
      // Created
      //   - CopyPaste � 20240412 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240412 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpHTMLPage()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override void ShowPage()
      //***
      // Action
      //   - Start html node
      //   - Start body node
      //   - Define page data
      //   - Stop body node
      //   - Stop html node
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240412 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240412 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("<html>");
      Console.WriteLine("<body>");
      Console.WriteLine("<p>" + mstrPageData + "</p>");
      Console.WriteLine("</body>");
      Console.WriteLine("</html>");
    }
    // ShowPage()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx