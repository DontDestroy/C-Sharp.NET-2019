﻿//***
// Action
//   - Having a connection towards a database
//   - Interaction logic for ctrlConnection.xaml (part of MainWindow.xaml)
// Created
//   - CopyPaste – 20210806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210806 – VVDW
// Proposal (To Do)
//   - 
//***

using WPFConnection.ViewModel;
using System.Windows.Controls;

namespace WPFConnection.cpUserControl
{

  public partial class ctrlConnection : UserControl
  {

    #region "Constructors / Destructors"

    public ctrlConnection()
    //***
    // Action
    //   - Creating an instance of the WPF control
    //   - Initialize the components of that control
    //   - Define a cpConnectionViewModel
    // Called by
    //   - MainWindow.mnuConnections_Click(System.Object, System.Windows.RoutedEventArgs)
    //   - User Action Or System action (Showing the control)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210806 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210806 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***

    {
      InitializeComponent();
      _viewModel = (cpConnectionViewModel)this.Resources["viewModel"];
    }
    // ctrlConnection()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private readonly cpConnectionViewModel _viewModel;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void cmdOpenConnectionErrorHandling_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Connect to the database thru the given connection string (on screen)
    //   - Show the properties of the connection in txtResult
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - cpConnectionViewModel.ConnectWithErrors()
    // Created
    //   - CopyPaste – 20210806 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210806 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.ConnectWithErrors();
    }
    // cmdOpenConnectionErrorHandling_Click(System.Object, System.Windows.RoutedEventArgs)

    private void cmdOpenConnectionSQLServerAuthorisation_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Connect to the database thru the given connection string (hardcoded)
    //   - Show the properties of the connection in txtResult
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - cpConnectionViewModel.Connect(string)
    //   - cpConnectionViewModel.ConnectionString(string) (Set)
    //   - string cpConnectionViewModel.ConnectionString() (Get)
    // Created
    //   - CopyPaste – 20210806 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210806 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Study the alternative
    //***
    {
      _viewModel.Connect("Server=COPYPASTEPOWER\\COPYPASTE;Database=cpNorthWindScript2019;User ID=sa;Password=Full0fData;");
      // _viewModel.ConnectionString = "Server=COPYPASTEPOWER\\COPYPASTE;Database=cpNorthWindScript2019;User ID=sa;Password=Full0fData;";
      // _viewModel.Connect(_viewModel.ConnectionString);
    }
    // cmdOpenConnectionSQLServerAuthorisation_Click(System.Object, System.Windows.RoutedEventArgs)

    private void cmdOpenConnectionUsingBlock_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Connect to the database thru the given connection string (on screen)
    //   - Show the properties of the connection in txtResult
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - cpConnectionViewModel.ConnectUsingBlock()
    // Created
    //   - CopyPaste – 20210806 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210806 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.ConnectUsingBlock();
    }
    // cmdOpenConnectionUsingBlock_Click(System.Object, System.Windows.RoutedEventArgs)

    private void cmdOpenConnectionWindowsAuthorisation_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Connect to the database thru the given connection string (on screen)
    //   - Show the properties of the connection in txtResult
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - cpConnectionViewModel.Connect(String)
    //   - string cpConnectionViewModel.ConnectionString() (Get)
    // Created
    //   - CopyPaste – 20210806 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210806 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.Connect(_viewModel.ConnectionString);
    }
    // cmdOpenConnectionWindowsAuthorisation_Click(System.Object, System.Windows.RoutedEventArgs)

  private void cmdOpenWebsite_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Start a certain website in a browser
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20210806 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210806 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      System.Diagnostics.Process.Start("https://www.connectionstrings.com");
    }
    // cmdOpenWebsite_Click(System.Object, System.Windows.RoutedEventArgs)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // ctrlConnection 

}
// WPFConnection.cpUserControl