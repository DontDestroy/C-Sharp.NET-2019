//***
// Action
//   - An empty form with a click that runs the delegate
// Created
//   - CopyPaste � 20250713 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250713 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDelegateTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDelegateTryout));
      // 
      // frmDelegateTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDelegateTryout";
      this.Text = "Tryout Delegate";
      this.Click += new System.EventHandler(this.frmDelegateTryout_Click);
      this.Load += new System.EventHandler(this.frmDelegateTryout_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDelegateTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250713 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250713 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDelegateTryout()
      //***
      // Action
      //   - Create instance of 'frmDelegateTryout'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250713 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250713 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDelegateTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpDelegate mcpDelegate;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmDelegateTryout_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Execute the delegated method
      // Called by
      //   - User action (Clicking the form)
      // Calls
      //   - cpDelegate.TestDelegate()
      // Created
      //   - CopyPaste � 20250713 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250713 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - 
      //***
    {
      mcpDelegate.TestDelegate();
    }
    // frmDelegateTryout_Click(System.Object, System.EventArgs) Handles this.Click

    private void frmDelegateTryout_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Setting the delegate to 2 possible methods
      //   - Using a property or a method
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpDelegate()
      //   - cpDelegate.CallBack (cpCallBack) (Set) 
      //   - cpDelegate.SetDelegate(cpCallBack)
      //   - int CallBack1(string) 
      //   - int CallBack2(string)
      // Created
      //   - CopyPaste � 20250713 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250713 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - Use the commented statements to test
      //***
    {
      mcpDelegate = new cpDelegate();

      mcpDelegate.CallBack = new cpDelegate.cpCallBack(CallBack1);
      // mcpDelegate.CallBack = new cpDelegate.cpCallBack(CallBack2);
      // mcpDelegate.SetDelegate(new cpDelegate.cpCallBack(CallBack1));
      // mcpDelegate.SetDelegate(new cpDelegate.cpCallBack(CallBack2));
    }
    // frmDelegateTryout_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private int CallBack1(string strText)
      //***
      // Action
      //   - Shows the given text
      //   - Returns the length
      // Called by
      //   - frmDelegateTryout_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250713 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250713 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show(strText);

      return strText.Length;
    }
    // int CallBack1(string)

    private int CallBack2(string strText)
      //***
      // Action
      //   - Shows the given text
      //   - Returns if it ends with "123"
      // Called by
      //   - frmDelegateTryout_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250713 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250713 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show(strText);

      return Convert.ToInt32(strText.EndsWith("123"));
    }
    // int CallBack2(string)

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDelegateTryout
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDelegateTryout()
      // Created
      //   - CopyPaste � 20250713 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250713 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDelegateTryout());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDelegateTryout

}
// CopyPaste.Learning