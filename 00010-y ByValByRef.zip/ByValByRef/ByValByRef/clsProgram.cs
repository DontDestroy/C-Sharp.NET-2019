//***
// Action
//   - An example of variables in a method using ByValue or ByRef
// Created
//   - CopyPaste � 20240608 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240608 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void ChangeByRef(ref byte bytFirstNumber, ref byte bytSecondNumber)
      //***
      // Action
      //   - Switch the values given by the parameters
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240608 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240608 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      byte bytHelp;

      bytHelp = bytFirstNumber;
      bytFirstNumber = bytSecondNumber;
      bytSecondNumber = bytHelp;
    }
    // ChangeByRef(�byte, �byte)

    public static void ChangeByValue(byte bytFirstNumber, byte bytSecondNumber)
      //***
      // Action
      //   - Switch the values given by the parameters
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240608 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240608 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      byte bytHelp;

      bytHelp = bytFirstNumber;
      bytFirstNumber = bytSecondNumber;
      bytSecondNumber = bytHelp;
    }
    // ChangeByValue(byte, byte)

    public static void Main()
      //***
      // Action
      //   - You have 2 values and you switch them using methods
      //   - One time the variables are given by value
      //   - One time the variables are given by reference
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - ChangeByRef(�byte, �byte)
      //   - ChangeByValue(byte, byte)
      // Created
      //   - CopyPaste � 20240608 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240608 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      byte bytNumber1 = 1;
      byte bytNumber2 = 2;

      ChangeByValue(bytNumber1, bytNumber2);
      Console.WriteLine("By Value");
      Console.WriteLine(bytNumber1);
      Console.WriteLine(bytNumber2);
      Console.WriteLine();

      ChangeByRef(ref bytNumber1, ref bytNumber2);
      Console.WriteLine("By Reference");
      Console.WriteLine(bytNumber1);
      Console.WriteLine(bytNumber2);
      Console.WriteLine();
      Console.WriteLine("Hit any key ...");
      Console.ReadLine();
    }		
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx