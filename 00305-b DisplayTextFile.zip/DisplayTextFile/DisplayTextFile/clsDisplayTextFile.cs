//***
// Action
//   - Reading from a textfile
// Created
//   - CopyPaste � 20220527 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220527 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace DisplayTextFile
{

  class cpDisplayTextFile
	{

  //#region "Constructors / Destructors"
  //#endregion

  //#region "Designer"
  //#endregion

  //#region "Structures"
  //#endregion

  //#region "Fields"
  //#endregion

  //#region "Properties"
  //#endregion

  #region "Methods"

  //#region "Overrides"
  //#endregion

  //#region "Controls"
  //#endregion

  #region "Functionality"

  //#region "Event"
  //#endregion

  #region "Sub / Function"

  static void Main()
    //***
    // Action
    //   - Defining a StreamReader
    //   - Reading from a file (line per line)
    //     - While line is not null
    //       - Show it in the console
    //   - Closing the file
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220527 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220527 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
  {
    string strContent;
    StreamReader strReader = new StreamReader(@"C:\BookInfo.txt");

    do
    {
      strContent = strReader.ReadLine();

      if (strContent == null)
      {
      }
      else
      // strContent <> null
      {
        Console.WriteLine(strContent);
      }
      // strContent == null

    }
    while (strContent != null);
    // strContent = null

    strReader.Close();
    Console.ReadLine();

  }
  // Main()

  #endregion

  #endregion

  #endregion

  //#region "Not used"
  //#endregion
  
  }
  // cpDisplayTextFile

}
// DisplayTextFile