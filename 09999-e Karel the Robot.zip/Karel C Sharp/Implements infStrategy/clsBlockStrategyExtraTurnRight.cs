﻿//***
// Action
//   - Implementation of a BlockStrategyExtraTurnRight
// Created
//   - CopyPaste – 20251028 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251028 – VVDW
// Proposal (To Do)
//   -
//***

using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpBlockStrategyExtraTurnRight : cpinfStrategy
	{

    #region "Constructors / Destructors"

    public cpBlockStrategyExtraTurnRight(cpinfStrategy theDecorated)
    //***
    // Action
    //   - Constructor of the start situation
    //   - A given cpinfStrategy is the input
    // Called by
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theInternalDecorated = theDecorated;
    }
    // cpBlockStrategyExtraTurnRight(cpinfStrategy)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpinfStrategy theInternalDecorated = new cpNullStrategy();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void DoIt(cpCopyPasteRobot aRobot)
    //***
    // Action
    //   - Implementation of DoIt
    //     - Do the action for the decorated (which is unknown here)
    //     - Extra turn right (the decoration)
    // Called by
    //   - 
    // Calls
    //   - cpCopyPasteRobot.TurnRight()
    //   - cpinfStrategy.DoIt(cpCopyPasteRobot)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theInternalDecorated.DoIt(aRobot);
      aRobot.TurnRight();
    }
    // DoIt(cpCopyPasteRobot)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBlockStrategyExtraTurnRight

}
// cpKarelTheRobot