﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="default.aspx.cs" Inherits="CopyPaste.Learning.wfrmDefault" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Welcome</title>
</head>
<body>
  <form id="wfrmWelcome" method="post" runat="server">
    <asp:Label ID="lblWelcome" Style="z-index: 101; position: absolute; top: 32px; left: 32px"
      runat="server" Font-Size="XX-Large">Welcome</asp:Label>
  </form>
</body>
</html>
