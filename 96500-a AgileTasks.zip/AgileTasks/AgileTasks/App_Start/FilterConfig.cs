﻿//***
// Action
//   - Implementation of Bundle Config
// Created
//   - CopyPaste – 20260427 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260427 – VVDW
// Proposal (To Do)
//   -
//***

using System.Web;
using System.Web.Mvc;

namespace AgileTasks
{

  public class FilterConfig
  {

    #region "Constructors / Destructors"

    public FilterConfig()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // FilterConfig()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void RegisterGlobalFilters(GlobalFilterCollection filters)
    //***
    // Action
    //   - Add an handle error attribute to the filters collection
    // Called by
    //   - MvcApplication.Application_Start()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      filters.Add(new HandleErrorAttribute());
    }
    // RegisterGlobalFilters(GlobalFilterCollection)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // FilterConfig

}
// AgileTasks