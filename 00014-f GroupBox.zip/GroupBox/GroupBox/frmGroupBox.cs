//***
// Action
//   - A demo of group boxes and option buttons 
// Created
//   - CopyPaste � 20240207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240207 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmGroupBox: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.GroupBox grpDinner;
    internal System.Windows.Forms.RadioButton optDinnerSoup;
    internal System.Windows.Forms.RadioButton optDinnerSalad;
    internal System.Windows.Forms.RadioButton optDinnerAppetizer;
    internal System.Windows.Forms.Button cmdShow;
    internal System.Windows.Forms.GroupBox grpLunch;
    internal System.Windows.Forms.RadioButton optLunchFruit;
    internal System.Windows.Forms.RadioButton optLunchSoup;
    internal System.Windows.Forms.RadioButton optLunchSalad;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmGroupBox));
      this.grpDinner = new System.Windows.Forms.GroupBox();
      this.optDinnerSoup = new System.Windows.Forms.RadioButton();
      this.optDinnerSalad = new System.Windows.Forms.RadioButton();
      this.optDinnerAppetizer = new System.Windows.Forms.RadioButton();
      this.cmdShow = new System.Windows.Forms.Button();
      this.grpLunch = new System.Windows.Forms.GroupBox();
      this.optLunchFruit = new System.Windows.Forms.RadioButton();
      this.optLunchSoup = new System.Windows.Forms.RadioButton();
      this.optLunchSalad = new System.Windows.Forms.RadioButton();
      this.grpDinner.SuspendLayout();
      this.grpLunch.SuspendLayout();
      this.SuspendLayout();
      // 
      // grpDinner
      // 
      this.grpDinner.Controls.Add(this.optDinnerSoup);
      this.grpDinner.Controls.Add(this.optDinnerSalad);
      this.grpDinner.Controls.Add(this.optDinnerAppetizer);
      this.grpDinner.Location = new System.Drawing.Point(24, 184);
      this.grpDinner.Name = "grpDinner";
      this.grpDinner.Size = new System.Drawing.Size(200, 128);
      this.grpDinner.TabIndex = 4;
      this.grpDinner.TabStop = false;
      this.grpDinner.Text = "Dinner";
      // 
      // optDinnerSoup
      // 
      this.optDinnerSoup.Location = new System.Drawing.Point(32, 88);
      this.optDinnerSoup.Name = "optDinnerSoup";
      this.optDinnerSoup.TabIndex = 2;
      this.optDinnerSoup.Text = "Soup";
      // 
      // optDinnerSalad
      // 
      this.optDinnerSalad.Location = new System.Drawing.Point(32, 56);
      this.optDinnerSalad.Name = "optDinnerSalad";
      this.optDinnerSalad.TabIndex = 1;
      this.optDinnerSalad.Text = "Salad";
      // 
      // optDinnerAppetizer
      // 
      this.optDinnerAppetizer.Location = new System.Drawing.Point(32, 24);
      this.optDinnerAppetizer.Name = "optDinnerAppetizer";
      this.optDinnerAppetizer.TabIndex = 0;
      this.optDinnerAppetizer.Text = "Appetizer";
      // 
      // cmdShow
      // 
      this.cmdShow.Location = new System.Drawing.Point(80, 344);
      this.cmdShow.Name = "cmdShow";
      this.cmdShow.Size = new System.Drawing.Size(96, 23);
      this.cmdShow.TabIndex = 5;
      this.cmdShow.Text = "Show Choices";
      this.cmdShow.Click += new System.EventHandler(this.cmdShow_Click);
      // 
      // grpLunch
      // 
      this.grpLunch.Controls.Add(this.optLunchFruit);
      this.grpLunch.Controls.Add(this.optLunchSoup);
      this.grpLunch.Controls.Add(this.optLunchSalad);
      this.grpLunch.Location = new System.Drawing.Point(24, 24);
      this.grpLunch.Name = "grpLunch";
      this.grpLunch.Size = new System.Drawing.Size(200, 128);
      this.grpLunch.TabIndex = 3;
      this.grpLunch.TabStop = false;
      this.grpLunch.Text = "Lunch";
      // 
      // optLunchFruit
      // 
      this.optLunchFruit.Location = new System.Drawing.Point(32, 88);
      this.optLunchFruit.Name = "optLunchFruit";
      this.optLunchFruit.TabIndex = 2;
      this.optLunchFruit.Text = "Fruit";
      // 
      // optLunchSoup
      // 
      this.optLunchSoup.Location = new System.Drawing.Point(32, 56);
      this.optLunchSoup.Name = "optLunchSoup";
      this.optLunchSoup.TabIndex = 1;
      this.optLunchSoup.Text = "Soup";
      // 
      // optLunchSalad
      // 
      this.optLunchSalad.Location = new System.Drawing.Point(32, 24);
      this.optLunchSalad.Name = "optLunchSalad";
      this.optLunchSalad.TabIndex = 0;
      this.optLunchSalad.Text = "Salad";
      // 
      // frmGroupBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(248, 405);
      this.Controls.Add(this.grpDinner);
      this.Controls.Add(this.cmdShow);
      this.Controls.Add(this.grpLunch);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmGroupBox";
      this.Text = "GroupBox";
      this.grpDinner.ResumeLayout(false);
      this.grpLunch.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmGroupBox'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmGroupBox()
      //***
      // Action
      //   - Create instance of 'frmGroupBox'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmGroupBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdShow_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the result of the choosen options
      //   - Depending on the option choosen for lunch
      //     - Show the information
      //   - Depending on the option choosen for dinner
      //     - Show the information
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (optLunchSoup.Checked)
      {
        MessageBox.Show("Soup for lunch");
      }
      else if (optLunchSalad.Checked)
        // Not optLunchSoup.Checked
      {
        MessageBox.Show("Salad for lunch");
      }
      else if (optLunchFruit.Checked)
        // Not optLunchSalad.Checked
      {
        MessageBox.Show("Fruit for lunch");
      }
      else
        // Not optLunchFruit.Checked
      {
      }
      // optLunchSoup.Checked
      // optLunchSalad.Checked
      // optLunchFruit.Checked

      if (optDinnerAppetizer.Checked)
      {
        MessageBox.Show("Appetizer for dinner");
      }
      else if (optDinnerSalad.Checked)
        // Not optDinnerAppetizer.Checked
      {
        MessageBox.Show("Salad for dinner");
      }
      else if (optDinnerSoup.Checked)
        // Not optDinnerSalad.Checked
      {
        MessageBox.Show("Soup for dinner");
      }
      else
        // Not optDinnerSoup.Checked
      {
      }
      // optDinnerAppetizer.Checked
      // optDinnerSalad.Checked
      // optDinnerSoup.Checked
    
    }
    // cmdShow_Click(System.Object, System.EventArgs) Handles cmdShow_Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDefault
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmGroupBox());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmGroupBox

}
// CopyPaste.Learning