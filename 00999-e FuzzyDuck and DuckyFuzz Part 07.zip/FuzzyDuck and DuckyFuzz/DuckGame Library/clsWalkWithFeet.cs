﻿//***
// Action
//   - Implementation of a cpWalkHappyFeet
//		 - The way a thing moves on the ground using feet
// Created
//   - CopyPaste – 20240725 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240725 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Animal.Library
{

	public class cpWalkWithFeet : cpiWalk
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpWalkWithFeet
		/// </summary>
		public cpWalkWithFeet()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - cpMallardDuck()
		//   - cpRedHeadDuck()
		//   - cpWoodDuck()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpWalkWithFeet()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing moves on the ground using feet
		/// </summary>
		public void Walk()
		//***
		// Action
		//   - Define how something is moving with feet
		// Called by
		//   - cpMallardDuck()
		//   - cpRedHeadDuck()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Something is moving around on the ground using feet");
		}
		// Walk()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpWalkWithFeet

}
// CopyPaste.Game.Animal.Library