﻿//***
// Action
//   - A sorting routine are compared to each other (depending on three different lengths)
// Created
//   - CopyPaste – 20260525 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260525 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpSortingBenchMarks
  {

    #region "Constructors / Destructors"

    public cpSortingBenchMarks()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main() 
    //   - cpProgram.RunSomeCode()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpSortingBenchMarks()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    [ParamsAttribute(100_000, 1_000_000, 10_000_000, 100_000_000)]
    public int size;
    private int[] arrDataToSort;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [BenchmarkAttribute]
    public void ArraySort()
    //***
    // Action
    //   - Sort the array
    //     - On creation the items were put in reverse order, so the worst case is tested
    // Called by
    //   - cpProgram.Main()
    //   - cpProgram.RunSomeCode()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Array.Sort(arrDataToSort);
    }
    // ArraySort()

    [GlobalSetupAttribute]
    public void Setup()
    //***
    // Action
    //   - A range from 0 to size is created and reversed, so the worst case for sorting is tested
    // Called by
    //   - cpProgram.Main()
    //   - cpProgram.RunSomeCode()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      arrDataToSort = Enumerable.Range(0, size).Reverse().ToArray();
    }
    // Setup()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpSortingBenchMarks

}
// CopyPaste.Learning