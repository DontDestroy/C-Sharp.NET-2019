﻿//***
// Action
//   - Create a class cpWhile that inherits cpCopyPasteRobot
//   - Demo a while loop
// Created
//   - CopyPaste – 20251020 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251020 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpWhile: cpCopyPasteRobot
	{

    #region "Constructors / Destructors"

    public cpWhile(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Reset the world
    //   - Build the world according to the Robot World specifications
    //   - Make the world visible
    //   - Karel becomes a green cpCopyPasteRobot starting at position (1, 1), looking to the right with no beepers in the bag
    //   - As long it is true (so always)
    //     - Go as far as possible
    //     - Turn left
    //   - Karel is switched off
    // Called by
    //   - cpProgram.WhileLoop()
    // Calls
    //   - cpCopyPasteRobot(int, int, Direction, int, Color)
    // Created
    //   - CopyPaste – 20251020 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251020 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\01.05 The Robot World Closed.kwld");
      World.setVisible(true);
      cpCopyPasteRobot karel = new cpCopyPasteRobot(intStreet, intAvenue, theDirection, intBeepers, theColor);

      while (true)
      {
        karel.GoAsFarAsPossible();
        karel.turnLeft();
      }
      // true

      karel.turnOff(); // Robot karel is switched off, can't be reached

    }
    // cpWhile(int, int, Directions.Direction, int, Color)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpWhile 

}
// cpKarelTheRobot