//***
// Action
//   - Startup class
//   - A Main() is created, because the App.xaml is removed
//   - the App is constructed with code
// Created
//   - CopyPaste � 20220817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220817 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace SingleInstanceApplication
{

  public class cpStartup
  {

    #region "Constructors / Destructors"

    [STAThread]
    public static void Main(string[] arrstrArguments)
    //***
    // Action
    //   - Startup routine
    // Called by
    //   - Manual action (Starting the application)
    // Calls
    //   - cpSingleInstanceApplicationWrapper()
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpSingleInstanceApplicationWrapper theWrapper = new cpSingleInstanceApplicationWrapper();

      theWrapper.Run(arrstrArguments);
    }
    // Main(string[])

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpStartup

}
// SingleInstanceApplication