//***
// Action
//   - Test on different kind of errors
// Created
//   - CopyPaste � 20230808 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230808 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Ask 2 numbers
      //   - On an error show an error message, depending on the kind of error
      //   - At the end, show that the program ends
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      decimal decNumber1;
      decimal decNumber2;

      Console.Write("Number 1: ");

      try
      {
        decNumber1 = Convert.ToDecimal(Console.ReadLine());
        Console.Write("Number 2: ");
        decNumber2 = Convert.ToDecimal(Console.ReadLine());
        Console.WriteLine("Division: " + decNumber1 / decNumber2);
      }
      catch (FormatException theFormatException)
      {
        Console.WriteLine("You have typed text in stead of numbers");
      }
      catch (DivideByZeroException theDivideByZeroException)
      {
        Console.WriteLine("You can not divide by zero");
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error: " + theException.Message);
        Console.WriteLine("Procedures: " + theException.StackTrace);
      }
      finally
      {
        Console.WriteLine();
        Console.WriteLine("End Program");
        Console.ReadLine();
      }

    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning