//***
// Action
//   - Possible variable types
// Created
//   - CopyPaste � 20210825 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210825 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Proposal (To Do)
//   -
//***

using System;

namespace VariableAssignment
{

  class cpVariableAssignment
	{
    static bool blnMarried = true;
    static byte bytAsciiCode = 17;
    static char chrMiddleInitial = 'V';
    static double dblCarLoan = 23752.65;
    static decimal decHomeLoan = 137240.25M;
    static DateTime dtmBirthDate = new DateTime(1970, 5, 6);
    static int intShoeSize = 42;
    static long lngWeight = 179;
    static object objSomething = "A nice message";
    static short shtAge = 50;
    static float sngAnnualIncome = 12345.67F;
    static string strAddress = "C. Ameyestraat";

    static void Main()
    //***
    // Action
    //   - Set some variables with values
    //   - Show the variable contents
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    //   - System.Console.WriteLine(string, System.Object)
    // Created
    //   - CopyPaste � 20210825 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210825 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("THE VARIABLES PROGRAM");
      Console.WriteLine("---------------------");
      Console.WriteLine("The Boolean is {0}.", blnMarried);
      Console.WriteLine("The Byte is {0}.", bytAsciiCode);
      Console.WriteLine("The Char is {0}.", chrMiddleInitial);
      Console.WriteLine("The Double is {0}.", dblCarLoan);
      Console.WriteLine("The Decimal is {0}.", decHomeLoan);
      Console.WriteLine("The Date is {0}.", dtmBirthDate.Date);
      Console.WriteLine("The Integer is {0}.", intShoeSize);
      Console.WriteLine("The Long is {0}.", lngWeight);
      Console.WriteLine("The Object is {0}.", objSomething);
      Console.WriteLine("The Short is {0}.", shtAge);
      Console.WriteLine("The Single is {0}.", sngAnnualIncome);
      Console.WriteLine("The String is {0}.", strAddress);
      Console.WriteLine("");
      Console.WriteLine("Press Enter...");
      Console.ReadLine();
    }
    // Main()

  }
  // cpVariableAssignment

}
// VariableAssignment