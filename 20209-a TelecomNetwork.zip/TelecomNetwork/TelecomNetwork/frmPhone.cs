﻿//***
// Action
//   - A visualisation of a cpPhone
// Created
//   - CopyPaste – 20230614 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230614 – VVDW
// Proposal (To Do)
//   -
//***

using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.TelecomNetwork
{

  public partial class frmPhone : Form
  {

    #region "Constructors / Destructors"

    public frmPhone()
    //***
    // Action
    //   - Create instance of 'frmPhone'
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmPhone()

    public frmPhone(cpNetwork<cpPhone> aNetwork, cpPhone aPhone) : this()
    //***
    // Action
    //   - Create instance of 'frmPhone'
    //   - Assign a cpNetwork to it
    //   - Assign a cpPhone to it
    //   - Define the action to receive a call
    //   - Define the action to receive a call
    //   - Show information of the cpPhone in the text of the window
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - cpPhone.IsOpen(bool) (Set)
    //   - string cpPhone.ToString()
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      thePhone = aPhone;
      theNetwork = aNetwork;
      thePhone.IsOpen = true;
      thePhone.ReceiveCall += CallReceived;
      thePhone.ReceiveMessage += MessageReceived;
      this.Text = thePhone.ToString();
    }
    // frmPhone(cpNetwork<cpPhone>, cpPhone)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private byte bytNotifyCounter;
    private cpNetwork<cpPhone> theNetwork;
    private cpPhone thePhone;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmPhone_FormClosing(System.Object theSender, System.Windows.Forms.FormClosingEventArgs theFormClosingEventArguments)
    //***
    // Action
    //   - The cpPhone is marked as closed
    // Called by
    //   - User action (Form is closed)
    // Calls
    //   - cpPhone.IsOpen(bool) (Set)
    // Created
    //   - CopyPaste – 20230615 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230615 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      thePhone.IsOpen = false;
    }
    // frmPhone_FormClosing(System.Object, System.Windows.Forms.FormClosingEventArgs) Handles frmPhone.FormClosing

    private void tmrNotify_Tick(System.Object theSender, System.EventArgs theEventArguments)
    {
      bytNotifyCounter++;

      if (BackColor == Color.Red)
      {
        BackColor = DefaultBackColor;
      }
      else
      // BackColor <> Color.Red
      {
        BackColor = Color.Red;
      }
      // BackColor = Color.Red

      if (bytNotifyCounter > 10)
      {
        BackColor = DefaultBackColor;
        tmrNotify.Stop();
      }
      // bytNotifyCounter > 10

    }
    // tmrNotify_Tick(System.Object, System.EventArgs) Handles tmrNotify.Tick

    #endregion

    #region "Functionality"

    #region "Event"

    private void CallReceived(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Implementation of receiving a call with a cpPhone
    //   - Set the notify counter to 0
    //   - Start the timer (to notify a certain time)
    //   - cpPhone becomes 5 times red, simulating a ringtone
    // Called by
    //   - Event when receiving a call
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230615 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230615 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bytNotifyCounter = 0;
      tmrNotify.Start();
    }
    // CallReceived(System.Object, System.EventArgs) Handles thePhone.ReceiveCall

    #endregion

    #region "Sub / Function"

    private void cmdCall_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Call a phone
    //     - You can't call yourself
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - cpNetwork.CallPhone(string)
    // Created
    //   - CopyPaste – 20230615 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230615 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (txtNumber.Text == thePhone.PhoneNumber)
      {
      }
      else
      // txtNumber.Text <> thePhone.PhoneNumber
      {
        theNetwork.CallPhone(txtNumber.Text);
      }
      // txtNumber.Text = thePhone.PhoneNumber

    }
    // cmdCall_Click(System.Object, System.EventArgs) Handles cmdCall.Click

    private void cmdSend_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Message a phone
    //     - You can't message to yourself
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - cpNetwork.MessagePhone(string, string, string)
    // Created
    //   - CopyPaste – 20230615 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230615 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (txtNumber.Text == thePhone.PhoneNumber)
      {
      }
      else
      // txtNumber.Text <> thePhone.PhoneNumber
      {
        theNetwork.MessagePhone(txtNumber.Text, thePhone.PhoneNumber, txtMessage.Text);
        txtMessage.Text = "";
      }
      // txtNumber.Text = thePhone.PhoneNumber

    }
    // cmdSend_Click(System.Object, System.EventArgs) Handles cmdSend.Click

    private void MessageReceived(string strPhoneNumber, string strMessage)
    //***
    // Action
    //   - Implementation of receiving a call with a phone
    //   - Set the notify counter to 8
    //   - Start the timer (to notify a certain time)
    //   - cpPhone becomes one time red, simulating a beep, and the received message is shown
    // Called by
    //   - Event when receiving a message
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230615 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230615 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bytNotifyCounter = 8;
      tmrNotify.Start();
      txtMessage.Text = $"Message from {strPhoneNumber}:\n{strMessage}";
    }
    // MessageReceived(string, string) Handles thePhone.ReceiveMessage

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPhone

}
// CopyPaste.TelecomNetwork
