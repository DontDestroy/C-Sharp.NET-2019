﻿//***
// Action
//   - A definition of a BlockWalker
// Created
//   - CopyPaste – 20251028 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251028 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpBlockWalker : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpBlockWalker(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpBlockWalker starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpBlockWalker(int, int, Directions.Direction, int) 
    //   - cpProgram.BlockWalker()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpBlockWalker(int, int, Directions.Direction, int, Color) 

    public cpBlockWalker(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpBlockWalker starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpBlockWalker(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpBlockWalker(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpinfStrategy myStrategy = new cpThreeBlockStrategy();
    private cpinfStrategy otherStrategy = new cpTwoBlockStrategy();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void SwapStrategies()
    //***
    // Action
    //   - Swap the strategies
    //     - The current (my) strategy becomes a temporary
    //     - The current (my) strategy becomes the other strategy
    //     - The other strategy becomes the temporary
    // Called by
    //   - WalkASide()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpinfStrategy tempStrategy = myStrategy;
      myStrategy = otherStrategy;
      otherStrategy = tempStrategy;
    }
    // SwapStrategies()

    public void WalkASide()
    //***
    // Action
    //   - Execute the current strategy
    //   - Swap the strategies
    // Called by
    //   - cpProgram.BlockWalker()
    // Calls
    //   - cpinfStrategy.DoIt(cpCopyPasteRobot)
    //   - SwapStrategies()
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      myStrategy.DoIt(this);
      SwapStrategies();
    }
    // WalkASide()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBlockWalker

}
// cpKarelTheRobot