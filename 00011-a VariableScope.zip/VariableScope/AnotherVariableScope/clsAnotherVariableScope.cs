//***
// Action
//   - Define some variables
// Created
//   - CopyPaste � 20220128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220128 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace VariableScope
{

  public class cpAnotherVariableScope
	{
    internal string strModuleLevelInternal = "Module Level Internal (Part 3)";
    public string strModuleLevelPublic = "Module Level Public (Part 3)";

    public void VariableScopePart3()
    //***
    // Action
    //   - the method itself is public
    // Called by
    //   - cpVariableScope.Main()
    //   - cpVariableScopePart2.ShowVariables() 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // VariableScopePart3()

    internal void VariableScopePart4()
    //***
    // Action
    //   - The method itself is internal
    // Called by
    //   - cpVariableScope.Main()
    //   - cpVariableScopePart2.ShowVariables() 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strModuleLevel = "Module Level (Part 4)";

      Console.WriteLine(strModuleLevel);
    }
    // VariableScopePart4()

  }
  // cpAnotherVariableScope

}
// VariableScope