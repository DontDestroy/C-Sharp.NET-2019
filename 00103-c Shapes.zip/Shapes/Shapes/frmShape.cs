//***
// Action
//   - Demo of a cpShape
//   - The implementation of the methods is forced in the classes that inherit from cpShape
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmShape : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.PictureBox picCopyPaste;
    internal System.Windows.Forms.Button cmdReal;
    internal System.Windows.Forms.Button cmdFake;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmShape));
      this.picCopyPaste = new System.Windows.Forms.PictureBox();
      this.cmdReal = new System.Windows.Forms.Button();
      this.cmdFake = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // picCopyPaste
      // 
      this.picCopyPaste.Image = ((System.Drawing.Image)(resources.GetObject("picCopyPaste.Image")));
      this.picCopyPaste.Location = new System.Drawing.Point(56, 80);
      this.picCopyPaste.Name = "picCopyPaste";
      this.picCopyPaste.Size = new System.Drawing.Size(188, 188);
      this.picCopyPaste.TabIndex = 5;
      this.picCopyPaste.TabStop = false;
      this.picCopyPaste.Visible = false;
      // 
      // cmdReal
      // 
      this.cmdReal.Location = new System.Drawing.Point(192, 48);
      this.cmdReal.Name = "cmdReal";
      this.cmdReal.TabIndex = 4;
      this.cmdReal.Text = "Real Shape";
      this.cmdReal.Click += new System.EventHandler(this.cmdReal_Click);
      // 
      // cmdFake
      // 
      this.cmdFake.Location = new System.Drawing.Point(192, 16);
      this.cmdFake.Name = "cmdFake";
      this.cmdFake.TabIndex = 3;
      this.cmdFake.Text = "Fake Shape";
      this.cmdFake.Click += new System.EventHandler(this.cmdFake_Click);
      // 
      // frmShape
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.picCopyPaste);
      this.Controls.Add(this.cmdReal);
      this.Controls.Add(this.cmdFake);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmShape";
      this.Text = "Shape";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmShape'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmShape()
      //***
      // Action
      //   - Create instance of 'frmShape'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmShape()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFake_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Demo the fake of a cpShape
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpFakeShape()
      //   - cpFakeShape.Draw()
      //   - cpFakeShape.Reflect()
      //   - cpFakeShape.Rotate(System.Single)
      //   - cpFakeShape.Translate(int, int)
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpFakeShape aFakeShape = new cpFakeShape();

      aFakeShape.Draw();
      aFakeShape.Translate(10, 10);
      aFakeShape.Rotate(90);
      aFakeShape.Reflect();    
    }
    // cmdFake_Click(System.Object, System.EventArgs) Handles cmdFake.Click

    private void cmdReal_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Demo an image (in a picturebox)
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpImage(System.Windows.Forms.PictureBox)
      //   - cpImage.Draw()
      //   - cpImage.Reflect()
      //   - cpImage.Rotate(System.Single)
      //   - cpImage.Translate(int, int)
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpImage anImage = new cpImage(picCopyPaste);

      anImage.Draw();
      anImage.Translate(10, 10);
      anImage.Rotate(90);
      anImage.Reflect();    
    }
    // cmdReal_Click(System.Object, System.EventArgs) Handles cmdReal.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmShape
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmShape()
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmShape());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmShape

}
// CopyPaste.Learning