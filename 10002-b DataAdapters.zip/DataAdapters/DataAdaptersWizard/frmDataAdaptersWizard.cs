﻿//***
// Action
//   - Having DataAdapters and Commands towards a database
// Created
//   - CopyPaste – 20210706 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210706 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataAdaptersWizard
{
  public partial class frmDataAdaptersWizard : Form
  {

    #region "Constructors / Destructors"
    public frmDataAdaptersWizard()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Setting commands (Delete, Insert, Update and Select) for Supplier
    //   - Set properties for mcmmSelectSupplier
    //   - Set handlers for tbaCategory
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210706 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210706 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
      mdtaSupplier = new System.Data.SqlClient.SqlDataAdapter();
      mcmmDeleteSuppliers = new System.Data.SqlClient.SqlCommand();
      mcmmInsertSuppliers = new System.Data.SqlClient.SqlCommand();
      mcmmUpdateSuppliers = new System.Data.SqlClient.SqlCommand();
      mcmmSelectSuppliers = new System.Data.SqlClient.SqlCommand();

      mdtaSupplier.DeleteCommand = mcmmDeleteSuppliers;
      mdtaSupplier.InsertCommand = mcmmInsertSuppliers;
      mdtaSupplier.UpdateCommand = mcmmUpdateSuppliers;
      mdtaSupplier.SelectCommand = mcmmSelectSuppliers;
      mcmmSelectSuppliers.CommandText = "SELECT * FROM tblCPSupplier";
      mcmmSelectSuppliers.Connection = tbaCategory.Connection;

      this.tbaCategory.Adapter.RowUpdated += new System.Data.SqlClient.SqlRowUpdatedEventHandler(_adapter_RowUpdated);
      this.tbaCategory.Adapter.RowUpdating += new System.Data.SqlClient.SqlRowUpdatingEventHandler(_adapter_RowUpdating);
    }
    // frmDataAdaptersWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    internal System.Data.SqlClient.SqlCommand mcmmDeleteSuppliers;
    internal System.Data.SqlClient.SqlCommand mcmmInsertSuppliers;
    internal System.Data.SqlClient.SqlCommand mcmmSelectSuppliers;
    internal System.Data.SqlClient.SqlCommand mcmmUpdateSuppliers;
    internal System.Data.SqlClient.SqlDataAdapter mdtaSupplier;
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFillAll_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Clear Category Dataset
    //   - Clear Product Dataset
    //   - Fill Category Dataset with TableAdapter Category
    //   - Fill Product Dataset with TableAdapter Product
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210702 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210702 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.dsCategory.Clear();
      this.dsProduct.Clear();

      this.tbaCategory.Fill(dsCategory.tblCPCategory);
      this.tbaProduct.Fill(dsProduct.tblCPProduct);
    }
    // cmdFillAll_Click(System.Object, System.EventArgs)

    private void cmdUpdateCategory_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Clear message text
    //   - Update Category Dataset with TableAdapter Category
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210702 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210702 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.txtMessages.Text = "";
      this.tbaCategory.Update(dsCategory.tblCPCategory);
    }
    // cmdUpdateCategory_Click(System.Object, System.EventArgs)

    #endregion

    #region "Functionality"

    #region "Event"

    private void _adapter_RowUpdated(System.Object theSender, System.Data.SqlClient.SqlRowUpdatedEventArgs theSqlRowUpdatedEventArguments)
    //***
    // Action
    //   - Adapt message for every row updated in Dataset Category (Finished)
    // Called by
    //   - SQL action (Finished updating a Category Row) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210706 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210706 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.txtMessages.Text += "Update completed";
      this.txtMessages.Text += ", " + theSqlRowUpdatedEventArguments.RecordsAffected.ToString() + " record(s) updated.\r\n\r\n";
    }
    // _adapter_RowUpdated(System.Object, System.Data.SqlClient.SqlRowUpdatedEventArgs)

    private void _adapter_RowUpdating(System.Object theSender, System.Data.SqlClient.SqlRowUpdatingEventArgs theSqlRowUpdatingEventArguments)
    //***
    // Action
    //   - Adapt message for every row updated in Dataset Category (Started)
    // Called by
    //   - SQL action (Starting updating a Category Row) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210706 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210706 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      txtMessages.Text += "Beginning Update ...";
      txtMessages.Text += "\r\nExecuting a command of type " + theSqlRowUpdatingEventArguments.StatementType.ToString() + "\r\n";
    }
    // _adapter_RowUpdating(System.Object, System.Data.SqlClient.SqlRowUpdatingEventArgs )

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataAdaptersWizard 
}
// DataAdaptersWizard 
