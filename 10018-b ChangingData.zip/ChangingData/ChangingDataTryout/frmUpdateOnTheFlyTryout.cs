//***
// Action
//   - Update records with a SQL Statement
//   - Create and Execute 'On the Fly' Batch Updates Using ADO.NET
// Created
//   - CopyPaste � 20251209 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251209 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmUpdateOnTheFlyTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdExecute;
    internal System.Windows.Forms.TextBox txtRecordsAffected;
    internal System.Windows.Forms.TextBox txtSQLStatement;
    internal System.Windows.Forms.Label lblRecordsAffected;
    internal System.Windows.Forms.Label lblStatement;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmUpdateOnTheFlyTryout));
      this.cmdExecute = new System.Windows.Forms.Button();
      this.txtRecordsAffected = new System.Windows.Forms.TextBox();
      this.txtSQLStatement = new System.Windows.Forms.TextBox();
      this.lblRecordsAffected = new System.Windows.Forms.Label();
      this.lblStatement = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdExecute
      // 
      this.cmdExecute.Location = new System.Drawing.Point(412, 12);
      this.cmdExecute.Name = "cmdExecute";
      this.cmdExecute.Size = new System.Drawing.Size(72, 24);
      this.cmdExecute.TabIndex = 9;
      this.cmdExecute.Text = "&Execute";
      this.cmdExecute.Click += new System.EventHandler(this.cmdExecute_Click);
      // 
      // txtRecordsAffected
      // 
      this.txtRecordsAffected.BackColor = System.Drawing.SystemColors.Control;
      this.txtRecordsAffected.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtRecordsAffected.Location = new System.Drawing.Point(116, 124);
      this.txtRecordsAffected.Name = "txtRecordsAffected";
      this.txtRecordsAffected.Size = new System.Drawing.Size(96, 20);
      this.txtRecordsAffected.TabIndex = 8;
      this.txtRecordsAffected.Text = "";
      // 
      // txtSQLStatement
      // 
      this.txtSQLStatement.Location = new System.Drawing.Point(12, 44);
      this.txtSQLStatement.Multiline = true;
      this.txtSQLStatement.Name = "txtSQLStatement";
      this.txtSQLStatement.Size = new System.Drawing.Size(472, 72);
      this.txtSQLStatement.TabIndex = 6;
      this.txtSQLStatement.Text = "Update tblCPEmployee Set strCity = \'Ypres\' Where strCity = \'Seattle\'";
      // 
      // lblRecordsAffected
      // 
      this.lblRecordsAffected.Location = new System.Drawing.Point(12, 124);
      this.lblRecordsAffected.Name = "lblRecordsAffected";
      this.lblRecordsAffected.Size = new System.Drawing.Size(96, 16);
      this.lblRecordsAffected.TabIndex = 7;
      this.lblRecordsAffected.Text = "Records Affected:";
      // 
      // lblStatement
      // 
      this.lblStatement.Location = new System.Drawing.Point(12, 20);
      this.lblStatement.Name = "lblStatement";
      this.lblStatement.Size = new System.Drawing.Size(160, 16);
      this.lblStatement.TabIndex = 5;
      this.lblStatement.Text = "Update Statement to Execute:";
      // 
      // frmUpdateOnTheFlyTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(496, 157);
      this.Controls.Add(this.cmdExecute);
      this.Controls.Add(this.txtRecordsAffected);
      this.Controls.Add(this.txtSQLStatement);
      this.Controls.Add(this.lblRecordsAffected);
      this.Controls.Add(this.lblStatement);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmUpdateOnTheFlyTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Create and Execute \'On the Fly\' Batch Updates Using ADO.NET Tryout";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmUpdateOnTheFlyTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmUpdateOnTheFlyTryout()
      //***
      // Action
      //   - Create instance of 'frmUpdateOnTheFlyTryout'
      // Called by
      //   - frmChangingDataMainTryout.cmdChangeOnTheFly_Click(System.Object, System.EventArgs) Handles cmdChangeOnTheFly.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmUpdateOnTheFlyTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdExecute_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a connection string
      //   - Create a command (with the typed SQL statement in the form)
      //   - Try to
      //     - Set the command type
      //     - Open the connection
      //     - Execute the command
      //     - Show how many rows are affected
      //   - On error
      //     - Show exception message
      //   - Close the connection
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpConnectionString()
      //   - string cpConnectionString.BuildConnectionString()
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdExecute_Click(System.Object, System.EventArgs) Handles cmdExecute.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmUpdateOnTheFlyTryout

}
// CopyPaste.Learning