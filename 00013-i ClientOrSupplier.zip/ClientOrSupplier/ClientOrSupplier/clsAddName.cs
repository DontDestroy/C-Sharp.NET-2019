//***
// Action
//   - Add a new name to a specific group
// Created
//   - CopyPaste � 20240118 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240118 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;

namespace CopyPaste.Learning
{

  public class cpAddName
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
		
    public static void Add(string strGroup, ref string strReturn)
      //***
      // Action
      //   - Ask for a name
      //   - Return name with linefeed
      // Called by
      //   - frmClientOrSupplier.cmdClient_Click(System.Object, System.EventArgs) Handles cmdClient.Click
      //   - frmClientOrSupplier.cmdSupplier_Click(System.Object, System.EventArgs) Handles cmdSupplier.Click
      // Calls
      //   - string Microsoft.VisualBasic.InputBox(string, string, string, int, int)
      //   - string Microsoft.VisualBasic.ControlChars.CrLf()
      // Created
      //   - CopyPaste � 20240118 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Created
      //   - CopyPaste � 20240118 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strName;
      string strPrompt;
      
      strPrompt = "Type the company name to be added in the " + strGroup;
      strName = Interaction.InputBox(strPrompt, "Input Box", "", 0, 0);
      strReturn = strName + ControlChars.CrLf;
    }
    // Add(string, �string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpAddName

}
// CopyPaste.Learning

