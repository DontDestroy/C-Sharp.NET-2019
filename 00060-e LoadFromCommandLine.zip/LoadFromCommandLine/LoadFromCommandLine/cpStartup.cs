//***
// Action
//   - 
// Created
//   - CopyPaste � 20220815 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220815 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;

namespace LoadFromCommandLine
{

  public class cpStartup
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private static void ApplicationStartup(System.Object theSender, System.Windows.StartupEventArgs theStartupEventArguments)
    //***
    // Action
    //   - There can be one argument given in the application
    //   - It is considered as 1 filepath
    //   - At that point, the main window has been defined but not shown yet
    //   - The command-line argument is set through the Visual Studio Project Properties (the Debug tab)
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220815 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220815 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (theStartupEventArguments.Args.Length > 0)
      {
        string strFile = theStartupEventArguments.Args[0];

        if (File.Exists(strFile))
        {
          FileViewer theStartupScreen = (FileViewer)Application.Current.MainWindow;
          theStartupScreen.LoadFile(strFile);
        }
        // File.Exists(strFile)

      }
      // theStartupEventArguments.Args.Length > 0

    }
    // ApplicationStartup(System.Object, System.Windows.StartupEventArgs)

    [STAThread()]
    static void Main()
    //***
    // Action
    //   - Create an instance of Application
    //   - Set a method to the Startup event of the Application
    //   - Run the application with the Startup screen
    // Called by
    //   - User action (Starting application)
    // Calls
    //   - ApplicationStartup(System.Object, System.Windows.StartupEventArgs)
    //   - FileViewer()
    // Created
    //   - CopyPaste � 20220815 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220815 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application theApplication = new Application(); // Create an instance of the application

      theApplication.Startup += ApplicationStartup; // Assign a method for the Startup event
      theApplication.Run(new FileViewer()); // Launch the application
    }
    // Main()


    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpStartup

}
// LoadFromCommandLine