//***
// Action
//   - A Domain Up Down control
// Created
//   - CopyPaste � 20240129 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240129 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmDomainUpDown: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdDone;
    internal System.Windows.Forms.DomainUpDown dudText;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDomainUpDown));
      this.cmdDone = new System.Windows.Forms.Button();
      this.dudText = new System.Windows.Forms.DomainUpDown();
      this.SuspendLayout();
      // 
      // cmdDone
      // 
      this.cmdDone.Location = new System.Drawing.Point(112, 71);
      this.cmdDone.Name = "cmdDone";
      this.cmdDone.TabIndex = 3;
      this.cmdDone.Text = "Done";
      this.cmdDone.Click += new System.EventHandler(this.cmdDone_Click);
      // 
      // dudText
      // 
      this.dudText.Location = new System.Drawing.Point(16, 23);
      this.dudText.Name = "dudText";
      this.dudText.TabIndex = 2;
      this.dudText.Text = "Select a State";
      // 
      // frmDomainUpDown
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(296, 117);
      this.Controls.Add(this.cmdDone);
      this.Controls.Add(this.dudText);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDomainUpDown";
      this.Text = "Domain Up Down";
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmDomainUpDown'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240129 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240129 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmDomainUpDown()
			//***
			// Action
			//   - Create instance of 'frmDomainUpDown'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240129 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240129 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();

      dudText.Items.Add("Alaska");
      dudText.Items.Add("Arizona");
      dudText.Items.Add("California");
      dudText.Items.Add("Colorado");
      dudText.Items.Add("Delaware");
      dudText.Items.Add("Florida");
      dudText.Items.Add("Georgia");
      dudText.Items.Add("");
		}
		// frmDomainUpDown()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"

    private void cmdDone_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Check if the user has selected a state
      //     - A state, nothing or an empty option can be selected
      //   - If nothing or empty option is chosen
      //     - Show error message
      //   - If not
      //     - Show selected state
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240129 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240129 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      
      if ((dudText.SelectedItem == null) || (dudText.SelectedItem.ToString() == ""))
      {
        MessageBox.Show("You must select a state");
      }
      else
        // Not dudText.SelectedItem = null And Not dudText.SelectedItem.ToString() = ""
      {
        MessageBox.Show("You choose: " + dudText.SelectedItem.ToString());
      }
      // dudText.SelectedItem = null Or dudText.SelectedItem.ToString() = "" 
    
    }
    // cmdDone_Click(System.Object, System.EventArgs) Handles cmdDone.Click

		#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmDomainUpDown
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmDefault()
			// Created
			//   - CopyPaste � 20240129 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240129 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmDomainUpDown());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmDomainUpDown

}
// CopyPaste.CopyPaste.Learning