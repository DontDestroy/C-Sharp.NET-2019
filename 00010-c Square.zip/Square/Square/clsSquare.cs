//***
// Action
//   - Example of calling function with parameter
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Square
{

  class cpSquare
	{

    static void Main()
    //***
    // Action
    //   - Show titles at console screen
    //   - Loop from 1 to 10 (lngCounter)
    //     - Show 'lngCounter' and square of 'lngCounter'
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - double Square(long)
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter;

      Console.WriteLine("Number\tSquare\n");

      for (lngCounter = 1; lngCounter <= 10; lngCounter++)
      {
        Console.WriteLine(lngCounter + "\t" + Square(lngCounter));
      }
      // lngCounter = 11
      Console.ReadLine();
    }
    // Main()

    static double Square(long lngValue)
    //***
    // Action
    //   - Calculate the power of 2 of the given number
    //   - Return it
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return lngValue * lngValue;
    }
    // double Square(long lngValue)

  }
  // cpSquare

}
// Square