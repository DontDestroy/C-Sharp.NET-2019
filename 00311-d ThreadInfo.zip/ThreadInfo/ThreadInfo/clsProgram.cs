//***
// Action
//   - Show information about threads
// Created
//   - CopyPaste � 20250709 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250709 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Threading;

namespace CopyPaste.Threading
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define a thread
      //   - Get the current thread
      //   - Show the ApartmentState, CurrentContext, CurrentCulture, CurrentPrincipal
      //   - Show the CurrentThread, CurrentUICulture, IsAlive, IsBackground
      //   - Show the IsThreadPoolThread, Name, Priority, ThreadState
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250709 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250709 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Thread theThread;

      theThread = Thread.CurrentThread;
      Console.WriteLine("Apartment State: {0}", theThread.ApartmentState);
      Console.WriteLine("Current Context: {0}", Thread.CurrentContext);
      Console.WriteLine("Current Culture: {0}", theThread.CurrentCulture);
      Console.WriteLine("Current Principal: {0}", Thread.CurrentPrincipal);
      Console.WriteLine("Current Thread: {0}", Thread.CurrentThread);
      Console.WriteLine("Current UI Culture: {0}", theThread.CurrentUICulture);
      Console.WriteLine("Is Alive: {0}", theThread.IsAlive);
      Console.WriteLine("Is Background: {0}", theThread.IsBackground);
      Console.WriteLine("Is Thread Pool Thread: {0}", theThread.IsThreadPoolThread);
      Console.WriteLine("Name: {0}", theThread.Name);
      Console.WriteLine("Priority: {0}", theThread.Priority);
      Console.WriteLine("Thread State: {0}", theThread.ThreadState);

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning