﻿//***
// Action
//   - Demo of Partitioning and Concatenation with Linq
//   - Keyword Take
//   - Keyword TakeWhile
//   - Keyword Skip
//   - Keyword SkipWhile
//   - Keyword Concat
// Created
//   - CopyPaste – 20230418 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230418 – VVDW
// Proposal (To Do)
//   -
//***

using AmericanHistory;
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace DeferredOperatorLinq
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Study the methods in order
    //   - Try to experiment, your own location to try things out
    //   - Take the first three of a list
    //   - Take while a condition is met
    //   - Skip the first thirty of a list
    //   - Skip while a condition is met
    //   - Concatenate two lists
    //   - Concatenate list with Select Many
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - PartitioningConcatenate()
    //   - PartitioningConcatenateWithSelectMany()
    //   - PartitioningSkipFirstThirty()
    //   - PartitioningSkipWhile()
    //   - PartitioningTakeFirstThree()
    //   - PartitioningTakeWhile()
    //   - TryToExperiment()
    // Created
    //   - CopyPaste – 20230418 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230418 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      TryToExperiment();
      // PartitioningTakeFirstThree();
      // PartitioningTakeWhile();
      // PartitioningSkipFirstThirty();
      // PartitioningSkipWhile();
      // PartitioningConcatenate();
      // PartitioningConcatenateWithSelectMany();
      Console.ReadLine();
    }
    // Main()

    public static void PartitioningConcatenate()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Partitioning operators return an output sequence of elements that are a subset of the input sequence
    //     - Sequence is of the form IEnumerable<T> or IOrderedEnumerable<T>
    //   - Concat has 1 overload
    //     - Concat the elements of a first collection with the elements of a second collection into a sequence
    //   - Fill the array with presidents
    //   - Select the presidents names before the sixth element (Lambda Linq Dot Notation)
    //   - Select the presidents names after the fourthies element (Lambda Linq Dot Notation)
    //   - Concatenate them
    //   - Show result 
    //   - Concat does not exist in Linq Fluent Syntax Query Expression
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)
    //   - string cpPresident.Name (Get)
    // Created
    //   - CopyPaste – 20230418 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230418 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpPresident> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();

      colResultLambda = cpPresident.AllPresidents.Take(5).Concat(cpPresident.AllPresidents.Skip(40));
      // Concat takes two input sequences, and returns an object that, when enumerated,
      // enumerates throught the input source sequence yielding the elements of both sequences (in this example cpPresident)
      // Concat is an extension method, so we use it on an instance of a sequence that is enumerable (AllPresidents)

      ShowContentOfPresidentSequence(colResultLambda, "The list of the American Presidents names before the sixth and after the fourthiest: (Lambda Linq Dot Notation)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // PartitioningConcatenate()

    public static void PartitioningConcatenateWithSelectMany()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Partitioning operators return an output sequence of elements that are a subset of the input sequence
    //     - Sequence is of the form IEnumerable<T> or IOrderedEnumerable<T>
    //   - Fill the array with presidents
    //   - Select the presidents names before the sixth element (Lambda Linq Dot Notation)
    //   - Select the presidents names after the fourthies element (Lambda Linq Dot Notation)
    //   - Concatenate them with SelectMany
    //   - Show result 
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)
    //   - string cpPresident.Name (Get)
    // Created
    //   - CopyPaste – 20230418 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230418 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpPresident> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();

      colResultLambda = new[] {cpPresident.AllPresidents.Take(5),
                               cpPresident.AllPresidents.Skip(40)}.SelectMany(aPresident => aPresident);

      ShowContentOfPresidentSequence(colResultLambda, "The list of the American Presidents names before the sixth and after the fourthiest: (Lambda Linq Dot Notation)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // PartitioningConcatenate()

    public static void PartitioningSkipFirstThirty()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Partitioning operators return an output sequence of elements that are a subset of the input sequence
    //     - Sequence is of the form IEnumerable<T> or IOrderedEnumerable<T>
    //   - Skip has 1 overload
    //     - Skip the first x elements of a collection into a sequence
    //   - Fill the array with presidents
    //   - Select the presidents names after the thirtiest element (Lambda Linq Dot Notation)
    //   - Show result 
    //   - Skip does not exist in Linq Fluent Syntax Query Expression (in VB .NET is exists)
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)
    //   - string cpPresident.Name (Get)
    // Created
    //   - CopyPaste – 20230418 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230418 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpPresident> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();

      colResultLambda = cpPresident.AllPresidents.Skip(30);
      // Skip takes an input sequence and a counter, and returns an object that, when enumerated,
      // enumerates throught the input source sequence yielding the elements after the counter (in this example cpPresident)
      // Skip is an extension method, so we use it on an instance of a sequence that is enumerable (AllPresidents)

      ShowContentOfPresidentSequence(colResultLambda, "The list of the American Presidents names after the thirtiest: (Lambda Linq Dot Notation)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // PartitioningSkipFirstThirty()

    public static void PartitioningSkipWhile()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Partitioning operators return an output sequence of elements that are a subset of the input sequence
    //     - Sequence is of the form IEnumerable<T> or IOrderedEnumerable<T>
    //   - SkipWhile has 2 overloads
    //     - Take the elements of a collection into a sequence after a predicate is false
    //     - Take the elements of a collection into a sequence after a predicate is false or when an index is reached
    //   - Fill the array with presidents
    //   - Select the presidents names with a name smaller than 18 (Lambda Linq Dot Notation)
    //   - Show result 
    //   - SkipWhile does not exist in Linq Fluent Syntax Query Expression (in VB .NET is exists)
    //   - Select the first presidents names with a name smaller than 18 and an index smaller than 6 (Lambda Linq Dot Notation)
    //   - Show result 
    //   - SkipWhile does not exist in Linq Fluent Syntax Query Expression (in VB .NET is exists)
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)
    //   - string cpPresident.Name (Get)
    // Created
    //   - CopyPaste – 20230418 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230418 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpPresident> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();

      colResultLambda = cpPresident.AllPresidents.SkipWhile(aPresident => aPresident.Name.Length < 18);
      // SkipWhile takes an input sequence and a predicate delegate, and returns an object that, when enumerated,
      // enumerates throught the input source sequence yielding elements from which the predicate delegates returns False
      // The enumeration starts at the first False
      // SkipWhile is an extension method, so we use it on an instance of a sequence that is enumerable (AllPresidents)

      ShowContentOfPresidentSequence(colResultLambda, "The list of the American Presidents names from the name that is longer than 17 characters: (Lambda Linq Dot Notation)");

      colResultLambda = cpPresident.AllPresidents.SkipWhile((aPresident, intIndex) => aPresident.Name.Length < 18 && intIndex < 6);
      // SkipWhile takes an input sequence, an index and a predicate delegate, and returns an object that, when enumerated,
      // enumerates throught the input source sequence yielding elements from which the predicate delegates returns False
      // The enumeration starts at the first False, or the index is reached
      // SkipWhile is an extension method, so we use it on an instance of a sequence that is enumerable (AllPresidents)

      Console.WriteLine();
      ShowContentOfPresidentSequence(colResultLambda, "The list of the American Presidents names till the name is longer than 17 characters and index is smaller than 6: (Lambda Linq Dot Notation)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // PartitioningTakeWhile()

    public static void PartitioningTakeFirstThree()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Partitioning operators return an output sequence of elements that are a subset of the input sequence
    //     - Sequence is of the form IEnumerable<T> or IOrderedEnumerable<T>
    //   - Take has 1 overload
    //     - Take the first x elements of a collection into a sequence
    //   - Fill the array with presidents
    //   - Select the first 3 presidents names (Lambda Linq Dot Notation)
    //   - Show result 
    //   - Take does not exist in Linq Fluent Syntax Query Expression (in VB .NET is exists)
    //   - Select the first 3 presidents names and show the characters of the name (Lambda Linq Dot Notation)
    //   - Show result 
    //   - Take does not exist in Linq Fluent Syntax Query Expression (in VB .NET is exists)
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)
    //   - ShowContentOfSequence<T>(IEnumerable<T>, string)
    //   - string cpPresident.Name (Get)
    // Created
    //   - CopyPaste – 20230418 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230418 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpPresident> colResultLambda;
      IEnumerable<char> colchrResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();

      colResultLambda = cpPresident.AllPresidents.Take(3);
      // Take takes an input sequence and a counter, and returns an object that, when enumerated,
      // enumerates throught the input source sequence yielding the first counter elements (in this example cpPresident)
      // Take is an extension method, so we use it on an instance of a sequence that is enumerable (AllPresidents)

      ShowContentOfPresidentSequence(colResultLambda, "The list of the first three American Presidents names: (Lambda Linq Dot Notation)");

      colchrResultLambda = cpPresident.AllPresidents.Take(3).SelectMany(aPresident => aPresident.Name.ToArray());

      Console.WriteLine();
      ShowContentOfSequence(colchrResultLambda, "The list of the characters of the first three American Presidents names: (Lambda Linq Dot Notation)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // PartitioningTakeFirstThree()

    public static void PartitioningTakeWhile()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Partitioning operators return an output sequence of elements that are a subset of the input sequence
    //     - Sequence is of the form IEnumerable<T> or IOrderedEnumerable<T>
    //   - Take has 2 overloads
    //     - Take the first elements of a collection into a sequence till a predicate is false
    //     - Take the first elements of a collection into a sequence till a predicate is false or an index is reached
    //   - Fill the array with presidents
    //   - Select the first presidents names with a name smaller than 18 (Lambda Linq Dot Notation)
    //   - Show result 
    //   - TakeWhile does not exist in Linq Fluent Syntax Query Expression (in VB .NET is exists)
    //   - Select the first presidents names with a name smaller than 18 and an index smaller than 6 (Lambda Linq Dot Notation)
    //   - Show result 
    //   - TakeWhile does not exist in Linq Fluent Syntax Query Expression (in VB .NET is exists)
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)
    //   - string cpPresident.Name (Get)
    // Created
    //   - CopyPaste – 20230418 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230418 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpPresident> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();

      colResultLambda = cpPresident.AllPresidents.TakeWhile(aPresident => aPresident.Name.Length < 18);
      // TakeWhile takes an input sequence and a predicate delegate, and returns an object that, when enumerated,
      // enumerates throught the input source sequence yielding elements for which the predicate delegates returns True
      // The enumeration stops at the first False
      // TakeWhile is an extension method, so we use it on an instance of a sequence that is enumerable (AllPresidents)

      ShowContentOfPresidentSequence(colResultLambda, "The list of the American Presidents names till the name is longer than 17 characters: (Lambda Linq Dot Notation)");

      colResultLambda = cpPresident.AllPresidents.TakeWhile((aPresident, intIndex) => aPresident.Name.Length < 18 && intIndex < 5);
      // TakeWhile takes an input sequence, an index and a predicate delegate, and returns an object that, when enumerated,
      // enumerates throught the input source sequence yielding elements for which the predicate delegates returns True
      // The enumeration stops at the first False, or the index is reached
      // TakeWhile is an extension method, so we use it on an instance of a sequence that is enumerable (AllPresidents)

      Console.WriteLine();
      ShowContentOfPresidentSequence(colResultLambda, "The list of the American Presidents names till the name is longer than 17 characters or index is bigger than 5: (Lambda Linq Dot Notation)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // PartitioningTakeWhile()

    private static void ShowContentOfPresidentSequence(IEnumerable<cpPresident> colSequence, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type cpPresident in a sequence
    // Called by
    //   - PartitioningConcatenate()
    //   - PartitioningConcatenateWithSelectMany()
    //   - PartitioningTakeFirstThree()
    //   - PartitioningTakeWhile()
    //   - PartitioningSkipFirstThirty()
    //   - PartitioningSkipWhile()
    // Calls
    //   - string cpPresident.Name() (Get)
    // Created
    //   - CopyPaste – 20230418 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230418 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine(strTitle);

      foreach (cpPresident aPresident in colSequence)
      {
        Console.WriteLine(aPresident.Name);
      }
      // in colSequence

    }
    // ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)

    private static void ShowContentOfSequence<T>(IEnumerable<T> colSequence, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type T in a sequence
    // Called by
    //   - PartitioningTakeFirstThree()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230418 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230418 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine(strTitle);

      foreach (T anElement in colSequence)
      {
        Console.WriteLine(anElement);
      }
      // in colSequence

    }
    // ShowContentOfSequence<T>(IEnumerable<T>, string)

    public static void TryToExperiment()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Method used for experimenting
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230418 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230418 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      //  Do your stuff here

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // TryToExperiment()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion  

  }
  // cpProgram

}
// DeferredOperatorLinq