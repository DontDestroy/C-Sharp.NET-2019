﻿//***
// Action
//   - Implementation of a cpSuv
// Created
//   - CopyPaste – 20260128 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260128 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpSuv : cpRoadVehicle, cpiCompareVehicle<cpSuv>, cpiAutomaticDifferential
  {

    #region "Constructors / Destructors"

    public cpSuv(): base()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - AutomaticDifferential(bool) (Set)
    //   - cpRoadVehicle()
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      AutomaticDifferential = false;
    }
    // cpSuv()

    public cpSuv(string strVehicleIdentificationNumber, uint intWheelCount, uint intMaximumSpeedForward, uint intMaximumSpeedBackward, bool blnAutomaticDifferential) : base(strVehicleIdentificationNumber, intWheelCount, intMaximumSpeedForward, intMaximumSpeedBackward)
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - 
    // Calls
    //   - AutomaticDifferential(bool) (Set)
    //   - cpRoadVehicle(string, uint, uint, uint)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      AutomaticDifferential = blnAutomaticDifferential;
    }
    // cpSuv(string, uint, uint, uint, bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    protected bool _automaticDifferential;

    #endregion

    #region "Properties"

    public bool AutomaticDifferential
    {

      get
      //***
      // Action Get
      //   - Return _automaticDifferential
      // Called by
      //   - cpProgram.Main()
      //   - string ToString()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        return _automaticDifferential;
      }
      // bool AutomaticDifferential (Get)

      set
      //***
      // Action Set
      //   - _automaticDifferential becomes value
      // Called by
      //   - cpProgram.Main()
      //   - cpSuv()
      //   - cpSuv(string, uint, uint, uint, bool)
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        _automaticDifferential = value;
      }
      // AutomaticDifferential(bool) (Set)

    }
    // bool AutomaticDifferential 

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
    //***
    // Action
    //   - Visualization of a cpSuv
    // Called by
    //   - cpProgram.Main() (thru inheritance and polymorphism)
    // Calls
    //   - bool AutomaticDifferential (Get) (thru inheritance)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strMessage;

      strMessage = base.ToString() +
                   $"Automatic differential : {AutomaticDifferential}\n";

      return strMessage;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public bool VehicleIdentificationNumberCheck(cpSuv theVehicle)
    //***
    // Action
    //   - Check the Vehicle Identification Numbers of two vehicles
    //   - If equal
    //     - Return true
    //   - If not
    //     - Return false 
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - string VehicleIdentificationNumber (Get)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return VehicleIdentificationNumber.Equals(theVehicle.VehicleIdentificationNumber);
    }
    // VehicleIdentificationNumberCheck(cpSuv)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCar

}
// CopyPaste.Learning