//***
// Action
//   - Control pattern editor for bitmapts
//     - Event save must be triggered, but is implemented where it is used
// Created
//   - CopyPaste � 20240330 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240330 � VVDW
// Proposal (To Do)
//   -
//***

using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpctlBitmapPatternEditor : cpctlPatternEditor
  {

    #region Component Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      this.dlgFileOpen = new System.Windows.Forms.OpenFileDialog();
      this.cmdSave = new System.Windows.Forms.Button();
      this.cmdBrowse = new System.Windows.Forms.Button();
      this.picBox = new System.Windows.Forms.PictureBox();
      this.SuspendLayout();
      // 
      // cmdSave
      // 
      this.cmdSave.Location = new System.Drawing.Point(94, 88);
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.TabIndex = 5;
      this.cmdSave.Text = "&Save";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // cmdBrowse
      // 
      this.cmdBrowse.Location = new System.Drawing.Point(6, 88);
      this.cmdBrowse.Name = "cmdBrowse";
      this.cmdBrowse.TabIndex = 4;
      this.cmdBrowse.Text = "&Browse";
      this.cmdBrowse.Click += new System.EventHandler(this.cmdBrowse_Click);
      // 
      // picBox
      // 
      this.picBox.Location = new System.Drawing.Point(6, 8);
      this.picBox.Name = "picBox";
      this.picBox.Size = new System.Drawing.Size(61, 61);
      this.picBox.TabIndex = 3;
      this.picBox.TabStop = false;
      // 
      // cpctlBitmapPatternEditor
      // 
      this.Controls.Add(this.cmdBrowse);
      this.Controls.Add(this.picBox);
      this.Controls.Add(this.cmdSave);
      this.Name = "cpctlBitmapPatternEditor";
      this.Size = new System.Drawing.Size(175, 150);
      this.ResumeLayout(false);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpctlDrawnPatternEditor'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpctlBitmapPatternEditor(cpBitmapPattern thePattern) : base()
      //***
      // Action
      //   - Create new instance of 'cpctlBitmapPatternEditor', a cpBitmapPattern is given
      //   - Redefine the path of the bitmap
      //   - A draw method is assigned as handler for the paint action in the picBox
      //   - cpBitmpaPattern is assigned to the variable of the class
      // Called by
      //   - cpBitmapPattern.cpGetEditor() As cpctlPatternEditor
      //   - cpctlPatternEditor.New(cpBitmapPattern)
      //   - User action (Starting the control)
      // Calls
      //   - cpDrawnPattern.Points() (Get)
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();

      mstrBitmapFile = thePattern.BitmapFile;
      this.picBox.Paint += new PaintEventHandler(this.cpDraw);
      mcpPattern = thePattern;
    }
    // cpctlDrawnPatternEditor()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpBitmapPattern mcpPattern;
    public override event cpSavedEventHandler cpSaved;
    internal System.Windows.Forms.OpenFileDialog dlgFileOpen;
    internal System.Windows.Forms.Button cmdSave;
    internal System.Windows.Forms.Button cmdBrowse;
    internal System.Windows.Forms.PictureBox picBox;
    private string mstrBitmapFile;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdBrowse_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Get a file open screen to select a new bitmap
      //   - When a file is choosen
      //     - The path of the filename is saved
      //     - Picture box is refreshed
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      dlgFileOpen.ShowDialog();

      if (dlgFileOpen.FileName.Length == 0)
      {
      }
      else
        // dlgFileOpen.FileName.Length <> 0
      {
        mstrBitmapFile = dlgFileOpen.FileName;
        picBox.Refresh();
      }
      // dlgFileOpen.FileName.Length = 0
    
    }
    // cmdBrowse_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdBrowse.Click
  
    private void cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The array of points is saved into the pattern
      //   - Trigger the save event
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpBitmapPattern.BitmapFile() As String (Get)
      //   - cpctlPatternEditor.cpRaiseSaved(System.Object, System.EventArgs)
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpPattern.BitmapFile = mstrBitmapFile;

      if (this.cpSaved == null)
      {
      }
      else
        // this.cpSaved <> null
      {
        this.cpSaved(this, new System.EventArgs());
      }
      // this.cpSaved = null

    }
    // cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdSave.Click

    #endregion

    #region "Functionality"

    #region "Event"

    public void cpDraw(System.Object theSender, System.Windows.Forms.PaintEventArgs thePaintEventArguments)
      //***
      // Action
      //   - The image is drawn
      // Called by
      //   - cpctlPatternEditor.cpRaiseSaved(System.Object, System.EventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      thePaintEventArguments.Graphics.DrawImage(new Bitmap(mstrBitmapFile), 0, 0);
    }
    // cpDraw(System.Object, System.Windows.Forms.PaintEventArgs)

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpctlBitmapPatternEditor

}
// CopyPaste.Learning