﻿//***
// Action
//   - Definition of a cpSphere
// Created
//   - CopyPaste – 20251218 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251218 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpSphere
  {

    #region "Constructors / Destructors"

    public cpSphere(double dblRadius)
    //***
    // Action
    //   - Basic constructor of cpSphere with radius parameter
    // Called by
    //   - cpProgram().Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251218 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251218 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Radius = dblRadius;
    }
    // cpSphere()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public double Radius { get; private set; }
    // cpLocalFunction().CalculateObjectVolume(System.Object)

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpSphere

}
// CopyPaste.Learning