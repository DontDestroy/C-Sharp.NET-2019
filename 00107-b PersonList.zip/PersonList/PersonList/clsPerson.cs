//***
// Action
//   - Definition of cpPerson
// Created
//   - CopyPaste � 20230821 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230821 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpPerson
  {

    #region "Constructors / Destructors"

    public cpPerson(string strFirstLast)
    //***
    // Action
    //   - Constructor of cpPerson with a text as parameter
    //   - The text is the first and last name together
    //   - We try to split this on the first element of "strSprlitCharacters" that is found
    //   - On whatever error we encounter, we show an error message
    // Called by
    //   - 
    // Calls
    //   - cpNameFormatIncorrectException(string)
    //   - FirstName(string) (Set)
    //   - LastName(string) (Set)
    //   - string LastName() (Get)
    // Created
    //   - CopyPaste � 20230821 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230821 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      try
      {
        int lngCounter;
        string strSplitCharacters = " ";
        string[] arrstrNames = strFirstLast.Split(strSplitCharacters.ToCharArray());

        FirstName = arrstrNames[0];

        for (lngCounter = 1; lngCounter < arrstrNames.Length; lngCounter++)
        {
          LastName = LastName + arrstrNames[lngCounter] + " ";
        }
        // lngCounter = arrstrNames.Length

        LastName = LastName.Trim();
      }

      catch (Exception theException)
      {
        throw new cpNameFormatIncorrectException("Cannot find the first name and last name in the string:" + strFirstLast, theException);
      }

    }
    // cpPerson(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrFirst;
    private string mstrLast;

    #endregion

    #region "Properties"

    public string FirstName
    {

      get
      //***
      // Action Get
      //   - Return the first name of cpPerson
      // Called by
      //   - string ToString()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230821 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230821 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return mstrFirst;
      }
      // string FirstName (Get)

      set
      //***
      // Action Set
      //   - The first name of cpPerson becomes value
      // Called by
      //   - cpPerson(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230821 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230821 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        mstrFirst = value;
      }
      // FirstName(string) (Set)

    }
    // string FirstName

    public string LastName
    {

      get
      //***
      // Action Get
      //   - Return the last name of cpPerson
      // Called by
      //   - cpPerson(string)
      //   - string ToString()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230821 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230821 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return mstrLast;
      }
      // string LastName (Get)

      set
      //***
      // Action Set
      //   - The last name of cpPerson becomes value
      // Called by
      //   - cpPerson(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230821 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230821 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        mstrLast = value;
      }
      // LastName(string) (Set)

    }
    // string LastName

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
    //***
    // Action
    //   - Show the lastname and firstname with a comma in between
    // Called by
    //   - New(String)
    // Calls
    //   - string FirstName (Get)
    //   - string LastName (Get)
    // Created
    //   - CopyPaste � 20230821 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230821 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return LastName + ", " + FirstName;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPerson

}
// CopyPaste.Learning