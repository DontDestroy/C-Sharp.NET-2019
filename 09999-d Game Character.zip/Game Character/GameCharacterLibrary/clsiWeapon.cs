﻿//***
// Action
//   - Interface for the behaviour (method) Fight
// Created
//   - CopyPaste – 20240806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240806 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Game.Weapon.Library
{

	public interface cpiWeapon
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing can used in a fight
		/// </summary>
		public void UseWeapon();
		// UseWeapon()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpiWeapon

}
// CopyPaste.Game.Weapon.Library