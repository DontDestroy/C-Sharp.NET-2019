﻿//***
// Action
//   - Definition of a cpCacheBetter
// Created
//   - CopyPaste – 20260617 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260617 – VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.Extensions.Caching.Memory;
using System;
// using System.Runtime.Caching;

namespace CopyPaste.Learning
{

  public class cpCacheBetter
  {

    #region "Constructors / Destructors"

    public cpCacheBetter()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   -
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260617 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260617 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpCacheBetter()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static readonly MemoryCache memcCache = new MemoryCache(new MemoryCacheOptions { SizeLimit = 1024 });

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Add(string strKey, string strValue)
    //***
    // Action
    //   - Adding an element to a dictionary with the key strKey and the value strValue with a Timespan of 5 minutes
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260617 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260617 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - This is never cleared of trimmed, so it is a memory sink
    //***
    {
      memcCache.Set(strKey, strValue,
        new MemoryCacheEntryOptions
        {
          Size = 1,
          SlidingExpiration = TimeSpan.FromMinutes(5)
        });
    }
    // Add(string, string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpWorker

}
// CopyPaste.Learning