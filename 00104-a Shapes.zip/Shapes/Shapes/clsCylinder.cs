//***
// Action
//   - Definition of a cpCylinder
// Created
//   - CopyPaste � 20230811 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230811 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpCylinder : cpCircle
  {

    #region "Constructors / Destructors"

    public cpCylinder() : base()
      //***
      // Action
      //   - Constructor of a cpCyclinder
      //   - The base of a cpCylinder is a cpCylinder with heigth 0 (and that is a cpCircle)
      //   - A cpCylinder is a cpCircle, that is the reason it works
      // Called by
      //   - 
      // Calls
      //   - Base(cpCircle) (Set)
      //   - cpCircle()
      //   - Height(double) (Set)
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Base = this;
      Height = 0;
    }
    // cpCylinder()

    public cpCylinder(int lngX, int lngY, double dblRadius, double dblHeight) : base(lngX, lngY, dblRadius)
      //***
      // Action
      //   - Constructor of a cpCircle using 2 coordinates and a radius
      //   - The base of a cylinder is a cpCylinder (and that is a cpCircle)
      //   - A cpCyclinder is a cpCircle, that is the reason it works
      //   - The height becomes dblHeight
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - Base(cpCircle) (Set)
      //   - cpCircle(int, int, double)
      //   - Height(double) (Set)
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Base = this;
      Height = dblHeight;
    }
    // cpCylinder(int, int, double, double)

    public cpCylinder(cpPoint thecpPoint, double dblRadius, double dblHeight) : base(thecpPoint, dblRadius)
      //***
      // Action
      //   - Constructor of a cpCylinder using a cpCircle and a height
      //   - The base of a cylinder is a here a cpPoint and a radius
      //   - The height becomes dblHeight
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - Base(cpCircle) (Set)
      //   - cpCircle(cpPoint, double)
      //   - Height(double) (Set)
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Base = this;
      Height = dblHeight;
    }
    // cpCylinder(cpPoint, double, double)

    public cpCylinder(cpCircle thecpCircle, double dblHeight)
      //***
      // Action
      //   - Constructor of a cpCylinder using a cpCircle and a height
      //   - The base of a cylinder is a here a cpCircle, not a cpCyclinder like in the other constructors
      //   - The height becomes dblHeight
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - Base(cpCircle) (Set)
      //   - Height(double) (Set)
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Base = thecpCircle;
      Height = dblHeight;
    }
    // cpCylinder(cpCircle , double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private double mdblHeight;
    private cpCircle mcpBase;

    #endregion

    #region "Properties"

    public cpCircle Base
    {

      get
        //***
        // Action Get
        //   - Returns mcpBase
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230811 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230811 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mcpBase;
      }
      // cpCircle Base (Get)

      set
        //***
        // Action Set
        //   - The base becomes the circle (cpValue)
        //   - Coordinate X becomes the X of the center of the circle
        //   - Coordinate Y becomes the Y of the center of the circle
        //   - The radius becomes the radius of the circle
        // Called by
        //   - cpCylinder()
        //   - cpCylinder(cpCircle, double)
        //   - cpCylinder(cpPoint, double, double)
        //   - cpCylinder(int, int, double, double)
        // Calls
        //   - cpCylinder.Radius(double) (Set)
        //   - cpPoint.X(int) (Set)
        //   - cpPoint.Y(int) (Set)
        //   - double cpCylinder.Radius() (Get)
        //   - int cpPoint.X (Get)
        //   - int cpPoint.Y (Get)
        // Created
        //   - CopyPaste � 20230811 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230811 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mcpBase = value;
        X = value.X;
        Y = value.Y;
        Radius = value.Radius;
      }
      // Base(cpCircle) (Set)

    }
    // cpCircle Base

    public double Height
    {

      get
        //***
        // Action Get
        //   - Returns mdblHeight
        // Called by
        //   - double Area()
        //   - double Volume()
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230811 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230811 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdblHeight;
      }
      // double Height (Get)
      
      set
        //***
        // Action Set
        //   - If dblValue is larger or equal than 0
        //     - mdblHeight becomes dblValue
        //   - If Not
        //     - mdblHeight becomes 0
        // Called by
        //   - cpCylinder()
        //   - cpCylinder(cpCircle, double)
        //   - cpCylinder(cpPoint, double, double)
        //   - cpCylinder(int, int, double, double)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230811 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230811 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value >= 0)
        {
          mdblHeight = value;
        }
        else
          // value < 0
        {
          mdblHeight = 0;
        }
        // value >= 0

      }
      // Height(double) (Set)

    }
    // double Height

    public override string Name
    {
    
      get
        //***
        // Action Get
        //   - Returns text "cpCylinder"
        // Called by
        //   - modShapesTest.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230811 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230811 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return "cpCylinder";
      }
      // string Name

    }
    // string Name

    #endregion

    #region "Methods"

    #region "Overrides"

    public override double Area()
      //***
      // Action
      //   - Calculates the area of a cpCylinder
      // Called by
      //   - 
      // Calls
      //   - double cpCircle.Area()
      //   - double cpCircle.Circumference()
      //   - double Height (Get)
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return 2 * base.Area() + base.Circumference() * Height;
    }
    // double Area()

    public override string ToString()
      //***
      // Action
      //   - Shows information of a cpCylinder
      // Called by
      //   - modShapesTest.Main()
      // Calls
      //   - double Height (Get)
      //   - string cpCircle.ToString()
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return base.ToString() + "; Height = " + Height;
    }
    // string ToString()

    public override double Volume()
      //***
      // Action
      //   - Calculates the volume of a cpCylinder
      // Called by
      //   - 
      // Calls
      //   - double cpCircle.Area()
      //   - double Height (Get)
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return base.Area() * Height;
    }
    // double Volume()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"

    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCylinder

}
// CopyPaste.Learning