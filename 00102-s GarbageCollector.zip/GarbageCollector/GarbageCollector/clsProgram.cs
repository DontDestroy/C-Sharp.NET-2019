//***
// Action
//   - Testroutine for cpEmployee
// Created
//   - CopyPaste � 20230802 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230802 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;

namespace GarbageCollector
{

  class cpProgram
	{
    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Create 3 instances of cpEmployee
    //   - Stop the application
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - ~cpEmployee.Finalize()
    //   - cpEmployee(string, string)
    // Created
    //   - CopyPaste � 20230802 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230802 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpEmployee theBoss = new cpEmployee("Jones", "Bill@SomeCompany.com");
      cpEmployee theWorker = new cpEmployee("Smith", "Debbie@SomeCompany.com");
      cpEmployee theManager = new cpEmployee("Davis", "Janet@SomeCompany.com");

      // GC.SuppressFinalize(theManager);
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// GarbageCollector