﻿//***
// Action
//   - The class cpWarning
//   - Will be used to create a table in a SQL Server database
//   - The primary key is by default setting in Entity FrameWork Core the <classname>Id notification
//     - This is not according to Copy Paste naming conventions (it should be intIdWarning)
//   - For demoing the migrations
//     - A class cpPerson will be added (also here there is a mismatch between the naming conventions)
//     - A link between cpWarning and cpPerson will be added (also here there is a mismatch between the naming conventions)
// Created
//   - CopyPaste – 20230406 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230406 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace PersonWarnings
{

  public class cpWarning
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public int cpWarningId { get; set; }
    public string strName { get; set; }
    public string strDescription { get; set; }

    // Both statements below are added after the first migration
    // public int? cpPersonId { get; set; }
    // public cpPerson Person { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpWarning

}
// PersonWarnings