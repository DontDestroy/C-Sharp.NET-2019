//***
// Action
//   - Creating a math quiz
//   - This is a form as startpoint of the exercise
// Created
//   - CopyPaste � 20210830 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210830 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;

namespace MathQuiz
{

  public class frmMathQuiz : System.Windows.Forms.Form
	{

    #region Windows Form Designer generated code

    internal System.Windows.Forms.Label lblTitle;
    internal System.Windows.Forms.TextBox txtResult;
    internal System.Windows.Forms.Label lblNumber02;
    internal System.Windows.Forms.Button cmdQuit;
    internal System.Windows.Forms.Button cmdAnswer;
    internal System.Windows.Forms.Label lblNumber01;
    internal System.Windows.Forms.Label lblEqual;
    internal System.Windows.Forms.Label lblOperator;
    private System.ComponentModel.Container components = null;
    
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMathQuiz));
      this.lblTitle = new System.Windows.Forms.Label();
      this.txtResult = new System.Windows.Forms.TextBox();
      this.lblNumber02 = new System.Windows.Forms.Label();
      this.cmdQuit = new System.Windows.Forms.Button();
      this.cmdAnswer = new System.Windows.Forms.Button();
      this.lblNumber01 = new System.Windows.Forms.Label();
      this.lblEqual = new System.Windows.Forms.Label();
      this.lblOperator = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // lblTitle
      // 
      this.lblTitle.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblTitle.ForeColor = System.Drawing.Color.Navy;
      this.lblTitle.Location = new System.Drawing.Point(7, 8);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(370, 35);
      this.lblTitle.TabIndex = 8;
      this.lblTitle.Text = "Math Quiz";
      this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // txtResult
      // 
      this.txtResult.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.txtResult.Location = new System.Drawing.Point(282, 96);
      this.txtResult.Name = "txtResult";
      this.txtResult.Size = new System.Drawing.Size(90, 35);
      this.txtResult.TabIndex = 13;
      this.txtResult.Text = "";
      this.txtResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
      // 
      // lblNumber02
      // 
      this.lblNumber02.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblNumber02.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblNumber02.Location = new System.Drawing.Point(147, 96);
      this.lblNumber02.Name = "lblNumber02";
      this.lblNumber02.Size = new System.Drawing.Size(90, 35);
      this.lblNumber02.TabIndex = 11;
      this.lblNumber02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cmdQuit
      // 
      this.cmdQuit.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmdQuit.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(0)), ((System.Byte)(192)));
      this.cmdQuit.Location = new System.Drawing.Point(232, 208);
      this.cmdQuit.Name = "cmdQuit";
      this.cmdQuit.Size = new System.Drawing.Size(96, 35);
      this.cmdQuit.TabIndex = 15;
      this.cmdQuit.Text = "Quit";
      this.cmdQuit.Click += new System.EventHandler(this.cmdQuit_Click);
      // 
      // cmdAnswer
      // 
      this.cmdAnswer.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmdAnswer.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(0)), ((System.Byte)(0)), ((System.Byte)(192)));
      this.cmdAnswer.Location = new System.Drawing.Point(57, 208);
      this.cmdAnswer.Name = "cmdAnswer";
      this.cmdAnswer.Size = new System.Drawing.Size(96, 35);
      this.cmdAnswer.TabIndex = 14;
      this.cmdAnswer.Text = "Answer";
      this.cmdAnswer.Click += new System.EventHandler(this.cmdAnswer_Click);
      // 
      // lblNumber01
      // 
      this.lblNumber01.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblNumber01.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblNumber01.Location = new System.Drawing.Point(12, 96);
      this.lblNumber01.Name = "lblNumber01";
      this.lblNumber01.Size = new System.Drawing.Size(90, 35);
      this.lblNumber01.TabIndex = 9;
      this.lblNumber01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblEqual
      // 
      this.lblEqual.AutoSize = true;
      this.lblEqual.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblEqual.Location = new System.Drawing.Point(247, 104);
      this.lblEqual.Name = "lblEqual";
      this.lblEqual.Size = new System.Drawing.Size(23, 31);
      this.lblEqual.TabIndex = 12;
      this.lblEqual.Text = "=";
      // 
      // lblOperator
      // 
      this.lblOperator.AutoSize = true;
      this.lblOperator.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblOperator.Location = new System.Drawing.Point(112, 96);
      this.lblOperator.Name = "lblOperator";
      this.lblOperator.Size = new System.Drawing.Size(23, 31);
      this.lblOperator.TabIndex = 10;
      this.lblOperator.Text = "+";
      this.lblOperator.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // frmMathQuiz
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(385, 296);
      this.Controls.Add(this.lblTitle);
      this.Controls.Add(this.txtResult);
      this.Controls.Add(this.lblNumber02);
      this.Controls.Add(this.cmdQuit);
      this.Controls.Add(this.cmdAnswer);
      this.Controls.Add(this.lblNumber01);
      this.Controls.Add(this.lblEqual);
      this.Controls.Add(this.lblOperator);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMathQuiz";
      this.Text = "Math Quiz";
      this.Load += new System.EventHandler(this.frmMathQuiz_Load);
      this.ResumeLayout(false);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose( bool disposing )
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210830 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210830 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if ( disposing )
      {
        if (components == null) 
        {
        }
        else
          // (components != null) 
        {
          components.Dispose();
        }
        // (components == null) 

      }
      else
        // Not ( disposing )
      {
      }
      // ( disposing )

      base.Dispose( disposing );
    }
    // Dispose( bool )
  
    public frmMathQuiz()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210830 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210830 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmMathQuiz()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    static int mintAnswer;
    static Random mrndRandom = new Random(DateTime.Now.Millisecond);
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAnswer_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try
    //     - If mintAnswer equals txtResult (converted to integer)
    //       - Show message "You got the answer right!".
    //     - If Not
    //       - Show message "Oh no, you missed that one!".
    //   - On Error
    //     - Show message "Please enter a number."
    //   - Create a new math problem
    //   - Clear txtResult
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - CreateMathProblem()
    // Created
    //   - CopyPaste � 20210830 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210830 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      try
      {

        if (mintAnswer == int.Parse(txtResult.Text))
        {
          MessageBox.Show("You got the answer right!", "Correct");
        }
        else
          // (mintAnswer <> int.Parse(txtResult.Text)
        {
          MessageBox.Show("Oh no, you missed that one!", "Wrong");
        }
        // (mintAnswer == int.Parse(txtResult.Text)

      }
      catch (Exception theException)
      {
        MessageBox.Show("Please enter a number.");
      }

      CreateMathProblem();
      txtResult.Text = "";
    }
    // cmdAnswer_Click(System.Object, System.EventArgs)

    private void cmdQuit_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - End application
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210830 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210830 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //   - Alternative: Application.Exit();
    //     - Is this better?
    //***
    {
      this.Close();
    }
    // cmdQuit_Click(System.Object, System.EventArgs)

    private void frmMathQuiz_Load(System.Object theSender, System.EventArgs theEventArguments)
    //'***
    //' Action
    //'   - Create a new math problem
    //' Called by
    //'   - User action (loading the form)
    //' Calls
    //'   - CreateMathProblem()
    //' Created
    //'   - CopyPaste � 20210830 � VVDW
    //' Changed
    //'   - Organisation � yyyymmdd � Initials of programmer � What changed
    //' Tested
    //'   - CopyPaste � 20210830 � VVDW
    //' Keyboard key
    //'   - 
    //' Proposal (To Do)
    //'   - List of actions that can be added to the functionality
    //'***
    {
      CreateMathProblem();
    }
    // frmMathQuiz_Load(System.Object theSender, System.EventArgs theEventArguments)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void CreateMathProblem()
    //***
    // Action
    //   - Define a random first number (intFirst)
    //   - Define a random second number (intSecond)
    //   - Define a random operator
    //     - When 0
    //       - Correct answer is intFirst + intSecond
    //     - When 1
    //       - Correct answer is intFirst - intSecond
    //     - When 2
    //       - Correct answer is intFirst * intSecond
    // Called by
    //   - cmdAnswer_Click(System.Object, System.EventArgs) Handles cmdAnswer.Click
    //   - frmMathQuiz_Load(System.Object, System.EventArgs) Handles frmMathQuiz.Load
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210830 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210830 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int intFirst;
      int intSecond;

      intFirst = mrndRandom.Next(11);
      lblNumber01.Text = intFirst.ToString();
      intSecond = mrndRandom.Next(11);
      lblNumber02.Text = intSecond.ToString();

      switch (mrndRandom.Next(3))
      {
        case 0:
          lblOperator.Text = "+";
          mintAnswer = intFirst + intSecond;
          break;
        case 1:
          lblOperator.Text = "-";
          mintAnswer = intFirst - intSecond;
          break;
        case 2:
          lblOperator.Text = "*";
          mintAnswer = intFirst * intSecond;
          break;
        default:
          // Not 0, 1, 2
          break;
      }
      // mrndRandom.Next(3)
    }
    // CreateMathProblem()

    static void Main()
    // Action
    //   - Start of the application
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmMathQuiz()
    // Created
    //   - CopyPaste � 20210830 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210830 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmMathQuiz());
    }
    // Main()

    #endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMathQuiz

}
// MathQuiz