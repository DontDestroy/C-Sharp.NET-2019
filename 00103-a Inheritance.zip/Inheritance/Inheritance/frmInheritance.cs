//***
// Action
//   - Testroutine for cpEmployee, cpExecutive and cpSecretary
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Organigram
{

  public class frmInheritance : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblMicrosoft;
    internal System.Windows.Forms.Button cmdCEO;
    internal System.Windows.Forms.Button cmdSecretary;
    internal System.Windows.Forms.Button cmdEmployee;
    internal System.Windows.Forms.TextBox txtSalary;
    internal System.Windows.Forms.Label lblSalary;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmInheritance));
      this.lblMicrosoft = new System.Windows.Forms.Label();
      this.cmdCEO = new System.Windows.Forms.Button();
      this.cmdSecretary = new System.Windows.Forms.Button();
      this.cmdEmployee = new System.Windows.Forms.Button();
      this.txtSalary = new System.Windows.Forms.TextBox();
      this.lblSalary = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // lblMicrosoft
      // 
      this.lblMicrosoft.Font = new System.Drawing.Font("Microsoft Sans Serif", 3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblMicrosoft.Location = new System.Drawing.Point(8, 160);
      this.lblMicrosoft.Name = "lblMicrosoft";
      this.lblMicrosoft.Size = new System.Drawing.Size(392, 144);
      this.lblMicrosoft.TabIndex = 11;
      this.lblMicrosoft.DoubleClick += new System.EventHandler(this.lblMicrosoft_DoubleClick);
      // 
      // cmdCEO
      // 
      this.cmdCEO.Location = new System.Drawing.Point(96, 128);
      this.cmdCEO.Name = "cmdCEO";
      this.cmdCEO.TabIndex = 10;
      this.cmdCEO.Text = "CEO";
      this.cmdCEO.Click += new System.EventHandler(this.cmdCEO_Click);
      // 
      // cmdSecretary
      // 
      this.cmdSecretary.Location = new System.Drawing.Point(96, 88);
      this.cmdSecretary.Name = "cmdSecretary";
      this.cmdSecretary.TabIndex = 9;
      this.cmdSecretary.Text = "Secretary";
      this.cmdSecretary.Click += new System.EventHandler(this.cmdSecretary_Click);
      // 
      // cmdEmployee
      // 
      this.cmdEmployee.Location = new System.Drawing.Point(96, 48);
      this.cmdEmployee.Name = "cmdEmployee";
      this.cmdEmployee.TabIndex = 8;
      this.cmdEmployee.Text = "Employee";
      this.cmdEmployee.Click += new System.EventHandler(this.cmdEmployee_Click);
      // 
      // txtSalary
      // 
      this.txtSalary.Location = new System.Drawing.Point(72, 16);
      this.txtSalary.Name = "txtSalary";
      this.txtSalary.TabIndex = 7;
      this.txtSalary.Text = "";
      // 
      // lblSalary
      // 
      this.lblSalary.Location = new System.Drawing.Point(8, 16);
      this.lblSalary.Name = "lblSalary";
      this.lblSalary.Size = new System.Drawing.Size(56, 23);
      this.lblSalary.TabIndex = 6;
      this.lblSalary.Text = "Salary";
      // 
      // frmInheritance
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(408, 310);
      this.Controls.Add(this.lblMicrosoft);
      this.Controls.Add(this.cmdCEO);
      this.Controls.Add(this.cmdSecretary);
      this.Controls.Add(this.cmdEmployee);
      this.Controls.Add(this.txtSalary);
      this.Controls.Add(this.lblSalary);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmInheritance";
      this.Text = "Inheritance";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmInheritance'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmInheritance()
      //***
      // Action
      //   - Create instance of 'frmInheritance'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      lblMicrosoft.Text = "Microsoft : \n\n" + 
        "If Class B (cpExecutive) inherits from Class A (cpEmployee), then any object of Class B (cpExecutive) is also an object of Class A (cpEmployee) " +
        "and so includes the public properties and methods (that is, the public interface) of Class A (cpEmployee). \n" + 
        "In this case, Class A (cpEmployee) is called the base class and Class B (cpExecutive) is called the derived class. \n" + 
        "On the other hand, in general, the derived class can be override the implementation of a member of the base class for its own use.";
    }
    // frmInheritance()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCEO_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Creates a cpExecutive
      //   - Changes the salary to 5000
      //   - Show the salary on the form
      //   - Increases the salary with 5 percent
      //   - Show the new salary in a MessageBox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpEmployee.Salary(Decimal) (Set)
      //   - cpExecutive()
      //   - cpExecutive.IncrementSalary(System.Single)
      //   - decimal cpEmployee.Salary (Get)
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpExecutive theCEO = new cpExecutive();

      theCEO.Salary = 5000;
      txtSalary.Text = Convert.ToString(theCEO.Salary);
      theCEO.IncrementSalary(0.05F);
      MessageBox.Show("New salary is : " + theCEO.Salary);
    }
    // cmdCEO_Click(System.Object, System.EventArgs) Handles cmdCEO.Click

    private void cmdEmployee_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Creates a cpEmployee
      //   - Changes the salary to 1000
      //   - Show the salary on the form
      //   - Increases the salary with 5 percent
      //   - Show the new salary in a MessageBox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpEmployee()
      //   - cpEmployee.IncrementSalary(System.Single)
      //   - cpEmployee.Salary(decimal) (Set)
      //   - decimal cpEmployee.Salary (Get)
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpEmployee theEmployee = new cpEmployee();

      theEmployee.Salary = 1000;
      txtSalary.Text = Convert.ToString(theEmployee.Salary);
      theEmployee.IncrementSalary(0.05F);
      MessageBox.Show("New salary is : " + theEmployee.Salary);
    }
    // cmdEmployee_Click(System.Object, System.EventArgs) Handles cmdEmployee.Click

    private void cmdSecretary_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Creates a cpSecretary
      //   - Changes the salary to 2000
      //   - Show the salary on the form
      //   - Increases the salary with 5 percent
      //   - Show the new salary in a MessageBox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpEmployee.Salary(Decimal) (Set)
      //   - cpSecretary()
      //   - cpSecretary.IncrementSalary(System.Single)
      //   - decimal cpEmployee.Salary (Get)
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpSecretary theSecretary = new cpSecretary();

      theSecretary.Salary = 2000;
      txtSalary.Text = Convert.ToString(theSecretary.Salary);
      theSecretary.IncrementSalary(0.05F);
      MessageBox.Show("New salary is : " + theSecretary.Salary);
    }
    // cmdSecretary_Click(System.Object, System.EventArgs) Handles cmdSecretary.Click

    private void lblMicrosoft_DoubleClick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Changes the font of a label to a readable format
      // Called by
      //   - User action (Doubleclick a label)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblMicrosoft.Font = System.Windows.Forms.Label.DefaultFont;
    }
    // lblMicrosoft_DoubleClick(System.Object, System.EventArgs) Handles lblMicrosoft.DoubleClick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmInheritance
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmInheritance());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmInheritance

}
// CopyPaste.Organigram