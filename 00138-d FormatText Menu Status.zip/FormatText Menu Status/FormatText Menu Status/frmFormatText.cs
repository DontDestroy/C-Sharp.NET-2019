//***
// Action
//   - Create a small text editor
//   - Effect on text: Size, Bold, Italic, Underline and Strikethrough
//   - Effect on color background: White, Yellow, Light Green
//   - Effect on color foreground: Black, Blue and Green
//   - There is a menu bar
//   - There is a status bar
// Created
//   - CopyPaste � 20250705 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250705 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFormatText: System.Windows.Forms.Form
	{
		private System.ComponentModel.IContainer components;

		#region Windows Form Designer generated code
		internal System.Windows.Forms.GroupBox grpBackGroundColor;
    internal System.Windows.Forms.RadioButton optBackGroundColorLightGreen;
    internal System.Windows.Forms.RadioButton optBackGroundColorYellow;
    internal System.Windows.Forms.RadioButton optBackGroundColorWhite;
    internal System.Windows.Forms.GroupBox grpSize;
    internal System.Windows.Forms.Button cmdSmall;
    internal System.Windows.Forms.Label lblSize;
    internal System.Windows.Forms.Button cmdBig;
    internal System.Windows.Forms.MenuItem mnuFile;
    internal System.Windows.Forms.MenuItem mnuFileExit;
    internal System.Windows.Forms.MenuItem mnuFormatForeColorBlue;
    internal System.Windows.Forms.MenuItem mnuFormatSeparator01;
    internal System.Windows.Forms.MenuItem mnuFormatStrikeThrough;
    internal System.Windows.Forms.MainMenu mnuMain;
    internal System.Windows.Forms.MenuItem mnuFormat;
    internal System.Windows.Forms.MenuItem mnuFormatBold;
    internal System.Windows.Forms.MenuItem mnuFormatItalic;
    internal System.Windows.Forms.MenuItem mnuFormatUnderline;
    internal System.Windows.Forms.MenuItem mnuFormatForeColorBlack;
    internal System.Windows.Forms.MenuItem mnuFormatForeColorGreen;
    internal System.Windows.Forms.MenuItem MenuItem4;
    internal System.Windows.Forms.MenuItem mnuFormatBackColorWhite;
    internal System.Windows.Forms.MenuItem mnuFormatBackColorYellow;
    internal System.Windows.Forms.MenuItem mnuFormatBackColorLightGreen;
    internal System.Windows.Forms.GroupBox grpEffect;
    internal System.Windows.Forms.CheckBox chkEffectStrikethrough;
    internal System.Windows.Forms.CheckBox chkEffectUnderline;
    internal System.Windows.Forms.CheckBox chkEffectItalic;
    internal System.Windows.Forms.CheckBox chkEffectBold;
    internal System.Windows.Forms.GroupBox grpTextColor;
    internal System.Windows.Forms.RadioButton optTextColorGreen;
    internal System.Windows.Forms.RadioButton optTextColorBlue;
    internal System.Windows.Forms.RadioButton optTextColorBlack;
    internal System.Windows.Forms.TextBox txtText;
    internal System.Windows.Forms.ContextMenu ctmFormat;
    internal System.Windows.Forms.StatusBarPanel stpItalic;
    internal System.Windows.Forms.StatusBarPanel stpUnderline;
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.StatusBarPanel stpBold;
    internal System.Windows.Forms.StatusBar stbFormat;
    internal System.Windows.Forms.StatusBarPanel stpStrikeThrough;

    private void InitializeComponent()
    {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFormatText));
			this.grpBackGroundColor = new System.Windows.Forms.GroupBox();
			this.optBackGroundColorLightGreen = new System.Windows.Forms.RadioButton();
			this.optBackGroundColorYellow = new System.Windows.Forms.RadioButton();
			this.optBackGroundColorWhite = new System.Windows.Forms.RadioButton();
			this.grpSize = new System.Windows.Forms.GroupBox();
			this.cmdSmall = new System.Windows.Forms.Button();
			this.lblSize = new System.Windows.Forms.Label();
			this.cmdBig = new System.Windows.Forms.Button();
			this.mnuFile = new System.Windows.Forms.MenuItem();
			this.mnuFileExit = new System.Windows.Forms.MenuItem();
			this.mnuFormatForeColorBlue = new System.Windows.Forms.MenuItem();
			this.mnuFormatSeparator01 = new System.Windows.Forms.MenuItem();
			this.mnuFormatStrikeThrough = new System.Windows.Forms.MenuItem();
			this.mnuMain = new System.Windows.Forms.MainMenu(this.components);
			this.mnuFormat = new System.Windows.Forms.MenuItem();
			this.mnuFormatBold = new System.Windows.Forms.MenuItem();
			this.mnuFormatItalic = new System.Windows.Forms.MenuItem();
			this.mnuFormatUnderline = new System.Windows.Forms.MenuItem();
			this.mnuFormatForeColorBlack = new System.Windows.Forms.MenuItem();
			this.mnuFormatForeColorGreen = new System.Windows.Forms.MenuItem();
			this.MenuItem4 = new System.Windows.Forms.MenuItem();
			this.mnuFormatBackColorWhite = new System.Windows.Forms.MenuItem();
			this.mnuFormatBackColorYellow = new System.Windows.Forms.MenuItem();
			this.mnuFormatBackColorLightGreen = new System.Windows.Forms.MenuItem();
			this.grpEffect = new System.Windows.Forms.GroupBox();
			this.chkEffectStrikethrough = new System.Windows.Forms.CheckBox();
			this.chkEffectUnderline = new System.Windows.Forms.CheckBox();
			this.chkEffectItalic = new System.Windows.Forms.CheckBox();
			this.chkEffectBold = new System.Windows.Forms.CheckBox();
			this.grpTextColor = new System.Windows.Forms.GroupBox();
			this.optTextColorGreen = new System.Windows.Forms.RadioButton();
			this.optTextColorBlue = new System.Windows.Forms.RadioButton();
			this.optTextColorBlack = new System.Windows.Forms.RadioButton();
			this.txtText = new System.Windows.Forms.TextBox();
			this.ctmFormat = new System.Windows.Forms.ContextMenu();
			this.stpItalic = new System.Windows.Forms.StatusBarPanel();
			this.stpUnderline = new System.Windows.Forms.StatusBarPanel();
			this.cmdExit = new System.Windows.Forms.Button();
			this.stpBold = new System.Windows.Forms.StatusBarPanel();
			this.stbFormat = new System.Windows.Forms.StatusBar();
			this.stpStrikeThrough = new System.Windows.Forms.StatusBarPanel();
			this.grpBackGroundColor.SuspendLayout();
			this.grpSize.SuspendLayout();
			this.grpEffect.SuspendLayout();
			this.grpTextColor.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.stpItalic)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.stpUnderline)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.stpBold)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.stpStrikeThrough)).BeginInit();
			this.SuspendLayout();
			// 
			// grpBackGroundColor
			// 
			this.grpBackGroundColor.Controls.Add(this.optBackGroundColorLightGreen);
			this.grpBackGroundColor.Controls.Add(this.optBackGroundColorYellow);
			this.grpBackGroundColor.Controls.Add(this.optBackGroundColorWhite);
			this.grpBackGroundColor.Location = new System.Drawing.Point(368, 236);
			this.grpBackGroundColor.Name = "grpBackGroundColor";
			this.grpBackGroundColor.Size = new System.Drawing.Size(120, 96);
			this.grpBackGroundColor.TabIndex = 10;
			this.grpBackGroundColor.TabStop = false;
			this.grpBackGroundColor.Text = "BackGround &Color";
			// 
			// optBackGroundColorLightGreen
			// 
			this.optBackGroundColorLightGreen.Location = new System.Drawing.Point(16, 64);
			this.optBackGroundColorLightGreen.Name = "optBackGroundColorLightGreen";
			this.optBackGroundColorLightGreen.Size = new System.Drawing.Size(96, 24);
			this.optBackGroundColorLightGreen.TabIndex = 2;
			this.optBackGroundColorLightGreen.Text = "Lig&ht Green";
			this.optBackGroundColorLightGreen.CheckedChanged += new System.EventHandler(this.optBackGroundColorLightGreen_CheckedChanged);
			// 
			// optBackGroundColorYellow
			// 
			this.optBackGroundColorYellow.Location = new System.Drawing.Point(16, 40);
			this.optBackGroundColorYellow.Name = "optBackGroundColorYellow";
			this.optBackGroundColorYellow.Size = new System.Drawing.Size(96, 24);
			this.optBackGroundColorYellow.TabIndex = 1;
			this.optBackGroundColorYellow.Text = "&Yellow";
			this.optBackGroundColorYellow.CheckedChanged += new System.EventHandler(this.optBackGroundColorYellow_CheckedChanged);
			// 
			// optBackGroundColorWhite
			// 
			this.optBackGroundColorWhite.Checked = true;
			this.optBackGroundColorWhite.Location = new System.Drawing.Point(16, 16);
			this.optBackGroundColorWhite.Name = "optBackGroundColorWhite";
			this.optBackGroundColorWhite.Size = new System.Drawing.Size(96, 24);
			this.optBackGroundColorWhite.TabIndex = 0;
			this.optBackGroundColorWhite.TabStop = true;
			this.optBackGroundColorWhite.Text = "&White";
			this.optBackGroundColorWhite.CheckedChanged += new System.EventHandler(this.optBackGroundColorWhite_CheckedChanged);
			// 
			// grpSize
			// 
			this.grpSize.Controls.Add(this.cmdSmall);
			this.grpSize.Controls.Add(this.lblSize);
			this.grpSize.Controls.Add(this.cmdBig);
			this.grpSize.Location = new System.Drawing.Point(368, 340);
			this.grpSize.Name = "grpSize";
			this.grpSize.Size = new System.Drawing.Size(120, 64);
			this.grpSize.TabIndex = 11;
			this.grpSize.TabStop = false;
			this.grpSize.Text = "Si&ze";
			// 
			// cmdSmall
			// 
			this.cmdSmall.Enabled = false;
			this.cmdSmall.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmdSmall.Location = new System.Drawing.Point(80, 24);
			this.cmdSmall.Name = "cmdSmall";
			this.cmdSmall.Size = new System.Drawing.Size(32, 23);
			this.cmdSmall.TabIndex = 2;
			this.cmdSmall.Text = "A";
			this.cmdSmall.Click += new System.EventHandler(this.cmdSmall_Click);
			// 
			// lblSize
			// 
			this.lblSize.Location = new System.Drawing.Point(8, 24);
			this.lblSize.Name = "lblSize";
			this.lblSize.Size = new System.Drawing.Size(24, 23);
			this.lblSize.TabIndex = 0;
			this.lblSize.Text = "9";
			this.lblSize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// cmdBig
			// 
			this.cmdBig.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.cmdBig.Location = new System.Drawing.Point(40, 24);
			this.cmdBig.Name = "cmdBig";
			this.cmdBig.Size = new System.Drawing.Size(32, 23);
			this.cmdBig.TabIndex = 1;
			this.cmdBig.Text = "A";
			this.cmdBig.Click += new System.EventHandler(this.cmdBig_Click);
			// 
			// mnuFile
			// 
			this.mnuFile.Index = 0;
			this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mnuFileExit});
			this.mnuFile.Text = "&File";
			// 
			// mnuFileExit
			// 
			this.mnuFileExit.Index = 0;
			this.mnuFileExit.Text = "E&xit";
			this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
			// 
			// mnuFormatForeColorBlue
			// 
			this.mnuFormatForeColorBlue.Index = 6;
			this.mnuFormatForeColorBlue.Text = "Fore Color Bl&ue";
			this.mnuFormatForeColorBlue.Click += new System.EventHandler(this.mnuFormatForeColorBlue_Click);
			// 
			// mnuFormatSeparator01
			// 
			this.mnuFormatSeparator01.Index = 4;
			this.mnuFormatSeparator01.Text = "-";
			// 
			// mnuFormatStrikeThrough
			// 
			this.mnuFormatStrikeThrough.Index = 3;
			this.mnuFormatStrikeThrough.Text = "&Strike Through";
			this.mnuFormatStrikeThrough.Click += new System.EventHandler(this.mnuFormatStrikeThrough_Click);
			// 
			// mnuMain
			// 
			this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mnuFile,
            this.mnuFormat});
			// 
			// mnuFormat
			// 
			this.mnuFormat.Index = 1;
			this.mnuFormat.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mnuFormatBold,
            this.mnuFormatItalic,
            this.mnuFormatUnderline,
            this.mnuFormatStrikeThrough,
            this.mnuFormatSeparator01,
            this.mnuFormatForeColorBlack,
            this.mnuFormatForeColorBlue,
            this.mnuFormatForeColorGreen,
            this.MenuItem4,
            this.mnuFormatBackColorWhite,
            this.mnuFormatBackColorYellow,
            this.mnuFormatBackColorLightGreen});
			this.mnuFormat.Text = "F&ormat";
			this.mnuFormat.Popup += new System.EventHandler(this.mnuFormat_Popup);
			// 
			// mnuFormatBold
			// 
			this.mnuFormatBold.Index = 0;
			this.mnuFormatBold.Text = "&Bold";
			this.mnuFormatBold.Click += new System.EventHandler(this.mnuFormatBold_Click);
			// 
			// mnuFormatItalic
			// 
			this.mnuFormatItalic.Index = 1;
			this.mnuFormatItalic.Text = "&Italic";
			this.mnuFormatItalic.Click += new System.EventHandler(this.mnuFormatItalic_Click);
			// 
			// mnuFormatUnderline
			// 
			this.mnuFormatUnderline.Index = 2;
			this.mnuFormatUnderline.Text = "&Underline";
			this.mnuFormatUnderline.Click += new System.EventHandler(this.mnuFormatUnderline_Click);
			// 
			// mnuFormatForeColorBlack
			// 
			this.mnuFormatForeColorBlack.Index = 5;
			this.mnuFormatForeColorBlack.Text = "Fore Color B&lack";
			this.mnuFormatForeColorBlack.Click += new System.EventHandler(this.mnuFormatForeColorBlack_Click);
			// 
			// mnuFormatForeColorGreen
			// 
			this.mnuFormatForeColorGreen.Index = 7;
			this.mnuFormatForeColorGreen.Text = "Fore Color &Green";
			this.mnuFormatForeColorGreen.Click += new System.EventHandler(this.mnuFormatForeColorGreen_Click);
			// 
			// MenuItem4
			// 
			this.MenuItem4.Index = 8;
			this.MenuItem4.Text = "-";
			// 
			// mnuFormatBackColorWhite
			// 
			this.mnuFormatBackColorWhite.Index = 9;
			this.mnuFormatBackColorWhite.Text = "Back Color &White";
			this.mnuFormatBackColorWhite.Click += new System.EventHandler(this.mnuFormatBackColorWhite_Click);
			// 
			// mnuFormatBackColorYellow
			// 
			this.mnuFormatBackColorYellow.Index = 10;
			this.mnuFormatBackColorYellow.Text = "Back Color &Yellow";
			this.mnuFormatBackColorYellow.Click += new System.EventHandler(this.mnuFormatBackColorYellow_Click);
			// 
			// mnuFormatBackColorLightGreen
			// 
			this.mnuFormatBackColorLightGreen.Index = 11;
			this.mnuFormatBackColorLightGreen.Text = "Back Color Lig&ht Green";
			this.mnuFormatBackColorLightGreen.Click += new System.EventHandler(this.mnuFormatBackColorLightGreen_Click);
			// 
			// grpEffect
			// 
			this.grpEffect.Controls.Add(this.chkEffectStrikethrough);
			this.grpEffect.Controls.Add(this.chkEffectUnderline);
			this.grpEffect.Controls.Add(this.chkEffectItalic);
			this.grpEffect.Controls.Add(this.chkEffectBold);
			this.grpEffect.Location = new System.Drawing.Point(368, 4);
			this.grpEffect.Name = "grpEffect";
			this.grpEffect.Size = new System.Drawing.Size(120, 120);
			this.grpEffect.TabIndex = 8;
			this.grpEffect.TabStop = false;
			this.grpEffect.Text = "&Effect";
			// 
			// chkEffectStrikethrough
			// 
			this.chkEffectStrikethrough.Location = new System.Drawing.Point(16, 88);
			this.chkEffectStrikethrough.Name = "chkEffectStrikethrough";
			this.chkEffectStrikethrough.Size = new System.Drawing.Size(96, 24);
			this.chkEffectStrikethrough.TabIndex = 3;
			this.chkEffectStrikethrough.Text = "&Strikethrough";
			this.chkEffectStrikethrough.CheckedChanged += new System.EventHandler(this.chkEffectStrikethrough_CheckedChanged);
			// 
			// chkEffectUnderline
			// 
			this.chkEffectUnderline.Location = new System.Drawing.Point(16, 64);
			this.chkEffectUnderline.Name = "chkEffectUnderline";
			this.chkEffectUnderline.Size = new System.Drawing.Size(85, 24);
			this.chkEffectUnderline.TabIndex = 2;
			this.chkEffectUnderline.Text = "&Underline";
			this.chkEffectUnderline.CheckedChanged += new System.EventHandler(this.chkEffectUnderline_CheckedChanged);
			// 
			// chkEffectItalic
			// 
			this.chkEffectItalic.Location = new System.Drawing.Point(16, 40);
			this.chkEffectItalic.Name = "chkEffectItalic";
			this.chkEffectItalic.Size = new System.Drawing.Size(85, 24);
			this.chkEffectItalic.TabIndex = 1;
			this.chkEffectItalic.Text = "&Italic";
			this.chkEffectItalic.CheckedChanged += new System.EventHandler(this.chkEffectItalic_CheckedChanged);
			// 
			// chkEffectBold
			// 
			this.chkEffectBold.Location = new System.Drawing.Point(16, 16);
			this.chkEffectBold.Name = "chkEffectBold";
			this.chkEffectBold.Size = new System.Drawing.Size(85, 24);
			this.chkEffectBold.TabIndex = 0;
			this.chkEffectBold.Text = "&Bold";
			this.chkEffectBold.CheckedChanged += new System.EventHandler(this.chkEffectBold_CheckedChanged);
			// 
			// grpTextColor
			// 
			this.grpTextColor.Controls.Add(this.optTextColorGreen);
			this.grpTextColor.Controls.Add(this.optTextColorBlue);
			this.grpTextColor.Controls.Add(this.optTextColorBlack);
			this.grpTextColor.Location = new System.Drawing.Point(368, 132);
			this.grpTextColor.Name = "grpTextColor";
			this.grpTextColor.Size = new System.Drawing.Size(120, 96);
			this.grpTextColor.TabIndex = 9;
			this.grpTextColor.TabStop = false;
			this.grpTextColor.Text = "&Text Color";
			// 
			// optTextColorGreen
			// 
			this.optTextColorGreen.Location = new System.Drawing.Point(16, 64);
			this.optTextColorGreen.Name = "optTextColorGreen";
			this.optTextColorGreen.Size = new System.Drawing.Size(96, 24);
			this.optTextColorGreen.TabIndex = 2;
			this.optTextColorGreen.Text = "&Green";
			this.optTextColorGreen.CheckedChanged += new System.EventHandler(this.optTextColorGreen_CheckedChanged);
			// 
			// optTextColorBlue
			// 
			this.optTextColorBlue.Location = new System.Drawing.Point(16, 40);
			this.optTextColorBlue.Name = "optTextColorBlue";
			this.optTextColorBlue.Size = new System.Drawing.Size(96, 24);
			this.optTextColorBlue.TabIndex = 1;
			this.optTextColorBlue.Text = "Bl&ue";
			this.optTextColorBlue.CheckedChanged += new System.EventHandler(this.optTextColorBlue_CheckedChanged);
			// 
			// optTextColorBlack
			// 
			this.optTextColorBlack.Checked = true;
			this.optTextColorBlack.Location = new System.Drawing.Point(16, 16);
			this.optTextColorBlack.Name = "optTextColorBlack";
			this.optTextColorBlack.Size = new System.Drawing.Size(96, 24);
			this.optTextColorBlack.TabIndex = 0;
			this.optTextColorBlack.TabStop = true;
			this.optTextColorBlack.Text = "B&lack";
			this.optTextColorBlack.CheckedChanged += new System.EventHandler(this.optTextColorBlack_CheckedChanged);
			// 
			// txtText
			// 
			this.txtText.ContextMenu = this.ctmFormat;
			this.txtText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
			this.txtText.Location = new System.Drawing.Point(8, 4);
			this.txtText.Multiline = true;
			this.txtText.Name = "txtText";
			this.txtText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtText.Size = new System.Drawing.Size(352, 400);
			this.txtText.TabIndex = 7;
			// 
			// ctmFormat
			// 
			this.ctmFormat.Popup += new System.EventHandler(this.ctmFormat_Popup);
			// 
			// stpItalic
			// 
			this.stpItalic.Alignment = System.Windows.Forms.HorizontalAlignment.Center;
			this.stpItalic.MinWidth = 16;
			this.stpItalic.Name = "stpItalic";
			this.stpItalic.Width = 16;
			// 
			// stpUnderline
			// 
			this.stpUnderline.Alignment = System.Windows.Forms.HorizontalAlignment.Center;
			this.stpUnderline.MinWidth = 16;
			this.stpUnderline.Name = "stpUnderline";
			this.stpUnderline.Width = 16;
			// 
			// cmdExit
			// 
			this.cmdExit.Location = new System.Drawing.Point(8, 412);
			this.cmdExit.Name = "cmdExit";
			this.cmdExit.Size = new System.Drawing.Size(75, 23);
			this.cmdExit.TabIndex = 12;
			this.cmdExit.Text = "&Exit";
			this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
			// 
			// stpBold
			// 
			this.stpBold.Alignment = System.Windows.Forms.HorizontalAlignment.Center;
			this.stpBold.MinWidth = 16;
			this.stpBold.Name = "stpBold";
			this.stpBold.Width = 16;
			// 
			// stbFormat
			// 
			this.stbFormat.Location = new System.Drawing.Point(0, 396);
			this.stbFormat.Name = "stbFormat";
			this.stbFormat.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
            this.stpBold,
            this.stpItalic,
            this.stpUnderline,
            this.stpStrikeThrough});
			this.stbFormat.ShowPanels = true;
			this.stbFormat.Size = new System.Drawing.Size(494, 22);
			this.stbFormat.TabIndex = 13;
			// 
			// stpStrikeThrough
			// 
			this.stpStrikeThrough.Alignment = System.Windows.Forms.HorizontalAlignment.Center;
			this.stpStrikeThrough.MinWidth = 16;
			this.stpStrikeThrough.Name = "stpStrikeThrough";
			this.stpStrikeThrough.Width = 16;
			// 
			// frmFormatText
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(494, 418);
			this.Controls.Add(this.grpEffect);
			this.Controls.Add(this.grpTextColor);
			this.Controls.Add(this.txtText);
			this.Controls.Add(this.cmdExit);
			this.Controls.Add(this.stbFormat);
			this.Controls.Add(this.grpBackGroundColor);
			this.Controls.Add(this.grpSize);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Menu = this.mnuMain;
			this.Name = "frmFormatText";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Format Text";
			this.grpBackGroundColor.ResumeLayout(false);
			this.grpSize.ResumeLayout(false);
			this.grpEffect.ResumeLayout(false);
			this.grpTextColor.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.stpItalic)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.stpUnderline)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.stpBold)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.stpStrikeThrough)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFormatText'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFormatText()
      //***
      // Action
      //   - Create instance of 'frmFormatText'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFormatText()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void chkEffectBold_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the effect fontstyle bold
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeEffect(FontStyle)
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeEffect(FontStyle.Bold);
    }
    // chkEffectBold_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectBold.CheckedChanged

    private void chkEffectItalic_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the effect fontstyle italic
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeEffect(FontStyle)
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeEffect(FontStyle.Italic);
    }
    // chkEffectItalic_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectItalic.CheckedChanged

    private void chkEffectStrikethrough_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the effect fontstyle strikeout
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeEffect(FontStyle)
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeEffect(FontStyle.Strikeout);
    }
    // chkEffectStrikethrough_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectStrikethrough.CheckedChanged

    private void chkEffectUnderline_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the effect fontstyle underline
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeEffect(FontStyle)
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeEffect(FontStyle.Underline);
    }
    // chkEffectUnderline_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectUnderline.CheckedChanged
    
    private void cmdBig_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Make the size of the font one bigger
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ChangeSize(Single)
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeSize(1);
    }
    // cmdBig_Click(System.Object, System.EventArgs) Handles cmdBig.Click

    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop the application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit.Click

    private void cmdSmall_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Make the size of the font one smaller
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ChangeSize(Single)
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeSize(-1);
    }
    // cmdSmall_Click(System.Object, System.EventArgs) Handles cmdSmall.Click
    
    private void ctmFormat_Popup(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Check menu items
      //   - Clear all the context menus
      //   - Loop thru the menu items of the menu Format
      //     - Add menu item to the context menu
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - CheckMenuItems()
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ;

      CheckMenuItems();
      ctmFormat.MenuItems.Clear();

      foreach (MenuItem aMenuItem in mnuFormat.MenuItems)
      {
        ctmFormat.MenuItems.Add(aMenuItem.CloneMenu());
      }
      // in mnuFormat.MenuItems
    
    }
    // ctmFormat_Popup(System.Object, System.EventArgs) Handles ctmFormat.Popup

    private void mnuFileExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop the application
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    //  mnuFileExit_Click(System.Object, System.EventArgs) Handles mnuFileExit.Click

    private void mnuFormat_Popup(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Check menu items
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - CheckMenuItems()
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      CheckMenuItems();
    }
    // mnuFormat_Popup(System.Object theSender, System.EventArgs theEventArguments)

    private void mnuFormatBackColorLightGreen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set option background color light green to true (selected)
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      optBackGroundColorLightGreen.Checked = true;
    }
    // mnuFormatBackColorLightGreen_Click(System.Object, System.EventArgs) Handles mnuFormatBackColorLightGreen.Click

    private void mnuFormatBackColorWhite_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set option background color white to true (selected)
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      optBackGroundColorWhite.Checked = true;
    }
    // mnuFormatBackColorWhite_Click(System.Object, System.EventArgs) Handles mnuFormatBackColorWhite.Click

    private void mnuFormatBackColorYellow_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set option background color yellow to true (selected)
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      optBackGroundColorYellow.Checked = true;
    }
    // mnuFormatBackColorYellow_Click(System.Object, System.EventArgs) Handles mnuFormatBackColorYellow.Click

    private void mnuFormatBold_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set option bold to the opposite value
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      chkEffectBold.Checked = !chkEffectBold.Checked;
    }
    // mnuFormatBold_Click(System.Object, System.EventArgs) Handles mnuFormatBold.Click

    private void mnuFormatForeColorBlack_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set option text color black to true (selected)
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      optTextColorBlack.Checked = true;
    }
    // mnuFormatForeColorBlack_Click(System.Object, System.EventArgs) Handles mnuFormatForeColorBlack.Click

    private void mnuFormatForeColorBlue_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set option text color blue to true (selected)
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      optTextColorBlue.Checked = true;
    }
    // mnuFormatForeColorBlue_Click(System.Object, System.EventArgs) Handles mnuFormatForeColorBlue.Click

    private void mnuFormatForeColorGreen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set option text color green to true (selected)
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      optTextColorGreen.Checked = true;
    }
    // mnuFormatForeColorGreen_Click(System.Object, System.EventArgs) Handles mnuFormatForeColorGreen.Click

    private void mnuFormatItalic_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set option italic to the opposite value
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      chkEffectItalic.Checked = !chkEffectItalic.Checked;
    }
    // mnuFormatItalic_Click(System.Object, System.EventArgs) Handles mnuFormatItalic.Click

    private void mnuFormatStrikeThrough_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set option strikethrough to the opposite value
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      chkEffectStrikethrough.Checked = !chkEffectStrikethrough.Checked;
    }
    // mnuFormatStrikeThrough_Click(System.Object, System.EventArgs) Handles mnuFormatStrikeThrough.Click

    private void mnuFormatUnderline_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set option underline to the opposite value
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      chkEffectUnderline.Checked = !chkEffectUnderline.Checked;
    }
    // mnuFormatUnderline_Click(System.Object, System.EventArgs) Handles mnuFormatUnderline.Click

    private void optBackGroundColorLightGreen_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the back color of the text to light green
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeBackColor(Color)
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeBackColor(Color.LightGreen);
    }
    // optBackGroundColorLightGreen_CheckedChanged(System.Object, System.EventArgs) Handles optBackGroundColorLightGreen.CheckedChanged

    private void optBackGroundColorWhite_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the back color of the text to white
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeBackColor(Color)
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeBackColor(Color.White);
    }
    // optBackGroundColorWhite_CheckedChanged(System.Object, .EventArgs) Handles optBackGroundColorWhite.CheckedChanged

    private void optBackGroundColorYellow_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the back color of the text to yellow
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeBackColor(Color)
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeBackColor(Color.Yellow);
    }
    // optBackGroundColorYellow_CheckedChanged(System.Object, System.EventArgs) Handles optBackGroundColorYellow.CheckedChanged

    private void optTextColorBlack_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the text color of the text to black
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeForeColor(Color)
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeForeColor(Color.Black);
    }
    // optTextColorBlack_CheckedChanged(System.Object, System.EventArgs) Handles optTextColorBlack.CheckedChanged

    private void optTextColorBlue_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the text color of the text to blue
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeForeColor(Color)
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeForeColor(Color.Blue);
    }
    // optTextColorBlue_CheckedChanged(System.Object, System.EventArgs) Handles optTextColorBlue.CheckedChanged

    private void optTextColorGreen_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the text color of the text to green
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeForeColor(Color)
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeForeColor(Color.Green);
    }
    // optTextColorGreen_CheckedChanged(System.Object, System.EventArgs) Handles optTextColorGreen.CheckedChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void ChangeBackColor(Color theColor)
      //***
      // Action
      //   - Get the size of the font (sngSize)
      //   - Back color of the text becomes theColor
      // Called by
      //   - optBackGroundColorLightGreen_CheckedChanged(System.Object, System.EventArgs) Handles optBackGroundColorLightGreen.CheckedChanged
      //   - optBackGroundColorWhite_CheckedChanged(System.Object, .EventArgs) Handles optBackGroundColorWhite.CheckedChanged
      //   - optBackGroundColorYellow_CheckedChanged(System.Object, .EventArgs) Handles optBackGroundColorYellow.CheckedChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Single sngSize = txtText.Font.Size;

      txtText.BackColor = theColor;
    }
    // ChangeBackColor(Color)

    private void ChangeEffect(FontStyle theEffect)
      //***
      // Action
      //   - Extra info
      //     - Fontstyle regular = 0
      //     - Fontstyle bold = 1
      //     - Fontstyle italic = 2
      //     - Fontstyle underline = 4
      //     - Fontstyle striketrough = 8
      //   - Get the size of the font (sngSize)
      //   - Depending on the effect
      //     - Fontstyle bold
      //       - Redraw with txtText.Font.Style (0000 till 1111) Xor theEffect (0001)
      //         - Xor (bitwise operator): If both values are the same, the result is false
      //           - If the last bits of the two operands (most right) are different, the last bit becomes 1
      //           - Font.Style is bold (true) and bold checkbox is changed (true), bold is switched off
      //           - Font.Style is bold (false) and bold checkbox is changed (true), bold is switched on
      //           - Font.Style is bold (false) and bold checkbox is changed (false), bold is switched off
      //           - Font.Style is bold (true) and bold checkbox is changed (false), bold is switched on
      //       - If bold
      //         - Set B to status bar
      //       - If not
      //         - Remove B from status bar
      //     - Fontstyle italic
      //       - Redraw with txtText.Font.Style (0000 till 1111) Xor theEffect (0010)
      //         - Xor (bitwise operator): If both values are the same, the result is false
      //           - If the second to last bits of the two operands (most right) are different, the second last bit becomes 1
      //       - If italic
      //         - Set I to status bar
      //       - If not
      //         - Remove I from status bar
      //     - Fontstyle strikeout
      //       - Redraw with txtText.Font.Style (0000 till 1111) Xor theEffect (1000)
      //         - Xor (bitwise operator): If both values are the same, the result is false
      //           - If the first bits of the two operands (most left) are different, the first bit becomes 1
      //       - If strikeout
      //         - Set S to status bar
      //       - If not
      //         - Remove S from status bar
      //     - Fontstyle underline
      //       - Redraw with txtText.Font.Style (0000 till 1111) Xor theEffect (0100)
      //         - Xor (bitwise operator): If both values are the same, the result is false
      //           - If the second bits of the two operands (most left) are different, the second bit becomes 1
      //       - If underline
      //         - Set U to status bar
      //       - If not
      //         - Remove U from status bar
      // Called by
      //   - chkEffectBold_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectBold.CheckedChanged
      //   - chkEffectItalic_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectItalic.CheckedChanged
      //   - chkEffectStrikethrough_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectStrikethrough.CheckedChanged
      //   - chkEffectUnderline_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectUnderline.CheckedChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Single sngSize = txtText.Font.Size;

      switch (theEffect)
      {
        case FontStyle.Bold:
          txtText.Font = new System.Drawing.Font(txtText.Font.FontFamily, sngSize, txtText.Font.Style ^ theEffect);
          
          if (txtText.Font.Bold) 
          {
            stpBold.Text = "B";
          }
          else
            // Not txtText.Font.Bold
          {
            stpBold.Text = "";
          }
          // txtText.Font.Bold
          
          break;
        case FontStyle.Italic:
          txtText.Font = new System.Drawing.Font(txtText.Font.FontFamily, sngSize, txtText.Font.Style ^ theEffect);

          if (txtText.Font.Italic) 
          {
            stpItalic.Text = "I";
          }
          else
            // Not txtText.Font.Italic
          {
            stpItalic.Text = "";
          }
          // txtText.Font.Italic
          
          break;
        case FontStyle.Strikeout:
          txtText.Font = new System.Drawing.Font(txtText.Font.FontFamily, sngSize, txtText.Font.Style ^ theEffect);

          if (txtText.Font.Strikeout) 
          {
            stpStrikeThrough.Text = "S";
          }
          else
            // Not txtText.Font.Strikeout
          {
            stpStrikeThrough.Text = "";
          }
          // txtText.Font.Strikeout
          
          break;
        case FontStyle.Underline:
          txtText.Font = new System.Drawing.Font(txtText.Font.FontFamily, sngSize, txtText.Font.Style ^ theEffect);

          if (txtText.Font.Underline) 
          {
            stpUnderline.Text = "U";
          }
          else
            // Not txtText.Font.Underline
          {
            stpUnderline.Text = "";
          }
          // txtText.Font.Underline
          
          break;
       }
      // theEffect

    }
    // ChangeEffect(FontStyle)

    private void ChangeForeColor(Color theColor)
      //***
      // Action
      //   - Get the size of the font (sngSize)
      //   - Fore color of the text becomes theColor
      // Called by
      //   - optTextColorBlack_CheckedChanged(System.Object, System.EventArgs) Handles optTextColorBlack.CheckedChanged
      //   - optTextColorBlue_CheckedChanged(System.Object, System.EventArgs) Handles optTextColorBlack.CheckedChanged
      //   - optTextColorGreen_CheckedChanged(System.Object, System.EventArgs) Handles optTextColorBlack.CheckedChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Single sngSize = txtText.Font.Size;

      txtText.ForeColor = theColor;
    }
    // ChangeForeColor(Color)

    private void ChangeSize(Single sngChange)
      //***
      // Action
      //   - Get the size of the font (sngSize)
      //   - Add sngChange to sngSize
      //   - Redraw with the new value of sngSize
      //   - If sngSize is different from 9
      //     - cmdSmall becomes enabled
      //   - If not
      //     - cmdSmall becomes disabled
      // Called by
      //   - cmdBig_Click(System.Object, System.EventArgs) Handles cmdBig.Click
      //   - cmdSmall_Click(System.Object, System.EventArgs) Handles cmdSmall.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Single sngSize = txtText.Font.Size;

      sngSize += sngChange;
      txtText.Font = new System.Drawing.Font(txtText.Font.FontFamily, sngSize, txtText.Font.Style);
      lblSize.Text = sngSize.ToString();
      cmdSmall.Enabled = (sngSize != 9);
    }
    // ChangeSize(Single)

    public void CheckMenuItems()
      //***
      // Action
      //   - Menu format bold is checked or not depending on the bold font
      //   - Menu format italic is checked or not depending on the italic font
      //   - Menu format strikethrough is checked or not depending on the strikethrough font
      //   - Menu format underline is checked or not depending on the underline font
      //   - Menu format back color light green is checked or not depending on the font back color
      //   - Menu format back color white is checked or not depending on the font back color
      //   - Menu format back color yellow is checked or not depending on the font back color
      //   - Menu format text color black is checked or not depending on the font color
      //   - Menu format text color blue is checked or not depending on the font color
      //   - Menu format text color green is checked or not depending on the font color
      // Called by
      //   - ctmFormat_Popup(System.Object, System.EventArgs) Handles ctmFormat.Popup
      //   - mnuFormat_Popup(System.Object, System.EventArgs) Handles mnuFormat.Popup
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mnuFormatBold.Checked = txtText.Font.Bold;
      mnuFormatItalic.Checked = txtText.Font.Italic;
      mnuFormatStrikeThrough.Checked = txtText.Font.Strikeout;
      mnuFormatUnderline.Checked = txtText.Font.Underline;
      mnuFormatBackColorLightGreen.Checked = txtText.BackColor.Equals(Color.LightGreen);
      mnuFormatBackColorWhite.Checked = txtText.BackColor.Equals(Color.White);
      mnuFormatBackColorYellow.Checked = txtText.BackColor.Equals(Color.Yellow);
      mnuFormatForeColorBlack.Checked = txtText.ForeColor.Equals(Color.Black);
      mnuFormatForeColorBlue.Checked = txtText.ForeColor.Equals(Color.Blue);
      mnuFormatForeColorGreen.Checked = txtText.ForeColor.Equals(Color.Green);
    }
    // CheckMenuItems()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFormatText
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmFormatText()
      // Created
      //   - CopyPaste � 20250705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFormatText());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmFormatText

}
// CopyPaste.Learning