//***
// Action
//   - Demo adding a text to a textbox
// Created
//   - CopyPaste � 20240118 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240118 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmClientOrSupplier: System.Windows.Forms.Form
	{

    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.Button cmdSupplier;
    internal System.Windows.Forms.Button cmdClient;
    internal System.Windows.Forms.Label lblSupplier;
    internal System.Windows.Forms.Label lblClient;
    internal System.Windows.Forms.TextBox txtSupplier;
    internal System.Windows.Forms.TextBox txtClient;
		private System.ComponentModel.Container components = null;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmClientOrSupplier));
      this.cmdExit = new System.Windows.Forms.Button();
      this.cmdSupplier = new System.Windows.Forms.Button();
      this.cmdClient = new System.Windows.Forms.Button();
      this.lblSupplier = new System.Windows.Forms.Label();
      this.lblClient = new System.Windows.Forms.Label();
      this.txtSupplier = new System.Windows.Forms.TextBox();
      this.txtClient = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdExit
      // 
      this.cmdExit.Location = new System.Drawing.Point(240, 184);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.TabIndex = 13;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // cmdSupplier
      // 
      this.cmdSupplier.Location = new System.Drawing.Point(176, 128);
      this.cmdSupplier.Name = "cmdSupplier";
      this.cmdSupplier.Size = new System.Drawing.Size(144, 23);
      this.cmdSupplier.TabIndex = 12;
      this.cmdSupplier.Text = "Add &Supplier";
      this.cmdSupplier.Click += new System.EventHandler(this.cmdSupplier_Click);
      // 
      // cmdClient
      // 
      this.cmdClient.Location = new System.Drawing.Point(16, 128);
      this.cmdClient.Name = "cmdClient";
      this.cmdClient.Size = new System.Drawing.Size(144, 23);
      this.cmdClient.TabIndex = 9;
      this.cmdClient.Text = "Add &Client";
      this.cmdClient.Click += new System.EventHandler(this.cmdClient_Click);
      // 
      // lblSupplier
      // 
      this.lblSupplier.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblSupplier.Location = new System.Drawing.Point(176, 24);
      this.lblSupplier.Name = "lblSupplier";
      this.lblSupplier.TabIndex = 10;
      this.lblSupplier.Text = "Suppliers";
      // 
      // lblClient
      // 
      this.lblClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblClient.Location = new System.Drawing.Point(16, 24);
      this.lblClient.Name = "lblClient";
      this.lblClient.TabIndex = 7;
      this.lblClient.Text = "Clients";
      // 
      // txtSupplier
      // 
      this.txtSupplier.Location = new System.Drawing.Point(176, 48);
      this.txtSupplier.Multiline = true;
      this.txtSupplier.Name = "txtSupplier";
      this.txtSupplier.ReadOnly = true;
      this.txtSupplier.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtSupplier.Size = new System.Drawing.Size(144, 72);
      this.txtSupplier.TabIndex = 11;
      this.txtSupplier.TabStop = false;
      this.txtSupplier.Text = "";
      // 
      // txtClient
      // 
      this.txtClient.Location = new System.Drawing.Point(16, 48);
      this.txtClient.Multiline = true;
      this.txtClient.Name = "txtClient";
      this.txtClient.ReadOnly = true;
      this.txtClient.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtClient.Size = new System.Drawing.Size(144, 72);
      this.txtClient.TabIndex = 8;
      this.txtClient.TabStop = false;
      this.txtClient.Text = "";
      // 
      // frmClientOrSupplier
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(336, 221);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.cmdSupplier);
      this.Controls.Add(this.cmdClient);
      this.Controls.Add(this.lblSupplier);
      this.Controls.Add(this.lblClient);
      this.Controls.Add(this.txtSupplier);
      this.Controls.Add(this.txtClient);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmClientOrSupplier";
      this.Text = "Client and Supplier list";
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmClientOrSupplier'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240118 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240118 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmClientOrSupplier()
			//***
			// Action
			//   - Create instance of 'frmClientOrSupplier'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240118 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240118 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmClientOrSupplier()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"
   
    private void cmdClient_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Add an asked name to 'txtClient'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpAddName.Add(String, String)
      // Created
      //   - CopyPaste � 20240118 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240118 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strClient = "";

      cpAddName.Add("client list", ref strClient);
      txtClient.Text = txtClient.Text + strClient;
    }
    // cmdClient_Click(System.Object, System.EventArgs) Handles cmdClient.Click

    
    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop program
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240118 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240118 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit.Click

    private void cmdSupplier_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Add an asked name to 'txtSupplier'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpAddName.Add(string, �string)
      // Created
      //   - CopyPaste � 20240118 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240118 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strSupplier = "";

      cpAddName.Add("supplier list", ref strSupplier);
      txtSupplier.Text = txtSupplier.Text + strSupplier;
    }
    // cmdSupplier_Click(System.Object, System.EventArgs) Handles cmdSupplier.Click

		#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmClientOrSupplier
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmClientOrSupplier()
			// Created
			//   - CopyPaste � 20240118 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240118 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmClientOrSupplier());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmClientOrSupplier

}
// CopyPaste.Learning