//***
// Action
//   - Having an example of looping
//   - This form is a startpoint of the exercise
// Created
//   - CopyPaste � 20230807 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230807 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmLoopingNames : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdCopy;
    internal System.Windows.Forms.TextBox txtText;
    internal System.Windows.Forms.ListBox lstNames;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmLoopingNames));
      this.cmdCopy = new System.Windows.Forms.Button();
      this.txtText = new System.Windows.Forms.TextBox();
      this.lstNames = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // cmdCopy
      // 
      this.cmdCopy.Location = new System.Drawing.Point(104, 256);
      this.cmdCopy.Name = "cmdCopy";
      this.cmdCopy.Size = new System.Drawing.Size(192, 40);
      this.cmdCopy.TabIndex = 5;
      this.cmdCopy.Text = "Copy Names";
      this.cmdCopy.Click += new System.EventHandler(this.cmdCopy_Click);
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(224, 16);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(168, 199);
      this.txtText.TabIndex = 4;
      this.txtText.Text = "";
      // 
      // lstNames
      // 
      this.lstNames.Location = new System.Drawing.Point(24, 16);
      this.lstNames.Name = "lstNames";
      this.lstNames.Size = new System.Drawing.Size(168, 199);
      this.lstNames.TabIndex = 3;
      // 
      // frmLoopingNames
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(416, 357);
      this.Controls.Add(this.cmdCopy);
      this.Controls.Add(this.txtText);
      this.Controls.Add(this.lstNames);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmLoopingNames";
      this.Text = "Looping Names";
      this.Load += new System.EventHandler(this.frmLoopingNames_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmLoopingNames'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmLoopingNames()
      //***
      // Action
      //   - Create instance of 'frmLoopingNames'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmLoopingNames()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    
    private void cmdCopy_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - txtText becomes empty
      //   - Loop thru lstNames.Items (with a counter lngNumber)
      //     - txtText becomes txtText concatenated with lstNames.Items(lngNumber)
      //     - txtText becomes txtText with a hard return
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      int intNumber;

      txtText.Text = "";

      for (intNumber = 0; intNumber < lstNames.Items.Count; intNumber++)
      {
        txtText.Text += lstNames.Items[intNumber].ToString();
        txtText.Text += Environment.NewLine;
      }
      // lngNumber = lstNames.Items.Count
    
    }
    // cmdCopy_Click(System.Object, System.EventArgs) Handles cmdCopy.Click

    private void frmLoopingNames_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Fill the list with names 
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lstNames.Items.Add("Bob");
      lstNames.Items.Add("Jane");
      lstNames.Items.Add("Mary");
      lstNames.Items.Add("Steve");
      lstNames.Items.Add("Andrew");
      lstNames.Items.Add("Michelle");
      lstNames.Items.Add("Laura");
      lstNames.Items.Add("Vincent");
      lstNames.Items.Add("Hilde");
      lstNames.Items.Add("Martijn");
      lstNames.Items.Add("Liesbeth");
    }
    // frmLoopingNames_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDefault
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmLoopingNames());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmLoopingNames

}
// CopyPaste.Learning