﻿//***
// Action
//   - Design of the Tryout Startup screen of the duck game
// Created
//   - CopyPaste – 20240725 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240725 – VVDW
// Proposal (To Do)
//   - 
//***

namespace CopyPaste.Game.Duck
{
	partial class frmDuckGameTryout
	{

		#region Windows Form Designer generated code

		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDuckGameTryout));
			SuspendLayout();
			// 
			// frmDuckGameTryout
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(800, 450);
			Icon = (Icon)resources.GetObject("$this.Icon");
			Name = "frmDuckGameTryout";
			Text = "Copy Paste Fuzzy Duck Game (Students Screen)";
			ResumeLayout(false);
		}

		#endregion

	}
	// frmDuckGameTryout

}
// CopyPaste.Game.Duck
