﻿//***
// Action
//   - Demo of a ProgressBar
// Created
//   - CopyPaste – 20230224 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230224 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows;

namespace WPFProgressBar
{

  public partial class wpfExampleProgressBar : Window
  {

    #region "Constructors / Destructors"

    public wpfExampleProgressBar()
    //***
    // Action
    //   - Create an instance of 'wpfExampleProgressBar'
    //   - Calculate the small steps of the progress bar
    //   - Assign what code must be runned in the background
    //   - Assign what code must be runned in when the work is done
    //   - Make sure you can cancel
    // Called by
    //   - User action (Starting the form)
    // Calls
    //   - theBackgroundWorker_DoWork(System.Object, System.ComponentModel.DoWorkEventArgs)
    // Created
    //   - CopyPaste – 20230224 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230224 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
      dblMaximumValueProgressBar = prgProcentCompleted.Maximum;
      theBackgroundWorker.WorkerSupportsCancellation = true;
      theBackgroundWorker.DoWork += theBackgroundWorker_DoWork;
      theBackgroundWorker.RunWorkerCompleted += theBackgroundWorker_RunWorkerCompleted;
    }
    // wpfExampleProgressBar()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private double dblMaximumValueProgressBar; 
    private System.ComponentModel.BackgroundWorker theBackgroundWorker = new System.ComponentModel.BackgroundWorker();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdStartCounting_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Start the thread of a BackgroundWorker
    // Called by
    //   - User action (Clicking a checkbox)
    // Calls
    //   - theBackgroundWorker_DoWork(System.Object, System.ComponentModel.DoWorkEventArgs)
    // Created
    //   - CopyPaste – 20230224 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230224 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      try
      {
        theBackgroundWorker.RunWorkerAsync();
      }
      catch
      { 
      }

    }
    // cmdStartCounting_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdStartCounting.Click

    #endregion

    #region "Functionality"

    #region "Event"

    private delegate void UpdateTheProgress(double dblStep);

    #endregion

    #region "Sub / Function"

    private void theBackgroundWorker_DoWork(System.Object theSender, System.ComponentModel.DoWorkEventArgs theDoWorkEventArguments)
    //***
    // Action
    //   - The values for the loops are defined
    //   - The progress bar works in 1000th parts
    //   - You start counting in 2 loops
    //   - Loop from 1 till 1000
    //     - Inside that loop from 1 till 25000
    //     - Update the progress bar
    // Called by
    //   - wpfExampleProgressBar()
    // Calls
    //   - UpdateProgressBar(double)
    // Created
    //   - CopyPaste – 20230224 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230224 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int intCounterInnerLoop;
      int intCounterOuterLoop;
      int intMaxInnerLoop = 1000000;
      int intMaxOuterLoop = 5000;
      double dblProgressValue = dblMaximumValueProgressBar / intMaxOuterLoop;

      UpdateTheProgress doTheUpdate = new UpdateTheProgress(UpdateProgressBar);

      for (intCounterOuterLoop = 1; intCounterOuterLoop <= intMaxOuterLoop; intCounterOuterLoop++)
      {

        for (intCounterInnerLoop = 1; intCounterInnerLoop <= intMaxInnerLoop; intCounterInnerLoop++)
        {

        }
        // intCounterInnerLoop > intMaxInnerLoop

        prgProcentCompleted.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Send, doTheUpdate, dblProgressValue);
      }
      // intCounterOuterLoop > intMaxOuterLoop

    }
    // theBackgroundWorker_DoWork(System.Object, System.ComponentModel.DoWorkEventArgs)

    private void theBackgroundWorker_RunWorkerCompleted(System.Object theSender, System.ComponentModel.RunWorkerCompletedEventArgs theRunWorkerCompletedEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - System action (DoWork is finished)
    //   - wpfExampleProgressBar()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20230224 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230224 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      theBackgroundWorker.CancelAsync();
    }
    // theBackgroundWorker_RunWorkerCompleted(System.Object, System.ComponentModel.RunWorkerCompletedEventArgs)

    private void UpdateProgressBar(double dblStep)
    //***
    // Action
    //   - Increment the progress bar with dblStep
    // Called by
    //   - theBackgroundWorker_DoWork(System.Object, System.ComponentModel.DoWorkEventArgs)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230224 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230224 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (prgProcentCompleted.Value == prgProcentCompleted.Maximum)
      {
        prgProcentCompleted.Value = 0;
      }

      prgProcentCompleted.Value += dblStep;
    }
    // UpdateProgressBar(double)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfExampleProgressBar

}
// WPFProgressBar