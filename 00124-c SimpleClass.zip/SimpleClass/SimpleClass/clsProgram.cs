//***
// Action
//   - Testroutine for cpPerson
// Created
//   - CopyPaste � 20240705 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240705 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Reflection;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create an instance of cpPerson
      //   - Define a MemberInfo
      //   - Show the information of the instance of cpPerson
      //   - Loop thru all the members of the instance of cpPerson
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpPerson(string, int, string)
      //   - cpPerson.ShowPerson()
      // Created
      //   - CopyPaste � 20240705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpPerson thecpEmployee = new cpPerson("Buddy Jamsa", 21, "555-1212");
      
      thecpEmployee.ShowPerson();

      Console.WriteLine();
      Console.WriteLine("Members:");

      foreach (MemberInfo theMemberInfo in thecpEmployee.GetType().GetMembers())
      {
        Console.WriteLine(theMemberInfo.Name + " - " + theMemberInfo.MemberType.ToString());
      }
      // in thecpEmployee.GetType().GetMembers()

      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning