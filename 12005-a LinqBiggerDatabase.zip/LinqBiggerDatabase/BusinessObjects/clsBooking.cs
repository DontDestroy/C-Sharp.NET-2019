﻿//***
// Action
//   - Definition of a cpBooking
// Created
//   - CopyPaste – 20230711 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230711 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Text;

namespace CopyPaste.BusinessObjects
{

  public class Booking
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    // A relation towards entity class Flight(the one part)
    // Composite Key: [Key] not possible, see OnModelCreating for solution
    public int FlightNo { get; set; }
    public Flight Flight { get; set; }

    // A relation towards entity class Passenger (the one part)
    // Composite Key: [Key] not possible, see OnModelCreating for solution
    public int PassengerId { get; set; }
    public Passenger Passenger { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // Booking

}
// CopyPaste.BusinessObjects 