//***
// Action
//   - Calculate square root of 2
// Created
//   - CopyPaste � 20210823 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210823 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Windows.Forms;

namespace SquareRoot
{

  class cpSquareRoot
	{

		static void Main()
    //***
    // Action
    //   - Define double as square root of 2
    //   - Show message with result
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - DialogResult System.Windows.Forms.MessageBox.Show(string, string)
    //   - double System.Math.Sqrt(double)
    //   - string double.ToString()
    // Created
    //   - CopyPaste � 20210823 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210823 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      double dblRoot = Math.Sqrt(2);

      MessageBox.Show("The square root of 2 is " + dblRoot.ToString(), "Copy Paste");
    }
    // Main()

	}
  // cpSquareRoot

}
// SquareRoot