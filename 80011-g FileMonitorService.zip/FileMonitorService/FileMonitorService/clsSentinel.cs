//***
// Action
//   - Implementation of cpSentinel
// Created
//   - CopyPaste � 20240718 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240718 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning.Toolkit.Tool
{

  public class cpSentinel
  {

    #region "Constructors / Destructors"

    public cpSentinel(string strObserve)
      //***
      // Action
      //   - Create an instance of cpSentinel with a given string
      //   - Define a file system watcher
      //   - Define a file info (with the given string)
      //   - If file exists
      //     - Watch the specific path and filter (subdirectories not included)
      //   - If not
      //     - If the given string ends with a backslash
      //       - Do nothing
      //     - If not
      //       - Add a backslash to it
      //     - Watch the specific path and filter (subdirectories not included)
      //   - Set specific attributes for the file system watcher
      //   - Add handlers
      //   - Enable the events (commented out, because it is done with a property)
      //   - Define a file to write the information to (append information)
      // Called by
      //   - 
      // Calls
      //   - AddHandlers()
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheFileSystemWatcher = new FileSystemWatcher();
      mfinFileInfo = new FileInfo(strObserve);

      if (mfinFileInfo.Exists)
      {        
        mtheFileSystemWatcher.Path = mfinFileInfo.DirectoryName.ToString();
        mtheFileSystemWatcher.Filter = mfinFileInfo.Name.ToString();
        mtheFileSystemWatcher.IncludeSubdirectories = false;
      }
      else
        // Not mfinFileInfo.Exists
      {

        if (strObserve.EndsWith("\\"))
        {
        }
        else
          // Not strObserve.EndsWith("\")
        {
          string.Concat(strObserve, "\\");
        }
        // strObserve.EndsWith("\")

        try
        {
          mtheFileSystemWatcher.Path = strObserve;
          mtheFileSystemWatcher.Filter = "";
          mtheFileSystemWatcher.IncludeSubdirectories = false;
        }
        catch
        {
        }

      }
      // mfinFileInfo.Exists

      mtheFileSystemWatcher.NotifyFilter = NotifyFilters.FileName |
        NotifyFilters.LastWrite | NotifyFilters.Security | NotifyFilters.CreationTime |
        NotifyFilters.DirectoryName | NotifyFilters.Attributes | NotifyFilters.Size |
        NotifyFilters.LastAccess;

      AddHandlers();

      try
      {
        // mtheFileSystemWatcher.EnableRaisingEvents = true;
        // Will be switched on and off with a property (starting and stopping the service)
      }
      catch
      {
      }

      mstrWriterObserve = new StreamWriter("T:\\ObserverService.txt", true);
    }
    // cpSentinel(string)

    public void Dispose()
      //***
      // Action
      //   - Switch off the events for the file system watcher
      //   - Set the file system watcher to nothing
      //   - Close the log file
      // Called by
      //   - frmFileSentinel.cmdDisable_Click(System.Object, System.EventArgs) Handles cmdDisable.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheFileSystemWatcher.EnableRaisingEvents = false;
      mtheFileSystemWatcher = null;
      mstrWriterObserve.Close();
    }
    // Dispose()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private FileSystemWatcher mtheFileSystemWatcher;
    private StreamWriter mstrWriterObserve;
    private FileInfo mfinFileInfo;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private void cpOnChanged(System.Object theSender, FileSystemEventArgs theFileSystemEventArguments)
      //***
      // Action
      //   - Actions done on the Changed, Created and Deleted event of the file system watcher
      //   - Define the change type of the file System Event argument
      //     - Changed, Created or Deleted
      //   - If there is a change type
      //     - If the file that is changed is the textfile where we write or logging to
      //       - Do nothing (this is to prevent an infinite loop)
      //     - If not
      //       - Write the correct information to the log file
      //   - If not
      //     - Do nothing
      // Called by
      //   - AddHandlers()
      // Calls
      //   - WriteToFile(string)
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strChange = "";

      switch (theFileSystemEventArguments.ChangeType)
      {
        case WatcherChangeTypes.Changed:
          strChange = "Changed";
          break;
        case WatcherChangeTypes.Created:
          strChange = "Created";
          break;
        case WatcherChangeTypes.Deleted:
          strChange = "Deleted";
          break;
        case WatcherChangeTypes.Renamed:
          break;
      }
      // theFileSystemEventArguments.ChangeType

      if (strChange.Length > 0)
      {
        
        if (theFileSystemEventArguments.FullPath.IndexOf("ObserverService.txt") > 0)
        {
        }
        else
          // theFileSystemEventArguments.FullPath.IndexOf("ObserverService.txt") = 0
        {
          WriteToFile("File: " + theFileSystemEventArguments.FullPath + "  " + strChange);
        }
        // theFileSystemEventArguments.FullPath.IndexOf("ObserverService.txt") > 0

      }
      else
        // strChange.Length = 0
      {
      }
      // strChange.Length > 0

    }
    // cpOnChanged(System.Object, FileSystemEventArgs)

    private void cpOnError(System.Object theSource, ErrorEventArgs theErrorEventArguments)
      //***
      // Action
      //   - Actions done on the Error event of the file system watcher
      //   - Write the correct information to the log file
      // Called by
      //   - 
      // Calls
      //   - WriteToFile(string)
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      WriteToFile("ERROR: " + theErrorEventArguments.GetException().Message);
    }
    // cpOnError(System.Object, ErrorEventArgs)

    private void cpOnRenamed(System.Object theSource, RenamedEventArgs theRenamedEventArguments)
      //***
      // Action
      //   - Actions done on the Rename event of the file system watcher
      //   - Write the correct information to the log file
      // Called by
      //   - 
      // Calls
      //   - WriteToFile(string)
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      WriteToFile("File: " + theRenamedEventArguments.OldFullPath + " renamed to " + theRenamedEventArguments.FullPath);
    }
    // cpOnRenamed(System.Object, RenamedEventArgs)

    #endregion

    #region "Sub / Function"

    private void AddHandlers()
      //***
      // Action
      //   - Assign the code to the events of the file system watcher
      //     - Changed, Created, Deleted, Error and Renamed event
      // Called by
      //   - cpSentinel(string)
      // Calls
      //   - cpOnChanged(System.Object, FileSystemEventArgs)
      //   - cpOnError(System.Object, ErrorEventArgs)
      //   - cpOnRenamed(System.Object, RenamedEventArgs)
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheFileSystemWatcher.Changed += new FileSystemEventHandler(cpOnChanged);
      mtheFileSystemWatcher.Created += new FileSystemEventHandler(cpOnChanged);
      mtheFileSystemWatcher.Deleted += new FileSystemEventHandler(cpOnChanged);
      mtheFileSystemWatcher.Error += new ErrorEventHandler(cpOnError);
      mtheFileSystemWatcher.Renamed += new RenamedEventHandler(cpOnRenamed);
    }
		// AddHandlers()

    public void StartLogging()
      //***
      // Action
      //   - Enable the events
      // Called by
      //   - cpFileMonitorService.OnStart(string[])
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheFileSystemWatcher.EnableRaisingEvents = true;
    }
    // StartLogging()

    public void StopLogging()
      //***
      // Action
      //   - Enable the events
      // Called by
      //   - cpFileMonitorService.OnStop()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheFileSystemWatcher.EnableRaisingEvents = false;
    }
    // StopLogging()

    private void WriteToFile(string strObserve)
      //***
      // Action
      //   - Write the content of strObserve to the log file
      //   - Set a Date and time
      //   - Write that together with the observe information to the file
      //   - Flush the info
      // Called by
      //   - cpOnChanged(System.Object, FileSystemEventArgs)
      //   - cpOnError(System.Object, ErrorEventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strRightNow = DateTime.Now.ToLongDateString() + " " + DateTime.Now.ToLongTimeString();

      try
      {
        mstrWriterObserve.WriteLine(strRightNow + " " + strObserve);
        mstrWriterObserve.Flush();
      }
      catch
      {
      }

    }
    // WriteToFile(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpSentinel

}
// CopyPaste.Learning.Toolkit.Tool