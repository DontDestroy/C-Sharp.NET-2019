﻿//***
// Action
//   - A definition of a point (structure)
// Created
//   - CopyPaste – 20260530 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260530 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public struct structContainer
  {

    #region "Constructors / Destructors"

    public structContainer(structPoint cpPoint)
    //***
    // Action
    //   - Basic constructor with a given structPoint
    // Called by
    //   - cpProgram.DemoStructContainer()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      thePoint = cpPoint;
    }
    // structContainer(structPoint)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public structPoint thePoint;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public double Distance()
    //***
    // Action
    //   - Calculate the distance of a current structPoint
    // Called by
    //   - cpProgram.DemoStructContainer()
    // Calls
    //   - int structPoint.X (Get)
    //   - int structPoint.Y (Get)
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return Math.Sqrt(thePoint.X * thePoint.X + thePoint.Y * thePoint.Y);
    }
    // double Distance()

    public double Distance(in structPoint theGivenPoint)
    //***
    // Action
    //   - Calculate the distance of a given structPoint
    // Called by
    //   - cpProgram.DemoStructContainer()
    // Calls
    //   - int structPoint.X (Get)
    //   - int structPoint.Y (Get)
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return Math.Sqrt(theGivenPoint.X * theGivenPoint.X + theGivenPoint.Y * theGivenPoint.Y);
    }
    // double Distance(structPoint)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // structContainer

}
// CopyPaste.Learning