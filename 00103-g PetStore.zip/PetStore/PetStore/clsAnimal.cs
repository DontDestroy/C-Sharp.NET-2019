//***
// Action
//   - A pet store, the definition of an animal (base class)
//   - Working with properties (Get and Set) and methods in several classes, that can be reused
// Created
//   - CopyPaste � 20220316 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20220316 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace CopyPaste.Pet
{

  public class cpAnimal
	{

    #region "Constructors / Destructors"

    public cpAnimal()
      //***
      // Action
      //   - Creating an instance of cpAnimals with parameters set to default
      // Called by
      //   - CopyPaste.Pet.cpPet()
      //   - cpAnimal(string, int)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      mstrSpecies = "";
      mstrBreed = "";
      mstrColor = "";
      mstrName = "";
      mstrGender = "";
      mdecCost = 0;
      mintLegs = 0;
    }
    // cpAnimal()

    public cpAnimal(string strSpecies, int intLegs) : this()
      //***
      // Action
      //   - Creating an instance of cpAnimals with given parameters
      // Called by
      //   - CopyPaste.Pet.cpPet(string, int)
      //   - CopyPaste.Pet.Bird.cpBird()
      // Calls
      //   - cpAnimal()
      //   - Legs(int) (Set)
      //   - Species(string) (Set)
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      Species = strSpecies;
      Legs = intLegs;
    }
    // cpAnimal(string, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    private decimal mdecCost;
    private int mintLegs;
    private string mstrBreed;
    private string mstrColor;
    private string mstrGender;
    private string mstrName;
    private string mstrSpecies;
  
    #endregion

    #region "Properties"

    public string Breed
    {
    
      get
        //***
        // Action Get
        //   - Return the breed of the animal (mstrBreed)
        // Called by
        //   - cpProgram.FillArray()
        //   - frmPetStore.Display(CopyPaste.Pet.cpPet)
        //   - frmPetStore.frmPetStore_Load(System.Object, System.EventArgs) Handles this.Load
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        return mstrBreed;
      }
      // string Breed (Get)

      set
        //***
        // Action Set
        //   - Set the breed of the animal (mstrBreed becomes strValue)
        // Called by
        //   - CopyPaste.Pet.Bird.cpCockatiel()
        //   - CopyPaste.Pet.Bird.cpCockatiel(string, string)
        //   - CopyPaste.Pet.Bird.cpParakeet()
        //   - CopyPaste.Pet.Bird.cpParakeet(string, string)
        //   - CopyPaste.Pet.Cat.cpManx()
        //   - CopyPaste.Pet.Cat.cpManx(string, string)
        //   - CopyPaste.Pet.Cat.cpSiamese()
        //   - CopyPaste.Pet.Cat.cpSiamese(string, string)
        //   - CopyPaste.Pet.Dog.cpGreatDane()
        //   - CopyPaste.Pet.Dog.cpGreatDane(string, string)
        //   - CopyPaste.Pet.Dog.cpMiniDoxen()
        //   - CopyPaste.Pet.Dog.cpMiniDoxen(string, string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        mstrBreed = value;
      }
      // Breed(string) (Set)

    }
    // string Breed

    public string Coloration
    {
    
      get
        //***
        // Action Get
        //   - Return the coloration of the animal (mstrColor)
        // Called by
        //   - frmPetStore.Display(CopyPaste.Pet.cpPet)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        return mstrColor;
      }
      // string Coloration (Get)

      set
        //***
        // Action Set
        //   - Set the coloration of the animal (mstrColor becomes strValue)
        // Called by
        //   - CopyPaste.Pet.Bird.cpCockatiel(string, string)
        //   - CopyPaste.Pet.Bird.cpParakeet(string, string)
        //   - CopyPaste.Pet.Cat.cpManx(string, string)
        //   - CopyPaste.Pet.Cat.cpSiamese(string, string)
        //   - CopyPaste.Pet.Dog.cpMiniDoxen(string, string)
        //   - CopyPaste.Pet.Dog.cpGreatDane(string, string)
        //   - cpProgram.FillArray()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        mstrColor = value;
      }
      // Coloration(string) (Set)

    }
    // string Coloration

    public decimal Cost
    {
    
      get
        //***
        // Action Get
        //   - Return the cost of the animal (mdecCost)
        // Called by
        //   - frmPetStore.Display(CopyPaste.Pet.cpPet)
        //   - frmPetStore.frmPetStore_Load(System.Object, System.EventArgs) Handles this.Load
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        return mdecCost;
      }

      set
        //***
        // Action Set
        //   - Set the cost of the animal (mdecCost becomes decValue)
        // Called by
        //   - CopyPaste.Pet.Bird.cpCockatiel()
        //   - CopyPaste.Pet.Bird.cpCockatiel(string, string)
        //   - CopyPaste.Pet.Bird.cpParakeet()
        //   - CopyPaste.Pet.Bird.cpParakeet(string, string)
        //   - CopyPaste.Pet.Cat.cpManx()
        //   - CopyPaste.Pet.Cat.cpManx(string, string)
        //   - CopyPaste.Pet.Cat.cpSiamese()
        //   - CopyPaste.Pet.Cat.cpSiamese(string, string)
        //   - CopyPaste.Pet.Dog.cpMiniDoxen()
        //   - CopyPaste.Pet.Dog.cpMiniDoxen(string, string)
        //   - CopyPaste.Pet.Dog.cpGreatDane()
        //   - CopyPaste.Pet.Dog.cpGreatDane(string, string)
        //   - cpProgram.FillArray()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        mdecCost = value;
      }

    }
    // decimal Cost

    public string Gender
    {

      get
        //***
        // Action Get
        //   - Return the gender of the animal (mstrGender)
        // Called by
        //   - frmPetStore.Display(CopyPaste.Pet.cpPet)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        return mstrGender;
      }
      // string Gender (Get)

      set
        // Action Set
        //   - Set the gender of the animal (mstrGender becomes strValue)
        // Called by
        //   - cpProgram.FillArray()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        mstrGender = value;
      }
      // Gender(string) (Set)

    }
    // string Gender

    public int Legs
    {

      get
        //***
        // Action Get
        //   - Return the number of legs of the animal (mlngLegs)
        // Called by
        //   - frmPetStore.Display(CopyPaste.Pet.cpPet)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        return mintLegs;
      }
      // int Legs (Get)

      set
        //***
        // Action Set
        //   - Set the number of legs of the animal (mlngLegs becomes lngValue)
        // Called by
        //    - cpAnimal(string, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        mintLegs = value;
      }
      // Legs(int) (Set)

    }
    // int Legs
    
    public string Name
    {
    
      get
        //***
        // Action Get
        //   - Return the name of the animal (mstrName)
        // Called by
        //   - string CopyPaste.Pet.Bird.cpCockatiel.Speak()
        //   - string CopyPaste.Pet.Bird.cpParakeet.Speak()
        //   - string CopyPaste.Pet.Cat.cpManx.Speak()
        //   - string CopyPaste.Pet.Cat.cpSiamese.Speak()
        //   - string CopyPaste.Pet.cpBird.Play()
        //   - string CopyPaste.Pet.cpCat.Play()
        //   - string CopyPaste.Pet.cpDog.Play()
        //   - string CopyPaste.Pet.Dog.cpGreatDane.Speak()
        //   - string CopyPaste.Pet.Dog.cpMiniDoxen.Speak()
        //   - frmPetStore.Display(CopyPaste.Pet.cpPet)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        return mstrName;
      }
      // string Name (Get)  
      
      set
        //***
        // Action Set
        //   - Set the name of the animal (mstrName becomes strValue)
        // Called by
        //   - CopyPaste.Pet.cpBird(string)
        //   - CopyPaste.Pet.cpCat(string)
        //   - CopyPaste.Pet.cpDog(string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        mstrName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    public string Species
    {
    
      get
        //***
        // Action Get
        //   - Return the species of the animal (mstrSpecies)
        // Called by
        //   - frmPetStore.Display(CopyPaste.Pet.cpPet)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        return mstrSpecies;
      }
      // string Species (Get)

      set
        //***
        // Action Set
        //   - Set the species of the animal (mstrSpecies becomes strValue)
        // Called by
        //   - cpAnimal(string, int)
        //   - cpProgram.FillArray()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220316 � VVDW
        // Changed
        //   - Organisation � yyyymmdd � Initials of programmer � What changed
        // Tested
        //   - CopyPaste � 20220316 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - List of actions that can be added to the functionality
        //***
      {
        mstrSpecies = value;
      }
      // Species(string) (Set)

    }
    // string Species

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    public virtual string Play()
      //***
      // Action
      //   - Write a line to the console with "CopyPaste.Pet.cpAnimal.Play"
      //   - Return empty string
      // Called by
      //   - frmPetStore.cmdPlay_Click(System.Object, System.EventArgs) Handles cmdPlay.Click
      //   - Overwritten by string CopyPaste.Pet.cpBird.Play()
      //   - Overwritten by string CopyPaste.Pet.cpCat.Play()
      //   - Overwritten by string CopyPaste.Pet.cpDog.Play()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      Console.WriteLine("CopyPaste.Pet.cpAnimal.Play");
      return "";
    }
    // string Play()

    public virtual string Speak()
      //***
      // Action
      //   - Write a line to the console with "CopyPaste.Pet.cpAnimal.Speak"
      //   - Return empty string
      // Called by
      //   - frmPetStore.cmdSpeak_Click(System.Object, System.EventArgs) Handles cmdSpeak.Click
      //   - Overwritten by string CopyPaste.Pet.Bird.cpCockatiel.Speak()
      //   - Overwritten by string CopyPaste.Pet.Bird.cpParakeet.Speak()
      //   - Overwritten by string CopyPaste.Pet.Cat.cpManx.Speak()
      //   - Overwritten by string CopyPaste.Pet.Cat.cpSiamese.Speak()
      //   - Overwritten by string CopyPaste.Pet.Dog.cpGreatDane.Speak()
      //   - Overwritten by string CopyPaste.Pet.Dog.cpMiniDoxen.Speak()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      Console.WriteLine("CopyPaste.Pet.cpAnimal.Speak");
      return "";
    }
    // string Speak()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpAnimal

}
// CopyPaste.Pet