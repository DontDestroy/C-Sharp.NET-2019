//***
// Action
//   - Check if a directory exists
//     - If not, create it
// Created
//   - CopyPaste � 20240715 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240715 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create some directories, if they don't exist
      //   - Try
      //     - If T:\Sample01 exist
      //       - Show message
      //     - If not
      //       - Create it
      //     - If T:\Temp\Sample02 exist
      //       - Show message
      //     - If not
      //       - Create it
      //   - On error
      //     - Show message
      //     - Show exception message
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240715 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Creating directories...");

      try
      {
        
        if (Directory.Exists("T:\\Sample01"))
        {
          Console.WriteLine("T:\\Sample01 already exists");
        }
        else
          // Not Directory.Exists("T:\Sample01")
        {
          Directory.CreateDirectory("T:\\Sample01");
        }
        // Directory.Exists("T:\Sample01")
        
        if (Directory.Exists("T:\\Temp\\Sample02"))
        {
          Console.WriteLine("T:\\Temp\\Sample02 already exists");
        }
        else
          // Not Directory.Exists("T:\Temp\Sample02")
        {
          Directory.CreateDirectory("T:\\Temp\\Sample02");
        }
        // Directory.Exists("T:\Temp\Sample02")

        Console.WriteLine("Directories created");
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error creating directory");
        Console.WriteLine("Error: {0}", theException.Message);
      }
      finally
      {
      }

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning