<%@ Page Language="C#" %>

<html>
<head>
  <title>Browser Snoop</title>
</head>
<body>
  <center>
    <h1>Browser Capabilities</h1>
  </center>
  <hr />

  <% 

    Response.Write("ActiveX Controls: " + Request.Browser.ActiveXControls + "<br>");
    Response.Write("AOL: " + Request.Browser.AOL + "<br>");
    Response.Write("Background Sounds: " + Request.Browser.BackgroundSounds + "<br>");
    Response.Write("Beta: " + Request.Browser.Beta + "<br>");
    Response.Write("CDF: " + Request.Browser.CDF + "<br>");
    Response.Write("CLR Version: " + Request.Browser.ClrVersion.ToString() + "<br>");
    Response.Write("Cookies: " + Request.Browser.Cookies + "<br>");
    Response.Write("Crawler: " + Request.Browser.Crawler + "<br>");
    Response.Write("ECMA Script Version: " + Request.Browser.EcmaScriptVersion.ToString() + "<br>");
    Response.Write("Frames: " + Request.Browser.Frames + "<br>");
    Response.Write("Java Applets: " + Request.Browser.JavaApplets + "<br>");
    Response.Write("JavaScript: " + Request.Browser.JavaScript + "<br>");
    Response.Write("Major Version: " + Request.Browser.MajorVersion + "<br>");
    Response.Write("Minor Version: " + Request.Browser.MinorVersion + "<br>");
    Response.Write("MS DOM Version: " + Request.Browser.MSDomVersion.ToString() + "<br>");
    Response.Write("Platform: " + Request.Browser.Platform + "<br>");
    Response.Write("Tables: " + Request.Browser.Tables + "<br>");
    Response.Write("Tag Writer: " + Request.Browser.TagWriter.ToString() + "<br>");
    Response.Write("Type: " + Request.Browser.Type + "<br>");
    Response.Write("VBScript: " + Request.Browser.VBScript + "<br>");
    Response.Write("W3C DOM Version: " + Request.Browser.W3CDomVersion.ToString() + "<br>");
    Response.Write("Win16: " + Request.Browser.Win16 + "<br>");
    Response.Write("Win32: " + Request.Browser.Win32 + "<br>");

  %>

</body>
</html>
