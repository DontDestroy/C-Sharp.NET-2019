//***
// Action
//   - Testroutine of cpAccount, cpSavingAccount and cpUsingAccount
// Created
//   - CopyPaste � 20240105 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240105 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

	public class cpProgram
	{
	
		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public static void Main()
			//***
			// Action
			//   - Create a correct Belgian account
			//   - Show the information
			//   - Add 100 to the account
			//   - Show the information
			//   - Create a correct Belgian saving account
			//   - Show the information
			//   - Add 125 to the account
			//   - Show the information
			//   - Create a correct Belgian using account
			//   - Show the information
			//   - Add 1000 to the account
			//   - Show the information
			//   - Create a wrong Belgian account (bankaccount is wrong)
			//   - Create a wrong Belgian account (date is wrong)
			//   - Create a wrong Belgian account (bankaccount and date are wrong)
			//   - Create a wrong Belgian saving account (intrest rate is wrong)
			//   - Create a wrong Belgian using account (maximum credit is wrong)
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - cpAccount(long, decimal, DateTime)
			//   - cpSavingAccount(long, decimal, DateTime, decimal)
			//   - cpUsingAccount(long, decimal, DateTime, decimal)
			//   - cpAccount.Show()
			//   - cpSavingAccount.Show()
			//   - cpUsingAccount.Show()
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - Not all properties are tested in this routine
			//***
	  {

			try
			{
				// Happy flow
				cpAccount thecpAccount = new cpAccount(747524091936, 0, new DateTime(2004, 12, 17));
				cpSavingAccount thecpSavingAccount = new cpSavingAccount(83179377453, 0, new DateTime(2004, 12, 18), 4.5M);
				cpUsingAccount thecpUsingAccount = new cpUsingAccount(63154756360, 0, new DateTime(2004, 12, 19), -1000);
				cpAccount thecpWrongAccount;
				cpAccount thecpWrongSavingAccount;
				cpAccount thecpWrongUsingAccount;
				thecpAccount.Show();
				thecpAccount.Add(100);
				thecpAccount.Show();
				
				Console.WriteLine("-----");
				Console.WriteLine();
				
				thecpSavingAccount.Show();
				thecpSavingAccount.Add(125);
				thecpSavingAccount.Show();
				
				Console.WriteLine("-----");
				Console.WriteLine();

				thecpUsingAccount.Show();
				thecpUsingAccount.Add(1000);
				thecpUsingAccount.Show();

				// Not so happy flow
				thecpWrongAccount = new cpAccount(123456789012, 0, new DateTime(2004, 12, 17));
				thecpWrongAccount = new cpAccount(747524091936, 0, new DateTime(1830, 1, 1));
				thecpWrongAccount = new cpAccount(123456789012, 0, new DateTime(1830, 1, 1));
				thecpWrongSavingAccount = new cpSavingAccount(83179377453, 0, new DateTime(2004, 12, 18), -4.5M);
				thecpWrongUsingAccount = new cpUsingAccount(63154756360, 0, new DateTime(2004, 12, 19), 1000);
			}			
			catch (Exception theException)
			{
				Console.WriteLine(theException.Message);
			}
			finally
			{
				Console.ReadLine();
			}

		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.Learning