﻿//***
// Action
//   - A definition of a Getter
// Created
//   - CopyPaste – 20251104 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251104 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpGetter : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpGetter(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpGetter starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    // Called by
    //   - cpGetter(int, int, Directions.Direction, int)
    //   - cpProgram.GetterPutter01()
    //   - cpProgram.GetterPutter02()
    //   - cpProgram.GetterPutter03()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpGetter(int, int, Directions.Direction, int, Color) 

    public cpGetter(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpGetter starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpGetter(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpGetter(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override void move()
    //***
    // Action
    //   - Pick all the beepers
    //   - Move one forward
    // Called by
    //   - cpProgram.GetterPutter01()
    //   - cpProgram.GetterPutter02()
    //   - cpProgram.GetterPutter03()
    // Calls
    //   - cpCopyPasteRobot.PickAllBeepers()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      PickAllBeepers();
      base.move();
    }
    // move()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpGetter

}
// cpKarelTheRobot