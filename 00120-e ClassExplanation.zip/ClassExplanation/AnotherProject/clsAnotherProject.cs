//***
// Action
//   - Implementation of cpAnotherProject
// Created
//   - CopyPaste � 20240618 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240618 � VVDW
// Proposal (To Do)
//   - References to other project are not documented
//***

using System;

namespace CopyPaste.Learning
{

  public class cpAnotherProject
  {

    //#region "Constructors / Destructors"
    //#endregion

    #region "Designer"

    internal class ClassInternal
    {

      #region "Fields"
      
      public string strClassInternal = "In Class Internal Other Project";
      
      #endregion

    }
    // ClassInternal

    private class ClassPrivate
    {

      #region "Fields"
      
      public string strClassPrivate = "In Class Private Other Project";
    
      #endregion

    }
    // ClassPrivate

    protected class ClassProtected
    {

      #region "Fields"
      
      public string strClassProtected = "In Class Protected Other Project";

      #endregion

    }
    // ClassProtected

    protected internal class ClassProtectedInternal
    {

      #region "Fields"
      
      public string strClassProtectedInternal = "In Class Protected Internal Other Project";

      #endregion

    }
    // ClassProtectedInternal

    public class ClassPublic
    {

      #region "Fields"
      
      public string strClassPublic = "In Class Public Other Project";

      #endregion
    
    }
    // ClassPublic

    #endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    public void Test()
      //***
      // Action
      //   - Show the fields of the created classes
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      ClassInternal theClassInternal = new ClassInternal();
      ClassPrivate theClassPrivate = new ClassPrivate();
      ClassProtected theClassProtected = new ClassProtected();
      ClassProtectedInternal theClassProtectedInternal = new ClassProtectedInternal();
      ClassPublic theClassPublic = new ClassPublic();

      Console.WriteLine(theClassPublic.strClassPublic);
      Console.WriteLine(theClassInternal.strClassInternal);
      Console.WriteLine(theClassPrivate.strClassPrivate);
      Console.WriteLine(theClassProtected.strClassProtected);
      Console.WriteLine(theClassProtectedInternal.strClassProtectedInternal);
      Console.ReadLine();
    }
    // Test()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpAnotherProject

}
// CopyPaste.Learning