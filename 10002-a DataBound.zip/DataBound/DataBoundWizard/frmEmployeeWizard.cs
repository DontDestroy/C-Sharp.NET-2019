﻿//***
// Action
//   - Binding data to controls on a form
// Created
//   - CopyPaste – 20210628 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210628 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System.Windows.Forms;

namespace DataBoundWizard
{

  public partial class frmEmployeeWizard : Form
  {

    #region "Constructors / Destructors"

    public frmEmployeeWizard()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Fill TableAdapter with DataSet information
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210628 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210628 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***

    {
      InitializeComponent();
      this.tbaEmployee.Fill(this.dsEmployee.tblCPEmployee);
    }
    // frmEmployeeWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmEmployeeWizard

}
//DataBoundWizard
