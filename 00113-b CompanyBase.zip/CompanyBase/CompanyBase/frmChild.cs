//***
// Action
//   - Using visual inheritance
//   - This form is the child
// Created
//   - CopyPaste � 20240218 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240218 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.Company
{

  public class frmChild: frmCompany
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox TextBox2;
    internal System.Windows.Forms.TextBox TextBox1;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmChild));
      this.TextBox2 = new System.Windows.Forms.TextBox();
      this.TextBox1 = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // TextBox2
      // 
      this.TextBox2.Location = new System.Drawing.Point(152, 136);
      this.TextBox2.Name = "TextBox2";
      this.TextBox2.TabIndex = 8;
      this.TextBox2.Text = "TextBox2";
      // 
      // TextBox1
      // 
      this.TextBox1.Location = new System.Drawing.Point(152, 96);
      this.TextBox1.Name = "TextBox1";
      this.TextBox1.TabIndex = 7;
      this.TextBox1.Text = "TextBox1";
      // 
      // frmChild
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(312, 273);
      this.Controls.Add(this.TextBox2);
      this.Controls.Add(this.TextBox1);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmChild";
      this.Load += new System.EventHandler(this.frmChild_Load);
      this.Controls.SetChildIndex(this.TextBox1, 0);
      this.Controls.SetChildIndex(this.TextBox2, 0);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmChild'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmChild()
      //***
      // Action
      //   - Create instance of 'frmChild'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmChild()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override void cmdHelp_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a messagebox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strMessage = "Context Sensitive Help";
      
      MessageBox.Show(strMessage, "Copy Paste - Child Form", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // cmdHelp_Click(System.Object, System.EventArgs) Hanldes cmdHelp.Click
   
    #endregion

    #region "Controls"

    private void frmChild_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a messagebox
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show("Load Child Form", "Copy Paste");
    }
    // frmChild_Load(System.Object theSender, System.EventArgs theEventArguments) Handles this.Load


    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmChild
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmChild());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmChild

}
// CopyPaste.Learning.Company