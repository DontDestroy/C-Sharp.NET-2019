//***
// Action
//   - Showing the startscreen of the application (frmNetwork)
// Created
//   - CopyPaste � 20230614 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230614 � VVDW
// Proposal (To Do)
//   - This example is far from finished
//   - It gives an idea of what is possible
//   - When called, you don't see who is calling you
//   - When called, another can also be calling you (you should have a "busy" indication)
//   - A lot of more ideas can be implemented
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.TelecomNetwork
{

  static class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThread]
    static void Main()
    //***
    // Action
    //   - Show the startscreen for a cpNetwork
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmNetwork()
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***

    {
      Application.SetHighDpiMode(HighDpiMode.SystemAware);
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run(new frmNetwork());
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.TelecomNetwork