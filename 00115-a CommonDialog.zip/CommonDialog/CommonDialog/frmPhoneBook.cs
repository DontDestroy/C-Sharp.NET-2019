//***
// Action
//   - A demo of a lot of common dialogs and testroutine for cpPerson
// Created
//   - CopyPaste � 20240610 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240610 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPhoneBook: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdAdd;
    internal System.Windows.Forms.Button cmdPrint;
    internal System.Windows.Forms.Button cmdPrintPreview;
    internal System.Windows.Forms.OpenFileDialog dlgFileOpen;
    internal System.Windows.Forms.ColorDialog dlgColor;
    internal System.Windows.Forms.Button cmdColor;
    internal System.Windows.Forms.SaveFileDialog dlgFileSave;
    internal System.Windows.Forms.Button cmdFont;
    internal System.Windows.Forms.Button cmdOpen;
    internal System.Windows.Forms.PrintPreviewDialog dlgPrintPreview;
    internal System.Windows.Forms.Button cmdSave;
    internal System.Windows.Forms.Button cmdPageSetup;
    internal System.Windows.Forms.TextBox txtPhoneNumber;
    internal System.Drawing.Printing.PrintDocument prndocPerson;
    internal System.Windows.Forms.FontDialog dlgFont;
    internal System.Windows.Forms.TextBox txtName;
    internal System.Windows.Forms.Label lblName;
    internal System.Windows.Forms.PageSetupDialog dlgPageSetup;
    internal System.Windows.Forms.Label lblPhoneNumber;
    internal System.Windows.Forms.ListBox lstPersons;
    internal System.Windows.Forms.PrintDialog dlgPrint;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPhoneBook));
      this.cmdAdd = new System.Windows.Forms.Button();
      this.cmdPrint = new System.Windows.Forms.Button();
      this.cmdPrintPreview = new System.Windows.Forms.Button();
      this.dlgFileOpen = new System.Windows.Forms.OpenFileDialog();
      this.dlgColor = new System.Windows.Forms.ColorDialog();
      this.cmdColor = new System.Windows.Forms.Button();
      this.dlgFileSave = new System.Windows.Forms.SaveFileDialog();
      this.cmdFont = new System.Windows.Forms.Button();
      this.cmdOpen = new System.Windows.Forms.Button();
      this.dlgPrintPreview = new System.Windows.Forms.PrintPreviewDialog();
      this.cmdSave = new System.Windows.Forms.Button();
      this.cmdPageSetup = new System.Windows.Forms.Button();
      this.txtPhoneNumber = new System.Windows.Forms.TextBox();
      this.prndocPerson = new System.Drawing.Printing.PrintDocument();
      this.dlgFont = new System.Windows.Forms.FontDialog();
      this.txtName = new System.Windows.Forms.TextBox();
      this.lblName = new System.Windows.Forms.Label();
      this.dlgPageSetup = new System.Windows.Forms.PageSetupDialog();
      this.lblPhoneNumber = new System.Windows.Forms.Label();
      this.lstPersons = new System.Windows.Forms.ListBox();
      this.dlgPrint = new System.Windows.Forms.PrintDialog();
      this.SuspendLayout();
      // 
      // cmdAdd
      // 
      this.cmdAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdAdd.Location = new System.Drawing.Point(166, 272);
      this.cmdAdd.Name = "cmdAdd";
      this.cmdAdd.Size = new System.Drawing.Size(112, 48);
      this.cmdAdd.TabIndex = 25;
      this.cmdAdd.Text = "&Add";
      this.cmdAdd.Click += new System.EventHandler(this.cmdAdd_Click);
      // 
      // cmdPrint
      // 
      this.cmdPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdPrint.Location = new System.Drawing.Point(206, 168);
      this.cmdPrint.Name = "cmdPrint";
      this.cmdPrint.TabIndex = 23;
      this.cmdPrint.Text = "Pr&int";
      this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
      // 
      // cmdPrintPreview
      // 
      this.cmdPrintPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdPrintPreview.Location = new System.Drawing.Point(206, 136);
      this.cmdPrintPreview.Name = "cmdPrintPreview";
      this.cmdPrintPreview.TabIndex = 22;
      this.cmdPrintPreview.Text = "P&review";
      this.cmdPrintPreview.Click += new System.EventHandler(this.cmdPrintPreview_Click);
      // 
      // dlgFileOpen
      // 
      this.dlgFileOpen.Filter = "Text Files|*.txt";
      // 
      // cmdColor
      // 
      this.cmdColor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdColor.Location = new System.Drawing.Point(206, 104);
      this.cmdColor.Name = "cmdColor";
      this.cmdColor.TabIndex = 21;
      this.cmdColor.Text = "&Color";
      this.cmdColor.Click += new System.EventHandler(this.cmdColor_Click);
      // 
      // dlgFileSave
      // 
      this.dlgFileSave.Filter = "Text Files|*.txt";
      // 
      // cmdFont
      // 
      this.cmdFont.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdFont.Location = new System.Drawing.Point(206, 72);
      this.cmdFont.Name = "cmdFont";
      this.cmdFont.TabIndex = 20;
      this.cmdFont.Text = "&Font";
      this.cmdFont.Click += new System.EventHandler(this.cmdFont_Click);
      // 
      // cmdOpen
      // 
      this.cmdOpen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdOpen.Location = new System.Drawing.Point(206, 40);
      this.cmdOpen.Name = "cmdOpen";
      this.cmdOpen.TabIndex = 19;
      this.cmdOpen.Text = "&Open";
      this.cmdOpen.Click += new System.EventHandler(this.cmdOpen_Click);
      // 
      // dlgPrintPreview
      // 
      this.dlgPrintPreview.AutoScrollMargin = new System.Drawing.Size(0, 0);
      this.dlgPrintPreview.AutoScrollMinSize = new System.Drawing.Size(0, 0);
      this.dlgPrintPreview.ClientSize = new System.Drawing.Size(400, 300);
      this.dlgPrintPreview.Enabled = true;
      this.dlgPrintPreview.Icon = ((System.Drawing.Icon)(resources.GetObject("dlgPrintPreview.Icon")));
      this.dlgPrintPreview.Location = new System.Drawing.Point(22, -29);
      this.dlgPrintPreview.MinimumSize = new System.Drawing.Size(375, 250);
      this.dlgPrintPreview.Name = "dlgPrintPreview";
      this.dlgPrintPreview.TransparencyKey = System.Drawing.Color.Empty;
      this.dlgPrintPreview.Visible = false;
      // 
      // cmdSave
      // 
      this.cmdSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdSave.Location = new System.Drawing.Point(206, 8);
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.TabIndex = 18;
      this.cmdSave.Text = "&Save";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // cmdPageSetup
      // 
      this.cmdPageSetup.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdPageSetup.Location = new System.Drawing.Point(206, 200);
      this.cmdPageSetup.Name = "cmdPageSetup";
      this.cmdPageSetup.TabIndex = 24;
      this.cmdPageSetup.Text = "Pa&ge Setup";
      this.cmdPageSetup.Click += new System.EventHandler(this.cmdPageSetup_Click);
      // 
      // txtPhoneNumber
      // 
      this.txtPhoneNumber.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.txtPhoneNumber.Location = new System.Drawing.Point(60, 304);
      this.txtPhoneNumber.Name = "txtPhoneNumber";
      this.txtPhoneNumber.TabIndex = 17;
      this.txtPhoneNumber.Text = "";
      // 
      // prndocPerson
      // 
      this.prndocPerson.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.prndocPerson_PrintPage);
      // 
      // txtName
      // 
      this.txtName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.txtName.Location = new System.Drawing.Point(60, 272);
      this.txtName.Name = "txtName";
      this.txtName.TabIndex = 15;
      this.txtName.Text = "";
      // 
      // lblName
      // 
      this.lblName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.lblName.Location = new System.Drawing.Point(12, 272);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(48, 24);
      this.lblName.TabIndex = 14;
      this.lblName.Text = "&Name:";
      // 
      // lblPhoneNumber
      // 
      this.lblPhoneNumber.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.lblPhoneNumber.Location = new System.Drawing.Point(12, 304);
      this.lblPhoneNumber.Name = "lblPhoneNumber";
      this.lblPhoneNumber.Size = new System.Drawing.Size(48, 24);
      this.lblPhoneNumber.TabIndex = 16;
      this.lblPhoneNumber.Text = "&Phone:";
      // 
      // lstPersons
      // 
      this.lstPersons.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.lstPersons.Location = new System.Drawing.Point(14, 8);
      this.lstPersons.Name = "lstPersons";
      this.lstPersons.Size = new System.Drawing.Size(182, 251);
      this.lstPersons.Sorted = true;
      this.lstPersons.TabIndex = 13;
      this.lstPersons.DoubleClick += new System.EventHandler(this.lstPersons_DoubleClick);
      // 
      // frmPhoneBook
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 367);
      this.Controls.Add(this.cmdSave);
      this.Controls.Add(this.cmdPageSetup);
      this.Controls.Add(this.txtPhoneNumber);
      this.Controls.Add(this.txtName);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.lblPhoneNumber);
      this.Controls.Add(this.lstPersons);
      this.Controls.Add(this.cmdAdd);
      this.Controls.Add(this.cmdPrint);
      this.Controls.Add(this.cmdPrintPreview);
      this.Controls.Add(this.cmdColor);
      this.Controls.Add(this.cmdFont);
      this.Controls.Add(this.cmdOpen);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.Name = "frmPhoneBook";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Phone book";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPhoneBook'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPhoneBook()
      //***
      // Action
      //   - Create instance of 'frmPhoneBook'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPhoneBook()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdAdd_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a cpPerson with the information typed
      //   - Add the cpPerson to the list of persons
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpPerson(string, string)
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lstPersons.Items.Add(new cpPerson(txtName.Text, txtPhoneNumber.Text));
    }
    // cmdAdd_Click(System.Object, System.EventArgs) Handles cmdAdd.Click

    
    private void cmdColor_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a color dialog
      //   - When OK is clicked, the list of persons gets the choosen color as forecolor
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (dlgColor.ShowDialog() == DialogResult.OK)
      {
        lstPersons.ForeColor = dlgColor.Color;
      }
      else
        // dlgColor.ShowDialog <> DialogResult.OK
      {
      }
      // dlgColor.ShowDialog = DialogResult.OK
    
    }
    // cmdColor_Click(System.Object, System.EventArgs) Handles cmdColor.Click
    
    private void cmdFont_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a font dialog
      //   - When OK is clicked, the list of persons gets the choosen font
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    { 
          
      if (dlgFont.ShowDialog() == DialogResult.OK)
      {
        lstPersons.Font = dlgFont.Font;
      }
      else
        // dlgFont.ShowDialog <> DialogResult.OK
      {
      }
      // dlgFont.ShowDialog = DialogResult.OK

    }
    // cmdFont_Click(System.Object, System.EventArgs) Handles cmdFont.Click

    private void cmdOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a file open dialog
      //   - The choosen file is defined in a stream reader
      //   - The list is cleared
      //   - A line is read
      //   - When the line is not nothing
      //     - Where is a ":" in the line
      //     - Before the ":" it is the name
      //     - After the ":" is is the phone number
      //     - A cpPerson is created
      //     - The cpPerson is added to the list
      //     - The next line is read
      //   - Stream reader is closed
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpPerson.New(String, String)
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (dlgFileOpen.ShowDialog() == DialogResult.OK)
      {
        string strLine;
        StreamReader strReader = new StreamReader(dlgFileOpen.OpenFile());

        lstPersons.Items.Clear();
        strLine = strReader.ReadLine();

        while (strLine != null)
        {
          int lngPosition = strLine.IndexOf(':');
          cpPerson thecpPerson = new cpPerson(strLine.Substring(0, lngPosition), strLine.Substring(lngPosition + 1));

          lstPersons.Items.Add(thecpPerson);
          strLine = strReader.ReadLine();
        }
        // strLine = null

        strReader.Close();
      }
      else
      // dlgFileOpen.ShowDialog <> DialogResult.OK
      {
      }
      // dlgFileOpen.ShowDialog = DialogResult.OK

    }
    // cmdOpen_Click(System.Object, System.EventArgs) Handles cmdOpen.Click

    private void cmdPageSetup_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Document is defined in the page setup dialog
      //   - Show a page setup dialog
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dlgPageSetup.Document = prndocPerson;
      dlgPageSetup.ShowDialog();
    }
    // cmdPageSetup_Click(System.Object, System.EventArgs) Handles cmdPageSetup.Click


    private void cmdPrint_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Add the print document to the print dialog
      //   - Show a print dialog
      //   - Print if OK button is clicked
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dlgPrint.Document = prndocPerson;

      if (dlgPrint.ShowDialog() == DialogResult.OK)
      {
        prndocPerson.Print();
      }
      else
        // dlgPrint.ShowDialog <> DialogResult.OK 
      {
      }
      // dlgPrint.ShowDialog = DialogResult.OK 
    
    }
    // cmdPrint_Click(System.Object, System.EventArgs) Handles cmdPrint.Click

    private void cmdPrintPreview_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Add the print document to the print preview dialog
      //   - Show a print preview dialog
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dlgPrintPreview.Document = prndocPerson;
      dlgPrintPreview.ShowDialog();
    }
    // cmdPrintPreview_Click(System.Object, System.EventArgs) Handles cmdPrintPreview.Click

    private void cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a file save dialog
      //   - If OK is clicked, the choosen file is defined in a stream writer
      //   - For every cpPerson in the list of persons
      //     - A line is written to the stream writer
      //     - Before the ":" it is the name
      //     - After the ":" is is the phone number
      //   - Stream writer is closed
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpPerson.Name() As String (Get)
      //   - cpPerson.PhoneNumber() As String (Get)
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (dlgFileSave.ShowDialog() == DialogResult.OK)
      {
        StreamWriter strWriter = new StreamWriter(dlgFileSave.OpenFile());

        foreach (cpPerson thecpPerson in lstPersons.Items)
        {
          strWriter.WriteLine(thecpPerson.Name + ":" + thecpPerson.PhoneNumber);
        }
        // in lstPersons.Items

        strWriter.Close();
      }
      else
        // dlgFileSave.ShowDialog <> DialogResult.OK
      {
      }
      // dlgFileSave.ShowDialog = DialogResult.OK
    
    }
    // cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click

    private void lstPersons_DoubleClick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - An item in the listbox is casted towards a cpPerson
      //   - The name and phonenumber are filled in in the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpPerson.Name() As String (Get)
      //   - cpPerson.PhoneNumber() As String (Get)
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpPerson thecpPerson = (cpPerson)lstPersons.SelectedItem;

      txtName.Text = thecpPerson.Name;
      txtPhoneNumber.Text = thecpPerson.PhoneNumber;
    }
    // lstPersons_DoubleClick(System.Object, System.EventArgs) Handles lstPersons.DoubleClick

    private void prndocPerson_PrintPage(System.Object theSender, PrintPageEventArgs thePrintPageEventArguments)
      //***
      // Action
      //   - Set a Brush to the same color of the listbox fore color
      //   - Loop thru all the items in the listbox
      //     - Set the name on a calculated position (depending on the line counter)
      //     - Set the phonenumber on a calculated position (depending on the line counter)
      //   - Clean up the brush
      // Called by
      //   - System action (Printing a page)
      // Calls
      //   - cpPerson.Name() As String (Get)
      //   - cpPerson.PhoneNumber() As String (Get)
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      SolidBrush brhTextColor = new SolidBrush(lstPersons.ForeColor);
      int lngLineCounter = 0;

      foreach (cpPerson thecpPerson in lstPersons.Items)
      {
        thePrintPageEventArguments.Graphics.DrawString(thecpPerson.Name, lstPersons.Font, brhTextColor, thePrintPageEventArguments.MarginBounds.Left, thePrintPageEventArguments.MarginBounds.Top + lstPersons.Font.Height * lngLineCounter);
        thePrintPageEventArguments.Graphics.DrawString(thecpPerson.PhoneNumber, lstPersons.Font, brhTextColor, thePrintPageEventArguments.MarginBounds.Left + thePrintPageEventArguments.MarginBounds.Width / 2.0F, thePrintPageEventArguments.MarginBounds.Top + lstPersons.Font.Height * lngLineCounter);
        lngLineCounter += 1;
      }
      // in lstPersons.Items

      brhTextColor.Dispose();
    }
    // prndocPerson_PrintPage(System.Object, Printing.PrintPageEventArgs) Handles prndocPerson.PrintPage

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPhoneBook
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmPhoneBook()
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPhoneBook());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPhoneBook

}
// CopyPaste.Learning