//***
// Action
//   - Testroutine for cpEmployee
// Created
//   - CopyPaste � 20230802 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230802 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;

namespace Static
{

  public class clsProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Define an employee with the default constructor
    //   - Define an employee with the defined constructor (fith October 1991, first lesson)
    //   - Set the company date to 1 September 1991 (Start of Copy Paste)
    //   - Show information of first employee
    //   - Show information of second employee
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpEmployee.CompanyParty(DateTime) (Set)
    //   - cpEmployee()
    //   - cpEmployee(string, aSex, DateTime)
    //   - cpEmployee.ShowInfo()
    // Created
    //   - CopyPaste � 20230802 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230802 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpEmployee theEmployee01 = new cpEmployee();
      cpEmployee theEmployee02 = new cpEmployee("Vincent", cpEmployee.aSex.Male, new DateTime(1991, 10, 5));

      cpEmployee.CompanyParty = new DateTime(1991, 9, 1);
      // cpEmployee.CompanyParty = new DateTime(2021, 2, 5);

      theEmployee01.ShowInfo();
      theEmployee02.ShowInfo();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// Static
