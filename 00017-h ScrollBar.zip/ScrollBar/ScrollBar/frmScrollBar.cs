//***
// Action
//   - Demo of horizontal and vertical scrollbar
// Created
//   - CopyPaste � 20240312 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240312 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmScrollBar: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtHorizontal;
    internal System.Windows.Forms.TextBox txtVertical;
    internal System.Windows.Forms.VScrollBar scrVertical;
    internal System.Windows.Forms.HScrollBar scrHorizontal;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmScrollBar));
      this.txtHorizontal = new System.Windows.Forms.TextBox();
      this.txtVertical = new System.Windows.Forms.TextBox();
      this.scrVertical = new System.Windows.Forms.VScrollBar();
      this.scrHorizontal = new System.Windows.Forms.HScrollBar();
      this.SuspendLayout();
      // 
      // txtHorizontal
      // 
      this.txtHorizontal.Location = new System.Drawing.Point(242, 112);
      this.txtHorizontal.Name = "txtHorizontal";
      this.txtHorizontal.TabIndex = 7;
      this.txtHorizontal.Text = "";
      // 
      // txtVertical
      // 
      this.txtVertical.Location = new System.Drawing.Point(58, 24);
      this.txtVertical.Name = "txtVertical";
      this.txtVertical.TabIndex = 5;
      this.txtVertical.Text = "";
      // 
      // scrVertical
      // 
      this.scrVertical.LargeChange = 1;
      this.scrVertical.Location = new System.Drawing.Point(26, 16);
      this.scrVertical.Minimum = 1;
      this.scrVertical.Name = "scrVertical";
      this.scrVertical.TabIndex = 4;
      this.scrVertical.Value = 1;
      this.scrVertical.ValueChanged += new System.EventHandler(this.scrVertical_ValueChanged);
      // 
      // scrHorizontal
      // 
      this.scrHorizontal.LargeChange = 5;
      this.scrHorizontal.Location = new System.Drawing.Point(26, 112);
      this.scrHorizontal.Maximum = 250;
      this.scrHorizontal.Minimum = 1;
      this.scrHorizontal.Name = "scrHorizontal";
      this.scrHorizontal.Size = new System.Drawing.Size(200, 13);
      this.scrHorizontal.TabIndex = 6;
      this.scrHorizontal.Value = 1;
      this.scrHorizontal.Scroll += new System.Windows.Forms.ScrollEventHandler(this.scrHorizontal_Scroll);
      // 
      // frmScrollBar
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(368, 165);
      this.Controls.Add(this.txtHorizontal);
      this.Controls.Add(this.txtVertical);
      this.Controls.Add(this.scrVertical);
      this.Controls.Add(this.scrHorizontal);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmScrollBar";
      this.Text = "ScrollBar";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmScrollBar'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmScrollBar()
      //***
      // Action
      //   - Create instance of 'frmScrollBar'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmScrollBar()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void scrHorizontal_Scroll(System.Object theSender, System.Windows.Forms.ScrollEventArgs theScrollEventArguments)
      //***
      // Action
      //   - Set the text according to th evalue of the horizontal scrollbar
      // Called by
      //   - User action (Changing the value of the scrollbar)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtHorizontal.Text = scrHorizontal.Value.ToString();
    }
    // scrHorizontal_Scroll(System.Object, System.Windows.Forms.ScrollEventArgs) Handles scrHorizontal_Scroll

    private void scrVertical_ValueChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the text according to th evalue of the vertical scrollbar
      // Called by
      //   - User action (Changing the value of the scrollbar)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtVertical.Text = scrVertical.Value.ToString();
    }
    // scrVertical_ValueChanged(System.Object theSender, System.EventArgs theEventArguments) Handles scrVertical.ValueChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmScrollBar
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmScrollBar());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmScrollBar

}
// CopyPaste.Learning