﻿//***
// Action
//   - Definition of a cpRectangle
// Created
//   - CopyPaste – 20251222 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251222 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpRectangle
  {

    #region "Constructors / Destructors"

    public cpRectangle(string strDescription) => Description = strDescription ?? throw new ArgumentNullException(nameof(strDescription));
    //***
    // Action
    //   - Basic constructor with one parameter
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - Description(string) (Set)
    // Created
    //   - CopyPaste – 20251222 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251222 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***

    public cpRectangle(int intLength, int intWidth, string strDescription)
    //***
    // Action
    //   - Basic constructor with three parameters
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - Description(string) (Set)
    //   - Length(int) (Set)
    //   - Width(int) (Set)
    // Created
    //   - CopyPaste – 20251222 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251222 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Length = intLength;
      Width = intWidth;
      Description = strDescription ?? throw new ArgumentNullException(nameof(strDescription));

      // VVDW - Alternative

      // if (strDescription == null)
      // {
      //   throw new ArgumentNullException(nameof(strDescription));
      // }
      // else
      // {
      //   Description = strDescription;
      // }

    }
    // cpRectangle(int, int, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public string Description { get; private set; }
    // cpRectangle(int, int, string)
    // cpRectangle(string)

    public int Length { get; private set; } = 1;
    // cpRectangle(int, int, string)

    public int Width { get; private set; } = 1;
    // cpRectangle(int, int, string)


    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpRectangle

}
// CopyPaste.Learning