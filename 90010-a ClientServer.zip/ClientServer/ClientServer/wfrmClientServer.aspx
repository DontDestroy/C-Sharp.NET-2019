﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmClientServer.aspx.cs" Inherits="CopyPaste.Learning.wfrmClientServer" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Client versus Server</title>
</head>
<body>
  <form id="wfrmClientServer" method="post" runat="server">
    <asp:Button Style="z-index: 101; position: absolute; top: 24px; left: 24px; height: 26px;" ID="cmdClick" runat="server"
      Text="Click here"></asp:Button>
    <asp:Label Style="z-index: 107; position: absolute; top: 106px; left: 25px; width: 371px;" ID="lblCookieOut"
      runat="server" Height="224px" TabIndex="5"></asp:Label>
    <asp:Button Style="z-index: 106; position: absolute; top: 104px; left: 416px" ID="cmdCookieRead"
      runat="server" Text="Read Cookie" TabIndex="6"></asp:Button>
    <asp:Button Style="z-index: 105; position: absolute; top: 72px; left: 416px" ID="cmdCookieWrite"
      runat="server" Text="Write Cookie" TabIndex="4"></asp:Button>
    <asp:TextBox Style="z-index: 104; position: absolute; top: 72px; left: 24px; width: 366px;" ID="txtCookieIn"
      runat="server" TabIndex="3"></asp:TextBox>
    <asp:Label Style="z-index: 103; position: absolute; top: 24px; left: 272px; height: 20px;" ID="lblHidden"
      runat="server" TabIndex="2"></asp:Label>
    <asp:Label Style="z-index: 102; position: absolute; top: 24px; left: 128px; height: 20px;" ID="lblResult"
      runat="server" Width="128px" BorderWidth="1px" BorderStyle="Solid" TabIndex="1"></asp:Label>
  </form>
</body>
</html>
