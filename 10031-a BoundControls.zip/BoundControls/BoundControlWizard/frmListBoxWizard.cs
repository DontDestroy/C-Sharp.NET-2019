//***
// Action
//   - Show a listbox bound to a data set
// Created
//   - CopyPaste � 20251231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251231 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmListBoxWizard: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    internal System.Windows.Forms.ListBox lstListbox;
    private BoundControlWizard.dsCustomer dsCustomer;
    private BindingSource bdsrcCustomer;
    private BoundControlWizard.dsCustomerTableAdapters.tbaCustomer tbaCustomer;
    private IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmListBoxWizard));
      this.lstListbox = new System.Windows.Forms.ListBox();
      this.bdsrcCustomer = new System.Windows.Forms.BindingSource(this.components);
      this.dsCustomer = new BoundControlWizard.dsCustomer();
      this.tbaCustomer = new BoundControlWizard.dsCustomerTableAdapters.tbaCustomer();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCustomer)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomer)).BeginInit();
      this.SuspendLayout();
      // 
      // lstListbox
      // 
      this.lstListbox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.lstListbox.DataSource = this.bdsrcCustomer;
      this.lstListbox.DisplayMember = "strCompanyName";
      this.lstListbox.Location = new System.Drawing.Point(8, 8);
      this.lstListbox.Name = "lstListbox";
      this.lstListbox.Size = new System.Drawing.Size(352, 277);
      this.lstListbox.TabIndex = 1;
      this.lstListbox.ValueMember = "strIdCustomer";
      // 
      // bdsrcCustomer
      // 
      this.bdsrcCustomer.DataMember = "tblCPCustomer";
      this.bdsrcCustomer.DataSource = this.dsCustomer;
      // 
      // dsCustomer
      // 
      this.dsCustomer.DataSetName = "dsCustomer";
      this.dsCustomer.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // tbaCustomer
      // 
      this.tbaCustomer.ClearBeforeFill = true;
      // 
      // frmListBoxWizard
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(368, 293);
      this.Controls.Add(this.lstListbox);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmListBoxWizard";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Displaying a Bound Listbox Wizard";
      this.Load += new System.EventHandler(this.frmListBoxWizard_Load);
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCustomer)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomer)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmListBoxWizard'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmListBoxWizard()
      //***
      // Action
      //   - Create instance of 'frmListBoxWizard'
      // Called by
      //   - frmBoundControlMainWizard.cmdListbox_Click(System.Object, System.EventArgs) Handles cmdListbox.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmListBoxWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmListBoxWizard_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Fill the data set using the data adapter
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      tbaCustomer.Fill(dsCustomer.tblCPCustomer);
    }
    // frmListBoxWizard_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmListBoxWizard

}
// CopyPaste.Learning