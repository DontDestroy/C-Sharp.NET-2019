//***
// Action
//   -  Definition of a cpTouchTonePhone
// Created
//   - CopyPaste � 20230817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230817 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpTouchTonePhone : cpPhone
  {

    #region "Constructors / Destructors"

    public cpTouchTonePhone(string strNumber) : base(strNumber)
      //***
      // Action
      //   - Constructor of a cpTouchTonePhone
      //   - A given strNumber
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpPhone(string)
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpTouchTonePhone(string)
    
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override void Dial()
      //***
      // Action
      //   - Simulation of the use of a touch tone phone
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Beep, touch-tone phone dialing: " + mstrNumber);
    }
    // Dial()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpTouchTonePhone 

}
// CopyPaste.Learning