//***
// Action
//   - Create a windows screen
// Created
//   - CopyPaste � 20210825 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210825 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace SimpleProject
{

  public class frmSimpleProject: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    internal System.Windows.Forms.PictureBox piclogo;
    internal System.Windows.Forms.Label lblWelcome;
    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSimpleProject));
      this.piclogo = new System.Windows.Forms.PictureBox();
      this.lblWelcome = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.piclogo)).BeginInit();
      this.SuspendLayout();
      // 
      // piclogo
      // 
      this.piclogo.Image = ((System.Drawing.Image)(resources.GetObject("piclogo.Image")));
      this.piclogo.Location = new System.Drawing.Point(72, 154);
      this.piclogo.Name = "piclogo";
      this.piclogo.Size = new System.Drawing.Size(192, 64);
      this.piclogo.TabIndex = 3;
      this.piclogo.TabStop = false;
      // 
      // lblWelcome
      // 
      this.lblWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblWelcome.Location = new System.Drawing.Point(56, 26);
      this.lblWelcome.Name = "lblWelcome";
      this.lblWelcome.Size = new System.Drawing.Size(216, 112);
      this.lblWelcome.TabIndex = 2;
      this.lblWelcome.Text = "Welcome to C#.NET 2019";
      this.lblWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // frmSimpleProject
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.BackColor = System.Drawing.Color.LightBlue;
      this.ClientSize = new System.Drawing.Size(328, 245);
      this.Controls.Add(this.piclogo);
      this.Controls.Add(this.lblWelcome);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSimpleProject";
      this.Text = "A simple program";
      ((System.ComponentModel.ISupportInitialize)(this.piclogo)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmSimpleProject'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210825 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210825 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing)
      {

        if(components == null)
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)

      }
      else
      // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSimpleProject()
    // Action
    //   - Create new instance of 'frmSimpleProject'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210825 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210825 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmSimpleProject()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start routine
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmSimpleProject()
    // Created
    //   - CopyPaste � 20210825 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210825 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmSimpleProject());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSimpleProject

}
// SimpleProject