//***
// Action
//   - Testroutine of an instance of cpCircle
// Created
//   - CopyPaste � 20231230 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231230 � VVDW
// Proposal (To Do)
//   - This routine proves that working in two different ways, will mess up the content of your information
//   - Decide to use one method
//   - Way 1: Creating circles by creating the center point (thru coordinats)
//   - Way 2: Creating circles by giving the center point (thru a cpPoint)
//***

using CopyPaste.Learning.Math;
using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace Circle
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Create a new instance of a cpCircle
    //   - Get some properties
    //   - Set some properties
    //   - Use of ToString()
    //   - Show the diameter
    //   - Show the circumference
    //   - Show the area
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpCircle(cpPoint, double)
    //   - cpCircle(int, int, double)
    //   - cpCircle.Radius(double) (Set)
    //   - cpCircle.X(int) (Set)
    //   - cpCircle.Y(int) (Set)
    //   - cpPoint cpCircle.Point (Get)
    //   - cpPoint cpPoint.Point (Get)
    //   - cpPoint()
    //   - cpPoint(int, int)
    //   - double cpCircle.Area()
    //   - double cpCircle.Circumference()
    //   - double cpCircle.Diameter()
    //   - double cpCircle.Radius() (Get)
    //   - int cpCircle.X() (Get)
    //   - int cpCircle.Y() (Get)
    //   - string cpCircle.ToString()
    //   - string cpPoint.ToString()
    // Created
    //   - CopyPaste � 20231230 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20231230 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpCircle thecpFirstCircle;
      cpCircle thecpSecondCircle;
      cpCircle thecpThirdCircle;
      cpPoint thecpFirstPoint;
      cpPoint thecpFourthPoint;
      cpPoint thecpPointCenter;
      cpPoint thecpSecondPoint;
      cpPoint thecpThirdPoint;
      string strOutput;

      /*
      // Tests for points
      thecpFirstPoint = new cpPoint();
      thecpSecondPoint = new cpPoint(2, 3);
      thecpPointCenter = new cpPoint(37, 43);

      // Show info of the first point and change stuff and show info again
      strOutput = thecpFirstPoint.ToString();
      strOutput += ControlChars.CrLf + thecpFirstPoint.Point.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpPoint");

      thecpFirstPoint.X = 1;
      thecpFirstPoint.Y = 2;

      strOutput = thecpFirstPoint.ToString();
      strOutput += ControlChars.CrLf + thecpFirstPoint.Point.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpPoint");

      // Show info of the second point and change stuff and show info again
      strOutput = thecpSecondPoint.ToString();
      strOutput += ControlChars.CrLf + thecpSecondPoint.Point.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpPoint");

      thecpSecondPoint.X = 1;
      thecpSecondPoint.Y = 2;

      strOutput = thecpSecondPoint.ToString();
      strOutput += ControlChars.CrLf + thecpSecondPoint.Point.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpPoint");

      // thecpThirdPoint = new cpPoint();
      thecpThirdPoint = thecpPointCenter;
      // thecpThirdPoint = thecpPointCenter.Point;
      // Do you understand the difference of these 3 lines?

      // Show info of the third point (and center point) and change stuff and show info again
      strOutput = thecpThirdPoint.ToString();
      strOutput += ControlChars.CrLf + thecpThirdPoint.Point.ToString();
      strOutput += ControlChars.CrLf + thecpPointCenter.ToString();
      strOutput += ControlChars.CrLf + thecpPointCenter.Point.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpPoint");

      thecpThirdPoint.X = 1;
      thecpThirdPoint.Y = 2;

      strOutput = thecpThirdPoint.ToString();
      strOutput += ControlChars.CrLf + thecpThirdPoint.Point.ToString();
      strOutput += ControlChars.CrLf + thecpPointCenter.ToString();
      strOutput += ControlChars.CrLf + thecpPointCenter.Point.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpPoint");

      // thecpFourthPoint = new cpPoint();
      // thecpFourthPoint = thecpPointCenter;
      thecpFourthPoint = thecpPointCenter.Point;
      // Do you understand the difference of these 3 lines?

      // Show info of the fourth point (and center point) and change stuff and show info again
      strOutput = thecpFourthPoint.ToString();
      strOutput += ControlChars.CrLf + thecpFourthPoint.Point.ToString();
      strOutput += ControlChars.CrLf + thecpPointCenter.ToString();
      strOutput += ControlChars.CrLf + thecpPointCenter.Point.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpPoint");

      thecpFourthPoint.X = 37;
      thecpFourthPoint.Y = 43;

      strOutput = thecpFourthPoint.ToString();
      strOutput += ControlChars.CrLf + thecpFourthPoint.Point.ToString();
      strOutput += ControlChars.CrLf + thecpPointCenter.ToString();
      strOutput += ControlChars.CrLf + thecpPointCenter.Point.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpPoint");
      */

      // Tests for circles
      thecpPointCenter = new cpPoint(37, 43);
      thecpFirstCircle = new cpCircle();
      thecpSecondCircle = new cpCircle(37, 43, 2.5);
      thecpThirdCircle = new cpCircle(thecpPointCenter, 2.5);
      // Do you understand the difference of these 3 lines?

      // Show info of the first circle (and center and point) and change stuff and show info again
      strOutput = thecpFirstCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpFirstCircle.Center.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpFirstCircle.Point.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Diameter is " + String.Format("{0:F}", thecpFirstCircle.Diameter());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Circumference is " + String.Format("{0:F}", thecpFirstCircle.Circumference());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Area is " + String.Format("{0:F}", thecpFirstCircle.Area());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      thecpFirstCircle.X = 2;
      thecpFirstCircle.Y = 2;
      thecpFirstCircle.Radius = 4.25;

      strOutput = thecpFirstCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpFirstCircle.Center.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpFirstCircle.Point.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      thecpFirstCircle.Center.X = 1;
      thecpFirstCircle.Center.Y = 1;

      strOutput = thecpFirstCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpFirstCircle.Center.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpFirstCircle.Point.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      thecpFirstCircle.Point.X = 37;
      thecpFirstCircle.Point.Y = 43;

      strOutput = thecpFirstCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpFirstCircle.Center.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpFirstCircle.Point.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      /*
      // Show info of the second circle (and center and point) and change stuff and show info again
      strOutput = thecpSecondCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpSecondCircle.Center.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpSecondCircle.Point.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Diameter is " + String.Format("{0:F}", thecpSecondCircle.Diameter());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Circumference is " + String.Format("{0:F}", thecpSecondCircle.Circumference());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Area is " + String.Format("{0:F}", thecpSecondCircle.Area());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      thecpSecondCircle.X = 2;
      thecpSecondCircle.Y = 2;
      thecpSecondCircle.Radius = 4.25;

      strOutput = thecpSecondCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpSecondCircle.Center.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpSecondCircle.Point.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      thecpSecondCircle.Center.X = 1;
      thecpSecondCircle.Center.Y = 1;

      strOutput = thecpSecondCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpSecondCircle.Center.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpSecondCircle.Point.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      thecpSecondCircle.Point.X = 37;
      thecpSecondCircle.Point.Y = 43;

      strOutput = thecpSecondCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpSecondCircle.Center.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpSecondCircle.Point.ToString();
      // This is treated as a cpCircle
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");
      */

      /*
      // Show info of the third circle (and center and point) and change stuff and show info again
      // You are mixing the stuff, so the results will be wrong here

      strOutput = thecpThirdCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpThirdCircle.Center.ToString();
      // This is treated as a cpPoint
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpThirdCircle.Point.ToString();
      // This is treated as a cpPoint
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Diameter is " + String.Format("{0:F}", thecpThirdCircle.Diameter());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Circumference is " + String.Format("{0:F}", thecpThirdCircle.Circumference());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Area is " + String.Format("{0:F}", thecpThirdCircle.Area());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      thecpThirdCircle.X = 2;
      thecpThirdCircle.Y = 2;
      thecpThirdCircle.Radius = 4.25;

      strOutput = thecpThirdCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpThirdCircle.Center.ToString();
      // This is treated as a cpPoint
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpThirdCircle.Point.ToString();
      // This is treated as a cpPoint
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      thecpThirdCircle.Center.X = 1;
      thecpThirdCircle.Center.Y = 1;

      strOutput = thecpThirdCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpThirdCircle.Center.ToString();
      // This is treated as a cpPoint
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpThirdCircle.Point.ToString();
      // This is treated as a cpPoint
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      thecpThirdCircle.Point.X = 37;
      thecpThirdCircle.Point.Y = 43;

      strOutput = thecpThirdCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpThirdCircle.Center.ToString();
      // This is treated as a cpPoint
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = thecpThirdCircle.Point.ToString();
      // This is treated as a cpPoint
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");
      */
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// Circle