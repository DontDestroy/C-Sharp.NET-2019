//***
// Action
//   - Implementation of a cpEmployee with a protected property
// Created
//   - CopyPaste � 20240409 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240409 � VVDW
// Proposal (To Do)
//   - There is an exercise where you can add a property that must be inherited
//   - There is an exercise where you can give a cpDirector another class to inherit from
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpEmployee
  {

    #region "Constructors / Destructors"

    public cpEmployee(string strName)
      //***
      // Action
      //   - Constructor with Name
      // Called by
      //   - cpEmployee(string, cpDepartment)
      //   - cpHandWorker(string)
      //   - cpOfficeWorker(string)
      // Calls
      //   - Name(string) (Set)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Name = strName;
    }
    // cpEmployee(string)

    public cpEmployee(string strName, cpDepartment thecpDepartment) : this(strName)
      //***
      // Action
      //   - Constructor with Name and Department
      // Called by
      //   - cpHandWorker(string, cpDepartment)
      //   - cpOfficeWorker(string, cpDepartment)
      // Calls
      //   - cpEmployee(string)
      //   - Department(string) (Set)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Department = thecpDepartment;
    }
    // cpEmployee(string, cpDepartment)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpDepartment mcpDepartment;
    private string mstrName;

    #endregion

    #region "Properties"

    // public abstract decimal Extra
    // {
    //   get;
    //   set;
    // }

    protected cpDepartment Department
    {

      get
        //***
        // Action Get
        //   - Returns mcpDepartment
        // Called by
        //   - cpDirector.ShowInfo()
        //   - cpHandWorker.ShowInfo()
        //   - cpManager.ShowInfo()
        //   - cpOfficeWorker.ShowInfo()
        //   - ShowInfo()
        //   - string cpDirector.ToString()
        //   - string cpHandWorker.ToString()
        //   - string cpManager.ToString()
        //   - string cpOfficeWorker.ToString()
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mcpDepartment;
      }
      // cpDepartment Department (Get)

      set
        //***
        // Action Set
        //   - mstrDepartment becomes value
        // Called by
        //   - cpEmployee(string, cpDepartment)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mcpDepartment = value;
      }
      // Department(cpDepartment) (Set)

    }
    // string Department 

    public string Name
    {

      get
        //***
        // Action Get
        //   - Returns mstrName
        // Called by
        //   - cpDirector.ShowInfo()
        //   - cpHandWorker.ShowInfo()
        //   - cpManager.ShowInfo()
        //   - cpOfficeWorker.ShowInfo()
        //   - ShowInfo()
        //   - string cpDirector.ToString()
        //   - string cpHandWorker.ToString()
        //   - string cpManager.ToString()
        //   - string cpOfficeWorker.ToString()
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

      set
        //***
        // Action Set
        //   - mstrName becomes value
        // Called by
        //   - cpEmployee(string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Returns the Name (Department) and that the person is an employee
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpDepartment Department (Get)
      //   - string cpDepartment.Name (Get)
      //   - string Name (Get)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strResult;

      if (Department == null)
      {
        strResult =  Name + " is an employee.";
      }
      else
        // Department <> null
      {
        strResult = Name + "(" + Department.Name + ") is an employee.";
      }
      // Department = null

      return strResult;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public virtual void ShowInfo()
      //***
      // Action
      //   - Shows information to the console
      //     - Employee + Name
      //     - Department
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpDepartment Department (Get)
      //   - cpDepartment.ShowInfo()
      //   - string Name (Get)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Employee - Name: {0}", Name);

      if (Department == null) 
      {
      }
      else
        // Department <> null
      {
        Department.ShowInfo();
      }
      // Department = null

    }
    // ShowInfo()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpEmployee

}
// CopyPaste.Learning.Employee