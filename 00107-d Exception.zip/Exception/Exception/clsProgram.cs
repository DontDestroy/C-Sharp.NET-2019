//***
// Action
//   - Testroutine for cpCopyMachine and some exception classes
// Created
//   - CopyPaste � 20231226 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231226 � VVDW
// Proposal (To Do)
//   -
//***

using Company.Material;
using System;

namespace Exception
{

	public class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main()
			//***
			// Action
			//   - Starting point of the application
			// Called by
			//   - User action (Starting application)
			// Calls
			//   - cpCopyMachine()
			//   - cpCopyMachine.NumberOfPages(int) (Set)
			//   - cpCopyMachine.PageCost(decimal) (Set)
			//   - decimal cpCostPerPageException.WrongCost() (Get)
			//   - string cpCostPerPageException.Message() (Get)
			//   - string cpNumberOfPagesException.Message() (Get)
			//   - string cpNumberOfPagesException.WrongNumber() (Get)
			// Created
			//   - CopyPaste � 20231226 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231226 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
	  {

			try
			{
				cpCopyMachine thecpCopyMachine = new cpCopyMachine();

				thecpCopyMachine.PageCost = 0.025M;
				thecpCopyMachine.NumberOfPages = 10000;
				Console.WriteLine("Machine is correct initialized");
			}
			catch (cpCostPerPageException thecpCostPerPageException) 
			{
				Console.WriteLine();
				Console.WriteLine("Error: {0}: wrong value {1}", thecpCostPerPageException.Message, thecpCostPerPageException.WrongCost);
			}
			catch (cpNumberOfPagesException thecpNumberOfPagesException)
			{
				Console.WriteLine();
				Console.WriteLine("Error: {0}: wrong value {1}", thecpNumberOfPagesException.Message, thecpNumberOfPagesException.WrongNumber);
			}
			finally
			{
				Console.WriteLine();
				Console.WriteLine("End Program");
				Console.ReadLine();
			}
    
		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpProgram

}
// Exception