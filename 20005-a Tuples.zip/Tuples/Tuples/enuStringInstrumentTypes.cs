﻿//***
// Action
//   - An enumeration of string instrument types
// Created
//   - CopyPaste – 20251130 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251130 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  //#region "Constructors / Destructors"
  //#endregion

  #region "Designer"

  public enum StringInstrumentType
  {
    cello,
    guitar,
    violin
  }
  // StringInstrumentType

  #endregion

  //#region "Structures"
  //#endregion

  //#region "Fields"
  //#endregion

  //#region "Properties"
  //#endregion

  //#region "Methods"

  //#region "Overrides"
  //#endregion

  //#region "Controls"
  //#endregion

  //#region "Functionality"

  //#region "Event"
  //#endregion

  //#region "Sub / Function"

  //#endregion

  //#endregion

  //#endregion

  //#region "Not used"
  //#endregion

}
// CopyPaste.Learning