﻿//***
// Action
//   - Interface of a Controller
// Created
//   - CopyPaste – 20251030 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251030 – VVDW
// Proposal (To Do)
//   -
//***

using kareltherobot;

namespace cpKarelTheRobot
{

	public interface cpinfController
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		void ControlIt();
    //***
    // Action
    //   - Here will be defined what action will be executed by the Controller
    // Called by
    //   - cpControllerStrategyVersion01.Turn()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpinfController

}
// cpKarelTheRobot