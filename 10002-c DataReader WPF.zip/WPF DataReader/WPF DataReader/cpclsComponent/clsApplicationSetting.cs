﻿//***
// Action
//   - Reading Application Settings
// Created
//   - CopyPaste – 20210819 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210819 – VVDW
// Proposal(To Do)
//   -
//***

using System.Configuration;

namespace WPFDataReader
{

  public static class cpApplicationSetting
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public static string ConnectionString
    {
      get
      //***
      // Action Get
      //   - Look up the connection string in the Application Configuration(App.config)
      // Called by
      //   - cpDataReaderViewModel.GetMultipleResultSets()
      //   - cpDataReaderViewModel.GetProductsAsDataReader()
      //   - DataTable cpProductManager.GetProductsAsDataTable()
      //   - ObservableCollection<cpProduct> cpDataReaderViewModel.GetProductsAsGenericList()
      //   - ObservableCollection<cpProduct> cpDataReaderViewModel.GetProductsUsingExtensionMethods()
      //   - ObservableCollection<cpProduct> cpDataReaderViewModel.GetProductsUsingFieldValue()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20210819 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20210819 – VVDW
      // Keyboard Key
      //   - 
      // Proposal(To Do)
      //   -
      //***
      {
        return ConfigurationManager.ConnectionStrings["WPFConnection"].ConnectionString;
      }
      // string ConnectionString (Get)

    }
    // string ConnectionString 

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpApplicationSetting

}
// WPFDataReader