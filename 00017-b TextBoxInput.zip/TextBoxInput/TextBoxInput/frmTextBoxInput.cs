//***
// Action
//   - A textbox and a save button
// Created
//   - CopyPaste � 20240229 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240229 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTextBoxInput: System.Windows.Forms.Form
  {
    internal System.Windows.Forms.Button cmdSave;
    internal System.Windows.Forms.TextBox txtText;

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTextBoxInput));
      this.cmdSave = new System.Windows.Forms.Button();
      this.txtText = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdSave
      // 
      this.cmdSave.Location = new System.Drawing.Point(128, 299);
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.TabIndex = 3;
      this.cmdSave.Text = "Save";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(24, 27);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(288, 248);
      this.txtText.TabIndex = 2;
      this.txtText.Text = "";
      // 
      // frmTextBoxInput
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(336, 349);
      this.Controls.Add(this.cmdSave);
      this.Controls.Add(this.txtText);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTextBoxInput";
      this.Text = "TextBox Input";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTextBoxInput'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240229 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240229 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTextBoxInput()
      //***
      // Action
      //   - Create instance of 'frmTextBoxInput'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240229 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240229 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdSave_Click(System.Object sender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a StreamWriter
      //   - Try to initialize it to C:\Memos.txt and in append mode
      //     - You can add text to an existing file
      //     - Show an error message if it fails
      //   - If StreamWriter is null
      //     - Do nothing
      //   - If Not
      //     - Try to
      //       - Add the current date and time to the file
      //       - Add the text of the textbox to the file
      //       - Add 2 empty lines
      //       - Show an error message when it fails
      //     - Close the file, when it was opened
      //   - Show a message that the file was successfully saved or not
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240229 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240229 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnOpenError = false;
      bool blnWriteError = false;
      StreamWriter strWriter = null;
      
      try
      {
        strWriter = new StreamWriter("C:\\Memos.txt", true);
      }
      catch
      {
        MessageBox.Show("Error opening " + "C:\\Memos.txt");
        blnOpenError = true;
      }

      if (strWriter == null)
      {
      }
      else
      // strWriter <> null
      {

        try
        {
          strWriter.WriteLine(DateTime.Now);
          strWriter.Write(txtText.Text);
          strWriter.WriteLine();
          strWriter.WriteLine();
        }
        catch
        {
          MessageBox.Show("Error writing file");
          blnWriteError = true;
        }

      }
      // strWriter = null

      if (blnOpenError)
      {
      }
      else
        // Not blnOpenError 
      {
        strWriter.Close();
      }
      // blnOpenError 

      if (blnOpenError || blnWriteError)
      {
        MessageBox.Show("Text is not saved to " + ("C:\\Memos.txt"));
      }
      else
        // Not blnError AndAlso Not blnWriteError
      {
        MessageBox.Show("Text saved to " + ("C:\\Memos.txt"));
      }
      // blnOpenError OrElse blnWriteError 
    
    }
    // cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTextBoxInput
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240229 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240229 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTextBoxInput());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTextBoxInput

}
// CopyPaste.Learning