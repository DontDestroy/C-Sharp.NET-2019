//***
// Action
//   - Testroutine for a cpctlValidationTextbox control
// Created
//   - CopyPaste � 20250718 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250718 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Learning;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmValidationTextBox: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdClose;
    internal System.Windows.Forms.GroupBox grpOption;
    internal System.Windows.Forms.RadioButton optSignedFloat;
    internal System.Windows.Forms.RadioButton optFloat;
    internal System.Windows.Forms.RadioButton optSignedNumeric;
    internal System.Windows.Forms.RadioButton optNumeric;
    internal System.Windows.Forms.RadioButton optAlphaNumeric;
    internal System.Windows.Forms.RadioButton optAlpha;
    internal System.Windows.Forms.RadioButton optNone;
    internal CopyPaste.Learning.cpctlValidationTextbox txtValidate;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmValidationTextBox));
      this.cmdClose = new System.Windows.Forms.Button();
      this.grpOption = new System.Windows.Forms.GroupBox();
      this.optSignedFloat = new System.Windows.Forms.RadioButton();
      this.optFloat = new System.Windows.Forms.RadioButton();
      this.optSignedNumeric = new System.Windows.Forms.RadioButton();
      this.optNumeric = new System.Windows.Forms.RadioButton();
      this.optAlphaNumeric = new System.Windows.Forms.RadioButton();
      this.optAlpha = new System.Windows.Forms.RadioButton();
      this.optNone = new System.Windows.Forms.RadioButton();
      this.txtValidate = new CopyPaste.Learning.cpctlValidationTextbox();
      this.grpOption.SuspendLayout();
      this.SuspendLayout();
      // 
      // cmdClose
      // 
      this.cmdClose.Location = new System.Drawing.Point(171, 233);
      this.cmdClose.Name = "cmdClose";
      this.cmdClose.TabIndex = 4;
      this.cmdClose.Text = "Close";
      this.cmdClose.Click += new System.EventHandler(this.cmdClose_Click);
      // 
      // grpOption
      // 
      this.grpOption.Controls.Add(this.optSignedFloat);
      this.grpOption.Controls.Add(this.optFloat);
      this.grpOption.Controls.Add(this.optSignedNumeric);
      this.grpOption.Controls.Add(this.optNumeric);
      this.grpOption.Controls.Add(this.optAlphaNumeric);
      this.grpOption.Controls.Add(this.optAlpha);
      this.grpOption.Controls.Add(this.optNone);
      this.grpOption.Location = new System.Drawing.Point(11, 9);
      this.grpOption.Name = "grpOption";
      this.grpOption.Size = new System.Drawing.Size(152, 248);
      this.grpOption.TabIndex = 3;
      this.grpOption.TabStop = false;
      this.grpOption.Text = "Validation Modifiers";
      // 
      // optSignedFloat
      // 
      this.optSignedFloat.Location = new System.Drawing.Point(8, 216);
      this.optSignedFloat.Name = "optSignedFloat";
      this.optSignedFloat.Size = new System.Drawing.Size(104, 16);
      this.optSignedFloat.TabIndex = 6;
      this.optSignedFloat.Text = "Signed Float";
      this.optSignedFloat.Click += new System.EventHandler(this.OptionArray_Click);
      // 
      // optFloat
      // 
      this.optFloat.Location = new System.Drawing.Point(8, 184);
      this.optFloat.Name = "optFloat";
      this.optFloat.Size = new System.Drawing.Size(104, 16);
      this.optFloat.TabIndex = 5;
      this.optFloat.Text = "Unsigned Float";
      this.optFloat.Click += new System.EventHandler(this.OptionArray_Click);
      // 
      // optSignedNumeric
      // 
      this.optSignedNumeric.Location = new System.Drawing.Point(8, 152);
      this.optSignedNumeric.Name = "optSignedNumeric";
      this.optSignedNumeric.Size = new System.Drawing.Size(104, 16);
      this.optSignedNumeric.TabIndex = 4;
      this.optSignedNumeric.Text = "Signed Numeric";
      this.optSignedNumeric.Click += new System.EventHandler(this.OptionArray_Click);
      // 
      // optNumeric
      // 
      this.optNumeric.Location = new System.Drawing.Point(8, 120);
      this.optNumeric.Name = "optNumeric";
      this.optNumeric.Size = new System.Drawing.Size(120, 16);
      this.optNumeric.TabIndex = 3;
      this.optNumeric.Text = "Unsigned Numeric";
      this.optNumeric.Click += new System.EventHandler(this.OptionArray_Click);
      // 
      // optAlphaNumeric
      // 
      this.optAlphaNumeric.Location = new System.Drawing.Point(8, 88);
      this.optAlphaNumeric.Name = "optAlphaNumeric";
      this.optAlphaNumeric.Size = new System.Drawing.Size(104, 16);
      this.optAlphaNumeric.TabIndex = 2;
      this.optAlphaNumeric.Text = "Alpha Numeric";
      this.optAlphaNumeric.Click += new System.EventHandler(this.OptionArray_Click);
      // 
      // optAlpha
      // 
      this.optAlpha.Location = new System.Drawing.Point(8, 56);
      this.optAlpha.Name = "optAlpha";
      this.optAlpha.Size = new System.Drawing.Size(104, 16);
      this.optAlpha.TabIndex = 1;
      this.optAlpha.Text = "Alpha Only";
      this.optAlpha.Click += new System.EventHandler(this.OptionArray_Click);
      // 
      // optNone
      // 
      this.optNone.Checked = true;
      this.optNone.Location = new System.Drawing.Point(8, 24);
      this.optNone.Name = "optNone";
      this.optNone.Size = new System.Drawing.Size(104, 16);
      this.optNone.TabIndex = 0;
      this.optNone.TabStop = true;
      this.optNone.Text = "None";
      this.optNone.Click += new System.EventHandler(this.OptionArray_Click);
      //
      // txtValidate
      //
      this.txtValidate.Location = new System.Drawing.Point(168, 16);
      this.txtValidate.Name = "txtValidate";
      this.txtValidate.Restrict = null;
      this.txtValidate.SelectAllText = true;
      this.txtValidate.Size = new System.Drawing.Size(72, 20);
      this.txtValidate.TabIndex = 1;
      this.txtValidate.Text = "";
      // 
      // frmValidationTextBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(256, 266);
      this.Controls.Add(this.cmdClose);
      this.Controls.Add(this.grpOption);
      this.Controls.Add(this.txtValidate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmValidationTextBox";
      this.Text = "Validation Textbox";
      this.grpOption.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmValidationTextBox'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmValidationTextBox()
      //***
      // Action
      //   - Create instance of 'frmValidationTextBox'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmValidationTextBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdClose_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Close the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250718 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // cmdClose_Click(System.Object, System.EventArgs) Handles cmdClose.Click

    private void OptionArray_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Remove the text that was typed in the textbox
      //   - Depending on what option button is checked
      //     - optNone, there is no restriction
      //     - optAlpha, there is a restriction on only letters
      //     - optAlphaNumeric, there is a restriction on only letters or digits
      //     - optFloat, there is a restriction on only digits but there can be a decimal symbol
      //     - optNumeric, there is a restriction on only digits
      //     - optSignedFloat, there is a restriction on only digits but there can be a decimal symbol and the first character can be a negative sign
      //     - optSignedNumeric, there is a restriction on only digits but first character can be a negative sign
      // Called by
      //   - User action (Clicking a radio button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250718 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtValidate.Text = String.Empty;

      if (optNone.Checked)
      {
        txtValidate.Restrict = null;
      }
      else
        // Not optNone.Checked
      {
      }
      // optNone.Checked

      if (optAlpha.Checked)
      {
        txtValidate.Restrict = new cpValidationRestrictionAlpha();
      }
      else
        // Not optAlpha.Checked
      {
      }
      // optAlpha.Checked

      if (optAlphaNumeric.Checked)
      {
        txtValidate.Restrict = new cpValidationRestrictionAlphaNumeric();
      }
      else
        // Not optAlphaNumeric.Checked
      {
      }
      // optAlphaNumeric.Checked

      if (optFloat.Checked)
      {
        txtValidate.Restrict = new cpValidationRestrictionDecimal();
      }
      else
        // Not optFloat.Checked
      {
      }
      // optFloat.Checked

      if (optNumeric.Checked)
      {
        txtValidate.Restrict = new cpValidationRestrictionNumeric();
      }
      else
        // Not optNumeric.Checked
      {
      }
      // optNumeric.Checked

      if (optSignedFloat.Checked)
      {
        txtValidate.Restrict = new cpValidationRestrictionNegativeDecimal();
      }
      else
        // Not optSignedFloat.Checked
      {
      }
      // optSignedFloat.Checked

      if (optSignedNumeric.Checked)
      {
        txtValidate.Restrict = new cpValidationRestrictionNegativeNumeric();
      }
      else
        // Not optSignedNumeric.Checked
      {
      }
      // optSignedNumeric.Checked
      
    }
    // OptionArray_Click(System.Object, System.EventArgs) Handles optAlpha.Click, optAlphaNumeric.Click, optFloat.Click, optNone.Click, optNumeric.Click, optSignedFloat.Click, optSignedNumeric.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmValidationTextBox
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmValidationTextBox()
      // Created
      //   - CopyPaste � 20250718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmValidationTextBox());
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmValidationTextBox

}
// CopyPaste.Learning