﻿//***
// Action
//   - Demo of a Slider
// Created
//   - CopyPaste – 20230224 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230224 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;
using System.Windows.Media;

namespace CopyPaste.Learning
{

  public partial class wpfExampleSlider : Window
  {

    #region "Constructors / Destructors"

    public wpfExampleSlider()
    //***
    // Action
    //   - Create an instance of 'wpfExampleSlider'
    // Called by
    //   - User action (Starting the form)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20230224 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230224 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      theBrushColor = new SolidColorBrush();
    }
    // wpfExampleSlider()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private SolidColorBrush theBrushColor;
    private Color theColor;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void sldAlphaChannel_ValueChanged(System.Object theSender, RoutedPropertyChangedEventArgs<double> theRoutedPropertyChangedEventArguments)
    //***
    // Action
    //   - Changing the Alpha Channel of a color
    // Called by
    //   - User action (Changing a slider)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230224 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230224 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      theColor.A = (byte)sldAlphaChannel.Value;
      theBrushColor.Color = theColor;
      recColored.Fill = theBrushColor;
    }
    // sldAlphaChannel_ValueChanged(System.Object, RoutedPropertyChangedEventArgs<double>) Handles sldAlphaChannel.ValueChanged

    private void sldBlueChannel_ValueChanged(System.Object theSender, RoutedPropertyChangedEventArgs<double> theRoutedPropertyChangedEventArguments)
    //***
    // Action
    //   - Changing the Blue Channel of a color
    // Called by
    //   - User action (Changing a slider)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230224 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230224 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theColor.B = (byte)sldBlueChannel.Value;
      theBrushColor.Color = theColor;
      recColored.Fill = theBrushColor;
    }
    // sldBlueChannel_ValueChanged(System.Object, RoutedPropertyChangedEventArgs<double>) Handles sldBlueChannel.ValueChanged

    private void sldGreenChannel_ValueChanged(System.Object theSender, RoutedPropertyChangedEventArgs<double> theRoutedPropertyChangedEventArguments)
    //***
    // Action
    //   - Changing the Green Channel of a color
    // Called by
    //   - User action (Changing a slider)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230224 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230224 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theColor.G = (byte)sldGreenChannel.Value;
      theBrushColor.Color = theColor;
      recColored.Fill = theBrushColor;
    }
    // sldGreenChannel_ValueChanged(System.Object, RoutedPropertyChangedEventArgs<double>) Handles sldGreenChannel.ValueChanged

    private void sldRedChannel_ValueChanged(System.Object theSender, RoutedPropertyChangedEventArgs<double> theRoutedPropertyChangedEventArguments)
    //***
    // Action
    //   - Changing the Red Channel of a color
    // Called by
    //   - User action (Changing a slider)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230224 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230224 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theColor.R = (byte)sldRedChannel.Value;
      theBrushColor.Color = theColor;
      recColored.Fill = theBrushColor;
    }
    // sldRedChannel_ValueChanged(System.Object, RoutedPropertyChangedEventArgs<double>) Handles sldRedChannel.ValueChanged

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfExampleSlider

}
// CopyPaste.Learning
