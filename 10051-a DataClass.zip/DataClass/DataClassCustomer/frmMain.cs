//***
// Action
//   - Starting point of the application
//   - A screen with four buttons
//     - Show information about a customer
//     - Find a customer
//     - Update a customer
//     - Validate a customer
//   - Coded with the point of view to classes, interfaces and components
// Created
//   - CopyPaste � 20260117 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260117 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMain: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdUpdateCustomer;
    internal System.Windows.Forms.Button cmdFindCustomer;
    internal System.Windows.Forms.Button cmdValidateCustomer;
    internal System.Windows.Forms.Button cmdShowCustomer;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMain));
      this.cmdUpdateCustomer = new System.Windows.Forms.Button();
      this.cmdFindCustomer = new System.Windows.Forms.Button();
      this.cmdValidateCustomer = new System.Windows.Forms.Button();
      this.cmdShowCustomer = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdUpdateCustomer
      // 
      this.cmdUpdateCustomer.Location = new System.Drawing.Point(9, 105);
      this.cmdUpdateCustomer.Name = "cmdUpdateCustomer";
      this.cmdUpdateCustomer.Size = new System.Drawing.Size(152, 40);
      this.cmdUpdateCustomer.TabIndex = 6;
      this.cmdUpdateCustomer.Text = "Update Customer";
      this.cmdUpdateCustomer.Click += new System.EventHandler(this.cmdUpdateCustomer_Click);
      // 
      // cmdFindCustomer
      // 
      this.cmdFindCustomer.Location = new System.Drawing.Point(9, 57);
      this.cmdFindCustomer.Name = "cmdFindCustomer";
      this.cmdFindCustomer.Size = new System.Drawing.Size(152, 40);
      this.cmdFindCustomer.TabIndex = 5;
      this.cmdFindCustomer.Text = "Find Customer";
      this.cmdFindCustomer.Click += new System.EventHandler(this.cmdFindCustomer_Click);
      // 
      // cmdValidateCustomer
      // 
      this.cmdValidateCustomer.Location = new System.Drawing.Point(9, 153);
      this.cmdValidateCustomer.Name = "cmdValidateCustomer";
      this.cmdValidateCustomer.Size = new System.Drawing.Size(152, 40);
      this.cmdValidateCustomer.TabIndex = 7;
      this.cmdValidateCustomer.Text = "Validate Customer";
      this.cmdValidateCustomer.Click += new System.EventHandler(this.cmdValidateCustomer_Click);
      // 
      // cmdShowCustomer
      // 
      this.cmdShowCustomer.Location = new System.Drawing.Point(9, 9);
      this.cmdShowCustomer.Name = "cmdShowCustomer";
      this.cmdShowCustomer.Size = new System.Drawing.Size(152, 40);
      this.cmdShowCustomer.TabIndex = 4;
      this.cmdShowCustomer.Text = "Show Customer";
      this.cmdShowCustomer.Click += new System.EventHandler(this.cmdShowCustomer_Click);
      // 
      // frmMain
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(170, 202);
      this.Controls.Add(this.cmdUpdateCustomer);
      this.Controls.Add(this.cmdFindCustomer);
      this.Controls.Add(this.cmdValidateCustomer);
      this.Controls.Add(this.cmdShowCustomer);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMain";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Select a section";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMain'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMain()
      //***
      // Action
      //   - Create instance of 'frmMain'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMain()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdFindCustomer_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmCustomerRead'
      //   - Show the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmCustomerRead()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmCustomerRead theForm = new frmCustomerRead();

      theForm.Show();
    }
    // cmdFindCustomer_Click(System.Object, System.EventArgs) Handles cmdFindCustomer.Click

    private void cmdShowCustomer_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmCustomer'
      //   - Show the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmCustomer()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmCustomer theForm = new frmCustomer();

      theForm.Show();
    }
    // cmdShowCustomer_Click(System.Object, System.EventArgs) Handles cmdShowCustomer.Click

    private void cmdUpdateCustomer_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmCustomerUpdate'
      //   - Show the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmCustomerUpdate()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmCustomerUpdate theForm = new frmCustomerUpdate();

      theForm.Show();
    }
    // cmdUpdateCustomer_Click(System.Object, System.EventArgs) Handles cmdUpdateCustomer.Click

    private void cmdValidateCustomer_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmCustomerValidation'
      //   - Show the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmCustomerValidation()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmCustomerValidation theForm = new frmCustomerValidation();
    
      theForm.Show();
    }
    // cmdValidateCustomer_Click(System.Object, System.EventArgs) Handles cmdValidateCustomer.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMain
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmMain()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMain());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMain

}
// CopyPaste.Learning