﻿//***
// Action
//   - Middle Tier part of a Three Tier Application
// Created
//   - CopyPaste – 20220826 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220826 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;

namespace CopyPaste.MiddleTierApplication
{
  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Startup of the Middle Tier Application
    //   - Fill the list of product categories and store this in a IDictionary
    //   - Loop thru the elements
    //     - Show the product
    //     - Show the product category
    //   - Show the number of elements in the products with product category
    // Called by
    //   - User action (Starting the application)
    //   - This is a .dll application, will never be executed
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      dtsProductWithProductCategory theProductsWithProductCategory = new dtsProductWithProductCategory();

      IDictionary<string, string> theResult = theProductsWithProductCategory.AllProductsWithProductCategory();

      Console.WriteLine("Business Layer says hello!\n");

      foreach (string strKey in theResult.Keys)
      {
        Console.WriteLine("Product: " + strKey);
        Console.WriteLine("Category: " + theResult[strKey]);
      }
      // in dicProducts.Keys

      Console.WriteLine();
      Console.WriteLine("Number of Products: " + theResult.Values.Count);
      Console.ReadKey();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.MiddleTierApplication