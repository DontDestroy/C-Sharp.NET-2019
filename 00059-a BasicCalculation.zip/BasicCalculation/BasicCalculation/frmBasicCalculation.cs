//***
// Action
//   - Basic calculations
// Created
//   - CopyPaste � 20240518 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240518 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBasicCalculation: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.Label lblVariable2;
    internal System.Windows.Forms.Label lblVariable1;
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.Button cmdCalculation;
    internal System.Windows.Forms.TextBox txtResult;
    internal System.Windows.Forms.GroupBox grpOperator;
    internal System.Windows.Forms.RadioButton optDivision;
    internal System.Windows.Forms.RadioButton optMultiplication;
    internal System.Windows.Forms.RadioButton optSubtract;
    internal System.Windows.Forms.RadioButton optAdd;
    internal System.Windows.Forms.TextBox txtVariable1;
    internal System.Windows.Forms.TextBox txtVariable2;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBasicCalculation));
      this.lblResult = new System.Windows.Forms.Label();
      this.lblVariable2 = new System.Windows.Forms.Label();
      this.lblVariable1 = new System.Windows.Forms.Label();
      this.cmdExit = new System.Windows.Forms.Button();
      this.cmdCalculation = new System.Windows.Forms.Button();
      this.txtResult = new System.Windows.Forms.TextBox();
      this.grpOperator = new System.Windows.Forms.GroupBox();
      this.optDivision = new System.Windows.Forms.RadioButton();
      this.optMultiplication = new System.Windows.Forms.RadioButton();
      this.optSubtract = new System.Windows.Forms.RadioButton();
      this.optAdd = new System.Windows.Forms.RadioButton();
      this.txtVariable1 = new System.Windows.Forms.TextBox();
      this.txtVariable2 = new System.Windows.Forms.TextBox();
      this.grpOperator.SuspendLayout();
      this.SuspendLayout();
      // 
      // lblResult
      // 
      this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblResult.Location = new System.Drawing.Point(296, 16);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(96, 16);
      this.lblResult.TabIndex = 14;
      this.lblResult.Text = "Result";
      // 
      // lblVariable2
      // 
      this.lblVariable2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblVariable2.Location = new System.Drawing.Point(16, 72);
      this.lblVariable2.Name = "lblVariable2";
      this.lblVariable2.Size = new System.Drawing.Size(88, 16);
      this.lblVariable2.TabIndex = 11;
      this.lblVariable2.Text = "Variable 2";
      // 
      // lblVariable1
      // 
      this.lblVariable1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblVariable1.Location = new System.Drawing.Point(16, 16);
      this.lblVariable1.Name = "lblVariable1";
      this.lblVariable1.Size = new System.Drawing.Size(88, 16);
      this.lblVariable1.TabIndex = 9;
      this.lblVariable1.Text = "Variable 1";
      // 
      // cmdExit
      // 
      this.cmdExit.Location = new System.Drawing.Point(312, 112);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.Size = new System.Drawing.Size(72, 24);
      this.cmdExit.TabIndex = 17;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // cmdCalculation
      // 
      this.cmdCalculation.Location = new System.Drawing.Point(312, 72);
      this.cmdCalculation.Name = "cmdCalculation";
      this.cmdCalculation.Size = new System.Drawing.Size(72, 24);
      this.cmdCalculation.TabIndex = 16;
      this.cmdCalculation.Text = "&Calculation";
      this.cmdCalculation.Click += new System.EventHandler(this.cmdCalculation_Click);
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(296, 32);
      this.txtResult.Name = "txtResult";
      this.txtResult.Size = new System.Drawing.Size(112, 20);
      this.txtResult.TabIndex = 15;
      this.txtResult.Text = "";
      // 
      // grpOperator
      // 
      this.grpOperator.Controls.Add(this.optDivision);
      this.grpOperator.Controls.Add(this.optMultiplication);
      this.grpOperator.Controls.Add(this.optSubtract);
      this.grpOperator.Controls.Add(this.optAdd);
      this.grpOperator.Location = new System.Drawing.Point(120, 24);
      this.grpOperator.Name = "grpOperator";
      this.grpOperator.Size = new System.Drawing.Size(168, 104);
      this.grpOperator.TabIndex = 13;
      this.grpOperator.TabStop = false;
      this.grpOperator.Text = "Operator";
      // 
      // optDivision
      // 
      this.optDivision.Location = new System.Drawing.Point(8, 72);
      this.optDivision.Name = "optDivision";
      this.optDivision.Size = new System.Drawing.Size(152, 16);
      this.optDivision.TabIndex = 3;
      this.optDivision.Text = "Division (/)";
      // 
      // optMultiplication
      // 
      this.optMultiplication.Location = new System.Drawing.Point(8, 56);
      this.optMultiplication.Name = "optMultiplication";
      this.optMultiplication.Size = new System.Drawing.Size(136, 16);
      this.optMultiplication.TabIndex = 2;
      this.optMultiplication.Text = "Multiplication (*)";
      // 
      // optSubtract
      // 
      this.optSubtract.Location = new System.Drawing.Point(8, 40);
      this.optSubtract.Name = "optSubtract";
      this.optSubtract.Size = new System.Drawing.Size(136, 16);
      this.optSubtract.TabIndex = 1;
      this.optSubtract.Text = "Subtract (-)";
      // 
      // optAdd
      // 
      this.optAdd.Location = new System.Drawing.Point(8, 24);
      this.optAdd.Name = "optAdd";
      this.optAdd.Size = new System.Drawing.Size(112, 16);
      this.optAdd.TabIndex = 0;
      this.optAdd.Text = "Add (+)";
      // 
      // txtVariable1
      // 
      this.txtVariable1.Location = new System.Drawing.Point(16, 32);
      this.txtVariable1.Name = "txtVariable1";
      this.txtVariable1.Size = new System.Drawing.Size(88, 20);
      this.txtVariable1.TabIndex = 10;
      this.txtVariable1.Text = "";
      // 
      // txtVariable2
      // 
      this.txtVariable2.Location = new System.Drawing.Point(16, 88);
      this.txtVariable2.Name = "txtVariable2";
      this.txtVariable2.Size = new System.Drawing.Size(88, 20);
      this.txtVariable2.TabIndex = 12;
      this.txtVariable2.Text = "";
      // 
      // frmBasicCalculation
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(416, 165);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.lblVariable2);
      this.Controls.Add(this.lblVariable1);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.cmdCalculation);
      this.Controls.Add(this.txtResult);
      this.Controls.Add(this.grpOperator);
      this.Controls.Add(this.txtVariable1);
      this.Controls.Add(this.txtVariable2);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBasicCalculation";
      this.Text = "Test basic calculation";
      this.grpOperator.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBasicCalculation'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBasicCalculation()
      //***
      // Action
      //   - Create instance of 'frmBasicCalculation'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmBasicCalculation()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
      double mdblFirstNumber;
      double mdblSecondNumber;
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCalculation_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Read the two textboxes and place them into integer variables
      //   - Depending the check option
      //     - Do calculation and place ToString property into textbox
      //     - Concatenation is an exception
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - System.Convert.ToDouble(String) As Double
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      double dblResult;

      mdblFirstNumber = Convert.ToDouble(txtVariable1.Text);
      mdblSecondNumber = Convert.ToDouble(txtVariable2.Text);

      if (optAdd.Checked)
      {
        dblResult = mdblFirstNumber + mdblSecondNumber;
        txtResult.Text = dblResult.ToString();
      }
      else
        // Not optAdd.Checked
      {
      }
      // optAdd.Checked

      if (optSubtract.Checked)
      {
        dblResult = mdblFirstNumber - mdblSecondNumber;
        txtResult.Text = dblResult.ToString();
      }
      else
        // Not optSubtract.Checked 
      {
      }
      // optSubtract.Checked 

      if (optMultiplication.Checked)
      {
        dblResult = mdblFirstNumber * mdblSecondNumber;
        txtResult.Text = dblResult.ToString();
      }
      else
        // Not optMultiplication.Checked
      {
      }
      // optMultiplication.Checked

      if (optDivision.Checked)
      {
        dblResult = mdblFirstNumber / mdblSecondNumber;
        txtResult.Text = dblResult.ToString();
      }
      else
        // Not optDivision.Checked 
      {
      }
      // optDivision.Checked 
    
    }
    // cmdCalculation_Click(System.Object, System.EventArgs) Handles cmdCalculation.Click

    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop program
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit_Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmBasicCalculation
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmBasicCalculation()
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmBasicCalculation());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBasicCalculation

}
// CopyPaste.Learning