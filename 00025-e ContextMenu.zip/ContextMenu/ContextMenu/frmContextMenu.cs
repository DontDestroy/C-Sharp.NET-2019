//***
// Action
//   - Working with a context menu on a label
//   - This form as startpoint of the exercise
// Created
//   - CopyPaste � 20230416 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230416 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace ContextMenu
{
	public class frmContextMenu: System.Windows.Forms.Form
	{
    internal System.Windows.Forms.ContextMenu ctmMenu;
    internal System.Windows.Forms.MenuItem mnuInsert;
    internal System.Windows.Forms.MenuItem mnuInsertDate;
    internal System.Windows.Forms.MenuItem mnuInsertTime;
    internal System.Windows.Forms.MenuItem mnuColor;
    internal System.Windows.Forms.MenuItem mnuColorBlack;
    internal System.Windows.Forms.MenuItem mnuColorBlue;
    internal System.Windows.Forms.MenuItem mnuColorGreen;
    internal System.Windows.Forms.MenuItem mnuColorRed;
    internal System.Windows.Forms.Label lblText;

		#region Windows Form Designer generated code
		private System.ComponentModel.Container components = null;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmContextMenu));
      this.ctmMenu = new System.Windows.Forms.ContextMenu();
      this.mnuInsert = new System.Windows.Forms.MenuItem();
      this.mnuInsertDate = new System.Windows.Forms.MenuItem();
      this.mnuInsertTime = new System.Windows.Forms.MenuItem();
      this.mnuColor = new System.Windows.Forms.MenuItem();
      this.mnuColorBlack = new System.Windows.Forms.MenuItem();
      this.mnuColorBlue = new System.Windows.Forms.MenuItem();
      this.mnuColorGreen = new System.Windows.Forms.MenuItem();
      this.mnuColorRed = new System.Windows.Forms.MenuItem();
      this.lblText = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // ctmMenu
      // 
      this.ctmMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuInsert,
                                                                            this.mnuColor});
      // 
      // mnuInsert
      // 
      this.mnuInsert.Index = 0;
      this.mnuInsert.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.mnuInsertDate,
                                                                              this.mnuInsertTime});
      this.mnuInsert.Text = "Insert";
      // 
      // mnuInsertDate
      // 
      this.mnuInsertDate.Index = 0;
      this.mnuInsertDate.Text = "Date";
      this.mnuInsertDate.Click += new System.EventHandler(this.mnuInsertDate_Click);
      // 
      // mnuInsertTime
      // 
      this.mnuInsertTime.Index = 1;
      this.mnuInsertTime.Text = "Time";
      this.mnuInsertTime.Click += new System.EventHandler(this.mnuInsertTime_Click);
      // 
      // mnuColor
      // 
      this.mnuColor.Index = 1;
      this.mnuColor.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                             this.mnuColorBlack,
                                                                             this.mnuColorBlue,
                                                                             this.mnuColorGreen,
                                                                             this.mnuColorRed});
      this.mnuColor.Text = "Color";
      // 
      // mnuColorBlack
      // 
      this.mnuColorBlack.Index = 0;
      this.mnuColorBlack.Text = "Black";
      this.mnuColorBlack.Click += new System.EventHandler(this.mnuColorBlack_Click);
      // 
      // mnuColorBlue
      // 
      this.mnuColorBlue.Index = 1;
      this.mnuColorBlue.Text = "Blue";
      this.mnuColorBlue.Click += new System.EventHandler(this.mnuColorBlue_Click);
      // 
      // mnuColorGreen
      // 
      this.mnuColorGreen.Index = 2;
      this.mnuColorGreen.Text = "Green";
      this.mnuColorGreen.Click += new System.EventHandler(this.mnuColorGreen_Click);
      // 
      // mnuColorRed
      // 
      this.mnuColorRed.Index = 3;
      this.mnuColorRed.Text = "Red";
      this.mnuColorRed.Click += new System.EventHandler(this.mnuColorRed_Click);
      // 
      // lblText
      // 
      this.lblText.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblText.ContextMenu = this.ctmMenu;
      this.lblText.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblText.Location = new System.Drawing.Point(112, 112);
      this.lblText.Name = "lblText";
      this.lblText.Size = new System.Drawing.Size(256, 48);
      this.lblText.TabIndex = 1;
      this.lblText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      this.lblText.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lblText_MouseDown);
      // 
      // frmContextMenu
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(480, 405);
      this.Controls.Add(this.lblText);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.ImeMode = System.Windows.Forms.ImeMode.Off;
      this.Name = "frmContextMenu";
      this.Text = "Context Menu";
      this.ResumeLayout(false);

    }
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230416 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20230416 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmContextMenu()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230416 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230416 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
		}
		// frmContextMenu()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmContextMenu
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230416 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230416 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmContextMenu());
		}
    // Main() 

    private void lblText_MouseDown(System.Object theSender, System.Windows.Forms.MouseEventArgs theMouseEventArguments)
    //***
    // Action
    //   - The label gets the context menu linked to it
    // Called by
    //   - User action (Rightclick on the label)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230416 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230416 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (theMouseEventArguments.Button == MouseButtons.Right)
      {
        ctmMenu.Show(lblText, new Point(theMouseEventArguments.X, theMouseEventArguments.Y));
      }
      else
        // theMouseEventArguments.Button <> MouseButtons.Right
      {
      }
      // theMouseEventArguments.Button = MouseButtons.Right
    
    }
    // lblText_MouseDown(System.Object theSender, System.Windows.Forms.MouseEventArgs theMouseEventArguments) Handles lblText.MouseDown
  
    private void mnuColorBlack_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - The label forecolor becomes black
    // Called by
    //   - User action (Clicking on menu mnuColorBlack)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230416 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230416 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblText.ForeColor = Color.Black;
    }
    // mnuColorBlack_Click(System.Object, System.EventArgs) Handles mnuColorBlack.Click

    private void mnuColorBlue_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - The label forecolor becomes blue
    // Called by
    //   - User action (Clicking on menu mnuColorBlue)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230416 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230416 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblText.ForeColor = Color.Blue;
    }
    // mnuColorBlue_Click(System.Object, System.EventArgs) Handles mnuColorBlue.Click

    private void mnuColorGreen_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - The label forecolor becomes green
    // Called by
    //   - User action (Clicking on menu mnuColorGreen)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230416 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230416 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblText.ForeColor = Color.Green;
    }
    // mnuColorGreen_Click(System.Object, System.EventArgs) Handles mnuColorBlue.Click
  
    private void mnuColorRed_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - The label forecolor becomes red
    // Called by
    //   - User action (Clicking on menu mnuColorRed)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230416 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230416 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblText.ForeColor = Color.Red;
    }
    // mnuColorRed_Click(System.Object, System.EventArgs) Handles mnuColorRed.Click

    private void mnuInsertDate_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - The label becomes the date of today
    // Called by
    //   - User action (Clicking on menu mnuInsertDate)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230416 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230416 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblText.Text = System.DateTime.Now.ToShortDateString();
    }
    // mnuInsertDate_Click(System.Object, System.EventArgs) Handles mnuInsertDate.Click

    private void mnuInsertTime_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - The label becomes the time of now
    // Called by
    //   - User action (Clicking on menu mnuInsertTime)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230416 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230416 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblText.Text = System.DateTime.Now.ToShortTimeString();
    }
    // mnuInsertTime_Click(System.Object, System.EventArgs) Handles mnuInsertTime.Click

    #endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmContextMenu

}
// ContextMenu