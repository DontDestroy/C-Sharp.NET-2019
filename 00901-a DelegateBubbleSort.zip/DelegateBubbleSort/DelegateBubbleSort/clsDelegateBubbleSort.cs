﻿//***
// Action
//   - A delegate that sorts a list of numbers
//   - The whole idea is that the way to compare is not defined in this class
//     - The user (consumer) of the class must say how to compare
// Created
//   - CopyPaste – 20250712 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250712 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpDelegateBubbleSort
  {

    #region "Constructors / Destructors"

    public cpDelegateBubbleSort()
      //***
      // Action
      //   - Empty constructor
      // Called by
      //   - frmBubbleSort()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250712 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250712 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDelegateBubbleSort()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate bool cpComparator(int lngElement1, int lngElement2);

    #endregion

    #region "Sub / Function"

    public void SortArray(int[] arrElement, cpComparator thecpCompare)
      //***
      // Action
      //   - Sort is done by the bubble sort technique
      //   - Define 2 integers (a counter and a looper)
      //   - For every element in the array (using counter)
      //     - For every element in the array except the last (using looper)
      //       - Compare current element with next element (using delegate)
      //       - If the delegate result is true
      //         - Swap both elements
      //       - If not
      //         - Do nothing
      // Called by
      //   - frmBubbleSort.cmdSortAscending_Click(System.Object, System.EventArgs) Handles cmdSortAscending.Click
      // Calls
      //   - bool cpComparator(int, int)
      //   - Swap(°int, °int)
      // Created
      //   - CopyPaste – 20250712 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250712 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngCounter;
      int lngLoop;
      int lngTillCounter;
      int lngTillLoop;

      lngTillCounter = arrElement.GetUpperBound(0);

      for (lngCounter = 0; lngCounter <= lngTillCounter; lngCounter++)
      {
        lngTillLoop = arrElement.GetUpperBound(0) - 1;

        for (lngLoop = 0; lngLoop <= lngTillLoop; lngLoop++)
        {

          if (thecpCompare(arrElement[lngLoop], arrElement[lngLoop + 1]))
          {
            Swap(ref arrElement[lngLoop], ref arrElement[lngLoop + 1]);
          }
          else
            // Not thecpCompare(arrElement[lngLoop], arrElement[lngLoop + 1])
          {
          }
          // thecpCompare(arrElement[lngLoop], arrElement[lngLoop + 1])
        
        }
        // lngLoop = lngTillLoop + 1

      }
      // lngCounter = lngTillCounter + 1

    }
		// SortArray(int[], cpComparator)

    private void Swap(ref int lngElement1, ref int lngElement2)
      //***
      // Action
      //   - Swap 2 given elements
      //   - First becomes second and vice versa
      // Called by
      //   - SortArray(int[], cpComparator)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250712 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250712 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngRemember;

      lngRemember = lngElement1;
      lngElement1 = lngElement2;
      lngElement2 = lngRemember;
    }
    // Swap(°int, °int)
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDelegateBubbleSort

}
// CopyPaste.Learning