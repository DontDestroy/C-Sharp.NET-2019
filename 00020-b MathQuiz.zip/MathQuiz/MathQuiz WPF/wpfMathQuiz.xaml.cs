﻿//***
// Action
//   - Creating a math quiz
//   - This is a form as startpoint of the exercise
// Created
//   - CopyPaste – 20220908 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20220908 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MathQuiz_WPF
{

  public partial class wpfMathQuiz : Window
  {

    #region "Constructors / Destructors"

    public wpfMathQuiz()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220908 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220908 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfMathQuiz()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    static int mintAnswer;
    static Random mrndRandom = new Random(DateTime.Now.Millisecond);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAnswer_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Try
    //     - If mintAnswer equals txtResult (converted to integer)
    //       - Show message "You got the answer right!".
    //     - If Not
    //       - Show message "Oh no, you missed that one!".
    //   - On Error
    //     - Show message "Please enter a number."
    //   - Create a new math problem
    //   - Clear txtResult
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - CreateMathProblem()
    // Created
    //   - CopyPaste – 20220908 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220908 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      try
      {

        if (mintAnswer == int.Parse(txtResult.Text))
        {
          MessageBox.Show("You got the answer right!", "Correct");
        }
        else
        // (mintAnswer <> int.Parse(txtResult.Text)
        {
          MessageBox.Show("Oh no, you missed that one!", "Wrong");
        }
        // (mintAnswer == int.Parse(txtResult.Text)

      }
      catch (Exception theException)
      {
        MessageBox.Show("Please enter a number.");
      }

      CreateMathProblem();
      txtResult.Text = "";
    }
    // cmdAnswer_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAnswer.Click

    private void cmdQuit_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - End application
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220908 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220908 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //   - Alternative: Application.Exit();
    //     - Is this better?
    //***
    {
      this.Close();
    }
    // cmdQuit_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdQuit.Click


    private void wndStartup_Loaded(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //'***
    //' Action
    //'   - Create a new math problem
    //' Called by
    //'   - User action (loading the form)
    //' Calls
    //'   - CreateMathProblem()
    //' Created
    //'   - CopyPaste – 20220908 – VVDW
    //' Changed
    //'   - Organisation – yyyymmdd – Initials of programmer – What changed
    //' Tested
    //'   - CopyPaste – 20220908 – VVDW
    //' Keyboard key
    //'   - 
    //' Proposal (To Do)
    //'   - List of actions that can be added to the functionality
    //'***
    {
      CreateMathProblem();
    }
    // wndStartup_Loaded(System.Object, System.Windows.RoutedEventArgs) Handles wndStartup.Loaded

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void CreateMathProblem()
    //***
    // Action
    //   - Define a random first number (intFirst)
    //   - Define a random second number (intSecond)
    //   - Define a random operator
    //     - When 0
    //       - Correct answer is intFirst + intSecond
    //     - When 1
    //       - Correct answer is intFirst - intSecond
    //     - When 2
    //       - Correct answer is intFirst * intSecond
    // Called by
    //   - cmdAnswer_Click(System.Object, System.RoutedEventArgs) Handles cmdAnswer.Click
    //   - wndStartup_Loaded(System.Object, System.RoutedEventArgs) Handles wndStartup.Loaded
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220908 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220908 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int intFirst;
      int intSecond;

      intFirst = mrndRandom.Next(11);
      lblNumber01.Content = intFirst.ToString();
      intSecond = mrndRandom.Next(11);
      lblNumber02.Content = intSecond.ToString();

      switch (mrndRandom.Next(3))
      {
        case 0:
          lblOperator.Content = "+";
          mintAnswer = intFirst + intSecond;
          break;
        case 1:
          lblOperator.Content = "-";
          mintAnswer = intFirst - intSecond;
          break;
        case 2:
          lblOperator.Content = "*";
          mintAnswer = intFirst * intSecond;
          break;
        default:
          // Not 0, 1, 2
          break;
      }
      // mrndRandom.Next(3)

    }
    // CreateMathProblem()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfMathQuiz

}
// MathQuiz_WPF