//***
// Action
//   - Demo of cpTextImage and cpPictureBoxWithText
// Created
//   - CopyPaste � 20260805 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260805 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Toolkit.UserInterface;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Web;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmExample: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmExample));
      // 
      // frmExample
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmExample";
      this.Text = "Example";
      this.Load += new System.EventHandler(this.frmExample_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmExample'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260805 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260805 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmExample()
    //***
    // Action
    //   - Create instance of 'frmExample'
    // Called by
    //   - Main()
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste � 20260805 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260805 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmExample()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmExample_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Set a left, top, height and width
    //   - Create 3 picture boxes
    //   - Define 2 cpTextImage
    //   - Define 1 cpPictureBoxWithText
    //   - Set the position of the first picture
    //   - Initialize a first cpTextImage
    //   - Draw the image
    //   - Draw the text Hello
    //   - Add 20 to the left
    //   - Add 30 to the top
    //   - Set the position of the second picture
    //   - Initialize a second cpTextImage
    //   - Draw the image
    //   - Draw the text World
    //   - Add 20 to the left
    //   - Add 30 to the top
    //   - Set the position of the third picture
    //   - Initialize a first cpPictureBoxWithText
    //   - Draw the image
    //   - Draw the text Copy Paste
    //   - Set the 3 images into the picture box
    //   - Save the 3 images to the current directory
    //   - Add the 3 controls to the form
    // Called by
    //   - User action (Loading a form)
    // Calls
    //   - cpPictureBoxWithText(int, int)
    //   - cpPictureBoxWithText.DrawImage(int, int, Color, Color)
    //   - cpTextImage(int, int)
    //   - cpTextImage.DrawImage(int, int, Color, Color)
    //   - cpTextImage.DrawTextOnImage(string, Color, int, int, string, int)
    //   - cpTextImage.WriteTo(string, System.Drawing.Imaging.ImageFormat)
    // Created
    //   - CopyPaste � 20260805 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260805 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intLeft = 10;
      int intTop = 20;
      int intHeight = 20;
      int intWidth = 100;
      PictureBox thePicture1 = new PictureBox();
      PictureBox thePicture2 = new PictureBox();
      PictureBox thePicture3 = new PictureBox();

      cpTextImage theTextImage1;
      cpTextImage theTextImage2;
      cpPictureBoxWithText theTextImage3;

      thePicture1.Left = intLeft;
      thePicture1.Top = intTop;
      thePicture1.Height = intHeight;
      thePicture1.Width = intWidth;

      theTextImage1 = new cpTextImage(0, 0);
      theTextImage1.DrawImage(intWidth, intHeight, Color.Green, Color.Gainsboro);
      theTextImage1.DrawTextOnImage("Hello", Color.Green, 10, 1, "Tahoma", 10);

      intLeft += 20;
      intTop += 30;

      thePicture2.Left = intLeft;
      thePicture2.Top = intTop;
      thePicture2.Height = intHeight;
      thePicture2.Width = intWidth;

      theTextImage2 = new cpTextImage(0, 0);
      theTextImage2.DrawImage(intWidth, intHeight, Color.Green, Color.Gainsboro);
      theTextImage2.DrawTextOnImage("World", Color.Green, 10, 1, "Tahoma", 10);

      intLeft += 20;
      intTop += 30;

      thePicture3.Left = intLeft;
      thePicture3.Top = intTop;
      thePicture3.Height = intHeight;
      thePicture3.Width = intWidth;

      theTextImage3 = new cpPictureBoxWithText(0, 0);
      theTextImage3.DrawImage(intWidth, intHeight, Color.Green, Color.Gainsboro);
      theTextImage3.DrawTextOnImage("Copy Paste", Color.Green, 10, 1, "Tahoma", 10);

      thePicture1.Image = theTextImage1.Image;
      thePicture2.Image = theTextImage2.Image;
      thePicture3.Image = theTextImage3.Image;

      theTextImage1.WriteTo("TextImage1.jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
      theTextImage2.WriteTo("TextImage2.jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
      theTextImage3.WriteTo("TextImage3.jpg", System.Drawing.Imaging.ImageFormat.Jpeg);

      this.Controls.Add(thePicture1);
      this.Controls.Add(thePicture2);
      this.Controls.Add(thePicture3);
    }
    // frmExample_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmExample
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmExample()
    // Created
    //   - CopyPaste � 20260805 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260805 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmExample());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmExample

}
// CopyPaste.Learning