﻿using System.Windows;

namespace WPFTextBox
{
  public partial class wpfExampleTextBox : Window
  {

    public wpfExampleTextBox()
    {
      InitializeComponent();
    }
    // wpfExampleTextBox()

  }
  // wpfExampleTextBox

}
// WPFTextBox