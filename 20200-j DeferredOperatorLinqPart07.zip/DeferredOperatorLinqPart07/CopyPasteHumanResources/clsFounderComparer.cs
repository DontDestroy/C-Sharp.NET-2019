﻿//***
// Action
//   - The compare if an employee is a founder or not
//   - When EmployeeNumber is 1, it is a founder
// Created
//   - CopyPaste – 20230505 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230505 – VVDW
// Proposal (To Do)
//   - Personally I do this with a property in the class cpEmployee
//   - For demo purposes it is done with a selfmade comparer
//***

using System.Collections.Generic;

namespace CopyPaste.HumanResources
{

  public class cpFounderComparer : IEqualityComparer<int>
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public bool Equals(int intFirstEmployee, int intSecondEmployee)
    //***
    // Action
    //   - Implementation of Equals method of IEqualityComparer<T>
    //   - An employee is considered equal with another when both are a founder or not
    // Called by
    //   - 
    // Calls
    //   - bool IsFounder(int)
    // Created
    //   - CopyPaste – 20230505 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230505 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return (IsFounder(intFirstEmployee) == IsFounder(intSecondEmployee));
    }
    // bool Equals(int, int)

    public int GetHashCode(int intEmployee)
    //***
    // Action
    //   - Implementation of GetHashCode method of IEqualityComparer<T>
    //   - An employee has a HashCode of one when the employee is a founder
    //   - An employee has a HashCode of zero when the employee is not a founder
    // Called by
    //   - 
    // Calls
    //   - bool IsFounder(int)
    // Created
    //   - CopyPaste – 20230505 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230505 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intFounder = 1;
      int intNotFounder = 100;

      if (IsFounder(intEmployee))
      {
        return intFounder.GetHashCode();
      }
      else
      // Not IsFounder(intEmployee)
      {
        return intNotFounder.GetHashCode();
      }
      // IsFounder(intEmployee)

    }
    // int GetHashCode(int)

    public bool IsFounder(bool blnFounder)
    //***
    // Action
    //   - An employee is a founder when the boolean founder is true
    // Called by
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230505 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230505 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return (blnFounder);
    }
    // bool IsFounder(bool)

    public bool IsFounder(int intEmployeeNumber)
    //***
    // Action
    //   - An employee is a founder when the EmployeeNumber is 1
    // Called by
    //   - bool Equals(int, int)
    //   - int GetHashCode(int)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230505 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230505 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return (intEmployeeNumber == 1);
    }
    // bool IsFounder(int)

    #endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion  

  }
  // cpFounderComparer

}
// CopyPaste.HumanResources 