//***
// Action
//   - Demo of a data grid
//     - cpStudents 2003.mdb
// Created
//   - CopyPaste � 20240615 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240615 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.Data
{

  public class frmDataGrid: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdUpdate;
    internal System.Data.OleDb.OleDbCommand cmmUpdateInstructor;
    internal System.Data.OleDb.OleDbConnection cnncpStudents;
    internal System.Data.OleDb.OleDbCommand cmmSelectInstructor;
    internal System.Windows.Forms.Button cmdLoad;
    internal System.Data.OleDb.OleDbCommand cmmDeleteInstructor;
    internal System.Data.OleDb.OleDbCommand cmmInsertInstructor;
    internal System.Windows.Forms.DataGrid dgrInstructors;
    internal System.Data.OleDb.OleDbDataAdapter dtaInstructor;
    private DataGrid.dsData dsData;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataGrid));
      this.cmdUpdate = new System.Windows.Forms.Button();
      this.cmmUpdateInstructor = new System.Data.OleDb.OleDbCommand();
      this.cnncpStudents = new System.Data.OleDb.OleDbConnection();
      this.cmmSelectInstructor = new System.Data.OleDb.OleDbCommand();
      this.cmdLoad = new System.Windows.Forms.Button();
      this.cmmDeleteInstructor = new System.Data.OleDb.OleDbCommand();
      this.cmmInsertInstructor = new System.Data.OleDb.OleDbCommand();
      this.dgrInstructors = new System.Windows.Forms.DataGrid();
      this.dsData = new DataGrid.dsData();
      this.dtaInstructor = new System.Data.OleDb.OleDbDataAdapter();
      ((System.ComponentModel.ISupportInitialize)(this.dgrInstructors)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdUpdate
      // 
      this.cmdUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdUpdate.Location = new System.Drawing.Point(104, 159);
      this.cmdUpdate.Name = "cmdUpdate";
      this.cmdUpdate.Size = new System.Drawing.Size(75, 23);
      this.cmdUpdate.TabIndex = 5;
      this.cmdUpdate.Text = "&Update";
      this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
      // 
      // cmmUpdateInstructor
      // 
      this.cmmUpdateInstructor.CommandText = "UPDATE tblCPInstructor SET strExtension = ?, strInstructor = ?, strPhoneNumber = " +
    "? WHERE (lngIdInstructor = ?)";
      this.cmmUpdateInstructor.Connection = this.cnncpStudents;
      this.cmmUpdateInstructor.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("strExtension", System.Data.OleDb.OleDbType.VarWChar, 30, "strExtension"),
            new System.Data.OleDb.OleDbParameter("strInstructor", System.Data.OleDb.OleDbType.VarWChar, 50, "strInstructor"),
            new System.Data.OleDb.OleDbParameter("strPhoneNumber", System.Data.OleDb.OleDbType.VarWChar, 30, "strPhoneNumber"),
            new System.Data.OleDb.OleDbParameter("Original_lngIdInstructor", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "lngIdInstructor", System.Data.DataRowVersion.Original, null)});
      // 
      // cnncpStudents
      // 
      this.cnncpStudents.ConnectionString = resources.GetString("cnncpStudents.ConnectionString");
      // 
      // cmmSelectInstructor
      // 
      this.cmmSelectInstructor.CommandText = "SELECT lngIdInstructor, strExtension, strInstructor, strPhoneNumber FROM tblCPIns" +
    "tructor";
      this.cmmSelectInstructor.Connection = this.cnncpStudents;
      // 
      // cmdLoad
      // 
      this.cmdLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdLoad.Location = new System.Drawing.Point(16, 159);
      this.cmdLoad.Name = "cmdLoad";
      this.cmdLoad.Size = new System.Drawing.Size(75, 23);
      this.cmdLoad.TabIndex = 4;
      this.cmdLoad.Text = "&Load";
      this.cmdLoad.Click += new System.EventHandler(this.cmdLoad_Click);
      // 
      // cmmDeleteInstructor
      // 
      this.cmmDeleteInstructor.CommandText = "DELETE FROM tblCPInstructor WHERE (lngIdInstructor = ?)";
      this.cmmDeleteInstructor.Connection = this.cnncpStudents;
      this.cmmDeleteInstructor.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("Original_lngIdInstructor", System.Data.OleDb.OleDbType.Integer, 0, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "lngIdInstructor", System.Data.DataRowVersion.Original, null)});
      // 
      // cmmInsertInstructor
      // 
      this.cmmInsertInstructor.CommandText = "INSERT INTO tblCPInstructor(strExtension, strInstructor, strPhoneNumber) VALUES (" +
    "?, ?, ?)";
      this.cmmInsertInstructor.Connection = this.cnncpStudents;
      this.cmmInsertInstructor.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("strExtension", System.Data.OleDb.OleDbType.VarWChar, 30, "strExtension"),
            new System.Data.OleDb.OleDbParameter("strInstructor", System.Data.OleDb.OleDbType.VarWChar, 50, "strInstructor"),
            new System.Data.OleDb.OleDbParameter("strPhoneNumber", System.Data.OleDb.OleDbType.VarWChar, 30, "strPhoneNumber")});
      // 
      // dgrInstructors
      // 
      this.dgrInstructors.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrInstructors.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.dgrInstructors.DataMember = "tblCPInstructor";
      this.dgrInstructors.DataSource = this.dsData;
      this.dgrInstructors.GridLineColor = System.Drawing.Color.Blue;
      this.dgrInstructors.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrInstructors.Location = new System.Drawing.Point(8, 15);
      this.dgrInstructors.Name = "dgrInstructors";
      this.dgrInstructors.PreferredColumnWidth = 110;
      this.dgrInstructors.Size = new System.Drawing.Size(590, 128);
      this.dgrInstructors.TabIndex = 3;
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // dtaInstructor
      // 
      this.dtaInstructor.DeleteCommand = this.cmmDeleteInstructor;
      this.dtaInstructor.InsertCommand = this.cmmInsertInstructor;
      this.dtaInstructor.SelectCommand = this.cmmSelectInstructor;
      this.dtaInstructor.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPInstructor", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("lngIdInstructor", "lngIdInstructor"),
                        new System.Data.Common.DataColumnMapping("strExtension", "strExtension"),
                        new System.Data.Common.DataColumnMapping("strInstructor", "strInstructor"),
                        new System.Data.Common.DataColumnMapping("strPhoneNumber", "strPhoneNumber")})});
      this.dtaInstructor.UpdateCommand = this.cmmUpdateInstructor;
      // 
      // frmDataGrid
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(606, 197);
      this.Controls.Add(this.dgrInstructors);
      this.Controls.Add(this.cmdUpdate);
      this.Controls.Add(this.cmdLoad);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataGrid";
      this.Text = "Data Grid";
      ((System.ComponentModel.ISupportInitialize)(this.dgrInstructors)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDataGrid'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240615 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240615 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDataGrid()
      //***
      // Action
      //   - Create instance of 'frmDataGrid'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240615 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240615 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDataGrid()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdLoad_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Clear the data set
      //   - Fill the data set thru the data adapter
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240615 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240615 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsData.Clear();
      dtaInstructor.Fill(dsData);
    }
    // cmdLoad_Click(theSender, theEventArguments) Handles cmdLoad.Click

    private void cmdUpdate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try
      //     - Update the data set thru the data adapter
      //   - When something fails
      //     - Show error message
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240615 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240615 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
  
      try
      {
        dtaInstructor.Update(dsData);
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.ToString());
      }
      finally
      {
      }
 
    }
    // cmdUpdate_Click(System.Object, System.EventArgs) Handles cmdUpdate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDataGrid
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDataGrid()
      // Created
      //   - CopyPaste � 20240615 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240615 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDataGrid());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataGrid

}
// CopyPaste.Learning.Data