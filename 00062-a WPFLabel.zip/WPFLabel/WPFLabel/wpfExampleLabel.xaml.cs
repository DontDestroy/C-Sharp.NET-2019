﻿using System.Windows;

namespace WPFLabel
{
  public partial class wpfExampleLabel : Window
  {
    public wpfExampleLabel()
    {
      InitializeComponent();
    }
    // wpfExampleLabel()

  }
  // wpfExampleLabel

}
// WPFLabel