//***
// Action
//   - Looping thru all the files of a certain directory and subdirectory
// Created
//   - CopyPaste � 20240722 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240722 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private static void DisplayTree(string strDirectory)
      //***
      // Action
      //   - Try to
      //     - Fill an array with files of a certain directory (strDirectory)
      //     - Fill an array with directories of a certain directory (strDirectory)
      //     - Loop thru all the files in the file array
      //       - Show the filename
      //     - Loop thru all the directories in the directory array
      //       - Display the tree of directory
      // Called by
      //   - DisplayTree(string)
      //   - Main()
      // Calls
      //   - DisplayTree(string)
      // Created
      //   - CopyPaste � 20240722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240722 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        string[] arrstrFile = Directory.GetFiles(strDirectory);
        string[] arrstrDirectory = Directory.GetDirectories(strDirectory);

        foreach (string strFilename in arrstrFile)
        {
          Console.WriteLine(strFilename);
        }
        // in arrstrFile

        foreach (string strDirectoryName in arrstrDirectory)
        {
          DisplayTree(strDirectoryName);
        }
        // in arrstrDirectory

      }
      catch 
      {
      }

    }
    // DisplayTree(string)

    public static void Main()
      //***
      // Action
      //   - Display the tree of directory T:\
      //   - Wait for user to hit any key
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - DisplayTree(string)
      // Created
      //   - CopyPaste � 20240722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240722 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      DisplayTree("T:\\");
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning