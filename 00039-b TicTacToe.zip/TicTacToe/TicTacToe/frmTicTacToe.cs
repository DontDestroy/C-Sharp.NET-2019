//***
// Action
//   - Creating the game TicTacToe. This is form as startpoint of the exercise
// Created
//   - CopyPaste � 20240201 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240201 � VVDW
// Proposal (To Do)
//   - A lot refactorings / improvements can be done here, but it is a simple start
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmTicTacToe: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdRestart;
    internal System.Windows.Forms.Button cmdQuit;
    internal System.Windows.Forms.Label lblPlayer;
    internal System.Windows.Forms.Button cmd09;
    internal System.Windows.Forms.Button cmd08;
    internal System.Windows.Forms.Button cmd07;
    internal System.Windows.Forms.Button cmd06;
    internal System.Windows.Forms.Button cmd05;
    internal System.Windows.Forms.Button cmd04;
    internal System.Windows.Forms.Button cmd03;
    internal System.Windows.Forms.Button cmd02;
    internal System.Windows.Forms.Button cmd01;
    internal System.Windows.Forms.Panel panHorizontal02;
    internal System.Windows.Forms.Panel panHorizontal01;
    internal System.Windows.Forms.Panel panVertical01;
    internal System.Windows.Forms.Label lblTitle;
    internal System.Windows.Forms.Panel panVertical02;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTicTacToe));
      this.cmdRestart = new System.Windows.Forms.Button();
      this.cmdQuit = new System.Windows.Forms.Button();
      this.lblPlayer = new System.Windows.Forms.Label();
      this.cmd09 = new System.Windows.Forms.Button();
      this.cmd08 = new System.Windows.Forms.Button();
      this.cmd07 = new System.Windows.Forms.Button();
      this.cmd06 = new System.Windows.Forms.Button();
      this.cmd05 = new System.Windows.Forms.Button();
      this.cmd04 = new System.Windows.Forms.Button();
      this.cmd03 = new System.Windows.Forms.Button();
      this.cmd02 = new System.Windows.Forms.Button();
      this.cmd01 = new System.Windows.Forms.Button();
      this.panHorizontal02 = new System.Windows.Forms.Panel();
      this.panHorizontal01 = new System.Windows.Forms.Panel();
      this.panVertical01 = new System.Windows.Forms.Panel();
      this.lblTitle = new System.Windows.Forms.Label();
      this.panVertical02 = new System.Windows.Forms.Panel();
      this.SuspendLayout();
      // 
      // cmdRestart
      // 
      this.cmdRestart.Location = new System.Drawing.Point(350, 488);
      this.cmdRestart.Name = "cmdRestart";
      this.cmdRestart.Size = new System.Drawing.Size(72, 24);
      this.cmdRestart.TabIndex = 4;
      this.cmdRestart.Text = "RESTART";
      this.cmdRestart.Click += new System.EventHandler(this.cmdRestart_Click);
      // 
      // cmdQuit
      // 
      this.cmdQuit.Location = new System.Drawing.Point(428, 488);
      this.cmdQuit.Name = "cmdQuit";
      this.cmdQuit.Size = new System.Drawing.Size(72, 24);
      this.cmdQuit.TabIndex = 4;
      this.cmdQuit.Text = "QUIT";
      this.cmdQuit.Click += new System.EventHandler(this.cmdQuit_Click);
      // 
      // lblPlayer
      // 
      this.lblPlayer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblPlayer.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblPlayer.Location = new System.Drawing.Point(8, 488);
      this.lblPlayer.Name = "lblPlayer";
      this.lblPlayer.Size = new System.Drawing.Size(336, 24);
      this.lblPlayer.TabIndex = 3;
      this.lblPlayer.Text = "Player";
      this.lblPlayer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cmd09
      // 
      this.cmd09.BackColor = System.Drawing.Color.LimeGreen;
      this.cmd09.Font = new System.Drawing.Font("Arial Black", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmd09.Location = new System.Drawing.Point(350, 336);
      this.cmd09.Name = "cmd09";
      this.cmd09.Size = new System.Drawing.Size(90, 90);
      this.cmd09.TabIndex = 0;
      this.cmd09.Click += new System.EventHandler(this.cmd09_Click);
      // 
      // cmd08
      // 
      this.cmd08.BackColor = System.Drawing.Color.LimeGreen;
      this.cmd08.Font = new System.Drawing.Font("Arial Black", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmd08.Location = new System.Drawing.Point(218, 336);
      this.cmd08.Name = "cmd08";
      this.cmd08.Size = new System.Drawing.Size(90, 90);
      this.cmd08.TabIndex = 0;
      this.cmd08.Click += new System.EventHandler(this.cmd08_Click);
      // 
      // cmd07
      // 
      this.cmd07.BackColor = System.Drawing.Color.LimeGreen;
      this.cmd07.Font = new System.Drawing.Font("Arial Black", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmd07.Location = new System.Drawing.Point(86, 336);
      this.cmd07.Name = "cmd07";
      this.cmd07.Size = new System.Drawing.Size(90, 90);
      this.cmd07.TabIndex = 0;
      this.cmd07.Click += new System.EventHandler(this.cmd07_Click);
      // 
      // cmd06
      // 
      this.cmd06.BackColor = System.Drawing.Color.LimeGreen;
      this.cmd06.Font = new System.Drawing.Font("Arial Black", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmd06.Location = new System.Drawing.Point(350, 208);
      this.cmd06.Name = "cmd06";
      this.cmd06.Size = new System.Drawing.Size(90, 90);
      this.cmd06.TabIndex = 0;
      this.cmd06.Click += new System.EventHandler(this.cmd06_Click);
      // 
      // cmd05
      // 
      this.cmd05.BackColor = System.Drawing.Color.LimeGreen;
      this.cmd05.Font = new System.Drawing.Font("Arial Black", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmd05.Location = new System.Drawing.Point(218, 208);
      this.cmd05.Name = "cmd05";
      this.cmd05.Size = new System.Drawing.Size(90, 90);
      this.cmd05.TabIndex = 0;
      this.cmd05.Click += new System.EventHandler(this.cmd05_Click);
      // 
      // cmd04
      // 
      this.cmd04.BackColor = System.Drawing.Color.LimeGreen;
      this.cmd04.Font = new System.Drawing.Font("Arial Black", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmd04.Location = new System.Drawing.Point(86, 208);
      this.cmd04.Name = "cmd04";
      this.cmd04.Size = new System.Drawing.Size(90, 90);
      this.cmd04.TabIndex = 0;
      this.cmd04.Click += new System.EventHandler(this.cmd04_Click);
      // 
      // cmd03
      // 
      this.cmd03.BackColor = System.Drawing.Color.LimeGreen;
      this.cmd03.Font = new System.Drawing.Font("Arial Black", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmd03.Location = new System.Drawing.Point(350, 72);
      this.cmd03.Name = "cmd03";
      this.cmd03.Size = new System.Drawing.Size(90, 90);
      this.cmd03.TabIndex = 0;
      this.cmd03.Click += new System.EventHandler(this.cmd03_Click);
      // 
      // cmd02
      // 
      this.cmd02.BackColor = System.Drawing.Color.LimeGreen;
      this.cmd02.Font = new System.Drawing.Font("Arial Black", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmd02.Location = new System.Drawing.Point(218, 72);
      this.cmd02.Name = "cmd02";
      this.cmd02.Size = new System.Drawing.Size(90, 90);
      this.cmd02.TabIndex = 0;
      this.cmd02.Click += new System.EventHandler(this.cmd02_Click);
      // 
      // cmd01
      // 
      this.cmd01.BackColor = System.Drawing.Color.LimeGreen;
      this.cmd01.Font = new System.Drawing.Font("Arial Black", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmd01.Location = new System.Drawing.Point(86, 72);
      this.cmd01.Name = "cmd01";
      this.cmd01.Size = new System.Drawing.Size(90, 90);
      this.cmd01.TabIndex = 0;
      this.cmd01.Click += new System.EventHandler(this.cmd01_Click);
      // 
      // panHorizontal02
      // 
      this.panHorizontal02.BackColor = System.Drawing.Color.Blue;
      this.panHorizontal02.Location = new System.Drawing.Point(56, 304);
      this.panHorizontal02.Name = "panHorizontal02";
      this.panHorizontal02.Size = new System.Drawing.Size(400, 18);
      this.panHorizontal02.TabIndex = 2;
      // 
      // panHorizontal01
      // 
      this.panHorizontal01.BackColor = System.Drawing.Color.Blue;
      this.panHorizontal01.Location = new System.Drawing.Point(50, 176);
      this.panHorizontal01.Name = "panHorizontal01";
      this.panHorizontal01.Size = new System.Drawing.Size(400, 18);
      this.panHorizontal01.TabIndex = 2;
      // 
      // panVertical01
      // 
      this.panVertical01.BackColor = System.Drawing.Color.Blue;
      this.panVertical01.Location = new System.Drawing.Point(188, 56);
      this.panVertical01.Name = "panVertical01";
      this.panVertical01.Size = new System.Drawing.Size(18, 400);
      this.panVertical01.TabIndex = 2;
      // 
      // lblTitle
      // 
      this.lblTitle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblTitle.Font = new System.Drawing.Font("Times New Roman", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblTitle.ForeColor = System.Drawing.Color.Red;
      this.lblTitle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
      this.lblTitle.Location = new System.Drawing.Point(8, 0);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(492, 48);
      this.lblTitle.TabIndex = 1;
      this.lblTitle.Text = "Tic-Tac-Toe";
      this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // panVertical02
      // 
      this.panVertical02.BackColor = System.Drawing.Color.Blue;
      this.panVertical02.Location = new System.Drawing.Point(320, 56);
      this.panVertical02.Name = "panVertical02";
      this.panVertical02.Size = new System.Drawing.Size(18, 400);
      this.panVertical02.TabIndex = 2;
      // 
      // frmTicTacToe
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(509, 525);
      this.Controls.Add(this.cmdRestart);
      this.Controls.Add(this.cmdQuit);
      this.Controls.Add(this.lblPlayer);
      this.Controls.Add(this.cmd09);
      this.Controls.Add(this.cmd08);
      this.Controls.Add(this.cmd07);
      this.Controls.Add(this.cmd06);
      this.Controls.Add(this.cmd05);
      this.Controls.Add(this.cmd04);
      this.Controls.Add(this.cmd03);
      this.Controls.Add(this.cmd02);
      this.Controls.Add(this.cmd01);
      this.Controls.Add(this.panHorizontal02);
      this.Controls.Add(this.panHorizontal01);
      this.Controls.Add(this.panVertical01);
      this.Controls.Add(this.lblTitle);
      this.Controls.Add(this.panVertical02);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTicTacToe";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Tic-Tac-Toe";
      this.Load += new System.EventHandler(this.frmTicTacToe_Load);
      this.ResumeLayout(false);

    }
		// InitializeComponent()

		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmTicTacToe'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240201 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240201 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmTicTacToe()
			//***
			// Action
			//   - Create instance of 'frmTicTacToe'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240201 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240201 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmTicTacToe()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

    char mchrToken;
    int mlngPlayer;

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"
    
    private void cmd01_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the text of the button to a character (mchrToken)
      //   - Disable the button
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - CheckWinner()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cmd01.Text = mchrToken.ToString();
      cmd01.Enabled = false;
      CheckWinner();
    }
    // cmd01_Click(System.Object, System.EventArgs) Handles cmd01.Click

    private void cmd02_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the text of the button to a character (mchrToken)
      //   - Disable the button
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - CheckWinner()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cmd02.Text = mchrToken.ToString();
      cmd02.Enabled = false;
      CheckWinner();
    }
    // cmd02_Click(System.Object, System.EventArgs) Handles cmd01.Click

    private void cmd03_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the text of the button to a character (mchrToken)
      //   - Disable the button
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - CheckWinner()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cmd03.Text = mchrToken.ToString();
      cmd03.Enabled = false;
      CheckWinner();
    }
    // cmd03_Click(System.Object, System.EventArgs) Handles cmd01.Click

    private void cmd04_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the text of the button to a character (mchrToken)
      //   - Disable the button
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - CheckWinner()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cmd04.Text = mchrToken.ToString();
      cmd04.Enabled = false;
      CheckWinner();
    }
    // cmd04_Click(System.Object, System.EventArgs) Handles cmd01.Click

    private void cmd05_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the text of the button to a character (mchrToken)
      //   - Disable the button
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - CheckWinner()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cmd05.Text = mchrToken.ToString();
      cmd05.Enabled = false;
      CheckWinner();
    }
    // cmd05_Click(System.Object, System.EventArgs) Handles cmd01.Click

    private void cmd06_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the text of the button to a character (mchrToken)
      //   - Disable the button
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - CheckWinner()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cmd06.Text = mchrToken.ToString();
      cmd06.Enabled = false;
      CheckWinner();
    }
    // cmd06_Click(System.Object, System.EventArgs) Handles cmd01.Click

    private void cmd07_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the text of the button to a character (mchrToken)
      //   - Disable the button
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - CheckWinner()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cmd07.Text = mchrToken.ToString();
      cmd07.Enabled = false;
      CheckWinner();
    }
    // cmd07_Click(System.Object, System.EventArgs) Handles cmd01.Click

    private void cmd08_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the text of the button to a character (mchrToken)
      //   - Disable the button
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - CheckWinner()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cmd08.Text = mchrToken.ToString();
      cmd08.Enabled = false;
      CheckWinner();
    }
    // cmd08_Click(System.Object, System.EventArgs) Handles cmd01.Click

    private void cmd09_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the text of the button to a character (mchrToken)
      //   - Disable the button
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - CheckWinner()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cmd09.Text = mchrToken.ToString();
      cmd09.Enabled = false;
      CheckWinner();
    }
    // cmd09_Click(System.Object, System.EventArgs) Handles cmd01.Click

    private void cmdQuit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - End the program
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Exit();
    }
    // cmdQuit_Click(System.Object, System.EventArgs) Handles cmdQuit.Click

    private void cmdRestart_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Restart the game
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - RestartGame()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      RestartGame();    
    }
    // cmdRestart_Click(System.Object, System.EventArgs) Handles cmdRestart_Click
 
    
    private void frmTicTacToe_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Start the game
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - RestartGame()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      RestartGame();
    }
    // frmTicTacToe_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

    private void CheckWinner()
      //***
      // Action
      //   - Check each row, column and diagonal if the 3 texts are filled
      //   - Check each row, column and diagonal if the 3 texts are equal
      //   - If so
      //     - Put all with a yellow background
      //     - Display the info of the winner
      //   - If not
      //     - Game is not ended yet, and a next player is assigned
      // Called by
      //   - cmd01_Click(System.Object, System.EventArgs) Handles cmd01.Click
      //   - cmd02_Click(System.Object, System.EventArgs) Handles cmd02.Click
      //   - cmd03_Click(System.Object, System.EventArgs) Handles cmd03.Click
      //   - cmd04_Click(System.Object, System.EventArgs) Handles cmd04.Click
      //   - cmd05_Click(System.Object, System.EventArgs) Handles cmd05.Click
      //   - cmd06_Click(System.Object, System.EventArgs) Handles cmd06.Click
      //   - cmd07_Click(System.Object, System.EventArgs) Handles cmd07.Click
      //   - cmd08_Click(System.Object, System.EventArgs) Handles cmd08.Click
      //   - cmd09_Click(System.Object, System.EventArgs) Handles cmd09.Click
      // Calls
      //   - DisplayWinner()
      //   - NextPlayer()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (((cmd01.Text + cmd02.Text + cmd03.Text).Length == 3) &&
        (cmd01.Text == cmd02.Text) && (cmd02.Text == cmd03.Text))
      {
        cmd01.BackColor = Color.Yellow;
        cmd02.BackColor = Color.Yellow;
        cmd03.BackColor = Color.Yellow;
        DisplayWinner();
      }
      else if (((cmd04.Text + cmd05.Text + cmd06.Text).Length == 3) && 
        (cmd04.Text == cmd05.Text) && (cmd05.Text == cmd06.Text))
      {
        cmd04.BackColor = Color.Yellow;
        cmd05.BackColor = Color.Yellow;
        cmd06.BackColor = Color.Yellow;
        DisplayWinner();
      }
      else if (((cmd07.Text + cmd08.Text + cmd09.Text).Length == 3) &&
        (cmd07.Text == cmd08.Text) && (cmd08.Text == cmd09.Text))
      {
        cmd07.BackColor = Color.Yellow;
        cmd08.BackColor = Color.Yellow;
        cmd09.BackColor = Color.Yellow;
        DisplayWinner();
      }
      else if (((cmd01.Text + cmd04.Text + cmd07.Text).Length == 3) &&
        (cmd01.Text == cmd04.Text) && (cmd04.Text == cmd07.Text))
      {
        cmd01.BackColor = Color.Yellow;
        cmd04.BackColor = Color.Yellow;
        cmd07.BackColor = Color.Yellow;
        DisplayWinner();
      }
      else if (((cmd02.Text + cmd05.Text + cmd08.Text).Length == 3) &&
        (cmd02.Text == cmd05.Text) && (cmd05.Text == cmd08.Text))
      {
        cmd02.BackColor = Color.Yellow;
        cmd05.BackColor = Color.Yellow;
        cmd08.BackColor = Color.Yellow;
        DisplayWinner();
      }
      else if (((cmd03.Text + cmd06.Text + cmd09.Text).Length == 3) &&
        (cmd03.Text == cmd06.Text) && (cmd06.Text == cmd09.Text))
      {
        cmd03.BackColor = Color.Yellow;
        cmd06.BackColor = Color.Yellow;
        cmd09.BackColor = Color.Yellow;
        DisplayWinner();
      }
      else if (((cmd01.Text + cmd05.Text + cmd09.Text).Length == 3) &&
        (cmd01.Text == cmd05.Text) && (cmd05.Text == cmd09.Text))
      {
        cmd01.BackColor = Color.Yellow;
        cmd05.BackColor = Color.Yellow;
        cmd09.BackColor = Color.Yellow;
        DisplayWinner();
      }
      else if (((cmd03.Text + cmd05.Text + cmd07.Text).Length == 3) &&
        (cmd03.Text == cmd05.Text) && (cmd05.Text == cmd07.Text))
      {
        cmd03.BackColor = Color.Yellow;
        cmd05.BackColor = Color.Yellow;
        cmd07.BackColor = Color.Yellow;
        DisplayWinner();
      }
      else
      // Each row, each column and diagonals haven't equal text
      {
        NextPlayer();
      }
      // Check each row, each column and diagonals on equal text

    }
    // CheckWinner()

    private void DisplayWinner()
      //***
      // Action
      //   - When the first player has played
      //     - Second player gets an "X"
      //   - When the second player has played
      //     - First player gets an "O"
      //   - Set information on who plays on the screen
      // Called by
      //   - CheckWinner()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      lblPlayer.Text = "Player '" + mchrToken + "' is the winner!";
      cmd01.Enabled = false;
      cmd02.Enabled = false;
      cmd03.Enabled = false;
      cmd04.Enabled = false;
      cmd05.Enabled = false;
      cmd06.Enabled = false;
      cmd07.Enabled = false;
      cmd08.Enabled = false;
      cmd09.Enabled = false;
    }
    // DisplayWinner()

		public static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmTicTacToe
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmTicTacToe()
			// Created
			//   - CopyPaste � 20240201 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240201 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmTicTacToe());
		}
		// Main() 

    private void NextPlayer()
      //***
      // Action
      //   - When the first player has played
      //     - Second player gets an "X"
      //   - When the second player has played
      //     - First player gets an "O"
      //   - Set information on who plays on the screen
      // Called by
      //   - CheckWinner()
      //   - RestartGame()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      
      if (mlngPlayer == 1)
      {
        mchrToken = 'X';
        mlngPlayer = 2;
      }
      else
        // mlngPlayer <> 1
      {
        mchrToken = 'O';
        mlngPlayer = 1;
      }
      // mlngPlayer = 1

      lblPlayer.Text = "Player " + mlngPlayer + " : '" + mchrToken + "'";
    }
    // NextPlayer()

    private void RestartGame()
      //***
      // Action
      //   - Start or Restart the game by setting the defaults
      //   - All buttons enabled
      //   - All texts are cleared
      //   - All backcolors are set to default
      //   - Second player starts with an "O"
      //   - Run the next player routine
      // Called by
      //   - cmdRestart_Click(System.Object, System.EventArgs) Handles cmdRestart.Click
      //   - frmTicTacToe_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - NextPlayer()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cmd01.Enabled = true;
      cmd02.Enabled = true;
      cmd03.Enabled = true;
      cmd04.Enabled = true;
      cmd05.Enabled = true;
      cmd06.Enabled = true;
      cmd07.Enabled = true;
      cmd08.Enabled = true;
      cmd09.Enabled = true;
      cmd01.Text = "";
      cmd02.Text = "";
      cmd03.Text = "";
      cmd04.Text = "";
      cmd05.Text = "";
      cmd06.Text = "";
      cmd07.Text = "";
      cmd08.Text = "";
      cmd09.Text = "";
      cmd01.BackColor = Color.LimeGreen;
      cmd02.BackColor = Color.LimeGreen;
      cmd03.BackColor = Color.LimeGreen;
      cmd04.BackColor = Color.LimeGreen;
      cmd05.BackColor = Color.LimeGreen;
      cmd06.BackColor = Color.LimeGreen;
      cmd07.BackColor = Color.LimeGreen;
      cmd08.BackColor = Color.LimeGreen;
      cmd09.BackColor = Color.LimeGreen;
      
      mlngPlayer = 2;
      mchrToken = 'O';
      NextPlayer();
    }
    // RestartGame()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmTicTacToe

}
// CopyPaste.Learning