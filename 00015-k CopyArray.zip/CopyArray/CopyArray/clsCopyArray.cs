//***
// Action
//   - Making a copy of an array
// Created
//   - CopyPaste � 20220214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220214 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyArray
{

  class cpCopyArray
	{

    static void Main()
      //***
      // Action
      //   - Creating an array of 3 elements
      //   - Creating a copy of it
      //   - Show the compare between copy and the original
      //   - Change an element in the copy
      //   - Show the compare between copy and the original
      //   - Change an element in the original
      //   - Show the compare between copy and the original
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Array.Copy(Array, Array, int)
      //   - DialogResult MessageBox(string)
      //   - int Array.GetUpperBound(int)
      // Created
      //   - CopyPaste � 20220214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220214 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int[] arrInteger = new int[] {1, 2, 3};
      int[] arrCopy;

      arrCopy = new int[arrInteger.GetUpperBound(0)+ 1];

      Array.Copy(arrInteger, arrCopy, arrInteger.GetUpperBound(0) + 1);
      MessageBox.Show(arrInteger[0] + "-" + arrCopy[0]);
      arrCopy[0] = 20;
      MessageBox.Show(arrInteger[0] + "-" + arrCopy[0]);
      arrInteger[0] = 5;
      MessageBox.Show(arrInteger[0] + "-" + arrCopy[0]);
    }
    // Main()

  }
  // cpCopyArray

}
// CopyArray