//***
// Action
//   - Start of the application
//   - The command line arguments are checked, and are used in the startup routine
//   - ApplicationStartup is the implementation of the startup event
// Created
//   - CopyPaste � 20220815 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220815 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;
using System.Windows;

namespace LoadFromCommandLine
{

  public class cpStartup
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private static void ApplicationStartup(System.Object theSender, System.Windows.StartupEventArgs theStartupEventArguments)
    //***
    // Action
    //   - There can be one argument given in the application
    //   - It is considered as 1 filepath
    //   - At that point, the main window has been defined but not shown yet
    //   - The command-line argument is set through the Visual Studio Project Properties (the Debug tab)
    // Called by
    //   - Main()
    // Calls
    //   - wpfFileViewer.LoadFile(string)
    // Created
    //   - CopyPaste � 20220815 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220815 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (theStartupEventArguments.Args.Length > 0)
      {
        string strFile = theStartupEventArguments.Args[0];

        if (File.Exists(strFile))
        {
          wpfFileViewer theStartupScreen = (wpfFileViewer)Application.Current.MainWindow;
          theStartupScreen.LoadFile(strFile);
        }
        // File.Exists(strFile)

      }
      // theStartupEventArguments.Args.Length > 0

    }
    // ApplicationStartup(System.Object, System.Windows.StartupEventArgs)

    [STAThreadAttribute()]
    public static void Main()
    //***
    // Action
    //   - Create an instance of Application
    //   - Set a method to the Startup event of the Application (Method ApplicationStartup)
    //   - Run the application with the Startup screen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - ApplicationStartup(System.Object, System.Windows.StartupEventArgs)
    //   - wpfFileViewer()
    // Created
    //   - CopyPaste � 20220815 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220815 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application theApplication = new Application(); // Create an instance of the application

      theApplication.Startup += ApplicationStartup; // Assign a method for the Startup event
      theApplication.Run(new wpfFileViewer()); // Launch the application
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpStartup

}
// LoadFromCommandLine