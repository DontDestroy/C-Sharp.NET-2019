﻿//***
// Action
//   - Toolkit for console visualisations
// Created
//   - CopyPaste – 20230710 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230710 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace CopyPaste.Toolkit
{

  public class cpConsole
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static bool blnDebug = true;
    private static bool blnVerbose = true;
    private static int intCount;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Print(System.Object anObject)
    //***
    // Action
    //   - Print something on the console window, with the default foreground color and a backcolor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - PrintInternal(System.Object, ConsoleColor? = null, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      PrintInternal(anObject);
    }
    // Print(System.Object)

    public static void Print(System.Object anObject, ConsoleColor? theFrontColor = null, ConsoleColor? theBackColor = null)
    //***
    // Action
    //   - Print something on the console window, with a foreground color and a backcolor (default null)
    // Called by
    //   - cpProgram.Main()
    //   - PrintDebugOrVerbose(System.Object, ConsoleColor, ConsoleColor? = null)
    //   - PrintError(System.Object)
    //   - PrintMainHeadLine(System.Object)
    //   - PrintSuccess(System.Object)
    //   - PrintWarning(System.Object)
    //   - PrintWithCounter(System.Object, ConsoleColor, ConsoleColor? = null)
    //   - PrintWithTime(System.Object, ConsoleColor = ConsoleColor.White)
    // Calls
    //   - PrintInternal(System.Object, ConsoleColor? = null, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (blnDebug || blnVerbose)
      {
        PrintInternal(anObject, theFrontColor, theBackColor);
      }
      else
      // Not blnDebug && Not blnVerbose
      {
      }
      // blnDebug || blnVerbose

    }
    // Print(System.Object, ConsoleColor? = null, ConsoleColor? = null)

    public static void PrintDebug(System.Object anObject)
    //***
    // Action
    //   - Print something on the console window, with the default foreground color
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - PrintDebug(System.Object, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      PrintDebug(anObject, Console.ForegroundColor);
    }
    // PrintDebug(System.Object)

    public static void PrintDebug(System.Object anObject, ConsoleColor theFrontColor, ConsoleColor? theBackColor = null)
    //***
    // Action
    //   - If blnDebug or blnVerbose
    //     - Print something on the debug, trace and console window, with a foreground color and a backcolor (default null)
    // Called by
    //   - cpProgram.Main()
    //   - PrintDebug(System.Object)
    //   - PrintDebugError(System.Object)
    //   - PrintDebugSuccess(System.Object)
    //   - PrintDebugWarning(System.Object)
    // Calls
    //   - PrintDebugOrVerbose(System.Object, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (blnDebug || blnVerbose)
      {
        PrintDebugOrVerbose(anObject, theFrontColor, theBackColor);
      }
      else
      // Not blnDebug && Not blnVerbose
      {
      }
      // blnDebug || blnVerbose

    }
    // PrintDebug(System.Object, ConsoleColor, ConsoleColor? = null)

    public static void PrintDebugError(System.Object anObject)
    //***
    // Action
    //   - Print something on the console window, with a foreground color white and background color red
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - PrintDebug(System.Object anObject, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      PrintDebug(anObject, ConsoleColor.White, ConsoleColor.Red);
    }
    // PrintDebugError(System.Object)

    public static void PrintDebugOrVerbose(System.Object anObject, ConsoleColor theFrontColor, ConsoleColor? theBackColor = null)
    //***
    // Action
    //   - Add one to a counter and print the value of the counter
    //   - Print something on the console window, with a foreground color and a backcolor (default null)
    //   - Print something in the debug window
    //   - Print something in the trace window
    // Called by
    //   - cpProgram.Main()
    //   - PrintDebug(System.Object)
    //   - PrintVerbose(System.Object anObject, ConsoleColor, ConsoleColor? = null)
    // Calls
    //   - Print(System.Object, ConsoleColor? = null, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      intCount += 1;
      anObject = $"{intCount:0000}: {anObject}";
      Print(anObject, theFrontColor, theBackColor);
      Debug.WriteLine(anObject);
      Trace.WriteLine(anObject);
      Trace.Flush();
    }
    // PrintDebugOrVerbose(System.Object, ConsoleColor, ConsoleColor? = null)

    public static void PrintDebugSuccess(System.Object anObject)
    //***
    // Action
    //   - Print something on the console window, with a foreground color green
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - PrintDebug(System.Object anObject, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      PrintDebug(anObject, ConsoleColor.Green);
    }
    // PrintDebugSuccess(System.Object)

    public static void PrintDebugWarning(System.Object anObject)
    //***
    // Action
    //   - Print something on the console window, with a foreground color cyan
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - PrintDebug(System.Object anObject, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      PrintDebug(anObject, ConsoleColor.Cyan);
    }
    // PrintDebugWarning(System.Object)

    public static void PrintError(System.Object anObject)
    //***
    // Action
    //   - Print something on the console window, with a foreground color white and background color red
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - Print(System.Object anObject, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Print(anObject, ConsoleColor.White, ConsoleColor.Red);
    }
    // PrintError(System.Object)

    [DebuggerStepThroughAttribute]
    public static void PrintInternal(System.Object anObject, ConsoleColor? theFrontColor = null, ConsoleColor? theBackColor = null)
    //***
    // Action
    //   - If anObject is nothing
    //     - Do nothing
    //   - If Not
    //     - Remember the front and backcolor of the console
    //     - Change the frontcolor when a frontcolor is given
    //     - Change the backcolor when a backcolor is given
    //     - Show a message on the console window
    //     - Reset the front and backcolor to the original values
    // Called by
    //   - cpProgram.Main()
    //   - Print(System.Object)
    //   - Print(System.Object, ConsoleColor? = null, ConsoleColor? = null)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Must be optimized for websites
    //***
    {

      if (anObject == null)
      {
      }
      else
      // anObject <> null
      {
        object objLock = 1;

        lock (objLock) // In multitreading environments it should work, all below is considered as one statement, so executed togehter
        {
          ConsoleColor oldConsoleFrontColor = Console.ForegroundColor;
          ConsoleColor oldConsoleBackColor = Console.BackgroundColor;

          if (theFrontColor == null)
          { 
          }
          else
          // theFrontColor <> null
          {
            Console.ForegroundColor = theFrontColor.Value;
          }
          // theFrontColor = null

          if (theBackColor == null)
          {
          }
          else
          // theBackColor  <> null
          {
            Console.BackgroundColor = theBackColor.Value;
          }
          // theBackColor = null

          Console.WriteLine(anObject);
          Console.ForegroundColor = oldConsoleFrontColor;
          Console.BackgroundColor = oldConsoleBackColor;
        }
        // objLock

      }
      // anObject = null

    }
    // PrintInternal(System.Object, ConsoleColor? = null, ConsoleColor? = null)

    public static void PrintMainHeadLine(System.Object anObject)
    //***
    // Action
    //   - Print an empty line
    //   - Print something on the console window, with a foreground color black and background color yellow
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - Print(System.Object anObject, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine();
      Print(anObject, ConsoleColor.Black, ConsoleColor.Yellow);
    }
    // PrintMainHeadLine(System.Object)

    public static void PrintSuccess(System.Object anObject)
    //***
    // Action
    //   - Print something on the console window, with a foreground color green
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - Print(System.Object anObject, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Print(anObject, ConsoleColor.Green);
    }
    // PrintSuccess(System.Object)

    public static void PrintVerbose(System.Object anObject)
    //***
    // Action
    //   - Print something on the console window, with the default foreground color
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - PrintVerbose(System.Object, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      PrintVerbose(anObject, Console.ForegroundColor);
    }
    // PrintVerbose(System.Object)

    public static void PrintVerbose(System.Object anObject, ConsoleColor theFrontColor, ConsoleColor? theBackColor = null)
    //***
    // Action
    //   - If blnVerbose
    //     - Print something on the console window, with a foreground color
    // Called by
    //   - cpProgram.Main()
    //   - PrintVerbose(System.Object)
    //   - PrintVerboseError(System.Object)
    //   - PrintVerboseSuccess(System.Object)
    //   - PrintVerboseWarning(System.Object)
    // Calls
    //   - PrintDebugOrVerbose(System.Object, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (blnVerbose)
      {
        PrintDebugOrVerbose(anObject, theFrontColor, theBackColor);
      }
        // Not blnVerbose
      else
      {
      }
      // blnVerbose

    }
    // PrintVerbose(System.Object anObject, ConsoleColor, ConsoleColor? = null)

    public static void PrintVerboseError(System.Object anObject)
    //***
    // Action
    //   - Print something on the console window, with a foreground color white and background color red
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - PrintVerbose(System.Object anObject, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      PrintVerbose(anObject, ConsoleColor.White, ConsoleColor.Red);
    }
    // PrintVerboseError(System.Object)

    public static void PrintVerboseSuccess(System.Object anObject)
    //***
    // Action
    //   - Print something on the console window, with a foreground color green
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - PrintVerbose(System.Object anObject, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      PrintVerbose(anObject, ConsoleColor.Green);
    }
    // PrintVerboseSuccess(System.Object)

    public static void PrintVerboseWarning(System.Object anObject)
    //***
    // Action
    //   - Print something on the console window, with a foreground color cyan
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - PrintVerbose(System.Object anObject, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      PrintVerbose(anObject, ConsoleColor.Cyan);
    }
    // PrintVerboseWarning(System.Object)

    public static void PrintWarning(System.Object anObject)
    //***
    // Action
    //   - Print something on the console window, with a foreground color cyan
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - Print(System.Object anObject, ConsoleColor, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Print(anObject, ConsoleColor.Cyan);
    }
    // PrintWarning(System.Object)

    public static void PrintWithCounter(System.Object anObject, ConsoleColor theFrontColor, ConsoleColor? theBackColor = null)
    //***
    // Action
    //   - Add one to a counter and print the value of the counter
    //   - Print something on the console window, with a foreground color and a backcolor (default null)
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - Print(System.Object, ConsoleColor? = null, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      intCount += 1;
      anObject = $"{intCount:0000}: {anObject}";
      Print(anObject, theFrontColor, theBackColor);
    }
    // PrintWithCounter(System.Object, ConsoleColor, ConsoleColor? = null)

    public static void PrintWithTime(System.Object anObject, ConsoleColor theFrontColor = ConsoleColor.White)
    //***
    // Action
    //   - Add the current time to anObject
    //   - Print something on the console window, with a foreground color white and a backcolor (default)
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - Print(System.Object, ConsoleColor? = null, ConsoleColor? = null)
    // Created
    //   - CopyPaste – 20230710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      DateTime theCurrentTime = DateTime.Now;

      anObject = $"{theCurrentTime.Year:0000}/{theCurrentTime.Month:00}/{theCurrentTime.Day:00} {theCurrentTime.Hour:00}:{theCurrentTime.Minute:00}:{theCurrentTime.Second:00}.{theCurrentTime.Millisecond:000}: {anObject}";
      Print(anObject, theFrontColor);
    }
    // PrintWithTime(System.Object, ConsoleColor = ConsoleColor.White)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpConsole

}
// CopyPaste.Toolkit