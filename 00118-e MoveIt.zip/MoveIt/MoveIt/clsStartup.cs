//***
// Action
//   - Testroutine for a pawn
// Created
//   - CopyPaste � 20240313 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240313 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Games
{

  public class cpStartup
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Initialize a game piece (pawn) that can be moved
      //   - Set X coordinate to 10
      //   - Set Y coordinate to 10
      //   - Show the position of the piece
      //   - Say that the peice will be moved 5 places upwards
      //   - Move the piece 5 places up
      //   - Show the position of the piece
      //   - Cast the moveable game piece to a pawn
      //   - Set captured to false
      //   - Show the information of being captured
      //   - Set captured to true
      //   - Show the information of being captured
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - bool cpPawn.Captured (Get)
      //   - cpPawn.Captured(bool) (Set)
      //   - cpPawn.X(int) (Set)
      //   - cpPawn.Y(int) (Set)
      //   - int cpPawn.X (Get)
      //   - int cpPawn.Y (Get)
      // Created
      //   - CopyPaste � 20240313 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240313 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpiMoveable thecpMover = new cpPawn();
      
      thecpMover.X = 10;
      thecpMover.Y = 10;
      Console.WriteLine("X:{0} Y:{1}", thecpMover.X, thecpMover.Y);
      Console.WriteLine("Moving up 5 spaces");
      thecpMover.Move(cpDirection.Up, 5);
      Console.WriteLine("X:{0} Y:{1}", thecpMover.X, thecpMover.Y);
      
      cpPawn thecpPawn = (cpPawn)thecpMover;
      
      thecpPawn.Captured = false;
      Console.WriteLine("Is the pawn captured? {0}", thecpPawn.Captured);
      thecpPawn.Captured = true;
      Console.WriteLine("Is the pawn captured? {0}", thecpPawn.Captured);
      Console.WriteLine();
      Console.WriteLine("Hit enter to end program.");
      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.Games

