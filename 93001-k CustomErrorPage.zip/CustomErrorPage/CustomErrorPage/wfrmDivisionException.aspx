<%@ Page Language="C#" ErrorPage="https://localhost:44310/ErrorPage.html" %>

<!-- VVDW - This does not seems to work -->

<html>
<head>
  <script language="C#" runat="server">

    protected void Page_Error(System.Object theSender, EventArgs theEventArguments)
    {
      Response.Redirect("https://localhost:44310/ErrorPage.html");
      // VVDW - This seems to work
      // VVDW - Alternative way can be found in Web.config and in Global.asax
    }

  </script>
  <title>Divide by Zero</title>
</head>
<body>
  <center>
    <h1>Divide by Zero triggers Error Page</h1>
  </center>
  <hr>

  <% 

    int intNumber = 10;
    int intDivider = 0;
    int intRemainder;

    intRemainder = intNumber % intDivider;
    Response.Write("Remainder: " + intRemainder + "<br>");

  %>
</body>
</html>
