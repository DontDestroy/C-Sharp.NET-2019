﻿//***
// Action
//   - Monitor the used threads
// Created
//   - CopyPaste – 20250710 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250710 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Threading;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static Object mtheMonitorLock = new Object();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create four threads with the same routine
      //   - Name all the threads
      //   - Start all the threads
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - USeResource()
      // Created
      //   - CopyPaste – 20250710 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250710 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Thread thrA = new Thread(new ThreadStart(UseResource));
      Thread thrB = new Thread(new ThreadStart(UseResource));
      Thread thrC = new Thread(new ThreadStart(UseResource));
      Thread thrD = new Thread(new ThreadStart(UseResource));

      thrA.Name = "First";
      thrB.Name = "Second";
      thrC.Name = "Third";
      thrD.Name = "Fourth";

      thrA.Start();
      thrB.Start();
      thrC.Start();
      thrD.Start();

      Console.ReadLine();
    }
		// Main()

    public static void UseResource()
      //***
      // Action
      //   - Let the routine wait between 1 and 3 seconds
      //   - Enter the monitor (locks the object, thread will stop when object is in use)
      //   - Write some information about the thread (the name)
      //   - Exit the monitor (frees the object, other threads can use the object)
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250710 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250710 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Random rndNumber = new Random();

      Thread.Sleep(Convert.ToInt32(rndNumber.Next(1000, 3000)));
      Monitor.Enter(mtheMonitorLock);
      Console.WriteLine("Thread: " + Thread.CurrentThread.Name);
      Monitor.Exit(mtheMonitorLock);
    }
    // UseResource()

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning