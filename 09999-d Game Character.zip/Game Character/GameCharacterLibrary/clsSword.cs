﻿//***
// Action
//   - Implementation of a cpWeapon
//		 - The way a sword can be used
// Created
//   - CopyPaste – 20240806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240806 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Weapon.Library
{

	public class cpSword : cpiWeapon
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpSword
		/// </summary>
		public cpSword()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - CopyPaste.Game.Character.Library.cpKing()
		//   - CopyPaste.Game.Character.Library.cpKnight()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpSword()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a sword is used to fight
		/// </summary>
		public void UseWeapon()
		//***
		// Action
		//   - Define how a sword is used to fight
		// Called by
		//   - cpKing() (indirectly, thru delegate)
		//   - cpKnight() (indirectly, thru delegate)
		//   - cpQueen() (indirectly, thru delegate)
		//   - cpTroll() (indirectly, thru delegate)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Swinging a sword");
		}
		// UseWeapon()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpSword

}
// CopyPaste.Game.Weapon.Library