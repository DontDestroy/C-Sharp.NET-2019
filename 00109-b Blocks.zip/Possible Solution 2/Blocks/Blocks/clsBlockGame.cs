//***
// Action
//   - A block game
//   - Working with properties (Get and Set) and methods in a class, that can be used in another game
//   - Possible Solution 2
// Created
//   - CopyPaste � 20240214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240214 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning.Games
{

  public class cpBlockGame
  {

    #region "Constructors / Destructors"

    public cpBlockGame()
      //***
      // Action
      //   - Creating an instance of cpBlockGame with default values
      // Called by
      //   - 
      // Calls
      //   - Lives(int) (Set)
      //   - NumberOfBlocks(int) (Set)
      //   - Score(int) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Lives = 3;
      Score = 0;
      NumberOfBlocks = 1;
    }
    // cpBlockGame()

    public cpBlockGame(int lngLives, int lngScore, int lngNumberOfBlocks)
      //***
      // Action
      //   - Creating an instance of cpBlockGame with values that can be setup
      // Called by
      //   - frmBlock
      // Calls
      //   - Lives(int) (Set)
      //   - NumberOfBlocks(int) (Set)
      //   - Score(int) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Lives = lngLives;
      Score = lngScore;
      NumberOfBlocks = lngNumberOfBlocks;
    }
    // cpBlock(int, int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private bool mblnLostBall;
    private int mlngNumberOfBlocks;
    private int mlngLives;
    private int mlngScore;

    #endregion

    #region "Properties"

    public bool GameFinished
    {
      
      get
        //***
        // Action Get
        //   - Check if the game is finished (True or False)
        //   - If NumberOfBlocks equals zero
        //     - Return True
        //   - If Not
        //     - If LostBall
        //       - If Lives lower than 1 (equals zero)
        //         - Return True
        //       - If Not
        //         - Return False
        //     - If Not
        //       - Do Nothing
        // Called by
        //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - bool LostBall (Get)
        //   - int Lives (Get)
        //   - int NumberOfBlocks (Get)
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        bool blnResult = false;

        if (NumberOfBlocks == 0)
        {
          blnResult = true;
        }
        else
          // NumberOfBlocks <> 0
        {
          
          if (LostBall)
          {
            
            if (Lives < 1)
            {
              // MessageBox.Show("You have lost the game.", "OH NO!");
              blnResult = true;
            }
            else
              // Lives >= 1
            {
              // MessageBox.Show("You missed!", "OH NO");
              blnResult = false;
            }
            // Lives < 1

          }
          else
            // Not LostBall
          {
          }
          // LostBall
       
        }
        // NumberOfBlocks = 0

        return blnResult;
      }
      // bool GameFinished (Get)

    }
    // bool GameFinished 

    public int Lives
    {

      get
        //***
        // Action Get
        //   - Return the number of lives you still have in the game (mlngLives)
        // Called by
        //   - bool GameFinished (Get)
        //   - frmBlock.frmBlock_Load(System.Object, System.EventArgs) Handles this.Load
        //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        //   - frmBlock.UpdateLives()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngLives;
      }
      // int Lives (Get)

      set
        //***
        // Action Set
        //   - Set the number of lives you still have in the game (mlngLives becomes value)
        // Called by
        //   - cpBlockGame()
        //   - cpBlockGame(int, int, int)
        //   - frmBlock.UpdateLives()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngLives = value;
      }
      // Lives(int) (Set)

    }
    // int Lives

    public bool LostBall
    {

      get
        //***
        // Action Get
        //   - Check if you have lost the ball (mblnLostBall)
        // Called by
        //   - bool GameFinished (Get)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mblnLostBall;
      }
      // bool LostBall (Get)

      set
        //***
        // Action Set
        //   - Set the boolean if you have lost the ball or not (mblnLostBall becomes value)
        // Called by 
        //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mblnLostBall = value;
      }
      // LostBall(bool) (Set)

    }
    // bool LostBall

    public int NumberOfBlocks
    {

      get
        //***
        // Action Get
        //   - Return the number of blocks left in the game (mlngNumberOfBlocks)
        // Called by
        //   - frmBlock.CheckCollision() 
        //   - bool GameFinished (Get)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngNumberOfBlocks;
      }
      // int NumberOfBlocks (Get)

      set
        //***
        // Action Set
        //   - Set the number of blocks left in the game (mlngNumberOfBlocks becomes value)
        // Called by
        //   - cpBlockGame()
        //   - cpBlockGame(int, int, int)
        //   - frmBlock.CheckCollision()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngNumberOfBlocks = value;
      }
      // NumberOfBlocks(int) (Set)

    }
    // int NumberOfBlocks

    public int Score
    {

      get
        //***
        // Action Get
        //   - Return the score of the game (mlngScore)
        // Called by
        //   - frmBlock.frmBlock_Load(System.Object, System.EventArgs) Handles this.Load
        //   - frmBlock.UpdateScore()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngScore;
      }
      // int Score (Get)

      set
        //***
        // Action Set
        //   - Set the score of the game (mlngScore becomes value)
        // Called by
        //   - cpBlockGame()
        //   - cpBlockGame(int, int, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngScore = value;
      }
      // Score(int) (Set)

    }
    // int Score

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpBlockGame

}
// CopyPaste.Learning.Games