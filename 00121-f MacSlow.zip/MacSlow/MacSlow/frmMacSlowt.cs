//***
// Action
//   - Order screen of a fast food restaurant
// Created
//   - CopyPaste � 20240701 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240701 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMacSlow: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtPrice;
    internal System.Windows.Forms.TextBox txtCreditCard;
    internal System.Windows.Forms.TextBox txtTable;
    internal System.Windows.Forms.Label lblPrice;
    internal System.Windows.Forms.Label lblCreditCard;
    internal System.Windows.Forms.Label lblTable;
    internal System.Windows.Forms.GroupBox grpSauce;
    internal System.Windows.Forms.CheckBox chkSauceSweet;
    internal System.Windows.Forms.CheckBox chkSauceTatare;
    internal System.Windows.Forms.CheckBox chkSauceCurry;
    internal System.Windows.Forms.CheckBox chkSauceMayo;
    internal System.Windows.Forms.CheckBox chkSauceKetchup;
    internal System.Windows.Forms.GroupBox grpDrinks;
    internal System.Windows.Forms.RadioButton optDrinksSprite;
    internal System.Windows.Forms.RadioButton optDrinksFanta;
    internal System.Windows.Forms.RadioButton optDrinksCoke;
    internal System.Windows.Forms.ErrorProvider erpTable;
    internal System.Windows.Forms.GroupBox grpDrinksSize;
    internal System.Windows.Forms.RadioButton optDrinksSize50;
    internal System.Windows.Forms.RadioButton optDrinksSize40;
    internal System.Windows.Forms.RadioButton optDrinksSize30;
    internal System.Windows.Forms.Button cmdClear;
    internal System.Windows.Forms.GroupBox grpFrenchFrice;
    internal System.Windows.Forms.RadioButton optFrenchFriceLarge;
    internal System.Windows.Forms.RadioButton optFrenchFriceMedium;
    internal System.Windows.Forms.RadioButton optFrenchFriceSmall;
    internal System.Windows.Forms.Button cmdAccept;
    internal System.Windows.Forms.GroupBox grpMenu;
    internal System.Windows.Forms.RadioButton optMenuCheeseHam;
    internal System.Windows.Forms.RadioButton optMenuChickenNuggets;
    internal System.Windows.Forms.RadioButton optMenuVegetarianBurger;
    internal System.Windows.Forms.RadioButton optMenuFishBurger;
    internal System.Windows.Forms.RadioButton optMenuKingBurger;
    internal System.Windows.Forms.RadioButton optMenuDoubleCheese;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMacSlow));
      this.txtPrice = new System.Windows.Forms.TextBox();
      this.txtCreditCard = new System.Windows.Forms.TextBox();
      this.txtTable = new System.Windows.Forms.TextBox();
      this.lblPrice = new System.Windows.Forms.Label();
      this.lblCreditCard = new System.Windows.Forms.Label();
      this.lblTable = new System.Windows.Forms.Label();
      this.grpSauce = new System.Windows.Forms.GroupBox();
      this.chkSauceSweet = new System.Windows.Forms.CheckBox();
      this.chkSauceTatare = new System.Windows.Forms.CheckBox();
      this.chkSauceCurry = new System.Windows.Forms.CheckBox();
      this.chkSauceMayo = new System.Windows.Forms.CheckBox();
      this.chkSauceKetchup = new System.Windows.Forms.CheckBox();
      this.grpDrinks = new System.Windows.Forms.GroupBox();
      this.optDrinksSprite = new System.Windows.Forms.RadioButton();
      this.optDrinksFanta = new System.Windows.Forms.RadioButton();
      this.optDrinksCoke = new System.Windows.Forms.RadioButton();
      this.erpTable = new System.Windows.Forms.ErrorProvider();
      this.grpDrinksSize = new System.Windows.Forms.GroupBox();
      this.optDrinksSize50 = new System.Windows.Forms.RadioButton();
      this.optDrinksSize40 = new System.Windows.Forms.RadioButton();
      this.optDrinksSize30 = new System.Windows.Forms.RadioButton();
      this.cmdClear = new System.Windows.Forms.Button();
      this.grpFrenchFrice = new System.Windows.Forms.GroupBox();
      this.optFrenchFriceLarge = new System.Windows.Forms.RadioButton();
      this.optFrenchFriceMedium = new System.Windows.Forms.RadioButton();
      this.optFrenchFriceSmall = new System.Windows.Forms.RadioButton();
      this.cmdAccept = new System.Windows.Forms.Button();
      this.grpMenu = new System.Windows.Forms.GroupBox();
      this.optMenuCheeseHam = new System.Windows.Forms.RadioButton();
      this.optMenuChickenNuggets = new System.Windows.Forms.RadioButton();
      this.optMenuVegetarianBurger = new System.Windows.Forms.RadioButton();
      this.optMenuFishBurger = new System.Windows.Forms.RadioButton();
      this.optMenuKingBurger = new System.Windows.Forms.RadioButton();
      this.optMenuDoubleCheese = new System.Windows.Forms.RadioButton();
      this.grpSauce.SuspendLayout();
      this.grpDrinks.SuspendLayout();
      this.grpDrinksSize.SuspendLayout();
      this.grpFrenchFrice.SuspendLayout();
      this.grpMenu.SuspendLayout();
      this.SuspendLayout();
      // 
      // txtPrice
      // 
      this.txtPrice.Enabled = false;
      this.txtPrice.Location = new System.Drawing.Point(241, 344);
      this.txtPrice.Name = "txtPrice";
      this.txtPrice.Size = new System.Drawing.Size(56, 20);
      this.txtPrice.TabIndex = 25;
      this.txtPrice.TabStop = false;
      this.txtPrice.Text = "";
      // 
      // txtCreditCard
      // 
      this.txtCreditCard.Location = new System.Drawing.Point(225, 312);
      this.txtCreditCard.Name = "txtCreditCard";
      this.txtCreditCard.Size = new System.Drawing.Size(160, 20);
      this.txtCreditCard.TabIndex = 21;
      this.txtCreditCard.Text = "";
      // 
      // txtTable
      // 
      this.txtTable.Location = new System.Drawing.Point(65, 312);
      this.txtTable.Name = "txtTable";
      this.txtTable.Size = new System.Drawing.Size(40, 20);
      this.txtTable.TabIndex = 19;
      this.txtTable.Text = "";
      this.txtTable.Validating += new System.ComponentModel.CancelEventHandler(this.txtTable_Validating);
      // 
      // lblPrice
      // 
      this.lblPrice.Location = new System.Drawing.Point(201, 344);
      this.lblPrice.Name = "lblPrice";
      this.lblPrice.Size = new System.Drawing.Size(40, 23);
      this.lblPrice.TabIndex = 24;
      this.lblPrice.Text = "Price";
      // 
      // lblCreditCard
      // 
      this.lblCreditCard.Location = new System.Drawing.Point(161, 312);
      this.lblCreditCard.Name = "lblCreditCard";
      this.lblCreditCard.Size = new System.Drawing.Size(64, 23);
      this.lblCreditCard.TabIndex = 20;
      this.lblCreditCard.Text = "&CreditCard";
      // 
      // lblTable
      // 
      this.lblTable.Location = new System.Drawing.Point(17, 312);
      this.lblTable.Name = "lblTable";
      this.lblTable.Size = new System.Drawing.Size(48, 23);
      this.lblTable.TabIndex = 18;
      this.lblTable.Text = "Ta&ble";
      // 
      // grpSauce
      // 
      this.grpSauce.Controls.Add(this.chkSauceSweet);
      this.grpSauce.Controls.Add(this.chkSauceTatare);
      this.grpSauce.Controls.Add(this.chkSauceCurry);
      this.grpSauce.Controls.Add(this.chkSauceMayo);
      this.grpSauce.Controls.Add(this.chkSauceKetchup);
      this.grpSauce.Location = new System.Drawing.Point(9, 248);
      this.grpSauce.Name = "grpSauce";
      this.grpSauce.Size = new System.Drawing.Size(376, 48);
      this.grpSauce.TabIndex = 17;
      this.grpSauce.TabStop = false;
      this.grpSauce.Text = "Sa&uce";
      // 
      // chkSauceSweet
      // 
      this.chkSauceSweet.Location = new System.Drawing.Point(216, 16);
      this.chkSauceSweet.Name = "chkSauceSweet";
      this.chkSauceSweet.Size = new System.Drawing.Size(64, 24);
      this.chkSauceSweet.TabIndex = 3;
      this.chkSauceSweet.Text = "S&weet";
      // 
      // chkSauceTatare
      // 
      this.chkSauceTatare.Location = new System.Drawing.Point(280, 16);
      this.chkSauceTatare.Name = "chkSauceTatare";
      this.chkSauceTatare.Size = new System.Drawing.Size(72, 24);
      this.chkSauceTatare.TabIndex = 4;
      this.chkSauceTatare.Text = "&Tatare";
      // 
      // chkSauceCurry
      // 
      this.chkSauceCurry.Location = new System.Drawing.Point(152, 16);
      this.chkSauceCurry.Name = "chkSauceCurry";
      this.chkSauceCurry.Size = new System.Drawing.Size(72, 24);
      this.chkSauceCurry.TabIndex = 2;
      this.chkSauceCurry.Text = "C&urry";
      // 
      // chkSauceMayo
      // 
      this.chkSauceMayo.Location = new System.Drawing.Point(88, 16);
      this.chkSauceMayo.Name = "chkSauceMayo";
      this.chkSauceMayo.Size = new System.Drawing.Size(72, 24);
      this.chkSauceMayo.TabIndex = 1;
      this.chkSauceMayo.Text = "Ma&yo";
      // 
      // chkSauceKetchup
      // 
      this.chkSauceKetchup.Location = new System.Drawing.Point(16, 16);
      this.chkSauceKetchup.Name = "chkSauceKetchup";
      this.chkSauceKetchup.Size = new System.Drawing.Size(72, 24);
      this.chkSauceKetchup.TabIndex = 0;
      this.chkSauceKetchup.Text = "Ketc&hup";
      // 
      // grpDrinks
      // 
      this.grpDrinks.Controls.Add(this.optDrinksSprite);
      this.grpDrinks.Controls.Add(this.optDrinksFanta);
      this.grpDrinks.Controls.Add(this.optDrinksCoke);
      this.grpDrinks.Location = new System.Drawing.Point(153, 128);
      this.grpDrinks.Name = "grpDrinks";
      this.grpDrinks.Size = new System.Drawing.Size(104, 112);
      this.grpDrinks.TabIndex = 15;
      this.grpDrinks.TabStop = false;
      this.grpDrinks.Text = "Dr&inks";
      // 
      // optDrinksSprite
      // 
      this.optDrinksSprite.Location = new System.Drawing.Point(16, 72);
      this.optDrinksSprite.Name = "optDrinksSprite";
      this.optDrinksSprite.Size = new System.Drawing.Size(72, 24);
      this.optDrinksSprite.TabIndex = 2;
      this.optDrinksSprite.Text = "S&prite";
      // 
      // optDrinksFanta
      // 
      this.optDrinksFanta.Location = new System.Drawing.Point(16, 48);
      this.optDrinksFanta.Name = "optDrinksFanta";
      this.optDrinksFanta.Size = new System.Drawing.Size(72, 24);
      this.optDrinksFanta.TabIndex = 1;
      this.optDrinksFanta.Text = "F&anta";
      // 
      // optDrinksCoke
      // 
      this.optDrinksCoke.Checked = true;
      this.optDrinksCoke.Location = new System.Drawing.Point(16, 24);
      this.optDrinksCoke.Name = "optDrinksCoke";
      this.optDrinksCoke.Size = new System.Drawing.Size(72, 24);
      this.optDrinksCoke.TabIndex = 0;
      this.optDrinksCoke.TabStop = true;
      this.optDrinksCoke.Text = "C&oke";
      // 
      // erpTable
      // 
      this.erpTable.ContainerControl = this;
      // 
      // grpDrinksSize
      // 
      this.grpDrinksSize.Controls.Add(this.optDrinksSize50);
      this.grpDrinksSize.Controls.Add(this.optDrinksSize40);
      this.grpDrinksSize.Controls.Add(this.optDrinksSize30);
      this.grpDrinksSize.Location = new System.Drawing.Point(265, 128);
      this.grpDrinksSize.Name = "grpDrinksSize";
      this.grpDrinksSize.Size = new System.Drawing.Size(120, 112);
      this.grpDrinksSize.TabIndex = 16;
      this.grpDrinksSize.TabStop = false;
      this.grpDrinksSize.Text = "Drinksi&ze";
      // 
      // optDrinksSize50
      // 
      this.optDrinksSize50.Location = new System.Drawing.Point(16, 72);
      this.optDrinksSize50.Name = "optDrinksSize50";
      this.optDrinksSize50.Size = new System.Drawing.Size(96, 24);
      this.optDrinksSize50.TabIndex = 2;
      this.optDrinksSize50.Text = "&50 cl (� 2,00)";
      // 
      // optDrinksSize40
      // 
      this.optDrinksSize40.Checked = true;
      this.optDrinksSize40.Location = new System.Drawing.Point(16, 48);
      this.optDrinksSize40.Name = "optDrinksSize40";
      this.optDrinksSize40.Size = new System.Drawing.Size(96, 24);
      this.optDrinksSize40.TabIndex = 1;
      this.optDrinksSize40.TabStop = true;
      this.optDrinksSize40.Text = "&40 cl (� 1,70)";
      // 
      // optDrinksSize30
      // 
      this.optDrinksSize30.Location = new System.Drawing.Point(16, 24);
      this.optDrinksSize30.Name = "optDrinksSize30";
      this.optDrinksSize30.Size = new System.Drawing.Size(96, 24);
      this.optDrinksSize30.TabIndex = 0;
      this.optDrinksSize30.Text = "&30 cl (� 1,30)";
      // 
      // cmdClear
      // 
      this.cmdClear.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.cmdClear.Location = new System.Drawing.Point(17, 344);
      this.cmdClear.Name = "cmdClear";
      this.cmdClear.TabIndex = 22;
      this.cmdClear.Text = "Clear";
      this.cmdClear.Click += new System.EventHandler(this.cmdClear_Click);
      // 
      // grpFrenchFrice
      // 
      this.grpFrenchFrice.Controls.Add(this.optFrenchFriceLarge);
      this.grpFrenchFrice.Controls.Add(this.optFrenchFriceMedium);
      this.grpFrenchFrice.Controls.Add(this.optFrenchFriceSmall);
      this.grpFrenchFrice.Location = new System.Drawing.Point(9, 128);
      this.grpFrenchFrice.Name = "grpFrenchFrice";
      this.grpFrenchFrice.Size = new System.Drawing.Size(136, 112);
      this.grpFrenchFrice.TabIndex = 14;
      this.grpFrenchFrice.TabStop = false;
      this.grpFrenchFrice.Text = "F&rench Frice";
      // 
      // optFrenchFriceLarge
      // 
      this.optFrenchFriceLarge.Location = new System.Drawing.Point(16, 72);
      this.optFrenchFriceLarge.Name = "optFrenchFriceLarge";
      this.optFrenchFriceLarge.Size = new System.Drawing.Size(112, 24);
      this.optFrenchFriceLarge.TabIndex = 2;
      this.optFrenchFriceLarge.Text = "&Large (� 2,20)";
      // 
      // optFrenchFriceMedium
      // 
      this.optFrenchFriceMedium.Checked = true;
      this.optFrenchFriceMedium.Location = new System.Drawing.Point(16, 48);
      this.optFrenchFriceMedium.Name = "optFrenchFriceMedium";
      this.optFrenchFriceMedium.Size = new System.Drawing.Size(112, 24);
      this.optFrenchFriceMedium.TabIndex = 1;
      this.optFrenchFriceMedium.TabStop = true;
      this.optFrenchFriceMedium.Text = "M&edium (� 1,80)";
      // 
      // optFrenchFriceSmall
      // 
      this.optFrenchFriceSmall.Location = new System.Drawing.Point(16, 24);
      this.optFrenchFriceSmall.Name = "optFrenchFriceSmall";
      this.optFrenchFriceSmall.Size = new System.Drawing.Size(112, 24);
      this.optFrenchFriceSmall.TabIndex = 0;
      this.optFrenchFriceSmall.Text = "&Small (� 1,40)";
      // 
      // cmdAccept
      // 
      this.cmdAccept.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.cmdAccept.Location = new System.Drawing.Point(105, 344);
      this.cmdAccept.Name = "cmdAccept";
      this.cmdAccept.TabIndex = 23;
      this.cmdAccept.Text = "Accept";
      this.cmdAccept.Click += new System.EventHandler(this.cmdAccept_Click);
      // 
      // grpMenu
      // 
      this.grpMenu.Controls.Add(this.optMenuCheeseHam);
      this.grpMenu.Controls.Add(this.optMenuChickenNuggets);
      this.grpMenu.Controls.Add(this.optMenuVegetarianBurger);
      this.grpMenu.Controls.Add(this.optMenuFishBurger);
      this.grpMenu.Controls.Add(this.optMenuKingBurger);
      this.grpMenu.Controls.Add(this.optMenuDoubleCheese);
      this.grpMenu.Location = new System.Drawing.Point(9, 8);
      this.grpMenu.Name = "grpMenu";
      this.grpMenu.Size = new System.Drawing.Size(376, 112);
      this.grpMenu.TabIndex = 13;
      this.grpMenu.TabStop = false;
      this.grpMenu.Text = "&Menu (� 3,00)";
      // 
      // optMenuCheeseHam
      // 
      this.optMenuCheeseHam.Location = new System.Drawing.Point(192, 72);
      this.optMenuCheeseHam.Name = "optMenuCheeseHam";
      this.optMenuCheeseHam.Size = new System.Drawing.Size(136, 24);
      this.optMenuCheeseHam.TabIndex = 5;
      this.optMenuCheeseHam.Text = "Cheese and Ha&m";
      // 
      // optMenuChickenNuggets
      // 
      this.optMenuChickenNuggets.Location = new System.Drawing.Point(192, 48);
      this.optMenuChickenNuggets.Name = "optMenuChickenNuggets";
      this.optMenuChickenNuggets.Size = new System.Drawing.Size(136, 24);
      this.optMenuChickenNuggets.TabIndex = 4;
      this.optMenuChickenNuggets.Text = "Chicken &Nuggets";
      // 
      // optMenuVegetarianBurger
      // 
      this.optMenuVegetarianBurger.Location = new System.Drawing.Point(192, 24);
      this.optMenuVegetarianBurger.Name = "optMenuVegetarianBurger";
      this.optMenuVegetarianBurger.Size = new System.Drawing.Size(144, 24);
      this.optMenuVegetarianBurger.TabIndex = 3;
      this.optMenuVegetarianBurger.Text = "&Vegetarian Burger";
      // 
      // optMenuFishBurger
      // 
      this.optMenuFishBurger.Location = new System.Drawing.Point(32, 72);
      this.optMenuFishBurger.Name = "optMenuFishBurger";
      this.optMenuFishBurger.TabIndex = 2;
      this.optMenuFishBurger.Text = "&Fish Burger";
      // 
      // optMenuKingBurger
      // 
      this.optMenuKingBurger.Location = new System.Drawing.Point(32, 48);
      this.optMenuKingBurger.Name = "optMenuKingBurger";
      this.optMenuKingBurger.TabIndex = 1;
      this.optMenuKingBurger.Text = "&King Burger";
      // 
      // optMenuDoubleCheese
      // 
      this.optMenuDoubleCheese.Checked = true;
      this.optMenuDoubleCheese.Location = new System.Drawing.Point(32, 24);
      this.optMenuDoubleCheese.Name = "optMenuDoubleCheese";
      this.optMenuDoubleCheese.Size = new System.Drawing.Size(120, 24);
      this.optMenuDoubleCheese.TabIndex = 0;
      this.optMenuDoubleCheese.TabStop = true;
      this.optMenuDoubleCheese.Text = "&Double Cheese";
      // 
      // frmMacSlow
      // 
      this.AcceptButton = this.cmdAccept;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.CancelButton = this.cmdClear;
      this.ClientSize = new System.Drawing.Size(394, 375);
      this.Controls.Add(this.txtCreditCard);
      this.Controls.Add(this.txtTable);
      this.Controls.Add(this.lblPrice);
      this.Controls.Add(this.lblCreditCard);
      this.Controls.Add(this.lblTable);
      this.Controls.Add(this.grpSauce);
      this.Controls.Add(this.grpDrinks);
      this.Controls.Add(this.grpDrinksSize);
      this.Controls.Add(this.cmdClear);
      this.Controls.Add(this.grpFrenchFrice);
      this.Controls.Add(this.cmdAccept);
      this.Controls.Add(this.grpMenu);
      this.Controls.Add(this.txtPrice);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.Name = "frmMacSlow";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Mac Slow : Self Serve Screen";
      this.grpSauce.ResumeLayout(false);
      this.grpDrinks.ResumeLayout(false);
      this.grpDrinksSize.ResumeLayout(false);
      this.grpFrenchFrice.ResumeLayout(false);
      this.grpMenu.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMacSlow'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240701 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMacSlow()
      //***
      // Action
      //   - Create instance of 'frmMacSlow'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240701 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMacSlow()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdAccept_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Accept the order
      //   - By default a 3 euro price (for the burger)
      //   - Add a price for the selected size of French Frice (none is not an option)
      //   - Add a price for the selected size of drink (none is not an option)
      //   - Add a price for every selected sauce (none is an option)
      //   - Generate a nice overview of what was ordered
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240701 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - Add the possibility to choose no French Frice, no drink 
      //***
    {
      float fltPrice = 3.0F;
      int lngNumberOfSauce = 0;
      string strSauce = "";
      string strText = "You have ordered a ";

      // Add the price of the selected French Frice
      if (optFrenchFriceSmall.Checked)
      {
        fltPrice += 1.4F;
      }
      else if (optFrenchFriceMedium.Checked)
        // Not optFrenchFriceSmall.Checked
      {
        fltPrice += 1.8F;
      }
      else if (optFrenchFriceLarge.Checked)
        // Not optFrenchFriceMedium.Checked
      {
        fltPrice += 2.2F;
      }
      else
        // Not optFrenchFriceLarge.Checked
      {
      }
      // optFrenchFriceSmall.Checked
      // optFrenchFriceMedium.Checked
      // optFrenchFriceLarge.Checked

      // Add the price of the selected drink
      if (optDrinksSize30.Checked)
      {
        fltPrice += 1.3F;
      }
      else if (optDrinksSize40.Checked)
        // Not optDrinksSize30.Checked
      {
        fltPrice += 1.7F;
      }
      else if (optDrinksSize50.Checked)
        // Not optDrinksSize40.Checked
      {
        fltPrice += 2.0F;
      }
      else
        // Not optDrinksSize50.Checked
      {
      }
      // optDrinksSize30.Checked
      // optDrinksSize40.Checked
      // optDrinksSize50.Checked

      // Count the selected sauces
      foreach (CheckBox theSauce in grpSauce.Controls)
      {

        if (theSauce.Checked)
        {
          lngNumberOfSauce += 1;
        }
        else
          // Not theSauce.Checked
        {
        }
        // theSauce.Checked

      }
      // in grpSauce.Controls

      // Add the calculated price of the selected sauces
      fltPrice += lngNumberOfSauce * 0.5F;
      // Show the calcuated price
      txtPrice.Text = "� " + fltPrice.ToString();

      // Loop thru all the controls of the menu group (find the selected menu)

      foreach (RadioButton theMenu in grpMenu.Controls)
      {
        
        if (theMenu.Checked)
        {
          // Generate a text with the selected menu
          strText += theMenu.Text.Replace("&", "") + " menu with ";
          break;
        }
        else
          // Not theMenu.Checked
        {
        }
        // theMenu.Checked 

      }
      // in grpMenu.Controls

      // Generate a text with the selected French frice

      if (optFrenchFriceSmall.Checked)
      {
        strText += "a small ";
      }
      else if (optFrenchFriceMedium.Checked)
        // Not optFrenchFriceSmall.Checked
      {
        strText += "a medium ";
      }
      else if (optFrenchFriceLarge.Checked)
        // Not optFrenchFriceMedium.Checked
      {
        strText += "a large ";
      }
      else
        // Not optFrenchFriceLarge.Checked
      {
      }
      // optFrenchFriceSmall.Checked
      // optFrenchFriceMedium.Checked
      // optFrenchFriceLarge.Checked

      strText += "french frice" + Environment.NewLine + "and ";

      // Generate a text with the selected size of drink
      if (optDrinksSize30.Checked)
      {
        strText += "a small ";
      }
      else if (optDrinksSize40.Checked)
        // Not optDrinksSize30.Checked
      {
        strText += "a medium ";
      }
      else if (optDrinksSize50.Checked)
        // Not optDrinksSize40.Checked
      {
        strText += "a large ";
      }
      else
        // Not optDrinksSize50.Checked
      {
      }
      // optDrinksSize30.Checked
      // optDrinksSize40.Checked
      // optDrinksSize50.Checked

      // Loop thru all the controls of the drink group (find the selected drink)
      foreach (RadioButton theMenu in grpDrinks.Controls)
      {
        
        if (theMenu.Checked)
        {
          // Generate a text with the selected drink
          strText += theMenu.Text.Replace("&", "") + Environment.NewLine;
          break;
        }
        else
          // Not theMenu.Checked 
        {
        }
        // theMenu.Checked 

      }
      // in grpDrinks.Controls

      // Generate a text with the selected sauces (zero, one or more is possible)
      if (lngNumberOfSauce == 0)
      {
        strText += "There was no order of a sauce.";
      }
      else
        // lngNumberOfSauce <> 0
      {
        
        if (lngNumberOfSauce == 1)
        {
          strText += "You have ordered this sauce : ";
        }
        else
          // lngNumberOfSauce <> 1
        {
          strText += "You have ordered this sauces : ";
        }
        // lngNumberOfSauce = 1

        // Loop thru all the controls of the sauce group (find the selected sauces)
        
        foreach (CheckBox theSauce in grpSauce.Controls)
        {
          
          if (theSauce.Checked)
          {
            // Generate a text with the selected sauce
            strText += theSauce.Text.Replace("&", "") + ", ";
          }
          else
            // Not theSauce.Checked 
          {
          }
          // theSauce.Checked 
        
        }
        // in grpSauce.Controls

        strText = strText.Substring(0, strText.Length - 2) + ".";
      }
      // lngNumberOfSauce = 0

      // Show the order
      MessageBox.Show(strText, "Order");    
    }
    // cmdAccept_Click(System.Object, System.EventArgs) Handles cmdAccept_Click

    private void cmdClear_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Return to the original state of the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240701 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - 
      //***
    {
      txtCreditCard.Text = "";
      txtPrice.Text = "";
      txtTable.Text = "";
      optMenuDoubleCheese.Checked = true;
      optFrenchFriceMedium.Checked = true;
      optDrinksCoke.Checked = true;
      optDrinksSize40.Checked = true;

      foreach (CheckBox theCheckBox in grpSauce.Controls)
      {
        theCheckBox.Checked = false;
      }
      // in grpSauce.Controls
    
    }
    // cmdClear_Click(System.Object, System.EventArgs) Handles cmdClear.Click

    private void txtTable_Validating(System.Object theSender, System.ComponentModel.CancelEventArgs theCancelEventArguments)
      //***
      // Action
      //   - Check if the table number is correct
      //     - Error is removed when nothing is filled in or correct number is entered
      //     - Check if table number is a number
      //       - Show corresponding error when not
      //     - Check if the table number is between 1 and 39 (borders included)
      //       - Show corresponding error when not
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240701 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - Add the possibility to choose no French Frice, no drink, 
      //***
    {
      TextBox theTextBox = (TextBox)theSender;

      try
      {

        if (theTextBox.Text == "")
        {
          erpTable.SetError((Control)theSender, "");
        }
        else
          // theTextBox.Text <> ""
        {
          int lngTableNumber = Convert.ToInt32(theTextBox.Text);

          if ((lngTableNumber > 39) || (lngTableNumber < 1))
          {
            erpTable.SetError((Control)theSender, "Type a number between 1 and 39");
            theCancelEventArguments.Cancel = true;
          }
          else
            // lngTableNumber <= 39 AndAlso lngTableNumber >= 1
          {
            erpTable.SetError((Control)theSender, "");
          }
          // lngTableNumber > 39 OrElse lngTableNumber < 1

        }
        // theTextBox.Text = ""

      }
      catch (Exception theException)
      {
        erpTable.SetError((Control)theSender, "You have to type a number");
        theCancelEventArguments.Cancel = true;
      }
    
    }
    // txtTable_Validating(System.Object, System.ComponentModel.CancelEventArgs) Handles txtTable.Validating

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMacSlow
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmMacSlow()
      // Created
      //   - CopyPaste � 20240701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240701 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMacSlow());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMacSlow

}
// CopyPaste.Learning