//***
// Action
//   - Testroutine for option button
// Created
//   - CopyPaste � 20240215 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240215 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmRadioButton: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.RadioButton optMacOS;
    internal System.Windows.Forms.RadioButton optLinux;
    internal System.Windows.Forms.RadioButton optWindows2000;
    internal System.Windows.Forms.Label lblResult;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmRadioButton));
      this.optMacOS = new System.Windows.Forms.RadioButton();
      this.optLinux = new System.Windows.Forms.RadioButton();
      this.optWindows2000 = new System.Windows.Forms.RadioButton();
      this.lblResult = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // optMacOS
      // 
      this.optMacOS.Location = new System.Drawing.Point(32, 111);
      this.optMacOS.Name = "optMacOS";
      this.optMacOS.TabIndex = 6;
      this.optMacOS.Text = "Mac OS";
      this.optMacOS.CheckedChanged += new System.EventHandler(this.optMacOS_CheckedChanged);
      // 
      // optLinux
      // 
      this.optLinux.Location = new System.Drawing.Point(32, 71);
      this.optLinux.Name = "optLinux";
      this.optLinux.TabIndex = 5;
      this.optLinux.Text = "Linux";
      this.optLinux.CheckedChanged += new System.EventHandler(this.optLinux_CheckedChanged);
      // 
      // optWindows2000
      // 
      this.optWindows2000.Location = new System.Drawing.Point(32, 31);
      this.optWindows2000.Name = "optWindows2000";
      this.optWindows2000.TabIndex = 4;
      this.optWindows2000.Text = "Windows 2000";
      this.optWindows2000.CheckedChanged += new System.EventHandler(this.optWindows2000_CheckedChanged);
      // 
      // lblResult
      // 
      this.lblResult.Location = new System.Drawing.Point(32, 159);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(232, 23);
      this.lblResult.TabIndex = 7;
      // 
      // frmRadioButton
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(296, 213);
      this.Controls.Add(this.optMacOS);
      this.Controls.Add(this.optLinux);
      this.Controls.Add(this.optWindows2000);
      this.Controls.Add(this.lblResult);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmRadioButton";
      this.Text = "Radio Button";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmRadioButton'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmRadioButton()
      //***
      // Action
      //   - Create instance of 'frmRadioButton'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmRadioButton()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void optLinux_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Setting a text according the choosen option
      // Called by
      //   - User action (Clicking an option button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblResult.Text = "Current choice: " + optLinux.Text;
      lblResult.Refresh();
    }
    // optLinux_CheckedChanged(System.Object, System.EventArgs) Handles optLinux.CheckedChanged

    private void optMacOS_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Setting a text according the choosen option
      // Called by
      //   - User action (Clicking an option button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblResult.Text = "Current choice: " + optMacOS.Text;
      lblResult.Refresh();
    }
    // optMacOS_CheckedChanged(System.Object, System.EventArgs) Handles optMacOS.CheckedChanged
    
    private void optWindows2000_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Setting a text according the choosen option
      // Called by
      //   - User action (Clicking an option button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblResult.Text = "Current choice: " + optWindows2000.Text;
      lblResult.Refresh();
    }
    // optWindows2000_CheckedChanged(System.Object, System.EventArgs) Handles optWindows2000.CheckedChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmRadioButton
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmRadioButton());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmRadioButton

}
// CopyPaste.Learning