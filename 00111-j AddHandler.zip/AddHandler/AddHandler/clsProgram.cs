//***
// Action
//   - Testroutines of cpStock
// Created
//   - CopyPaste � 20240524 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240524 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static cpStock mcpStock;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public static void EarningsAnnouncement(double dblAmount, DateTime dtmAnnounce)
      //***
      // Action
      //   - Show the earnings at a certain time
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Earnings Annoucement: " + dblAmount + " " + dtmAnnounce);
    }
    // EarningsAnnouncement(Double, DateTime)

    public static void PriceGoingDown(double dblPrice)
      //***
      // Action
      //   - Show that the price is going down
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Don't Panic Price down: " + dblPrice);
    }
    // PriceGoingDown(Double, DateTime)

    public static void PriceGoingUp(double dblPrice)
      //***
      // Action
      //   - Show that the price is going up
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Good News! Price up: " + dblPrice);
    }
    // PriceGoingUp(Double, DateTime)

    #endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define a cpStock
      //   - Add for the events a method to it
      //   - Execute the events using a method from inside the class cpStock
      //   - Execute the events using the delegates seperately
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpStock()
      //   - cpStock.Earnings(double, DateTime)
      //   - cpStock.GenerateEvents()
      //   - cpStock.PriceDown(double)
      //   - cpStock.PriceUp(double)
      //   - EarningsAnnouncement(double, DateTime)
      //   - PriceGoingDown(double)
      //   - PriceGoingUp(double)
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mcpStock = new cpStock();

      if (mcpStock == null)
      {
      }
      else
        // mcpStock <> null
      {
        mcpStock.PriceUp += new cpStock.cpPriceUp(PriceGoingUp);
        mcpStock.PriceDown += new cpStock.cpPriceDown(PriceGoingDown);
        mcpStock.Earnings += new cpStock.cpEarnings(EarningsAnnouncement);

        mcpStock.GenerateEvents();
        Console.WriteLine();
      }
      // mcpStock = null

      cpStock.cpPriceUp goingUp = PriceGoingUp;
      goingUp(100);
      // goingUp.Invoke(100);
      cpStock.cpPriceDown goingDown = PriceGoingDown;
      goingDown(50);
      // goingDown.Invoke(50);
      cpStock.cpEarnings earnings = EarningsAnnouncement;
      earnings(100, DateTime.Today.AddDays(-1));
      // earnings.Invoke(100, DateTime.Today.AddDays(-1));

      Console.WriteLine();
      Console.WriteLine("Hit enter to stop program");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning