//***
// Action
//   - Implementation of cpBook
// Created
//   - CopyPaste � 20240106 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240106 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

	public class cpBook
	{

		#region "Constructors / Destructors"

		public cpBook()
			//***
			// Action
			//   - Empty Constructor
			// Called by
			//   - frmReadBooks.cmdShowPage_Click(System.Object, System.EventArgs) Handles cmdShowPage.Click
			//   - frmReadBooks.frmReadBooks_Load(System.Object, System.EventArgs) Handles base.Load
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240106 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240106 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
	  {
		}
		// cpBook()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		public int mlngPageLength = 10;
		public string mstrText = "";
		private string mstrTitle;
		
		#endregion

		#region "Properties"

		public string Title
		{

			get
				//***
				// Action Get
				//   - Returns mstrTitle
				// Called by
				//   - cpLibrary.CheckIn(cpBook)
				//   - frmReadBooks.cmdShowPage_Click(System.Object, System.EventArgs) Handles cmdShowPage.Click
				//   - frmReadBooks.lstBooks_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBooks.SelectedIndexChanged
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240106 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240106 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
    	{
				return mstrTitle;
			}
			// string Title (Get)

			set
				//***
				// Action Set
				//   - mstrTitle becomes value
				// Called by
				//   - frmReadBooks.cmdShowPage_Click(System.Object, System.EventArgs) Handles cmdShowPage.Click
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240106 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240106 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
	    {
				mstrTitle = value;
			}
			// Title(string) (Set)

		}
		// string Title

		#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public string GetPage(int lngPageNumber)
			//***
			// Action
			//   - The text of the books is divided in pages
			//   - Every page has a certain length of characters
			//     - This is the value of mlngPageLength (Default 10)
			//   - Find the start position of the searched page (lngStart)
			//   - Using lngStart, the needed page is searched
			//   - If the page is found
			//     - The content of that page is returned
			//   - If Not
			//     - An empty string is returned
			// Called by
			//   - frmReadBooks.cmdShowPage_Click(System.Object, System.EventArgs) Handles cmdShowPage.Click
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240106 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240106 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
      int lngStart;
      int lngTextLength;
			string strPageContent;

      lngStart = (lngPageNumber - 1) * mlngPageLength;
      lngTextLength = mstrText.Length;

			if ((lngStart < lngTextLength) && (lngStart >= 0))
			{
				// lngStart is somewhere in the text

				if ((lngStart + mlngPageLength) < lngTextLength)
				{
					// There is a full page
					strPageContent = mstrText.Substring(lngStart, mlngPageLength);
				}
				else
					// (lngStart + mlngPageLength) >= lngTextLength
				{
					// There is no full page
					strPageContent = mstrText.Substring(lngStart, lngTextLength - lngStart);
				}
				// (lngStart + mlngPageLength) < lngTextLength

			}
			else
				// (lngStart <= lngTextLength) Or (lngStart < 0)
			{
				// There is no page found at that location
				strPageContent = "";
			}
			// (lngStart < lngTextLength) And (lngStart >= 0)

      return strPageContent;
		}
		// string GetPage(int)

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpBook

}
// CopyPaste.Learning