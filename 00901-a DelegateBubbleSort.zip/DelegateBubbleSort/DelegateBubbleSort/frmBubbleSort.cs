//***
// Action
//   - Generate a random list of numbers (10 elements)
//   - Define 2 ways of sorting that list of numbers using a delegate from with a class
// Created
//   - CopyPaste � 20250712 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250712 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Learning;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBubbleSort: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdSortDescending;
    internal System.Windows.Forms.TextBox txtSorted;
    internal System.Windows.Forms.TextBox txtOriginal;
    internal System.Windows.Forms.Label lblSorted;
    internal System.Windows.Forms.Label lblOriginal;
    internal System.Windows.Forms.Button cmdSortAscending;
    internal System.Windows.Forms.Button cmdCreate;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBubbleSort));
      this.cmdSortDescending = new System.Windows.Forms.Button();
      this.txtSorted = new System.Windows.Forms.TextBox();
      this.txtOriginal = new System.Windows.Forms.TextBox();
      this.lblSorted = new System.Windows.Forms.Label();
      this.lblOriginal = new System.Windows.Forms.Label();
      this.cmdSortAscending = new System.Windows.Forms.Button();
      this.cmdCreate = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdSortDescending
      // 
      this.cmdSortDescending.Enabled = false;
      this.cmdSortDescending.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmdSortDescending.Location = new System.Drawing.Point(152, 280);
      this.cmdSortDescending.Name = "cmdSortDescending";
      this.cmdSortDescending.Size = new System.Drawing.Size(96, 40);
      this.cmdSortDescending.TabIndex = 13;
      this.cmdSortDescending.Text = "Sort Descending";
      this.cmdSortDescending.Click += new System.EventHandler(this.cmdSortDescending_Click);
      // 
      // txtSorted
      // 
      this.txtSorted.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.txtSorted.Location = new System.Drawing.Point(152, 32);
      this.txtSorted.Multiline = true;
      this.txtSorted.Name = "txtSorted";
      this.txtSorted.Size = new System.Drawing.Size(96, 168);
      this.txtSorted.TabIndex = 10;
      this.txtSorted.Text = "";
      this.txtSorted.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
      // 
      // txtOriginal
      // 
      this.txtOriginal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.txtOriginal.Location = new System.Drawing.Point(16, 32);
      this.txtOriginal.Multiline = true;
      this.txtOriginal.Name = "txtOriginal";
      this.txtOriginal.Size = new System.Drawing.Size(96, 168);
      this.txtOriginal.TabIndex = 8;
      this.txtOriginal.Text = "";
      this.txtOriginal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
      // 
      // lblSorted
      // 
      this.lblSorted.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblSorted.Location = new System.Drawing.Point(152, 8);
      this.lblSorted.Name = "lblSorted";
      this.lblSorted.Size = new System.Drawing.Size(96, 24);
      this.lblSorted.TabIndex = 9;
      this.lblSorted.Text = "Sorted Values";
      this.lblSorted.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblOriginal
      // 
      this.lblOriginal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblOriginal.Location = new System.Drawing.Point(16, 8);
      this.lblOriginal.Name = "lblOriginal";
      this.lblOriginal.Size = new System.Drawing.Size(96, 24);
      this.lblOriginal.TabIndex = 7;
      this.lblOriginal.Text = "Original Values";
      this.lblOriginal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cmdSortAscending
      // 
      this.cmdSortAscending.Enabled = false;
      this.cmdSortAscending.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmdSortAscending.Location = new System.Drawing.Point(152, 216);
      this.cmdSortAscending.Name = "cmdSortAscending";
      this.cmdSortAscending.Size = new System.Drawing.Size(96, 40);
      this.cmdSortAscending.TabIndex = 12;
      this.cmdSortAscending.Text = "Sort Ascending";
      this.cmdSortAscending.Click += new System.EventHandler(this.cmdSortAscending_Click);
      // 
      // cmdCreate
      // 
      this.cmdCreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmdCreate.Location = new System.Drawing.Point(16, 216);
      this.cmdCreate.Name = "cmdCreate";
      this.cmdCreate.Size = new System.Drawing.Size(96, 32);
      this.cmdCreate.TabIndex = 11;
      this.cmdCreate.Text = "Create Data";
      this.cmdCreate.Click += new System.EventHandler(this.cmdCreate_Click);
      // 
      // frmBubbleSort
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(264, 333);
      this.Controls.Add(this.cmdSortDescending);
      this.Controls.Add(this.txtSorted);
      this.Controls.Add(this.txtOriginal);
      this.Controls.Add(this.lblSorted);
      this.Controls.Add(this.lblOriginal);
      this.Controls.Add(this.cmdSortAscending);
      this.Controls.Add(this.cmdCreate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBubbleSort";
      this.Text = "Bubble Sort";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBubbleSort'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBubbleSort()
      //***
      // Action
      //   - Create instance of 'frmBubbleSort'
      // Called by
      //   - Main()
      // Calls
      //   - cpDelegateBubbleSort.New()
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      mcpBubbleSort = new cpDelegateBubbleSort();
    }
    // frmBubbleSort()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    cpDelegateBubbleSort mcpBubbleSort;
    int[] marrElement = new int[10];

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCreate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Clear the current list
      //   - Loop thru the array
      //     - Generate number between 0 (included) and 100 (excluded)
      //     - Add the new element to the strOutput string
      //   - The original text becomes strOuput
      //   - Enable the sorting buttons
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngLoop;
      int lngLoopTill;
      Random rndNumber = new Random();
      string strOutput = "";

      txtSorted.Clear();
      lngLoopTill = marrElement.GetUpperBound(0);

      for (lngLoop = 0; lngLoop <= lngLoopTill; lngLoop++)
      {
        marrElement[lngLoop] = rndNumber.Next(100);
        strOutput += marrElement[lngLoop] + Environment.NewLine;
      }
      // lngLoop = lngLoopTill + 1
    
      txtOriginal.Text = strOutput;
      cmdSortAscending.Enabled = true;
      cmdSortDescending.Enabled = true;
    }
    // cmdCreate_Click(System.Object, System.EventArgs) Handles cmdCreate.Click
    
    private void cmdSortAscending_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a cpComparator with a given sort method (here SortAscending)
      //   - Sort the array using a given cpComparator
      //   - Display the result
      //   - Disable the sort ascending button
      //   - Enable the sort descending button
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool SortAscending(int, int)
      //   - cpDelegateBubbleSort.SortArray(int[], cpComparator)
      //   - DisplayResults()
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpDelegateBubbleSort.cpComparator theComparator = new cpDelegateBubbleSort.cpComparator(SortAscending);
      mcpBubbleSort.SortArray(marrElement, theComparator);
      DisplayResults();
      cmdSortAscending.Enabled = false;
      cmdSortDescending.Enabled = true;
    }
    // cmdSortAscending_Click(System.Object, System.EventArgs) Handles cmdSortAscending.Click

    private void cmdSortDescending_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a cpComparator with a given sort method (here SortDescending)
      //   - Sort the array using a given cpComparator
      //   - Display the result
      //   - Disable the sort descending button
      //   - Enable the sort ascending button
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool SortDescending(int, int)
      //   - cpDelegateBubbleSort.SortArray(int[], cpComparator)
      //   - DisplayResults()
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpDelegateBubbleSort.cpComparator theComparator = new cpDelegateBubbleSort.cpComparator(SortDescending);
      mcpBubbleSort.SortArray(marrElement, theComparator);
      DisplayResults();
      cmdSortAscending.Enabled = true;
      cmdSortDescending.Enabled = false;
    }
    // cmdSortDescending_Click(System.Object, System.EventArgs) Handles cmdSortDescending.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void DisplayResults()
      //***
      // Action
      //   - Loop thru the array
      //     - Add the current element to the strOutput string
      //   - The sorted text becomes strOuput
      //   - Set focus ont the sorted text
      // Called by
      //   - cmdSortAscending_Click(System.Object, System.EventArgs) Handles cmdSortAscending.Click
      //   - cmdSortDescending_Click(System.Object, System.EventArgs) Handles cmdSortDescending.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngLoop;
      int lngLoopTill;
      string strOutput = "";

      lngLoopTill = marrElement.GetUpperBound(0);

      for (lngLoop = 0; lngLoop <= lngLoopTill; lngLoop++)
      {
        strOutput += marrElement[lngLoop] + Environment.NewLine;
      }
      // lngLoop = lngLoopTill + 1

      txtSorted.Text = strOutput;
      txtSorted.Focus();
    }
    // DisplayResults()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmBubbleSort
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmBubbleSort()
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmBubbleSort());
    }
    // Main() 
    
    private bool SortAscending(int lngElement1, int lngElement2)
      //***
      // Action
      //   - If lngElement1 is larger than lngElement2
      //     - Return true
      //   - If not
      //     - Return false
      // Called by
      //   - cmdSortAscending_Click(System.Object, System.EventArgs) Handles cmdSortAscending.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return (lngElement1 > lngElement2);
    }
    // bool SortAscending(int, int)

    private bool SortDescending(int lngElement1, int lngElement2)
      //***
      // Action
      //   - If lngElement1 is smaller than lngElement2
      //     - Return true
      //   - If not
      //     - Return false
      // Called by
      //   - cmdSortDescending_Click(System.Object, System.EventArgs) Handles cmdSortAscending.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return (lngElement1 < lngElement2);
    }
    // bool SortDescending(int, int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBubbleSort

}
// CopyPaste.Learning