//***
// Action
//   - Test a cpTime
// Created
//   - CopyPaste � 20220411 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220411 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning.Toolkit
{

  class cpProgram
	{

    static void Main()
      //***
      // Action
      //   - Define a cpTime
      //   - Show a messagebox with that time.
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - string cpTime.BuildString()
      //   - cpTime.New(int, int, int)
      // Created
      //   - CopyPaste � 20220411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpTime thecpTime = new cpTime(12, 30, 19);

      MessageBox.Show(thecpTime.BuildString(), "Demonstrating the 'this' Reference");
		}
    // Main()

  }
  // cpProgram

}
// CopyPaste.Learning.Toolkit