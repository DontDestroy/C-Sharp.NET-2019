﻿//***
// Action
//   - A demo of benchmarking
//     - Used BenchMarkDotNet.Attributes
//       - BenchMarkDotNET and Microsoft.VisualStudio.DiagnosticksHub.BenchmarkDotNetDiagnosers are NuGet packages
//   - A demo of using StopWatch
// Created
//   - CopyPaste – 20260525 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260525 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - A demo of benchmarking (Time and Memory)
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpAllocationBenchMarks()
    //   - cpAllocationBenchMarks.AllocationInsideLoop()
    //   - cpAllocationBenchMarks.AllocationOutsideLoop()
    //   - cpSortingBenchMarks()
    //   - cpSortingBenchMarks.ArraySort()
    //   - cpSortingBenchMarks.Setup()
    //   - cpStringBenchMarks()
    //   - cpStringBenchMarks.StringBuilder()
    //   - cpStringBenchMarks.StringPlusOperator()
    //   - RunSomeCodeWithStopWatch()
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      // BenchmarkRunner.Run<cpSortingBenchMarks>();
      // BenchmarkRunner.Run<cpStringBenchMarks>();
      // BenchmarkRunner.Run<cpAllocationBenchMarks>();

      // RunSomeCodeWithStopWatch();

      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadKey();
    }
    // Main()

    public static void RunSomeCodeWithStopWatch()
    //***
    // Action
    //   - Run the actual code with a stopwatch
    //     - This will give you an impression, not exact numbers
    // Called by
    //   - Main()
    // Calls
    //   - cpAllocationBenchMarks()
    //   - cpAllocationBenchMarks.AllocationInsideLoop()
    //   - cpAllocationBenchMarks.AllocationOutsideLoop()
    //   - cpSortingBenchMarks()
    //   - cpSortingBenchMarks.ArraySort()
    //   - cpSortingBenchMarks.Setup()
    //   - cpStringBenchMarks()
    //   - cpStringBenchMarks.StringBuilder()
    //   - cpStringBenchMarks.StringPlusOperator()
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intFirstRun = 100_000;
      int intSecondRun = 1_000_000;
      int intThirdRun = 10_000_000;
      int intFourthRun = 100_000_000;

      string strFirstResult = string.Empty;
      string strSecondResult = string.Empty;

      Console.WriteLine("First sort run with {0:#,##0} elements", intFirstRun);

      Stopwatch stwSortFirstRun = Stopwatch.StartNew();

      cpSortingBenchMarks theSortingFirstBenchMarks = new cpSortingBenchMarks();
      theSortingFirstBenchMarks.size = intFirstRun;

      theSortingFirstBenchMarks.Setup();
      theSortingFirstBenchMarks.ArraySort();

      stwSortFirstRun.Stop();

      Console.WriteLine($"First sort run took {stwSortFirstRun.ElapsedMilliseconds} ms");
      Console.WriteLine();
      Console.WriteLine("Second sort run with {0:#,##0} elements", intSecondRun);

      Stopwatch stwSortSecondRun = Stopwatch.StartNew();

      cpSortingBenchMarks theSortingSecondBenchMarks = new cpSortingBenchMarks();
      theSortingSecondBenchMarks.size = intSecondRun;

      theSortingSecondBenchMarks.Setup();
      theSortingSecondBenchMarks.ArraySort();

      stwSortSecondRun.Stop();

      Console.WriteLine($"Second sort run took {stwSortSecondRun.ElapsedMilliseconds} ms");
      Console.WriteLine();
      Console.WriteLine("Third sort run with {0:#,##0} elements", intThirdRun);

      Stopwatch stwSortThirdRun = Stopwatch.StartNew();

      cpSortingBenchMarks theSortingThirdBenchMarks = new cpSortingBenchMarks();
      theSortingThirdBenchMarks.size = intThirdRun;

      theSortingThirdBenchMarks.Setup();
      theSortingThirdBenchMarks.ArraySort();

      stwSortThirdRun.Stop();

      Console.WriteLine($"Third sort run took {stwSortThirdRun.ElapsedMilliseconds} ms");
      Console.WriteLine();
      Console.WriteLine("Fourth sort run with {0:#,##0} elements", intFourthRun);

      Stopwatch stwSortFourthRun = Stopwatch.StartNew();

      cpSortingBenchMarks theSortingFourthBenchMarks = new cpSortingBenchMarks();
      theSortingFourthBenchMarks.size = intFourthRun;

      theSortingFourthBenchMarks.Setup();
      theSortingFourthBenchMarks.ArraySort();

      stwSortFourthRun.Stop();

      Console.WriteLine($"Fourth sort run took {stwSortFourthRun.ElapsedMilliseconds} ms");
      Console.WriteLine();
      Console.WriteLine("String Plus Operator run");

      Stopwatch stwStringPlusOperatorRun = Stopwatch.StartNew();

      cpStringBenchMarks theStringPlusOperatorBenchMarks = new cpStringBenchMarks();

      strFirstResult = theStringPlusOperatorBenchMarks.StringPlusOperator();
      stwStringPlusOperatorRun.Stop();

      Console.WriteLine($"String Plus Operator run took {stwStringPlusOperatorRun.ElapsedMilliseconds} ms");
      Console.WriteLine();
      Console.WriteLine("String Builder run");

      Stopwatch stwStringBuilderRun = Stopwatch.StartNew();

      cpStringBenchMarks theStringBuilderBenchMarks = new cpStringBenchMarks();

      strSecondResult = theStringBuilderBenchMarks.StringBuilder();
      stwStringBuilderRun.Stop();

      Console.WriteLine($"String Builder run took {stwStringBuilderRun.ElapsedMilliseconds} ms");
      Console.WriteLine();
      Console.WriteLine("Inside Allication run");

      Stopwatch stwInsideAllicationRun = Stopwatch.StartNew();

      cpAllocationBenchMarks theInsideAllocationBenchMarks = new cpAllocationBenchMarks();

      theInsideAllocationBenchMarks.AllocationInsideLoop();
      stwInsideAllicationRun.Stop();

      Console.WriteLine($"Inside Allocation run took {stwInsideAllicationRun.ElapsedMilliseconds} ms");
      Console.WriteLine();
      Console.WriteLine("Outside Allication run");

      Stopwatch stwOutsideAllicationRun = Stopwatch.StartNew();

      cpAllocationBenchMarks theOutsideAllocationBenchMarks = new cpAllocationBenchMarks();

      theOutsideAllocationBenchMarks.AllocationInsideLoop();
      stwOutsideAllicationRun.Stop();

      Console.WriteLine($"Outside Allocation run took {stwOutsideAllicationRun.ElapsedMilliseconds} ms");
      Console.WriteLine();
    }
    // RunSomeCodeWithStopWatch()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning