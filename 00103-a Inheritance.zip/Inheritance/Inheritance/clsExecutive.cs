//***
// Action
//   - The definition of a cpExecutive (inherits from cpEmployee)
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   - When cpEmployee is changed into abstract, see the changes
//   - When cpEmployee is changed into sealed, see the changes
//***

using System;

namespace CopyPaste.Organigram
{

  public class cpExecutive : cpEmployee
  {

    #region "Constructors / Destructors"
    
    public cpExecutive()
      //***
      // Action
      //   - Empty constructor of cpExecutive
      // Called by
      //   - frmInheritance.cmdCEO_Click(System.Object, System.EventArgs) Handles cmdCEO.Click
      // Calls
      //   - cpEmployee()
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpExecutive()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override void IncrementSalary(System.Single sngPercent)
      // public sealed override void IncrementSalary(System.Single sngPercent)
      //***
      // Action
      //   - The current salary of the employee is changed with a certain sngPercent
      //   - There is an extra 5% increase because the use of a car
      // Called by
      //   - frmInheritance.cmdCEO_Click(System.Object, System.EventArgs) Handles cmdCEO.Click
      // Calls
      //   - cpEmployee.Salary(decimal) (Set)
      //   - decimal cpEmployee.Salary (Get)
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - When abstract is used, check this code
      //   - When sealed is used, check this code
      //***
    {
      Salary = Salary * (1.05M + Convert.ToDecimal(sngPercent));
    }
    // IncrementSalary(System.Single)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpExecutive

}
// CopyPaste.Organigram