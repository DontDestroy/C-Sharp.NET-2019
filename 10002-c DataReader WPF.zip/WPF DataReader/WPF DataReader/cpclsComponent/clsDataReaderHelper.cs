﻿//***
// Action
//   - Having a generic routine for GetFieldValue
//   - Solves the IsNullable check for fields in the table
// Created
//   - CopyPaste – 20210819 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210819 – VVDW
// Proposal(To Do)
//   -
//***

using System;
using System.Data.SqlClient;

namespace WPFDataReader
{

  public static class cpDataReaderHelper
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static T GetFieldValue<T>(this SqlDataReader drdSQL, string strFieldName)
    //***
    // Action
    //   - Given an object T, a SqlDataReader and a fieldname
    //   - theReturn becomes a default value
    //   - If strFieldName of drdSQL equals the Null value of database
    //     - Do nothing (default value will be returned)
    //   - If Not
    //     - theReturn becomes the value of that field (recasted to type T)
    //   - Return a value of type T
    // Called by
    //   - ObservableCollection<cpProduct> cpDataReaderViewModel.GetProductsUsingExtensionMethods()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard Key
    //   - 
    // Proposal(To Do)
    //   -
    //***
    {
      T theReturn = default;

      if (drdSQL[strFieldName].Equals(DBNull.Value))
      {
      }
      else
      // (Not drdSQL[strFieldName].Equals(DBNull.Value))
      {
        theReturn = (T)drdSQL[strFieldName];
      }
      // (drdSQL[strFieldName].Equals(DBNull.Value))

      return theReturn;
    }
    // T GetFieldValue<T>(SqlDataReader, string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDataReaderHelper

}
// WPFDataReader 