//***
// Action
//   - Example of a listbox with checkboxes
// Created
//   - CopyPaste � 20240330 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240330 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmCheckListBox: System.Windows.Forms.Form
  {
    internal System.Windows.Forms.Button cmdShow;
    internal System.Windows.Forms.CheckedListBox chklst;

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCheckListBox));
      this.cmdShow = new System.Windows.Forms.Button();
      this.chklst = new System.Windows.Forms.CheckedListBox();
      this.SuspendLayout();
      // 
      // cmdShow
      // 
      this.cmdShow.Location = new System.Drawing.Point(156, 120);
      this.cmdShow.Name = "cmdShow";
      this.cmdShow.Size = new System.Drawing.Size(96, 23);
      this.cmdShow.TabIndex = 3;
      this.cmdShow.Text = "Show Choice";
      this.cmdShow.Click += new System.EventHandler(this.cmdShow_Click);
      // 
      // chklst
      // 
      this.chklst.Location = new System.Drawing.Point(28, 32);
      this.chklst.Name = "chklst";
      this.chklst.Size = new System.Drawing.Size(360, 64);
      this.chklst.TabIndex = 2;
      // 
      // frmCheckListBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(416, 165);
      this.Controls.Add(this.cmdShow);
      this.Controls.Add(this.chklst);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCheckListBox";
      this.Text = "CheckListBox";
      this.Load += new System.EventHandler(this.frmCheckListBox_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmCheckListBox'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmCheckListBox()
      //***
      // Action
      //   - Create instance of 'frmCheckListBox'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmCheckListBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string[] marrstrList = { "C# Programming Tips & Techniques", 
                                     "Visual Basic .Net Programming Tips & Techniques", 
                                     "HTML & Web Design Tips & Techniques", 
                                     "PC Performance Tuning & Upgrading Tips & Techniques"};

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdShow_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The selected items are counted
      //   - If count is zero
      //     - Show message that an item must be selected
      //   - If Not
      //     - Loop thru the selected items
      //       - Show message with the text of the selected item
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (chklst.CheckedItems.Count == 0)
      {
        MessageBox.Show("You must select an item");
      }
      else
        // chklst.CheckedItems.Count <> 0
      {
        
        foreach (System.Object theEntry in chklst.CheckedItems)
        {
          MessageBox.Show(theEntry.ToString());
        }
        // in chklst.CheckedItems

      }
      // chklst.CheckedItems.Count = 0
   
    }
    // cmdShow_Click(System.Object, System.EventArgs) Handles cmdShow.Click

    private void frmCheckListBox_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Checked Listbox is linked to the array
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      chklst.BeginUpdate();
      chklst.DataSource = marrstrList;
      chklst.EndUpdate();
    }
    // frmCheckListBox_Load(System.Object, System.EventArgs) Handles frmCheckListBox.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmCheckListBox
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmCheckListBox());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmCheckListBox

}
// CopyPaste.Learning