//***
// Action
//   - Demo the class cpTime
// Created
//   - CopyPaste � 20220301 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220301 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning.Toolkit.Time
{

  class cpProgram
	{

    static void Main()
    //***
    // Action
    //   - Define an instance of cpTime (thecpTime)
    //   - Prepare some output
    //   - Show a messagebox with the output
    //   - Set the time of thecpTime
    //   - Prepare some output
    //   - Show a messagebox with the output
    //   - Set the time of thecpTime
    //   - Prepare some output
    //   - Show a messagebox with the output
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpTime.New()
    //   - cpTime.SetTime(Integer, Integer, Integer)
    //   - cpTime.ToAmericanString()
    //   - cpTime.ToUniversalString()
    //   - MessageBox.Show(String, String) As DialogResult
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strOutput;
      cpTime thecpTime = new cpTime();

      strOutput = "The initial universal times is: " +
        thecpTime.ToUniversalString() + "\n" + 
        "The initial standard time is: " + thecpTime.ToAmericanString();
      MessageBox.Show(strOutput, "Testing Class cpTime");
      thecpTime.SetTime(13, 27, 6);
          
      strOutput = "The initial universal times is: " +
        thecpTime.ToUniversalString() + "\n" +
        "The initial standard time is: " + thecpTime.ToAmericanString();
      
      MessageBox.Show(strOutput, "Testing Class cpTime");
      thecpTime.SetTime(13, 99, 6);
          
      strOutput = "The initial universal times is: " + 
        thecpTime.ToUniversalString() + "\n" +
        "The initial standard time is: " + thecpTime.ToAmericanString();

      MessageBox.Show(strOutput, "Testing Class cpTime");
    }
    // Main()

	}
  // cpProgram

}
// CopyPaste.Learning.Toolkit.Time