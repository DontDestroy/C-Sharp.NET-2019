//***
// Action
//   - Startup screen of the duck game
// Created
//   - CopyPaste � 20240717 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240717 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Game.Duck.Library;
using System.Reflection;

namespace CopyPaste.Game.Duck
{

	public partial class frmDuckGame : System.Windows.Forms.Form
	{

		#region "Constructors / Destructors"

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		//***
		// Action
		//   - Clean up instance of 'frmDuckGame'
		// Called by
		//   - User action (Closing the form)
		// Calls
		//   - 
		// Created
		//   - CopyPaste � 20240717 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20240717 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{

			if (disposing)
			{

				if (components == null)
				{
				}
				else
				// (components != null)
				{
					components.Dispose();
				}
				// (components == null)

			}
			else
			// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		/// <summary>
		/// Constructor of the start screen of the Duck Game
		/// </summary>
		public frmDuckGame()
		//***
		// Action
		//   - Create instance of 'frmDuckGame'
		// Called by
		//   - Main()
		// Calls
		//   - InitializeComponent()
		//   - FillComboBoxWithChildsOfcpDuck()
		// Created
		//   - CopyPaste � 20240717 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20240717 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			InitializeComponent();
			FillComboBoxWithChildsOfcpDuck();
		}
		// frmDuckGame()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"

		private void cmbChooseDuck_SelectedIndexChanged(System.Object theSender, EventArgs theEventArguments)
			//***
			// Action
			//   - Find the location where the pictures are located
			//   - Make sure that there is a backslash at the end of the location
			//   - Add the folder "DuckDisplays" to the path
			//   - Construct the filename of the picture
			//   - Add this to the path
			//   - Show the picture in the picture box
			// Called by
			//   - User action (Choosing an option in the combo box)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240717 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240717 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			string strPath;

			try
			{

				if (cmbChooseDuck.SelectedItem == null)
				{
				}
				else
  				// cmbChooseDuck.SelectedItem <> null
				{

					strPath = Environment.CurrentDirectory;

					if (strPath.EndsWith('\\'))
					{
					}
					else
					// Not strPath.EndsWith('\\')
					{
						strPath += "\\";
					}
					// strPath.EndsWith('\\')

					strPath = strPath + "DuckDisplays\\" + cmbChooseDuck.SelectedItem.ToString() + ".jpg";
					picImage.Image = Image.FromFile(strPath);
				}
				// cmbChooseDuck.SelectedItem = null

			}
			catch (FileNotFoundException theException)
			{
				string strException = theException.ToString();
				// VVDW - I do nothing with this text yet
				lblErrorMessage.Text = "The picture was not found";
			}
			catch (Exception theException)
			{
				lblErrorMessage.Text = theException.ToString();
			}

		}
		// cmbChooseDuck_SelectedIndexChanged(System.Object, EventArgs) Handles cmbChooseDuck.SelectedIndexChanged

		#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Fill the combo box on the screen with all the childs of cpDuck
		/// </summary>
		private void FillComboBoxWithChildsOfcpDuck()
		//***
		// Action
		//   - Use cpDuck (data type)
		//     - Needed because I want to find the attached DuckGameLibrary assembly
		//   - Get the assembly of cpDuck
		//   - Loop thru all the types
		//     - If the type (class) had a base class of cpDuck
		//       - Add the name to the combo box
		//     - If not
		//       - Do nothing
		// Called by
		//   - frmDuckGame()
		// Calls
		//   - 
		// Created
		//   - CopyPaste � 20240717 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20240717 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			Type typBaseClass = typeof(cpDuck);
			Assembly theAssembly = typBaseClass.Assembly;
			// Assembly theAssembly = Assembly.GetExecutingAssembly();
			// VVDW - This can be used if the classes are inside the current assembly
			// VVDW - In this battleplan solution it is not the case
			// VVDW - So I look up the assembly where cpDuck is defined

			foreach (Type theType in theAssembly.GetTypes())
			{

				if (theType.BaseType == typBaseClass)
				{
					cmbChooseDuck.Items.Add(theType.Name);
				}
				else
  				// theType.BaseType <> typBaseClass
				{
				}
				// theType.BaseType = typBaseClass

			}
			// in theAssembly.GetTypes()

		}
		// FillComboBoxWithChildsOfcpDuck()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmDuckGame

}
// CopyPaste.Game.Duck