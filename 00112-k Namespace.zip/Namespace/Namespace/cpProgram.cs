//***
// Action
//   - Testroutine of 2 different classes with the same name
// Created
//   - CopyPaste � 20240410 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240410 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Explanation of the code in this method
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Mailing.cpAddress.New(String, String, String, String)
      //   - Mailing.cpAddress.ToString() As String
      //   - Network.cpAddress.New(String, String)
      //   - Network.cpAddress.ToString() As String
      // Created
      //   - CopyPaste � 20240410 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240410 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Network.cpAddress thecpIPAddress = new Network.cpAddress("122.111.222.112", "www.CopyPaste.be");
      Mailing.cpAddress thecpEmployeeAddress = new Mailing.cpAddress("Hazebos 13", "Zonnebeke", "Belgium", "B-8980");

      Console.WriteLine(thecpIPAddress);
      Console.WriteLine(thecpEmployeeAddress);
      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning