'***
' Action
'   - ADO code about commands
' Created
'   - CopyPaste � 20260331 � VVDW
' Changed
'   - CopyPaste � yyyymmdd � VVDW � What changed
' Tested
'   - CopyPaste � 20260331 � VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On
Option Strict On

Imports Microsoft.VisualBasic.ControlChars
Imports System.Windows.Forms

Namespace CopyPaste.Learning

  Public Module modCommand

    '#Region "Constructors / Destructors"
    '#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

    '#Region "Fields"
    '#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

    '#Region "Controls"
    '#End Region

#Region "Functionality"

    '#Region "Event"
    '#End Region

#Region "Sub / Function"

    Public Sub CreatingASQLServerObjectFromADO()
      '***
      ' Action
      '   - Create a SQL statement
      '   - Create a new instance of a command
      '   - Create a new instance of a connection
      '   - Open the connection
      '   - Set the connection to the command
      '   - Set the SQL Statement to the command
      '   - Say that the command is a text command
      '   - Execute the command
      '   - Set the command to nothing
      '   - Close the connection
      ' Called by
      '   - frmMain.cmdCreatingSQLServerObjects_Click(System.Object, System.EventArgs) Handles cmdCreatingSQLServerObjects.Click
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      Dim strSQL As String = "CREATE TABLE tblCPTest (intIdPrimary Integer IDENTITY(1,1) PRIMARY KEY, strField Text)"
      Dim theCommand As New ADODB.Command
      Dim theConnection As New ADODB.Connection

      OpencpNorthwindScriptADOConnection(theConnection)
      theCommand.ActiveConnection = theConnection
      theCommand.CommandText = strSQL
      theCommand.CommandType = ADODB.CommandTypeEnum.adCmdText
      theCommand.Execute()
      theCommand = Nothing
      theConnection.Close()
    End Sub
    ' CreatingASQLServerObjectFromADO()

    Public Sub ExecuteABatchCommand(ByVal txtResult As TextBox)
      '***
      ' Action
      '   - Create two instances of a recordset
      '   - Define a select sql statement (to display)
      '   - Define a first update statement (to change)
      '   - Define a second update statement (to change back to original)
      '   - Create a new instance of a command
      '   - Create a new instance of a connection
      '   - Define a parameter
      '   - Open the connection
      '   - Open the recordset with the select statement
      '   - Show the values
      '   - Assign the connection to the command
      '   - Assign the update statement to the command
      '   - Say that the command is a sql statement to execute
      '   - Execute the command
      '   - Open the recordset with the select statement
      '   - Show the values
      '   - Put the records back to their original
      '   - Close the recordsets
      '   - Set the command to nothing
      '   - Close the connection
      ' Called by
      '   - frmMain.cmdBatchUpdate_Click(System.Object, System.EventArgs) Handles cmdBatchUpdate.Click
      ' Calls
      '   - modConnection.OpencpNorthwindScriptADOConnection(�ADODB.Connection)
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      Dim rstNew As New ADODB.Recordset
      Dim rstOld As New ADODB.Recordset
      Dim strDisplaySQLStatement As String = "SELECT intIdOrder, dtmShippedDate FROM tblCPOrder WHERE intIdOrder < 10251"
      Dim strSQLStatementFirstChange As String = "UPDATE tblCPOrder SET dtmShippedDate = dtmShippedDate+1"
      Dim strSQLStatementSecondChange As String = "UPDATE tblCPOrder SET dtmShippedDate = dtmShippedDate-1"
      Dim theCommand As New ADODB.Command
      Dim theConnection As New ADODB.Connection
      Dim theParameter As ADODB.Parameter

      OpencpNorthwindScriptADOConnection(theConnection)
      rstOld.Open(strDisplaySQLStatement, theConnection)
      txtResult.Text = "Old Values: " & CrLf & CrLf & rstOld.GetString

      theCommand.ActiveConnection = theConnection
      theCommand.CommandText = strSQLStatementFirstChange
      theCommand.CommandType = ADODB.CommandTypeEnum.adCmdText
      theCommand.Execute()

      rstNew.Open(strDisplaySQLStatement, theConnection)
      txtResult.Text &= CrLf & CrLf & "New Values: " & CrLf & CrLf & rstNew.GetString

      theCommand.CommandText = strSQLStatementSecondChange
      theCommand.CommandType = ADODB.CommandTypeEnum.adCmdText
      theCommand.Execute()

      theCommand = Nothing
      rstOld.Close()
      rstNew.Close()
      theConnection.Close()
    End Sub
    ' ExecuteABatchCommand(TextBox)

    Public Sub UseAStoredProcedureWithAParameter(ByVal txtResult As TextBox)
      '***
      ' Action
      '   - Create a new instance of a command
      '   - Create a new instance of a connection
      '   - Define a parameter
      '   - Create a new instance of a recordset
      '   - Try to
      '     - Define the stored procedure to the command
      '     - Say that the command must be treated as a stored procedure
      '     - Create the parameter
      '     - Add the parameter to the command
      '     - Set the value of the parameter
      '     - Create and open the connection
      '     - Set the connection to the command
      '     - Open the recordset (by executing the command)
      '     - Set the result
      '   - On possible error
      '     - Show the exception message
      '   - Close the recordset
      '   - Close the connection
      ' Called by
      '   - frmMain.cmdStoredProcWithParam_Click(System.Object, System.EventArgs) Handles cmdStoredProcWithParam.Click
      ' Calls
      '   - OpencpNorthwindScriptADOConnection(�ADODB.Connection)
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      Dim theCommand As New ADODB.Command
      Dim theConnection As New ADODB.Connection
      Dim theParameter As ADODB.Parameter
      Dim theRecordset As New ADODB.Recordset

      Try
        theCommand.CommandText = "spCPCustomerOrderHistory"
        theCommand.CommandType = ADODB.CommandTypeEnum.adCmdStoredProc
        theParameter = theCommand.CreateParameter("KeyCustomer", ADODB.DataTypeEnum.adChar, ADODB.ParameterDirectionEnum.adParamInput, 5)
        theCommand.Parameters.Append(theParameter)
        theParameter.Value = "CHOPS"

        OpencpNorthwindScriptADOConnection(theConnection)
        theCommand.ActiveConnection = theConnection
        theRecordset.Open(theCommand)
        txtResult.Text = theRecordset.GetString
      Catch theException As Exception
        MessageBox.Show(theException.Message)
      Finally
        theRecordset.Close()
        theConnection.Close()
        theCommand = Nothing
      End Try

    End Sub
    ' UseAStoredProcedureWithAParameter(TextBox)

#End Region

#End Region

#End Region

    '#Region "Not used"
    '#End Region

  End Module
  ' modCommand

End Namespace
' CopyPaste.Learning