//***
// Action
//   - xample of password with timer
// Created
//   - CopyPaste � 20240118 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240118 � VVDW
// Proposal (To Do)
//   - There is an error in the application when you test profoundly
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmPassword: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdAccept;
    internal System.Windows.Forms.Label lblTime;
    internal System.Windows.Forms.TextBox txtPassword;
    internal System.Windows.Forms.Timer tmrCountDown;
    private System.ComponentModel.IContainer components;

		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPassword));
      this.cmdAccept = new System.Windows.Forms.Button();
      this.lblTime = new System.Windows.Forms.Label();
      this.txtPassword = new System.Windows.Forms.TextBox();
      this.tmrCountDown = new System.Windows.Forms.Timer(this.components);
      this.SuspendLayout();
      // 
      // cmdAccept
      // 
      this.cmdAccept.Location = new System.Drawing.Point(136, 72);
      this.cmdAccept.Name = "cmdAccept";
      this.cmdAccept.Size = new System.Drawing.Size(88, 24);
      this.cmdAccept.TabIndex = 5;
      this.cmdAccept.Text = "&Accept";
      this.cmdAccept.Click += new System.EventHandler(this.cmdAccept_Click);
      // 
      // lblTime
      // 
      this.lblTime.Location = new System.Drawing.Point(0, 24);
      this.lblTime.Name = "lblTime";
      this.lblTime.RightToLeft = System.Windows.Forms.RightToLeft.No;
      this.lblTime.Size = new System.Drawing.Size(360, 16);
      this.lblTime.TabIndex = 3;
      this.lblTime.Text = "Enter your password within 20 seconds";
      this.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // txtPassword
      // 
      this.txtPassword.Location = new System.Drawing.Point(72, 48);
      this.txtPassword.Name = "txtPassword";
      this.txtPassword.PasswordChar = '*';
      this.txtPassword.Size = new System.Drawing.Size(200, 20);
      this.txtPassword.TabIndex = 4;
      this.txtPassword.Text = "";
      // 
      // tmrCountDown
      // 
      this.tmrCountDown.Enabled = true;
      this.tmrCountDown.Interval = 1000;
      this.tmrCountDown.Tick += new System.EventHandler(this.tmrCountDown_Tick);
      // 
      // frmPassword
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(360, 109);
      this.Controls.Add(this.lblTime);
      this.Controls.Add(this.txtPassword);
      this.Controls.Add(this.cmdAccept);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPassword";
      this.Text = "Password";
      this.ResumeLayout(false);

    }
		// InitializeComponent()

		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmPassword'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240118 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240118 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmPassword()
			//***
			// Action
			//   - Create instance of 'frmPassword'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240118 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240118 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmPassword()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

    int mlngCountDown = 20;

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"

    
    private void cmdAccept_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If 'txtPassword' = "secret"
      //     - Stop timer
      //     - Show message
      //     - End program
      //   - If Not
      //     - Show error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - DialogResult System.Windows.Forms.MessageBox(String)
      // Created
      //   - CopyPaste � 20240118 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240118 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (txtPassword.Text == "secret")
      {
        tmrCountDown.Enabled = false;
        MessageBox.Show("Welcome in the system!");
        Application.Exit();
      }
      else
        // txtPassword.Text <> "secred"
      {
        MessageBox.Show("Sorry, friend, I don't know who you are.");
      }
      // txtPassword.Text = "secred"
    
    }
    // cmdAccept_Click(System.Object, System.EventArgs) Handles cmdAccept.Click
    
    private void tmrCountDown_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If 'mlngCountDown' > 0
      //     - 'mlngCountDown' becomes one less
      //     - 'lblTime' is filled in
      //   - If Not
      //     - Stop timer
      //     - Show message
      //     - End program
      // Called by
      //   - System action (A tick has passed by)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240118 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240118 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (mlngCountDown > 0)
      {
        mlngCountDown -= 1;
        lblTime.Text = "Enter your password within " + mlngCountDown + " seconds";
      }
      else
        // mlngCountDown <= 0
      {
        tmrCountDown.Enabled = false;
        MessageBox.Show("Sorry, time is up.");
        Application.Exit();
      }
      // mlngCountDown > 0
    
    }
    // tmrCountDown_Tick(System.Object, System.EventArgs) Handles tmrCountDown.Tick

    #endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmPassword
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmDefault()
			// Created
			//   - CopyPaste � 20240118 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240118 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmPassword());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmPassword

}
// CopyPaste.Learning