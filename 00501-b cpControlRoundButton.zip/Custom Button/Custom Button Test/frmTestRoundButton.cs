//***
// Action
//   - Testform to demo the cpRoundButton
// Created
//   - CopyPaste � 20240221 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240221 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTestRoundButton: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTestRoundButton));
      // 
      // frmTestRoundButton
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTestRoundButton";
      this.Text = "Test Round Button";
      this.Load += new System.EventHandler(this.frmTestRoundButton_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTestRoundButton'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTestRoundButton()
      //***
      // Action
      //   - Create instance of 'frmTestRoundButton'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTestRoundButton()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmTestRoundButton_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - A new cpctlRoundButton is created
      //   - The position is 10 pixels from the top
      //   - The position is 10 pixels from the left
      //   - The cpctlRoundButton is added to the controls (of the form)
      //   - The click event is handled
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - cpctlRoundButton()
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpctlRoundButton thecpRoundButton = new cpctlRoundButton();

      thecpRoundButton.Top = 10;
      thecpRoundButton.Left = 10;
      this.Controls.Add(thecpRoundButton);
      thecpRoundButton.Click += new EventHandler(RoundButton_Click);
    }
    // frmTestRoundButton_Load(System.Object, System.EventArgs) Handles this.Load

    private void RoundButton_Click(System.Object theSender, EventArgs theEventArguments)
      //***
      // Action
      //   - A cpctlRoundButton is defined
      //   - Message "Hello" is shown
      //   - theSender becomes the cpctlRoundButton
      //   - The cpctlRoundButton is moved 10 pixels to the bottom and to the right
      // Called by
      //   - User action (Clicking a cpctlRoundButton)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpctlRoundButton thecpButton;

      MessageBox.Show("Hello");
      thecpButton = theSender as cpctlRoundButton;

      if (thecpButton == null)
      {
      }
      else
        // thecpButton <> null
      {
        thecpButton.Top += 10;
        thecpButton.Left += 10;
      }
      // thecpButton = null

    }
    // RoundButton_Click(System.Object theSender, EventArgs theEventArguments)

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTestRoundButton
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTestRoundButton());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTestRoundButton

}
// CopyPaste.Learning