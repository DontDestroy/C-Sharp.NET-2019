//***
// Action
//   - Interface definition for customer class
//   - Define the properties
//   - Define the methods
// Created
//   - CopyPaste � 20260117 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260117 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public interface cpiCustomerTryout
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    string Address{get; set;}
    string City{get; set;}
    string CompanyName{get; set;}
    string ContactName{get; set;}
    string ContactTitle{get; set;}
    string Country{get; set;}
    string Fax{get; set;}
    string IdCustomer{get; }
    string Phone{get; set;}
    string PostalCode{get; set;}
    string Region{get; set;}

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    bool Delete();
    bool Save();
    string ToString();

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpiCustomerTryout

}
// CopyPaste.Learning