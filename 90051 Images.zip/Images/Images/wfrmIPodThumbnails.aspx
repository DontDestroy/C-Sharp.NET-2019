﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmIPodThumbnails.aspx.cs" Inherits="CopyPaste.Learning.wfrmIPodThumbnails" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>myPod</title>
  <style>
    body {
      background-color: #eaf3da;
    }
  </style>
</head>
<body>
  <form id="wfrmIPodThumbnails">
    <p>
      <img src="./Resources/myPod.png" alt="myPod Logo" />
    </p>
    <h1>Welcome to myPod</h1>
    <p>
      Welcome to the place to show off your iPod, wherever you might be.
      Wanna join the fun? All you need is any iPod, from the early classic iPod to the latest iPod Nano,
      the smallest iPod Shuffle to the largest iPod Photo, and a digital camera.
      Just take a snapshot of your iPod in your favorite location and we'll be glad to post it on myPod.
      So, what are you waiting for?
    </p>
    <h2>Seattle, Washington</h2>
    <p>
      Me and my iPod in Seattle! You can see rain clouds and the Space Needle. You can't see the 628 coffee shops.
    </p>
    <p>
      <a href="wfrmSeattle.aspx">
        <img src="./Resources/Thumbnails/Seattle.jpg" alt="The skyline of Seattle" />
      </a>
      <a href="wfrmSeattleClassic.aspx">
        <img src="./Resources/Thumbnails/Seattle_Classic.jpg" alt="The skyline of Seattle with classic iPod" />
      </a>
      <a href="wfrmSeattleShuffle.aspx">
        <img src="./Resources/Thumbnails/Seattle_Shuffle.jpg" alt="An iPod shuffle in Seattle" />
      </a>
      <a href="wfrmSeattleDowntown.aspx">
        <img src="./Resources/Thumbnails/Seattle_Downtown.jpg" alt="An iPod downtown in Seattle" />
      </a>
    </p>
    <h2>Birmingham, England</h2>
    <p>
      Here are some iPod photos around Birmingham. We've obviously got some passionate folks over here who love their iPods.
      Check out the classic red British telephone box!
    </p>
    <p>
      <a href="wfrmBritain.aspx">
        <img src="./Resources/Thumbnails/Britain.jpg" alt="An iPod in Birmingham at a telephone box" />
      </a>
      <a href="wfrmAppleStore.aspx">
        <img src="./Resources/Thumbnails/AppleStore.jpg" alt="An iPod at the Birmingham Apple store" />
      </a>
    </p>
  </form>
</body>
</html>
