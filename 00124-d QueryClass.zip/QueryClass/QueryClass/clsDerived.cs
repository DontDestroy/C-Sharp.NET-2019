//***
// Action
//   - Implementation of cpDerived
// Created
//   - CopyPaste � 20240705 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240705 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpDerived : cpBase, IFormattable
  {

    #region "Constructors / Destructors"

    public cpDerived(string strTitle, string strAuthor, string strPublisher, string strProductId, double dblPrice, double dblWeight) : base(strProductId, dblPrice, dblWeight)
      //***
      // Action
      //   - Constructor of a cpDerived with a given Title, Author, Publisher, ProductId, Price and Weight
      // Called by
      //   - modQueryClass.Main()
      // Calls
      //   - cpBase(string, double, double)
      // Created
      //   - CopyPaste � 20240705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240705 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrTitle = strTitle;
      mstrAuthor = strAuthor;
      mstrPublisher = strPublisher;
    }
    // cpDerived(string, string, string, string, double, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public string mstrAuthor;
    public string mstrPublisher;
    public string mstrTitle;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ShowBook()
      //***
      // Action
      //   - Show information about the object
      //   - Title, Author and Publisher
      //   - ProductId, Weight and Price (thru inheritance)
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpBase.ShowProduct()
      // Created
      //   - CopyPaste � 20240705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Title: " + mstrTitle);
      Console.WriteLine("Author: " + mstrAuthor);
      Console.WriteLine("Publisher: " + mstrPublisher);
      ShowProduct();
    }
    // ShowBook()

    public string ToString(string strFormat, IFormatProvider theFormatProvider)
      //***
      // Action
      //   - Show information about the object
      //   - Title
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return mstrTitle;
    }
    // string ToString(string, IFormatProvider) Implements IFormattable.ToString

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDerived

}
// CopyPaste.Learning