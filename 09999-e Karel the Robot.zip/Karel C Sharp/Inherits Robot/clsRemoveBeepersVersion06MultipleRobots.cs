﻿//***
// Action
//   - A field of crops must be harvested
// Created
//   - CopyPaste – 20251027 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251027 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

  public class cpRemoveBeepersVersion06MultipleRobots : cpBadFieldHarvesterVersion05
  {

    #region "Constructors / Destructors"

    public cpRemoveBeepersVersion06MultipleRobots(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpRemoveBeepersVersion06MultipleRobots starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpRemoveBeepersVersion06MultipleRobots(int, int, Directions.Direction, int)
    //   - cpProgram.RemoveBeepersVersion06MultipleRobots()
    // Calls
    //   - cpBadFieldHarvesterVersion05(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251013 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251013 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRemoveBeepersVersion06MultipleRobots(int, int, Directions.Direction, int, Color) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpBadFieldHarvester

}
// cpKarelTheRobot