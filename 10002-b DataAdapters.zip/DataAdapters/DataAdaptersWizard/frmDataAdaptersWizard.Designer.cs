﻿//***
// Action
//   - Having DataAdapters and Commands towards a database
// Created
//   - CopyPaste – 20210706 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210706 – VVDW
// Proposal (To Do)
//   -
//***

namespace DataAdaptersWizard
{

  partial class frmDataAdaptersWizard
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.TextBox txtMessages;
    internal System.Windows.Forms.TabPage pagCategory;
    internal System.Windows.Forms.DataGrid dgrCategories;
    internal System.Windows.Forms.BindingSource bdsrcCategory;
    internal System.Windows.Forms.Button cmdFillAll;
    internal System.Windows.Forms.TabControl tabTables;
    internal System.Windows.Forms.TabPage pagProduct;
    internal System.Windows.Forms.DataGrid dgrProducts;
    internal System.Windows.Forms.BindingSource bdsrcProduct;
    internal System.Windows.Forms.Button cmdUpdateCategory;
    internal System.Windows.Forms.Label lblMessage;
    internal dsCategory dsCategory;
    internal dsCategoryTableAdapters.tbaCategory tbaCategory;
    internal dsProductTableAdapters.tbaProduct tbaProduct;
    internal dsProduct dsProduct;
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataAdaptersWizard));
      this.txtMessages = new System.Windows.Forms.TextBox();
      this.pagCategory = new System.Windows.Forms.TabPage();
      this.dgrCategories = new System.Windows.Forms.DataGrid();
      this.bdsrcCategory = new System.Windows.Forms.BindingSource(this.components);
      this.dsCategory = new DataAdaptersWizard.dsCategory();
      this.cmdFillAll = new System.Windows.Forms.Button();
      this.tabTables = new System.Windows.Forms.TabControl();
      this.pagProduct = new System.Windows.Forms.TabPage();
      this.dgrProducts = new System.Windows.Forms.DataGrid();
      this.bdsrcProduct = new System.Windows.Forms.BindingSource(this.components);
      this.dsProduct = new DataAdaptersWizard.dsProduct();
      this.cmdUpdateCategory = new System.Windows.Forms.Button();
      this.lblMessage = new System.Windows.Forms.Label();
      this.tbaCategory = new DataAdaptersWizard.dsCategoryTableAdapters.tbaCategory();
      this.tbaProduct = new DataAdaptersWizard.dsProductTableAdapters.tbaProduct();
      this.pagCategory.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgrCategories)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCategory)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCategory)).BeginInit();
      this.tabTables.SuspendLayout();
      this.pagProduct.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgrProducts)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcProduct)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsProduct)).BeginInit();
      this.SuspendLayout();
      // 
      // txtMessages
      // 
      this.txtMessages.Location = new System.Drawing.Point(8, 294);
      this.txtMessages.Multiline = true;
      this.txtMessages.Name = "txtMessages";
      this.txtMessages.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtMessages.Size = new System.Drawing.Size(408, 80);
      this.txtMessages.TabIndex = 7;
      // 
      // pagCategory
      // 
      this.pagCategory.Controls.Add(this.dgrCategories);
      this.pagCategory.Location = new System.Drawing.Point(4, 22);
      this.pagCategory.Name = "pagCategory";
      this.pagCategory.Size = new System.Drawing.Size(400, 230);
      this.pagCategory.TabIndex = 0;
      this.pagCategory.Text = "Category";
      // 
      // dgrCategories
      // 
      this.dgrCategories.DataMember = "tblCPCategory";
      this.dgrCategories.DataSource = this.bdsrcCategory;
      this.dgrCategories.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrCategories.Location = new System.Drawing.Point(8, 8);
      this.dgrCategories.Name = "dgrCategories";
      this.dgrCategories.Size = new System.Drawing.Size(384, 216);
      this.dgrCategories.TabIndex = 0;
      // 
      // bdsrcCategory
      // 
      this.bdsrcCategory.DataSource = this.dsCategory;
      this.bdsrcCategory.Position = 0;
      // 
      // dsCategory
      // 
      this.dsCategory.DataSetName = "dsCategory";
      this.dsCategory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // cmdFillAll
      // 
      this.cmdFillAll.Location = new System.Drawing.Point(432, 38);
      this.cmdFillAll.Name = "cmdFillAll";
      this.cmdFillAll.Size = new System.Drawing.Size(112, 23);
      this.cmdFillAll.TabIndex = 8;
      this.cmdFillAll.Text = "&Fill All";
      this.cmdFillAll.Click += new System.EventHandler(this.cmdFillAll_Click);
      // 
      // tabTables
      // 
      this.tabTables.Controls.Add(this.pagCategory);
      this.tabTables.Controls.Add(this.pagProduct);
      this.tabTables.Location = new System.Drawing.Point(8, 14);
      this.tabTables.Name = "tabTables";
      this.tabTables.SelectedIndex = 0;
      this.tabTables.Size = new System.Drawing.Size(408, 256);
      this.tabTables.TabIndex = 5;
      // 
      // pagProduct
      // 
      this.pagProduct.Controls.Add(this.dgrProducts);
      this.pagProduct.Location = new System.Drawing.Point(4, 22);
      this.pagProduct.Name = "pagProduct";
      this.pagProduct.Size = new System.Drawing.Size(400, 230);
      this.pagProduct.TabIndex = 1;
      this.pagProduct.Text = "Product";
      // 
      // dgrProducts
      // 
      this.dgrProducts.DataMember = "tblCPProduct";
      this.dgrProducts.DataSource = this.bdsrcProduct;
      this.dgrProducts.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrProducts.Location = new System.Drawing.Point(8, 8);
      this.dgrProducts.Name = "dgrProducts";
      this.dgrProducts.Size = new System.Drawing.Size(384, 216);
      this.dgrProducts.TabIndex = 0;
      // 
      // bdsrcProduct
      // 
      this.bdsrcProduct.DataSource = this.dsProduct;
      this.bdsrcProduct.Position = 0;
      // 
      // dsProduct
      // 
      this.dsProduct.DataSetName = "dsProduct";
      this.dsProduct.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // cmdUpdateCategory
      // 
      this.cmdUpdateCategory.Location = new System.Drawing.Point(432, 70);
      this.cmdUpdateCategory.Name = "cmdUpdateCategory";
      this.cmdUpdateCategory.Size = new System.Drawing.Size(112, 23);
      this.cmdUpdateCategory.TabIndex = 9;
      this.cmdUpdateCategory.Text = "&Update Category";
      this.cmdUpdateCategory.Click += new System.EventHandler(this.cmdUpdateCategory_Click);
      // 
      // lblMessage
      // 
      this.lblMessage.AutoSize = true;
      this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblMessage.Location = new System.Drawing.Point(8, 278);
      this.lblMessage.Name = "lblMessage";
      this.lblMessage.Size = new System.Drawing.Size(67, 13);
      this.lblMessage.TabIndex = 6;
      this.lblMessage.Text = "Messages:";
      // 
      // tbaCategory
      // 
      this.tbaCategory.ClearBeforeFill = false;
      // 
      // tbaProduct
      // 
      this.tbaProduct.ClearBeforeFill = true;
      // 
      // frmDataAdaptersWizard
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(552, 389);
      this.Controls.Add(this.txtMessages);
      this.Controls.Add(this.cmdFillAll);
      this.Controls.Add(this.tabTables);
      this.Controls.Add(this.cmdUpdateCategory);
      this.Controls.Add(this.lblMessage);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataAdaptersWizard";
      this.Text = "Data Adapters Wizard";
      this.pagCategory.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgrCategories)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCategory)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCategory)).EndInit();
      this.tabTables.ResumeLayout(false);
      this.pagProduct.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgrProducts)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcProduct)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsProduct)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210706 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210706 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      if (disposing && (components != null))
      {
        components.Dispose();
      }
      // disposing and (components <> null)

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataAdaptersWizard

}
// DataAdaptersWizard