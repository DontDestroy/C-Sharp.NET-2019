﻿//***
// Action
//   - Demo of Sorting and Orderning with Linq
//   - Keyword OrderBy
//   - Keyword OrderByDescending
//   - Keyword ThenBy
//   - Keyword ThenByDescending
//   - Keyword Reverse
// Created
//   - CopyPaste – 20230502 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230502 – VVDW
// Proposal (To Do)
//   -
//***

using AmericanHistory;
using CopyPaste.Learning;
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace DeferredOperatorLinq
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Study the methods in order
    //   - Try to experiment, your own location to try things out
    //   - Sort a list in an order
    //   - Sort a list in an order descending
    //   - Sort a list in an order and by equals in another order
    //   - Sort a list in an order descending and by equals in another order descending
    //   - Reverse a list
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - OrderningOrderBy()
    //   - OrderningOrderByDescending()
    //   - OrderningOrderByThenBy()
    //   - OrderningOrderByDescendingThenByDescending()
    //   - OrderningReverse()
    //   - TryToExperiment()
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      TryToExperiment();
      // OrderningOrderBy();
      // OrderningOrderByDescending();
      // OrderningOrderByThenBy();
      // OrderningOrderByDescendingThenByDescending();
      // OrderningReverse();
      Console.ReadLine();
    }
    // Main()

    public static void OrderningOrderBy()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Ordening operators return an output sequence of elements that is the input sequence in a specific order
    //     - The input sequence is of the form IEnumerable<T>
    //     - The output sequence is of the form IOrderedEnumerable<T>
    //     - The order is determined by a keySelector method
    //   - OrderBy has 2 overloads
    //     - Order the elements of a collection into a sequence using a keySelector delegate
    //     - Order the elements of a collection into a sequence using a keySelector delegate with a comparer
    //   - Fill the array with presidents
    //   - Order the presidents names shortest first (Lambda Linq Dot Notation)
    //   - Show result 
    //   - Order the presidents names shortest first (Linq Fluent Syntax Query Expression)
    //   - Show result 
    //   - Create an instance of cpVowelConsonantRatioComparer (self created comparer)
    //     - Doing this allows me to use the methods in this class (displaying information)
    //   - Order the presidents names by a self created ordening (Lambda Linq Dot Notation)
    //   - Show result (using the comparer information)
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - cpVowelConsonantRatioComparer()
    //   - ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)
    //   - ShowContentOfSequenceComparer(IOrderedEnumerable<cpPresident>, cpVowelConsonantRatioComparer, string)
    //   - string cpPresident.Name (Get)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IOrderedEnumerable<cpPresident> colResultComparerLambda;
      IOrderedEnumerable<cpPresident> colResultExpression;
      IOrderedEnumerable<cpPresident> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();

      colResultLambda = cpPresident.AllPresidents.OrderBy(aPresident => aPresident.Name.Length);
      // OrderBy takes an input sequence and a keySelector delegate, and returns an object that, when enumerated,
      // enumerates throught the input source sequence passing each element to the keySelector method retrieving each key,
      // and orders in ascending order the sequence using the key (in this example cpPresident)
      // On equal values, the order is stable, the order is maintained in the order the input sequence was
      // OrderBy is an extension method, so we use it on an instance of a sequence that is comparable (AllPresidents)

      ShowContentOfPresidentSequence(colResultLambda, "The list of the American Presidents names in order of length: (Lambda Linq Dot Notation)");

      colResultExpression = from aPresident in cpPresident.AllPresidents
                            orderby aPresident.Name.Length
                            select aPresident;

      Console.WriteLine();
      ShowContentOfPresidentSequence(colResultExpression, "The list of the American Presidents names in order of length: (Linq Fluent Syntax Query Expression)");

      cpVowelConsonantRatioComparer theComparer = new cpVowelConsonantRatioComparer();

      colResultComparerLambda = cpPresident.AllPresidents.OrderBy((aPresident => aPresident.Name), theComparer);
      // OrderBy takes an input sequence and a keySelector delegate, and returns an object that, when enumerated,
      // enumerates throught the input source sequence passing each element to the keySelector method retrieving each key,
      // and orders in ascending order the sequence using the comparer (in this example theComparer)
      // On equal values, the order is stable, the order is maintained in the order the input sequence was
      // OrderBy is an extension method, so we use it on an instance of a sequence that is comparable (AllPresidents)

      Console.WriteLine();
      ShowContentOfSequenceComparer(colResultComparerLambda, theComparer, "The list of the American Presidents names in order of the ratio between vowels and consonants: (Lambda Linq Dot Notation)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // OrderningOrderBy()

    public static void OrderningOrderByDescending()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Ordening operators return an output sequence of elements that is the input sequence in a specific order
    //     - The input sequence is of the form IEnumerable<T>
    //     - The output sequence is of the form IOrderedEnumerable<T>
    //     - The order is determined by a keySelector method
    //   - OrderByDescending has 2 overloads
    //     - Order the elements of a collection into a sequence using a keySelector delegate
    //     - Order the elements of a collection into a sequence using a keySelector delegate with a comparer
    //   - Fill the array with presidents
    //   - Order the presidents names longest first (Lambda Linq Dot Notation)
    //   - Show result 
    //   - Order the presidents names longest first (Linq Fluent Syntax Query Expression)
    //   - Show result 
    //   - Create an instance of cpVowelConsonantRatioComparer (self created comparer)
    //     - Doing this allows me to use the methods in this class (displaying information)
    //   - Order the presidents names by a self created ordening descending (Lambda Linq Dot Notation)
    //   - Show result (using the comparer information)
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - cpVowelConsonantRatioComparer()
    //   - ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)
    //   - ShowContentOfSequenceComparer(IOrderedEnumerable<cpPresident>, cpVowelConsonantRatioComparer, string)
    //   - string cpPresident.Name (Get)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IOrderedEnumerable<cpPresident> colResultComparerLambda;
      IOrderedEnumerable<cpPresident> colResultExpression;
      IOrderedEnumerable<cpPresident> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();

      colResultLambda = cpPresident.AllPresidents.OrderByDescending(aPresident => aPresident.Name.Length);
      // OrderByDescending takes an input sequence and a keySelector delegate, and returns an object that, when enumerated,
      // enumerates throught the input source sequence passing each element to the keySelector method retrieving each key,
      // and orders in descending order the sequence using the key (in this example cpPresident)
      // On equal values, the order is stable, the order is maintained in the order the input sequence was
      // OrderByDescending is an extension method, so we use it on an instance of a sequence that is comparable (AllPresidents)

      ShowContentOfPresidentSequence(colResultLambda, "The list of the American Presidents names in descending order of length: (Lambda Linq Dot Notation)");

      colResultExpression = from aPresident in cpPresident.AllPresidents
                            orderby aPresident.Name.Length descending
                            select aPresident;

      Console.WriteLine();
      ShowContentOfPresidentSequence(colResultExpression, "The list of the American Presidents names in descending order of length: (Linq Fluent Syntax Query Expression)");

      cpVowelConsonantRatioComparer theComparer = new cpVowelConsonantRatioComparer();

      colResultComparerLambda = cpPresident.AllPresidents.OrderByDescending((aPresident => aPresident.Name), theComparer);
      // OrderByDescending takes an input sequence and a keySelector delegate, and returns an object that, when enumerated,
      // enumerates throught the input source sequence passing each element to the keySelector method retrieving each key,
      // and orders in descending order the sequence using the comparer (in this example theComparer)
      // On equal values, the order is stable, the order is maintained in the order the input sequence was
      // OrderByDescending is an extension method, so we use it on an instance of a sequence that is comparable (AllPresidents)

      Console.WriteLine();
      ShowContentOfSequenceComparer(colResultComparerLambda, theComparer, "The list of the American Presidents names in descending order of the ratio between vowels and consonants: (Lambda Linq Dot Notation)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // OrderningOrderByDescending()

    public static void OrderningOrderByDescendingThenByDescending()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Ordening operators return an output sequence of elements that is the input sequence in a specific order
    //     - The input sequence is of the form IEnumerable<T>
    //     - The output sequence is of the form IOrderedEnumerable<T>
    //     - The order is determined by a keySelector method
    //   - OrderBy has 2 overloads
    //     - Order the elements of a collection into a sequence using a keySelector delegate
    //     - Order the elements of a collection into a sequence using a keySelector delegate with a comparer
    //   - Fill the array with presidents
    //   - Order the presidents names longest first (Lambda Linq Dot Notation)
    //   - Then order the presidents names alfabetic descending (Lambda Linq Dot Notation)
    //   - Show result 
    //   - Order the presidents names longest first (Linq Fluent Syntax Query Expression)
    //   - Then order the presidents names alfabetic descending (Linq Fluent Syntax Query Expression)
    //   - Show result 
    //   - Create an instance of cpVowelConsonantRatioComparer (self created comparer)
    //     - Doing this allows me to use the methods in this class (displaying information)
    //   - Order the presidents names longest first (Linq Fluent Syntax Query Expression)
    //   - Then order the presidents names by a self created ordening descending (Lambda Linq Dot Notation)
    //   - Show result (using the comparer information)
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - cpVowelConsonantRatioComparer()
    //   - ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)
    //   - ShowContentOfSequenceComparer(IOrderedEnumerable<cpPresident>, cpVowelConsonantRatioComparer, string)
    //   - string cpPresident.Name (Get)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IOrderedEnumerable<cpPresident> colResultComparerLambda;
      IOrderedEnumerable<cpPresident> colResultExpression;
      IOrderedEnumerable<cpPresident> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();

      colResultLambda = cpPresident.AllPresidents.OrderByDescending(aPresident => aPresident.Name.Length).ThenByDescending(aPresident => aPresident.Name);
      // ThenByDescending takes an input sequence and a keySelector delegate, and returns an object that, when enumerated,
      // enumerates throught the input source sequence passing each element to the keySelector method retrieving each key,
      // and orders in descending order the sequence using the key (in this example cpPresident)
      // On equal values, the order is stable, the order is maintained in the order the input sequence was
      // ThenByDescending is an extension method, so we use it on an instance of a sequence that is comparable (AllPresidents)

      ShowContentOfPresidentSequence(colResultLambda, "The list of the American Presidents names in order of length descending and then by name descending: (Lambda Linq Dot Notation)");

      colResultExpression = from aPresident in cpPresident.AllPresidents
                            orderby aPresident.Name.Length descending, aPresident.Name descending
                            select aPresident;

      Console.WriteLine();
      ShowContentOfPresidentSequence(colResultExpression, "The list of the American Presidents names in order of length descending and then by name descending: (Linq Fluent Syntax Query Expression)");

      cpVowelConsonantRatioComparer theComparer = new cpVowelConsonantRatioComparer();

      colResultComparerLambda = cpPresident.AllPresidents.OrderByDescending(aPresident => aPresident.Name.Length).ThenByDescending((aPresident => aPresident.Name), theComparer);
      // ThenByDescending takes an input sequence and a keySelector delegate, and returns an object that, when enumerated,
      // enumerates throught the input source sequence passing each element to the keySelector method retrieving each key,
      // and orders in descending order the sequence using the comparer (in this example theComparer)
      // On equal values, the order is stable, the order is maintained in the order the input sequence was
      // ThenByDescending is an extension method, so we use it on an instance of a sequence that is comparable (AllPresidents)

      Console.WriteLine();
      ShowContentOfSequenceComparer(colResultComparerLambda, theComparer, "The list of the American Presidents names in descending order by length and in descending order of the ratio between vowels and consonants: (Lambda Linq Dot Notation)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // OrderningOrderByDescendingThenByDescending()

    public static void OrderningOrderByThenBy()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Ordening operators return an output sequence of elements that is the input sequence in a specific order
    //     - The input sequence is of the form IEnumerable<T>
    //     - The output sequence is of the form IOrderedEnumerable<T>
    //     - The order is determined by a keySelector method
    //   - OrderBy has 2 overloads
    //     - Order the elements of a collection into a sequence using a keySelector delegate
    //     - Order the elements of a collection into a sequence using a keySelector delegate with a comparer
    //   - Fill the array with presidents
    //   - Order the presidents names shortest first (Lambda Linq Dot Notation)
    //   - Then order the presidents names alfabetic (Lambda Linq Dot Notation)
    //   - Show result 
    //   - Order the presidents names shortest first (Linq Fluent Syntax Query Expression)
    //   - Then order the presidents names alfabetic (Linq Fluent Syntax Query Expression)
    //   - Show result 
    //   - Create an instance of cpVowelConsonantRatioComparer (self created comparer)
    //     - Doing this allows me to use the methods in this class (displaying information)
    //   - Order the presidents names shortest first (Linq Fluent Syntax Query Expression)
    //   - Then order the presidents names by a self created ordening (Lambda Linq Dot Notation)
    //   - Show result (using the comparer information)
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - cpVowelConsonantRatioComparer()
    //   - ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)
    //   - ShowContentOfSequenceComparer(IOrderedEnumerable<cpPresident>, cpVowelConsonantRatioComparer, string)
    //   - string cpPresident.Name (Get)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IOrderedEnumerable<cpPresident> colResultComparerLambda;
      IOrderedEnumerable<cpPresident> colResultExpression;
      IOrderedEnumerable<cpPresident> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();

      colResultLambda = cpPresident.AllPresidents.OrderBy(aPresident => aPresident.Name.Length).ThenBy(aPresident => aPresident.Name);
      // ThenBy takes an input sequence and a keySelector delegate, and returns an object that, when enumerated,
      // enumerates throught the input source sequence passing each element to the keySelector method retrieving each key,
      // and orders in ascending order the sequence using the key (in this example cpPresident)
      // On equal values, the order is stable, the order is maintained in the order the input sequence was
      // ThenBy is an extension method, so we use it on an instance of a sequence that is comparable (AllPresidents)

      ShowContentOfPresidentSequence(colResultLambda, "The list of the American Presidents names in order of length: (Lambda Linq Dot Notation)");

      colResultExpression = from aPresident in cpPresident.AllPresidents
                            orderby aPresident.Name.Length, aPresident.Name
                            select aPresident;

      Console.WriteLine();
      ShowContentOfPresidentSequence(colResultExpression, "The list of the American Presidents names in order of length: (Linq Fluent Syntax Query Expression)");

      cpVowelConsonantRatioComparer theComparer = new cpVowelConsonantRatioComparer();

      colResultComparerLambda = cpPresident.AllPresidents.OrderBy(aPresident => aPresident.Name.Length).ThenBy((aPresident => aPresident.Name), theComparer);
      // ThenBy takes an input sequence and a keySelector delegate, and returns an object that, when enumerated,
      // enumerates throught the input source sequence passing each element to the keySelector method retrieving each key,
      // and orders in ascending order the sequence using the comparer (in this example theComparer)
      // On equal values, the order is stable, the order is maintained in the order the input sequence was
      // ThenBy is an extension method, so we use it on an instance of a sequence that is comparable (AllPresidents)

      Console.WriteLine();
      ShowContentOfSequenceComparer(colResultComparerLambda, theComparer, "The list of the American Presidents names in order of the ratio between vowels and consonants: (Lambda Linq Dot Notation)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // OrderningOrderByThenBy()

    public static void OrderningReverse()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Ordening operators return an output sequence of elements that is the input sequence in a specific order
    //     - The input sequence is of the form IEnumerable<T>
    //     - The output sequence has the same type
    //   - Reverse has 1 overload
    //     - Order the elements of a collection into a sequence starting with the last and going to the first
    //   - Fill the array with presidents
    //   - Reverse the presidents (Lambda Linq Dot Notation)
    //   - Show result 
    //   - Reverse the presidents (Linq Fluent Syntax Query Expression)
    //   - Show result 
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)
    //   - string cpPresident.Name (Get)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<string> colResultExpression;
      IEnumerable<string> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();

      colResultLambda = cpPresident.AllPresidents.Reverse().Select(aPresident => aPresident.Name) ;
      // Reverse takes an input sequence, and returns an object that, when enumerated,
      // enumerates throught the input source sequence passing each element in reverse order (in this example cpPresident)
      // Reverse is an extension method, so we use it on an instance of a sequence that is comparable (AllPresidents)

      ShowContentOfSequence(colResultLambda, "The list of the American Presidents names in reversed order: (Lambda Linq Dot Notation)");

      colResultExpression = from aPresident in cpPresident.AllPresidents.Reverse()
                            select aPresident.Name;

      Console.WriteLine();
      ShowContentOfSequence(colResultExpression, "The list of the American Presidents names in reversed order: (Linq Fluent Syntax Query Expression)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // OrderningReverse()

    private static void ShowContentOfPresidentSequence(IOrderedEnumerable<cpPresident> colSequence, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type cpPresident in a sequence
    // Called by
    //   - OrderningOrderBy()
    //   - OrderningOrderByDescending()
    //   - OrderningOrderByThenBy()
    //   - OrderningOrderByDescendingTheByDescending()
    // Calls
    //   - string cpPresident.Name() (Get)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine(strTitle);

      foreach (cpPresident aPresident in colSequence)
      {
        Console.WriteLine(aPresident.Name);
      }
      // in colSequence

    }
    // ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)

    private static void ShowContentOfSequence<T>(IEnumerable<T> colSequence, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type T in a sequence
    // Called by
    //   - OrderningReverse()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine(strTitle);

      foreach (T anElement in colSequence)
      {
        Console.WriteLine(anElement);
      }
      // in colSequence

    }
    // ShowContentOfSequence<T>(IEnumerable<T>, string)

    private static void ShowContentOfSequenceComparer(IOrderedEnumerable<cpPresident> colSequence, cpVowelConsonantRatioComparer aComparer, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type cpPresident in a sequence
    //     - Calculated the ratio between vowels and consonants (that is the comparer)
    //     - Write some info on the screen
    // Called by
    //   - OrderningOrderBy()
    //   - OrderningOrderByDescending()
    //   - OrderningOrderByThenBy()
    //   - OrderningOrderByDescendingTheByDescending()
    // Calls
    //   - string cpPresident.Name (Get)
    //   - cpVowelConsonantRatioComparer.GetVowelConsonantCount(string, °int, °int)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine(strTitle);

      foreach (cpPresident aPresident in colSequence)
      {
        int intConsonantCount = 0;
        int intVowelCount = 0;
        double dblRatio;

        aComparer.GetVowelConsonantCount(aPresident.Name, ref intVowelCount, ref intConsonantCount);

        if (intConsonantCount == 0)
        {
          dblRatio = 1;
        }
        // intConsonantCount <> 0
        else
        {
          dblRatio = intVowelCount / (double)intConsonantCount;
        }
        // intConsonantCount == 0

        Console.WriteLine("{0} - Ratio: {1:F4} - Vowels:Consonants = {2}:{3}", aPresident.Name, dblRatio, intVowelCount, intConsonantCount);
      }
      // in colSequence

    }
    // ShowContentOfSequenceComparer(IOrderedEnumerable<cpPresident>, cpVowelConsonantRatioComparer, string)

    public static void TryToExperiment()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Method used for experimenting
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      //  Do your stuff here

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // TryToExperiment()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion  

  }
  // cpProgram

}
// DeferredOperatorLinq