﻿//***
// Action
//   - Testroutine for cpDuck, cpMallardDuck, cpPlasticRubberDuck and cpRedHeadDuck
// Created
//   - CopyPaste – 20240717 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240717 – VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Game.Duck.Library;

namespace CopyPaste.Game.Duck.Test
{

	internal static class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		///  The main entry point for the test application
		/// </summary>
		public static void Main()
		//***
		// Action
		//   - Start application
		//   - Showing a text
		//   - Wait for the user to hit the keyboard
		// Called by
		//   - User action (Starting the application)
		// Calls
		//   - frmDuckGame()
		// Created
		//   - CopyPaste – 20240717 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240717 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			Console.WriteLine("Hello, duck test program");
			Console.ReadLine();
		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#Region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.Game.Duck.Test