//***
// Action
//   - Implementation of cpSecondShape
//     - Example, code has no functionality
// Created
//   - CopyPaste � 20240628 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240628 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;

namespace CopyPaste.Learning
{

  public class cpSecondShape : cpiShape
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Draw()
      //***
      // Action
      //   - Implemenation of drawing a shape
      //   - Showing it on the form
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // Draw() Implements cpiShape.Draw
      
    public void Reflect(int lngSlope, int lngIntercept)
      //***
      // Action
      //   - Implemenation of reflecting a shape
      //   - This mirrors the shape
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // Reflect(int, int) Implements cpiShape.Reflect
  
    public void Rotate(float fltDegrees)
      //***
      // Action
      //   - Implemenation of rotating a shape
      //   - This rotates the shape
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // Rotate(float) Implements cpiShape.Rotate
  
    public void Translate(int lngX, int lngY)
      //***
      // Action
      //   - Implemenation of translate a shape
      //   - This moves the shape by certain coordinates
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // Translate(int, int) Implements cpiShape.Translate

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpSecondShape

}
// CopyPaste.Learning