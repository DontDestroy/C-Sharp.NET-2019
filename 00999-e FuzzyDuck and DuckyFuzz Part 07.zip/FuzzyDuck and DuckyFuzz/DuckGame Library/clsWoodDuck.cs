﻿//***
// Action
//   - Implementation of a cpWoodDuck
//     - Inherits from cpDuck, where Display (how do I look like) is an abstract method
//       - All class that inherit from cpDuck must implement the Display method
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
//   - The way a cpWoodDuck moves on water is inherited
//     - All cpDuck and child classes moves on water the same way
//   - The sound that a cpWoodDuck makes is given thru a delegate and an event
//   - The way a cpWoodDuck moves on land is given thru a delegate and an event
//   - The way a cpWoodDuck moves in the air is given thru a delegate and an event
// Created
//   - CopyPaste – 20240725 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240725 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Animal.Library;
using System.Diagnostics;

namespace CopyPaste.Game.Duck.Library
{

	public class cpWoodDuck : cpDuck
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpWoodDuck
		/// </summary>
		public cpWoodDuck() : base()
		//***
		// Action
		//   - Basic constructor
		//   - Define how a cpWoodDuck flies (with wings)
		//   - Define how a cpWoodDuck makes some noise (quacking)
		//   - Define how a cpWoodDuck walks (with feet)
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - cpDuck()
		//   - cpFlyWithWings()
		//   - cpFlyWithWings.Fly()
		//   - cpQuack()
		//   - cpQuack.MakeNoise()
		//   - cpWalkWithFeet()
		//   - cpWalkWithFeet.Walk()
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			cpiFly cpHowToFly = new cpFlyWithWings();
			cpiMakeNoise cpHowToMakeNoise = new cpQuack();
			cpiWalk cpHowToWalk = new cpWalkWithFeet();

			PerformFly += new cpDelegateFly(cpHowToFly.Fly);
			PerformMakeNoise += new cpDelegateMakeNoise(cpHowToMakeNoise.MakeNoise);
			PerformWalk += new cpDelegateWalk(cpHowToWalk.Walk);
		}
		// cpWoodDuck()

			#endregion

			//#region "Designer"
			//#endregion

			//#region "Structures"
			//#endregion

			//#region "Fields"
			//#endregion

			//#region "Properties"
			//#endregion

			#region "Methods"

			#region "Overrides"

			/// <summary>
			/// The visualization (displaying) of a cpWoodDuck
			/// </summary>
		public override void Display()
		//***
		// Action
		//   - Define how a cpWoodDuck looks like
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Representation of a cpWoodDuck");
		}
		// Display()

		#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpWoodDuck

}
// CopyPaste.Game.Duck.Library