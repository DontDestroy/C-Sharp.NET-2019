﻿//***
// Action
//   - Demo of an Euro calculator
//     - Running a script
//     - Handling a calculation with a button, a linkbutton and an image button
// Created
//   - CopyPaste – 20260707 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260707 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmEuroCalculator : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.ibtConvert.Click += new System.Web.UI.ImageClickEventHandler(this.ibtConvert_Click);
      this.lbtConvert.Click += new System.EventHandler(this.cmdConvert_Click);
      this.cmdConvert.Click += new System.EventHandler(this.cmdConvert_Click);
      this.ID = "wfrmEuroCalculator";
    }
    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when initializing the page
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260707 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdConvert_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Execute a conversion
    // Called by
    //   - User action (Clicking a button)
    //   - User action (Clicking a linkbutton)
    // Calls
    //   - Conversion()
    // Created
    //   - CopyPaste – 20260707 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Conversion();
    }
    // cmdConvert_Click(System.Object, System.EventArgs) Handles cmdConvert.Click, lbtConvert.Click

    private void ibtConvert_Click(System.Object theSender, System.Web.UI.ImageClickEventArgs theImageClickEventArguments)
    //***
    // Action
    //   - Execute a conversion
    // Called by
    //   - User action (Clicking an image)
    // Calls
    //   - Conversion()
    // Created
    //   - CopyPaste – 20260707 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Conversion();
    }
    // ibtConvert_Click(System.Object, System.Web.UI.ImageClickEventArgs) Handles ibtConvert.Click

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - If the page is first time loaded
    //     - Create a view state item "intNumberOfConversions" with value 0
    //   - If not
    //     - Do nothing
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - SetFocus(Control)
    // Created
    //   - CopyPaste – 20260707 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (IsPostBack)
      {
      }
      else
      // Not IsPostBack
      {
        int intNumberOfConversions = 0;

        ViewState.Add("intNumberOfConversions", intNumberOfConversions);
      }
      // IsPostBack

      SetFocus(txtEuro);
    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void Conversion()
    //***
    // Action
    //   - Calculate a conversion
    //   - If information is valid
    //     - Convert the view state item "intNumberOfConversions" to an integer
    //     - Increment the number of conversions
    //     - Set the dollar text calculated
    //     - Set the conversions executed
    //     - Set the view state item "intNumberOfConversions" with the correct value
    //   - If not
    //     - Do nothing
    // Called by
    //   - Convert_Click(System.Object, System.EventArgs) Handles cmdConvert.Click, lbtConvert.Click
    //   - ibtConvert_Click(System.Object, System.Web.UI.ImageClickEventArgs) Handles ibtConvert.Click
    // Calls
    //   - SetFocus(Control)
    // Created
    //   - CopyPaste – 20260707 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (IsValid)
      {
        int intNumberOfConversions = Convert.ToInt32(ViewState["intNumberOfConversions"]);

        intNumberOfConversions += 1;
        txtDollar.Text = (Convert.ToDouble(txtEuro.Text) * 1.2).ToString();
        lblCountConversions.Text = "Count conversions: " + intNumberOfConversions.ToString();
        ViewState["intNumberOfConversions"] = intNumberOfConversions;
      }
      else
      // Not IsValid
      {
      }
      // IsValid

      SetFocus(txtEuro);
    }
    // Conversion()

    private void SetFocus(Control theControl)
    //***
    // Action
    //   - Define a script to set the focus to a given control
    // Called by
    //   - Conversion()
    //   - Page_Load(System.Object, System.EventArgs) Handles MyBase.Load
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260707 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strFocusScript =
      "<script language='javascript'>" +
      "document.getElementById('" + theControl.ClientID + "').focus()" +
      "</script>";

      Page.RegisterStartupScript("FocusScript", strFocusScript);
    }
    // SetFocus(Control)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmEuroCalculator

}
// CopyPaste.Learning