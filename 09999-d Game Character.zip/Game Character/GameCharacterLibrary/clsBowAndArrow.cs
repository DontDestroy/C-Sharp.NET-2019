﻿//***
// Action
//   - Implementation of a cpWeapon
//		 - The way a bow and arrow can be used
// Created
//   - CopyPaste – 20240806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240806 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Weapon.Library
{

	public class cpBowAndArrow : cpiWeapon
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpBowAndArrom
		/// </summary>
		public cpBowAndArrow()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - CopyPaste.Game.Character.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpBowAndArrow()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a Bow and Arrow is used in a fight
		/// </summary>
		public void UseWeapon()
		//***
		// Action
		//   - Define how a Bow and Arrow is used in a fight
		// Called by
		//   - cpKing() (indirectly, thru delegate)
		//   - cpKnight() (indirectly, thru delegate)
		//   - cpQueen() (indirectly, thru delegate)
		//   - cpTroll() (indirectly, thru delegate)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Shooting an arrow with a bow");
		}
		// UseWeapon()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpBowAndArrow

}
// CopyPaste.Game.Weapon.Library