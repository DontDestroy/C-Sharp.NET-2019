//***
// Action
//   -  Definition of a cpRotaryPhone
// Created
//   - CopyPaste � 20230817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230817 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpRotaryPhone : cpPhone
  {

    #region "Constructors / Destructors"

    public cpRotaryPhone(string strNumber) : base(strNumber)
      //***
      // Action
      //   - Constructor of a cpPhone
      //   - A given strNumber
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpPhone(string)
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpRotaryPhone(string)
    
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override void Dial()
      //***
      // Action
      //   - Simulation of the use of a rotary phone
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Rotary Dialing: " + mstrNumber);
    }
    // Dial()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpRotaryPhone 

}
// CopyPaste.Learning