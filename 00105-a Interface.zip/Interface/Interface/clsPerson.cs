//***
// Action
//   - Definition of cpPerson
//   - An implementation of cpiAgeAndName
// Created
//   - CopyPaste � 20230818 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230818 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpPerson : cpiAgeAndName
  {

    #region "Constructors / Destructors"

    public cpPerson(string strFirstName, string strLastName, int lngYearBorn)
      //***
      // Action
      //   - Constructor of cpPerson
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - FirstName(string) (Set)
      //   - LastName(string) (Set)
      //   - YearBorn(int) (Set)
      // Created
      //   - CopyPaste � 20230818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      FirstName = strFirstName;
      LastName = strLastName;
      YearBorn = lngYearBorn;
    }
    // cpPerson(string, string, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mlngYearBorn;
    private string mstrFirstName;
    private string mstrLastName;

    #endregion

    #region "Properties"

    public int Age
    {

      get
        //***
        // Action Get
        //   - Return the age of a cpPerson
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - int YearBorn (Get)
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - The calculation is an estimation and is not 100% correct
        //***
      {
        return DateTime.Now.Year - YearBorn;
      }
      // int Age (Get)

    }
    // int Age

    public string FirstName
    {

      get
        //***
        // Action Get
        //   - Return mstrFirstName
        // Called by
        //   - string Name (Get)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrFirstName;
      }
      // string FirstName (Get)

      set
        //***
        // Action Set
        //   - mstrFirstName becomes strValue
        // Called by
        //   - cpPerson(string, string, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrFirstName = value;
      }
      // FirstName(string) (Set)

    }
    // string FirstName

    public string LastName
    {

      get
        //***
        // Action Get
        //   - Return mstrLastName
        // Called by
        //   - string Name (Get)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrLastName;
      }
      // string LastName (Get)

      set
        //***
        // Action Set
        //   - mstrLastName becomes strValue
        // Called by
        //   - cpPerson(string, string, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrLastName = value;
      }
      // LastName(string) (Set)

    }
    // string LastName

    public string Name
    {

      get
        //***
        // Action Get
        //   - Return the firstname and lastname with a space in between
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - string FirstName (Get)
        //   - string LastName (Get)
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return FirstName + " " + LastName;
      }
      // string Name (Get)

    }
    // string Name

    public int YearBorn
    {

      get
        //***
        // Action Get
        //   - Return mlngYearBorn
        // Called by
        //   - int Age (Get)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngYearBorn;
      }
      // int YearBorn (Get)
      
      set
        //***
        // Action Set
        //   - If value is larger than zero and not in the future (next year or later)
        //     - mlngYearBorn becomes value
        //   - If not
        //     - mlngYearBorn becomes this year
        // Called by
        //   - cpPerson(string, string, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value > 0 && value <= DateTime.Now.Year)
        {
          mlngYearBorn = value;
        }
        else
          // (value <= 0 || value > DateTime.Now.Year)
        {
          mlngYearBorn = DateTime.Now.Year;
        }
        // (value > 0 && value <= DateTime.Now.Year)

      }
      // YearBorn(int) (Set)

    }
    // int YearBorn

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpPerson

}
// CopyPaste.Learning