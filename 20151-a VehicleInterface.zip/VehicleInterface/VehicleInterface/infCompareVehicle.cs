﻿//***
// Action
//   - Implementation of a compare of vehicles
// Created
//   - CopyPaste – 20260129 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260129 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public interface cpiCompareVehicle<T>
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    bool VehicleIdentificationNumberCheck(T theVehicle);
    // Check the vehicle identification number with the number of another vehicle (of type T)
    // cpCar.VehicleIdentificationNumberCheck(cpCar)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpiCompareVehicle

}
// CopyPaste.Learning