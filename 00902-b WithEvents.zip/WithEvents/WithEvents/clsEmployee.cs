﻿//***
// Action
//   - Definition of a cpEmployee
//     - Has a name
//     - An employee can do some maintenance on a cpCopyMachine
// Created
//   - CopyPaste – 20250716 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250716 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Material;
using System;

namespace CopyPaste.Learning
{

  namespace Personnel
  {

    public class cpEmployee
    {

      #region "Constructors / Destructors"

      public cpEmployee(string strName)
        //***
        // Action
        //   - Constructor with a given name
        // Called by
        //   - cpOfficeWorker(string)
        //   - cpProgram.Main()
        // Calls
        //   - Name(string) (Set)
        // Created
        //   - CopyPaste – 20250716 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250716 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        Name = strName;
      }
      // cpEmployee(string)

      #endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      #region "Fields"

      private string mstrName;

      #endregion

      #region "Properties"

      public string Name
      {

        get
          //***
          // Action Get
          //   - Returns mstrName
          // Called by
          //   - cpOfficeWorker.DoMaintenance(cpCopyMachine)
          //   - DoMaintenance(cpCopyMachine)
          // Calls
          //   - 
          // Created
          //   - CopyPaste – 20250716 – VVDW
          // Changed
          //   - CopyPaste – yyyymmdd – VVDW – What changed
          // Tested
          //   - CopyPaste – 20250716 – VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {
          return mstrName;
        }

        set
          //***
          // Action Set
          //   - mstrName becomes value
          // Called by
          //   - cpEmployee(string)
          // Calls
          //   - 
          // Created
          //   - CopyPaste – 20250716 – VVDW
          // Changed
          //   - CopyPaste – yyyymmdd – VVDW – What changed
          // Tested
          //   - CopyPaste – 20250716 – VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {
          mstrName = value;
        }
        // Name(string) (Set)

      }
      // string Name

      #endregion

      #region "Methods"

      //#region "Overrides"
      //#endregion

      //#region "Controls"
      //#endregion

      #region "Functionality"

      //#region "Event"
      //#endregion

      #region "Sub / Function"

      public virtual void DoMaintenance(cpCopyMachine cpErrorMachine)
        //***
        // Action
        //   - On a given machine there is a maintenance
        //   - Show who is doing the maintance, what is the cost per page and the number of pages that are runned
        // Called by
        //   - cpProgram.Main() (thru delegate)
        // Calls
        //   - decimal cpCopyMachine.Cost (Get)
        //   - int cpCopyMachine.NumberOfPages (Get)
        //   - int cpCopyMachine.NumberOfRuns (Get)
        //   - Name(string) (Set)
        // Created
        //   - CopyPaste – 20250716 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250716 – VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        Console.WriteLine("{0} checks machine that costs {1}/page after {2} pages ({3} runs).", Name, cpErrorMachine.Cost, cpErrorMachine.NumberOfPages, cpErrorMachine.NumberOfRuns);
      }
      // DoMaintenance(cpCopyMachine)

      #endregion

      #endregion

      #endregion

      //#region "Not used"
      //#endregion

    }
    // cpEmployee

  }
  // Personnel

}
// CopyPaste.Learning