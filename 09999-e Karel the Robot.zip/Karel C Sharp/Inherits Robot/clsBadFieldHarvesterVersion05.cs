﻿//***
// Action
//   - A definition of a bad field harvester
// Created
//   - CopyPaste – 20251020 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251020 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

  public class cpBadFieldHarvesterVersion05 : cpHarvesterVersion05
  {

    #region "Constructors / Destructors"

    public cpBadFieldHarvesterVersion05(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpBadFieldHarvesterVersion05 starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpBadFieldHarvesterVersion05(int, int, Directions.Direction, int)
    //   - cpRemoveBeepersVersion06MultipleRobots(int, int, Directions.Direction, int, Color) 
    // Calls
    //   - cpHarvesterVersion05(int, int, Directions.Direction, int)
    // Created
    //   - CopyPaste – 20251020 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251020 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpBadFieldHarvesterVersion05(int, int, Directions.Direction, int, Color) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override void HarvestCorner()
    //***
    // Action
    //   - Pick the beeper (if there is one)
    // Called by
    //   - HarvestOneRow()
    // Calls
    //   - cpHarvesterVersion05.HarvestCorner()
    // Created
    //   - CopyPaste – 20251020 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251020 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (nextToABeeper())
      {
        base.HarvestCorner();
      }
      // nextToABeeper()

    }
    // HarvestCorner()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBadFieldHarvesterVersion05

}
// cpKarelTheRobot