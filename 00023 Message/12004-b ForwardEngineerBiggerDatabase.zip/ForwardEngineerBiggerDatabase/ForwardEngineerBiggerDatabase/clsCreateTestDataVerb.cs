﻿//***
// Action
//   - Prepare the option "Create Database" for CommandLine Parser
// Created
//   - CopyPaste – 20230717 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230717 – VVDW
// Proposal (To Do)
//   -
//***

using CommandLine;
using CopyPaste.BusinessLayer;
using CopyPaste.DataAccess;
using CopyPaste.Toolkit;
using System;
using System.Collections.Generic;
using System.Text;


namespace ForwardEngineerBiggerDatabase
{

  [VerbAttribute("CreateTestData", HelpText = "Create test data for forward engineered database")]
  public class cpCreateTestDataVerb
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    [OptionAttribute('d', "DeleteDatabase", Default = false, HelpText = "Delete the existing database")]
    public bool DeleteDatabase { get; set; }

    [OptionAttribute('r', "RemoveData", Default = false, HelpText = "Remove the data from existing database")]
    public bool RemoveData { get; set; }

    [OptionAttribute('f', "FlightCount", Default = 0, HelpText = "Number of Flights to create")]
    public int FlightCount { get; set; } = 0;

    [OptionAttribute('p', "PassengerCount", Default = 0, HelpText = "Number of Passengers to create")]
    public int PassengerCount { get; set; } = 0;

    [OptionAttribute('i', "PilotCount", Default = 0, HelpText = "Number of Pilots to create")]
    public int PilotCount { get; set; } = 0;

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int CreateTestData(cpWingsContext theContext)
    //***
    // Action
    //   - Create the test data
    //     - First option "DeleteDatabase"
    //     - Second option "RemoveData"
    //     - Third option "FlightCount"
    //     - Fourth option "PassengerCount"
    //     - Fifth option "PilotCount"
    // Called by
    //   - int cpProgram.Main(string[])
    // Calls
    //   - bool DeleteDatabase (Get)
    //   - bool RemoveData (Get)
    //   - cpConsole.PrintError(string)
    //   - cpConsole.PrintSuccess(string)
    //   - cpDataGeneration.SeedData(cpWingsContext, bool = false, bool = false, int = 0, int = 0, int = 0)
    //   - int FlightCount (Get)
    //   - int PassengerCount (Get)
    //   - int PilotCount (Get)
    // Created
    //   - CopyPaste – 20230717 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230717 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpConsole.Print("Create Test Data");

      try
      {
        cpDataGeneration.SeedData(theContext, DeleteDatabase, RemoveData, PilotCount, FlightCount, PassengerCount);
        cpConsole.PrintSuccess("Create Test Data done!");
        return 0;
      }
      catch
      {
        cpConsole.PrintError("Create Test Data had errors!");
        return 1;
      }

    }
    // CreateTestData(cpWingsContext)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCreateTestDataVerb

}
// ForwardEngineerBiggerDatabase