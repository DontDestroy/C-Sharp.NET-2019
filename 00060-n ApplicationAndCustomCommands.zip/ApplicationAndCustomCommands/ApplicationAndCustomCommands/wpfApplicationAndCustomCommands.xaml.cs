﻿//***
// Action
//   - Activating a Custom Command
//   - Activating an Application Command
// Created
//   - CopyPaste – 20220906 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220906 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;
using System.Windows.Input;

namespace ApplicationAndCustomCommands
{

  public partial class wpfApplicationAndCustomCommands : Window
  {

    #region "Constructors / Destructors"

    public wpfApplicationAndCustomCommands()
    //***
    // Action
    //   - Create an instance of 'wpfApplicationAndCustomCommands'
    //   - Create a CommandBinding
    //   - Set the command for the CommandBinding
    //   - Link the action with the CommandBinding
    //   - Link the enabling of the action with the CommandBinding
    //   - Link the CommandBinding with the instance of the form
    //   - Create a CommandBinding
    //   - Create an Input Gesture
    //     - Add key combination Ctrl+Q to the Input Gesture (Ctrl+F is by default already linked to Find)
    //     - Add mouse + key combination Ctrl+WheelClick (turn the wheel, error in the .NET application) to the Input Gesture
    //   - Set the command for the CommandBinding
    //   - Link the action with the CommandBinding
    //   - Link the enabling of the action with the CommandBinding
    //   - Link the CommandBinding with the instance of the form
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - ApplicationCommandLaunchEnabledHandler(System.Object, System.Windows.Input.CanExecuteRoutedEventArgs)
    //   - ApplicationCommandLaunchHandler(System.Object, System.Windows.Input.ExecutedRoutedEventArgs)
    //   - CustomCommandLaunchEnabledHandler(System.Object, System.Windows.Input.CanExecuteRoutedEventArgs)
    //   - CustomCommandLaunchHandler(System.Object, System.Windows.Input.ExecutedRoutedEventArgs)
    //   - System.Windows.Input.RoutedUICommand cpCustomCommands.Launch (Get)
    // Created
    //   - CopyPaste – 20220906 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220906 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
      System.Windows.Input.CommandBinding aCommandBinding = new System.Windows.Input.CommandBinding();
      aCommandBinding.Command = cpCustomCommands.Launch;
      aCommandBinding.Executed += new System.Windows.Input.ExecutedRoutedEventHandler(CustomCommandLaunchHandler);
      aCommandBinding.CanExecute += new System.Windows.Input.CanExecuteRoutedEventHandler(CustomCommandLaunchEnabledHandler);
      this.CommandBindings.Add(aCommandBinding);

      System.Windows.Input.CommandBinding anApplicationCommandBinding = new System.Windows.Input.CommandBinding();
      ApplicationCommands.Find.InputGestures.Add(new KeyGesture(Key.Q, ModifierKeys.Control)); //Ctrl+F is also default connected to the find
      ApplicationCommands.Find.InputGestures.Add(new MouseGesture(MouseAction.WheelClick, ModifierKeys.Control));
      anApplicationCommandBinding.Command = ApplicationCommands.Find;
      anApplicationCommandBinding.Executed += new System.Windows.Input.ExecutedRoutedEventHandler(ApplicationCommandLaunchHandler);
      anApplicationCommandBinding.CanExecute += new System.Windows.Input.CanExecuteRoutedEventHandler(ApplicationCommandLaunchEnabledHandler);
      this.CommandBindings.Add(anApplicationCommandBinding);
    }
    // wpfApplicationAndCustomCommands()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void ApplicationCommandLaunchEnabledHandler(System.Object theSender, System.Windows.Input.CanExecuteRoutedEventArgs theCanExecuteRoutedEventArguments)
    //***
    // Action
    //   - Enabling the button, menu and Key combination
    // Called by
    //   - wpfApplicationAndCustomCommands()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220906 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220906 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      theCanExecuteRoutedEventArguments.CanExecute = (bool)chkEnabled.IsChecked;
    }
    // ApplicationCommandLaunchEnabledHandler(System.Object, System.Windows.Input.CanExecuteRoutedEventArgs)

    private void ApplicationCommandLaunchHandler(System.Object theSender, System.Windows.Input.ExecutedRoutedEventArgs theExecutedRoutedEventArguments)
    //***
    // Action
    //   - Show a message that the application command is handled
    //   - Set the handled property to true
    // Called by
    //   - wpfApplicationAndCustomCommands()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220906 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220906 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      MessageBox.Show("Application Command is Launched");
      theExecutedRoutedEventArguments.Handled = true;
    }
    // ApplicationCommandLaunchHandler(System.Object, System.Windows.Input.ExecutedRoutedEventArgs)

    private void CustomCommandLaunchEnabledHandler(System.Object theSender, System.Windows.Input.CanExecuteRoutedEventArgs theCanExecuteRoutedEventArguments)
    //***
    // Action
    //   - Enabling the button, menu and Key combination
    // Called by
    //   - wpfApplicationAndCustomCommands()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220906 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220906 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      theCanExecuteRoutedEventArguments.CanExecute = (bool)chkEnabled.IsChecked;
    }
    // CustomCommandLaunchEnabledHandler(System.Object, System.Windows.Input.CanExecuteRoutedEventArgs)

    private void CustomCommandLaunchHandler(System.Object theSender, System.Windows.Input.ExecutedRoutedEventArgs theExecutedRoutedEventArguments)
    //***
    // Action
    //   - Show a message that the custom command is handled
    // Called by
    //   - wpfApplicationAndCustomCommands()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220906 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220906 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      MessageBox.Show("Custom Command is Launched");
    }
    // CustomCommandLaunchHandler(System.Object, System.Windows.Input.ExecutedRoutedEventArgs)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfApplicationAndCustomCommands 

}
// ApplicationAndCustomCommands