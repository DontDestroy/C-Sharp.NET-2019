//***
// Action
//   - Show some operators and their results
//   - +, -, *, /, \, % and ^ (power)
// Created
//   - CopyPaste � 20240412 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240412 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Explanation of the code in this method
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240412 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240412 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("1 + 2 = " + (1 + 2));
      Console.WriteLine("3 - 4 = " + (3 - 4));
      Console.WriteLine("5 * 4 = " + (5 * 4));
      Console.WriteLine("25 / 4 = " + (25 / 4.0));
      Console.WriteLine("25 \\ 4 = " + (25 / 4));
      Console.WriteLine("25 Mod 4 = " + (25 % 4));
      Console.WriteLine("5 ^ 2 = " + (5 * 5));
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning