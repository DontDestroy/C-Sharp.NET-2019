﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmRequired.aspx.cs" Inherits="CopyPaste.Learning.wfrmRequired" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Required fields</title>
</head>
<body>
  <form id="wfrmRequired" method="post" runat="server">
    <asp:DropDownList ID="cmbChoose" Style="z-index: 101; position: absolute; top: 24px; left: 32px" runat="server"
      Width="136px">
      <asp:ListItem Value="Enter your choice">Enter your choice</asp:ListItem>
      <asp:ListItem Value="Mister">Mister</asp:ListItem>
      <asp:ListItem Value="Miss">Miss</asp:ListItem>
      <asp:ListItem Value="Misses">Misses</asp:ListItem>
    </asp:DropDownList>
    <asp:ValidationSummary ID="valsumRequired" Style="z-index: 127; position: absolute; top: 128px; left: 384px"
      runat="server" ShowMessageBox="True"></asp:ValidationSummary>
    <asp:CompareValidator ID="cmpvRepeatPassword" Style="z-index: 126; position: absolute; top: 192px; left: 320px"
      runat="server" ErrorMessage="The entered passwords must be equal" ControlToValidate="txtRepeatPassword"
      ControlToCompare="txtPassword">*</asp:CompareValidator>
    <asp:CompareValidator ID="cmpvBirthday" Style="z-index: 125; position: absolute; top: 224px; left: 208px"
      runat="server" ErrorMessage="This date is not valid" ControlToValidate="txtBirthday" Type="Date" Operator="DataTypeCheck">*</asp:CompareValidator>
    <asp:Label ID="lblBirthDay" Style="z-index: 120; position: absolute; top: 224px; left: 40px"
      runat="server">Birthday</asp:Label>
    <asp:TextBox ID="txtBirthday" Style="z-index: 119; position: absolute; top: 224px; left: 104px"
      runat="server" Width="96px" TabIndex="6"></asp:TextBox>
    <asp:Label ID="lblRepeatPassword" Style="z-index: 116; position: absolute; top: 192px; left: 40px"
      runat="server">Repeat Password</asp:Label>
    <asp:TextBox ID="txtRepeatPassword" Style="z-index: 114; position: absolute; top: 192px; left: 152px"
      runat="server" Width="160px" TextMode="Password" TabIndex="5"></asp:TextBox>
    <asp:CustomValidator ID="cstvPassword" Style="z-index: 118; position: absolute; top: 160px; left: 320px"
      runat="server" ErrorMessage="Password must be at least 8 characters long" ControlToValidate="txtPassword">*</asp:CustomValidator>
    <asp:RequiredFieldValidator ID="rfvPassword" Style="z-index: 117; position: absolute; top: 160px; left: 320px"
      runat="server" ErrorMessage="Password must be entered" ControlToValidate="txtPassword">*</asp:RequiredFieldValidator>
    <asp:Label ID="lblPassword" Style="z-index: 115; position: absolute; top: 160px; left: 40px"
      runat="server">Password</asp:Label>
    <asp:TextBox ID="txtPassword" Style="z-index: 113; position: absolute; top: 160px; left: 152px"
      runat="server" Width="160px" TextMode="Password" TabIndex="4"></asp:TextBox>
    <asp:RegularExpressionValidator ID="revEmail" Style="z-index: 112; position: absolute; top: 128px; left: 320px"
      runat="server" ErrorMessage="This is not a valid email address" ControlToValidate="txtEmail" ValidationExpression="(\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)">*</asp:RegularExpressionValidator>
    <asp:Label ID="lblEmail" Style="z-index: 111; position: absolute; top: 128px; left: 40px" runat="server">Email</asp:Label>
    <asp:TextBox ID="txtEmail" Style="z-index: 110; position: absolute; top: 128px; left: 96px" runat="server"
      Width="216px" TabIndex="3"></asp:TextBox>
    <asp:CompareValidator ID="cmpvNumberOfChildren" Style="z-index: 109; position: absolute; top: 96px; left: 208px"
      runat="server" ErrorMessage="Number must be greater than or equal to 0" ControlToValidate="txtNumberOfChildren"
      ValueToCompare="0" Type="Integer" Operator="GreaterThanEqual">*</asp:CompareValidator>
    <asp:RequiredFieldValidator ID="rfvNumberOfChildren" Style="z-index: 108; position: absolute; top: 96px; left: 208px"
      runat="server" ErrorMessage="The entered value must be a number" ControlToValidate="txtNumberOfChildren">*</asp:RequiredFieldValidator>
    <asp:Label ID="lblNumberOfChildren" Style="z-index: 107; position: absolute; top: 96px; left: 40px"
      runat="server">Number of children</asp:Label>
    <asp:TextBox ID="txtNumberOfChildren" Style="z-index: 105; position: absolute; top: 96px; left: 168px"
      runat="server" Width="32px" TabIndex="2"></asp:TextBox>
    <asp:Label ID="lblSuggest" Style="z-index: 124; position: absolute; top: 256px; left: 40px"
      runat="server">Suggestions</asp:Label>
    <asp:TextBox ID="txtSuggest" Style="z-index: 121; position: absolute; top: 256px; left: 120px"
      runat="server" Width="192px" TextMode="MultiLine" Rows="4" TabIndex="7"></asp:TextBox>
    <asp:Label ID="lblName" Style="z-index: 106; position: absolute; top: 64px; left: 40px" runat="server">Name</asp:Label>
    <asp:RequiredFieldValidator ID="rfvName" Style="z-index: 104; position: absolute; top: 64px; left: 256px" runat="server"
      Width="8px" ErrorMessage="Name must be filled in" ControlToValidate="txtName">*</asp:RequiredFieldValidator>
    <asp:TextBox ID="txtName" Style="z-index: 103; position: absolute; top: 64px; left: 96px; width: 142px;" runat="server"
      TabIndex="1"></asp:TextBox>
    <asp:Label ID="lblResult" Style="z-index: 123; position: absolute; top: 24px; left: 384px"
      runat="server" Width="320px"></asp:Label>
    <asp:Button ID="cmdMakeMember" Style="z-index: 122; position: absolute; top: 352px; left: 40px"
      runat="server" Text="Make member" TabIndex="8"></asp:Button>
    <asp:RequiredFieldValidator ID="rfvChoose" Style="z-index: 102; position: absolute; top: 24px; left: 176px"
      runat="server" ErrorMessage="You have to make a choice" ControlToValidate="cmbChoose" InitialValue="Enter your choice">*</asp:RequiredFieldValidator>
  </form>
</body>
</html>
