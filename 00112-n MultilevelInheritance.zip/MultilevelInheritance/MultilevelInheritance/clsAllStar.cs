//***
// Action
//   - Implementation of a cpAllStar
// Created
//   - CopyPaste � 20240529 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240529 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpAllStar : cpAthlete
  {

    #region "Constructors / Destructors"

    public cpAllStar(string strName, int lngAge, string strSport, string strTeam, double dblPoints, double dblRebounds) : base(strName, lngAge, strSport, strTeam)
      //***
      // Action
      //   - Create an instance of cpAllStar
      // Called by
      //   - cpPerson.Main()
      // Calls
      //   - cpAtlete(string, int, string, string)
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdblPointsPerGame = dblPoints;
      mdblRebounds = dblRebounds;
    }
    // cpAllStar(string, int, string, string, double, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public double mdblPointsPerGame;
    public double mdblRebounds;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Returns information about a cpAtlete
      // Called by
      //   - modMultiLevelInheritance.Main()
      // Calls
      //   - cpAthlete.ToString()
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strResult;

      strResult = base.ToString();
      strResult += "Points: " + mdblPointsPerGame + Environment.NewLine;
      strResult += "Rebounds: " + mdblRebounds + Environment.NewLine;

      return strResult;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpAllStar

}
// CopyPaste.Learning