<%@ Page Language="C#" %>

<%@ Import Namespace="System.Threading" %>

<html>
<head>
  <title>Multiple Threads</title>
</head>
<body>
  <script runat="server">

    void Display_A()
    {
      int intCounter;

      for (intCounter = 0; intCounter < 50; intCounter++)
      {
        Response.Write("AAAA<br/>");
      }

      Thread.Sleep(500);

      for (intCounter = 0; intCounter < 50; intCounter++)
      {
        Response.Write("AAAA<br/>");
      }

    }

    void Display_B()
    {
      int intCounter;

      for (intCounter = 0; intCounter < 50; intCounter++)
      {
        Response.Write("BBBB<br/>");
      }

      Thread.Sleep(100);

      for (intCounter = 0; intCounter < 50; intCounter++)
      {
        Response.Write("BBBB<br/>");
      }

    }

    void Display_C()
    {
      int intCounter;

      for (intCounter = 0; intCounter < 50; intCounter++)
      {
        Response.Write("CCCC<br/>");
      }

      Thread.Sleep(50);

      for (intCounter = 0; intCounter < 50; intCounter++)
      {
        Response.Write("CCCC<br/>");
      }

    }
  </script>

  <%

    Thread threadA;
    Thread threadB;
    Thread threadC;

    threadA = new Thread(new ThreadStart(Display_A));
    threadB = new Thread(new ThreadStart(Display_B));
    threadC = new Thread(new ThreadStart(Display_C));

    threadA.Start();
    threadB.Start();
    threadC.Start();
    threadA.Join();
    threadB.Join();
    threadC.Join();

  %>

</body>
</html>
