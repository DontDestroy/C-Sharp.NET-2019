//***
// Action
//   - Testroutine for cpEmployee, cpHandWorker, cpOfficeWorker, cpManager and cpDirector
// Created
//   - CopyPaste � 20240405 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240405 � VVDW
// Proposal (To Do)
//   - Not all getters and setters are tested, but the usual stuff is
//   - Pay attention, the result of the testroutine will be different if you do the extra exercises
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Instantiation of a cpDirector
      //   - Instantiation of a cpEmployee
      //   - Instantiation of a cpHandWorker
      //   - Instantiation of a cpManager
      //   - Instantiation of a cpOfficeWorker
      //   - Show information of a cpEmployee using ShowInfo
      //   - Show information of a cpEmployee using ToString
      //   - Show information about the data type of cpEmployee
      //   - Show information of a cpHandWorker using ShowInfo
      //   - Show information of a cpHandWorker using ToString
      //   - Show information about the data type of cpHandWorker
      //   - Show information of a cpOfficeWorker using ShowInfo
      //   - Show information of a cpOfficeWorker using ToString
      //   - Show information about the data type of cpOfficeWorker 
      //   - Show information of a cpManager using ShowInfo
      //   - Show information of a cpManager using ToString
      //   - Show information about the data type of cpManager
      //   - Show information of a cpDirector using ShowInfo
      //   - Show information of a cpDirector using ToString
      //   - Show information about the data type of cpDirector
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpDirector(string, string)
      //   - cpDirector.ShowInfo()
      //   - cpEmployee.ShowInfo()
      //   - cpHandWorker(string, string)
      //   - cpHandWorker.ShowInfo()
      //   - cpManager(string, string)
      //   - cpManager.ShowInfo()
      //   - cpOfficeWorker(string, string)
      //   - cpOfficeWorker.ShowInfo()
      //   - string cpDirector.ToString() 
      //   - string cpEmployee.ToString() 
      //   - string cpHandWorker.ToString()
      //   - string cpManager.ToString() 
      //   - string cpOfficeWorker.ToString() 
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      // cpEmployee thecpEmployee = new cpEmployee("Alfons");
      // This is impossible, you can't create a cpEmployee

      cpDirector theDirector = new cpDirector("Gertrude", "General");
      cpEmployee theEmployee;
      cpHandWorker theHandWorker = new cpHandWorker("Xavier", "Production");
      cpOfficeWorker theOfficeWorker = new cpOfficeWorker("Hilde", "Human Resources");
      cpManager theManager = new cpManager("Vincent", "Finance");

      theEmployee = new cpHandWorker("Alfons", "Transport");
      theEmployee.ShowInfo();
      Console.WriteLine(theEmployee.ToString());
      Console.WriteLine("Is Alfons employee? " + (theEmployee is cpEmployee));
      Console.WriteLine("Is Alfons handworker? " + (theEmployee is cpHandWorker));
      Console.WriteLine("Is Alfons officeworker? " + (theEmployee is cpOfficeWorker));
      Console.WriteLine("Is Alfons manager? " + (theEmployee is cpManager));
      Console.WriteLine("Is Alfons director? " + (theEmployee is cpDirector));
      Console.WriteLine();
      theHandWorker.ShowInfo();
      Console.WriteLine(theHandWorker.ToString());
      Console.WriteLine("Is Xavier employee? " + (theHandWorker is cpEmployee));
      Console.WriteLine("Is Xavier handworker? " + (theHandWorker is cpHandWorker));
      Console.WriteLine("Is Xavier officeworker? " + (theHandWorker is cpOfficeWorker));
      Console.WriteLine("Is Xavier manager? " + (theHandWorker is cpManager));
      Console.WriteLine("Is Xavier director? " + (theHandWorker is cpDirector));
      Console.WriteLine();
      theOfficeWorker.ShowInfo();
      Console.WriteLine(theOfficeWorker.ToString());
      Console.WriteLine("Is Hilde employee? " + (theOfficeWorker is cpEmployee));
      Console.WriteLine("Is Hilde handworker? " + (theOfficeWorker is cpHandWorker));
      Console.WriteLine("Is Hilde officeworker? " + (theOfficeWorker is cpOfficeWorker));
      Console.WriteLine("Is Hilde manager? " + (theOfficeWorker is cpManager));
      Console.WriteLine("Is Hilde director? " + (theOfficeWorker is cpDirector));
      Console.WriteLine();
      theManager.ShowInfo();
      Console.WriteLine(theManager);
      Console.WriteLine("Is Vincent employee? " + (theManager is cpEmployee));
      Console.WriteLine("Is Vincent handworker? " + (theManager is cpHandWorker));
      Console.WriteLine("Is Vincent officeworker? " + (theManager is cpOfficeWorker));
      Console.WriteLine("Is Vincent manager? " + (theManager is cpManager));
      Console.WriteLine("Is Vincent director? " + (theManager is cpDirector));
      Console.WriteLine();
      theDirector.ShowInfo();
      Console.WriteLine(theDirector);
      Console.WriteLine("Is Gertrude employee? " + (theDirector is cpEmployee));
      Console.WriteLine("Is Gertrude handworker? " + (theDirector is cpHandWorker));
      Console.WriteLine("Is Gertrude officeworker? " + (theDirector is cpOfficeWorker));
      Console.WriteLine("Is Gertrude manager? " + (theDirector is cpManager));
      Console.WriteLine("Is Gertrude director? " + (theDirector is cpDirector));
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning.Employee