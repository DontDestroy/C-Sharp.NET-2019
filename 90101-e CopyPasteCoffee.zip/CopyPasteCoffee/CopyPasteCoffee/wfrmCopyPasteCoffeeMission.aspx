﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCopyPasteCoffeeMission.aspx.cs" Inherits="CopyPaste.Learning.wfrmCopyPasteCoffeeMission" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/html">
<head runat="server">
  <title>Copy Paste Coffee's Mission</title>
  <style type="text/css">
    body {
      background-color: #d2b48c;
      margin-left: 20%;
      margin-right: 20%;
      border: 2px dotted black;
      padding: 10px 10px 10px 10px;
      font-family: sans-serif;
    }
  </style>
</head>
<body>
  <form id="wfrmCopyPasteCoffeeMission" runat="server">
    <h1>Copy Paste Coffee's Mission</h1>
    <p>To provide all the caffeine that you need to power your life.</p>
    <p>Just drink it.</p>
  </form>
</body>
</html>
