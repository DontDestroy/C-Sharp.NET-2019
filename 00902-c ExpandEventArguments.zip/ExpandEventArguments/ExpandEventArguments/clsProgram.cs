﻿//***
// Action
//   - Testroutine of cpHackerMonitor and cpMoreArguments
// Created
//   - CopyPaste – 20250716 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250716 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static cpHackerMonitor thecpHackerAlarm = new cpHackerMonitor();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private static void Attack(System.Object theObject, cpMoreArguments thecpArguments)
      // Action
      //   - Start the event that runs the attack routine
      //   - Notice that the code that must be runned is an event with 2 extra parameters
      // Called by
      //   - cpHackerMonitor.GenerateEvent() (thru raising events)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250716 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250716 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Hack Attack in progress");
      Console.WriteLine(thecpArguments.mstrMessage);
      Console.WriteLine(thecpArguments.mdtmTime);
    }
    // Attack(System.Object, cpMoreArguments) Handles thecpHackerAlarm.HackerAttack

    public static void Main()
      //***
      // Action
      //   - Start the event that runs the attack routine
      //   - Notice that the code that must be runned is an event with 2 extra parameters
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpMoreArguments(string, DateTime)
      //   - HackerAttack(System.Object, cpMoreArguments)
      //   - cpProgram.Attack(System.Object, cpMoreArguments)
      // Created
      //   - CopyPaste – 20250716 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250716 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      thecpHackerAlarm.HackerAttack += new cpHackerMonitor.cpDelegate(Attack);
      thecpHackerAlarm.GenerateEvent();
      Console.ReadLine();
    }
		// Main()

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning