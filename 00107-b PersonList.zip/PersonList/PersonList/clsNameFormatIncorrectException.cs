//***
// Action
//   - Definition of cpNameFormatIncorrectException
// Created
//   - CopyPaste � 20230821 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230821 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpNameFormatIncorrectException : ApplicationException
  {

    #region "Constructors / Destructors"

    public cpNameFormatIncorrectException() : base()
      //***
      // Action
      //   - Constructor of cpNameFormatIncorrectException with no parameters
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230821 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230821 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpNameFormatIncorrectException()

    public cpNameFormatIncorrectException(string strMessage) : base(strMessage)
      //***
      // Action
      //   - Constructor of cpNameFormatIncorrectException with a text as parameter
      // Called by
      //   - cpPerson(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230821 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230821 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpNameFormatIncorrectException(string)

    public cpNameFormatIncorrectException(string strMessage, Exception theInnerException) : base(strMessage, theInnerException)
      //***
      // Action
      //   - Constructor of cpNameFormatIncorrectException with a text and exception as parameters
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230821 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230821 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpNameFormatIncorrectException(string, Exception)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpNameFormatIncorrectException

}
// CopyPaste.Learning