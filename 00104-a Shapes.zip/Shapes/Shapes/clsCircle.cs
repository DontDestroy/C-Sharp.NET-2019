//***
// Action
//   - Definition of a cpCircle
// Created
//   - CopyPaste � 20230811 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230811 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpCircle : cpPoint
  {

    #region "Constructors / Destructors"

    public cpCircle() : base()
      //***
      // Action
      //   - Constructor of a cpCircle
      //   - The center of a circle is a cpCircle with radius 0 (and that is a cpPoint)
      //   - A cpCircle is a cpPoint, that is the reason it works
      // Called by
      //   - cpCylinder.New()
      // Calls
      //   - Center(cpPoint) (Set)
      //   - cpPoint()
      //   - Radius(double) (Set)
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Center = this;
      Radius = 0;
    }
    // cpCircle()

    public cpCircle(int lngX, int lngY, double dblRadius) : base(lngX, lngY)
      //***
      // Action
      //   - Constructor of a cpCircle using 2 coordinates and a radius
      //   - The center of a circle is a cpCircle (and that is a cpPoint)
      //   - A cpCircle is a cpPoint, that is the reason it works
      //   - The radius becomes dblRadius
      // Called by
      //   - cpCylinder.New(int, int, double, double)
      //   - cpProgram.Main()
      // Calls
      //   - Center(cpPoint) (Set)
      //   - cpPoint.New(Int32, Int32)
      //   - Radius(double) (Set)
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Center = this;
      Radius = dblRadius;
    }
    // cpCircle(int, int, double)

    public cpCircle(cpPoint thecpCenter, double dblRadius)
      //***
      // Action
      //   - Constructor of a cpCircle using a cpPoint and a radius
      //   - The center of a circle is a here a cpPoint, not a cpCircle like in the other constructors
      //   - The radius becomes dblRadius
      // Called by
      //   - cpCylinder.New(cpPoint, Double, Double)
      // Calls
      //   - Center(cpPoint) (Set)
      //   - Radius(double) (Set)
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Center = thecpCenter;
      Radius = dblRadius;
    }
    // cpCircle(cpPoint, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpPoint mcpCenter;
    private double mdblRadius;

    #endregion

    #region "Properties"

    public cpPoint Center 
    {

      get
        //***
        // Action Get
        //   - Return mcpCenter
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230811 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230811 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mcpCenter;
      }
      // cpPoint Center (Get)

      set
        //***
        // Action Set
        //   - The center becomes the point (cpValue)
        //   - Coordinate X becomes the X of the center
        //   - Coordinate Y becomes the Y of the center
        // Called by
        //   - cpCircle()
        //   - cpCircle(cpPoint, double)
        //   - cpCircle(int, int, double)
        // Calls
        //   - cpPoint.X(int) (Set)
        //   - cpPoint.Y(int) (Set)
        //   - int cpPoint.X (Get)
        //   - int cpPoint.Y() (Get)
        // Created
        //   - CopyPaste � 20230811 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230811 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mcpCenter = value;
        X = value.X;
        Y = value.Y;
      }
      // Center(cpPoint) (Set) 

    }
    // cpPoint Center 

    public override string Name
    {

      get
        //***
        // Action Get
        //   - Returns text "cpCircle"
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230811 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230811 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return "cpCircle";
      }
      // string Name (Get)

    }
    // string Name

    public double Radius
    {

      get
        //***
        // Action Get
        //   - Return mdblRadius
        // Called by
        //   - cpCylinder.Base(cpCircle) (Set)
        //   - double Area()
        //   - double Diameter()
        //   - string ToSTring()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230811 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230811 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdblRadius;
      }
      // cpPoint Center (Get)

      set
        //***
        // Action Set
        //   - If dblValue is larger than 0
        //     - mdblRadius becomes dblValue
        //   - If Not
        //     - mdblRadius becomes 0
        // Called by
        //   - cpCircle()
        //   - cpCircle(cpPoint, double)
        //   - cpCircle(int, int, double)
        //   - cpCylinder.Base(cpCircle) (Set)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230811 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230811 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value > 0)
        {
          mdblRadius = value;
        }
          // value <= 0
        else
        {
          mdblRadius = 0;
        }
        // value > 0

      }
      // Radius(double) (Set) 

    }
    // double Radius

    #endregion

    #region "Methods"

    #region "Overrides"

    public override double Area()
      //***
      // Action
      //   - Calculates the area of a cpCircle
      // Called by
      //   - double cpCylinder.Area()
      //   - double cpCylinder.Volume()
      // Calls
      //   - Radius() As Double (Get)
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Math.PI * Math.Pow(Radius, 2);
    }
    // double Area()

    public override string ToString()
      //***
      // Action
      //   - Shows information of a cpCircle
      // Called by
      //   - cpProgram.Main()
      //   - string cpCylinder.ToString()
      // Calls
      //   - cpPoint.ToString() As String
      //   - Radius() As Double (Get)
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "Center = " + base.ToString() + "; Radius = " + Radius;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public double Circumference()
      //***
      // Action
      //   - Calculates the circumference of a cpCircle
      // Called by
      //   - double cpCylinder.Area()
      // Calls
      //   - double Diameter()
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Math.PI * Diameter();
    }
    // double Circumference()

    public double Diameter()
      //***
      // Action
      //   - Calculates the diameter of a cpCircle
      // Called by
      //   - double Circumference()
      // Calls
      //   - double Radius (Get)
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Radius * 2;
    }
    // double Circumference()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCircle

}
// CopyPaste.Learning