//***
// Action
//   - If ... Then [... ElseIf ... Then ]... Else ... End If
// Created
//   - CopyPaste � 20220119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220119 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace If
{

  class cpIf
	{

    static void Main()
    //***
    // Action
    //   - Define a variable (lngTestScore)
    //   - Depending on value of variable, show correct test grade
    //   - Define a variable (strLanguage)
    //   - Depending on value of variable, show correct greeting
    //   - Depending on actual hour, show correct greeting
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application) 
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(String)
    //   - int System.DateTime.Now.Hour() 
    // Created
    //   - CopyPaste � 20220119 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220119 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngTestScore = 80;

      if (lngTestScore >= 90)
      {
        Console.WriteLine("Test grade: A");
      }
      else if (lngTestScore >= 80)
        // lngTestScore < 90
      {
        Console.WriteLine("Test grade: B");
      }
      else if (lngTestScore >= 70)
        // lngTestScore < 80
      {
        Console.WriteLine("Test grade: C");
      }
      else
        // lngTestScore < 70
      {
        Console.WriteLine("Test grade: F");
      }
      // lngTestScore >= 90
      // lngTestScore >= 80
      // lngTestScore >= 70
      
      string strLanguage = "English";
      
      if (strLanguage == "English")
      {
        Console.WriteLine("Hello, world!");
      }
      else if (strLanguage == "Spanish")
        // strLanguage <> "English"
      {
        Console.WriteLine("Hola, mundo");
      }
      else
        // strLanguage <> "English"
        // strLanguage <> "Spanish"
      {
      }
      // strLanguage == "English"
      // strLanguage == "Spanish"

      if (DateTime.Now.Hour < 12)
      {
        Console.WriteLine("Good morning");
      }
      else if (DateTime.Now.Hour < 18)
        // DateTime.Now.Hour > 12
      {
        Console.WriteLine("Good day");
      }
      else
        // DateTime.Now.Hour > 18
      {
        Console.WriteLine("Good evening");
      }
      // DateTime.Now.Hour < 12
      // DateTime.Now.Hour < 18
      
      Console.ReadLine();
    }
    // Main()

  }
  // cpIf

}
// If