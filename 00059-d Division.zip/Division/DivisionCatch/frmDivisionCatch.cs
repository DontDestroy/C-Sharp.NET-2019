//***
// Action
//   - A solution for the exercise for handling a division by zero
// Created
//   - CopyPaste � 20240518 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240518 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDivisionCatch: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdCalculateResult;
    internal System.Windows.Forms.Label lblRemainder;
    internal System.Windows.Forms.Label lblDenominator;
    internal System.Windows.Forms.Label lblNumberator;
    internal System.Windows.Forms.TextBox txtRemainder;
    internal System.Windows.Forms.TextBox txtDenominator;
    internal System.Windows.Forms.TextBox txtNumerator;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDivisionCatch));
      this.cmdCalculateResult = new System.Windows.Forms.Button();
      this.lblRemainder = new System.Windows.Forms.Label();
      this.lblDenominator = new System.Windows.Forms.Label();
      this.lblNumberator = new System.Windows.Forms.Label();
      this.txtRemainder = new System.Windows.Forms.TextBox();
      this.txtDenominator = new System.Windows.Forms.TextBox();
      this.txtNumerator = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdCalculateResult
      // 
      this.cmdCalculateResult.Location = new System.Drawing.Point(80, 200);
      this.cmdCalculateResult.Name = "cmdCalculateResult";
      this.cmdCalculateResult.Size = new System.Drawing.Size(104, 23);
      this.cmdCalculateResult.TabIndex = 13;
      this.cmdCalculateResult.Text = "Calculate Result";
      this.cmdCalculateResult.Click += new System.EventHandler(this.cmdCalculateResult_Click);
      // 
      // lblRemainder
      // 
      this.lblRemainder.Location = new System.Drawing.Point(16, 136);
      this.lblRemainder.Name = "lblRemainder";
      this.lblRemainder.Size = new System.Drawing.Size(88, 23);
      this.lblRemainder.TabIndex = 11;
      this.lblRemainder.Text = "Remainder";
      // 
      // lblDenominator
      // 
      this.lblDenominator.Location = new System.Drawing.Point(16, 88);
      this.lblDenominator.Name = "lblDenominator";
      this.lblDenominator.Size = new System.Drawing.Size(88, 23);
      this.lblDenominator.TabIndex = 9;
      this.lblDenominator.Text = "Denominator";
      // 
      // lblNumberator
      // 
      this.lblNumberator.Location = new System.Drawing.Point(16, 32);
      this.lblNumberator.Name = "lblNumberator";
      this.lblNumberator.Size = new System.Drawing.Size(88, 23);
      this.lblNumberator.TabIndex = 7;
      this.lblNumberator.Text = "Numerator";
      // 
      // txtRemainder
      // 
      this.txtRemainder.Location = new System.Drawing.Point(112, 136);
      this.txtRemainder.Name = "txtRemainder";
      this.txtRemainder.TabIndex = 12;
      this.txtRemainder.Text = "";
      // 
      // txtDenominator
      // 
      this.txtDenominator.Location = new System.Drawing.Point(112, 88);
      this.txtDenominator.Name = "txtDenominator";
      this.txtDenominator.TabIndex = 10;
      this.txtDenominator.Text = "";
      // 
      // txtNumerator
      // 
      this.txtNumerator.Location = new System.Drawing.Point(112, 32);
      this.txtNumerator.Name = "txtNumerator";
      this.txtNumerator.TabIndex = 8;
      this.txtNumerator.Text = "";
      // 
      // frmDivisionCatch
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdCalculateResult);
      this.Controls.Add(this.lblRemainder);
      this.Controls.Add(this.lblDenominator);
      this.Controls.Add(this.lblNumberator);
      this.Controls.Add(this.txtRemainder);
      this.Controls.Add(this.txtDenominator);
      this.Controls.Add(this.txtNumerator);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDivisionCatch";
      this.Text = "Division Catch";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDivisionCatch'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDivisionCatch()
      //***
      // Action
      //   - Create instance of 'frmDivisionCatch'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDivision()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCalculateResult_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If the numerator is not filled in
      //     - Show an error
      //   - If not
      //     - If the denomerator is not filled in
      //       - Show an error
      //     - If not
      //       - Try
      //         - Convert both texts into numbers
      //         - Try
      //           - Divide them and calculate the remainder
      //           - Show the remainder
      //         - When it fails by division by zero
      //           - Show a message that division by zero is not possible
      //           - Show "Infinity" as remainder
      //       - When it fails by overflow
      //         - Show that the number is too large
      //           - Show "Impossible" as remainder
      //       - When it fails by format
      //         - Show that the number is not a number
      //           - Show "Impossible" as remainder
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (txtNumerator.Text.Length == 0)
      {
        MessageBox.Show("Must specify numerator");
      }
      else if (txtDenominator.Text.Length == 0)
        // txtNumerator.Text.Length <> 0
      {
        MessageBox.Show("Must specify denominator");
      }
      else
        // txtDenominator.Text.Length <> 0
      {
        int lngNumerator;
        int lngDenominator;
        int lngRemainder;

        try
        {
          lngNumerator = Convert.ToInt32(txtNumerator.Text);
          lngDenominator = Convert.ToInt32(txtDenominator.Text);

          try
          {
            lngRemainder = lngNumerator % lngDenominator;
            txtRemainder.Text = lngRemainder.ToString();
          }
          catch (DivideByZeroException theDivideByZeroException)
          {
            MessageBox.Show("Error: Division by zero is not possible", "Copy Paste");
            txtRemainder.Text = "Infinity";
          }

        }

        catch (OverflowException theOverflowException)
        {
          MessageBox.Show("Error: Number is to large to fit into integer", "Copy Paste");
          txtRemainder.Text = "Impossible";
        }
        catch (FormatException theFormatException)
        {
          MessageBox.Show("Error: Entered text is not a number", "Copy Paste");
          txtRemainder.Text = "Impossible";
        }

      }
      // txtNumerator.Text.Length = 0
      // txtDenominator.Text.Length = 0
    
    }
    // cmdCalculateResult_Click(System.Object, System.EventArgs) Handles cmdCalculateResult.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDivisionCatch
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDivisionCatch()
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDivisionCatch());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDivisionCatch

}
// CopyPaste.Learning