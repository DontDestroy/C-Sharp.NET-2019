//***
// Action
//   - Show a customer (used a a test form)
// Created
//   - CopyPaste � 20260117 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260117 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmCustomerTryout: ifrmCustomerTryout
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCustomerTryout));
      // 
      // cmdNew
      // 
      this.cmdNew.Name = "cmdNew";
      // 
      // cmdDelete
      // 
      this.cmdDelete.Name = "cmdDelete";
      // 
      // cmdSave
      // 
      this.cmdSave.Name = "cmdSave";
      // 
      // cmdRetrieve
      // 
      this.cmdRetrieve.Name = "cmdRetrieve";
      // 
      // txtFax
      // 
      this.txtFax.Name = "txtFax";
      // 
      // txtPhone
      // 
      this.txtPhone.Name = "txtPhone";
      // 
      // txtRegion
      // 
      this.txtRegion.Name = "txtRegion";
      // 
      // txtCountry
      // 
      this.txtCountry.Name = "txtCountry";
      // 
      // txtZip
      // 
      this.txtZip.Name = "txtZip";
      // 
      // txtCity
      // 
      this.txtCity.Name = "txtCity";
      // 
      // txtAddress
      // 
      this.txtAddress.Name = "txtAddress";
      // 
      // txtContactTitle
      // 
      this.txtContactTitle.Name = "txtContactTitle";
      // 
      // txtIdCustomer
      // 
      this.txtIdCustomer.Name = "txtIdCustomer";
      // 
      // txtContactName
      // 
      this.txtContactName.Name = "txtContactName";
      // 
      // txtCompanyName
      // 
      this.txtCompanyName.Name = "txtCompanyName";
      // 
      // frmCustomer
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(688, 325);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCustomer";
      this.Load += new System.EventHandler(this.frmCustomerTryout_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmCustomerTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - ifrmCustomerTryout.Dispose(bool)
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmCustomerTryout() : base()
      //***
      // Action
      //   - Create new instance of 'frmCustomerTryout'
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCustomerTryout()
      //   - ifrmCustomerTryout()
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
    }
    // frmCustomerTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void TextBoxChange(string strProperty, string strValue)
      //***
      // Action
      //   - Try to
      //     - Depending on the textbox (property)
      //       - Fill the corresponding property of the customer instance (linked to the form)
      //     - Fill the rich text box with the customer info (ToString())
      //   - When there is no cpCustomer instance
      //     - Do nothing
      //   - When other exception
      //     - Show exception message
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCustomerTryout.Address(string) (Set)
      //   - cpCustomerTryout.City(string) (Set)
      //   - cpCustomerTryout.CompanyName(string) (Set)
      //   - cpCustomerTryout.ContactName(string) (Set)
      //   - cpCustomerTryout.ContactTitle(string) (Set)
      //   - cpCustomerTryout.Country(string) (Set)
      //   - cpCustomerTryout.Fax(string) (Set)
      //   - cpCustomerTryout.Phone(string) (Set)
      //   - cpCustomerTryout.Region(string) (Set)
      //   - cpCustomerTryout.PostalCode(string) (Set)
      //   - string cpCustomerTryout.ToString()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // TextBoxChange(string, string)
  
    #endregion

    #region "Controls"

    private void frmCustomerTryout_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Fill dummy data to the form
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmCustomerTryout_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmCustomerTryout

}
// CopyPaste.Learning