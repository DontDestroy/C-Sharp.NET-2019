//***
// Action
//   - Demo of a StringBuilder
// Created
//   - CopyPaste � 20240414 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240414 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Text;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Do some string manipulations with a string builder
      //   - Do some string manipulations (the same) with a string
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - ManipulateStringBuilder()
      //   - ManipulateString()
      // Created
      //   - CopyPaste � 20240414 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240414 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      ManipulateStringBuilder();
      ManipulateString();
      Console.WriteLine();
      Console.WriteLine("Hit Enter");
      Console.ReadLine();
    }
    // Main()
		
    public static void ManipulateStringBuilder()
      //***
      // Action
      //   - Get the start ticks
      //   - Create a StringBuilder
      //   - Append the alphabet to it
      //   - Loop 2.000.000 times
      //     - Change the first character to "a"
      //     - Change the fifth character to "e"
      //     - Insert at position 10 "XXX"
      //     - Append "aBCDe"
      //     - Replace all "aBCDe" into "ABCDE"
      //     - Remove at poistion 10 3 characters
      //     - Remove at the end 5 characters
      //   - Get the end ticks
      //   - Calculated the number of ticks needed
      //   - Show the result
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240414 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240414 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngCounter;
      long lngStartTicks = DateTime.Now.Ticks;
      StringBuilder strBuild = new StringBuilder(26);

      strBuild.Append("ABCDEFGHIJKLMNOPQRSTUVWYZ");

      for (lngCounter = 0; lngCounter < 2000000; lngCounter++)
      {
        strBuild[0] = 'a';
        strBuild[4] = 'e';
        strBuild.Insert(10, "XXX");
        strBuild.Append("aBCDe");
        strBuild.Replace("aBCDe", "ABCDE");
        strBuild.Remove(10, 3);
        strBuild.Remove(strBuild.Length - 5, 5);
      }
      // lngCounter = 2.000.001

      long lngEndTicks = DateTime.Now.Ticks;
      long lngTicks = lngEndTicks - lngStartTicks;

      Console.WriteLine("StringBuilder required: " + lngTicks.ToString("#,##0") + " ticks");
      Console.WriteLine("Ending StringBuilder: " + strBuild.ToString());
    }
    // ManipulateStringBuilder()

    public static void ManipulateString()
      //'***
      //' Action
      //'   - Get the start ticks
      //'   - Create a StringBuilder
      //'   - Append the alphabet to it
      //'   - Loop 2.000.000 times
      //'     - Change the first character to "a"
      //'     - Change the fifth character to "e"
      //'     - Insert at position 10 "XXX"
      //'     - Append "aBCDe"
      //'     - Replace all "aBCDe" into "ABCDE"
      //'     - Remove at poistion 10 3 characters
      //'     - Remove at the end 5 characters
      //'   - Get the end ticks
      //'   - Calculated the number of ticks needed
      //'   - Show the result
      //' Called by
      //'   - Main()
      //' Calls
      //'   - 
      //' Created
      //'   - CopyPaste � 20240414 � VVDW
      //' Changed
      //'   - CopyPaste � yyyymmdd � VVDW � What changed
      //' Tested
      //'   - CopyPaste � 20240414 � VVDW
      //' Keyboard key
      //'   - 
      //' Proposal (To Do)
      //'   - 
      //'***
    {
      int lngCounter;
      long lngStartTicks = DateTime.Now.Ticks;
      string strText = "ABCDEFGHIJKLMNOPQRSTUVWYZ";

      for (lngCounter = 0; lngCounter < 2000000; lngCounter++)
      {
        strText = strText.Replace("A", "a");
        strText = strText.Replace("E", "e");
        strText = strText.Insert(10, "XXX");
        strText += "aBCDe";
        strText = strText.Replace("aBCDe", "ABCDE");
        strText = strText.Remove(10, 3);
        strText = strText.Remove(strText.Length - 5, 5);
      }
      // lngCounter = 2.000.001

      long lngEndTicks = DateTime.Now.Ticks;
      long lngTicks = lngEndTicks - lngStartTicks;

      Console.WriteLine();
      Console.WriteLine("String required: " + lngTicks.ToString("#,##0") + " ticks");
      Console.WriteLine("Ending String: " + strText);
    }
    // ManipulateString()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning