﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmInteractivity.aspx.cs" Inherits="CopyPaste.Learning.wfrmInteractivity" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Interactivity</title>
  <script>

    window.onload = Initialize;

    function BidValidation() {

      if (document.getElementById("txtBitAmount").value > 0) {
        document.getElementById("wfrmInteractivity").submit();
      }
      else {
        return false;
      }

    }

    function Initialize() {
      var submitButton = document.getElementById("cmdSubmit");
      submitButton.onclick = BidValidation;
    }

  </script>
</head>
<body>
  <!-- form id="wfrmInteractivity" method="post" action="action.php" -->
  <form id="wfrmInteractivity" action="wfrmInteractivityAnswer.aspx" method="post">
    <input type="number" id="txtBitAmount" name="bitAmount" value="0">
    <input type="submit" id="cmdSubmit" value="Bid!">
    <br>
  </form>
</body>
</html>
