﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmSeattleShuffle.aspx.cs" Inherits="CopyPaste.Learning.wfrmSeattleShuffle" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>myPod: iPod Shuffle</title>
  <style type="text/css">
    body {
      background-color: #eaf3da;
    }
  </style>
</head>
<body>
  <form id="wfrmSeattleShuffle" runat="server">
    <h1>iPod Shuffle in Seattle</h1>
    <p>
      <img src="../Resources/Seattle_Shuffle.jpg" alt="An iPod shuffle in Seattle" />
    </p>
  </form>
</body>
</html>
