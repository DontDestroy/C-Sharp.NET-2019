//***
// Action
//   - TestRoutine for cpBook and cpSoftware
// Created
//   - CopyPaste � 20240710 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240710 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Reflection;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void LateBinding(System.Object theObject)
      //***
      // Action
      //   - Show the values of the object (it can be a cpBook or cpSoftware)
      //   - Get the type of theObject
      //   - Define the method you want to execute
      //   - Create an instance of the same type of the object
      //   - Invoke the method
      // Called by
      //   - Main()
      // Calls
      //   - cpBook.ShowValues() (indirectly)
      //   - cpSoftware.ShowValues() (indirectly)
      // Created
      //   - CopyPaste � 20240710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MethodInfo theMethodInfo; 
      Type theType;

      theType = theObject.GetType();
      theMethodInfo = theType.GetMethod("ShowValues");

      System.Object theInstance = Activator.CreateInstance(theType);
      theInstance = theObject;

      theMethodInfo.Invoke(theInstance, null);
    }
    // LateBinding(System.Object)

    public static void Main()
      //***
      // Action
      //   - Initialize a cpBook
      //   - Initialize a cpSoftware
      //   - Show the values of the book
      //   - Show the values of the software
      //   - Show the values of the book indirectly
      //   - Show the values of the software indirectly
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpBook(string, string, string, double)
      //   - cpBook.ShowValues()
      //   - cpSoftware(string, string, string, double)
      //   - cpSoftware.ShowValues()
      //   - LateBinding(System.Object)
      // Created
      //   - CopyPaste � 20240710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBook theComputerBook = new cpBook("ASP.NET", "Smith", "Osborne", 49.99);
      cpSoftware theGameProgram = new cpSoftware("Avenger", "Jones", "GameCO", 29.99);

      theComputerBook.ShowValues();
      Console.WriteLine();
      theGameProgram.ShowValues();
      Console.WriteLine();

      LateBinding(theGameProgram);
      Console.WriteLine();
      LateBinding(theComputerBook);

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning