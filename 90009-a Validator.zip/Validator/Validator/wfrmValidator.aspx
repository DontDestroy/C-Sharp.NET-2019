﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmValidator.aspx.cs" Inherits="CopyPaste.Learning.wfrmValidator" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Validator</title>
</head>
  <body MS_POSITIONING="GridLayout">
    <form id="wfrmValidator" method="post" runat="server">
      <asp:calendar id="calSelectDay" style="Z-INDEX: 100; POSITION: absolute; TOP: 16px; LEFT: 16px"
        runat="server" Width="263px"></asp:calendar>
      <asp:customvalidator id="cstvalDateSelected" style="Z-INDEX: 111; POSITION: absolute; TOP: 216px; LEFT: 296px"
        runat="server" ControlToValidate="txtSelectedDay"></asp:customvalidator>
      <asp:validationsummary id="valsumDateSelected" style="Z-INDEX: 110; POSITION: absolute; TOP: 72px; LEFT: 296px"
        runat="server"></asp:validationsummary>
      <asp:rangevalidator id="rgvDateSelected" style="Z-INDEX: 109; POSITION: absolute; TOP: 40px; LEFT: 296px"
        runat="server" ControlToValidate="txtSelectedDayMonthFormat" Type="Date"></asp:rangevalidator>
      <asp:comparevalidator id="cmpvDateSelectedTo" style="Z-INDEX: 108; POSITION: absolute; TOP: 16px; LEFT: 296px"
        runat="server" ControlToValidate="txtSelectedDayMonthFormat" Operator="LessThanEqual" Type="Date"></asp:comparevalidator>
      <asp:comparevalidator id="cmpvDateSelectedFrom" style="Z-INDEX: 107; POSITION: absolute; TOP: 16px; LEFT: 296px"
        runat="server" ControlToValidate="txtSelectedDayMonthFormat" Operator="GreaterThanEqual" Type="Date"></asp:comparevalidator>
      <asp:comparevalidator id="cmpvDateSelected" style="Z-INDEX: 106; POSITION: absolute; TOP: 16px; LEFT: 296px"
        runat="server" ErrorMessage="The entered text is not a date" Operator="DataTypeCheck" Type="Date" ControlToValidate="txtSelectedDayMonthFormat"></asp:comparevalidator>
      <asp:regularexpressionvalidator id="revDateSelected" style="Z-INDEX: 105; POSITION: absolute; TOP: 16px; LEFT: 296px"
        runat="server" ErrorMessage="Date must have format dd/mm/yyyy or dd-mm-yyyy" ControlToValidate="txtSelectedDay"
        ValidationExpression="^\d{1,2}(\-|\/|\.)\d{1,2}\1\d{4}$"></asp:regularexpressionvalidator>
      <asp:requiredfieldvalidator id="rfvDateSelected" style="Z-INDEX: 104; POSITION: absolute; TOP: 16px; LEFT: 296px"
        runat="server" ErrorMessage="A date is required" ControlToValidate="txtSelectedDayMonthFormat"></asp:requiredfieldvalidator>
      <asp:Button id="cmdOK" style="Z-INDEX: 103; POSITION: absolute; TOP: 248px; LEFT: 16px" runat="server"
        Text="OK" Width="265px"></asp:Button>
      <asp:TextBox id="txtSelectedDay" style="Z-INDEX: 101; POSITION: absolute; TOP: 216px; LEFT: 16px"
        runat="server" Width="265px"></asp:TextBox>
      <asp:TextBox id="txtSelectedDayMonthFormat" style="Z-INDEX: 112; POSITION: absolute; TOP: 216px; LEFT: 440px"
        runat="server" Width="224px" Visible="False"></asp:TextBox></form>
  </body>
</html>
