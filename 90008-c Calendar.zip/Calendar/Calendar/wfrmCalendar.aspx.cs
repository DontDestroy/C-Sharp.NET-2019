﻿//***
// Action
//   - Demo of a Calendar Web Control
// Created
//   - CopyPaste – 20260618 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260618 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmCalendar: System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.calDate.SelectionChanged += new System.EventHandler(this.calDate_SelectionChanged);
      this.ID = "wfrmCalendar";
      this.Load += new System.EventHandler(this.Page_Load);
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when initializing the page
    //   - Make sure the active date is today
    //   - Make sue that teh selected date is visible
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260618 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260618 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
      calDate.SelectedDate = DateTime.Today;
      calDate.VisibleDate = this.calDate.SelectedDate;
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void calDate_SelectionChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Clear the items from the list box
    //   - Show the selected date in Dutch format as text
    //   - For every date in selected dates
    //     - Add the selected date in Dutch format to the list box
    // Called by
    //   - User action (Selecting a date or a range of dates)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260618 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260618 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      lstDataSelected.Items.Clear();
      lblDate.Text = calDate.SelectedDate.ToString("dd/MM/yyyy");

      foreach (DateTime theDate in calDate.SelectedDates)
      {
        lstDataSelected.Items.Add(theDate.ToString("dd/MM/yyyy"));
      }
      // in calDate.SelectedDates

    }
    // calDate_SelectionChanged(System.Object, System.EventArgs)

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when the page is loaded
    //   - Listbox is visible depending on IsPostBack
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260618 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260618 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lstDataSelected.Visible = IsPostBack;
      calDate_SelectionChanged(theSender, theEventArguments);
    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmCalendar

}
// CopyPaste.Learning