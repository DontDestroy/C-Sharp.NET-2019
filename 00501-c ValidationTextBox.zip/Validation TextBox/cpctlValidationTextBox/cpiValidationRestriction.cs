﻿//***
// Action
//   - Interface to define a validation restriction for a textbox
// Created
//   - CopyPaste – 20250718 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250718 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public interface cpiValidationRestriction
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    bool Validate(cpctlValidationTextbox theSender, System.Windows.Forms.KeyPressEventArgs theKeyPressEventArguments);

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpiValidationRestriction

}
// CopyPaste.Learning