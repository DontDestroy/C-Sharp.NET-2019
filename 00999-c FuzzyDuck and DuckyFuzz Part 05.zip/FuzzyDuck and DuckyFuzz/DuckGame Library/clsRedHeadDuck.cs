﻿//***
// Action
//   - Implementation of a cpRedHeadDuck
//     - Inherits from cpDuck, where Display (how do I look like) is an abstract method
//       - All class that inherit from cpDuck must implement the Display method
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
//   - The way a cpRedHeadDuck moves on water is inherited
//     - All cpDuck and child classes moves on water the same way
//   - The sound that a cpRedHeadDuck makes is thru an interface
//   - The way a cpRedHeadDuck moves on land is thru an interface
//   - The way a cpRedHeadDuck moves in the air is thru an interface
// Created
//   - CopyPaste – 20240718 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240718 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Duck.Library
{

	public class cpRedHeadDuck : cpDuck, cpiFlyable, cpiQuackable, cpiWalkable
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpRedHeadDuck
		/// </summary>
		public cpRedHeadDuck() : base()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - cpDuck()
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpRedHeadDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		#region "Overrides"

		/// <summary>
		/// The visualization (displaying) of a cpRedHeadDuck
		/// </summary>
		public override void Display()
		//***
		// Action
		//   - Define how a cpRedHeadDuck looks like
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240716 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240716 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Representation of a cpRedHeadDuck");
		}
		// Display()

		#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how the cpRedHeadDuck moves in the air
		/// </summary>
		public void Fly()
		//***
		// Action
		//   - Define how the cpRedHeadDuck if flying
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("cpRedHeadDuck is moving around in the air");
		}
		// Fly()

		/// <summary>
		/// What noise is the cpRedHeadDuck making 
		/// </summary>
		public void Quack()
		//***
		// Action
		//   - Define the noise that the cpRedHeadDuck makes
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Represent the sound of a cpRedHeadDuck");
		}
		// Quack()

		/// <summary>
		/// How is a cpRedHeadDuck moving on land
		/// </summary>
		public void Walk()
		//***
		// Action
		//   - Define how the cpRedHeadDuck moves on land
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("cpRedHeadDuck is moving around on land");
		}
		// Walk()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpRedHeadDuck

}
// CopyPaste.Game.Duck.Library