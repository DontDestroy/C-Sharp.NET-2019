//***
// Action
//   - Testroutine for cpDailyEvent and cpTodaysActivity
// Created
//   - CopyPaste � 20240531 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240531 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static cpTodaysActivity mcpToday;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private static void ScheduleHandler(string strItem, string strStart)
      //***
      // Action
      //   - Show the item and the start
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine(strItem + " at: " + strStart);
    }
    // ScheduleHandler(String, String)

    #endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Initialize a cpTodaysActivity
      //   - Add a functionality for Family event
      //   - Add a functionality for Meals event
      //   - Add a functionality for Meeting event
      //   - Generate the events
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpDailyEvent.Family(string, string)
      //   - cpDailyEvent.GenerateEvents()
      //   - cpDailyEvent.Meals(string, string)
      //   - cpDailyEvent.Meeting(string, string)
      //   - cpTodaysActivity(DateTime, DateTime)
      //   - ScheduleHandler(string, string)
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mcpToday = new cpTodaysActivity(DateTime.Now, DateTime.Now.AddHours(8));

      mcpToday.Family += new cpDailyEvent.DoSomething(ScheduleHandler);
      mcpToday.Meals += new cpDailyEvent.DoSomething(ScheduleHandler);
      mcpToday.Meeting += new cpDailyEvent.DoSomething(ScheduleHandler);

      mcpToday.GenerateEvents();
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning