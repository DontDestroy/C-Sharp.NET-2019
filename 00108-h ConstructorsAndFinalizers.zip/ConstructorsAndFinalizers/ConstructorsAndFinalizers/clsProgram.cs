//***
// Action
//   - Testroutine of an instance of cpCircle
// Created
//   - CopyPaste � 20231231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231231 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Math;
using System;

namespace CopyPaste.Learning.Math
{

	public class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main()
			//***
			// Action
			//   - Create a few instances of a cpCircle
			//   - Destroy the instances of cpCircle
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - cpCircle()
			//   - cpCircle(cpPoint, double)
			//   - cpCircle(int, int, double)
			//   - cpPoint(int, int)
			// Created
			//   - CopyPaste � 20231231 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231231 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - Put the statement System.GC.Collect() below in comment the next run
			//   - Put a breakpoint in the finalizers of cpCircle and cpPoint
			//***
  	{
			cpCircle thecpCircle1;
			cpCircle thecpCircle2;
			cpCircle thecpCircle3;
			cpPoint thecpPoint;

			thecpCircle1 = new cpCircle(1, 1, 1.1);
			thecpCircle2 = new cpCircle(2, 2, 2.2);
      thecpPoint = new cpPoint(3, 3);
			thecpCircle3 = new cpCircle(thecpPoint, 3.3);

			thecpCircle1 = null;
			thecpCircle2 = null;
			thecpPoint = null;
			thecpCircle3 = null;

			System.GC.Collect();
			Console.ReadLine();
		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.Learning.Math