//***
// Action
//   - Implementation of cpDistanceChangedEventArguments
//   - Used for giving information on the event (signal) from ctlTrain to the frmTrainGame
//     - cpDistanceChangedEventArguments contains the needed data / information for the event
//   - Information given is the distance of the train
//   - The cltTrain triggers the event
//   - The frmTrainGame handles the event
// Created
//   - CopyPaste � 20240228 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240228 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Games
{

  public class cpDistanceChangedEventArguments: System.EventArgs
  {

    #region "Constructors / Destructors"

    public cpDistanceChangedEventArguments(int lngDistance)
      //***
      // Action
      //   - Constructor with the distance of the train from the starting point on the form
      //   - At the start of the game, the train is at the beginning of the track on the form
      // Called by
      //   - cpctlTrain.tmrDistance_Tick(System.Object, System.EventArgs) Handles tmrDistance.Tick
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mlngDistance = lngDistance;
    }
    // cpDistanceChangedEventArguments(int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mlngDistance = 0;

    #endregion

    #region "Properties"

    public int Distance
    {

      get
        //***
        // Action Get
        //   - Returning mlngDistance
        // Called by
        //   - frmTrainGame.cpctlTrain_cpDistanceChanged(System.Object, cpDistanceChangedEventArguments) Handles cpctlTrain.cpDistanceChanged
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240228 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240228 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngDistance;
      }
      // int Distance (Get)

    }
    // int Distance

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpDistanceChangedEventArguments

}
// CopyPaste.Learning.Games