//***
// Action
//   - Work with data bound multi-select ListBoxes using Windows Forms
//   - Show the categories and the products that are in that category
//   - Show the categories and the products that are not in that category
//   - Show the products that are not in a category
//   - Remove a product from a category
//   - Add a product to a category
// Created
//   - CopyPaste � 20251211 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251211 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMultiSelectListTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.CheckBox chkUnAssignedOnly;
    internal System.Windows.Forms.Button cmdUnSelect;
    internal System.Windows.Forms.Button cmdSelect;
    internal System.Windows.Forms.Label lblSelectedProduct;
    internal System.Windows.Forms.ListBox lstSelectedProduct;
    internal System.Windows.Forms.Label lblUnSelectedProduct;
    internal System.Windows.Forms.Label lblCategory;
    internal System.Windows.Forms.ComboBox cmbCategory;
    internal System.Windows.Forms.ListBox lstUnSelectedProduct;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMultiSelectListTryout));
      this.chkUnAssignedOnly = new System.Windows.Forms.CheckBox();
      this.cmdUnSelect = new System.Windows.Forms.Button();
      this.cmdSelect = new System.Windows.Forms.Button();
      this.lblSelectedProduct = new System.Windows.Forms.Label();
      this.lstSelectedProduct = new System.Windows.Forms.ListBox();
      this.lblUnSelectedProduct = new System.Windows.Forms.Label();
      this.lblCategory = new System.Windows.Forms.Label();
      this.cmbCategory = new System.Windows.Forms.ComboBox();
      this.lstUnSelectedProduct = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // chkUnAssignedOnly
      // 
      this.chkUnAssignedOnly.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.chkUnAssignedOnly.Location = new System.Drawing.Point(8, 242);
      this.chkUnAssignedOnly.Name = "chkUnAssignedOnly";
      this.chkUnAssignedOnly.Size = new System.Drawing.Size(168, 24);
      this.chkUnAssignedOnly.TabIndex = 17;
      this.chkUnAssignedOnly.Text = "Unassigned Products Only";
      this.chkUnAssignedOnly.CheckedChanged += new System.EventHandler(this.chkUnAssignedOnly_CheckedChanged);
      // 
      // cmdUnSelect
      // 
      this.cmdUnSelect.Location = new System.Drawing.Point(248, 146);
      this.cmdUnSelect.Name = "cmdUnSelect";
      this.cmdUnSelect.Size = new System.Drawing.Size(40, 24);
      this.cmdUnSelect.TabIndex = 16;
      this.cmdUnSelect.Text = "<";
      this.cmdUnSelect.Click += new System.EventHandler(this.cmdUnSelect_Click);
      // 
      // cmdSelect
      // 
      this.cmdSelect.Location = new System.Drawing.Point(248, 114);
      this.cmdSelect.Name = "cmdSelect";
      this.cmdSelect.Size = new System.Drawing.Size(40, 24);
      this.cmdSelect.TabIndex = 15;
      this.cmdSelect.Text = ">";
      this.cmdSelect.Click += new System.EventHandler(this.cmdSelect_Click);
      // 
      // lblSelectedProduct
      // 
      this.lblSelectedProduct.Location = new System.Drawing.Point(304, 42);
      this.lblSelectedProduct.Name = "lblSelectedProduct";
      this.lblSelectedProduct.Size = new System.Drawing.Size(144, 16);
      this.lblSelectedProduct.TabIndex = 13;
      this.lblSelectedProduct.Text = "Selected Products";
      // 
      // lstSelectedProduct
      // 
      this.lstSelectedProduct.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.lstSelectedProduct.Location = new System.Drawing.Point(304, 60);
      this.lstSelectedProduct.Name = "lstSelectedProduct";
      this.lstSelectedProduct.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
      this.lstSelectedProduct.Size = new System.Drawing.Size(224, 173);
      this.lstSelectedProduct.TabIndex = 14;
      // 
      // lblUnSelectedProduct
      // 
      this.lblUnSelectedProduct.Location = new System.Drawing.Point(8, 42);
      this.lblUnSelectedProduct.Name = "lblUnSelectedProduct";
      this.lblUnSelectedProduct.Size = new System.Drawing.Size(144, 16);
      this.lblUnSelectedProduct.TabIndex = 11;
      this.lblUnSelectedProduct.Text = "Unselected Products";
      // 
      // lblCategory
      // 
      this.lblCategory.Location = new System.Drawing.Point(16, 10);
      this.lblCategory.Name = "lblCategory";
      this.lblCategory.Size = new System.Drawing.Size(56, 16);
      this.lblCategory.TabIndex = 9;
      this.lblCategory.Text = "Category";
      // 
      // cmbCategory
      // 
      this.cmbCategory.Location = new System.Drawing.Point(80, 10);
      this.cmbCategory.Name = "cmbCategory";
      this.cmbCategory.Size = new System.Drawing.Size(448, 21);
      this.cmbCategory.TabIndex = 10;
      this.cmbCategory.SelectedIndexChanged += new System.EventHandler(this.cmbCategory_SelectedIndexChanged);
      // 
      // lstUnSelectedProduct
      // 
      this.lstUnSelectedProduct.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.lstUnSelectedProduct.Location = new System.Drawing.Point(8, 58);
      this.lstUnSelectedProduct.Name = "lstUnSelectedProduct";
      this.lstUnSelectedProduct.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
      this.lstUnSelectedProduct.Size = new System.Drawing.Size(224, 173);
      this.lstUnSelectedProduct.TabIndex = 12;
      // 
      // frmMultiSelectListTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(536, 277);
      this.Controls.Add(this.chkUnAssignedOnly);
      this.Controls.Add(this.cmdUnSelect);
      this.Controls.Add(this.cmdSelect);
      this.Controls.Add(this.lblSelectedProduct);
      this.Controls.Add(this.lstSelectedProduct);
      this.Controls.Add(this.lblUnSelectedProduct);
      this.Controls.Add(this.lblCategory);
      this.Controls.Add(this.cmbCategory);
      this.Controls.Add(this.lstUnSelectedProduct);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMultiSelectListTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Work with Data Bound Multi-Select List Boxes Using a Windows Form Tryout";
      this.Load += new System.EventHandler(this.frmMultiSelectListTryout_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMultiSelectListTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMultiSelectListTryout()
      //***
      // Action
      //   - Create instance of 'frmMultiSelectListTryout'
      // Called by
      //   - frmMainTryout.cmdMultiSelectList_Click(System.Object, System.EventArgs) Handles cmdMultiSelectList.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMultiSelectListTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void chkUnAssignedOnly_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Reload the not selected products
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - LoadProduct(bool)
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // chkUnAssignedOnly_CheckedChanged(System.Object, System.EventArgs) Handles chkUnAssignedOnly.CheckedChanged

    private void cmbCategory_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Fill the list of selected products (of the chosen category)
      //   - Fill the list of not selected products (of the chosen category)
      // Called by
      //   - User action (Selecting an item in a combobox)
      // Calls
      //   - LoadProduct(Boolean)
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmbCategory_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbCategory.SelectedIndexChanged

    private void cmdSelect_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a two data row views
      //   - Count the items that are selected from the unselected products
      //   - Loop thru the selected items of the unselected products
      //     - Generate a list of items, seperated by a comma
      //     - If there is already an item
      //       - Add a comma
      //     - Set the data row view to that product
      //     - Add the key to the list of items
      //   - Try to
      //     - Set a data row view to the selected category
      //     - Define a command
      //     - Define a SQL statement
      //     - Define and create a connection
      //     - Create an SQL statement to add the category to the selected items of unselected products
      //     - Create the command with the SQL statement and the connection
      //     - Set the command to text
      //     - Open the connection
      //     - Execute the SQL statement
      //     - Close the connection
      //   - On error
      //     - Show the exception message
      //   - Load the selected products
      //   - Load the not selected products
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpGeneralRoutines()
      //   - LoadProduct(bool)
      //   - SqlConnection cpGeneralRoutines.GetConnection()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdSelect_Click(System.Object, System.EventArgs) Handles cmdSelect.Click
    
    private void cmdUnSelect_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a data row view
      //   - Count the items that are selected from the selected products
      //   - Loop thru the selected items of the selected products
      //     - Generate a list of items, seperated by a comma
      //     - If there is already an item
      //       - Add a comma
      //     - Set the data row view to that product
      //     - Add the key to the list of items
      //   - Try to
      //     - Define a command
      //     - Define a SQL statement
      //     - Define and create a connection
      //     - Create an SQL statement to remove the category from the selected items of selected products
      //     - Create the command with the SQL statement and the connection
      //     - Set the command to text
      //     - Open the connection
      //     - Execute the SQL statement
      //     - Close the connection
      //   - On error
      //     - Show the exception message
      //   - Load the selected products
      //   - Load the not selected products
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpGeneralRoutines()
      //   - LoadProduct(bool)
      //   - SqlConnection cpGeneralRoutines.GetConnection()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdUnSelect_Click(System.Object, System.EventArgs) Handles cmdUnSelect.Click

    private void frmMultiSelectListTryout_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a data adapter for category
      //   - Define and create a category data table
      //   - Create the data adapter using a SQL Statement and the connection string
      //   - Fill the data table using the data adapter
      //   - The combo box gets the data table category as data source
      //   - The name of the category is shown
      //   - The value is the unique key of category
      //   - Load the not selected products (of that category)
      //   - Load the selected products (of that category)
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpGeneralRoutines()
      //   - LoadProduct(bool)
      //   - SqlConnection cpGeneralRoutines.GetConnection() 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmMultiSelectListTryout_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void LoadProduct(bool blnSelected)
      //***
      // Action
      //   - Define a data row view
      //   - Define a SQL statement
      //   - If selected
      //     - Define a SQL data adapter (of selected products)
      //     - Define and create a data table (of selected products)
      //     - The data row view becomes the selected category
      //     - A SQL statement is created (Get the products of the selected category)
      //     - Create a data adapter using the SQL statement and the connection string
      //     - Fill the data table using the data adapter
      //     - The data source of list of the selected products becomes the data table
      //     - The name of the product is shown
      //     - The value is the unique key of product
      //     - Remove any selection
      //   - If not
      //     - Define a SQL data adapter (of not selected products)
      //     - Define and create a data table (of not selected products)
      //     - The data row view becomes the selected category
      //     - If checkbox of unassigned products is selected
      //       - A SQL statement is created (Get the products that don't have a category)
      //     - If not
      //       - A SQL statement is created (Get the products that don't have a category and the ones not the choosen category
      //     - Create a data adapter using the SQL statement and the connection string
      //     - Fill the data table using the data adapter
      //     - The data source of list of the not selected products becomes the data table
      //     - The name of the product is shown
      //     - The value is the unique key of product
      //     - Remove any selection
      // Called by
      //   - chkUnAssignedOnly_CheckedChanged(System.Object, System.EventArgs) Handles chkUnAssignedOnly.CheckedChanged
      //   - cmbCategory_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbCategory.SelectedIndexChanged
      //   - cmdSelect_Click(System.Object, System.EventArgs) Handles cmdSelect.Click
      //   - cmdUnSelect_Click(System.Object, System.EventArgs) Handles cmdUnSelect.Click
      //   - frmMultiSelectListTryout_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - cpGeneralRoutines()
      //   - SqlConnection cpGeneralRoutines.GetConnection()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***    
    {
    }
    // LoadProduct(bool)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMultiSelectListTryout

}
// CopyPaste.Learning