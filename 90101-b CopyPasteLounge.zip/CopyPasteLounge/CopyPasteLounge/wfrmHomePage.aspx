﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmHomePage.aspx.cs" Inherits="CopyPaste.Learning.wfrmHomePage" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Copy Paste Lounge with Some Tags</title>
  <link type="text/css" rel="stylesheet" href="cssLounge.css">
</head>
<body>
  <form id="wfrmHomePage">
    <h1>Welcome to the new and improved Copy Paste Lounge with some styling</h1>
    <img src="./Resources/Drinks.gif" alt="Picture not available">
    <p>
      Join us any evening for refreshing <a href="wfrmElixirs.aspx">elixirs</a>, conversations and maybe a game of two of <em>Ticket to Ride</em>.
      Wireless access is always provided.
      BYOWS (Bring Your Own Web Server).
    </p>
    <h2>Directions</h2>
    <p>
      You will find us right in the center of DownTown <a href="wfrmDoesNotWork">WebVille</a>.
    </p>
    <p>
      If you need help finding us, check out our <a href="wfrmDirections.aspx">detailed directions</a>.
    </p>
    <p>
      Always straight, till you must turn.
      Come join us!
    </p>
    <img src="./Resources/CopyPaste.jpg" alt="Copy Paste Logo not available">
  </form>
</body>
</html>
