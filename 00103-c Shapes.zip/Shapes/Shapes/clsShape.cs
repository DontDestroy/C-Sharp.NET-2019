//***
// Action
//   - The definition of a cpShape
//   - The implementation of the methods is forced in the classes that inherit
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public abstract class cpShape
  {

    #region "Constructors / Destructors"

    public cpShape()
      //***
      // Action
      //   - Empty constructor of a cpShape
      // Called by
      //   - cpFakeShape()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpShape()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public abstract void Draw();
    public abstract void Reflect();
    // VVDW - Mirroring horizontal and vertical
    public abstract void Rotate(System.Single sngDegrees);
    // VVDW - Rotation by degrees
    public abstract void Translate(int lngX, int lngY);
    // VVDW - Move by points

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpShape

}
// CopyPaste.Learning