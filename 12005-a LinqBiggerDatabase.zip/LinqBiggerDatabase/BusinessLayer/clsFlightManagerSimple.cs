﻿//***
// Action
//   - Flight Manager (Light)
// Created
//   - CopyPaste – 20230719 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230719 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.BusinessObjects;
using CopyPaste.DataAccess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CopyPaste.BusinessLayer
{

  public class cpFlightManagerSimple : IDisposable
  {

    #region "Constructors / Destructors"

    public cpFlightManagerSimple()
    //***
    // Action
    //   - Default Constructor of cpFlightManagerSimple
    // Called by
    //   - cpFlightManagerSimple(cpWingsContext)
    //   - cpWingsContext theContext (Get)
    //   - LoopThruUnbookedFlightsFromDepartureAndDestinationRepositoryPattern(cpWingsContext)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpFlightManagerSimple()

    public cpFlightManagerSimple(cpWingsContext theDatabaseContext) : this()
    //***
    // Action
    //   - Constructor of cpFlightManagerSimple with a cpWingsContext as parameter
    // Called by
    //   - theContext(cpWingsContext) (Set)
    //   - LoopThruUnbookedFlightsFromDepartureAndDestinationRepositoryPattern(cpWingsContext)
    // Calls
    //   - cpFlightManagerSimple()
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theContext = theDatabaseContext;
    }
    // cpFlightManagerSimple(cpWingsContext)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private bool _blnDispose;
    private cpWingsContext _theContext;

    #endregion

    #region "Properties"

    public cpWingsContext theContext
    {

      private get
      //***
      // Action Get
      //   - If _theContext is nothing
      //     - _theContext becomes an instance op cpWingsContext
      //   - Returns _theContext
      // Called by
      //   - IQueryable<Flight> BookableFlights()
      // Calls
      //   - cpWingsContext()
      // Created
      //   - CopyPaste – 20230719 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20230719 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if (_theContext == null)
        {
          _theContext = new cpWingsContext();
          _blnDispose = true;
        }
        else
        // _theContext <> null
        {
        }
        // _theContext = null

        return _theContext;
      }
      // cpWingsContext theContext (Get)

      set
      //***
      // Action Set
      //   - _theContext becomes value
      // Called by
      //   - cpFlightManagerSimple(cpWingsContext)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20230719 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20230719 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        _theContext = value;
      }
      // theContext(cpWingsContext) (Set)

    }
    // cpWingsContext theContext

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Dispose()
    //***
    // Action
    //   - Clean up the cpFlightManagerSimple
    // Called by
    //   - System action (not using the instance anymore)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (_blnDispose)
      {
        _theContext.Dispose();
      }
      else
      // Not _blnDispose
      {
      }
      // _blnDispose

    }
    // Dispose()

    public IQueryable<Flight> BookableFlights()
    //***
    // Action
    //   - Return all the Flights with free seats (so that are bookable)
    // Called by
    //   - 
    // Calls
    //   - cpWingsContext theContext (Get)
    //   - DbSet<Flight> cpWingsContext.Flight (Get)
    //   - LoopThruUnbookedFlightsFromDepartureAndDestinationRepositoryPattern(cpWingsContext)
    //   - short Flight.FreeSeats (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      IQueryable<Flight> colResultExpression;

      colResultExpression = from aFlight in theContext.Flight
                            where aFlight.FreeSeats > 0
                            select aFlight;

      // IQueryable<Flight> colResultLambda;
      // colResultLambda = theContext.Flight.Where(aFlight => aFlight.FreeSeats > 0);

      return colResultExpression;
    }
    // IQueryable<Flight> BookableFlights()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpFlightManagerSimple

}
// CopyPaste.BusinessLayer