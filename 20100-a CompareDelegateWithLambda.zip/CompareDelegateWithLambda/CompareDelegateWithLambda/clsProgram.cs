﻿//***
// Action
//   - Doing the same thing with Delegate, Lambda and Unnamed
// Created
//   - CopyPaste – 20230408 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230408 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Diagnostics;

namespace CompareDelegateWithLambda
{
  
  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void DelegateExample()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Create an array containing the first 10 natural numbers
    //   - Filter the array on odd numbers (using a delegate)
    //   - Show the result
    //   - Filter the array on even numbers (using a delegate)
    //   - Show the result
    // Called by
    //   - Main()
    // Calls
    //   - bool cpApplication.IsEven(int)
    //   - bool cpApplication.IsOdd(int)
    //   - cpCommon.LoopArray(int[])
    //   - int[] cpCommon.FilterArrayOfNumbers(int[], FilterNumbers)
    // Created
    //   - CopyPaste – 20230408 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230408 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      int[] arrintNumbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
      int[] arrintOddNumbers = cpCommon.FilterArrayOfNumbers(arrintNumbers, cpApplication.IsOdd);

      Console.Write("Odd numbers: ");
      cpCommon.LoopArray(arrintOddNumbers);

      int[] arrintEvenNumbers = cpCommon.FilterArrayOfNumbers(arrintNumbers, cpApplication.IsEven);
      Console.Write("Even numbers: ");
      cpCommon.LoopArray(arrintEvenNumbers);

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // DelegateExample()

    static void LambdaExample()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Create an array containing the first 10 natural numbers
    //   - Filter the array on odd numbers (using a Lambda expression)
    //   - Show the result
    //   - Filter the array on even numbers (using a Lambda expression)
    //   - Show the result
    // Called by
    //   - Main()
    // Calls
    //   - cpCommon.LoopArray(int[])
    //   - int[] cpCommon.FilterArrayOfNumbers(int[], FilterNumbers)
    // Created
    //   - CopyPaste – 20230409 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230409 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      int[] arrintNumbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
      int[] arrintOddNumbers = cpCommon.FilterArrayOfNumbers(arrintNumbers, intNumber => ((intNumber & 1) == 1));
      // Pay attention to what is happening here
      // I create a Lambda expression with input an integer, that is returning a boolean
      // The Lambda expression fills the delegate with a method

      Console.Write("Odd numbers: ");
      cpCommon.LoopArray(arrintOddNumbers);

      int[] arrintEvenNumbers = cpCommon.FilterArrayOfNumbers(arrintNumbers, intNumber => ((intNumber & 1) == 0));
      Console.Write("Even numbers: ");
      cpCommon.LoopArray(arrintEvenNumbers);

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // LambdaExample()

    public static void Main()
    //***
    // Action
    //   - Demo to show the difference between a delegate and Linq
    // Called by
    //   -
    // Calls
    //   - DelegateExample()
    //   - TryToExperiment()
    //   - UnnamedMethodExample()
    // Created
    //   - CopyPaste – 20230408 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230408 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      TryToExperiment();
      // DelegateExample();
      // UnnamedMethodExample();
      // LambdaExample();
      Console.ReadLine();
    }
    // Main()

    static void TryToExperiment()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Method used for experimenting
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230408 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230408 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      //  Do your stuff here

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // TryToExperiment()

    static void UnnamedMethodExample()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Create an array containing the first 10 natural numbers
    //   - Filter the array on odd numbers (using an unnamed method)
    //   - Show the result
    //   - Filter the array on even numbers (using an unnamed method)
    //   - Show the result
    // Called by
    //   - Main()
    // Calls
    //   - cpCommon.LoopArray(int[])
    //   - int[] cpCommon.FilterArrayOfNumbers(int[], FilterNumbers)
    // Created
    //   - CopyPaste – 20230409 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230409 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      int[] arrintNumbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
      int[] arrintOddNumbers = cpCommon.FilterArrayOfNumbers(arrintNumbers, delegate (int intNumber) { return ((intNumber & 1) == 1); });
        // Pay attention to what is happening here
        // I create a delegate with input an integer, that is returning a boolean
        // The method itself (return calculation but has no name) is written just behind the delegate definition
        // Look at where { and ( and ; are placed

      Console.Write("Odd numbers: ");
      cpCommon.LoopArray(arrintOddNumbers);

      int[] arrintEvenNumbers = cpCommon.FilterArrayOfNumbers(arrintNumbers, delegate (int intNumber) { return ((intNumber & 1) == 0); });
      Console.Write("Even numbers: ");
      cpCommon.LoopArray(arrintEvenNumbers);

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // UnnamedMethodExample()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CompareDelegateWithLambda