//***
// Action
//   - Definition of an abstract (mustinherit) cpPageContent
// Created
//   - CopyPaste � 20240412 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � yyyy20240412mmdd � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning.Page
{

  public abstract class cpPageContent
  {

    #region "Constructors / Destructors"

    public cpPageContent(string strMessage)
      //***
      // Action
      //   - Constructor with Message
      // Called by
      //   - cpHTMLPage(string)
      //   - cpWMLPage(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240412 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240412 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrPageData = strMessage;
    }
    // cpPageContent()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
      public string mstrPageData;
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public abstract void ShowPage();

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPageContent

}
// CopyPaste.Learning.Page