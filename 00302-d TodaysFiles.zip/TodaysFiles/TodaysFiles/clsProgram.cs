//***
// Action
//   - Show all files that are created today
// Created
//   - CopyPaste � 20240902 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240902 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    public static DateTime mdtmToday;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Set a date to today
      //   - Show a message "Searching ..."
      //   - Search tree on the C:\ root
      //   - Show a message to press enter
      //   - Wait till enter is pressed
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - SearchTree(string)
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mdtmToday = DateTime.Today;
      Console.WriteLine("Searching ...");
      SearchTree("C:\\");
      Console.WriteLine("Press Enter to Continue ...");
      Console.ReadLine();
    }
		// Main()

    private static bool SameDate(DateTime dtmFirst, DateTime dtmSecond)
      //***
      // Action
      //   - If Year of both dates and DayOfYear of both dates are the same
      //     - Return true
      //   - If not
      //     - Return false
      // Called by
      //   - SearchTree(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;

      blnResult = (dtmFirst.Year == dtmSecond.Year) && (dtmFirst.DayOfYear == dtmSecond.DayOfYear);

      return blnResult;
    }
    // bool SameDate(DateTime, DateTime)

    private static void SearchTree(string strDirectory)
      //***
      // Action
      //   - Get all the directories of a given path
      //   - Get all the files of a given path
      //   - Loop thru the filenames
      //     - Try
      //       - Get the creation time of file
      //       - If the date is the same date as today
      //         - Show a message of the filename and the date
      //       - If not
      //         - Do nothing
      //     - On Error
      //       - Show error that file can't be accessed
      //       - Show exception message
      //   - Loop thru directories
      //     - Try
      //       - Get the creation time of directory
      //       - If the date is the same date as today
      //         - Show a message of the directoryname and the date
      //       - If not
      //         - Do nothing
      //       - Search the tree of the directory
      //     - On Error
      //       - Show error that directory can't be accessed
      //      '       - Show exception message
      // Called by
      //   - SearchTree(String)
      // Calls
      //   - SearchTree(String)
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      DateTime dtmDirectory;
      DateTime dtmFile;
      string[] arrstrDirectory = Directory.GetDirectories(strDirectory);
      string[] arrstrFile = Directory.GetFiles(strDirectory);

      foreach(string strFileName in arrstrFile)
      {

        try
        {
          dtmFile = File.GetCreationTime(strFileName);

          if (SameDate(dtmFile, mdtmToday))
          {
            Console.WriteLine(strFileName + " - " + dtmFile);
          }
          else
            // Not SameDate(dtmFile, mdtmToday)
          {
          }
          // SameDate(dtmFile, mdtmToday)
        }
        catch (Exception theException)
        {
          Console.WriteLine("Error accessing {0}", strFileName);
          Console.WriteLine("Error: {0}", theException.Message);
        }

      }
      // in arrstrFile

      foreach(string strDirectoryName in arrstrDirectory)
      {

        try
        {
          dtmDirectory = Directory.GetCreationTime(strDirectoryName);

          if (SameDate(dtmDirectory, mdtmToday))
          {
            Console.WriteLine(strDirectoryName + " - " + dtmDirectory);
          }
          else
            // Not SameDate(dtmDirectory, mdtmToday)
          {
          }
          // SameDate(dtmDirectory, mdtmToday)

          SearchTree(strDirectoryName);
        }
        catch(Exception theException)
        {
          Console.WriteLine("Error accessing {0}", strDirectoryName);
          Console.WriteLine("Error: {0}", theException.Message);
        }

      }
      // in arrstrDirectory

    }
    // 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning