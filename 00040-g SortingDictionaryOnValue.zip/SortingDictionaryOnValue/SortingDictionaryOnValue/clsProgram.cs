﻿//***
// Action
//   - There a dictionary with keys and values
//   - Sort the dictionary on the values in it
// Created
//   - CopyPaste – 20230526 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230526 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    static void Main()
    //***
    // Action
    //   - Defining 2 dictionaries (one unsorted, one sorted)
    //   - Defining a list with KeyValuePair items
    //   - Count the characters of a sentence
    //   - Show the characters and their values
    //   - Sort the dictionary
    //   - Show the characters and their values (sorted)
    //   - Sort the list
    //   - Show the characters and their values (sorted)
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20230526 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230526 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Dictionary<string, int> anUnsorted = new Dictionary<string, int>();
      Dictionary<string, int> aSorted = new Dictionary<string, int>();
      List<KeyValuePair<string, int>> aList;

      // You want to see how many times a letter is used in a sentence
      // Sentence "the quick brown fox jumps over the lazy dog" is here added with the number of times it occurs

      anUnsorted.Add("a", 1);
      anUnsorted.Add("b", 1);
      anUnsorted.Add("c", 1);
      anUnsorted.Add("d", 1);
      anUnsorted.Add("e", 3);
      anUnsorted.Add("f", 1);
      anUnsorted.Add("g", 1);
      anUnsorted.Add("h", 2);
      anUnsorted.Add("i", 1);
      anUnsorted.Add("j", 1);
      anUnsorted.Add("k", 1);
      anUnsorted.Add("l", 1);
      anUnsorted.Add("m", 1);
      anUnsorted.Add("n", 1);
      anUnsorted.Add("o", 4);
      anUnsorted.Add("p", 1);
      anUnsorted.Add("q", 1);
      anUnsorted.Add("r", 2);
      anUnsorted.Add("s", 1);
      anUnsorted.Add("t", 2);
      anUnsorted.Add("u", 2);
      anUnsorted.Add("v", 1);
      anUnsorted.Add("w", 1);
      anUnsorted.Add("x", 1);
      anUnsorted.Add("y", 1);
      anUnsorted.Add("z", 1);
      anUnsorted.Add(" ", 8);

      Console.WriteLine("Unsorted");

      foreach (KeyValuePair<string, int> aPair in anUnsorted)
      {
        Console.Write(aPair.Key + " (" + aPair.Value + ") | ");
      }
      // in anUnsorted

      Console.WriteLine();

      aSorted = anUnsorted.OrderByDescending(aPair => aPair.Value).ToDictionary(aPair => aPair.Key, aPair => aPair.Value);
      // I use Linq (Lambda expression) to sort on the value (biggest first)
      // the original order is maintained
      // aPair is a KeyPairValue

      Console.WriteLine("Sorted");

      foreach (KeyValuePair<string, int> aPair in aSorted)
      {
        Console.Write(aPair.Key + " (" + aPair.Value + ") | ");
      }
      // in aSorted

      Console.WriteLine();

      // Alternative solution
      Console.WriteLine("Sorted Alternative");

      aList = anUnsorted.ToList();
      aList.Sort((anItem, anotherItem) => anotherItem.Value.CompareTo(anItem.Value));
      // I use Lambda expression to sort on the value (biggest first) with a CompareTo method
      // the original order is not maintained
      // aPair is a KeyPairValue

      foreach (KeyValuePair<string, int> aPair in aList)
      {
        Console.Write(aPair.Key + " (" + aPair.Value + ") | ");
      }
      // in aList

      Console.ReadLine();
    }
    // Main()

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning