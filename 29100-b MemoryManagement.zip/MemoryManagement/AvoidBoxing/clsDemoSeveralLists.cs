﻿//***
// Action
//   - Demo with an ArrayList and List<T>
// Created
//   - CopyPaste – 20260608 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260608 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections;
using System.Collections.Generic;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpDemoSeveralLists
  {

    #region "Constructors / Destructors"

    public cpDemoSeveralLists()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260608 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260608 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpDemoSeveralLists()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int intLength = 1_000_000;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [BenchmarkAttribute]
    public ArrayList DemoArrayList()
    //***
    // Action
    //   - Create an array list with 1 million integers
    //   - An arraylist contains objects
    //     - Every item must be boxed to be workable
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260608 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260608 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ArrayList arrNumbers = new ArrayList();

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {
        arrNumbers.Add(intCounter);
        // VVDW - The Add functionality boxes the integer into an Object (wrapper around integer)
      }
      // intCounter < intLength

      return arrNumbers;
    }
    // ArrayList DemoArrayList()

    [BenchmarkAttribute]
    public List<int> DemoList()
    //***
    // Action
    //   - Create a list with 1 million integers
    //   - An list contains a specific data type
    //     - Every item must not be boxed to be workable
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260608 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260608 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      List<int> arrNumbers = new List<int>();

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {
        arrNumbers.Add(intCounter);
      }
      // intCounter < intLength

      return arrNumbers;
    }
    // List<int> DemoList()

    #endregion

    #endregion

    #endregion

    #region "Not used"

    private void Process<T>(T theGivenValue) where T : IFormattable
      //***
      // Action
      //   - Do some process with a given value of data type T
      //     - The given data type has constraints
      //   - No boxing (converting to another data) is needed because of the generic data type
      //     - For each used value type the compiler generates a special version
      // Called by    
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260611 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260611 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine(theGivenValue.ToString(null, null));
    }
    // Process<T>(T)

    #endregion

  }
  // cpDemoSeveralLists

}
// CopyPaste.Learning