//***
// Action
//   - Methods for the EightBallAnswer Form
// Created
//   - CopyPaste � 20220813 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220813 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Input;

namespace EightBall
{

  public partial class wpfEightBallAnswer : Window
  {

    #region "Constructors / Destructors"

    public wpfEightBallAnswer()
    //***
    // Action
    //   - Constructor of a wpfEightBallAnswer
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220813 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220813 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfEightBallAnswer()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAnswer_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - The system waits one second, to simulate it is thinking
    //   - The mousepointer is changing into a wait symbol
    //   - Creating an instance of a AnswerGenerator
    //   - Generate a random answer
    //   - Show it on the screen
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - string AnswerGenerator.GetRandomAnswer(string)
    // Created
    //   - CopyPaste � 20220813 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220813 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Do proposals to optimize this
    //   - Tip: put generator somewhere else
    //***
    {
      this.Cursor = Cursors.Wait;
      System.Threading.Thread.Sleep(TimeSpan.FromSeconds(1));

      cpAnswerGenerator generator = new cpAnswerGenerator();
      txtAnswer.Text = generator.GetRandomAnswer(txtQuestion.Text);
      this.Cursor = null;
    }
    // cmdAnswer_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAnswer.Click

    private void cmdChangeColour_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Whatever you define in the XAML, you can do the same thing in code
    //     < Grid x:Name="grdWindow">
    //       < Grid.Background >
    //         < LinearGradientBrush >
    //           < LinearGradientBrush.GradientStops >
    //             < GradientStop Offset="0.00"  Color="Red" />
    //             < GradientStop Offset = "0.50" Color="Indigo" />
    //             < GradientStop Offset = "1.00" Color="Violet" />
    //           </LinearGradientBrush.GradientStops>
    //         </LinearGradientBrush>
    //       </Grid.Background>
    //     </Grid>
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220813 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220813 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      LinearGradientBrush aBrush = new LinearGradientBrush();
      
      GradientStop firstGradientStop = new GradientStop();
      GradientStop secondGradientStop = new GradientStop();
      GradientStop thirdGradientStop = new GradientStop();

      firstGradientStop.Offset = 0;
      secondGradientStop.Offset = 0.5;
      thirdGradientStop.Offset = 1;

      firstGradientStop.Color = Colors.Violet;
      secondGradientStop.Color = Colors.Indigo;
      thirdGradientStop.Color = Colors.Red;

      aBrush.GradientStops.Add(firstGradientStop);
      aBrush.GradientStops.Add(secondGradientStop);
      aBrush.GradientStops.Add(thirdGradientStop);

      grdWindow.Background = aBrush;
    }
    // cmdChangeColour_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdChangeColour.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfEightBallAnswer

}
// EightBall