'***
' Action
'   - Some controls in a form
' Created
'   - CopyPaste � 20210827 � VVDW
' Changed
'   - CopyPaste � yyyymmdd � VVDW � What changed
' Tested
'   - CopyPaste � 20210827 � VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On 
Option Strict On

Public Class frmSimpleControls
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "
  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  Friend WithEvents lblButton As System.Windows.Forms.Label
  Friend WithEvents lblTextBox As System.Windows.Forms.Label
  Friend WithEvents lblLarge As System.Windows.Forms.Label
  Friend WithEvents cmdButton As System.Windows.Forms.Button
  Friend WithEvents txtTextBox As System.Windows.Forms.TextBox
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmSimpleControls))
    Me.lblButton = New System.Windows.Forms.Label
    Me.lblTextBox = New System.Windows.Forms.Label
    Me.lblLarge = New System.Windows.Forms.Label
    Me.cmdButton = New System.Windows.Forms.Button
    Me.txtTextBox = New System.Windows.Forms.TextBox
    Me.SuspendLayout()
    '
    'lblButton
    '
    Me.lblButton.AutoSize = True
    Me.lblButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lblButton.Location = New System.Drawing.Point(24, 40)
    Me.lblButton.Name = "lblButton"
    Me.lblButton.Size = New System.Drawing.Size(129, 22)
    Me.lblButton.TabIndex = 0
    Me.lblButton.Text = "This is a Button:"
    '
    'lblTextBox
    '
    Me.lblTextBox.AutoSize = True
    Me.lblTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lblTextBox.Location = New System.Drawing.Point(24, 128)
    Me.lblTextBox.Name = "lblTextBox"
    Me.lblTextBox.Size = New System.Drawing.Size(142, 22)
    Me.lblTextBox.TabIndex = 2
    Me.lblTextBox.Text = "This is a TextBox:"
    '
    'lblLarge
    '
    Me.lblLarge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.lblLarge.Font = New System.Drawing.Font("Arial", 21.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lblLarge.Location = New System.Drawing.Point(64, 224)
    Me.lblLarge.Name = "lblLarge"
    Me.lblLarge.Size = New System.Drawing.Size(344, 80)
    Me.lblLarge.TabIndex = 4
    Me.lblLarge.Text = "This is a Label with a large font and a border."
    Me.lblLarge.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'cmdButton
    '
    Me.cmdButton.Location = New System.Drawing.Point(200, 24)
    Me.cmdButton.Name = "cmdButton"
    Me.cmdButton.Size = New System.Drawing.Size(248, 48)
    Me.cmdButton.TabIndex = 1
    Me.cmdButton.Text = "Button1"
    '
    'txtTextBox
    '
    Me.txtTextBox.Location = New System.Drawing.Point(200, 112)
    Me.txtTextBox.Multiline = True
    Me.txtTextBox.Name = "txtTextBox"
    Me.txtTextBox.Size = New System.Drawing.Size(248, 56)
    Me.txtTextBox.TabIndex = 3
    Me.txtTextBox.Text = "TextBox1"
    '
    'frmSimpleControls
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(472, 381)
    Me.Controls.Add(Me.lblLarge)
    Me.Controls.Add(Me.txtTextBox)
    Me.Controls.Add(Me.lblTextBox)
    Me.Controls.Add(Me.cmdButton)
    Me.Controls.Add(Me.lblButton)
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Name = "frmSimpleControls"
    Me.Text = "Simple Controls"
    Me.ResumeLayout(False)

  End Sub

#End Region

#Region "Constructors / Destructors"

  Protected Overloads Overrides Sub Dispose(ByVal blnDisposing As Boolean)
    '***
    ' Action
    '   - Clean up instance of 'frmSimpleControls'
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210827 � VVDW
    ' Changed
    '   - CopyPaste � yyyymmdd � VVDW � What changed
    ' Tested
    '   - CopyPaste � 20210827 � VVDW
    ' Keyboard key
    '   -
    ' Proposal (To Do)
    '   -
    '***

    If blnDisposing Then

      If components Is Nothing Then
      Else
        ' Not components Is Nothing
        components.Dispose()
      End If
      ' components Is Nothing

    Else
      ' Not blnDisposing
    End If
    ' blnDisposing

    MyBase.Dispose(blnDisposing)
  End Sub
  ' Dispose(Boolean)

  Public Sub New()
    '***
    ' Action
    '   - Create new instance of 'frmSimpleControls'
    ' Called by
    '   - 
    ' Calls
    '   - InitializeComponent()
    ' Created
    '   - CopyPaste � 20210827 � VVDW
    ' Changed
    '   - CopyPaste � yyyymmdd � VVDW � What changed
    ' Tested
    '   - CopyPaste � 20210827 � VVDW
    ' Keyboard key
    '   -
    ' Proposal (To Do)
    '   -
    '***

    MyBase.New()
    InitializeComponent()
  End Sub
  ' New()

#End Region

  '#Region "Designer"
  '#End Region

  '#Region "Structures"
  '#End Region

  '#Region "Fields"
  '#End Region

  '#Region "Properties"
  '#End Region

  '#Region "Methods"

  '#Region "Overrides"
  '#End Region

  '#Region "Controls"
  '#End Region

  '#Region "Functionality"

  '#Region "Event"
  '#End Region

  '#Region "Sub / Function"
  '#End Region

  '#End Region

  '#End Region

  '#Region "Not used"
  '#End Region

End Class
' frmSimpleControls