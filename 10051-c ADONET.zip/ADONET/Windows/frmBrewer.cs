//***
// Action
//   - Find a brewer, show the correct information of that brewer
//   - Go thru the records in the data set (brewers)
//   - Create, Read, Update and Delete a brewer
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBrewer: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.ComboBox cmbFind;
    internal System.Windows.Forms.Button cmdSave;
    internal System.Windows.Forms.Button cmdDelete;
    internal System.Windows.Forms.Label lblPosition;
    internal System.Windows.Forms.Button cmdLast;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Button cmdPrevious;
    internal System.Windows.Forms.Button cmdFirst;
    internal System.Windows.Forms.TextBox txtBrewerProduction;
    internal System.Windows.Forms.TextBox txtBrewerCity;
    internal System.Windows.Forms.TextBox txtBrewerZipCode;
    internal System.Windows.Forms.TextBox txtBrewerAddress;
    internal System.Windows.Forms.TextBox txtBrewerName;
    internal System.Windows.Forms.Label lblBrewerKey;
    internal System.Windows.Forms.Label lblBrewerProduction;
    internal System.Windows.Forms.Label lblBrewerCity;
    internal System.Windows.Forms.Label lblBrewerZipCode;
    internal System.Windows.Forms.Label lblBrewerAddress;
    internal System.Windows.Forms.Label lblBrewerName;
    internal System.Windows.Forms.Label lblKeyBrewer;
    private Code.dsData dsData;
    internal System.Windows.Forms.Button cmdNew;
    
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBrewer));
      this.cmbFind = new System.Windows.Forms.ComboBox();
      this.cmdSave = new System.Windows.Forms.Button();
      this.cmdDelete = new System.Windows.Forms.Button();
      this.lblPosition = new System.Windows.Forms.Label();
      this.cmdLast = new System.Windows.Forms.Button();
      this.cmdNext = new System.Windows.Forms.Button();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.cmdFirst = new System.Windows.Forms.Button();
      this.txtBrewerProduction = new System.Windows.Forms.TextBox();
      this.txtBrewerCity = new System.Windows.Forms.TextBox();
      this.txtBrewerZipCode = new System.Windows.Forms.TextBox();
      this.txtBrewerAddress = new System.Windows.Forms.TextBox();
      this.txtBrewerName = new System.Windows.Forms.TextBox();
      this.lblBrewerKey = new System.Windows.Forms.Label();
      this.lblBrewerProduction = new System.Windows.Forms.Label();
      this.lblBrewerCity = new System.Windows.Forms.Label();
      this.lblBrewerZipCode = new System.Windows.Forms.Label();
      this.lblBrewerAddress = new System.Windows.Forms.Label();
      this.lblBrewerName = new System.Windows.Forms.Label();
      this.lblKeyBrewer = new System.Windows.Forms.Label();
      this.cmdNew = new System.Windows.Forms.Button();
      this.dsData = new Code.dsData();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.SuspendLayout();
      // 
      // cmbFind
      // 
      this.cmbFind.DataSource = this.dsData;
      this.cmbFind.DisplayMember = "tblCPBrewer.strBrewerName";
      this.cmbFind.Location = new System.Drawing.Point(8, 8);
      this.cmbFind.Name = "cmbFind";
      this.cmbFind.Size = new System.Drawing.Size(160, 21);
      this.cmbFind.TabIndex = 33;
      this.cmbFind.TabStop = false;
      // 
      // cmdSave
      // 
      this.cmdSave.Location = new System.Drawing.Point(96, 40);
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.TabIndex = 35;
      this.cmdSave.TabStop = false;
      this.cmdSave.Text = "Save";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // cmdDelete
      // 
      this.cmdDelete.Location = new System.Drawing.Point(232, 40);
      this.cmdDelete.Name = "cmdDelete";
      this.cmdDelete.TabIndex = 36;
      this.cmdDelete.TabStop = false;
      this.cmdDelete.Text = "Delete";
      this.cmdDelete.Click += new System.EventHandler(this.cmdDelete_Click);
      // 
      // lblPosition
      // 
      this.lblPosition.Location = new System.Drawing.Point(168, 80);
      this.lblPosition.Name = "lblPosition";
      this.lblPosition.Size = new System.Drawing.Size(56, 23);
      this.lblPosition.TabIndex = 39;
      this.lblPosition.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cmdLast
      // 
      this.cmdLast.Location = new System.Drawing.Point(272, 80);
      this.cmdLast.Name = "cmdLast";
      this.cmdLast.Size = new System.Drawing.Size(32, 23);
      this.cmdLast.TabIndex = 41;
      this.cmdLast.TabStop = false;
      this.cmdLast.Text = ">>";
      this.cmdLast.Click += new System.EventHandler(this.cmdLast_Click);
      // 
      // cmdNext
      // 
      this.cmdNext.Location = new System.Drawing.Point(232, 80);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(32, 23);
      this.cmdNext.TabIndex = 40;
      this.cmdNext.TabStop = false;
      this.cmdNext.Text = ">";
      this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Location = new System.Drawing.Point(128, 80);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(32, 23);
      this.cmdPrevious.TabIndex = 38;
      this.cmdPrevious.TabStop = false;
      this.cmdPrevious.Text = "<";
      this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
      // 
      // cmdFirst
      // 
      this.cmdFirst.Location = new System.Drawing.Point(88, 80);
      this.cmdFirst.Name = "cmdFirst";
      this.cmdFirst.Size = new System.Drawing.Size(32, 23);
      this.cmdFirst.TabIndex = 37;
      this.cmdFirst.TabStop = false;
      this.cmdFirst.Text = "<<";
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      // 
      // txtBrewerProduction
      // 
      this.txtBrewerProduction.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPBrewer.lngBrewerProduction"));
      this.txtBrewerProduction.Location = new System.Drawing.Point(88, 240);
      this.txtBrewerProduction.Name = "txtBrewerProduction";
      this.txtBrewerProduction.Size = new System.Drawing.Size(216, 20);
      this.txtBrewerProduction.TabIndex = 32;
      this.txtBrewerProduction.Text = "";
      // 
      // txtBrewerCity
      // 
      this.txtBrewerCity.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPBrewer.strBrewerCity"));
      this.txtBrewerCity.Location = new System.Drawing.Point(88, 208);
      this.txtBrewerCity.Name = "txtBrewerCity";
      this.txtBrewerCity.Size = new System.Drawing.Size(216, 20);
      this.txtBrewerCity.TabIndex = 30;
      this.txtBrewerCity.Text = "";
      // 
      // txtBrewerZipCode
      // 
      this.txtBrewerZipCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPBrewer.strBrewerZipcode"));
      this.txtBrewerZipCode.Location = new System.Drawing.Point(88, 176);
      this.txtBrewerZipCode.Name = "txtBrewerZipCode";
      this.txtBrewerZipCode.Size = new System.Drawing.Size(216, 20);
      this.txtBrewerZipCode.TabIndex = 28;
      this.txtBrewerZipCode.Text = "";
      // 
      // txtBrewerAddress
      // 
      this.txtBrewerAddress.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPBrewer.strBrewerAddress"));
      this.txtBrewerAddress.Location = new System.Drawing.Point(88, 144);
      this.txtBrewerAddress.Name = "txtBrewerAddress";
      this.txtBrewerAddress.Size = new System.Drawing.Size(216, 20);
      this.txtBrewerAddress.TabIndex = 26;
      this.txtBrewerAddress.Text = "";
      // 
      // txtBrewerName
      // 
      this.txtBrewerName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPBrewer.strBrewerName"));
      this.txtBrewerName.Location = new System.Drawing.Point(88, 112);
      this.txtBrewerName.Name = "txtBrewerName";
      this.txtBrewerName.Size = new System.Drawing.Size(216, 20);
      this.txtBrewerName.TabIndex = 24;
      this.txtBrewerName.Text = "";
      // 
      // lblBrewerKey
      // 
      this.lblBrewerKey.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPBrewer.lngIdBrewer"));
      this.lblBrewerKey.Location = new System.Drawing.Point(56, 80);
      this.lblBrewerKey.Name = "lblBrewerKey";
      this.lblBrewerKey.Size = new System.Drawing.Size(32, 23);
      this.lblBrewerKey.TabIndex = 22;
      this.lblBrewerKey.TextChanged += new System.EventHandler(this.lblBrewerKey_TextChanged);
      // 
      // lblBrewerProduction
      // 
      this.lblBrewerProduction.Location = new System.Drawing.Point(16, 240);
      this.lblBrewerProduction.Name = "lblBrewerProduction";
      this.lblBrewerProduction.Size = new System.Drawing.Size(64, 23);
      this.lblBrewerProduction.TabIndex = 31;
      this.lblBrewerProduction.Text = "Production";
      // 
      // lblBrewerCity
      // 
      this.lblBrewerCity.Location = new System.Drawing.Point(16, 208);
      this.lblBrewerCity.Name = "lblBrewerCity";
      this.lblBrewerCity.Size = new System.Drawing.Size(64, 23);
      this.lblBrewerCity.TabIndex = 29;
      this.lblBrewerCity.Text = "City";
      // 
      // lblBrewerZipCode
      // 
      this.lblBrewerZipCode.Location = new System.Drawing.Point(16, 176);
      this.lblBrewerZipCode.Name = "lblBrewerZipCode";
      this.lblBrewerZipCode.Size = new System.Drawing.Size(64, 23);
      this.lblBrewerZipCode.TabIndex = 27;
      this.lblBrewerZipCode.Text = "Zipcode";
      // 
      // lblBrewerAddress
      // 
      this.lblBrewerAddress.Location = new System.Drawing.Point(16, 144);
      this.lblBrewerAddress.Name = "lblBrewerAddress";
      this.lblBrewerAddress.Size = new System.Drawing.Size(64, 23);
      this.lblBrewerAddress.TabIndex = 25;
      this.lblBrewerAddress.Text = "Address";
      // 
      // lblBrewerName
      // 
      this.lblBrewerName.Location = new System.Drawing.Point(16, 112);
      this.lblBrewerName.Name = "lblBrewerName";
      this.lblBrewerName.Size = new System.Drawing.Size(64, 23);
      this.lblBrewerName.TabIndex = 23;
      this.lblBrewerName.Text = "Name";
      // 
      // lblKeyBrewer
      // 
      this.lblKeyBrewer.Location = new System.Drawing.Point(16, 80);
      this.lblKeyBrewer.Name = "lblKeyBrewer";
      this.lblKeyBrewer.Size = new System.Drawing.Size(32, 23);
      this.lblKeyBrewer.TabIndex = 21;
      this.lblKeyBrewer.Text = "Key";
      // 
      // cmdNew
      // 
      this.cmdNew.Location = new System.Drawing.Point(8, 40);
      this.cmdNew.Name = "cmdNew";
      this.cmdNew.TabIndex = 34;
      this.cmdNew.TabStop = false;
      this.cmdNew.Text = "New";
      this.cmdNew.Click += new System.EventHandler(this.cmdNew_Click);
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.Locale = new System.Globalization.CultureInfo("en-US");
      // 
      // frmBrewer
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(320, 273);
      this.Controls.Add(this.cmbFind);
      this.Controls.Add(this.cmdSave);
      this.Controls.Add(this.cmdDelete);
      this.Controls.Add(this.lblPosition);
      this.Controls.Add(this.cmdLast);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.cmdFirst);
      this.Controls.Add(this.txtBrewerProduction);
      this.Controls.Add(this.txtBrewerCity);
      this.Controls.Add(this.txtBrewerZipCode);
      this.Controls.Add(this.txtBrewerAddress);
      this.Controls.Add(this.txtBrewerName);
      this.Controls.Add(this.lblBrewerKey);
      this.Controls.Add(this.lblBrewerProduction);
      this.Controls.Add(this.lblBrewerCity);
      this.Controls.Add(this.lblBrewerZipCode);
      this.Controls.Add(this.lblBrewerAddress);
      this.Controls.Add(this.lblBrewerName);
      this.Controls.Add(this.lblKeyBrewer);
      this.Controls.Add(this.cmdNew);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBrewer";
      this.Text = "Brewer";
      this.Load += new System.EventHandler(this.frmBrewer_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBrewer'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBrewer()
      //***
      // Action
      //   - Create instance of 'frmBrewer'
      // Called by
      //   - frmMain.cmdBrewer_Click(System.Object, System.EventArgs) Handles cmdBrewer.Click
      //   - User action (Starting the form)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmBrewer()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
       
    private void cmdDelete_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Delete the current record
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsData, "tblCPBrewer"].RemoveAt(BindingContext[dsData, "tblCPBrewer"].Position);
    }
    // cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click

    private void cmdFirst_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Select the first record in the data set
      //     - Show the correct buttons
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - EnableCorrectButtons()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsData, "tblCPBrewer"].Position = 0;
      EnableCorrectButtons();    
    }
    // cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click

    private void cmdLast_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Select the last record in the data set
      //     - Show the correct buttons
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - EnableCorrectButtons()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsData, "tblCPBrewer"].Position = BindingContext[dsData, "tblCPBrewer"].Count - 1;
      EnableCorrectButtons();
    }
    // cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click

    private void cmdNew_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new record in the data set
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - EnableCorrectButtons()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsData, "tblCPBrewer"].AddNew();
      EnableCorrectButtons();
    }
    // cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click

    private void cmdNext_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Select the next record in the data set
      //     - Show the correct buttons
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - EnableCorrectButtons()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (BindingContext[dsData, "tblCPBrewer"].Position == BindingContext[dsData, "tblCPBrewer"].Count - 1)
      {
      }
      else
        // BindingContext[dsData, "tblCPBrewer"].Position <> BindingContext[dsData, "tblCPBrewer"].Count - 1
      {
        BindingContext[dsData, "tblCPBrewer"].Position += 1;
      }
      // BindingContext[dsData, "tblCPBrewer"].Position = BindingContext[dsData, "tblCPBrewer"].Count - 1

      EnableCorrectButtons();    
    }
    // cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click

    private void cmdPrevious_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Select the previous record in the data set
      //     - Show the correct buttons
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - EnableCorrectButtons()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (BindingContext[dsData, "tblCPBrewer"].Position == 0)
      {
      }
      else
        // BindingContext[dsData, "tblCPBrewer"].Position <> 0
      {
        BindingContext[dsData, "tblCPBrewer"].Position -= 1;
      }
      // BindingContext[dsData, "tblCPBrewer"].Position = 0

      EnableCorrectButtons();
    }
    // cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click

    private void cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Save the current record
      //   - Stop editing the data set
      //   - If there are changes
      //     - Define a new instance of cpCommand
      //     - Set the cursor to wait
      //     - Try to
      //       - Update the brewer data set thru the instance of the command
      //     - On possible error
      //       - Show the exception information
      //     - Set the cursor to default
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking the button)
      // Calls
      //   - bool cpCommand.UpdateBrewer(dsData)
      //   - cpCommand()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsData, "tblCPBrewer"].EndCurrentEdit();

      if (dsData.HasChanges())
      {
        cpCommand thecpCommand = new cpCommand();

        this.Cursor = Cursors.WaitCursor;

        try
        {
          thecpCommand.UpdateBrewer(dsData);
        }
        catch (Exception theException)
        {
          MessageBox.Show(theException.Message);
        }
        finally
        {
          this.Cursor = Cursors.Default;
        }

      }
      else
        // Not dsData.HasChanges()
      {
      }
      // dsData.HasChanges()
    
    }
    // cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click

    private void frmBrewer_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Preparing the form to show correct information about brewers
      //   - Define an instance of cpCommand
      //   - Try to
      //     - Find the Brewers Beers Typed data set (Brewers is True, Beers is False)
      //     - Merge it into the data set
      //     - Show the correct buttons
      //   - On possible error
      //     - Show exception message
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCommand()
      //   - dsData cpCommand.FindBrewerBeersTypedDataSet([bool], [bool])
      //   - EnableCorrectButtons()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpCommand thecpCommand = new cpCommand();

      try
      {
        dsData.Merge(thecpCommand.FindBrewerBeersTypedDataSet(true, false));
        EnableCorrectButtons();
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // frmBrewer_Load(System.Object, System.EventArgs) Handles MyBase.Load

    private void lblBrewerKey_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the current record index with the total of records
      // Called by
      //   - System action (Changing text of label)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblPosition.Text = BindingContext[dsData, "tblCPBrewer"].Position + 1 + "/" + BindingContext[dsData, "tblCPBrewer"].Count;
    }
    // lblBrewerKey_TextChanged(System.Object, System.EventArgs) Handles lblBrewerKey.TextChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void EnableCorrectButtons()
      //***
      // Action
      //   - Depending on the number of records
      //     - Make cmdFirst enabled
      //     - Make cmdPrevious enabled
      //     - Make cmdLast enabled
      //     - Make cmdNext enabled
      // Called by
      //   - cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click
      //   - cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click
      //   - cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      //   - cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click
      //   - cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click
      //   - frmBrewer_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (BindingContext[dsData, "tblCPBrewer"].Position == 0)
      {
        cmdFirst.Enabled = false;
        cmdPrevious.Enabled = false;
      }
      else
        // BindingContext[dsData, "tblCPBrewer"].Position <> 0
      {
        cmdFirst.Enabled = true;
        cmdPrevious.Enabled = true;
      }
      // BindingContext[dsData, "tblCPBrewer"].Position = 0

      if (BindingContext[dsData, "tblCPBrewer"].Position == BindingContext[dsData, "tblCPBrewer"].Count - 1)
      {
        cmdLast.Enabled = false;
        cmdNext.Enabled = false;
      }
      else
        // BindingContext[dsData, "tblCPBrewer"].Position <> BindingContext[dsData, "tblCPBrewer"].Count - 1
      {
        cmdLast.Enabled = true;
        cmdNext.Enabled = true;
      }
      // BindingContext[dsData, "tblCPBrewer"].Position = BindingContext[dsData, "tblCPBrewer"].Count - 1

    }
    // EnableCorrectButtons()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBrewer

}
// CopyPaste.Learning