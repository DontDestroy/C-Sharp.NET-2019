'***
' Action
'   - Define a class cpBook
' Created
'   - CopyPaste � 20220224 � VVDW
' Changed
'   - CopyPaste � yyyymmdd � VVDW � What changed
' Tested
'   - CopyPaste � 20220224 � VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On 
Option Strict On

Imports Microsoft.VisualBasic.ControlChars
Imports System.Windows.Forms

Namespace CopyPaste.Learning

  Public Class cpBook

#Region "Constructors / Destructors"

    Public Sub New(ByVal strTitle As String, ByVal strAuthor As String, ByVal strPublisher As String, ByVal dblPrice As Double)
      '***
      ' Action
      '   - Create an instance of a cpBook
      '   - Fill in the attributes / properties Price, Author, Publisher and Title
      ' Called by
      '   - Not documented here
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste � 20220224 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20220224 � VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      mdblPrice = dblPrice
      mstrAuthor = strAuthor
      mstrPublisher = strPublisher
      mstrTitle = strTitle
    End Sub
    ' New(String, String, String, Double)

#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

#Region "Fields"
    Public mdblPrice As Double
    Public mstrAuthor As String
    Public mstrPublisher As String
    Public mstrTitle As String
#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

    '#Region "Controls"
    '#End Region

#Region "Functionality"

    '#Region "Event"
    '#End Region

#Region "Sub / Function"

    Public Sub ShowBook()
      '***
      ' Action
      '   - Show a messagebox with the info of the instance of a cpBook()
      ' Called by
      '   - Not documented here
      ' Calls
      '   - MessageBox.Show(String) As DialogResult
      ' Created
      '   - CopyPaste � 20220224 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20220224 � VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      MessageBox.Show("Title: " & mstrTitle & CrLf & _
        "Author:" & mstrAuthor & CrLf & _
        "Publisher: " & mstrPublisher & CrLf & _
        "Price: " & mdblPrice)
    End Sub
    ' ShowBook()

#End Region

#End Region

#End Region

    '#Region "Not used"
    '#End Region

  End Class
  ' cpBook

End Namespace
' CopyPaste.Learning