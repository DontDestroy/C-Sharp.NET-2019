//***
// Action
//   - Save a type text to a textfile
// Created
//   - CopyPaste � 20230809 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � yyy20230809ymmdd � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSave : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    internal System.Windows.Forms.Button cmdSave;
    internal System.Windows.Forms.TextBox txtText;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSave));
      this.cmdSave = new System.Windows.Forms.Button();
      this.txtText = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdSave
      // 
      this.cmdSave.Location = new System.Drawing.Point(105, 24);
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.TabIndex = 2;
      this.cmdSave.Text = "Save to File";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(21, 80);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(250, 150);
      this.txtText.TabIndex = 3;
      this.txtText.Text = "";
      // 
      // frmSave
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdSave);
      this.Controls.Add(this.txtText);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSave";
      this.Text = "Save Form To File";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSave'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSave()
      //***
      // Action
      //   - Create instance of 'frmSave'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSave()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - A file save dialog box is defined
      //   - Needed parameters are set
      //     - By default is "C:\Temp" chosen
      //     - This becomes the normal documents folder if it does not exist
      //   - If 'OK' button is clicked
      //     - The type text is saved to a file defined in the file save dialog box
      //     - If successful, a message is shown
      //     - If not, an error message is shown
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      SaveFileDialog dlgFileSave = new SaveFileDialog();

      dlgFileSave.Filter = "All files | *.* | Text files | *.txt"; 
      dlgFileSave.FilterIndex = 2; 
      dlgFileSave.InitialDirectory = "C:\\Temp"; 
      dlgFileSave.AddExtension = true; 
      dlgFileSave.DefaultExt = "txt";

      if (dlgFileSave.ShowDialog() == DialogResult.OK)
      {
        StreamWriter strWriter = null;

        try
        {
          strWriter = new StreamWriter(dlgFileSave.FileName);

          try
          {            
            strWriter.Write(txtText.Text);
            strWriter.Close();
            MessageBox.Show("Text saved to " + dlgFileSave.FileName);
          }
          catch
          {
            MessageBox.Show("Error writing file");
          }
          finally
          {
          }

        }
        catch
        {
          MessageBox.Show("Error opening " + dlgFileSave.FileName + " for writing data.");
        }
        finally
        {
        }

      }
      else
        // dlgFileSave.ShowDialog() <> DialogResult.OK
      {
        MessageBox.Show("User selected Cancel");
      }
      // dlgFileSave.ShowDialog() = DialogResult.OK

    }
    // cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSave
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSave());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmSave

}
// CopyPaste.Learning