//***
// Action
//   - A piece of a game (Pawn)
// Created
//   - CopyPaste � 20240313 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240313 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Games
{

  public class cpPawn : cpiMoveable
  {

    #region "Constructors / Destructors"

    public cpPawn()
      //***
      // Action
      //   - Empty constructor
      // Called by
      //   - cpStartup.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpPawn()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    bool mblnCaptured = false;
    int mlngX = 0;
    int mlngY = 0;

    #endregion

    #region "Properties"

    public bool Captured
    {

      get
        //***
        // Action Get
        //   - Returns mblnCaptured
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240313 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240313 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mblnCaptured;
      }
      // bool Captured

      set
        //***
        // Action Set
        //   - mblnCaptured becomes value
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240313 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240313 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mblnCaptured = value;
      }
      // bool Captured

    }
    // bool Captured

    public int X
    {

      get
        //***
        // Action Get
        //   - Returns mlngX
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240313 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240313 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngX;
      }
      // int X (Get)

      set
        //***
        // Action Set
        //   - mlngX becomes lngValue
        // Called by
        //   - cpProgram.Main()
        //   - Move(cpDirection, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240313 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240313 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngX = value;
      }
      // X(int) (Set)

    }
    // int X

    public int Y
    {

      get
        //***
        // Action Get
        //   - Returns mlngY
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240313 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240313 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngY;
      }
      // int Y (Get)

      set
        //***
        // Action Set
        //   - mlngY becomes lngValue
        // Called by
        //   - cpProgram.Main()
        //   - Move(cpDirection, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240313 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240313 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngY = value;
      }
      // Y(int) (Set)

    }
    // int Y

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Move(cpDirection thecpDirection, int lngHowFar)
      //***
      // Action
      //   - The pawn can be moved
      //   - Depending on the direction, X and Y coordinates are changed
      //     - Up
      //       - Y is incremented with lngHowFar
      //     - Down
      //       - Y is decremented with lngHowFar
      //     - Left
      //       - X is decremented with lngHowFar
      //     - Right
      //       - X is incremented with lngHowFar
      //     - Other directions
      //       - Throw exception that the direction is unknown
      // Called by
      //   - 
      // Calls
      //   - X(int) (Set)
      //   - Y(int) (Set)
      // Created
      //   - CopyPaste � 20240313 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240313 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      switch (thecpDirection)
      {
        case cpDirection.Up:
          Y += lngHowFar;
          break;
        case cpDirection.Down:
          Y -= lngHowFar;
          break;
        case cpDirection.Left:
          X -= lngHowFar;
          break;
        case cpDirection.Right:
          X += lngHowFar;
          break;
        default:
          throw new System.Exception("The move direction is unknown");
      }
      // thecpDirection

    }
    // Move(cpDirection, int)
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPawn

}
// CopyPaste.Games