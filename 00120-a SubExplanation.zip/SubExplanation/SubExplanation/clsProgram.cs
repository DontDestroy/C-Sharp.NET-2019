//***
// Action
//   - Testroutine for cpBase and cpDerived
// Created
//   - CopyPaste � 20240617 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240617 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using CopyPaste.Learning;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create an instance of cpBase
      //   - Try to execute all routines that are possible
      //   - Create an instance of cpDerived
      //   - Try to execute all routines that are possible
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpBase()
      //   - cpBase.SubInternal()
      //   - cpBase.SubPrivate()
      //   - cpBase.SubProtected()
      //   - cpBase.SubProtectedInternal()
      //   - cpBase.SubPublic()
      //   - cpBase.SubTestBase()
      //   - cpDerived()
      //   - cpDerived.SubInternal()
      //   - cpDerived.SubProtectedInternal()
      //   - cpDerived.SubPublic()
      //   - cpDerived.SubTestDerived()
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBase thecpBase = new cpBase();
      cpDerived thecpDerived = new cpDerived();

      Console.WriteLine("Default startroutine in a module");
      Console.WriteLine();

      Console.WriteLine("Routines in base class");
      thecpBase.SubInternal();
      // thecpBase.SubPrivate();
      // thecpBase.SubProtected();
      thecpBase.SubProtectedInternal();
      thecpBase.SubPublic();
      Console.WriteLine();
      thecpBase.SubTestBase();
      Console.WriteLine();

      Console.WriteLine("Routines in derived class");
      thecpDerived.SubInternal();
      // thecpDerived.SubPrivate();
      // thecpDerived.SubProtected();
      thecpDerived.SubProtectedInternal();
      thecpDerived.SubPublic();
      Console.WriteLine();
      thecpDerived.SubTestDerived();
      Console.WriteLine();

      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning