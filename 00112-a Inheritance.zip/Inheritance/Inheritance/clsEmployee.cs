//***
// Action
//   - Implementation of a cpEmployee
// Created
//   - CopyPaste � 20240405 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240405 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Employee

{

  public class cpEmployee
  {

    #region "Constructors / Destructors"

    public cpEmployee() : this("Unknown", cpSex.Male, DateTime.Today)
      //***
      // Action
      //   - Default constructor
      // Called by
      //   - cpOffice()
      //   - cpProgram.Main()
      //   - cpWorker()
      // Calls
      //   - cpEmployee(string, cpSex, DateTime)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpEmployee()

    static cpEmployee()
      //***
      // Action
      //   - The company start date is put fixed to 15 october 1992
      //   - Default Shared / Static constructor
      //   - The company party is the first friday after the first of februari of this year
      // Called by
      //   - System action (first use of a cpEmployee)
      // Calls
      //   - CompanyParty(DateTime) (Set)
      //   - DateTime CompanyParty (Get)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      CompanyParty = Convert.ToDateTime(DateTime.Today.Year + "/2/1");

      while (CompanyParty.DayOfWeek != DayOfWeek.Friday)
      {
        CompanyParty = CompanyParty.AddDays(1);
      }
      // CompanyParty.DayOfWeek = DayOfWeek.Friday

    }
    // cpEmployee()

    public cpEmployee(string strName, cpSex theSex, DateTime dtmStartDate)
      //***
      // Action
      //   - Constructor with Name, Sex and StartDate
      // Called by
      //   - cpOffice(string, cpSex, DateTime, decimal)
      //   - cpWorker(string, cpSex, DateTime, decimal, byte)
      //   - cpEmployee()
      // Calls
      //   - Name(string) (Set)
      //   - Sex(cpSex) (Set)
      //   - StartDate(DateTime) (Set)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Name = strName;
      Sex = theSex;
      StartDate = dtmStartDate;
    }
    // cpEmployee(string, cpSex, DateTime)

    #endregion

    #region "Designer"

    public enum cpSex
    {
      Male,
      Female
    }
    // cpSex

    #endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpSex mcpSex;
    private static DateTime mdtmCompanyParty;
    private DateTime mdtmStart;
    private readonly DateTime mdtmStartCompany = new DateTime(1992, 10, 15);
    private string mstrName;

    #endregion

    #region "Properties"
    
    public static DateTime CompanyParty
    {

      get
        //***
        // Action Get
        //   - Returns mdtmCompanyParty
        // Called by
        //   - bool TodayIsParty (Get)
        //   - cpEmployee()
        //   - ShowInfo()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdtmCompanyParty;
      }
      // DateTime CompanyParty (Get)

      set
        //***
        // Action Set
        //   - mdtmCompanyParty becomes value
        // Called by
        //   - cpEmployee()
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mdtmCompanyParty = value;
      }
      // CompanyParty(DateTime) (Set)

    }
    // DateTime CompanyParty 

    public string Name
    {

      get
        //***
        // Action Get
        //   - Returns mstrName
        // Called by
        //   - ShowInfo()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

      set
        //***
        // Action Set
        //   - mstrName becomes value
        // Called by
        //   - cpEmployee(string, cpSex, DateTime)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    public cpSex Sex
    {

      get
        //***
        // Action Get
        //   - Returns mcpSex
        // Called by
        //   - ShowInfo()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mcpSex;
      }
      // cpSex Sex (Get)

      set
        //***
        // Action Set
        //   - mcpSex becomes value
        // Called by
        //   - cpEmployee(string, cpSex, DateTime)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mcpSex = value;
      }
      // Sex(cpSex) (Set)

    }
    // cpSex Sex

    public DateTime StartDate
    {

      get
        //***
        // Action Get
        //   - Returns mdtmStart
        // Called by
        //   - bool WorkAnniversary (Get)
        //   - ShowInfo()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdtmStart;
      }
      // DateTime StartDate (Get)

      set
        //***
        // Action Set
        //   - The startdate of a cpEmployee can't be before the startdate of the company
        //   - If so, the startdate of the cpEmployee becomes the startdate of the company
        // Called by
        //   - cpEmployee(string, cpSex, DateTime)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value >= mdtmStartCompany)
        {
          mdtmStart = value;
        }
        else
          // value < mdtmStartCompany
        {
          mdtmStart = mdtmStartCompany;
        }
        // value >= mdtmStartCompany

      }
      // StartDate(DateTime) (Set)

    }
    // DateTime StartDate

    public static bool TodayIsParty
    {

      get
        //***
        // Action Get
        //   - If today is the company party
        //     - Return true
        //   - If not
        //     - Return talse
        // Called by
        //   - ShowInfo()
        // Calls
        //   - DateTime CompanyParty (Get)
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        bool blnResult;

        blnResult = (CompanyParty == DateTime.Today);
        
        return blnResult;
      }
      // bool TodayIsParty (Get)

    }
    // bool TodayIsParty

    public bool WorkAnniversary
    {

      get
        //***
        // Action Get
        //   - If today is the exact day and month of you start at company party
        //     - Return True
        //   - If not
        //     - Return False
        // Called by
        //   - ShowInfo()
        // Calls
        //   - DateTime StartDate (Get)
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        bool blnResult;
        DateTime dtmDate;
        
        dtmDate = DateTime.Today;

        if ((StartDate.Month == dtmDate.Month) && (StartDate.Day == dtmDate.Day))
        {
          blnResult = true;
        }
        else
          // (StartDate.Month <> dtmDate.Month) OrElse (StartDate.Day <> dtmDate.Day)
        {
          blnResult = false;
        }
        // (StartDate.Month = dtmDate.Month) AndAlso (StartDate.Day = dtmDate.Day)

        return blnResult;
      }
      // bool WorkAnniversary (Get)

    }
    // bool WorkAnniversary

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public virtual void ShowInfo()
      //***
      // Action
      //   - Shows information to the console
      //     - Name, Sex, StartDate, Is it a Workanniversary, Is it CompanyParty
      // Called by
      //   - cpOffice.ShowInfo()
      //   - cpWorker.ShowInfo()
      //   - cpProgram.Main()
      // Calls
      //   - bool TodayIsParty (Get)
      //   - bool WorkAnniversary (Get)
      //   - cpSex Sex (Get)
      //   - DateTime CompanyParty (Get)
      //   - DateTime StartDate (Get)
      //   - string Name (Get)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine();
      Console.WriteLine("Name: {0}", Name);
      Console.WriteLine("Sex: {0}", Sex.ToString());
      Console.WriteLine("Start date: {0}", StartDate);
      Console.WriteLine("Needs to buy a cake: {0}", WorkAnniversary);
      Console.WriteLine("Today is company party {0}: {1}", CompanyParty, TodayIsParty);
    }
    // void ShowInfo()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpEmployee

}
// CopyPaste.Learning.Employee