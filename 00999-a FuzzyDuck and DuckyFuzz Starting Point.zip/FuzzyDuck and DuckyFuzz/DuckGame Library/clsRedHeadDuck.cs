﻿//***
// Action
//   - Implementation of a cpRedHeadDuck
//     - Inherits from cpDuck, where Display (how do I look like) is an abstract method
//       - All class that inherit from cpDuck must implement the Display method
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
//   - The sound that a cpRedHeadDuck makes is inherited
//     - All cpDuck and child classes make the same noise
//   - The way a cpRedHeadDuck moves on water is inherited
//     - All cpDuck and child classes moves on water the same way
//   - The way a cpRedHeadDuck moves on land is inherited
//     - All cpDuck and child classes that are living ducks moves on land the same way
// Created
//   - CopyPaste – 20240716 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240716 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Game.Duck.Library
{

	internal class cpRedHeadDuck : cpDuck
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpRedHeadDuck
		/// </summary>
		public cpRedHeadDuck() : base()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - User action (Creating an instance)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240716 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240716 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpRedHeadDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		#region "Overrides"

		/// <summary>
		/// The visualization (displaying) of a cpRedHeadDuck
		/// </summary>
		public override void Display()
		//***
		// Action
		//   - Define how a cpRedHeadDuck looks like
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240716 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240716 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Representation of a cpRedHeadDuck");
		}
		// Display()

		#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpRedHeadDuck

}
// CopyPaste.Game.Duck.Library