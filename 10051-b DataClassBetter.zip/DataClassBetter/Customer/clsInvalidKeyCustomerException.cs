﻿//***
// Action
//   - Define the Invalid Key Customer Exception
// Created
//   - CopyPaste – 20260121 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260121 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpInvalidKeyCustomerException: System.ApplicationException
  {

    #region "Constructors / Destructors"

    public cpInvalidKeyCustomerException(string strKeyCustomer): base("The customer key specified, " + strKeyCustomer + ", is not valid  (must be 5 long and unique).")
      //'***
      //' Action
      //'   - Define a new instance with a given string
      //' Called by
      //'   - cpCustomer(cpKeyCustomer, string)
      //'   - cpKeyCustomer.KeyCustomer(string) (Set)
      //' Calls
      //'   - 
      //' Created
      //'   - CopyPaste – 20260121 – VVDW
      //' Changed
      //'   - CopyPaste – yyyymmdd – VVDW – What changed
      //' Tested
      //'   - CopyPaste – 20260121 – VVDW
      //' Keyboard key
      //'   - 
      //' Proposal (To Do)
      //'   - 
      //'*** 
    {
    }
    // cpInvalidKeyCustomerException(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
		//#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpInvalidKeyCustomerException

}
// CopyPaste.Learning