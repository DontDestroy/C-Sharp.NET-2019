//***
// Action
//   - Show the differences between a queue and a stack
// Created
//   - CopyPaste � 20240228 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240228 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmQueueAndStack: System.Windows.Forms.Form
  {
    internal System.Windows.Forms.Button cmdStack;
    internal System.Windows.Forms.Button cmdQueue;

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmQueueAndStack));
      this.cmdStack = new System.Windows.Forms.Button();
      this.cmdQueue = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdStack
      // 
      this.cmdStack.Location = new System.Drawing.Point(18, 72);
      this.cmdStack.Name = "cmdStack";
      this.cmdStack.Size = new System.Drawing.Size(256, 32);
      this.cmdStack.TabIndex = 3;
      this.cmdStack.Text = "&Stack (Last in First out)";
      this.cmdStack.Click += new System.EventHandler(this.cmdStack_Click);
      // 
      // cmdQueue
      // 
      this.cmdQueue.Location = new System.Drawing.Point(18, 24);
      this.cmdQueue.Name = "cmdQueue";
      this.cmdQueue.Size = new System.Drawing.Size(256, 32);
      this.cmdQueue.TabIndex = 2;
      this.cmdQueue.Text = "&Queue (First in First out)";
      this.cmdQueue.Click += new System.EventHandler(this.cmdQueue_Click);
      // 
      // frmQueueAndStack
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdStack);
      this.Controls.Add(this.cmdQueue);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmQueueAndStack";
      this.Text = "Queues And Stacks";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmQueueAndStack'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmQueueAndStack()
      //***
      // Action
      //   - Create instance of 'frmQueueAndStack'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmQueueAndStack()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdQueue_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a queue
      //   - Add (enqueue) the words "It was the best of times." to it
      //     - Spaces and dot are added to the words
      //   - Loop thru the elements of the queue
      //     - Add the word to a string
      //   - Show the string in a messagebox
      //   - Loop thru the queue with an enumerator
      //     - Dequeue the word
      //     - Add the word to a string
      //   - Show the string in a messagebox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Queue theQueue = new Queue();
      string strString = "";

      theQueue.Enqueue("It ");
      theQueue.Enqueue("was ");
      theQueue.Enqueue("the ");
      theQueue.Enqueue("best ");
      theQueue.Enqueue("of ");
      theQueue.Enqueue("times.");

      foreach (string strQueueItem in theQueue)
      {
        strString += strQueueItem;
      }
      // in theQueue

      MessageBox.Show(strString + " Item Count: " + theQueue.Count, "Copy Paste Tryout: Queue - DeQueue");
      strString = "";

      while (theQueue.GetEnumerator().MoveNext())
      {
        strString += theQueue.Dequeue().ToString();
      }
      // theQueue.GetEnumerator().MoveNext()

      MessageBox.Show(strString + " Item Count: " + theQueue.Count, "Copy Paste Tryout: Queue - DeQueue");
    }
    // cmdQueue_Click(System.Object, System.EventArgs) Handles cmdQueue.Click

    private void cmdStack_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a stack
      //   - Add (Push) the words "It was the best of times." to it
      //     - Spaces and dot are added to the words
      //   - Loop thru the elements of the stack
      //     - Add the word to a string
      //   - Show the string in a messagebox
      //   - Loop thru the stack with an enumerator
      //     - Pop the word
      //     - Add the word to a string
      //   - Show the string in a messagebox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Stack theStack = new Stack();
      string strString = "";

      theStack.Push("It ");
      theStack.Push("was ");
      theStack.Push("the ");
      theStack.Push("best ");
      theStack.Push("of ");
      theStack.Push("times.");

      foreach (string strStackItem in theStack)
      {
        strString += strStackItem;
      }
      // In theStack

      MessageBox.Show(strString + " Item Count: " + theStack.Count, "Copy Paste Tryout: Push - Pop");
      strString = "";

      while (theStack.GetEnumerator().MoveNext())
      {
        strString += theStack.Pop().ToString();
      }
      // theStack.GetEnumerator.MoveNext

      MessageBox.Show(strString + " Item Count: " + theStack.Count, "Copy Paste Tryout: Push - Pop");
    }
    // cmdStack_Click(System.Object, System.EventArgs) Handles cmdStack.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmQueueAndStack
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmQueueAndStack());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmQueueAndStack

}
// CopyPaste.Learning