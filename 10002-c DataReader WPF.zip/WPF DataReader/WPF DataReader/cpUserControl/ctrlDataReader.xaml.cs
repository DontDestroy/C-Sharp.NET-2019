﻿//***
// Action
//   - Having a Data Reader towards a database
//   - Interaction logic for ctrlDataReader.xaml (part of MainWindow.xaml)
// Created
//   - CopyPaste – 20210819 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210819 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Controls;
using WPFDataReader.ViewModel;

namespace WPFDataReader.cpUserControl
{

  public partial class ctrlDataReader : UserControl
  {

    #region "Constructors / Destructors"

    public ctrlDataReader()
    //***
    // Action
    //   - Creating an instance of the WPF control
    //   - Initialize the components of that control
    //   - Define a cpDataReaderViewModel
    // Called by
    //   - User Action Or System action (Showing the control)
    //   - mnuDataReader_Click(System.Object, System.Windows.RoutedEventArgs) Handles mnuDataReader.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      InitializeComponent();
      _viewModel = (cpDataReaderViewModel)this.Resources["viewModel"];
    }
    // ctrlCommand()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private readonly cpDataReaderViewModel _viewModel;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdDataReader_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Get product list using a data reader
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - cpDataReaderViewModel.GetProductsAsDataReader()
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.GetProductsAsDataReader();
    }
    // cmdDataReader_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdDataReader.Click

    private void cmdExtensionMethods_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Get product list using an extension method
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - ObservableCollection<cpProduct> cpDataReaderViewModel.GetProductsUsingExtensionMethods()
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.GetProductsUsingExtensionMethods();
    }
    // cmdExtensionMethods_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdExtensionMethods.Click

    private void cmdFieldValue_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Get product list using a field value
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - ObservableCollection<cpProduct> cpDataReaderViewModel.GetProductsUsingFieldValue()
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.GetProductsUsingFieldValue();
    }
    // cmdFieldValue_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdFieldValue.Click

    private void cmdGenericList_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Get product list using a generic list
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - ObservableCollection<cpProduct> cpDataReaderViewModel.GetProductsAsGenericList()
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.GetProductsAsGenericList();
    }
    // cmdGenericList_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdGenericList.Click

    private void cmdMultipleResultSets_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Get product list and a product category list using extension method
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - cpDataReaderViewModel.GetMultipleResultSets()
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.GetMultipleResultSets();
    }
    // cmdMultipleResultSets_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdMultipleResultSets.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void OnAutoGeneratingColumn(System.Object theSender, DataGridAutoGeneratingColumnEventArgs theDataGridAutoGeneratingColumnEventArguments)
    //***
    // Action
    //   - Defining the column in a specific format for dates
    //   - If the Column is of PropertyType DateTime
    //     - Set a specific format (European date)
    // Called by
    //   - User Action Or System action (Showing the control)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Functionality fails if field is nullable (Retire is hardcoded)
    //***
    {

      if (theDataGridAutoGeneratingColumnEventArguments.PropertyType == typeof(System.DateTime))
      {
        (theDataGridAutoGeneratingColumnEventArguments.Column as DataGridTextColumn).Binding.StringFormat = "dd/MM/yyyy HH:mm:ss";
      }
      else
      // (theDataGridAutoGeneratingColumnEventArguments.PropertyType <> typeof(System.DateTime))
      {

        if (theDataGridAutoGeneratingColumnEventArguments.PropertyName == "Retire")
        {
          (theDataGridAutoGeneratingColumnEventArguments.Column as DataGridTextColumn).Binding.StringFormat = "dd/MM/yyyy HH:mm:ss";
        }
        else
        // (theDataGridAutoGeneratingColumnEventArguments.PropertyName <> "Retire")
        {
        }
        // (theDataGridAutoGeneratingColumnEventArguments.PropertyName = "Retire")

      }
      // (theDataGridAutoGeneratingColumnEventArguments.PropertyType = typeof(System.DateTime))

    }
    // OnAutoGeneratingColumn(System.Object, DataGridAutoGeneratingColumnEventArgs)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // ctrlDataReader

}
// WPFDataReader.cpUserControl