﻿//***
// Action
//   - A definition of a point (class)
// Created
//   - CopyPaste – 20260530 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260530 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpPoint
  {

    #region "Constructors / Destructors"

    public cpPoint(double dblX, double dblY)
    //***
    // Action
    //   - Basic constructor
    //   - A given X and Y coordinate
    // Called by
    //   -
    // Calls
    //   - double X (Get)
    //   - double Y (Get)
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      X = dblX;
      Y = dblY;
    }
    // cpPoint(double, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public double X { get; set; }
    // cpPoint(double, double)

    public double Y { get; set; }
    // cpPoint(double, double)

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpPoint

}
// CopyPaste.Learning