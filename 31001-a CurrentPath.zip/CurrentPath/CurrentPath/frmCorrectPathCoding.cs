//***
// Action
//   - Different methods to have a correct reference towards a picture
// Created
//   - CopyPaste � 20260715 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260715 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmCorrectPathCoding: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.PictureBox picLogo;
    internal System.Windows.Forms.Label lblInfo;
    internal System.Windows.Forms.Button cmdMethod3;
    internal System.Windows.Forms.Button cmdMethod2;
    internal System.Windows.Forms.Button cmdMethod1;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCorrectPathCoding));
      this.picLogo = new System.Windows.Forms.PictureBox();
      this.lblInfo = new System.Windows.Forms.Label();
      this.cmdMethod3 = new System.Windows.Forms.Button();
      this.cmdMethod2 = new System.Windows.Forms.Button();
      this.cmdMethod1 = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // picLogo
      // 
      this.picLogo.Location = new System.Drawing.Point(136, 72);
      this.picLogo.Name = "picLogo";
      this.picLogo.Size = new System.Drawing.Size(376, 168);
      this.picLogo.TabIndex = 9;
      this.picLogo.TabStop = false;
      // 
      // lblInfo
      // 
      this.lblInfo.BackColor = System.Drawing.SystemColors.Info;
      this.lblInfo.Location = new System.Drawing.Point(128, 24);
      this.lblInfo.Name = "lblInfo";
      this.lblInfo.Size = new System.Drawing.Size(384, 32);
      this.lblInfo.TabIndex = 8;
      this.lblInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cmdMethod3
      // 
      this.cmdMethod3.Location = new System.Drawing.Point(16, 120);
      this.cmdMethod3.Name = "cmdMethod3";
      this.cmdMethod3.Size = new System.Drawing.Size(75, 32);
      this.cmdMethod3.TabIndex = 7;
      this.cmdMethod3.Text = "Method 3";
      this.cmdMethod3.Click += new System.EventHandler(this.cmdMethod3_Click);
      this.cmdMethod3.GotFocus += new System.EventHandler(this.cmdMethod3_GotFocus);
      this.cmdMethod3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.cmdMethod3_MouseMove);
      // 
      // cmdMethod2
      // 
      this.cmdMethod2.Location = new System.Drawing.Point(16, 72);
      this.cmdMethod2.Name = "cmdMethod2";
      this.cmdMethod2.Size = new System.Drawing.Size(75, 32);
      this.cmdMethod2.TabIndex = 6;
      this.cmdMethod2.Text = "Method 2";
      this.cmdMethod2.Click += new System.EventHandler(this.cmdMethod2_Click);
      this.cmdMethod2.GotFocus += new System.EventHandler(this.cmdMethod2_GotFocus);
      this.cmdMethod2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.cmdMethod2_MouseMove);
      // 
      // cmdMethod1
      // 
      this.cmdMethod1.Location = new System.Drawing.Point(16, 24);
      this.cmdMethod1.Name = "cmdMethod1";
      this.cmdMethod1.Size = new System.Drawing.Size(75, 32);
      this.cmdMethod1.TabIndex = 5;
      this.cmdMethod1.Text = "Method 1";
      this.cmdMethod1.Click += new System.EventHandler(this.cmdMethod1_Click);
      this.cmdMethod1.GotFocus += new System.EventHandler(this.cmdMethod1_GotFocus);
      this.cmdMethod1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.cmdMethod1_MouseMove);
      // 
      // frmCorrectPathCoding
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(536, 273);
      this.Controls.Add(this.picLogo);
      this.Controls.Add(this.lblInfo);
      this.Controls.Add(this.cmdMethod3);
      this.Controls.Add(this.cmdMethod2);
      this.Controls.Add(this.cmdMethod1);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCorrectPathCoding";
      this.Text = "Never hard code paths";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmCorrectPathCoding'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmCorrectPathCoding()
      //***
      // Action
      //   - Create instance of 'frmCorrectPathCoding'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmCorrectPathCoding()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdMethod1_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a fixed path
      //   - Try to show the logo
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ShowLogo(String)
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strLogoPath = "C:\\CopyPaste.jpg";
      ShowLogo(strLogoPath);
    }
    // cmdMethod1_Click(System.Object, System.EventArgs) Handles cmdMethod1.Click

    private void cmdMethod1_GotFocus(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a button
      //   - Set the button as the one that goto the focus
      //   - Show information about that button
      // Called by
      //   - User action (Focusing a button)
      // Calls
      //   - ShowInfo(String)
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Button theButton;

      theButton = (Button)theSender;
      ShowInfo(theButton.Name);
    }
    // cmdMethod1_GotFocus(System.Object, System.EventArgs) Handles cmdMethod1.GotFocus

    private void cmdMethod1_MouseMove(System.Object theSender, System.Windows.Forms.MouseEventArgs theMouseEventArguments)
      //***
      // Action
      //   - Define a button
      //   - Set the button as the one that goto the focus
      //   - Show information about that button
      // Called by
      //   - User action (Hoover over a button)
      // Calls
      //   - ShowInfo(String)
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Button theButton;

      theButton = (Button)theSender;
      ShowInfo(theButton.Name);
    }
    // cmdMethod1_MouseMove(System.Object, System.Windows.Forms.MouseEventArgs) Handles cmdMethod1.MouseMove

    private void cmdMethod2_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a path
      //   - Get the location of the current application
      //   - Use the logo path to make a path for the logo
      //   - Show the logo
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ShowLogo(String)
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strLogoPath;

      strLogoPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
      strLogoPath = System.IO.Path.GetDirectoryName(strLogoPath) + "\\CopyPaste.jpg";
      
      ShowLogo(strLogoPath);
    }
    // cmdMethod2_Click(System.Object, System.EventArgs) Handles cmdMethod2.Click

    private void cmdMethod2_GotFocus(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a button
      //   - Set the button as the one that goto the focus
      //   - Show information about that button
      // Called by
      //   - User action (Focusing a button)
      // Calls
      //   - ShowInfo(String)
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Button theButton;

      theButton = (Button)theSender;
      ShowInfo(theButton.Name);
    }
    // cmdMethod2_GotFocus(System.Object, System.EventArgs) Handles cmdMethod2.GotFocus

    private void cmdMethod2_MouseMove(System.Object theSender, System.Windows.Forms.MouseEventArgs theMouseEventArguments)
      //***
      // Action
      //   - Define a button
      //   - Set the button as the one that goto the focus
      //   - Show information about that button
      // Called by
      //   - User action (Hoover over a button)
      // Calls
      //   - ShowInfo(String)
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Button theButton;

      theButton = (Button)theSender;
      ShowInfo(theButton.Name);
    }
    // cmdMethod2_MouseMove(System.Object, System.Windows.Forms.MouseEventArgs) Handles cmdMethod2.MouseMove

    private void cmdMethod3_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a logo path
      //   - Define an assembly
      //   - Initialize the assembly
      //   - Get the name of the assembly
      //   - Define a stream (for the logo)
      //   - Define a resource name (for the logo)
      //   - Get the stream of the logo resource
      //   - Show the logo (as stream)
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ShowLogo(System.IO.Stream)
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      System.Reflection.Assembly theAssembly;

      theAssembly = System.Reflection.Assembly.GetExecutingAssembly();

      string strAssemblyName = theAssembly.GetName().Name;
      System.IO.Stream theLogoStream;
      string strLogoResourceName;

      strLogoResourceName = strAssemblyName + "." + "CopyPaste.JPG";
      theLogoStream = theAssembly.GetManifestResourceStream(strLogoResourceName);
      ShowLogo(theLogoStream);
    }
    // cmdMethod3_Click(System.Object, System.EventArgs) Handles cmdMethod3.Click

    private void cmdMethod3_GotFocus(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a button
      //   - Set the button as the one that goto the focus
      //   - Show information about that button
      // Called by
      //   - User action (Focusing a button)
      // Calls
      //   - ShowInfo(String)
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Button theButton;

      theButton = (Button)theSender;
      ShowInfo(theButton.Name);
    }
    // cmdMethod3_GotFocus(System.Object, System.EventArgs) Handles cmdMethod3.GotFocus

    private void cmdMethod3_MouseMove(System.Object theSender, System.Windows.Forms.MouseEventArgs theMouseEventArguments)
      //***
      // Action
      //   - Define a button
      //   - Set the button as the one that goto the focus
      //   - Show information about that button
      // Called by
      //   - User action (Hoover over a button)
      // Calls
      //   - ShowInfo(String)
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Button theButton;

      theButton = (Button)theSender;
      ShowInfo(theButton.Name);
    }
    // cmdMethod3_MouseMove(System.Object, System.Windows.Forms.MouseEventArgs) Handles cmdMethod3.MouseMove

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmCorrectPathCoding
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmCorrectPathCoding()
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmCorrectPathCoding());
    }
    // Main() 
    
    private void ShowInfo(string strControlName)
      //***
      // Action
      //   - Depending on the strControlName
      //     - Show a corresponding message in label on the screen
      // Called by
      //   - cmdMethod1_GotFocus(System.Object, System.EventArgs) Handles cmdMethod1.GotFocus
      //   - cmdMethod1_MouseMove(System.Object, System.Windows.Forms.MouseEventArgs) Handles cmdMethod1.MouseMove
      //   - cmdMethod2_GotFocus(System.Object, System.EventArgs) Handles cmdMethod2.GotFocus
      //   - cmdMethod2_MouseMove(System.Object, System.Windows.Forms.MouseEventArgs) Handles cmdMethod2.MouseMove
      //   - cmdMethod3_GotFocus(System.Object, System.EventArgs) Handles cmdMethod3.GotFocus
      //   - cmdMethod3_MouseMove(System.Object, System.Windows.Forms.MouseEventArgs) Handles cmdMethod3.MouseMove
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      switch (strControlName)
      {
        case "cmdMethod1":
          lblInfo.Text = "Using a fixed path";
          break;
        case "cmdMethod2":
          lblInfo.Text = "Using the actual path of the executable";
          break;
        case "cmdMethod3":
          lblInfo.Text = "Using a resource file";
          break;
      }
      // strControlName
       
    }
    // ShowInfo(string)

    private void ShowLogo(System.IO.Stream theStream)
      //***
      // Action
      //   - Show a logo with a given stream
      // Called by
      //   - cmdMethod3_Click(System.Object, System.EventArgs) Handles cmdMethod3.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Bitmap theImage;

      theImage = new Bitmap(theStream);
      picLogo.Image = theImage;
    }
    // ShowLogo(System.IO.Stream)

    private void ShowLogo(string strPath)
      //***
      // Action
      //   - Try to
      //     - Show a logo with a given path
      //   - On possible error
      //     - Show the error and the path that was used
      // Called by
      //   - cmdMethod1_Click(System.Object, System.EventArgs) Handles cmdMethod1.Click
      //   - cmdMethod2_Click(System.Object, System.EventArgs) Handles cmdMethod2.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        picLogo.Image = Image.FromFile(strPath);
      }
      catch
      {
        string strMessage;
        
        strMessage = "There was an error in finding the logo" + Environment.NewLine + strPath;
        MessageBox.Show(strMessage, "Copy Paste", MessageBoxButtons.OK, MessageBoxIcon.Stop);
      }
      
    }
    // ShowLogo(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmCorrectPathCoding

}
// CopyPaste.Learning