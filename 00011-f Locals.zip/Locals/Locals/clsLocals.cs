//***
// Action
//   - Working with local variables
// Created
//   - CopyPaste � 20220128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220128 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Locals
{

	class cpLocals
	{

    static void Main()
    //***
    // Action
    //   - Define and initialize variable (lngCounter)
    //   - Write value at console screen
    //   - Call routine
    //   - Write value at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(long)
    //   - theRoutine()
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter = 10;
      
      Console.WriteLine(lngCounter);
      theRoutine();
      Console.WriteLine(lngCounter);
      Console.ReadLine();
    }
    // Main()

    static void theRoutine()
    //***
    // Action
    //   - Define and initialize variable (lngCounter)
    //   - Write value at console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(long)
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter = 20;
      
      Console.WriteLine(lngCounter);
    }
    // theRoutine()

  }
  // cpLocals

}
// Locals