//***
// Action
//   - A form with the logical error corrected
// Created
//   - CopyPaste � 20230808 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230808 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDebugTest : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.Button cmdTest;
    internal System.Windows.Forms.TextBox txtResult;
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.TextBox txtQuestion;
    internal System.Windows.Forms.Label lblQuestion;
    internal System.Windows.Forms.Label lblTitle;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.cmdExit = new System.Windows.Forms.Button();
      this.cmdTest = new System.Windows.Forms.Button();
      this.txtResult = new System.Windows.Forms.TextBox();
      this.lblResult = new System.Windows.Forms.Label();
      this.txtQuestion = new System.Windows.Forms.TextBox();
      this.lblQuestion = new System.Windows.Forms.Label();
      this.lblTitle = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdExit
      // 
      this.cmdExit.Location = new System.Drawing.Point(256, 108);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.Size = new System.Drawing.Size(72, 24);
      this.cmdExit.TabIndex = 13;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // cmdTest
      // 
      this.cmdTest.Location = new System.Drawing.Point(256, 60);
      this.cmdTest.Name = "cmdTest";
      this.cmdTest.Size = new System.Drawing.Size(72, 24);
      this.cmdTest.TabIndex = 12;
      this.cmdTest.Text = "&Test";
      this.cmdTest.Click += new System.EventHandler(this.cmdTest_Click);
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(56, 116);
      this.txtResult.Name = "txtResult";
      this.txtResult.Size = new System.Drawing.Size(144, 20);
      this.txtResult.TabIndex = 11;
      this.txtResult.Text = "";
      // 
      // lblResult
      // 
      this.lblResult.Location = new System.Drawing.Point(48, 100);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(152, 16);
      this.lblResult.TabIndex = 10;
      this.lblResult.Text = "Result";
      // 
      // txtQuestion
      // 
      this.txtQuestion.Location = new System.Drawing.Point(56, 60);
      this.txtQuestion.Name = "txtQuestion";
      this.txtQuestion.Size = new System.Drawing.Size(144, 20);
      this.txtQuestion.TabIndex = 9;
      this.txtQuestion.Text = "0";
      // 
      // lblQuestion
      // 
      this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
      this.lblQuestion.Location = new System.Drawing.Point(48, 44);
      this.lblQuestion.Name = "lblQuestion";
      this.lblQuestion.Size = new System.Drawing.Size(120, 16);
      this.lblQuestion.TabIndex = 8;
      this.lblQuestion.Text = "How old are you?";
      // 
      // lblTitle
      // 
      this.lblTitle.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblTitle.Location = new System.Drawing.Point(40, 20);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(336, 24);
      this.lblTitle.TabIndex = 7;
      this.lblTitle.Text = "Debug Test: Can you find the error?";
      // 
      // frmDebugTest
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(392, 157);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.cmdTest);
      this.Controls.Add(this.txtResult);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.txtQuestion);
      this.Controls.Add(this.lblQuestion);
      this.Controls.Add(this.lblTitle);
      this.Name = "frmDebugTest";
      this.Text = "Debug Test";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDebugTest'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDebugTest()
      //***
      // Action
      //   - Create instance of 'frmDebugTest'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDebugTest()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stops the application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit.Click

    private void cmdTest_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Convert the input text to an integer
      //   - If test on criteria is true
      //     - Show "You are a teenager"
      //   - If not
      //     - Show "You are not a teenager"
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngAge;

      lngAge = Convert.ToInt32(txtQuestion.Text);

      if (lngAge > 13 && lngAge < 20)
      {
        txtResult.Text = "You are a teenager";
      }
      else
        // lngAge <= 13 || lngAge >= 20
      {
        txtResult.Text = "You are not a teenager";
      }
      // lngAge > 13 && lngAge < 20
    
    }
    // cmdTest_Click(System.Object, System.EventArgs) Handles cmdTest.Click

    private void frmDebugTest_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - 
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmDebugTest_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDebugTest
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDebugTest());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmDebugTest

}
// CopyPaste.Learning