//***
// Action
//   - Variable and overloaded functions
// Created
//   - CopyPaste � 20210823 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210823 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace LookAtVariable
{

  class cpLookAtVariable
	{

		static void Main()
    //***
    // Action
    //   - Initialize variables
    //   - Show messages at console screen
    //   - Wait for user action
    // Called by
    //   - 
    // Calls
    //   - System.Consoel.WriteLine(int)
    //   - System.Console.WriteLine(long)
    //   - System.Console.WriteLine(string)
    //   - System.Console.ReadLine()
    // Created
    //   - CopyPaste � 20210823 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210823 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int intInteger = 12;
      string strString = "This is a string.";
      long lngLong = 12345;

      Console.WriteLine(intInteger);
      Console.WriteLine(strString);
      Console.WriteLine(lngLong);
      Console.ReadLine();
    }
    // Main()

  }
  // cpLookAtVariable

}
// LookAtVariable