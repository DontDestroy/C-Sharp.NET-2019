﻿//***
// Action
//   - Show the details of Product
// Created
//   - CopyPaste – 20260409 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260409 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Controls;

namespace ProductCategory_WPF_MVVM.Views
{

  public partial class ctrlProductDetails : UserControl
  {

    #region "Constructors / Destructors"

    public ctrlProductDetails()
    //***
    // Action
    //   - Create an instance of ctrlProductDetails
    // Called by
    //   - wpfStartupScreen
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260409 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260409 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***

    {
      InitializeComponent();
    }
    // ctrlProductDetails()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // ctrlProductDetails

}
// ProductCategory_WPF_MVVM.Views