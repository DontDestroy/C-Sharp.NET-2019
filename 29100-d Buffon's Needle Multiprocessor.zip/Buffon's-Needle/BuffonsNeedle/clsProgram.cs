﻿//***
// Action
//   - Calculate an estimation of Pi by using the Buffons Needle algorithm
//   - Look on the website for the explanation of Buffons Needle
// Created
//   - CopyPaste – 20260811 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260811 – VVDW
// Proposal (To Do)
//   - We decided to calculate the crossing of a line with the cosinus
//   - In most documentations the middle of the needle is taken and then a calculation with 1/2 sin(angle)
//   - We used the top of the needle and a cosinus of the angle to calculated if there is a crossing
//***

using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260811 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260811 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    const int intAngleCount = 36_000;
    private static double[] dblarrcosTable = new double[intAngleCount];

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private static void DisplayInfo(long lngDrops, long lngHits)
    //***
    // Action
    //   - Showing the calculation of the estimation of PI
    //   - Pi becomes two times the number of drops divided by the number of hits (crossing a line)
    //   - Console is cleared
    //   - Number of drops is shown
    //   - Number of hits is shown
    //   - Estimation of PI is shown
    //   - The delta of the real PI is shown
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260811 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260811 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      double dblPi;

      dblPi = 2.0D * lngDrops / lngHits;
      Console.Clear();
      Console.WriteLine("Drops :  {0}", lngDrops.ToString("N0"));
      Console.WriteLine("Hits  :  {0}", lngHits.ToString("N0"));
      Console.WriteLine("Pi    :  {0}", dblPi);
      Console.WriteLine("Pi dt  :  {0:#,##0.0000000000}", Math.Abs(dblPi - Math.PI));
    }
    // DisplayInfo(long, long)

    private static void FillCosTable()
    //***
    // Action
    //   - 36_000 cosinus angles were calculated in advance and placed in a table
    //   - This is faster than calculate the cosinus 500_000_000 times
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260811 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260811 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      const double dblStep = 2.0 * Math.PI / intAngleCount;
      int intCounter;

      for (intCounter = 0; intCounter < intAngleCount; intCounter++)
      {
        dblarrcosTable[intCounter] = Math.Cos(intCounter * dblStep);
      }
      // intCounter = intAngleCount

    }
    // FillCosTable()

    static void Main()
    //***
    // Action
    //   - Set the number of drops to a half billion (miljard)
    //   - Start a stopwatch
    //   - Fill the table of all cosinus calculations
    //   - Split the functionality into the number of processors
    //     - Calculate the from (start) till to (end)
    //     - Loop thru from start till end
    //       - Get a random double (to have the top of the position where the needle fell)
    //       - Get a random integer (to have the angle of the needle)
    //       - Calculation the position of the end of the needle to see if it crosses a line
    //       - If calculation is <= 0 or >= 1 (then is crosses a line)
    //         - Increment number of hits
    //   - Add all results of the different processors together 
    //   - Stop the stopwatch
    //   - Show the elapsed seconds
    //   - Wait for user interaction
    // Called by
    //   - 
    // Calls
    //   - DisplayInfo(long, long)
    //   - double NextDoubleRandomPersonal() (Commented)
    //   - FillCosTable()
    //   - int NextIntegerRandomPersonal() (Commented)
    // Created
    //   - CopyPaste – 20260811 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260811 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Code in comment is informative
    //     - Compare the functionality using Random()
    //***
    {
      const long lngAmountOfDrops = 500_000_000;
      long lngHits;

      Stopwatch swWatch = new Stopwatch();
      swWatch.Start();
      FillCosTable();

      lngHits = 0;

      Parallel.For( // VVDW - I will use the maximum number of processors available on the pc
        0, // VVDW - Inclusive
        Environment.ProcessorCount, // VVDW - Exclusive
        () => 0L, // VVDW - Action Initializer (Starting with result zero
        (intThreadId, parloopState, lngLocalHits) => // VVDW - Action in thread that returns the number of hits in that thread
        {
          double dblValue;
          double dblX1;
          double dblX2;
          int intAngle;
          int intProcessors;
          long lngStartDrop;
          long lngEndDrop;
          uint uintSeed = (uint)DateTime.Now.Ticks;
          ulong ulngBits;
          ulong ulngProduct;
          ulong ulngSeed = (ulong)DateTime.Now.Ticks;

          intProcessors = Environment.ProcessorCount;
          lngStartDrop = lngAmountOfDrops * intThreadId / intProcessors;
          lngEndDrop = lngAmountOfDrops * (intThreadId + 1) / intProcessors;

          for (long lngLoop = lngStartDrop; lngLoop < lngEndDrop; lngLoop++)
          {
            // VVDW - Attempt to kill Random() :-)
            ulngSeed ^= ulngSeed << 13;
            ulngSeed ^= ulngSeed >> 7;
            ulngSeed ^= ulngSeed << 17;
            ulngBits = 0x3FF0000000000000UL | (ulngSeed & 0x000FFFFFFFFFFFFFUL);
            dblValue = Unsafe.As<ulong, double>(ref ulngBits);
            dblX1 = dblValue - 1.0D;

            uintSeed ^= uintSeed << 13;
            uintSeed ^= uintSeed >> 17;
            uintSeed ^= uintSeed << 5;
            ulngProduct = (ulong)uintSeed * intAngleCount;
            // VVDW - The biggest number you can get is intAngleCount - 1
            intAngle = (int)(ulngProduct >> 32);

            dblX2 = dblX1 + dblarrcosTable[intAngle];

            if (dblX2 <= 0 || dblX2 >= 1)
            {
              lngLocalHits++;
            }

          }
          // lngLoop = lngEndDrop

          return lngLocalHits;
        },
        lngLocalHits => // VVDW - Action Finalizer - All hits from the different thread are added
        {
          Interlocked.Add(ref lngHits, lngLocalHits);
        });

      DisplayInfo(lngAmountOfDrops, lngHits);
      swWatch.Stop();

      Console.WriteLine("Elapsed : {0} seconds", swWatch.ElapsedMilliseconds / 1000D);
      Console.ReadKey();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning