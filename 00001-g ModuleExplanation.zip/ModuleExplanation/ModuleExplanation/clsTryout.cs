//***
// Action
//   - One public and one friend module with one procedure
// Created
//   - CopyPaste � 20210823 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210823 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace ModuleExplanation
{

  public class cpTryout
	{

    public void ThisIsPublic()
    //***
    // Action
    //   - Write message to console
    //   - Wait for user action
    // Called by
    //   - cpModuleExplanation.Main() 
    // Calls
    //   - System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20210823 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210823 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Console.WriteLine("This is a public routine (visible to all applications)");
      Console.ReadLine();
    }
    // ThisIsPublic()

    internal void ThisIsInternal()
    //***
    // Action
    //   - Write message to console
    //   - Wait for user action
    // Called by
    //   - cpModuleExplanation.Main() 
    // Calls
    //   - System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20210823 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20210823 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Console.WriteLine("This is an internal routine (visible to the project)");
      Console.ReadLine();
    }
    // ThisIsInternal()

  }
  // cpTryout

}
// ModuleExplanation