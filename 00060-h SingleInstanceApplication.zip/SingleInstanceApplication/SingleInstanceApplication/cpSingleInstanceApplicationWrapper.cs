//***
// Action
//   - Startup class
//   - A Main() is created, because the App.xaml is removed
//   - the App is constructed with code
// Created
//   - CopyPaste � 20220817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220817 � VVDW
// Proposal (To Do)
//   - The cpDoc file extension must be manually connected to this application
//   - It should be a good idea to do this with code when the application starts up
//   - This is changing something in the registry of Windows
//   - You don't always have the rights to change this
//   - I have decided not to give this in the example, because this is not the goal of the exercise
//***

using System;

namespace SingleInstanceApplication
{

  public class cpSingleInstanceApplicationWrapper : Microsoft.VisualBasic.ApplicationServices.WindowsFormsApplicationBase
  {

    #region "Constructors / Destructors"

    public cpSingleInstanceApplicationWrapper()
    //***
    // Action
    //   - We use the boolean IsSingleInstance from WindowsFormsApplicationBase to determine
    //     if the application can be started one than once
    // Called by
    //   - Main(string[])
    // Calls
    //   - cpSingleInstanceApplicationWrapper()
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      this.IsSingleInstance = true;
    }
    // cpSingleInstanceApplicationWrapper()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpwpfApplication theWPFApplication;
    // The 3 next variables are not used, but are informative on the functionality that is manually done
    // They will be used when the extension (cpDoc) is automatically connected to the application
    // This is not implemented on purpose
    string strExtension = ".cpDoc";
    string strTitle = "SingleInstanceApplication";
    string strExtensionDescription = "A Test Document with cpDoc extension";

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override bool OnStartup(Microsoft.VisualBasic.ApplicationServices.StartupEventArgs theStartupEventArguments)
    //***
    // Action
    //   - This will be runned when you startup for the first time the application
    //   - The application is started by opening a document of a certain type
    //   - Returns false
    // Called by
    //   - User action (Starting the application, by opening a file)
    // Calls
    //   - cpwpfApplication()
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theWPFApplication = new cpwpfApplication();
      theWPFApplication.Run();

      return false;
    }
    // OnStartup(Microsoft.VisualBasic.ApplicationServices.StartupEventArgs)

    protected override void OnStartupNextInstance(Microsoft.VisualBasic.ApplicationServices.StartupNextInstanceEventArgs theStartupNextInstanceEventArguments)
    //***
    // Action
    //   - This will be runned when you startup for the next time (not the first time) the application
    //   - The application is started by opening a document of a certain type
    // Called by
    //   - User action (Starting the application, by opening a file)
    //   - But the application is already started
    // Calls
    //   - cpwpfApplication.ShowDocument(string)
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (theStartupNextInstanceEventArguments.CommandLine.Count > 0)
      {
        theWPFApplication.ShowDocument(theStartupNextInstanceEventArguments.CommandLine[0]);
      }
      // theStartupNextInstanceEventArguments.CommandLine.Count > 0

    }
    // OnStartupNextInstance(Microsoft.VisualBasic.ApplicationServices.StartupNextInstanceEventArgs)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // SingleInstanceApplicationWrapper

}
// SingleInstanceApplication