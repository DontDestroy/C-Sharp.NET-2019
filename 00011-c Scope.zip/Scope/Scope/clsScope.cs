//***
// Action
//   - Example of showing the scope of variables
// Created
//   - CopyPaste � 20220128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220128 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Scope
{

  class cpScope
	{
    static long lngCounter;
    // static long mlngCounter;

    static void BigLoop()
    //***
    // Action
    //   - Loop from 1000 to 1005 (lngCounter)
    //     - Write 'lngCounter' at console screen
    //   - Goto new line in console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.Write(string)
    //   - System.Console.WriteLine()
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   - Do the type declaration in the for loop away, and see what happens
    //***
    {
      for (long lngCounter = 1000; lngCounter <= 1005; lngCounter++)
      {
        Console.Write(lngCounter + " ");
      }
      // lngCounter = 1006

      Console.WriteLine();
    }
    // BigLoop()

    static void LittleLoop()
    //***
    // Action
    //   - Define variable (lngCounter)
    //   - Loop from 0 to 5 (lngCounter)
    //     - Write 'lngCounter' at console screen
    //   - Goto new line in console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.Write(string)
    //   - System.Console.WriteLine()
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter;

      for (lngCounter = 0; lngCounter <= 5; lngCounter++)
      {
        Console.Write(lngCounter + " ");
      }
      // lngCounter = 6

      Console.WriteLine();
    }
    // LittleLoop()

    static void Main()
    //***
    // Action
    //   - Define variable (lngCounter)
    //   - Show value at console screen
    //   - Do the big loop
    //   - Show value at console screen
    //   - Do the little loop
    //   - Show value at console screen
    //   - If lngCounter > 1000
    //     - Define variable (lngCounter)
    //     - Show value at console screen
    //   - Show value at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - BigLoop()
    //   - LittleLoop()
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      lngCounter = 100;

      Console.WriteLine("Starting Counter: " + lngCounter);
      BigLoop();
      Console.WriteLine("Counter after BigLoop: " + lngCounter);
      LittleLoop();
      Console.WriteLine("Counter after LittleLoop: " + lngCounter);
      
      if (lngCounter > 1000)
      {
        // long lngCounter = 0;
        
        Console.WriteLine("Counter in If statement: " + lngCounter);
      }
      else
        // lngCounter <= 1000
      {
      }
        // lngCounter > 1000

      Console.WriteLine("Ending Counter: " + lngCounter);
      Console.ReadLine();
    }
    // Main()

  }
  // cpScope

}
// Scope