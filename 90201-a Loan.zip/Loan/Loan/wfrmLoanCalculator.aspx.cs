﻿//***
// Action
//   - Starting form, asking for information to do a calculation
//   - There are some labels
//   - There are some text boxes
//   - There is a drop down list
//   - There is a button
//   - There are validators (rangevalidators, requiredfieldvalidator and regularexpressionvalidator)
//   - There is a hyperlink
//   - All is forced towards Belgium formatting (€, . as thousand separator and , as decimal symbol)
// Created
//   - CopyPaste – 20260423 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260423 – VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmLoanCalculator : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cmdCalculate.Click += new System.EventHandler(this.cmdCalculate_Click);
      this.ID = "wfrmLoanCalculator";
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260423 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260423 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdCalculate_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Calculate the monthy payment
    //   - Enable the hyperlink
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - CalculatePayment()
    // Created
    //   - CopyPaste – 20260423 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260423 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      CalculatePayment();
      hypSchedule.Enabled = true;
    }
    // cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - If it is the first time you render the page
    //     - Select first element in combo box
    //     - Disable the hyperlink
    //   - If not (loaded by a client postback)
    //     - Do nothing
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260423 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260423 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (IsPostBack)
      {
      }
      else
      // Not IsPostBack
      {
        cmbTerm.SelectedIndex = 0;
        hypSchedule.Enabled = false;
      }
      // IsPostBack

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void CalculatePayment()
    //***
    // Action
    //   - Define and initialize a Belgian culture info
    //   - Define and initialize the loan amount
    //   - Define and initialize the number of monthly terms
    //   - Define and initialize the wanted number format
    //   - Define and initialize the interest rate (Convert from the correct Belgian number format)
    //   - Define and initialize the monthly payment (Payment is done at the end of the period)
    //   - Set the result on the form in the correct format (Belgian number format)
    //   - Cache the needed data (Loan amount, rate, terms and monthy payments)
    // Called by
    //   - cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260423 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260423 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      CultureInfo culinfBelgium = new CultureInfo("fr-BE", false);
      int intLoanAmount = Convert.ToInt32(txtAmount.Text);
      int intTerm = Convert.ToInt32(cmbTerm.SelectedItem.Value);
      NumberFormatInfo nfiBelgium = culinfBelgium.NumberFormat;
      Single sngRate = Convert.ToSingle(Convert.ToDouble(txtRate.Text, nfiBelgium) / 100);
      // The given rate is forced to Belgian formatting using a Regular Expression validator
      Single sngPayment = Convert.ToSingle(Financial.Pmt(sngRate / 12, intTerm, -intLoanAmount, 0, DueDate.EndOfPeriod));

      lblMonthly.Text = "Monthly Payment: " + Math.Round(sngPayment, 2).ToString("€ #,##0.00", nfiBelgium);

      Cache["cpLoanAmount"] = intLoanAmount;
      Cache["cpRate"] = sngRate;
      Cache["cpTerm"] = intTerm;
      Cache["cpPayment"] = Math.Round(sngPayment, 2);
    }
    // CalculatePayment()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmLoanCalculator

}
// CopyPaste.Learning