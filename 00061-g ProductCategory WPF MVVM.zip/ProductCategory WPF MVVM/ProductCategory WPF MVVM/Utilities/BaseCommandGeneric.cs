﻿//***
// Action
//   - Definition of a base command (inherits from System.Windows.Input.ICommand)
// Created
//   - CopyPaste – 20260404 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260404 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Input;

namespace ProductCategory_WPF_MVVM.Utilities
{

  public class BaseCommand<T> : ICommand
  {

    #region "Constructors / Destructors"

    public BaseCommand(Action<T> theAction, Func<T, bool> theFunction = null)
    //***
    // Action
    //   - Basic constructor of a BaseCommand of type T with a given action and / or a given function
    //   - If there is an action
    //     - theAction becomes the action to execute
    //     - If there is a function
    //       - theFunction becomes the function to execute
    //     - If not
    //       - A true is returned by default
    //   - If there is no action, an argument exception is thrown
    // Called by
    //   - BaseCommand(Action)
    //   - BaseCommand(Action, Func<bool>)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260404 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      if (theAction == null)
      {
        throw new ArgumentNullException(nameof(theAction));
      }
      else
      // theAction <> null
      {
        _actionToExecute = theAction;
      }
      // theAction == null

      if (theFunction == null)
      {
        _functionToExecute = (_ => true);
      }
      else
      // theFunction <> null
      {
        _functionToExecute = theFunction;
      }
      // theFunction == null

    }
    // BaseCommand(Action<T>, Func<T, bool>)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private readonly Action<T> _actionToExecute = null;
    private readonly Func<T, bool> _functionToExecute = null;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public event EventHandler CanExecuteChanged
    //***
    // Action
    //   - Add and Remove actions to an event
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260404 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      add => CommandManager.RequerySuggested += value;
      remove => CommandManager.RequerySuggested -= value;
    }
    // EventHandler CanExecuteChanged

    #endregion

    #region "Sub / Function"

    public bool CanExecute(System.Object theSender)
    //***
    // Action
    //   - A function is executed with theSender as parameter
    //   - TheSender is casted towards T
    //   - The result of the function is returned
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260404 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return _functionToExecute((T)theSender);
    }
    // bool CanExecute(System.Object)

    public void Execute(System.Object theSender)
    //***
    // Action
    //   - A routine is executed with theSender as parameter
    //   - TheSender is casted towards T
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260404 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      _actionToExecute((T)theSender);
    }
    // Execute(System.Object)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // BaseCommand<T>

}
// ProductCategory_WPF_MVVM.Utilities