//***
// Action
//   - Show table (view) information of a certain database
// Created
//   - CopyPaste � 20251125 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251125 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Try to
      //     - Define a counter
      //     - Define a connection string
      //     - Create a connection
      //     - Open the connection
      //     - Show some database information
      //     - Create a command string
      //     - Create a data adapter
      //     - Define a data set
      //     - Fill the data set
      //     - Loop thru all the records of the first table of the dataset
      //       - Show some information
      //   - When there is an error
      //     - Show error information
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251125 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251125 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      
      try
      {
        string strConnection = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integrated Security=True";
        SqlConnection theConnection = new SqlConnection(strConnection);
        
        theConnection.Open();
        Console.WriteLine("Database: " + theConnection.Database);

        string theCommand = "SELECT table_name From Information_Schema.Tables";
        SqlDataAdapter theDataAdapter = new SqlDataAdapter(theCommand, theConnection);
        DataSet theDataSet = new DataSet();

        theDataAdapter.Fill(theDataSet);

        for (int lngCounter = 0; lngCounter < theDataSet.Tables[0].Rows.Count; lngCounter++)
        {
          Console.WriteLine(theDataSet.Tables[0].Rows[lngCounter][0]);
        }
        // lngCounter = theDataSet.Tables(0).Rows.Count
      
      }
      catch (Exception theException)
      {
        Console.WriteLine("Exception: " + theException.Message);
        Console.WriteLine(theException.ToString());
      }
      finally
      {
        Console.ReadLine();
      }

    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning