﻿//***
// Action
//   - Prepare the options "Migrate Database" for CommandLine Parser
// Created
//   - CopyPaste – 20230717 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230717 – VVDW
// Proposal (To Do)
//   -
//***

using CommandLine;
using CopyPaste.DataAccess;
using CopyPaste.Toolkit;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace MigrationBiggerDatabase
{

  [VerbAttribute("Migrate", HelpText = "Migrate the forward engineered database")]
  public class cpMigrateDatabaseVerb
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int Migrate(cpWingsContext theContext)
    //***
    // Action
    //   - Loop thru the available migrations
    //   - Loop thru the executed migrations
    //   - Print the status of the migrations
    //   - Execute all the migrations (assuming you created the database with Version01)
    //   - Print the status of the migrations
    // Called by
    //   - cpMigrateAndCreateTestVerb.Both(cpWingsContext)
    //   - int cpProgram.Main(string[])
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintError(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintSuccess()
    //   - PrintMigrationStatus(cpWingsContext)
    // Created
    //   - CopyPaste – 20230717 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230717 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpConsole.Print("Migrate Database");

      try
      {
        IEnumerable<string> theMigrations = theContext.Database.GetMigrations();
        cpConsole.PrintMainHeadLine("Available Migrations: " + theMigrations.Count());

        foreach (string aMigration in theMigrations)
        {
          Console.WriteLine(aMigration);
        }
        // in theMigrations

        IEnumerable<string> theAppliedMigrations = theContext.Database.GetAppliedMigrations();

        cpConsole.PrintMainHeadLine("Existing Migrations in this database: " + theAppliedMigrations.Count());

        foreach (string aMigration in theAppliedMigrations)
        {
          Console.WriteLine(aMigration);
        }
        // in theAppliedMigrations

        // theContext.Database.EnsureDeleted(); // Do this if you want a clean start

        IMigrator theMigrator = theContext.GetService<IMigrator>();
        theMigrator.Migrate(); // Migrate to a specific version seems not to work
        // theMigrator.MigrateAsync();

        PrintMigrationStatus(theContext);
        cpConsole.PrintMainHeadLine("Starting Migration...");
        // theContext.Database.EnsureCreated(); // Do not execute this
        theContext.Database.Migrate();
        cpConsole.PrintSuccess("Migrations done!");
        PrintMigrationStatus(theContext);
        return 0;
      }
      catch (Exception theException)
      {
        cpConsole.PrintError("Migration Error: " + theException.ToString());
        // System.Environment.Exit(2);
        return 2;
      }

    }
    // Migrate(cpWingsContext)

    private static void PrintMigrationStatus(cpWingsContext theContext)
    //***
    // Action
    //   - Compare the Migrations with the applied migrations
    //   - Show the correct information
    // Called by
    //   - Migrate(cpWingsContext)
    // Calls
    //   - cpConsole.PrintMainHeadLine(string)
    // Created
    //   - CopyPaste – 20230717 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230717 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - This does not work yes
    //***
    {
      cpConsole.PrintMainHeadLine("Migration Status");

      try
      {
        // Dictionary<string, string> theMigrationsStatus = new Dictionary<string, string>();
        // xxx theMigration = ctx.Database.GetMigrationStatus(); // This does not work yet

        // foreach (xxx aMigration in theMigrations)
        // {
        //    if (aMigration.Value)
        //    {
        //      CUI.PrintGreen(aMigration.Key + ":" + " Applied");
        //    }
        //    else
        //    {
        //      CUI.PrintRed(item.Key + ":" + " TODO");
        //    }
        //  }
      }
      catch
      {
        cpConsole.PrintError("Database not available!");
      }

    }
    // PrintMigrationStatus(cpWingsContext)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCreateTestDataVerb

}
// MigrationBiggerDatabase