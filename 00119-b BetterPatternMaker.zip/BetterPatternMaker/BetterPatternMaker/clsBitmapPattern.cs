//***
// Action
//   - Implementation of a cpBitmapPattern
//     - This is a picture using colored pixels
//   - It is an implementation of cpPattern
//     - Implement a clone functionality (copy the pattern)
//     - Implement a draw functionality (visualize the pattern)
//     - Implement an editor for drawing the pattern (bitmap)
//       - A file open screen it used as editor, so it only chooses another bitmap, not creating it
// Created
//   - CopyPaste � 20240409 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240409 � VVDW
// Proposal (To Do)
//   -
//***

using System.Drawing;

namespace CopyPaste.Learning
{

  public class cpBitmapPattern : cpPattern
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrBitmapFile = "";

    #endregion

    #region "Properties"

    public string BitmapFile
    {

      get
        //***
        // Action Get
        //   - Returns the path (as string) of the bitmap
        // Called by
        //   - cpPattern cpClone()
        //   - cpDraw(System.Object, System.Windows.Forms.PaintEventArgs)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrBitmapFile;
      }
      // string BitmapFile (Get)

      set
        //***
        // Action Set
        //   - The bitmap path becomes value
        // Called by
        //   - cpctlDrawnPatternEditor.SavePattern()
        //   - cpPattern cpPattern.cpClone()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mstrBitmapFile = value;
      }
      // BitmapFile(string) (Set)

    }
    // string BitmapFile

    #endregion

    #region "Methods"

    #region "Overrides"

    public override cpPattern cpClone()
      //***
      // Action
      //   - A cpDrawnPattern is created
      //   - The array of points are cloned
      //   - the created cpDrawnPattern is returned
      // Called by
      //   - frmPatternMaker.TemplateClick(System.Object, System.EventArgs)
      // Calls
      //   - string BitmapFile (Get)
      //   - BitmapFile(string) (Set)
      //   - cpBitmapPattern()
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpBitmapPattern thePattern = new cpBitmapPattern();

      thePattern.BitmapFile = this.BitmapFile;
      return thePattern;
    }
    // cpPattern cpClone()

    public override void cpDraw(System.Object theSender, System.Windows.Forms.PaintEventArgs thePaintEventArguments)
      //***
      // Action
      //   - There is an array of points
      //   - A rectangle is drawn of 60 by 60 pixels
      //   - For every pair of points in the array
      //     - A line is drawn using the pair or coordinates
      // Called by
      //   - 
      // Calls
      //   - BitmapFile() As String (Get)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      thePaintEventArguments.Graphics.DrawImage(new System.Drawing.Bitmap(BitmapFile), 0, 0);
    }
    // cpDraw(System.Object, System.Windows.Forms.PaintEventArgs)

    public override cpctlPatternEditor cpGetEditor()
      //***
      // Action
      //   - Return a cpctlBitmapPatternEditor
      //   - The class cpBitmapPattern is given in the constructor
      // Called by
      //   - 
      // Calls
      //   - cpctlBitmapPatternEditor(cpBitmapPattern)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return new cpctlBitmapPatternEditor(this);
    }
    // cpctlPatternEditor cpGetEditor()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion
   
  }
  // cpBitmapPattern

}
// CopyPaste.Learning