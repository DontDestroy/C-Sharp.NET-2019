﻿//***
// Action
//   - Create an implementation of ILogger
// Created
//   - CopyPaste – 20230403 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230403 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;

namespace LogDatabaseActionsEntityFrameWorkCore
{

  public class cpLogger : ILogger
  {

    #region "Constructors / Destructors"

    public cpLogger(List<string> colLogs)
    //***
    // Action
    //   - Create an instance of 'cpLogger'
    // Called by
    //   - ILogger cpLoggerProvider.CreateLogger(strCategoryName)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20230403 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230403 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      _colLogs = colLogs;
    }
    // cpLogger(List<string>)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private readonly List<string> _colLogs;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public IDisposable BeginScope<TState>(TState theState)
    //***
    // Action
    //   - Return null
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230403 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230403 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      return null;
    }
    // BeginScope<TState>(TState)

    public bool IsEnabled(LogLevel theLogLevel)
    //***
    // Action
    //   - If theLogLevel bigger than LogLevel.Information
    //     - Return True
    //   - If Not
    //     - Return False
    // Called by
    //   - string cpProgram.ReadTestData(cpApplicationDatabaseContext, bool = False)
    //   - string cpProgram.UpdateTestData(cpApplicationDatabaseContext, bool = False)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230403 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230403 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      bool blnResult;

      blnResult = theLogLevel >= LogLevel.Information;
      return blnResult;
    }
    // bool IsEnabled(LogLevel)

    public void Log<TState>(LogLevel theLogLevel, EventId theEventId, TState theState, Exception theException, Func<TState, Exception, string> theFormatter)
    //***
    // Action
    //   - Add a log to the Collection
    // Called by
    //   - string cpProgram.ReadTestData(cpApplicationDatabaseContext, bool = False)
    //   - string cpProgram.UpdateTestData(cpApplicationDatabaseContext, bool = False)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230403 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230403 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      _colLogs.Add(theFormatter(theState, theException));
    }
    // Log<TState>(LogLevel, EventId, TState, Exception, Func<TState, Exception, string>)

    #endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpLogger

}
// LogDatabaseActionsEntityFrameWorkCore