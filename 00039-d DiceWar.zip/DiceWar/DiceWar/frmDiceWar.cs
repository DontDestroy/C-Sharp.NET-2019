//***
// Action
//   - Creating a dice game
//   - Two players rolls 3 times 2 dices
//   - The player with the highest score wins
// Created
//   - CopyPaste � 20240201 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240201 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDiceWar: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.PictureBox picDiceRoll;
    internal System.Windows.Forms.Label lblRound;
    internal System.Windows.Forms.Label lblScore1;
    internal System.Windows.Forms.Label lblScore2;
    internal System.Windows.Forms.Label lblPlayer2;
    internal System.Windows.Forms.Label lblPlayer1;
    internal System.Windows.Forms.Button cmdStart;
    internal System.Windows.Forms.PictureBox picDiceResult2;
    internal System.Windows.Forms.PictureBox picDiceResult1;
    internal System.Windows.Forms.PictureBox picDice6;
    internal System.Windows.Forms.PictureBox picDice5;
    internal System.Windows.Forms.PictureBox picDice4;
    internal System.Windows.Forms.PictureBox picDice3;
    internal System.Windows.Forms.PictureBox picDice2;
    internal System.Windows.Forms.Timer tmrTimer;
    internal System.Windows.Forms.PictureBox picDice1;
    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDiceWar));
      this.picDiceRoll = new System.Windows.Forms.PictureBox();
      this.lblRound = new System.Windows.Forms.Label();
      this.lblScore1 = new System.Windows.Forms.Label();
      this.lblScore2 = new System.Windows.Forms.Label();
      this.lblPlayer2 = new System.Windows.Forms.Label();
      this.lblPlayer1 = new System.Windows.Forms.Label();
      this.cmdStart = new System.Windows.Forms.Button();
      this.picDiceResult2 = new System.Windows.Forms.PictureBox();
      this.picDiceResult1 = new System.Windows.Forms.PictureBox();
      this.picDice6 = new System.Windows.Forms.PictureBox();
      this.picDice5 = new System.Windows.Forms.PictureBox();
      this.picDice4 = new System.Windows.Forms.PictureBox();
      this.picDice3 = new System.Windows.Forms.PictureBox();
      this.picDice2 = new System.Windows.Forms.PictureBox();
      this.tmrTimer = new System.Windows.Forms.Timer(this.components);
      this.picDice1 = new System.Windows.Forms.PictureBox();
      this.SuspendLayout();
      // 
      // picDiceRoll
      // 
      this.picDiceRoll.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.picDiceRoll.Location = new System.Drawing.Point(16, 102);
      this.picDiceRoll.Name = "picDiceRoll";
      this.picDiceRoll.Size = new System.Drawing.Size(64, 64);
      this.picDiceRoll.TabIndex = 29;
      this.picDiceRoll.TabStop = false;
      // 
      // lblRound
      // 
      this.lblRound.Font = new System.Drawing.Font("Times New Roman", 16F, System.Drawing.FontStyle.Bold);
      this.lblRound.ForeColor = System.Drawing.Color.Blue;
      this.lblRound.Location = new System.Drawing.Point(136, 6);
      this.lblRound.Name = "lblRound";
      this.lblRound.Size = new System.Drawing.Size(160, 32);
      this.lblRound.TabIndex = 28;
      this.lblRound.Text = "Round 1";
      this.lblRound.TextAlign = System.Drawing.ContentAlignment.TopCenter;
      // 
      // lblScore1
      // 
      this.lblScore1.AutoSize = true;
      this.lblScore1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblScore1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(0)), ((System.Byte)(0)));
      this.lblScore1.Location = new System.Drawing.Point(8, 30);
      this.lblScore1.Name = "lblScore1";
      this.lblScore1.Size = new System.Drawing.Size(51, 18);
      this.lblScore1.TabIndex = 27;
      this.lblScore1.Text = "Score: 0";
      // 
      // lblScore2
      // 
      this.lblScore2.AutoSize = true;
      this.lblScore2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblScore2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(0)), ((System.Byte)(0)));
      this.lblScore2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
      this.lblScore2.Location = new System.Drawing.Point(352, 30);
      this.lblScore2.Name = "lblScore2";
      this.lblScore2.Size = new System.Drawing.Size(51, 18);
      this.lblScore2.TabIndex = 26;
      this.lblScore2.Text = "Score: 0";
      // 
      // lblPlayer2
      // 
      this.lblPlayer2.AutoSize = true;
      this.lblPlayer2.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
      this.lblPlayer2.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(0)), ((System.Byte)(0)));
      this.lblPlayer2.Location = new System.Drawing.Point(352, 6);
      this.lblPlayer2.Name = "lblPlayer2";
      this.lblPlayer2.Size = new System.Drawing.Size(53, 19);
      this.lblPlayer2.TabIndex = 25;
      this.lblPlayer2.Text = "Player 2";
      // 
      // lblPlayer1
      // 
      this.lblPlayer1.AutoSize = true;
      this.lblPlayer1.Font = new System.Drawing.Font("Times New Roman", 10F, System.Drawing.FontStyle.Bold);
      this.lblPlayer1.ForeColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(0)), ((System.Byte)(0)));
      this.lblPlayer1.Location = new System.Drawing.Point(8, 6);
      this.lblPlayer1.Name = "lblPlayer1";
      this.lblPlayer1.Size = new System.Drawing.Size(53, 19);
      this.lblPlayer1.TabIndex = 24;
      this.lblPlayer1.Text = "Player 1";
      // 
      // cmdStart
      // 
      this.cmdStart.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold);
      this.cmdStart.Location = new System.Drawing.Point(104, 222);
      this.cmdStart.Name = "cmdStart";
      this.cmdStart.Size = new System.Drawing.Size(232, 40);
      this.cmdStart.TabIndex = 23;
      this.cmdStart.Text = "Restart";
      this.cmdStart.Click += new System.EventHandler(this.cmdStart_Click);
      // 
      // picDiceResult2
      // 
      this.picDiceResult2.Location = new System.Drawing.Point(272, 78);
      this.picDiceResult2.Name = "picDiceResult2";
      this.picDiceResult2.Size = new System.Drawing.Size(64, 64);
      this.picDiceResult2.TabIndex = 22;
      this.picDiceResult2.TabStop = false;
      // 
      // picDiceResult1
      // 
      this.picDiceResult1.Location = new System.Drawing.Point(104, 78);
      this.picDiceResult1.Name = "picDiceResult1";
      this.picDiceResult1.Size = new System.Drawing.Size(64, 64);
      this.picDiceResult1.TabIndex = 21;
      this.picDiceResult1.TabStop = false;
      // 
      // picDice6
      // 
      this.picDice6.Image = ((System.Drawing.Image)(resources.GetObject("picDice6.Image")));
      this.picDice6.Location = new System.Drawing.Point(368, 286);
      this.picDice6.Name = "picDice6";
      this.picDice6.Size = new System.Drawing.Size(64, 64);
      this.picDice6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
      this.picDice6.TabIndex = 20;
      this.picDice6.TabStop = false;
      this.picDice6.Visible = false;
      // 
      // picDice5
      // 
      this.picDice5.Image = ((System.Drawing.Image)(resources.GetObject("picDice5.Image")));
      this.picDice5.Location = new System.Drawing.Point(296, 286);
      this.picDice5.Name = "picDice5";
      this.picDice5.Size = new System.Drawing.Size(64, 64);
      this.picDice5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
      this.picDice5.TabIndex = 19;
      this.picDice5.TabStop = false;
      this.picDice5.Visible = false;
      // 
      // picDice4
      // 
      this.picDice4.Image = ((System.Drawing.Image)(resources.GetObject("picDice4.Image")));
      this.picDice4.Location = new System.Drawing.Point(224, 286);
      this.picDice4.Name = "picDice4";
      this.picDice4.Size = new System.Drawing.Size(64, 64);
      this.picDice4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
      this.picDice4.TabIndex = 18;
      this.picDice4.TabStop = false;
      this.picDice4.Visible = false;
      // 
      // picDice3
      // 
      this.picDice3.Image = ((System.Drawing.Image)(resources.GetObject("picDice3.Image")));
      this.picDice3.Location = new System.Drawing.Point(152, 286);
      this.picDice3.Name = "picDice3";
      this.picDice3.Size = new System.Drawing.Size(64, 64);
      this.picDice3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
      this.picDice3.TabIndex = 17;
      this.picDice3.TabStop = false;
      this.picDice3.Visible = false;
      // 
      // picDice2
      // 
      this.picDice2.Image = ((System.Drawing.Image)(resources.GetObject("picDice2.Image")));
      this.picDice2.Location = new System.Drawing.Point(80, 286);
      this.picDice2.Name = "picDice2";
      this.picDice2.Size = new System.Drawing.Size(64, 64);
      this.picDice2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
      this.picDice2.TabIndex = 16;
      this.picDice2.TabStop = false;
      this.picDice2.Visible = false;
      // 
      // tmrTimer
      // 
      this.tmrTimer.Tick += new System.EventHandler(this.tmrTimer_Tick);
      // 
      // picDice1
      // 
      this.picDice1.Image = ((System.Drawing.Image)(resources.GetObject("picDice1.Image")));
      this.picDice1.Location = new System.Drawing.Point(8, 286);
      this.picDice1.Name = "picDice1";
      this.picDice1.Size = new System.Drawing.Size(64, 64);
      this.picDice1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
      this.picDice1.TabIndex = 15;
      this.picDice1.TabStop = false;
      this.picDice1.Visible = false;
      // 
      // frmDiceWar
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
      this.ClientSize = new System.Drawing.Size(440, 357);
      this.Controls.Add(this.lblRound);
      this.Controls.Add(this.lblScore1);
      this.Controls.Add(this.lblScore2);
      this.Controls.Add(this.lblPlayer2);
      this.Controls.Add(this.lblPlayer1);
      this.Controls.Add(this.cmdStart);
      this.Controls.Add(this.picDiceResult2);
      this.Controls.Add(this.picDiceResult1);
      this.Controls.Add(this.picDice6);
      this.Controls.Add(this.picDice5);
      this.Controls.Add(this.picDice4);
      this.Controls.Add(this.picDice3);
      this.Controls.Add(this.picDice2);
      this.Controls.Add(this.picDice1);
      this.Controls.Add(this.picDiceRoll);
      this.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDiceWar";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "DiceWar";
      this.Load += new System.EventHandler(this.frmDiceWar_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDiceWar'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDiceWar()
      //***
      // Action
      //   - Create instance of 'frmDiceWar'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDiceWar()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    int mlngPlayer = 1;
    int mlngRoll01 = 1;
    int mlngRoll02 = 3;
    int mlngRolls;
    int mlngRound = 1;
    int mlngScore01;
    int mlngScore02;
    Random mrndRandom = new Random(DateTime.Now.Millisecond);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdStart_Click(System.Object theSnder, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If text of Start button is "Restart"
      //     - Restart the game
      //   - If Not
      //     - Disable the Start button
      //     - Enable timer
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - RestartGame()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (cmdStart.Text == "Restart")
      {
        RestartGame();
      }
      else
        // cmdStart.Text <> "Restart"
      {
        cmdStart.Enabled = false;
        tmrTimer.Enabled = true;
      }
      // cmdStart.Text = "Restart"
    
    }
    // cmdStart_Click(System.Object, System.EventArgs) Handles cmdStart.Click
    
    private void frmDiceWar_Load(System.Object theSnder, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the 2 dice with value 6
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      picDiceResult1.Image = picDice6.Image;
      picDiceResult2.Image = picDice6.Image;
    }
    // frmDiceWar_Load(System.Object, System.EventArgs) Handles this.Load

    private void tmrTimer_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Roll first dice
      //   - Roll second dice
      //   - Add 1 to number of rolls (mlngRolls)
      //   - If more than 30 rolls (Rollover)
      //     - Set number of rolls to 0 (mlngRolls)
      //     - Disable Timer
      //     - Enable Start button
      //     - Show results of player (mlngPlayer)
      //     - If all players has rolled 3 times (GameOver)
      //       - Start button becomes "Restart"
      //       - Show the winner
      //     - If Not
      //       - Show the round number
      //   - If Not
      //     - Continue
      // Called by
      //   - System action (A timer)
      // Calls
      //   - DisplayRoll(Integer)
      //   - GameOver() As Boolean
      //   - RollDie1()
      //   - RollDie2()
      //   - RollOver() as Boolean
      //   - ShowWinner()
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      RollDie1();
      RollDie2();
      
      mlngRolls += 1;

      if (RollOver())
      {
        mlngRolls = 0;
        tmrTimer.Enabled = false;
        cmdStart.Enabled = true;
        DisplayRoll(mlngPlayer);

        if (GameOver())
        {
          cmdStart.Text = "Restart";
          ShowWinner();
        }
        else
          // Not GameOver()
        {
          lblRound.Text = "Round " + mlngRound;
        }
        // GameOver()

      }
      else
      // Not RollOver()
      {
      }
      // RollOver()
    
    }
    // tmrTimer_Tick(System.Object theSender, System.EventArgs theEventArguments)

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void DisplayRoll(int intPlayerNumber)
      //***
      // Action
      //   - Depending on the player (intPlayerNumber)
      //     - When Player 1
      //       - Show a messagebox with the total of the dice
      //       - Adapt the score of Player 1 (mlngScore01)
      //       - Show the score
      //       - Player 2 becomes the next player (mlngPlayer)
      //     - When Player 2
      //       - Show a messagebox with the total of the dice
      //       - Adapt the score of Player 2 (mlngScore02)
      //       - Show the score
      //       - Player 1 becomes the next player (mlngPlayer)
      //       - You have played a full round
      //     - In all other cases
      //       - Show a messagebox that there is an error
      // Called by
      //   -  tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      switch (intPlayerNumber)
      {
        case 1:
          MessageBox.Show("Player 1, you rolled a " + Convert.ToInt32(mlngRoll01 + mlngRoll02) + ".");
          mlngScore01 += mlngRoll01 + mlngRoll02;
          lblScore1.Text = "Score: " + mlngScore01;
          cmdStart.Text = "Player 2 - Roll";
          mlngPlayer = 2;
          break;
        case 2:
          MessageBox.Show("Player 2, you rolled a " + Convert.ToInt32(mlngRoll01 + mlngRoll02) + ".");
          mlngScore02 += mlngRoll01 + mlngRoll02;
          lblScore2.Text = "Score: " + mlngScore02;
          cmdStart.Text = "Player 1 - Roll";
          mlngPlayer = 1;
          mlngRound += 1;
          break;
        default:
          MessageBox.Show("intPlayerNum is invalid");
          break;
      }
      // intPlayerNumber

    }
    // DisplayRoll(int)

    private bool GameOver()
      //***
      // Action
      //   - If number of rounds (mlngRound) is larger than 3
      //     - Return True
      //   - If Not
      //     - Return False
      // Called by
      //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;

      if (mlngRound > 3)
      {
        blnResult = true;        
      }
      else
        // mlngRound <= 3
      {
        blnResult = false;
      }
      // mlngRound > 3

      return blnResult;
    }
    // bool GameOver()

    [STAThreadAttribute]
    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDiceWar
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDiceWar());
    }
    // Main() 
    
    private void RestartGame()
      //***
      // Action
      //   - Player 1 can start
      //   - Scores are set to 0 (mlngScore01 and mlngScore02)
      //   - Score for player 1 is shown
      //   - Score for player 2 is shown
      //   - We will start with round 1 (mlngRound)
      //   - We show the round number
      //   - We show 2 sixes for the dice
      // Called by
      //   - cmdStart_Click(System.Object, System.EventArgs) Handles cmdStart.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cmdStart.Text = "Player 1 - Roll";
      mlngScore01 = 0;
      mlngScore02 = 0;
      lblScore1.Text = "Score: " + mlngScore01;
      lblScore2.Text = "Score: " + mlngScore02;
      mlngRound = 1;
      lblRound.Text = "Round " + mlngRound;
      picDiceResult1.Image = picDice6.Image;
      picDiceResult2.Image = picDice6.Image;
    }
    // RestartGame()

    private void RollDie1()
      //***
      // Action
      //   - Set a random number between 1 and 6 (borders included) (mlngRoll01)
      //   - Depending on the random number, show the correct dice
      // Called by
      //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mlngRoll01 = mrndRandom.Next(1, 7);
      
      switch (mlngRoll01)
      {
        case 1:
          picDiceResult1.Image = picDice1.Image;
          break;
        case 2:
          picDiceResult1.Image = picDice2.Image;
          break;
        case 3:
          picDiceResult1.Image = picDice3.Image;
          break;
        case 4:
          picDiceResult1.Image = picDice4.Image;
          break;
        case 5:
          picDiceResult1.Image = picDice5.Image;
          break;
        case 6:
          picDiceResult1.Image = picDice6.Image;
          break;
      }
      // mlngRoll01

    }
    // RollDie1()

    private void RollDie2()
      //***
      // Action
      //   - Set a random number between 1 and 6 (borders included) (mlngRoll02)
      //   - Depending on the random number, show the correct dice
      // Called by
      //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mlngRoll02 = mrndRandom.Next(1, 7);
      
      switch (mlngRoll02)
      {
        case 1:
          picDiceResult2.Image = picDice1.Image;
          break;
        case 2:
          picDiceResult2.Image = picDice2.Image;
          break;
        case 3:
          picDiceResult2.Image = picDice3.Image;
          break;
        case 4:
          picDiceResult2.Image = picDice4.Image;
          break;
        case 5:
          picDiceResult2.Image = picDice5.Image;
          break;
        case 6:
          picDiceResult2.Image = picDice6.Image;
          break;
      }
      // mlngRoll02

    }
    // RollDie2()

    private bool RollOver()
      //***
      // Action
      //   - If number of rolls is larger than 30 (mlngRolls)
      //     - Return True
      //   - Otherwise
      //     - Return False
      // Called by
      //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;

      if (mlngRolls > 30)
      {
        blnResult = true;
      }
      else
        // mlngRolls <= 30
      {
        blnResult = false;
      }
      // mlngRolls > 30

      return blnResult;
    }
    // bool RollOver()

    private void ShowWinner()
      //***
      // Action
      //   - Depending on the 2 scores (mlngScore01 and mlngScore02)
      //   - Compare mlngScore01 with mlngScore02
      //     - Equal --> Draw
      //     - Larger --> Player 1 wins
      //     - Smaller --> Player 2 wins
      // Called by
      //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240201 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240201 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (mlngScore01 == mlngScore02)
      {
        MessageBox.Show("This game is a draw!");
      }
      else if (mlngScore01 > mlngScore02)
        // mlngScore01 <> mlngScore02
      {
        MessageBox.Show("Player 1 is the winner!");
      }
      else if (mlngScore02 > mlngScore01)
        // mlngScore01 < mlngScore02
      {
        MessageBox.Show("Player 2 is the winner!");
      }
      // mlngScore01 = mlngScore02 
      // mlngScore01 > mlngScore02
      // mlngScore02 > mlngScore01 

    }
    // ShowWinner()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDiceWar

}
// CopyPaste.Learning