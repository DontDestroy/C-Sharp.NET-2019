﻿namespace ADONET_Samples
{
  public class ProductCategory : CommonBase
  {
    public int ProductCategoryId { get; set; }
    public string CategoryName { get; set; }
  }
}
