﻿//***
// Action
//   - Show thumbnails from a certain location
// Created
//   - CopyPaste – 20260714 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260714 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmPhoto : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.ID = "wfrmPhoto";
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when the page is initialized
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260714 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define and initialize a relative path towards the images
    //   - Define and initialize the server path
    //   - Get an array of strings with all the found images
    //   - If one is found
    //     - Show the first image as big image
    //     - Build the image url with the path and the filename of the first image
    //   - If not
    //     - Do nothing
    //   - Loop thru the array
    //     - If filename contains "Thumb"
    //       - Create a new image button
    //       - Set the image url to the correct path
    //       - Make the image clickable
    //       - Add the image button to the panel
    //     - If not
    //       - Do nothing
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - ClickImageButton(System.Object, ImageClickEventArgs)
    // Created
    //   - CopyPaste – 20260714 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strURLPath = "./Image/";
      string strPath = Server.MapPath(strURLPath);

      string[] strFiles = System.IO.Directory.GetFiles(strPath);

      if (strFiles.Length > 0)
      {
        picBig.ImageUrl = strURLPath + strFiles[0].Substring(strPath.Length);
      }
      else
      // strFiles.Length = 0
      {
      }
      // strFiles.Length > 0

      foreach (string strFile in strFiles)
      {

        if (strFile.IndexOf("Thumb") > 0)
        {
          ImageButton theImageButton = new ImageButton();
          theImageButton.ImageUrl = strURLPath + strFile.Substring(strPath.Length);
          theImageButton.Click += new ImageClickEventHandler(ClickImageButton);
          panPhoto.Controls.Add(theImageButton);
        }
        else
        // strFile.IndexOf("Thumb") <= 0
        {
        }
        // strFile.IndexOf("Thumb") > 0

      }
      // in strFiles

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    #region "Event"

    private void ClickImageButton(System.Object theSender, ImageClickEventArgs theImageClickEventArguments)
    //***
    // Action
    //   - Find out on what image button you have clicked
    //   - Show the corresponding big image
    //     - Find the image url and remove "thumb"
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - ClickImageButton(System.Object, ImageClickEventArgs)
    // Created
    //   - CopyPaste – 20260714 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ImageButton theImageButton = (ImageButton)theSender;
      picBig.ImageUrl = theImageButton.ImageUrl.Remove(theImageButton.ImageUrl.IndexOf("Thumb"), 5);
    }
    // ClickImageButton(System.Object, ImageClickEventArgs)

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmPhoto

}
// CopyPaste.Learning