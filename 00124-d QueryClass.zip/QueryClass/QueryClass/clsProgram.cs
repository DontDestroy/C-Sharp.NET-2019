//***
// Action
//   - Testroutine for cpBase and cpDerived
// Created
//   - CopyPaste � 20240705 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240705 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Reflection;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create a new instance of cpDerived (thecpBook)
      //   - Define EventInfo, MemberInfo, MethodInfo, PropertyInfo and Type
      //   - Show information about thecpBook
      //   - Loop thru the members of thecpBook
      //   - Loop thru the properties of thecpBook
      //   - Loop thru the methods of thecpBook
      //   - Loop thru the events of thecpBook
      //   - Loop thru the constructors of thecpBook
      //   - Loop thru the interfaces of thecpBook
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpDerived(string, string, string, string, Double, Double)
      //   - cpDerived.ShowBook()
      // Created
      //   - CopyPaste � 20240705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpDerived thecpBook = new cpDerived("C# Programming Tips & Techniques", "Wright", "McGraw-Hill/Osborne", "9-780072-223187", 49.99, 4.3);

      thecpBook.ShowBook();
      Console.WriteLine();
      Console.WriteLine("Members:");

      foreach (MemberInfo theMemberInfo in thecpBook.GetType().GetMembers())
      {
        Console.WriteLine(theMemberInfo.Name + " - " + theMemberInfo.MemberType.ToString());
      }
      // in thecpBook.GetType().GetMembers()

      Console.WriteLine();
      Console.WriteLine("Properties:");

      foreach (PropertyInfo thePropertyInfo in thecpBook.GetType().GetProperties())
      {
        Console.WriteLine(thePropertyInfo.Name + " - " + thePropertyInfo.PropertyType.ToString());
      }
      // in thecpBook.GetType().GetProperties()

      Console.WriteLine();
      Console.WriteLine("Methods:");

      foreach (MethodInfo theMethodInfo in thecpBook.GetType().GetMethods())
      {
        Console.WriteLine(theMethodInfo.Name + " - " + theMethodInfo.ReturnType.ToString());
      }
      // in thecpBook.GetType().GetMethods()

      Console.WriteLine();
      Console.WriteLine("Events:");

      foreach (EventInfo theEventInfo in thecpBook.GetType().GetEvents())
      {
        Console.WriteLine(theEventInfo.Name + " - " + theEventInfo.IsMulticast);
      }
      // in thecpBook.GetType().GetEvents()

      Console.WriteLine();
      Console.WriteLine("Constructors:");

      foreach (ConstructorInfo theConstructorInfo in thecpBook.GetType().GetConstructors())
      {
        Console.WriteLine(theConstructorInfo.Name + " - " + theConstructorInfo.DeclaringType);
      }
      // in thecpBook.GetType().GetConstructors()

      Console.WriteLine();
      Console.WriteLine("Interfaces:");

      foreach (Type theType in thecpBook.GetType().GetInterfaces())
      {
        Console.WriteLine(theType.Name);
      }
      // in thecpBook.GetType().GetInterfaces()

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning