﻿//***
// Action
//   - Erase a database if it already exists
//   - Create a database based on the class cpBook using Entity Framework Core (version 5.0.17)
//   - Fill two tables with data
//   - Query the two tables 
// Created
//   - CopyPaste – 20230401 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230401 – VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LogDatabaseActionsEntityFrameWorkCore
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static bool CreateDatabase(cpApplicationDatabaseContext theDatabaseContext, bool blnOnlyWhenThereIsNoDatabase)
    //***
    // Action
    //   - Checks if the database exists as defined in the context
    //   - If it exists and blnOnlyWhenThereIsNoDatabase is set to true, nothing happens
    //   - In all other cases
    //     - The database is deleted (if possible)
    //     - The database is recreated (will take a bit of time)
    //     - Is there any book in the database?
    //       - No, the default data for testing purposes is set 
    // Called by
    //   - Main()
    // Calls
    //   - bool DatabaseExists(cpApplicationDatabaseContext)
    //   - DbSet<cpBook> cpApplicationDatabaseContext.cpBook() (Get)
    //   - CreateTestData(cpApplicationDatabaseContext)
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnDatabaseExists;
      bool blnCreateTestDataWasSuccessful = false;

      blnDatabaseExists = DatabaseExists(theDatabaseContext);

      if (blnOnlyWhenThereIsNoDatabase && blnDatabaseExists)
      {
        return false;
      }
      else
      // Not blnOnlyWhenThereIsNoDatabase Or Not blnDatabaseExists
      {
      }
      // blnOnlyWhenThereIsNoDatabase And blnDatabaseExists

      theDatabaseContext.Database.EnsureDeleted();
      // Delete the database thru the context if it already exists
      theDatabaseContext.Database.EnsureCreated();
      // Create a new databse thru the context

      if (theDatabaseContext.cpBook.Any())
      {
      }
      else
      // Not theDatabaseContext.cpBook.Any() 
      {
        // There is no data yet
        blnCreateTestDataWasSuccessful = CreateTestData(theDatabaseContext);
        // Add data to the two tables thru the context
      }
      // theDatabaseContext.cpBook.Any()

      return blnCreateTestDataWasSuccessful;
    }
    // bool CreateDatabase(cpApplicationDatabaseContext, bool)

    public static bool CreateTestData(cpApplicationDatabaseContext theDatabaseContext)
    //***
    // Action
    //   - Create a list of cpBooks
    //   - Create a cpAuthor
    //   - Create a cpBook
    //   - Add three other cpBooks to the list
    //   - Add a cpBook to the database (with the corresponding cpAuthor)
    //     - For demo purposes this method is used (one item)
    //   - Add a list of cpBooks to the database (with the corresponding cpAuthors)
    //     - For demo purposes this method is used (more items)
    // Called by
    //   - bool CreateDatabase(cpApplicationDatabaseContext, bool)
    // Calls
    //   - cpAuthor()
    //   - cpAuthor.strName(string) (Set)
    //   - cpAuthor.strWebUrl(string) (Set)
    //   - cpBook()
    //   - cpBook.Author(cpAuthor) (Set)
    //   - cpBook.dtmPublishedOn(DateTime) (Set)
    //   - cpBook.strDescription(string) (Set)
    //   - cpBook.strTitle(string) (Set)
    //   - DbSet<cpBook> cpApplicationDatabaseContext.cpBook() (Get)
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnCreateTestDataWasSuccessful = false;
      cpAuthor martinFowler;
      cpBook aBook;
      List<cpBook> lstBooks = new List<cpBook>();

      martinFowler = new cpAuthor
      {
        strName = "Martin Fowler",
        strWebUrl = "http://martinfowler.com/"
      };

      aBook = new cpBook
      {
        strTitle = "Refactoring",
        strDescription = "Improving the design of existing code",
        dtmPublishedOn = new DateTime(1999, 7, 8),
        Author = martinFowler
      };

      lstBooks.Add(
        new cpBook
        {
          strTitle = "Patterns of Enterprise Application Architecture",
          strDescription = "Written in direct response to the stiff challenges",
          dtmPublishedOn = new DateTime(2002, 11, 15),
          Author = martinFowler
        });

      lstBooks.Add(
        new cpBook
        {
          strTitle = "Domain-Driven Design",
          strDescription = "Linking business needs to software design",
          dtmPublishedOn = new DateTime(2003, 8, 30),
          Author = new cpAuthor { strName = "Eric Evans", strWebUrl = "http://domainlanguage.com/" }
        });

      lstBooks.Add(
        new cpBook
        {
          strTitle = "Quantum Networking",
          strDescription = "Entangled quantum networking provides faster-than-light data communications",
          dtmPublishedOn = new DateTime(2057, 1, 1),
          Author = new cpAuthor { strName = "Future Person" }
        });

      theDatabaseContext.cpBook.Add(aBook);
      theDatabaseContext.cpBook.AddRange(lstBooks);

      try
      {
        theDatabaseContext.SaveChanges();
        blnCreateTestDataWasSuccessful = true;
      }
      catch
      {
      }

      return blnCreateTestDataWasSuccessful;
    }
    // bool CreateTestData(cpApplicationDatabaseContext)

    public static bool DatabaseExists(cpApplicationDatabaseContext theDatabaseContext)
    //***
    // Action
    //   - Test if the database defined in the context exists
    // Called by
    //   - bool CreateDatabase(cpApplicationDatabaseContext, bool)
    //   - string ReadTestData(cpApplicationDatabaseContext, bool = False)
    //   - string UpdateTestData(cpApplicationDatabaseContext, bool)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20230403 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230403 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnDatabaseExists;
      RelationalDatabaseCreator theCreator;

      theCreator = theDatabaseContext.GetService<IDatabaseCreator>() as RelationalDatabaseCreator;
      blnDatabaseExists = theCreator.Exists();

      return blnDatabaseExists;
    }
    // bool DatabaseExists(cpApplicationDatabaseContext)

    public static void Main()
    //***
    // Action
    //   - Create a cpApplicationDatabaseContext
    //   - Delete the database if it already exists
    //   - Create the database
    //   - Push data towards the database
    //   - Read data from the database
    //   - Cleaning up the cpApplicationDatabaseContext
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - bool CreateDatabase(cpApplicationDatabaseContext, bool)
    //   - bool CreateTestData(cpApplicationDatabaseContext)
    //   - cpApplicationDatabaseContext()
    //   - ShowMenu(string)
    //   - string ReadTestData(cpApplicationDatabaseContext, bool = False)
    //   - string UpdateTestData(cpApplicationDatabaseContext, bool = False)
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Solve the workaround, creating the database several times after updating data can cause an error
    //   - To solve this, the database context is recreated to startup up with a clean object
    //   - Normally you create the context, do your stuff, stop the context
    //   - In this demo I leave it open (to show the possible errors you get)
    //***
    {
      bool blnDatabaseCreated = false;
      string strCommand;
      string strMessage = "Choose a command.\n";
      cpApplicationDatabaseContext theDatabaseContext;

      theDatabaseContext = new cpApplicationDatabaseContext();

      while (true)
      {
        ShowMenu(strMessage);

        strCommand = Console.ReadLine();

        switch (strCommand)
        {
          case "e":
            return;
          case "l":
            // Read data from the two tables thru the context
            strMessage = ReadTestData(theDatabaseContext);
            break;
          case "l -log":
            strMessage = ReadTestData(theDatabaseContext, true);
            break;
          case "r":
            blnDatabaseCreated = CreateDatabase(theDatabaseContext, false);

            if (blnDatabaseCreated)
            {
              // theDatabaseContext = new cpApplicationDatabaseContext();
              // Normally this is never done, but the user can create the database even after updating data
              // This is for demoing that the context should be recreated everytime when needed, now it stays open
              strMessage = "The database is created.\n";
            }
            else
            // Not blnDatabaseCreated
            {
              strMessage = "The database is not created.\n";
            }
            // blnDatabaseCreated

            break;
          case "u":
            strMessage = UpdateTestData(theDatabaseContext);
            // theDatabaseContext = new cpApplicationDatabaseContext();
            // Normally this is never done, but the user can create the database even after updating data
            // This is for demoing that the context should be recreated everytime when needed, now it stays open
            strMessage += ReadTestData(theDatabaseContext);
            break;
          case "u -log":
            strMessage = UpdateTestData(theDatabaseContext, true);
            // theDatabaseContext = new cpApplicationDatabaseContext();
            // Normally this is never done, but the user can create the database even after updating data
            // This is for demoing that the context should be recreated everytime when needed, now it stays open
            strMessage += ReadTestData(theDatabaseContext);
            break;
          default:
            strMessage = "You typed an unknown command.\n";
            break;
        }
        // strCommand

      }
      // (true)

      Console.ReadLine();
    }
    // Main()

    public static string ReadTestData(cpApplicationDatabaseContext theDatabaseContext, bool blnLog = false)
    //***
    // Action
    //   - Switch on logging (or not)
    //   - Reads all the books
    //   - AsNoTracking() says this is a read-only access
    //   - The include causes the cpAuthor information to be loaded with each cpBook
    //   - Loop thru all the books
    // Called by
    //   - Main()
    // Calls
    //   - bool cpLogger.IsEnabled(LogLevel)
    //   - bool DatabaseExists(cpApplicationDatabaseContext)
    //   - cpAuthor cpBook.Author (Get)
    //   - cpLogger.Log<TState>(LogLevel, EventId, TState, Exception, Func<TState, Exception, string>)
    //   - cpLoggerProvider.CreateLogger(strCategoryName)
    //   - DateTime cpBook.dtmPublishedOn (Get)
    //   - DbSet<cpBook> cpApplicationDatabaseContext.cpBook (Get)
    //   - string cpAuthor.strName (Get)
    //   - string cpAuthor.strWebUrl (Get)
    //   - string cpBook.strTitle (Get)
    //   - string ReturnLogging(bool, List<string>)
    //   - SwitchOnLogging(bool, cpApplicationDatabaseContext, List<string>)
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      List<string> colLogs = new List<string>();
      string strWebUrl;
      string strResult = "";

      if (DatabaseExists(theDatabaseContext))
      {

        try
        {
          SwitchOnLogging(blnLog, theDatabaseContext, colLogs);

          foreach (cpBook aBook in theDatabaseContext.cpBook.AsNoTracking().Include(theBook => theBook.Author))
          {

            if (aBook.Author.strWebUrl == null)
            {
              strWebUrl = "- no web url given yet -";
            }
            // aBook.Author.strWebUrl <> null
            else
            {
              strWebUrl = aBook.Author.strWebUrl;
            }
            // aBook.Author.strWebUrl = null

            strResult += aBook.strTitle + " by " + aBook.Author.strName + "\n";
            strResult += "     Published on " + aBook.dtmPublishedOn.ToString("dd/MM/yyyy") + "\n";
            strResult += "     More info can be found on the internet: " + strWebUrl + "\n\n";
          }
          // in theDatabaseContext.cpBook.AsNoTracking().Include(theBook => theBook.Author)

          strResult += ReturnLogging(blnLog, colLogs);
        }
        catch
        {
          strResult += "There is a problem reading the testdata from the database\n";
        }

      }
      else
      // Not DatabaseExists(theDatabaseContext)
      {
        strResult += "The database does not exist yet\n";
      }
      // DatabaseExists(theDatabaseContext)

      return strResult;
    }
    // string ReadTestData(cpApplicationDatabaseContext, bool = False)

    public static void ShowMenu(string strMessage)
    //***
    // Action
    //   - Clear the screen
    //   - Show the options the user can choose from
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.Clear();
      Console.WriteLine(strMessage);
      Console.WriteLine("List of commands:");
      Console.WriteLine(" e (Exit)");
      Console.WriteLine(" l (List)");
      Console.WriteLine(" l -log (List with logs)");
      Console.WriteLine(" r (Reset Database) (Doing this several times causes updates to fail)");
      Console.WriteLine("                    (The error is catched, it is part of the demo)");
      Console.WriteLine(" u (Change url)");
      Console.WriteLine(" u -log (Change url with logs)");
      Console.Write("> ");
    }
    // ShowMenu()

    public static void SwitchOnLogging(bool blnLog, cpApplicationDatabaseContext theDatabaseContext, List<string> colLogs)
    //***
    // Action
    //   - If blnLog
    //     - Get a service provider
    //     - Get the service
    //     - Create a new cpLoggerProvider and add it to the service
    // Called by
    //   - string ReadTestData(cpApplicationDatabaseContext, bool = False)
    //   - string UpdateTestData(cpApplicationDatabaseContext, bool = False)
    // Calls
    //   - cpLoggerProvider(List<string>)
    //   - cpLoggerProvider.CreateLogger(strCategoryName)
    // Created
    //   - CopyPaste – 20230403 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230403 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (blnLog)
      {
        IServiceProvider theServiceProvider = theDatabaseContext.GetInfrastructure();
        ILoggerFactory theLoggerFactory = (ILoggerFactory)theServiceProvider.GetService(typeof(ILoggerFactory));
        theLoggerFactory.AddProvider(new cpLoggerProvider(colLogs));
      }
      else
      // Not blnLog
      {
      }
      // blnLog

    }
    // SwitchOnLogging(bool, cpApplicationDatabaseContext, List<string>)

    public static string ReturnLogging(bool blnLog, List<string> colLogs)
    //***
    // Action
    //   - Define LogText
    //   - If blnLog
    //     - Loop thru list of strings
    //       - Generate LogText
    //   - Return LogText
    // Called by
    //   - string ReadTestData(cpApplicationDatabaseContext, bool = False)
    //   - string UpdateTestData(cpApplicationDatabaseContext, bool = False)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20230403 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230403 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strResult = "";

      if (blnLog)
      {

        foreach (string strLog in colLogs)
        {
          strResult += strLog + "\n";
        }
        // in colLogs

      }
      else
      // Not blnLog
      {
      }
      // blnLog

      return strResult;
    }
    // string ReturnLogging(bool, List<string>)

    public static string UpdateTestData(cpApplicationDatabaseContext theDatabaseContext, bool blnLog = false)
    //***
    // Action
    //   - Ask thru the console the new website of a book in the future
    //   - Read a specific book and the author information thru (I need a snapshot)
    //     - Only the book with the title "Quantum Networking" is selected
    //   - The read data is changed with the information given thru the console
    //   - The SaveChanges() thru the context checks for any change to the data that has been read in and write out
    // Called by
    //   - Main()
    // Calls
    //   - bool cpLogger.IsEnabled(LogLevel)
    //   - bool DatabaseExists(cpApplicationDatabaseContext)
    //   - cpAuthor cpBook.Author (Get)
    //   - cpAuthor.strWebUrl(string) (Set)
    //   - cpLogger.Log<TState>(LogLevel, EventId, TState, Exception, Func<TState, Exception, string>)
    //   - cpLoggerProvider.CreateLogger(strCategoryName)
    //   - DbSet<cpBook> cpApplicationDatabaseContext.cpBook (Get)
    //   - string cpBook.strTitle (Get)
    //   - string ReturnLogging(bool, List<string>)
    //   - SwitchOnLogging(bool, cpApplicationDatabaseContext, List<string>)
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      List<string> colLogs = new List<string>();
      string strResult = "";
      string strNewWebUrl = "";

      Console.Write("New Quantum Networking WebUrl > ");
      strNewWebUrl = Console.ReadLine();

      if (DatabaseExists(theDatabaseContext))
      {
        SwitchOnLogging(blnLog, theDatabaseContext, colLogs);

        cpBook theBook = theDatabaseContext.cpBook
        .Include(theBook => theBook.Author)
        .Single(theBook => theBook.strTitle == "Quantum Networking");

        if (strNewWebUrl == "")
        {
          theBook.Author.strWebUrl = null;
        }
        else
        // strNewWebUrl <> ""
        {
          theBook.Author.strWebUrl = strNewWebUrl;
        }
        // strNewWebUrl = ""

        theDatabaseContext.SaveChanges();
        strResult += ReturnLogging(blnLog, colLogs);
        strResult += "SaveChanges called.\n\n";
      }
      else
      // Not DatabaseExists(theDatabaseContext)
      {
        strResult += "The database does not exist yet\n";
      }
      // DatabaseExists(theDatabaseContext)

      return strResult;
    }
    // string UpdateTestData(cpApplicationDatabaseContext, bool = False)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// LogDatabaseActionsEntityFrameWorkCore