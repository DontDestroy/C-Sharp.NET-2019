//***
// Action
//   - Testroutine for serialization of cpXYPoint, cpTriangle, cpTriangleCollection
//   - Select three points to create a triangle
//   - You can create more triangles
//   - Serialize and Deserialize the list of triangles towards a data file (not readable)
//   - Serialize and Deserialize the list of triangles towards a XML file (readable)
// Created
//   - CopyPaste � 20240408 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240408 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace CopyPaste.Learning
{

  public class frmSerialize: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdLoadXML;
    internal System.Windows.Forms.Button cmdSaveXML;
    internal System.Windows.Forms.Button cmdLoadBinary;
    internal System.Windows.Forms.Button cmdSaveBinary;
    internal System.Windows.Forms.Button cmdClearAll;
    internal System.Windows.Forms.Button cmdRemoveTriangle;
    internal System.Windows.Forms.Button cmdAddTriangle;
    internal System.Windows.Forms.Label lblText2;
    internal System.Windows.Forms.ListBox lstTriangle;
    internal System.Windows.Forms.CheckedListBox lstSelectedPoints;
    internal System.Windows.Forms.Label lblText1;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSerialize));
      this.cmdLoadXML = new System.Windows.Forms.Button();
      this.cmdSaveXML = new System.Windows.Forms.Button();
      this.cmdLoadBinary = new System.Windows.Forms.Button();
      this.cmdSaveBinary = new System.Windows.Forms.Button();
      this.cmdClearAll = new System.Windows.Forms.Button();
      this.cmdRemoveTriangle = new System.Windows.Forms.Button();
      this.cmdAddTriangle = new System.Windows.Forms.Button();
      this.lblText2 = new System.Windows.Forms.Label();
      this.lstTriangle = new System.Windows.Forms.ListBox();
      this.lstSelectedPoints = new System.Windows.Forms.CheckedListBox();
      this.lblText1 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdLoadXML
      // 
      this.cmdLoadXML.Location = new System.Drawing.Point(271, 224);
      this.cmdLoadXML.Name = "cmdLoadXML";
      this.cmdLoadXML.TabIndex = 21;
      this.cmdLoadXML.Text = "Load XML";
      this.cmdLoadXML.Click += new System.EventHandler(this.cmdLoadXML_Click);
      // 
      // cmdSaveXML
      // 
      this.cmdSaveXML.Location = new System.Drawing.Point(191, 224);
      this.cmdSaveXML.Name = "cmdSaveXML";
      this.cmdSaveXML.TabIndex = 20;
      this.cmdSaveXML.Text = "Save XML";
      this.cmdSaveXML.Click += new System.EventHandler(this.cmdSaveXML_Click);
      // 
      // cmdLoadBinary
      // 
      this.cmdLoadBinary.Location = new System.Drawing.Point(95, 224);
      this.cmdLoadBinary.Name = "cmdLoadBinary";
      this.cmdLoadBinary.TabIndex = 19;
      this.cmdLoadBinary.Text = "Load Binary";
      this.cmdLoadBinary.Click += new System.EventHandler(this.cmdLoadBinary_Click);
      // 
      // cmdSaveBinary
      // 
      this.cmdSaveBinary.Location = new System.Drawing.Point(15, 224);
      this.cmdSaveBinary.Name = "cmdSaveBinary";
      this.cmdSaveBinary.TabIndex = 18;
      this.cmdSaveBinary.Text = "Save Binary";
      this.cmdSaveBinary.Click += new System.EventHandler(this.cmdSaveBinary_Click);
      // 
      // cmdClearAll
      // 
      this.cmdClearAll.Location = new System.Drawing.Point(271, 144);
      this.cmdClearAll.Name = "cmdClearAll";
      this.cmdClearAll.TabIndex = 17;
      this.cmdClearAll.Text = "Clear All";
      this.cmdClearAll.Click += new System.EventHandler(this.cmdClearAll_Click);
      // 
      // cmdRemoveTriangle
      // 
      this.cmdRemoveTriangle.Location = new System.Drawing.Point(191, 144);
      this.cmdRemoveTriangle.Name = "cmdRemoveTriangle";
      this.cmdRemoveTriangle.TabIndex = 16;
      this.cmdRemoveTriangle.Text = "Remove";
      this.cmdRemoveTriangle.Click += new System.EventHandler(this.cmdRemoveTriangle_Click);
      // 
      // cmdAddTriangle
      // 
      this.cmdAddTriangle.Location = new System.Drawing.Point(15, 144);
      this.cmdAddTriangle.Name = "cmdAddTriangle";
      this.cmdAddTriangle.TabIndex = 13;
      this.cmdAddTriangle.Text = "Add";
      this.cmdAddTriangle.Click += new System.EventHandler(this.cmdAddTriangle_Click);
      // 
      // lblText2
      // 
      this.lblText2.Location = new System.Drawing.Point(191, 16);
      this.lblText2.Name = "lblText2";
      this.lblText2.TabIndex = 14;
      this.lblText2.Text = "Triangles";
      // 
      // lstTriangle
      // 
      this.lstTriangle.Location = new System.Drawing.Point(191, 40);
      this.lstTriangle.Name = "lstTriangle";
      this.lstTriangle.Size = new System.Drawing.Size(152, 95);
      this.lstTriangle.TabIndex = 15;
      // 
      // lstSelectedPoints
      // 
      this.lstSelectedPoints.Location = new System.Drawing.Point(15, 40);
      this.lstSelectedPoints.Name = "lstSelectedPoints";
      this.lstSelectedPoints.Size = new System.Drawing.Size(152, 94);
      this.lstSelectedPoints.TabIndex = 12;
      // 
      // lblText1
      // 
      this.lblText1.Location = new System.Drawing.Point(15, 16);
      this.lblText1.Name = "lblText1";
      this.lblText1.TabIndex = 11;
      this.lblText1.Text = "Select three points";
      // 
      // frmSerialize
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(360, 266);
      this.Controls.Add(this.cmdLoadXML);
      this.Controls.Add(this.cmdSaveXML);
      this.Controls.Add(this.cmdLoadBinary);
      this.Controls.Add(this.cmdSaveBinary);
      this.Controls.Add(this.cmdClearAll);
      this.Controls.Add(this.cmdRemoveTriangle);
      this.Controls.Add(this.cmdAddTriangle);
      this.Controls.Add(this.lblText2);
      this.Controls.Add(this.lstTriangle);
      this.Controls.Add(this.lstSelectedPoints);
      this.Controls.Add(this.lblText1);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSerialize";
      this.Text = "Test Serialize";
      this.Load += new System.EventHandler(this.frmSerialize_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSerialize'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSerialize()
      //***
      // Action
      //   - Create instance of 'frmSerialize'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSerialize()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpTriangleCollection mcolcpTriangle = new cpTriangleCollection();
    private string mstrBinaryFile = Application.StartupPath + "\\Triangles.dat";
    private string mstrXMLFile = Application.StartupPath + "\\Triangles.xml";

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAddTriangle_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there are 3 points selected
      //     - Create a cpTriangle using the 3 selected points
      //     - Add the cpTriangle to the collection of triangles
      //     - Clear the list of triangles
      //     - Show the list of triangles (the collection of triangles)
      //     - Clear all selected cpPoints
      //   - If not
      //     - Messagebox that there must be exactly 3 point selected
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpTriangle[] cpTriangleCollection.ToArray()
      //   - cpTriangle(cpXYPoint, cpXYPoint, cpXYPoint)
      //   - cpTriangleCollection.Add(cpTriangle)
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      CheckedListBox.CheckedItemCollection colCheckedPoint;
      cpTriangle aTriangle;
  
      colCheckedPoint = lstSelectedPoints.CheckedItems;

      if (colCheckedPoint.Count == 3)
      {
        aTriangle = new cpTriangle(
          (cpXYPoint)colCheckedPoint[0], 
          (cpXYPoint)colCheckedPoint[1],
          (cpXYPoint)colCheckedPoint[2]);
        mcolcpTriangle.Add(aTriangle);
        lstTriangle.Items.Clear();
        lstTriangle.Items.AddRange(mcolcpTriangle.ToArray());

        foreach (int lngItem in lstSelectedPoints.CheckedIndices)
        {
          lstSelectedPoints.SetItemChecked(lngItem, false);
        }
        // in lstSelectedPoints.CheckedIndices

      }
      else
        // colCheckedPoint.Count <> 3
      {
        MessageBox.Show("You must select exactly three points.");
      }
      // colCheckedPoint.Count = 3
    
    }
    // cmdAddTriangle_Click(System.Object, System.EventArgs) Handles cmdAddTriangle.Click

    private void cmdClearAll_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Clear the collection of triangles
      //   - Clear the list of triangles
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcolcpTriangle.Clear();
      lstTriangle.Items.Clear();
    }
    // cmdClearAll_Click(System.Object, System.EventArgs) Handles cmdClearAll.Click
    
    private void cmdLoadBinary_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Read the list of triangles (collection of triangles) from a XML file
      //   - Try to 
      //     - Open a XML file
      //     - Read some data in it
      //   - Finally
      //     - Close the file if it exists
      //     - Clear the list of triangles
      //     - Fill the list of triangles
      //   - On error show a message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpTriangle[] cpTriangleCollection.ToArray()
      //   - cpXYPoint(SerializationInfo, StreamingContext)
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BinaryFormatter theBinaryFormatter = new BinaryFormatter();
      FileStream theFileStream = null;

      try
      {
        theFileStream = new FileStream(mstrBinaryFile, System.IO.FileMode.Open);

        mcolcpTriangle = (cpTriangleCollection)theBinaryFormatter.Deserialize(theFileStream);
      }
      catch
      {
        MessageBox.Show("Data file does not exist.");
      }
      finally
      {
        if (theFileStream == null)
        {}
        else
          // theFileStream <> null
        {
          theFileStream.Close();
          lstTriangle.Items.Clear();
          lstTriangle.Items.AddRange(mcolcpTriangle.ToArray());
        }
        // theStreamReader = null

      }

    }
    // cmdLoadBinary_Click(System.Object, System.EventArgs) Handles cmdLoadBinary.Click

    private void cmdLoadXML_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Read the list of triangles (collection of triangles) from a XML file
      //   - Try to 
      //     - Open a XML file
      //     - Read some data in it
      //     - Clear the list of triangles
      //     - Fill the list of triangles
      //   - Finally
      //     - Close the file if it exists
      //   - On error show a message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpTriangle[] cpTriangleCollection.ToArray() 
      //   - cpTriangle()
      //   - cpTriangleCollection.Add(cpTriangle)
      //   - cpTriangleCollection()
      //   - cpXYPoint()
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      StreamReader theStreamReader = null;
      XmlSerializer theXMLSerializer;

      try
      {
        theStreamReader = new StreamReader(mstrXMLFile);
        theXMLSerializer = new XmlSerializer(System.Type.GetType("CopyPaste.Learning.cpTriangleCollection"));
        
        mcolcpTriangle = (cpTriangleCollection)theXMLSerializer.Deserialize(theStreamReader);
      }
      catch
      {
        MessageBox.Show("XML file does not exist.");
      }
      finally
      {
        
        if (theStreamReader == null)
        {
        }
        else
          // theStreamReader <> null
        {
          theStreamReader.Close();
          lstTriangle.Items.Clear();
          lstTriangle.Items.AddRange(mcolcpTriangle.ToArray());
        }
        // theStreamReader = null

      }
    
    }
    // cmdLoadXML_Click(System.Object, System.EventArgs) Handles cmdLoadXML.Click

    private void cmdRemoveTriangle_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Remove a triangle from the list
      //   - If there is a triangle selected
      //     - Remove the triangle from the collection
      //     - Clear the list
      //     - Fill the list
      //   - If not
      //     - Nothing happens
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpTriangleCollection.Remove(cpTriangle)
      //   - cpTriangle[] cpTriangleCollection.ToArray()
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (lstTriangle.SelectedIndex == -1)
      {
      }
      else
        // lstTriangle.SelectedIndex <> -1
      {
        mcolcpTriangle.Remove((cpTriangle)lstTriangle.SelectedItem);
        lstTriangle.Items.Clear();
        lstTriangle.Items.AddRange(mcolcpTriangle.ToArray());
      }
      // lstTriangle.SelectedIndex = -1
    
    }
    // cmdRemoveTriangle_Click(System.Object, System.EventArgs) Handles cmdRemoveTriangle.Click
    
    private void cmdSaveBinary_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Save the list of triangles (collection of triangles) towards a binary file
      //   - Try to 
      //     - Create a binary file
      //     - Save some data in it
      //   - Finally
      //     - Close the file stream if it exists
      //   - On error show a message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpXYPoint.GetObjectData(SerializationInfo, StreamingContext)
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BinaryFormatter theBinaryFormatter = new BinaryFormatter();
      FileStream theFileStream = null;

      try
      {
        theFileStream = new FileStream(mstrBinaryFile, System.IO.FileMode.Create);

        theBinaryFormatter.Serialize(theFileStream, mcolcpTriangle);
      }
      catch
      {
        MessageBox.Show("Data file is not created.");
      }
      finally
      {

        if (theFileStream == null)
        {
        }
        else
          // theFileStream <> null
        {
          theFileStream.Close();
        }
        // theFileStream = null

      }

    }
    // cmdSaveBinary_Click(System.Object, System.EventArgs) Handles cmdSaveBinary.Click
    
    private void cmdSaveXML_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Save the list of triangles (collection of triangles) towards a XML file
      //   - Try to 
      //     - Create a XML file
      //     - Save some data in it
      //   - Finally
      //     - Close the file if it exists
      //   - On error show a message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpTriangle cpTriangleCollection.this[int] (Get)
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      StreamWriter theStreamWriter = null;
      XmlSerializer theXMLSerializer;

      try
      {
        theStreamWriter = new StreamWriter(mstrXMLFile);
        theXMLSerializer = new XmlSerializer(mcolcpTriangle.GetType());

        theXMLSerializer.Serialize(theStreamWriter, mcolcpTriangle);
      }
      catch
      {
        MessageBox.Show("XML file is not created.");
      }
      finally
      {
        
        if (theStreamWriter == null)
        {
        }
        else
          // theStreamWriter <> null
        {
          theStreamWriter.Close();
        }
        // theStreamWriter = null

      }
    
    }
    // cmdSaveXML_Click(System.Object, System.EventArgs) Handles cmdSaveXML.Click

    private void frmSerialize_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - All every point between (0, 0) and (6, 6) (borders included)
      //   - Loop thru X coordinates from 0 till 6
      //     - Loop thru Y coordinates from 0 till 6
      //       - Add the point (X, Y)
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpXYPoint(int, int)
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngX;
      int lngY;

      for (lngX = 0; lngX <= 6; lngX++)
      {

        for (lngY = 0; lngY <= 6; lngY++)
        {
          lstSelectedPoints.Items.Add(new cpXYPoint(lngX, lngY));
        }
        // lngY = 7

      }
      // lngX = 7
    
    }
    // frmSerialize_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSerialize
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSerialize()
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSerialize());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSerialize

}
// CopyPaste.Learning