﻿//***
// Action
//   - A factorial routine are compared to each other
// Created
//   - CopyPaste – 20260624 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260624 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpFactorial
  {

    #region "Constructors / Destructors"

    public cpFactorial()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main() 
    //   - cpProgram.RunSomeCode()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260624 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260624 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpFactorial()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [BenchmarkAttribute]
    [ArgumentsSourceAttribute(nameof(Numbers))]
    public BigInteger Factorial01(BigInteger bintNumber)
    //***
    // Action
    //   - Calculate the factorial of a number using a recursive method
    // Called by
    //   - cpProgram.Main()
    //   - cpProgram.RunSomeCode()
    //   - BigInteger Factorial01(BigInteger)
    // Calls
    //   - BigInteger Factorial01(BigInteger)
    // Created
    //   - CopyPaste – 20260624 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260624 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      BigInteger bintResult = 0;

      if (bintNumber == 0)
      {
        bintResult = 1;
      }
      else
      // bintNumber <> 0
      {
        bintResult = bintNumber * Factorial01(bintNumber - 1);
      }
      // bintNumber == 0

      return bintResult;
    }
    // Factorial01()

    [BenchmarkAttribute]
    [ArgumentsSourceAttribute(nameof(Numbers))]
    public BigInteger Factorial02(BigInteger bintNumber)
    //***
    // Action
    //   - Calculate the factorial of a number using a recursive method
    // Called by
    //   - BigInteger Factorial02(BigInteger)
    //   - cpProgram.Main()
    //   - cpProgram.RunSomeCode()
    // Calls
    //   - BigInteger Factorial02(BigInteger)
    // Created
    //   - CopyPaste – 20260624 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260624 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      BigInteger bintResult = 0;

      bintResult = (bintNumber == 0) ? 1 : bintNumber * Factorial02(bintNumber - 1);

      return bintResult;
    }
    // BigInteger Factorial02(BigInteger)

    [BenchmarkAttribute]
    [ArgumentsSourceAttribute(nameof(Numbers))]
    public BigInteger Factorial03(BigInteger bintNumber)
    //***
    // Action
    //   - Calculate the factorial of a number using a recursive method
    // Called by
    //   - cpProgram.Main()
    //   - cpProgram.RunSomeCode()
    //   - BigInteger Factorial03(BigInteger)
    // Calls
    //   - BigInteger Factorial03(BigInteger)
    // Created
    //   - CopyPaste – 20260624 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260624 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      if (bintNumber == 0)
      {
        return 1;
      }
      else
      // bintNumber <> 0
      {
        return bintNumber * Factorial01(bintNumber - 1);
      }
      // bintNumber == 0

    }
    // Factorial01()

    [BenchmarkAttribute]
    [ArgumentsSourceAttribute(nameof(Numbers))]
    public BigInteger Factorial04(BigInteger bintNumber)
    //***
    // Action
    //   - Calculate the factorial of a number using a recursive method
    // Called by
    //   - BigInteger Factorial04(BigInteger)
    //   - cpProgram.Main()
    //   - cpProgram.RunSomeCode()
    // Calls
    //   - BigInteger Factorial04(BigInteger)
    // Created
    //   - CopyPaste – 20260624 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260624 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      return (bintNumber == 0) ? 1 : bintNumber * Factorial02(bintNumber - 1);
    }
    // BigInteger Factorial04(BigInteger)

    public IEnumerable<BigInteger> Numbers()
    //***
    // Action
    //   - Calculate the factorial of a number using a recursive method using the yield return statement
    // Called by
    //   -
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260624 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260624 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      yield return 0;
      yield return 1;
      yield return 5;
      yield return 10;
      yield return 50;
      yield return 100;
    }
    // IEnumerable<BigInteger> Numbers()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpFactorial

}
// CopyPaste.Learning