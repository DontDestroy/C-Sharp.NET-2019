//***
// Action
//   - Definition of a Customer (linked with customer interface)
//   - This contains (thru the customer component interface)
//     - Customer connection (Connection string)
//     - Customer data adapter
//   - This contains (thru the customer class interface)
//     - Properties
//     - Methods
// Created
//   - CopyPaste � 20260117 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260117 � VVDW
// Proposal (To Do)
//   -
//***

using DataClassCustomer;
using System;
using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpCustomer : cmpCustomer, cpiCustomer
  {

    #region "Constructors / Destructors"

    public cpCustomer()
      //***
      // Action
      //   - Create new instance of 'cpCustomer'
      // Called by
      //   - frmCustomer()
      //   - frmCustomerRead()
      //   - frmCustomerUpdate()
      //   - frmCustomerValidation()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpCustomer()

    public cpCustomer(string strKeyCustomer)
      //***
      // Action
      //   - Create new instance of 'cpCustomer' with a unique key
      //   - Set an instance of dsCustomer
      //   - If strKeyCustomer is valid (5 characters long)
      //     - Try to
      //       - Set the parameter for the data adapter command (strKeyCustomer)
      //       - Fill the data set using the data adapter
      //       - If there is one record found
      //         - Fill the data row with the found record
      //         - Read the values from the dat row
      //       - If not (there are none)
      //         - Throw the application exception that the customer was not found
      //         - Attention: Thru database constraints it is impossible
      //     - When error occurs
      //       - Throw new application exception that customer row could not be retrieved
      //   - If Not
      //     - Throw a new cpInvalidKeyCustomer
      // Called by
      //   - frmCustomerRead.cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click
      //   - frmCustomerUpdate.cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click
      //   - frmCustomerValidation.cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click
      // Calls
      //   - bool ValidateKeyCustomer(string)
      //   - cpInvalidKeyCustomerException(string)
      //   - ReadValuesFromDataRow()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdsCustomer = new dsCustomer();

      if (ValidateKeyCustomer(strKeyCustomer))
      {

        try
        {
          base.dtaCustomer.SelectCommand.Parameters["@KeyCustomer"].Value = strKeyCustomer;
          dtaCustomer.Fill(mdsCustomer, "tblCPCustomer");

          if (mdsCustomer.tblCPCustomer.Rows.Count == 1)
          {
            mdrwCustomer = (dsCustomer.tblCPCustomerRow)mdsCustomer.tblCPCustomer.Rows[0];
            ReadValuesFromDataRow();
          }
          else
            // mdsCustomer.tblCPCustomer.Rows.Count <> 1
          {
            throw new ApplicationException("The customer " + strKeyCustomer + " was not found.");
          }
          // mdsCustomer.tblCPCustomer.Rows.Count = 1
        
        }
        catch (Exception theException)
        {
          throw new ApplicationException("The customer row could not be retrieved." +
            Environment.NewLine + theException.Message);
        }
        finally
        {
        }
      
      }
      else
        // Not ValidateKeyCustomer(strKeyCustomer)
      {
        throw new cpInvalidKeyCustomerException(strKeyCustomer);
      }
      // ValidateKeyCustomer(strKeyCustomer)

    }
    // cpCustomer(string)

    public cpCustomer(string strKeyCustomer, string strCompanyName)
      //***
      // Action
      //   - Create new instance of 'cpCustomer' with a unique key and a company name
      //   - If strKeyCustomer is valid (5 characters long)
      //     - If strKeyCustomer already exists
      //       - Set an instance of dsCustomer
      //       - Set boolean new to true
      //       - Set customer Id
      //       - Set Company name to given company name
      //       - All other properties are set to empty string
      //   - If strKeyCustomer is valid (5 characters long)
      //     - Try to
      //       - Set the parameter for the data adapter command (strKeyCustomer)
      //       - Fill the data set using the data adapter
      //       - If there is one record found
      //         - Fill the data row with the found record
      //         - Read the values from the dat row
      //       - If not (there are none)
      //         - Throw the application exception that the customer was not found
      //         - Attention: Thru database constraints it is impossible
      //     - When error occurs
      //       - Throw new application exception that customer row could not be retrieved
      //   - If Not
      //     - Throw a new cpInvalidKeyCustomer
      // Called by
      //   - frmCustomerUpdate.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      // Calls
      //   - Address(string) (Set)
      //   - bool DoesKeyCustomerExist(string)
      //   - bool ValidateKeyCustomer(string)
      //   - City(string) (Set)
      //   - CompanyName(string) (Set)
      //   - ContactName(string) (Set)
      //   - ContactTitle(string) (Set)
      //   - Country(string) (Set)
      //   - cpInvalidKeyCustomerException(string)
      //   - Fax(string) (Set)
      //   - Phone(string) (Set)
      //   - PostalCode(string) (Set)
      //   - ReadValuesFromDataRow()
      //   - Region(string) (Set)
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (ValidateKeyCustomer(strKeyCustomer))
      {

        if (DoesKeyCustomerExist(strKeyCustomer))
        {
          throw new cpInvalidKeyCustomerException(strKeyCustomer);
        }
        else
          // Not DoesKeyCustomerExist(strKeyCustomer)
        {
          mdsCustomer = new dsCustomer();

          mblnNew = true;
          mstrIdCustomer = strKeyCustomer;
          // VVDW - Only the getter is implemented

          CompanyName = strCompanyName;
          ContactName = "";
          ContactTitle = "";
          Address = "";
          City = "";
          Region = "";
          Country = "";
          PostalCode = "";
          Phone = "";
          Fax = "";
        }
        // DoesKeyCustomerExist(strKeyCustomer)

      }
      else
        // Not ValidateKeyCustomer(strKeyCustomer)
      {
        throw new cpInvalidKeyCustomerException(strKeyCustomer);
      }
      // ValidateKeyCustomer(strKeyCustomer)

    }
    // cpCustomer(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private bool mblnNew;
    private bool mblnValidation;
    private dsCustomer.tblCPCustomerRow mdrwCustomer;
    private dsCustomer mdsCustomer;
    private string mstrAddress;
    private string mstrCity;
    private string mstrCompanyName;
    private string mstrContactName;
    private string mstrContactTitle;
    private string mstrCountry;
    private string mstrFax;
    private string mstrIdCustomer;
    private string mstrPhone;
    private string mstrPostalCode;
    private string mstrRegion;
    
    #endregion

    #region "Properties"

    public string Address
    {

      get
        //***
        // Action Get
        //   - Return 'mstrAddress'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerRead.CustomerProperties()
        //   - frmCustomerUpdate.CustomerProperties()
        //   - frmCustomerValidation.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrAddress;
      }
      // string Address (Get)

      set
        //***
        // Action Set
        //   - If Validation is true
        //     - If length of value > 60
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrAddress becomes value
        //   - If not
        //     - mstrAddress becomes value
        // Called by
        //   - Clear()
        //   - cpCustomer(string, string)
        //   - frmCustomer.TextBoxChange(string, string)
        //   - frmCustomerRead.TextBoxChange(string, string)
        //   - frmCustomerUpdate.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerUpdate.TextBoxChange(string, string)
        //   - frmCustomerValidation.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidation.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 60)
          {
            throw new cpInvalidStringLengthException(60, "Address", value);
          }
          else
            // value.Length <= 60
          {
            mstrAddress = value;
          }
          // value.Length > 60
        
        }
        else
          // Not Validation
        {
          mstrAddress = value;
        }
        // Validation

      }
      // Address(string) (Set)

    }
    // String Address Implements cpiCustomer.Address

    public string City
    {

      get
        //***
        // Action Get
        //   - Return 'mstrCity'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerRead.CustomerProperties()
        //   - frmCustomerUpdate.CustomerProperties()
        //   - frmCustomerValidation.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrCity;
      }
      // string City (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of value > 15
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrCity becomes value
        //   - If not
        //     - mstrCity becomes value
        // Called by
        //   - Clear()
        //   - cpCustomer(string, string)
        //   - frmCustomer.TextBoxChange(string, string)
        //   - frmCustomerRead.TextBoxChange(string, string)
        //   - frmCustomerUpdate.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerUpdate.TextBoxChange(string, string)
        //   - frmCustomerValidation.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidation.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 15)
          {
            throw new cpInvalidStringLengthException(15, "City", value);
          }
          else
            // value.Length <= 15
          {
            mstrCity = value;
          }
          // value.Length > 15
        
        }
        else
          // Not Validation
        {
          mstrCity = value;
        }
        // Validation

      }
      // City(string) (Set)

    }
    // string City Implements cpiCustomer.City

    public string CompanyName
    {

      get
        //***
        // Action Get
        //   - Return 'mstrCompanyName'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerRead.CustomerProperties()
        //   - frmCustomerUpdate.CustomerProperties()
        //   - frmCustomerValidation.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrCompanyName;
      }
      // string CompanyName (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of value > 40
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrCompanyName becomes value
        //   - If not
        //     - mstrCompanyName becomes value
        // Called by
        //   - Clear()
        //   - cpCustomer(string, string)
        //   - ReadValuesFromDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        //   - frmCustomer.TextBoxChange(string, string)
        //   - frmCustomerRead.TextBoxChange(string, string)
        //   - frmCustomerUpdate.TextBoxChange(string, string)
        //   - frmCustomerValidation.TextBoxChange(string, string)
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 40)
          {
            throw new cpInvalidStringLengthException(40, "CompanyName", value);
          }
          else
            // value.Length <= 40
          {
            mstrCompanyName = value;
          }
          // value.Length > 40
        
        }
        else
          // Not Validation
        {
          mstrCompanyName = value;
        }
        // Validation

      }
      // CompanyName(string) (Set)

    }
    // string CompanyName Implements cpiCustomer.CompanyName

    public string ContactName
    {

      get
        //***
        // Action Get
        //   - Return 'mstrContactName'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerRead.CustomerProperties()
        //   - frmCustomerUpdate.CustomerProperties()
        //   - frmCustomerValidation.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrContactName;
      }
      // string ContactName (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of vValue > 30
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrContactName becomes value
        //   - If not
        //     - mstrContactName becomes value
        // Called by
        //   - Clear()
        //   - cpCustomer(string, string)
        //   - frmCustomer.TextBoxChange(string, string)
        //   - frmCustomerRead.TextBoxChange(string, string)
        //   - frmCustomerUpdate.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerUpdate.TextBoxChange(string, string)
        //   - frmCustomerValidation.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidation.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 30)
          {
            throw new cpInvalidStringLengthException(30, "ContactName", value);
          }
          else
            // value.Length <= 30
          {
            mstrContactName = value;
          }
          // value.Length > 30
        
        }
        else
          // Not Validation
        {
          mstrContactName = value;
        }
        // Validation

      }
      // ContactName(string) (Set)

    }
    // string ContactName Implements cpiCustomer.ContactName

    public string ContactTitle
    {

      get
        //***
        // Action Get
        //   - Return 'mstrContactTitle'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerRead.CustomerProperties()
        //   - frmCustomerUpdate.CustomerProperties()
        //   - frmCustomerValidation.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrContactTitle;
      }
      // string ContactTitle (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of value > 30
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrContactTitle becomes value
        //   - If not
        //     - mstrContactTitle becomes value
        // Called by
        //   - Clear()
        //   - cpCustomer(string, string)
        //   - frmCustomer.TextBoxChange(string, string)
        //   - frmCustomerRead.TextBoxChange(string, string)
        //   - frmCustomerUpdate.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerUpdate.TextBoxChange(string, string)
        //   - frmCustomerValidation.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidation.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 30)
          {
            throw new cpInvalidStringLengthException(30, "ContactTitle", value);
          }
          else
            // value.Length <= 30
          {
            mstrContactTitle = value;
          }
          // value.Length > 30
        
        }
        else
          // Not Validation
        {
          mstrContactTitle = value;
        }
        // Validation

      }
      // ContactTitle(string) (Set)

    }
    // string ContactTitle Implements cpiCustomer.ContactTitle

    public string Country
    {

      get
        //***
        // Action Get
        //   - Return 'mstrCountry'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerRead.CustomerProperties()
        //   - frmCustomerUpdate.CustomerProperties()
        //   - frmCustomerValidation.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrCountry;
      }
      // string Country (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of value > 15
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrContactTitle becomes value
        //   - If not
        //     - mstrContactTitle becomes value
        // Called by
        //   - Clear()
        //   - cpCustomer(string, string)
        //   - frmCustomer.TextBoxChange(string, string)
        //   - frmCustomerRead.TextBoxChange(string, string)
        //   - frmCustomerUpdate.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerUpdate.TextBoxChange(string, string)
        //   - frmCustomerValidation.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidation.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 15)
          {
            throw new cpInvalidStringLengthException(15, "Country", value);
          }
          else
            // value.Length <= 15
          {
            mstrCountry = value;
          }
          // value.Length > 15
        
        }
        else
          // Not Validation
        {
          mstrCountry = value;
        }
        // Validation

      }
      // Country(string) (Set)

    }
    // string Country Implements cpiCustomer.Country

    public string Fax
    {

      get
        //***
        // Action Get
        //   - Return 'mstrFax'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerRead.CustomerProperties()
        //   - frmCustomerUpdate.CustomerProperties()
        //   - frmCustomerValidation.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrFax;
      }
      // string Fax (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of value > 24
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - If ValidatePhoneNumber is true
        //         - mstrFax becomes value
        //       - If not
        //         - Throw new cpInvalidPhoneNumberException with correct info
        //   - If not
        //     - mstrFax becomes value
        // Called by
        //   - Clear()
        //   - cpCustomer(string, string)
        //   - frmCustomer.TextBoxChange(string, string)
        //   - frmCustomerRead.TextBoxChange(string, string)
        //   - frmCustomerUpdate.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerUpdate.TextBoxChange(string, string)
        //   - frmCustomerValidation.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidation.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        // Calls
        //   - bool ValidatePhoneNumber(string)
        //   - bool Validation (Get)
        //   - cpInvalidPhoneNumberException(string)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 24)
          {
            throw new cpInvalidStringLengthException(24, "Fax", value);
          }
          else
            // value.Length <= 24
          {
            
            if (ValidatePhoneNumber(value))
            {
              mstrFax = value;
            }
            else
              // Not ValidatePhoneNumber(value)
            {
              throw new cpInvalidPhoneNumberException(value);
            }
            // ValidatePhoneNumber(value)

          }
          // value.Length > 24
        
        }
        else
          // Not Validation
        {
          mstrFax = value;
        }
        // Validation

      }
      // Fax(string) (Set)

    }
    // string Fax Implements cpiCustomer.Fax

    public string IdCustomer
    {

      get
        //***
        // Action Get
        //   - Return 'mstrIdCustomer'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - string ToString() Implements cpiCustomer.ToString
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrIdCustomer;
      }
      // string IdCustomer (Get)

    }
    // string IdCustomer Implements cpiCustomer.IdCustomer

    public string Phone
    {

      get
        //***
        // Action Get
        //   - Return 'mstrPhone'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerRead.CustomerProperties()
        //   - frmCustomerUpdate.CustomerProperties()
        //   - frmCustomerValidation.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrPhone;
      }
      // string Phone (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of value > 24
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - If ValidatePhoneNumber is true
        //         - mstrFax becomes value
        //       - If not
        //         - Throw new cpInvalidPhoneNumberException with correct info
        //   - If not
        //     - mstrPhone becomes value
        // Called by
        //   - Clear()
        //   - cpCustomer(string, string)
        //   - frmCustomer.TextBoxChange(string, string)
        //   - frmCustomerRead.TextBoxChange(string, string)
        //   - frmCustomerUpdate.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerUpdate.TextBoxChange(string, string)
        //   - frmCustomerValidation.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidation.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        // Calls
        //   - bool ValidatePhoneNumber(string)
        //   - bool Validation (Get)
        //   - cpInvalidPhoneNumberException(string)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 24)
          {
            throw new cpInvalidStringLengthException(24, "Phone", value);
          }
          else
            // value.Length <= 24
          {
            
            if (ValidatePhoneNumber(value))
            {
              mstrPhone = value;
            }
            else
              // Not ValidatePhoneNumber(value)
            {
              throw new cpInvalidPhoneNumberException(value);
            }
            // ValidatePhoneNumber(value)

          }
          // value.Length > 24
        
        }
        else
          // Not Validation
        {
          mstrPhone = value;
        }
        // Validation

      }
      // Phone(string) (Set)

    }
    // string Phone Implements cpiCustomer.Phone

    public string PostalCode
    {

      get
        //***
        // Action Get
        //   - Return 'mstrPostalCode'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerRead.CustomerProperties()
        //   - frmCustomerUpdate.CustomerProperties()
        //   - frmCustomerValidation.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrPostalCode;
      }
      // string PostalCode (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of value > 10
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrPostalCode becomes value
        //   - If not
        //     - mstrPostalCode becomes value
        // Called by
        //   - Clear()
        //   - cpCustomer(string, string)
        //   - frmCustomer.TextBoxChange(string, string)
        //   - frmCustomerRead.TextBoxChange(string, string)
        //   - frmCustomerUpdate.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerUpdate.TextBoxChange(string, string)
        //   - frmCustomerValidation.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidation.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 10)
          {
            throw new cpInvalidStringLengthException(10, "Postal Code", value);
          }
          else
            // value.Length <= 10
          {
            mstrPostalCode = value;
          }
          // value.Length > 10
        
        }
        else
          // Not Validation
        {
          mstrPostalCode = value;
        }
        // Validation

      }
      // PostalCode(string) (Set)

    }
    // string PostalCode Implements cpiCustomer.PostalCode

    public string Region
    {

      get
        //***
        // Action Get
        //   - Return 'mstrRegion'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerRead.CustomerProperties()
        //   - frmCustomerUpdate.CustomerProperties()
        //   - frmCustomerValidation.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrRegion;
      }
      // string Region (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of value > 15
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrRegion becomes value
        //   - If not
        //     - mstrRegion becomes value
        // Called by
        //   - Clear()
        //   - cpCustomer(string, string)
        //   - frmCustomer.TextBoxChange(string, string)
        //   - frmCustomerRead.TextBoxChange(string, string)
        //   - frmCustomerUpdate.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerUpdate.TextBoxChange(string, string)
        //   - frmCustomerValidation.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidation.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 15)
          {
            throw new cpInvalidStringLengthException(15, "Region", value);
          }
          else
            // value.Length <= 15
          {
            mstrRegion = value;
          }
          // value.Length > 15
        
        }
        else
          // Not Validation
        {
          mstrRegion = value;
        }
        // Validation

      }
      // Region (string) (Set)

    }
    // string Region Implements cpiCustomer.Region

    public bool Validation
    {

      get
        //***
        // Action Get
        //   - Return 'mblnValidation'
        // Called by
        //   - Address(string) (Set)
        //   - City(string) (Set) 
        //   - CompanyName(string) (Set)
        //   - ContactName(string) (Set)
        //   - ContactTitle(string) (Set)
        //   - Country(string) (Set)
        //   - Fax(string) (Set)
        //   - Phone(string) (Set)
        //   - PostalCode(string) (Set)
        //   - Region(string) (Set)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mblnValidation;
      }
      // bool Validation (Get)

      set
        //***
        // Action
        //   - mblnValidation becomes value
        // Called by
        //   - frmCustomerValidation()
        //   - frmCustomerValidation.cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260117 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260117 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mblnValidation = value;
      }
      // Validation(bool)

    }
    // bool Validation

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Create the default return value of a cpCustomer
      // Called by
      //   - frmCustomer.TextBoxChange(string, string)
      //   - frmCustomerRead.TextBoxChange(string, string)
      //   - frmCustomerUpdate.TextBoxChange(string, string)
      //   - frmCustomerValidation.TextBoxChange(string, string)
      // Calls
      //   - string Address (Get)
      //   - string City (Get)
      //   - string CompanyName (Get)
      //   - string ContactName (Get)
      //   - string ContactTitle (Get)
      //   - string Country (Get)
      //   - string Fax (Get)
      //   - string IdCustomer (Get)
      //   - string Phone (Get)
      //   - string PostalCode (Get)
      //   - string Region (Get)
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strReturn;

      strReturn = "" +
        "Key:         " + IdCustomer + Environment.NewLine + 
        "Company:     " + CompanyName + Environment.NewLine + 
        "Contact:     " + ContactName + Environment.NewLine + 
        "Title:       " + ContactTitle + Environment.NewLine + 
        "Address:     " + Address + Environment.NewLine + 
        "City:        " + City + Environment.NewLine + 
        "Postal Code: " + PostalCode + Environment.NewLine + 
        "Country:     " + Country + Environment.NewLine + 
        "Phone:       " + Phone + Environment.NewLine + 
        "Fax:         " + Fax + Environment.NewLine + 
        "Region       " + Region + Environment.NewLine;
      return strReturn;
    }
    // string ToString() Implements cpiCustomer.ToString

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void Clear()
      //***
      // Action
      //   - Set the data row of the customer to nothing
      //   - Clear the data set of the customer to nothing
      //   - Set the unique key of the customer to nothing
      //   - Clear all properties
      //     - Address
      //     - City
      //     - CompanyName
      //     - ContactName
      //     - ContactTitle
      //     - Country
      //     - Fax
      //     - Phone
      //     - PostalCode
      //     - Region
      // Called by
      //   - bool Delete() Implements cpiCustomer.Delete
      // Calls
      //   - Address(string) (Set)
      //   - City(string) (Set)
      //   - CompanyName(string) (Set)
      //   - ContactName(string) (Set)
      //   - ContactTitle(string) (Set)
      //   - Country(string) (Set)
      //   - Fax(string) (Set)
      //   - Phone(string) (Set)
      //   - PostalCode(string) (Set)
      //   - Region(string) (Set)
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdrwCustomer = null;
      mdsCustomer = null;
      mstrIdCustomer = null;
      Address = null;
      City = null;
      CompanyName = null;
      ContactName = null;
      ContactTitle = null;
      Country = null;
      Fax = null;
      Phone = null;
      PostalCode = null;
      Region = null;
    }
    // Clear()

    public bool Delete()
      //***
      // Action
      //   - Define a result value
      //   - If you are busy adding a new customer
      //     - Clear the information
      //     - Set return value to true
      //   - If not
      //     - Delete the data row of the customer
      //     - Write the changes to the database
      //     - If successful
      //       - Clear the information
      //       - Set return value to true
      //     - If not
      //       - Reject the changes of the customer data row
      //       - Set return value to false
      //   - Return result
      // Called by
      //   - frmCustomerUpdate.cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click
      //   - frmCustomerValidation.cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click
      // Calls
      //   - bool WriteChangesToDatabase(DataRowState)
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnReturn;

      if (mblnNew)
      {
        Clear();
        blnReturn = true;
      }
      else
        // Not mblnNew
      {
        mdrwCustomer.Delete();

        if (WriteChangesToDatabase(DataRowState.Deleted))
        {
          Clear();
          blnReturn = true;
        }
        else
          // Not WriteChangesToDatabase(DataRowState.Deleted)
        {
          mdrwCustomer.RejectChanges();
          blnReturn = false;
        }
        // WriteChangesToDatabase(DataRowState.Deleted)

      }
      // mblnNew

      return blnReturn;
    }
    // bool Delete() Implements cpiCustomer.Delete 

    private bool DoesKeyCustomerExist(string strKeyCustomer)
      //***
      // Action
      //   - Define a boolean
      //   - Define a SQL command
      //   - Define and set a SQL Statement
      //     - Count the customers with a specific key (strKeyCustomer)
      //   - Set the SQL command with the SQL statement and the connection
      //   - Open the connection
      //   - Execute the SQL command (what returns a number (0 or 1)
      //   - Convert the result to a boolean
      //   - Close the connection
      //   - Return the boolean
      // Called by
      //   - cpCustomer(string, string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnExists;
      SqlCommand cmmSelect;
      string strSQLStatement;

      strSQLStatement = "SELECT Count(*) FROM tblCPCustomer WHERE strIdCustomer = '" + strKeyCustomer + "'";
      cmmSelect = new SqlCommand(strSQLStatement, cnncpNorthwindScript2019);
      cnncpNorthwindScript2019.Open();
      blnExists = Convert.ToBoolean(cmmSelect.ExecuteScalar());
      cnncpNorthwindScript2019.Close();
      return blnExists;
    }
    // bool DoesKeyCustomerExist(string)

    public void ReadValuesFromDataRow()
      //***
      // Action
      //   - Set values from Customer Data Row into cpCustomer
      //   - mstrIdCustomer becomse strIdCustomer
      //   - CompanyName becomes strCompanyName
      //   - Do routine for strAddress, strCity, strContactName, strContactTitle,
      //     - strCountry, strFax, strPhone, strPostalCode, strRegion)
      //   - Routine:
      //     - If strXxx Is null Then
      //       - Property becomes empty string
      //     - If not
      //       - Property becomes strXxx
      // Called by
      //   - cpCustomer(string)
      // Calls
      //   - Address(string) (Set)
      //   - City(string) (Set)
      //   - CompanyName(string) (Set)
      //   - ContactName(string) (Set)
      //   - ContactTitle(string) (Set)
      //   - Country(string) (Set)
      //   - Fax(string) (Set)
      //   - Phone(string) (Set)
      //   - PostalCode(string) (Set)
      //   - Region(string) (Set)
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrIdCustomer = mdrwCustomer.strIdCustomer;
      CompanyName = mdrwCustomer.strCompanyName;

      if (mdrwCustomer.IsstrAddressNull())
      {
        Address = "";
      }
      else
        // Not mdrwCustomer.IsstrAddressNull()
      {
        Address = mdrwCustomer.strAddress;
      }
      // mdrwCustomer.IsstrAddressNull()

      if (mdrwCustomer.IsstrCityNull())
      {
        City = "";
      }
      else
        // Not mdrwCustomer.IsstrCityNull 
      {
        City = mdrwCustomer.strCity;
      }
      // mdrwCustomer.IsstrCityNull 

      if (mdrwCustomer.IsstrContactNameNull())
      {
        ContactName = "";
      }
      else
        // Not mdrwCustomer.IsstrContactNameNull()
      {
        ContactName = mdrwCustomer.strContactName;
      }
      // mdrwCustomer.IsstrContactNameNull() 

      if (mdrwCustomer.IsstrContactTitleNull())
      {
        ContactTitle = "";
      }
      else
        // Not mdrwCustomer.IsstrContactTitleNull()
      {
        ContactTitle = mdrwCustomer.strContactTitle;
      }
      // mdrwCustomer.IsstrContactTitleNull() 

      if (mdrwCustomer.IsstrCountryNull())
      {
        Country = "";
      }
      else
        // Not mdrwCustomer.IsstrCountryNull()
      {
        Country = mdrwCustomer.strCountry;
      }
      // mdrwCustomer.IsstrCountryNull() 

      if (mdrwCustomer.IsstrFaxNull())
      {
        Fax = "";
      }
      else
        // Not mdrwCustomer.IsstrFaxNull() 
      {
        Fax = mdrwCustomer.strFax;
      }
      // mdrwCustomer.IsstrFaxNull() 

      if (mdrwCustomer.IsstrPhoneNull())
      {
        Phone = "";
      }
      else
        // Not mdrwCustomer.IsstrPhoneNull()
      {
        Phone = mdrwCustomer.strPhone;
      }
      // mdrwCustomer.IsstrPhoneNull() 

      if (mdrwCustomer.IsstrPostalCodeNull())
      {
        PostalCode = "";
      }
      else
        // Not mdrwCustomer.IsstrPostalCodeNull()
      {
        PostalCode = mdrwCustomer.strPostalCode;
      }
      // mdrwCustomer.IsstrPostalCodeNull()

      if (mdrwCustomer.IsstrRegionNull())
      {
        Region = "";
      }
      else
        // Not mdrwCustomer.IsstrRegionNull() 
      {
        Region = mdrwCustomer.strRegion;
      }
      // mdrwCustomer.IsstrRegionNull() 

    }
    // ReadValuesFromDataRow()

    public bool Save()
      //***
      // Action
      //   - Define a row state
      //   - If blnNew
      //     - Set the data row of customer an added row to the data set
      //     - Put the state to added
      //     - Set blnNew to false
      //   - If not
      //     - Set the state to modified
      //   - Try to
      //     - Start editing the data row
      //     - Write the values to the data row
      //     - Stop editing the data row
      //     - Write the changes to the data base
      //     - If successful
      //       - Set return value to true
      //     - If not
      //       - Reject the changes of the data row
      //       - Set return value to false
      //   - When error occurs
      //     - Cancel editing the data row
      //     - Reject the changes of the data row
      //     - Set return value to false
      //   - Return result
      // Called by
      //   - frmCustomerUpdate.cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      //   - frmCustomerValidation.cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      //   - WriteChangesToDatabase(DataRowState)
      //   - WriteValuesToDataRow()
      // Calls
      //   - string Address (Get)
      //   - string City (Get)
      //   - string CompanyName (Get)
      //   - string ContactName (Get)
      //   - string ContactTitle (Get)
      //   - string Country (Get)
      //   - string Fax (Get)
      //   - string IdCustomer (Get)
      //   - string Phone (Get)
      //   - string PostalCode (Get)
      //   - string Region (Get)
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnResult;
      DataRowState theDataRowState;

      if (mblnNew)
      {
        mdrwCustomer = mdsCustomer.tblCPCustomer.AddtblCPCustomerRow(
          IdCustomer, CompanyName, ContactName, ContactTitle, Address, City,
          Region, PostalCode, Country, Phone, Fax);

        theDataRowState = DataRowState.Added;
        mblnNew = false;
      }
      else
        // Not mblnNew 
      {
        theDataRowState = DataRowState.Modified;
      }
      // mblnNew 

      try
      {
        mdrwCustomer.BeginEdit();
        WriteValuesToDataRow();
        mdrwCustomer.EndEdit();

        if (WriteChangesToDatabase(theDataRowState))
        {
          blnResult = true;
        }
        else
          // Not WriteChangesToDatabase(theDataRowState) 
        {
          mdrwCustomer.RejectChanges();
          blnResult = false;
        }
        // WriteChangesToDatabase(theDataRowState) 
      
      }
      catch (Exception theException)
      {
        mdrwCustomer.CancelEdit();
        mdrwCustomer.RejectChanges();
        blnResult = false;
      }
      finally
      {
      }

      return blnResult;
    }
    // bool Save()

    private bool ValidateKeyCustomer(string strKeyCustomer)
      //***
      // Action
      //   - Check if the customer key is 5 long
      // Called by
      //   - cpCustomer(string)
      //   - cpCustomer(string, string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return (strKeyCustomer.Trim().Length == 5);
    }
    // bool ValidateKeyCustomer(string)

    private bool ValidatePhoneNumber(string strValue)
      //***
      // Action
      //   - Define an array of valid strings
      //   - Define a counter with value 0
      //   - Assign the valid characters to the array
      //   - Define and assign the upper bound of the array
      //   - Define and assign the lower bound of the array
      //   - Loop from lower bound to upperbound
      //     - Replace the found characters with empty string inside the given string
      //   - Trim the spaces of the result string
      //   - If length of the result string is bigger than zero
      //     - Not all characters are replaced, so there is at least one character not allowed
      //   - If not
      //     - Given string is accepted
      //   - Return a boolean result
      // Called by
      //   - Fax(string) (Set)
      //   - Phone(string) (Set)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnResult;
      string[] arrchrValid;
      
      arrchrValid = new String[] {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "+", "(", ")", "/", " ", ".", "-"};

      System.Int32 lngLowerBound = arrchrValid.GetLowerBound(0);
      System.Int32 lngUpperBound = arrchrValid.GetUpperBound(0);

      for (System.Int32 lngCounter = lngLowerBound; lngCounter < lngUpperBound; lngCounter++)
      {
        strValue = strValue.Replace(arrchrValid[lngCounter], "");
      }
      // lngCounter = lngUpperBound

      strValue = strValue.Trim();

      if (strValue.Length > 0)
      {
        blnResult = false;
      }
      else
        // strValue.Length <= 0
      {
        blnResult = true;
      }
      // strValue.Length > 0

      return blnResult;
    }
    // bool ValidatePhoneNumber(string)

    private bool WriteChangesToDatabase(DataRowState theDataRowState)
      //***
      // Action
      //   - Define a return value
      //   - Try to
      //     - Define and set a dataset with the changes of the customer data set
      //     - Update the changes using the data adapter
      //     - Accept the changes of the customer data set
      //     - Return value becomes true
      //   - When error occurs
      //     - Reject the changes of the customer data set
      //     - Return value becomes false
      // Called by
      //   - bool Delete() Implements cpiCustomer.Delete
      //   - bool Save() Implements cpiCustomer.Save
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnReturn;

      try
      {
        DataSet dsChanges = mdsCustomer.GetChanges(theDataRowState);

        dtaCustomer.Update(dsChanges);
        mdsCustomer.AcceptChanges();
        blnReturn = true;
      }
      catch (Exception theException)
      {
        mdsCustomer.RejectChanges();
        blnReturn = false;
      }
      finally
      {
      }

      return blnReturn;
    }
    // bool WriteChangesToDatabase(DataRowState)

    private void WriteValuesToDataRow()
      //***
      // Action
      //   - Write property values from instance to data row
      //     - strCompanyName becomes CompanyName 
      //   - Do routine for Address, City, ContactName, ContactTitle,
      //     - Country, Fax, Phone, PostalCode, Region)
      //   - Routine:
      //   - If Xxx.Length = 0 Then
      //     - Property becomes null
      //   - If not
      //     - Property becomes Xxx
      // Called by
      //   - bool Save() Implements cpiCustomer.Save
      // Calls
      //   - string CompanyName (Get)
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdrwCustomer.strCompanyName = CompanyName;

      if (Address.Length == 0)
      {
        mdrwCustomer.SetstrAddressNull();
      }
      else
        // Address.Length <> 0
      {
        mdrwCustomer.strAddress = Address;
      }
      // Address.Length = 0

      if (City.Length == 0)
      {
        mdrwCustomer.SetstrCityNull();
      }
      else
        // City.Length <> 0
      {
        mdrwCustomer.strCity = City;
      }
      // City.Length = 0

      if (ContactName.Length == 0)
      {
        mdrwCustomer.SetstrContactNameNull();
      }
      else
        // ContactName.Length <> 0
      {
        mdrwCustomer.strContactName = ContactName;
      }
      // ContactName.Length = 0

      if (ContactTitle.Length == 0)
      {
        mdrwCustomer.SetstrContactTitleNull();
      }
      else
        // ContactTitle.Length <> 0 
      {
        mdrwCustomer.strContactTitle = ContactTitle;
      }
      // ContactTitle.Length = 0 

      if (Country.Length == 0)
      {
        mdrwCustomer.SetstrCountryNull();
      }
      else
        // Country.Length <> 0 
      {
        mdrwCustomer.strCountry = Country;
      }
      // Country.Length = 0 

      if (Fax.Length == 0)
      {
        mdrwCustomer.SetstrFaxNull();
      }
      else
        // Fax.Length <> 0 
      {
        mdrwCustomer.strFax = Fax;
      }
      // Fax.Length = 0 

      if (Phone.Length == 0)
      {
        mdrwCustomer.SetstrPhoneNull();
      }
      else
        // Phone.Length <> 0
      {
        mdrwCustomer.strPhone = Phone;
      }
      // Phone.Length = 0

      if (PostalCode.Length == 0)
      {
        mdrwCustomer.SetstrPostalCodeNull();
      }
      else
        // PostalCode.Length <> 0
      {
        mdrwCustomer.strPostalCode = PostalCode;
      }
      // PostalCode.Length = 0

      if (Region.Length == 0)
      {
        mdrwCustomer.SetstrRegionNull();
      }
      else
        // Region.Length <> 0
      {
        mdrwCustomer.strRegion = Region;
      }
      // Region.Length = 0

    }
    // WriteValuesToDataRow()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCustomer

}
// CopyPaste.Learning