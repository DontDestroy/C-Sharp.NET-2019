//***
// Action
//   - Demo of a tab control
// Created
//   - CopyPaste � 20240312 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240312 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTabControl: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TabControl tabOptions;
    internal System.Windows.Forms.TabPage pagVisualBasic;
    internal System.Windows.Forms.TextBox txtVisualBasic;
    internal System.Windows.Forms.TabPage pagHTML;
    internal System.Windows.Forms.TextBox txtHTML;
    internal System.Windows.Forms.TabPage pagC;
    internal System.Windows.Forms.TextBox txtC;
    internal System.Windows.Forms.TabPage pagUpgrading;
    internal System.Windows.Forms.TextBox txtUpgrading;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTabControl));
      this.tabOptions = new System.Windows.Forms.TabControl();
      this.pagVisualBasic = new System.Windows.Forms.TabPage();
      this.txtVisualBasic = new System.Windows.Forms.TextBox();
      this.pagHTML = new System.Windows.Forms.TabPage();
      this.txtHTML = new System.Windows.Forms.TextBox();
      this.pagC = new System.Windows.Forms.TabPage();
      this.txtC = new System.Windows.Forms.TextBox();
      this.pagUpgrading = new System.Windows.Forms.TabPage();
      this.txtUpgrading = new System.Windows.Forms.TextBox();
      this.tabOptions.SuspendLayout();
      this.pagVisualBasic.SuspendLayout();
      this.pagHTML.SuspendLayout();
      this.pagC.SuspendLayout();
      this.pagUpgrading.SuspendLayout();
      this.SuspendLayout();
      // 
      // tabOptions
      // 
      this.tabOptions.Controls.Add(this.pagVisualBasic);
      this.tabOptions.Controls.Add(this.pagHTML);
      this.tabOptions.Controls.Add(this.pagC);
      this.tabOptions.Controls.Add(this.pagUpgrading);
      this.tabOptions.Location = new System.Drawing.Point(48, 48);
      this.tabOptions.Name = "tabOptions";
      this.tabOptions.SelectedIndex = 0;
      this.tabOptions.Size = new System.Drawing.Size(288, 200);
      this.tabOptions.TabIndex = 1;
      // 
      // pagVisualBasic
      // 
      this.pagVisualBasic.Controls.Add(this.txtVisualBasic);
      this.pagVisualBasic.Location = new System.Drawing.Point(4, 22);
      this.pagVisualBasic.Name = "pagVisualBasic";
      this.pagVisualBasic.Size = new System.Drawing.Size(280, 174);
      this.pagVisualBasic.TabIndex = 0;
      this.pagVisualBasic.Text = "Visual Basic .Net";
      // 
      // txtVisualBasic
      // 
      this.txtVisualBasic.Location = new System.Drawing.Point(8, 8);
      this.txtVisualBasic.Multiline = true;
      this.txtVisualBasic.Name = "txtVisualBasic";
      this.txtVisualBasic.Size = new System.Drawing.Size(264, 160);
      this.txtVisualBasic.TabIndex = 0;
      this.txtVisualBasic.Text = "";
      // 
      // pagHTML
      // 
      this.pagHTML.Controls.Add(this.txtHTML);
      this.pagHTML.Location = new System.Drawing.Point(4, 22);
      this.pagHTML.Name = "pagHTML";
      this.pagHTML.Size = new System.Drawing.Size(280, 174);
      this.pagHTML.TabIndex = 2;
      this.pagHTML.Text = "HTML";
      this.pagHTML.Visible = false;
      // 
      // txtHTML
      // 
      this.txtHTML.Location = new System.Drawing.Point(8, 8);
      this.txtHTML.Multiline = true;
      this.txtHTML.Name = "txtHTML";
      this.txtHTML.Size = new System.Drawing.Size(264, 160);
      this.txtHTML.TabIndex = 0;
      this.txtHTML.Text = "";
      // 
      // pagC
      // 
      this.pagC.Controls.Add(this.txtC);
      this.pagC.Location = new System.Drawing.Point(4, 22);
      this.pagC.Name = "pagC";
      this.pagC.Size = new System.Drawing.Size(280, 174);
      this.pagC.TabIndex = 1;
      this.pagC.Text = "C# ";
      this.pagC.Visible = false;
      // 
      // txtC
      // 
      this.txtC.Location = new System.Drawing.Point(8, 8);
      this.txtC.Multiline = true;
      this.txtC.Name = "txtC";
      this.txtC.Size = new System.Drawing.Size(264, 160);
      this.txtC.TabIndex = 0;
      this.txtC.Text = "";
      // 
      // pagUpgrading
      // 
      this.pagUpgrading.Controls.Add(this.txtUpgrading);
      this.pagUpgrading.Location = new System.Drawing.Point(4, 22);
      this.pagUpgrading.Name = "pagUpgrading";
      this.pagUpgrading.Size = new System.Drawing.Size(280, 174);
      this.pagUpgrading.TabIndex = 3;
      this.pagUpgrading.Text = "Upgrading";
      this.pagUpgrading.Visible = false;
      // 
      // txtUpgrading
      // 
      this.txtUpgrading.Location = new System.Drawing.Point(8, 8);
      this.txtUpgrading.Multiline = true;
      this.txtUpgrading.Name = "txtUpgrading";
      this.txtUpgrading.Size = new System.Drawing.Size(264, 160);
      this.txtUpgrading.TabIndex = 0;
      this.txtUpgrading.Text = "";
      // 
      // frmTabControl
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(528, 389);
      this.Controls.Add(this.tabOptions);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTabControl";
      this.Text = "TabControl";
      this.Activated += new System.EventHandler(this.frmTabControl_Activated);
      this.tabOptions.ResumeLayout(false);
      this.pagVisualBasic.ResumeLayout(false);
      this.pagHTML.ResumeLayout(false);
      this.pagC.ResumeLayout(false);
      this.pagUpgrading.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTabControl'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTabControl()
      //***
      // Action
      //   - Create instance of 'frmTabControl'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTabControl()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmTabControl_Activated(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the text of the four textboxes in the tab
      // Called by
      //   - User action (Activating the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtVisualBasic.Text = "Visual Basic .Net Programming Tips & Techniques" + Environment.NewLine;
      txtVisualBasic.AppendText("Jamsa" + Environment.NewLine);
      txtVisualBasic.AppendText("McGraw-Hill/Osborne" + Environment.NewLine);
      txtVisualBasic.AppendText("49.99" + Environment.NewLine);

      txtC.Text = "C# Programming Tips & Techniques" + Environment.NewLine;
      txtC.Text += "Wright" + Environment.NewLine;
      txtC.Text += "McGraw-Hill/Osborne" + Environment.NewLine;
      txtC.Text += "$49.99" + Environment.NewLine;

      txtHTML.Text = "HTML & Web Design Tips & Techniques" + Environment.NewLine;
      txtHTML.Text += "King" + Environment.NewLine;
      txtHTML.Text += "McGraw-Hill/Osborne" + Environment.NewLine;
      txtHTML.Text += "$49.99" + Environment.NewLine;

      txtUpgrading.Text = "PC Performance Tuning & Upgrading Tips & Techniques" + Environment.NewLine;
      txtUpgrading.Text += "Jamsa" + Environment.NewLine;
      txtUpgrading.Text += "McGraw-Hill/Osborne" + Environment.NewLine;
      txtUpgrading.Text += "$39.99" + Environment.NewLine;
    }
    // frmTabControl_Activated(System.Object, System.EventArgs) Handles frmTabControl.Activated

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTabControl
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTabControl());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTabControl

}
// CopyPaste.Learning