﻿
namespace CopyPaste.Learning.Data
{
  partial class frmADOWizard
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmADOWizard));
      this.txtCategory = new System.Windows.Forms.TextBox();
      this.bdsrcCategory = new System.Windows.Forms.BindingSource(this.components);
      this.dsCategory = new ADOFormWizard.dsCategory();
      this.cmdLast = new System.Windows.Forms.Button();
      this.cmdNext = new System.Windows.Forms.Button();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.cmdLoad = new System.Windows.Forms.Button();
      this.lblCategory = new System.Windows.Forms.Label();
      this.cmdFirst = new System.Windows.Forms.Button();
      this.lblCount = new System.Windows.Forms.Label();
      this.tbaCategory = new ADOFormWizard.dsCategoryTableAdapters.tbaCategory();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCategory)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCategory)).BeginInit();
      this.SuspendLayout();
      // 
      // txtCategory
      // 
      this.txtCategory.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCategory, "strCategoryName", true));
      this.txtCategory.Location = new System.Drawing.Point(118, 22);
      this.txtCategory.Name = "txtCategory";
      this.txtCategory.Size = new System.Drawing.Size(152, 20);
      this.txtCategory.TabIndex = 17;
      // 
      // bdsrcCategory
      // 
      this.bdsrcCategory.DataMember = "tblCPCategory";
      this.bdsrcCategory.DataSource = this.dsCategory;
      // 
      // dsCategory
      // 
      this.dsCategory.DataSetName = "dsCategory";
      this.dsCategory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // cmdLast
      // 
      this.cmdLast.Location = new System.Drawing.Point(190, 230);
      this.cmdLast.Name = "cmdLast";
      this.cmdLast.Size = new System.Drawing.Size(72, 32);
      this.cmdLast.TabIndex = 23;
      this.cmdLast.Text = "&Last";
      this.cmdLast.Click += new System.EventHandler(this.cmdLast_Click);
      // 
      // cmdNext
      // 
      this.cmdNext.Location = new System.Drawing.Point(190, 182);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(72, 32);
      this.cmdNext.TabIndex = 22;
      this.cmdNext.Text = "&Next";
      this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Location = new System.Drawing.Point(190, 134);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(72, 32);
      this.cmdPrevious.TabIndex = 21;
      this.cmdPrevious.Text = "&Previous";
      this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
      // 
      // cmdLoad
      // 
      this.cmdLoad.Location = new System.Drawing.Point(62, 86);
      this.cmdLoad.Name = "cmdLoad";
      this.cmdLoad.Size = new System.Drawing.Size(80, 32);
      this.cmdLoad.TabIndex = 19;
      this.cmdLoad.Text = "Load Data";
      this.cmdLoad.Click += new System.EventHandler(this.cmdLoad_Click);
      // 
      // lblCategory
      // 
      this.lblCategory.Location = new System.Drawing.Point(22, 22);
      this.lblCategory.Name = "lblCategory";
      this.lblCategory.Size = new System.Drawing.Size(88, 16);
      this.lblCategory.TabIndex = 16;
      this.lblCategory.Text = "Category";
      this.lblCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // cmdFirst
      // 
      this.cmdFirst.Location = new System.Drawing.Point(190, 86);
      this.cmdFirst.Name = "cmdFirst";
      this.cmdFirst.Size = new System.Drawing.Size(72, 32);
      this.cmdFirst.TabIndex = 20;
      this.cmdFirst.Text = "&First";
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      // 
      // lblCount
      // 
      this.lblCount.Location = new System.Drawing.Point(118, 46);
      this.lblCount.Name = "lblCount";
      this.lblCount.Size = new System.Drawing.Size(128, 24);
      this.lblCount.TabIndex = 18;
      this.lblCount.Text = "Record 0 of 0";
      // 
      // tbaCategory
      // 
      this.tbaCategory.ClearBeforeFill = true;
      // 
      // frmADOWizard
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(292, 285);
      this.Controls.Add(this.txtCategory);
      this.Controls.Add(this.cmdLast);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.cmdLoad);
      this.Controls.Add(this.lblCategory);
      this.Controls.Add(this.cmdFirst);
      this.Controls.Add(this.lblCount);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmADOWizard";
      this.Text = "ADO From Wizard";
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCategory)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCategory)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    internal System.Windows.Forms.TextBox txtCategory;
    internal System.Windows.Forms.Button cmdLast;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Button cmdPrevious;
    internal System.Windows.Forms.Button cmdLoad;
    internal System.Windows.Forms.Label lblCategory;
    internal System.Windows.Forms.Button cmdFirst;
    internal System.Windows.Forms.Label lblCount;
    private ADOFormWizard.dsCategory dsCategory;
    private ADOFormWizard.dsCategoryTableAdapters.tbaCategory tbaCategory;
    private System.Windows.Forms.BindingSource bdsrcCategory;
  }
}