//***
// Action
//   - The definition of a cpFakeShape
//   - The implementation of the methods is forced in the base class
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpFakeShape : cpShape
  {

    #region "Constructors / Destructors"

    public cpFakeShape()
      //***
      // Action
      //   - Empty constructor of a cpFakeShape
      // Called by
      //   - frmShape.cmdFake_Click(System.Object, System.EventArgs) Handles cmdFake.Click
      // Calls
      //   - cpShape()
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpFakeShape()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override void Draw()
      //***
      // Action
      //   - Fakes the drawing of a shape
      // Called by
      //   - frmShape.cmdFake_Click(System.Object, System.EventArgs) Handles cmdFake.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show("The shape is drawn.");
    }
    // Draw()

    public override void Reflect()
      //***
      // Action
      //   - Fakes the mirroring of a shape
      // Called by
      //   - frmShape.cmdFake_Click(System.Object, System.EventArgs) Handles cmdFake.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show("The shape is mirrored.");
    }
    // Reflect()

    public override void Rotate(System.Single sngDegrees)
      //***
      // Action
      //   - Fakes the rotation of a shape
      // Called by
      //   - frmShape.cmdFake_Click(System.Object, System.EventArgs) Handles cmdFake.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show("The shape is rotated by " + sngDegrees.ToString() + " degrees.");
    }
    // Rotate(System.Single)

    public override void Translate(int lngX, int lngY)
      //***
      // Action
      //   - Fakes the movement of a shape
      // Called by
      //   - frmShape.cmdFake_Click(System.Object, System.EventArgs) Handles cmdFake.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show("The shape is moved by " + lngX.ToString() + " points horizontal and " + lngY.ToString() + " point vertical.");
    }
    // Translate(int, int)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpShape

}
// CopyPaste.Learning