//***
// Action
//   - Showing the form of a guess game
// Created
//   - CopyPaste � 20260629 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260629 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmGuess: System.Windows.Forms.Form
  {
    private Label lblInput;
    private TextBox txtInput;
    private Label lblResult;
    private Button cmdGuess;

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGuess));
      this.lblInput = new System.Windows.Forms.Label();
      this.txtInput = new System.Windows.Forms.TextBox();
      this.lblResult = new System.Windows.Forms.Label();
      this.cmdGuess = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // lblInput
      // 
      this.lblInput.Location = new System.Drawing.Point(5, 9);
      this.lblInput.Name = "lblInput";
      this.lblInput.Size = new System.Drawing.Size(200, 34);
      this.lblInput.TabIndex = 0;
      this.lblInput.Text = "The PC has thoiught of a number 1-20. Can you guess what it is?";
      // 
      // txtInput
      // 
      this.txtInput.Location = new System.Drawing.Point(8, 46);
      this.txtInput.Name = "txtInput";
      this.txtInput.Size = new System.Drawing.Size(100, 20);
      this.txtInput.TabIndex = 1;
      // 
      // lblResult
      // 
      this.lblResult.AutoSize = true;
      this.lblResult.Location = new System.Drawing.Point(5, 74);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(10, 13);
      this.lblResult.TabIndex = 2;
      this.lblResult.Text = " ";
      // 
      // cmdGuess
      // 
      this.cmdGuess.Location = new System.Drawing.Point(130, 46);
      this.cmdGuess.Name = "cmdGuess";
      this.cmdGuess.Size = new System.Drawing.Size(75, 23);
      this.cmdGuess.TabIndex = 3;
      this.cmdGuess.Text = "Guess";
      this.cmdGuess.UseVisualStyleBackColor = true;
      this.cmdGuess.Click += new System.EventHandler(this.cmdGuess_Click);
      // 
      // frmGuess
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdGuess);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.txtInput);
      this.Controls.Add(this.lblInput);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmGuess";
      this.Text = "Take a Guess";
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmGuess'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260629 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260629 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmGuess()
    //***
    // Action
    //   - Create instance of 'frmGuess'
    //   - Define and initialize a randomizer
    //   - Get a random number between 1 (included) and 21 (excluded)
    // Called by
    //   - Main()
    // Calls
    //   - InitializeComponent()
    //   - NumberToGuess(int) (Set)
    // Created
    //   - CopyPaste � 20260629 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260629 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      Random rndGuess = new Random();

      NumberToGuess = rndGuess.Next(1, 21);
    }
    // frmGuess()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int intNumberToGuess;

    #endregion

    #region "Properties"

    public int NumberToGuess
    {

      get
      //***
      // Action Get
      //   - Return the number to guess
      // Called by
      //   - cmdGuess_Click(System.Objec, System.EventArgs) Handles cmdGuess.Click
      //   - Rate(int)
      // Calls
      //   -
      // Created
      //   - CopyPaste � 20260629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260629 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return intNumberToGuess;
      }
      // int NumberToGuess (Get)

      set
      //***
      // Action Set
      //   - Set the number to guess
      // Called by
      //   - frmGuess()
      // Calls
      //   -
      // Created
      //   - CopyPaste � 20260629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260629 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        intNumberToGuess = value;
      }
      // NumberToGuess(int) (Set)

    }
    // int NumberToGuess

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdGuess_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Convert the typed number in the textbox to a number
    //   - Rate the guessed number with the number to guess
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - int NumberToGuess (Get)
    //   - Rate(int)
    // Created
    //   - CopyPaste � 20260629 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260629 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intGuess;

      try
      {
        intGuess = Convert.ToInt32(txtInput.Text);
        Rate(intGuess);
      }
      catch
      {
        lblResult.Text = "A wrong input is given";
      }    
    
    }
    // cmdGuess_Click(System.Objec, System.EventArgs) Handles cmdGuess.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Rate(int intGuess)
    //***
    // Action
    //   - Compare intGuess with NumberToGuess
    //   - If smaller
    //     - Adapt the label in the form
    //   - If bigger
    //     - Adapt the label in the form
    //   - If correct
    //     - Adapt the label in the form
    // Called by
    //   - cmdGuess_Click(System.Objec, System.EventArgs) Handles cmdGuess.Click
    // Calls
    //   - int NumberToGuess (Get)
    // Created
    //   - CopyPaste � 20260629 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260629 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (intGuess < NumberToGuess)
      {
        lblResult.Text = "Too Low!";
      }
      else if (intGuess > NumberToGuess)
      // Not (intGuess < NumberToGuess)
      {
        lblResult.Text = "Too High!";
      }
      else
      // Not (intGuess < NumberToGuess)
      // Not (intGuess > NumberToGuess)
      {
        lblResult.Text = "*** Correct ***";
      }
      // intGuess < NumberToGuess
      // intGuess > NumberToGuess

    }
    // Rate(int)

    #endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmGuess

}
// CopyPaste.Learning