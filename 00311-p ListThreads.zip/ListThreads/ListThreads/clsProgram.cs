﻿//***
// Action
//   - Loop thru all the threads that are running
// Created
//   - CopyPaste – 20250710 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250710 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Diagnostics;
using System.Threading;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static Thread mthrA;
    public static Thread mthrB;
    public static Thread mthrC;
    public static Thread mthrD;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Display()
      //***
      // Action
      //   - Show the current name of the thread
      //   - Blocks mthrD by joining it to this thread
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250710 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250710 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Thread - {0}", Thread.CurrentThread.Name);
      mthrD.Join();
    }
    // Display()

    public static void Main()
      //***
      // Action
      //   - Create four different threads
      //   - Give them all a name
      //   - Start them
      //     - The fourth thread is joined to Display, so will be executed last
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Display()
      //   - ThreadInfo()
      // Created
      //   - CopyPaste – 20250710 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250710 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mthrA = new Thread(new ThreadStart(Display));
      mthrB = new Thread(new ThreadStart(Display));
      mthrC = new Thread(new ThreadStart(Display));
      mthrD = new Thread(new ThreadStart(ThreadInfo));

      mthrA.Name = "First";
      mthrB.Name = "Second";
      mthrC.Name = "Third";
      mthrD.Name = "Fourth";

      mthrA.Start();
      mthrB.Start();
      mthrC.Start();
      mthrD.Start();

      Console.ReadLine();
    }
    // Main()

    public static void ThreadInfo()
      //***
      // Action
      //   - Define a ProcessThread
      //   - Define a collection of ProcessThreads
      //   - Get the current process threads
      //   - Loop thru the collection of ProcessThreads
      //     - Show I, StartTime, TotalProcessorTime
      //     - Show ThreadState
      //     - If ThreadState is Wait
      //       - Show the reason
      //     - If not
      //       - Do nothing
      //     - Show StartAddress
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250710 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250710 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      ProcessThreadCollection theProcessThreadCollection;
      
      theProcessThreadCollection = Process.GetCurrentProcess().Threads;
      Console.WriteLine();
      
      foreach(ProcessThread theProcessThread in theProcessThreadCollection)
      {
        Console.Write("Thread: {0:D5}", theProcessThread.Id);
        Console.Write(" Start: {0}", theProcessThread.StartTime);
        Console.WriteLine(" CPU Time: {0}", theProcessThread.TotalProcessorTime);
        Console.Write(" State: {0}", theProcessThread.ThreadState);
        
        if (theProcessThread.ThreadState == System.Diagnostics.ThreadState.Wait)
        {
          Console.Write(" Reason: {0}", theProcessThread.WaitReason);
        }
        else
          // theProcessThread.ThreadState <> System.Diagnostics.ThreadState.Wait
        {
        }
        // theProcessThread.ThreadState = System.Diagnostics.ThreadState.Wait

        Console.WriteLine(" Address: {0}", theProcessThread.StartAddress);
        Console.WriteLine();
      }
      // in theProcessThreadCollection

    }
    // ThreadInfo()

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning