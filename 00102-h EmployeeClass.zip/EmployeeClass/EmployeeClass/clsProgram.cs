//***
// Action
//   - Testroutine of the clsEmployee
// Created
//   - CopyPaste � 20230419 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230419 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Define a new cpEmployee
    //   - Define an array of cpEmployees
    //   - Fill in the name
    //   - Fill in the sex
    //   - Fill in the startdate
    //   - Show the information on the screen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpEmployee()
    //   - cpEmployee.Name(String) (Set)
    //   - cpEmployee.Sex(aSex) (Set)
    //   - cpEmployee.ShowInfo()
    //   - cpEmployee.StartDate(Date) (Set)
    // Created
    //   - CopyPaste � 20230419 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230419 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpEmployee[] arrcpEmployees = new cpEmployee[3];
      long lngCounter;

      for (lngCounter = 0; lngCounter <= arrcpEmployees.Length - 1; lngCounter++)
      {
        arrcpEmployees[lngCounter] = new cpEmployee();
      }
      // lngCounter = arrcpEmployees.Length

      arrcpEmployees[0].Name = "Vincent";
      arrcpEmployees[0].Sex = cpEmployee.aSex.Male;
      arrcpEmployees[0].StartDate = new DateTime(2001, 1, 1);

      arrcpEmployees[1].Name = "Hilde";
      arrcpEmployees[1].Sex = cpEmployee.aSex.Female;
      arrcpEmployees[1].StartDate = DateTime.Today.AddYears(-1);

      arrcpEmployees[2].Name = "Gertrude";
      arrcpEmployees[2].Sex = cpEmployee.aSex.Female;
      arrcpEmployees[2].StartDate = new DateTime(2001, 1, 1);

      foreach (cpEmployee thecpEmployee in arrcpEmployees)
      {
        thecpEmployee.ShowInfo();
        Console.WriteLine();
      }
      // in arrcpEmployees

    Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// CopyPaste.Learning