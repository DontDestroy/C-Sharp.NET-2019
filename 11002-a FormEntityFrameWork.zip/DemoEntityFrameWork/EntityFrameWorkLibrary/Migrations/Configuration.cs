﻿//***
// Action
//   - Generated code that is adapted (thru command enable-migrations in "Package Manage Console")
// Created
//   - CopyPaste – 20230406 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230406 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;

namespace CopyPaste.Learning.Migrations
{

  internal sealed class Configuration : DbMigrationsConfiguration<cpApplicationDatabaseContext>
  {

    #region "Constructors / Destructors"

    public Configuration()
    //***
    // Action
    //   - Automatic migrations are swiched on
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20230406 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230406 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      AutomaticMigrationsEnabled = true;

      try
      {
        Seed(new cpApplicationDatabaseContext());
      }
      catch (Exception theException)
      {
        Console.WriteLine("There was an error in seeding the information");
        Console.WriteLine(theException.Message);
      }

    }
    // Configuration()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    protected override void Seed(cpApplicationDatabaseContext theDatabaseContext)
    //***
    // Action
    //   - Fill the just created database with a record
    // Called by
    //   - Configuration()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20230406 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230406 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine("Seeding data into tables ...");

      if (theDatabaseContext.cpWarning.Any())
      // Are there records
      {
        Console.WriteLine("There was already data in it, nothing is seeded.");
      }
      else
      // Not theDatabaseContext.cpWarning.Any()
      {
        cpWarning aWarning;
        cpWarning anotherWarning;

        List<cpWarning> lstWarnings = new List<cpWarning>();

        aWarning = new cpWarning
        {
          strName = "Normal warning",
          strDescription = "The police gave you a warning, but no fine."
        };

        anotherWarning = new cpWarning
        {
          strName = "Serious warning",
          strDescription = "The police gave you a fine."
        };

        lstWarnings.Add(aWarning);
        lstWarnings.Add(anotherWarning);

        theDatabaseContext.cpWarning.AddRange(lstWarnings);
        theDatabaseContext.SaveChanges();
      }
      // theDatabaseContext.cpWarning.Any()

    }
    // Seed(cpApplicationDatabaseContext)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Configuration

}
// CopyPaste.Learning.Migrations