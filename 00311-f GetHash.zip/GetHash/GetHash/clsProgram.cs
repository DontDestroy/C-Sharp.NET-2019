﻿//***
// Action
//   - Show the name and the hashcode of threads
// Created
//   - CopyPaste – 20250709 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250709 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Threading;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static Thread thrLotOfA;
    public static Thread thrLotOfB;
    public static Thread thrLotOfC;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void DisplayHash()
      //***
      // Action
      //   - Define a thread
      //   - Get the current thread
      //   - Get the hash code of the current thread
      //   - Show the name and the hash of the current thread
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250709 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250709 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngHash;
      Thread theTread;
      
      theTread = Thread.CurrentThread;
      lngHash = theTread.GetHashCode();
      Console.WriteLine("Thread name: {0} - Thread hash: {1}", Thread.CurrentThread.Name, lngHash.ToString());
    }
    // DisplayHash()
		
    public static void Main()
      //***
      // Action
      //   - Create three threads
      //   - Give the first thread the name First
      //   - Start First thread
      //   - Give the second thread the name Second
      //   - Start Second thread
      //   - Give the third thread the name Third
      //   - Start Third thread
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - DisplayHash()
      // Created
      //   - CopyPaste – 20250709 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250709 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      thrLotOfA = new Thread(new ThreadStart(DisplayHash));
      thrLotOfB = new Thread(new ThreadStart(DisplayHash));
      thrLotOfC = new Thread(new ThreadStart(DisplayHash));

      thrLotOfA.Name = "First";
      thrLotOfA.Start();

      thrLotOfB.Name = "Second";
      thrLotOfB.Start();

      thrLotOfC.Name = "Third";
      thrLotOfC.Start();

      Console.ReadLine();
    }
    // Main()

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning