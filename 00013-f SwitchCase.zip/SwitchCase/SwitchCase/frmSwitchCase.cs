//***
// Action
//   - Example of Switch ... Case statement
// Created
//   - CopyPaste � 20240117 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240117 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmSwitchCase: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.Label lblGreeting;
    internal System.Windows.Forms.Label lblCountry;
    internal System.Windows.Forms.ListBox lstCountry;
    internal System.Windows.Forms.Label lblChoice;
    internal System.Windows.Forms.Label lblTitle;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSwitchCase));
      this.cmdExit = new System.Windows.Forms.Button();
      this.lblGreeting = new System.Windows.Forms.Label();
      this.lblCountry = new System.Windows.Forms.Label();
      this.lstCountry = new System.Windows.Forms.ListBox();
      this.lblChoice = new System.Windows.Forms.Label();
      this.lblTitle = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdExit
      // 
      this.cmdExit.Location = new System.Drawing.Point(102, 232);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.Size = new System.Drawing.Size(80, 24);
      this.cmdExit.TabIndex = 11;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // lblGreeting
      // 
      this.lblGreeting.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblGreeting.ForeColor = System.Drawing.Color.Red;
      this.lblGreeting.Location = new System.Drawing.Point(46, 192);
      this.lblGreeting.Name = "lblGreeting";
      this.lblGreeting.Size = new System.Drawing.Size(184, 24);
      this.lblGreeting.TabIndex = 10;
      // 
      // lblCountry
      // 
      this.lblCountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblCountry.Location = new System.Drawing.Point(46, 168);
      this.lblCountry.Name = "lblCountry";
      this.lblCountry.Size = new System.Drawing.Size(128, 24);
      this.lblCountry.TabIndex = 9;
      // 
      // lstCountry
      // 
      this.lstCountry.Location = new System.Drawing.Point(46, 72);
      this.lstCountry.Name = "lstCountry";
      this.lstCountry.Size = new System.Drawing.Size(128, 69);
      this.lstCountry.TabIndex = 8;
      this.lstCountry.MouseHover += new System.EventHandler(this.lstCountry_MouseHover);
      this.lstCountry.SelectedIndexChanged += new System.EventHandler(this.lstCountry_SelectedIndexChanged);
      // 
      // lblChoice
      // 
      this.lblChoice.Location = new System.Drawing.Point(46, 56);
      this.lblChoice.Name = "lblChoice";
      this.lblChoice.Size = new System.Drawing.Size(128, 16);
      this.lblChoice.TabIndex = 7;
      this.lblChoice.Text = "Choose a country";
      // 
      // lblTitle
      // 
      this.lblTitle.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblTitle.Location = new System.Drawing.Point(22, 16);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(248, 32);
      this.lblTitle.TabIndex = 6;
      this.lblTitle.Text = "International welcome";
      this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // frmSwitchCase
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.lblGreeting);
      this.Controls.Add(this.lblCountry);
      this.Controls.Add(this.lstCountry);
      this.Controls.Add(this.lblChoice);
      this.Controls.Add(this.lblTitle);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSwitchCase";
      this.Text = "Test Switch Case";
      this.Load += new System.EventHandler(this.frmSwitchCase_Load);
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmSwitchCase'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240117 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240117 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmSwitchCase()
			//***
			// Action
			//   - Create instance of 'frmSwitchCase'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240117 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240117 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmSwitchCase()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"
    
    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop program
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit.Click


    private void frmSwitchCase_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Fill 'lstCountry'
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lstCountry.Items.Add("America");
      lstCountry.Items.Add("Germany");
      lstCountry.Items.Add("Mexico");
      lstCountry.Items.Add("Italy");
      lstCountry.Items.Add("Netherlands");
      lstCountry.Items.Add("France");
    }
    // frmSelectCase_Load(System.Object, System.EventArgs) Handles this.Load
    
    private void lstCountry_MouseHover(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a message
      // Called by
      //   - User action (Hover over the listbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if ((lstCountry.SelectedIndex < 0) || (lstCountry.SelectedIndex > 6))    
      {
        lblGreeting.Text = "Click on a country name";
      }
      else
        // lstCountry.SelectedIndex >= 0 And lstCountry.SelectedIndex <= 6 
      {
      }
      // lstCountry.SelectedIndex < 0 Or lstCountry.SelectedIndex > 6 

    }
    // lstCountry_MouseHover(System.Object, System.EventArgs) Handles lstCountry.MouseHover

    private void lstCountry_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Fill 'lblCountry' with choosen item from 'lstCountry'
      //   - Depending on selected item
      //     - Show correct greeting
      // Called by
      //   - User action (Selecting an item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      
      lblCountry.Text = lstCountry.Text;

      switch (lstCountry.SelectedIndex)
      {
        case 0:
          lblGreeting.Text = "Hello, programmer";
          break;
        case 1:
          lblGreeting.Text = "Hallo, programmierer";
          break;
        case 2:
          lblGreeting.Text = "Hola, programador";
          break;
        case 3:
          lblGreeting.Text = "Ciao, programmatore";
          break;
        case 4:
          lblGreeting.Text = "Hallo, programmeur";
          break;
        case 5:
          lblGreeting.Text = "Bonjour, programmeur";
          break;
        default:
          lblGreeting.Text = "Unknown country";
          break;
      }
      // lstCountry.SelectedIndex
    
    }
    // lstCountry_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstCountry.SelectedIndexChanged

		#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmSwitchCase
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmDefault()
			// Created
			//   - CopyPaste � 20240117 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240117 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmSwitchCase());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmSwitchCase

}
// CopyPaste.Learning