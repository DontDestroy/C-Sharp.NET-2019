//***
// Action
//   - Demo in a form for cpTime
// Created
//   - CopyPaste � 20220301 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220301 � VVDW
// Proposal (To Do)
//   - There are errors when you clear the textboxes
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning.Toolkit.Time
{

  public class frmTime: System.Windows.Forms.Form
  {
    #region Windows Form Designer generated code

    internal System.Windows.Forms.Label lblOutput2;
    internal System.Windows.Forms.Label lblOutput1;
    internal System.Windows.Forms.Button cmdAddSecond;
    internal System.Windows.Forms.TextBox txtSetSecond;
    internal System.Windows.Forms.Label lblSetSecond;
    internal System.Windows.Forms.TextBox txtSetMinute;
    internal System.Windows.Forms.Label lblSetMinute;
    internal System.Windows.Forms.TextBox txtSetHour;
    internal System.Windows.Forms.Label lblSetHour;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTime));
      this.lblOutput2 = new System.Windows.Forms.Label();
      this.lblOutput1 = new System.Windows.Forms.Label();
      this.cmdAddSecond = new System.Windows.Forms.Button();
      this.txtSetSecond = new System.Windows.Forms.TextBox();
      this.lblSetSecond = new System.Windows.Forms.Label();
      this.txtSetMinute = new System.Windows.Forms.TextBox();
      this.lblSetMinute = new System.Windows.Forms.Label();
      this.txtSetHour = new System.Windows.Forms.TextBox();
      this.lblSetHour = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // lblOutput2
      // 
      this.lblOutput2.Location = new System.Drawing.Point(13, 135);
      this.lblOutput2.Name = "lblOutput2";
      this.lblOutput2.Size = new System.Drawing.Size(347, 34);
      this.lblOutput2.TabIndex = 17;
      // 
      // lblOutput1
      // 
      this.lblOutput1.Location = new System.Drawing.Point(13, 95);
      this.lblOutput1.Name = "lblOutput1";
      this.lblOutput1.Size = new System.Drawing.Size(347, 26);
      this.lblOutput1.TabIndex = 16;
      // 
      // cmdAddSecond
      // 
      this.cmdAddSecond.Location = new System.Drawing.Point(127, 47);
      this.cmdAddSecond.Name = "cmdAddSecond";
      this.cmdAddSecond.Size = new System.Drawing.Size(120, 27);
      this.cmdAddSecond.TabIndex = 15;
      this.cmdAddSecond.Text = "Add 1 to Second";
      this.cmdAddSecond.Click += new System.EventHandler(this.cmdAddSecond_Click);
      // 
      // txtSetSecond
      // 
      this.txtSetSecond.Location = new System.Drawing.Point(320, 7);
      this.txtSetSecond.Name = "txtSetSecond";
      this.txtSetSecond.Size = new System.Drawing.Size(33, 20);
      this.txtSetSecond.TabIndex = 14;
      this.txtSetSecond.TextChanged += new System.EventHandler(this.txtSetSecond_TextChanged);
      // 
      // lblSetSecond
      // 
      this.lblSetSecond.Location = new System.Drawing.Point(247, 7);
      this.lblSetSecond.Name = "lblSetSecond";
      this.lblSetSecond.Size = new System.Drawing.Size(81, 14);
      this.lblSetSecond.TabIndex = 13;
      this.lblSetSecond.Text = "Set Second::";
      // 
      // txtSetMinute
      // 
      this.txtSetMinute.Location = new System.Drawing.Point(193, 7);
      this.txtSetMinute.Name = "txtSetMinute";
      this.txtSetMinute.Size = new System.Drawing.Size(34, 20);
      this.txtSetMinute.TabIndex = 12;
      this.txtSetMinute.TextChanged += new System.EventHandler(this.txtSetMinute_TextChanged);
      // 
      // lblSetMinute
      // 
      this.lblSetMinute.Location = new System.Drawing.Point(127, 7);
      this.lblSetMinute.Name = "lblSetMinute";
      this.lblSetMinute.Size = new System.Drawing.Size(72, 14);
      this.lblSetMinute.TabIndex = 11;
      this.lblSetMinute.Text = "Set Minute:";
      // 
      // txtSetHour
      // 
      this.txtSetHour.Location = new System.Drawing.Point(73, 7);
      this.txtSetHour.Name = "txtSetHour";
      this.txtSetHour.Size = new System.Drawing.Size(34, 20);
      this.txtSetHour.TabIndex = 10;
      this.txtSetHour.TextChanged += new System.EventHandler(this.txtSetHour_TextChanged);
      // 
      // lblSetHour
      // 
      this.lblSetHour.Location = new System.Drawing.Point(13, 7);
      this.lblSetHour.Name = "lblSetHour";
      this.lblSetHour.Size = new System.Drawing.Size(69, 14);
      this.lblSetHour.TabIndex = 9;
      this.lblSetHour.Text = "Set Hour:";
      // 
      // frmTime
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(373, 179);
      this.Controls.Add(this.lblOutput2);
      this.Controls.Add(this.lblOutput1);
      this.Controls.Add(this.cmdAddSecond);
      this.Controls.Add(this.txtSetSecond);
      this.Controls.Add(this.lblSetSecond);
      this.Controls.Add(this.txtSetMinute);
      this.Controls.Add(this.lblSetMinute);
      this.Controls.Add(this.txtSetHour);
      this.Controls.Add(this.lblSetHour);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTime";
      this.Text = "Using Properties";
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmTime'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTime()
    //***
    // Action
    //   - Create instance of 'frmTime'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmTime()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    cpTime thecpTime = new cpTime();
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAddSecond_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Add a second to seconds
    //   - When needed, add a minute and set seconds to 0
    //   - When needed, add an hour and set minutes to 0
    //   - When needed, set hour to 0
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - int cpTime.Hour() (Get)
    //   - int cpTime.Minute() (Get)
    //   - int cpTime.Second() (Get)
    //   - cpTime.Hour(int) (Set)
    //   - cpTime.Minute(int) (Set)
    //   - cpTime.Second(int) (Set)
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      thecpTime.Second = (thecpTime.Second + 1) % 60;
      txtSetSecond.Text = thecpTime.Second.ToString();

      if (thecpTime.Second == 0)
      {
        thecpTime.Minute = (thecpTime.Minute + 1) % 60;
        txtSetMinute.Text = thecpTime.Minute.ToString();

        if (thecpTime.Minute == 0)
        {
          thecpTime.Hour = (thecpTime.Hour + 1) % 24;
          txtSetHour.Text = thecpTime.Hour.ToString();
        }
        else
          // thecpTime.Minute <> 0
        {
          thecpTime.Minute = 0;
        }
        // thecpTime.Minute = 0

      }
      else
        // thecpTime.Second <> 0
      {
      }
      // thecpTime.Second = 0
      
      UpdateDisplay();
    }
    // cmdAddSecond_Click(System.Object, System.EventArgs) Handles cmdAddSecond.Click

    private void txtSetHour_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Set second
    //   - Update display
    // Called by
    //   - User action (Changing text)
    // Calls
    //   - cpTime.Hour(int) (Set)
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - The application fails when text is cleared
    //***
    {
      thecpTime.Hour = Convert.ToInt32(txtSetHour.Text);
      UpdateDisplay();
    }
    // txtSetHour_TextChanged(System.Object, System.EventArgs) Handles txtSetHour.TextChanged

    private void txtSetMinute_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Set minute
    //   - Update display
    // Called by
    //   - User action (Changing text)
    // Calls
    //   - cpTime.Minute(int) (Set)
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - The application fails when text is cleared
    //***
    {
      thecpTime.Minute = Convert.ToInt32(txtSetMinute.Text);
      UpdateDisplay();
    }
    // txtSetMinute_TextChanged(System.Object, System.EventArgs) Handles txtSetMinute.TextChanged

    private void txtSetSecond_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Set second
    //   - Update display
    // Called by
    //   - User action (Changing text)
    // Calls
    //   - cpTime.Second(int) (Set)
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - The application fails when text is cleared
    //***
    {
      thecpTime.Second = Convert.ToInt32(txtSetSecond.Text);
      UpdateDisplay();
    }
    // txtSetSecond_TextChanged(System.Object, System.EventArgs) Handles txtSetSecond.TextChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmTime
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmTime());
    }
    // Main() 
    
    private void UpdateDisplay()
    //***
    // Action
    //   - Update 2 outputs
    // Called by
    //   - cmdAddSecond_Click(System.Object, System.EventArgs) Handles cmdAddSecond.Click
    //   - txtSetHour_TextChanged(System.Object, System.EventArgs) Handles txtSetHour.TextChanged
    //   - txtSetMinute_TextChanged(System.Object, System.EventArgs) Handles txtSetMinute.TextChanged
    //   - txtSetSecond_TextChanged(System.Object, System.EventArgs) Handles txtSetSecond.TextChanged
    // Calls
    //   - int cpTime.Hour() (Get)
    //   - int cpTime.Minute() (Get)
    //   - int cpTime.Second() (Get)
    //   - string cpTime.ToAmericanString()
    //   - string cpTime.ToUniversalString()
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lblOutput1.Text = "Hour: " + thecpTime.Hour + "; Minute: " + thecpTime.Minute + "; Second: " + thecpTime.Second;
      lblOutput2.Text = "Standard time is: " + thecpTime.ToAmericanString() + "; Universal Time is: " + thecpTime.ToUniversalString();
    }
    // UpdateDisplay()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTime

}
// CopyPaste.Learning.Toolkit.Time