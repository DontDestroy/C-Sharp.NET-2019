﻿//***
// Action
//   - Different examples of Pattern Matching
// Created
//   - CopyPaste – 20251212 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251212 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpPatternMatching
  {

    #region "Constructors / Destructors"

    public cpPatternMatching()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251212 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251212 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpPatternMatching()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string GetPersonCourseBeforeCSharp07(System.Object thePerson)
    //***
    // Action
    //   - If thePerson is a Student
    //     - Return the student details
    //   - If not, if thePerson is a Lecturer
    //     - Return the lecture details
    //   - If not, if thePerson is an Alumnus
    //     - Return the alumnus details
    //   - If not, if thePerson is an Exchange Student
    //     - Return the exchange student details
    //   - If not
    //     - Throw an exception
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - (string, int, string) cpAlumnus.AlumnusDetails()
    //   - (string, string, int) cpExchangeStudent.ExchangeStudentDetails() 
    //   - (string, string, string) cpStudent.StudentDetails()
    //   - (string, string, string, int) cpLecture.LecturerDetails()
    // Created
    //   - CopyPaste – 20251213 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251213 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strResult = "";

      if (thePerson is cpStudent)
      {
        cpStudent theStudent = (cpStudent)thePerson;
        (string strFullName, string strStudentNumber, string strCourse) theStudentDetails = theStudent.StudentDetails();

        // var theStudentDetails = theStudent.StudentDetails();
        // VVDW - Var can also be used because you want the discrete variables of the tuple

        strResult = $"{theStudentDetails.strFullName} is enrolled for {theStudentDetails.strCourse} with student number {theStudentDetails.strStudentNumber}";
      }
      else if (thePerson is cpLecturer)
      // thePerson is not cpStudent 
      {
        cpLecturer theLecturer = (cpLecturer)thePerson;
        (string strFullName, string strEmployeeNumber, string strSpecialCourse, int intTotalDaysEmployed) theLecturerDetails = theLecturer.LecturerDetails();

        // var theLecturerDetails = theLecturer.LecturerDetails();
        // VVDW - Var can also be used because you want the discrete variables of the tuple

        strResult = $"{theLecturerDetails.strFullName} teaches {theLecturerDetails.strSpecialCourse}";
      }
      else if (thePerson is cpAlumnus)
      // thePerson is not cpLecturer
      {
        cpAlumnus theAlumnus = (cpAlumnus)thePerson;
        (string strFullName, int intCompletedYear, string strObtainedDegree) theAlumnusDetails = theAlumnus.AlumnusDetails();

        // var theAlumnusDetails = theAlumnus.AlumnusDetails();
        // VVDW - Var can also be used because you want the discrete variables of the tuple

        strResult = $"{theAlumnusDetails.strFullName} has completed {theAlumnusDetails.strObtainedDegree} in {theAlumnusDetails.intCompletedYear}";
      }
      else if (thePerson is cpExchangeStudent)
      // thePerson is not cpAlumnus
      {
        cpExchangeStudent theExchangeStudent = (cpExchangeStudent)thePerson;
        (string strFullName, string strShortCourse, int intDaysLeftOnVisa) theExchangeStudentDetails = theExchangeStudent.ExchangeStudentDetails();

        // var theExchangeStudentDetails = theExchangeStudent.ExchangeStudentDetails();
        // VVDW - Var can also be used because you want the discrete variables of the tuple

        strResult = $"{theExchangeStudentDetails.strFullName} has {theExchangeStudentDetails.intDaysLeftOnVisa} days left on Student Visa";
      }
      else
      // thePerson is not cpExchangeStudent
      {
        throw new System.Exception($"The object {nameof(thePerson)} is not recognized");
      }
      // thePerson is cpStudent
      // thePerson is cpLecturer 
      // thePerson is cpAlumnus
      // thePerson is cpExchangeStudent

      return strResult;
    }
    // GetPersonCourseBeforeCSharp07(System.Object)

    public string GetPersonCourseIsTypePattern(System.Object thePerson)
    //***
    // Action
    //   - If thePerson is a Student
    //     - Return the student details
    //   - If not, if thePerson is a Lecturer
    //     - Return the lecture details
    //   - If not, if thePerson is an Alumnus
    //     - Return the alumnus details
    //   - If not, if thePerson is an Exchange Student
    //     - Return the exchange student details
    //   - If not
    //     - Throw an exception
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - (string, int, string) cpAlumnus.AlumnusDetails()
    //   - (string, string, int) cpExchangeStudent.ExchangeStudentDetails() 
    //   - (string, string, string) cpStudent.StudentDetails()
    //   - (string, string, string, int) cpLecture.LecturerDetails()
    // Created
    //   - CopyPaste – 20251213 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251213 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strResult = "";

      if (thePerson is cpStudent theStudent)
      {
        (string strFullName, string strStudentNumber, string strCourse) theStudentDetails = theStudent.StudentDetails();

        // var theStudentDetails = theStudent.StudentDetails();
        // VVDW - Var can also be used because you want the discrete variables of the tuple

        strResult = $"{theStudentDetails.strFullName} is enrolled for {theStudentDetails.strCourse} with student number {theStudentDetails.strStudentNumber}";
      }
      else if (thePerson is cpLecturer theLecturer)
      // thePerson is not cpStudent 
      {
        (string strFullName, string strEmployeeNumber, string strSpecialCourse, int intTotalDaysEmployed) theLecturerDetails = theLecturer.LecturerDetails();

        // var theLecturerDetails = theLecturer.LecturerDetails();
        // VVDW - Var can also be used because you want the discrete variables of the tuple

        strResult = $"{theLecturerDetails.strFullName} teaches {theLecturerDetails.strSpecialCourse}";
      }
      else if (thePerson is cpAlumnus theAlumnus)
      // thePerson is not cpLecturer
      {
        (string strFullName, int intCompletedYear, string strObtainedDegree) theAlumnusDetails = theAlumnus.AlumnusDetails();

        // var theAlumnusDetails = theAlumnus.AlumnusDetails();
        // VVDW - Var can also be used because you want the discrete variables of the tuple

        strResult = $"{theAlumnusDetails.strFullName} has completed {theAlumnusDetails.strObtainedDegree} in {theAlumnusDetails.intCompletedYear}";
      }
      else if (thePerson is cpExchangeStudent theExchangeStudent)
      // thePerson is not cpAlumnus
      {
        (string strFullName, string strShortCourse, int intDaysLeftOnVisa) theExchangeStudentDetails = theExchangeStudent.ExchangeStudentDetails();

        // var theExchangeStudentDetails = theExchangeStudent.ExchangeStudentDetails();
        // VVDW - Var can also be used because you want the discrete variables of the tuple

        strResult = $"{theExchangeStudentDetails.strFullName} has {theExchangeStudentDetails.intDaysLeftOnVisa} days left on Student Visa";
      }
      else
      // thePerson is not cpExchangeStudent
      {
        throw new System.Exception($"The object {nameof(thePerson)} is not recognized");
      }
      // thePerson is cpStudent
      // thePerson is cpLecturer 
      // thePerson is cpAlumnus
      // thePerson is cpExchangeStudent

      // VVDW - Alternative for the else (discards variable)
      // else if (thePerson is var _)
      // {
      //   strResult = $"Invalid {nameof(thePerson)} object passed.";
      // }

      return strResult;
    }
    // GetPersonCourseIsTypePattern(System.Object)

    public string GetPersonCourseSwitchPattern(System.Object thePerson)
    //***
    // Action
    //   - If thePerson is a Student
    //     - Return the student details
    //   - If not, if thePerson is a Lecturer
    //     - Return the lecture details
    //   - If not, if thePerson is an Alumnus
    //     - Return the alumnus details
    //   - If not, if thePerson is an Exchange Student
    //     - Return the exchange student details
    //   - If not
    //     - Throw an exception
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - (string, int, string) cpAlumnus.AlumnusDetails()
    //   - (string, string, int) cpExchangeStudent.ExchangeStudentDetails() 
    //   - (string, string, string) cpStudent.StudentDetails()
    //   - (string, string, string, int) cpLecture.LecturerDetails()
    // Created
    //   - CopyPaste – 20251213 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251213 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strResult = "";

      switch (thePerson)
      {
        case cpStudent theStudent:
          (string strFullName, string strStudentNumber, string strCourse) theStudentDetails = theStudent.StudentDetails();

          // var theStudentDetails = theStudent.StudentDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theStudentDetails.strFullName} is enrolled for {theStudentDetails.strCourse} with student number {theStudentDetails.strStudentNumber}";
          break;
        case cpLecturer theLecturer:
          (string strFullName, string strEmployeeNumber, string strSpecialCourse, int intTotalDaysEmployed) theLecturerDetails = theLecturer.LecturerDetails();

          // var theLecturerDetails = theLecturer.LecturerDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theLecturerDetails.strFullName} teaches {theLecturerDetails.strSpecialCourse}";
          break;
        case cpAlumnus theAlumnus:
          (string strFullName, int intCompletedYear, string strObtainedDegree) theAlumnusDetails = theAlumnus.AlumnusDetails();

          // var theAlumnusDetails = theAlumnus.AlumnusDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theAlumnusDetails.strFullName} has completed {theAlumnusDetails.strObtainedDegree} in {theAlumnusDetails.intCompletedYear}";
          break;
        case cpExchangeStudent theExchangeStudent:
          (string strFullName, string strShortCourse, int intDaysLeftOnVisa) theExchangeStudentDetails = theExchangeStudent.ExchangeStudentDetails();

          // var theExchangeStudentDetails = theExchangeStudent.ExchangeStudentDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theExchangeStudentDetails.strFullName} has {theExchangeStudentDetails.intDaysLeftOnVisa} days left on Student Visa";
          break;
        default:
          throw new System.Exception($"The object {nameof(thePerson)} is not recognized");

        // VVDW - Alternative for the default with discarded variable
        // case var _:
        //  strResult = $"Invalid {nameof(thePerson)} object passed";
        //  break;
      }
      // thePerson

      return strResult;
    }
    // GetPersonCourseSwitchPattern(System.Object)

    public string GetPersonCourseSwitchPatternNull(System.Object thePerson)
    //***
    // Action
    //   - If thePerson is a Student
    //     - Return the student details
    //   - If not, if thePerson is a Lecturer
    //     - Return the lecture details
    //   - If not, if thePerson is an Alumnus
    //     - Return the alumnus details
    //   - If not, if thePerson is an Exchange Student
    //     - Return the exchange student details
    //   - If not, if thePerson is null
    //     - Return a string that null is not allowed
    //   - If not
    //     - Throw an exception
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - (string, int, string) cpAlumnus.AlumnusDetails()
    //   - (string, string, int) cpExchangeStudent.ExchangeStudentDetails() 
    //   - (string, string, string) cpStudent.StudentDetails()
    //   - (string, string, string, int) cpLecture.LecturerDetails()
    // Created
    //   - CopyPaste – 20251213 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251213 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strResult = "";

      switch (thePerson)
      {
        case cpStudent theStudent:
          (string strFullName, string strStudentNumber, string strCourse) theStudentDetails = theStudent.StudentDetails();

          // var theStudentDetails = theStudent.StudentDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theStudentDetails.strFullName} is enrolled for {theStudentDetails.strCourse} with student number {theStudentDetails.strStudentNumber}";
          break;
        case cpLecturer theLecturer:
          (string strFullName, string strEmployeeNumber, string strSpecialCourse, int intTotalDaysEmployed) theLecturerDetails = theLecturer.LecturerDetails();

          // var theLecturerDetails = theLecturer.LecturerDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theLecturerDetails.strFullName} teaches {theLecturerDetails.strSpecialCourse}";
          break;
        case cpAlumnus theAlumnus:
          (string strFullName, int intCompletedYear, string strObtainedDegree) theAlumnusDetails = theAlumnus.AlumnusDetails();

          // var theAlumnusDetails = theAlumnus.AlumnusDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theAlumnusDetails.strFullName} has completed {theAlumnusDetails.strObtainedDegree} in {theAlumnusDetails.intCompletedYear}";
          break;
        case cpExchangeStudent theExchangeStudent:
          (string strFullName, string strShortCourse, int intDaysLeftOnVisa) theExchangeStudentDetails = theExchangeStudent.ExchangeStudentDetails();

          // var theExchangeStudentDetails = theExchangeStudent.ExchangeStudentDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theExchangeStudentDetails.strFullName} has {theExchangeStudentDetails.intDaysLeftOnVisa} days left on Student Visa";
          break;
        case null:
          strResult = $"The object {nameof(thePerson)} is null and not allowed";
          break;
        default:
          throw new System.Exception($"The object {nameof(thePerson)} is not recognized");
      }
      // thePerson

      return strResult;
    }
    // GetPersonCourseSwitchPatternNull(System.Object)

    public string GetPersonCourseSwitchWhenPattern(System.Object thePerson)
    //***
    // Action
    //   - If thePerson is a Student
    //     - Return the student details
    //   - If not, if thePerson is a Lecturer
    //     - Return the lecture details
    //   - If not, if thePerson is an Alumnus
    //     - Return the alumnus details
    //   - If not, if thePerson is an Exchange Student
    //     - Return the exchange student details
    //   - If not
    //     - Throw an exception
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - (string, int, string) cpAlumnus.AlumnusDetails()
    //   - (string, string, int) cpExchangeStudent.ExchangeStudentDetails() 
    //   - (string, string, string) cpStudent.StudentDetails()
    //   - (string, string, string, int) cpLecture.LecturerDetails()
    // Created
    //   - CopyPaste – 20251213 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251213 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strResult = "";

      switch (thePerson)
      {
        case cpStudent theStudent:
          (string strFullName, string strStudentNumber, string strCourse) theStudentDetails = theStudent.StudentDetails();

          // var theStudentDetails = theStudent.StudentDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theStudentDetails.strFullName} is enrolled for {theStudentDetails.strCourse} with student number {theStudentDetails.strStudentNumber}";
          break;
        case cpLecturer theLecturer:
          (string strFullName, string strEmployeeNumber, string strSpecialCourse, int intTotalDaysEmployed) theLecturerDetails = theLecturer.LecturerDetails();

          // var theLecturerDetails = theLecturer.LecturerDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theLecturerDetails.strFullName} teaches {theLecturerDetails.strSpecialCourse}";
          break;
        case cpAlumnus theAlumnus when theAlumnus.CompletedYear < 2000:
          (string strFullName, int intCompletedYear, string strObtainedDegree) theAlumnusDetails = theAlumnus.AlumnusDetails();

          // var theAlumnusDetails = theAlumnus.AlumnusDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"The senior alumnus {theAlumnusDetails.strFullName} has completed {theAlumnusDetails.strObtainedDegree} in {theAlumnusDetails.intCompletedYear}";
          break;
        case cpAlumnus theAlumnus:
          (string strFullName, int intCompletedYear, string strObtainedDegree) theSeniorAlumnusDetails = theAlumnus.AlumnusDetails();

          // var theAlumnusDetails = theAlumnus.AlumnusDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theSeniorAlumnusDetails.strFullName} has completed {theSeniorAlumnusDetails.strObtainedDegree} in {theSeniorAlumnusDetails.intCompletedYear}";
          break;
        case cpExchangeStudent theExchangeStudent:
          (string strFullName, string strShortCourse, int intDaysLeftOnVisa) theExchangeStudentDetails = theExchangeStudent.ExchangeStudentDetails();

          // var theExchangeStudentDetails = theExchangeStudent.ExchangeStudentDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theExchangeStudentDetails.strFullName} has {theExchangeStudentDetails.intDaysLeftOnVisa} days left on Student Visa";
          break;
        default:
          throw new System.Exception($"The object {nameof(thePerson)} is not recognized");
      }
      // thePerson

      return strResult;
    }
    // GetPersonCourseSwitchWhenPattern(System.Object)

    public string GetPersonCourseSwitchWhenPatternExclusion(System.Object thePerson)
    //***
    // Action
    //   - If thePerson is a Student
    //     - Return the student details
    //   - If not, if thePerson is a Lecturer
    //     - Return the lecture details
    //   - If not, if thePerson is an Alumnus
    //     - Return the alumnus details
    //   - If not, if thePerson is an Exchange Student
    //     - Return the exchange student details
    //   - If not
    //     - Throw an exception
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - (string, int, string) cpAlumnus.AlumnusDetails()
    //   - (string, string, int) cpExchangeStudent.ExchangeStudentDetails() 
    //   - (string, string, string) cpStudent.StudentDetails()
    //   - (string, string, string, int) cpLecture.LecturerDetails()
    //   - string cpPerson.FirstName (Get)
    //   - string cpPerson.LastName (Get)
    // Created
    //   - CopyPaste – 20251213 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251213 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strResult = "";

      switch (thePerson)
      {
        case cpStudent theStudent when theStudent.EnrolledForCourse == cpProgram.cpUniversityCourses.LifeSkills:
        case cpAlumnus theAlumnus when theAlumnus.CompletedYear >= 2000:
          cpPerson aPerson = (cpPerson)thePerson;

          strResult = $"{aPerson.FirstName} {aPerson.LastName} is excluded.";
          break;
        case cpStudent theStudent:
          (string strFullName, string strStudentNumber, string strCourse) theStudentDetails = theStudent.StudentDetails();

          // var theStudentDetails = theStudent.StudentDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theStudentDetails.strFullName} is enrolled for {theStudentDetails.strCourse} with student number {theStudentDetails.strStudentNumber}";
          break;
        case cpLecturer theLecturer:
          (string strFullName, string strEmployeeNumber, string strSpecialCourse, int intTotalDaysEmployed) theLecturerDetails = theLecturer.LecturerDetails();

          // var theLecturerDetails = theLecturer.LecturerDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theLecturerDetails.strFullName} teaches {theLecturerDetails.strSpecialCourse}";
          break;
        case cpAlumnus theAlumnus when theAlumnus.CompletedYear < 2000:
          (string strFullName, int intCompletedYear, string strObtainedDegree) theAlumnusDetails = theAlumnus.AlumnusDetails();

          // var theAlumnusDetails = theAlumnus.AlumnusDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"The senior alumnus {theAlumnusDetails.strFullName} has completed {theAlumnusDetails.strObtainedDegree} in {theAlumnusDetails.intCompletedYear}";
          break;
        case cpAlumnus theAlumnus:
          (string strFullName, int intCompletedYear, string strObtainedDegree) theSeniorAlumnusDetails = theAlumnus.AlumnusDetails();

          // var theAlumnusDetails = theAlumnus.AlumnusDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theSeniorAlumnusDetails.strFullName} has completed {theSeniorAlumnusDetails.strObtainedDegree} in {theSeniorAlumnusDetails.intCompletedYear}";
          break;
        case cpExchangeStudent theExchangeStudent:
          (string strFullName, string strShortCourse, int intDaysLeftOnVisa) theExchangeStudentDetails = theExchangeStudent.ExchangeStudentDetails();

          // var theExchangeStudentDetails = theExchangeStudent.ExchangeStudentDetails();
          // VVDW - Var can also be used because you want the discrete variables of the tuple

          strResult = $"{theExchangeStudentDetails.strFullName} has {theExchangeStudentDetails.intDaysLeftOnVisa} days left on Student Visa";
          break;
        default:
          throw new System.Exception($"The object {nameof(thePerson)} is not recognized");
      }
      // thePerson

      return strResult;
    }
    // GetPersonCourseSwitchWhenPatternExclusion(System.Object)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPatternMatching

}
// CopyPaste.Learning