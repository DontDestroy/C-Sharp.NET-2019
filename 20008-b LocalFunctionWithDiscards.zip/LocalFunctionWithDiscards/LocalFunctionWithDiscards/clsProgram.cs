﻿//***
// Action
//   - Local function with discards
// Created
//   - CopyPaste – 20251222 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251222 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251222 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251222 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Starting routine
    //   - Define a local function CheckValue
    //     - Checks if a value is above zero, below max and in range
    //     - Returns a tuple of three booleans
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - (bool, bool, bool) CheckValue(int)
    // Created
    //   - CopyPaste – 20251222 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251222 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      (bool blnZeroCheck, bool blnMaximumCheck, bool blnInRangeBordersExcludedCheck) CheckValue(int intValue)
      //***
      // Action
      //   - Define 3 booleans
      //   - If given value is larger than zero
      //     - Boolean above zero becomes true
      //   - If given value is smaller than twenty
      //     - Boolean below twenty becomes true
      //   - If both previous booleans are true
      //     - Boolean within range (borders excluded) becomes true
      //   - Returns a tuple of the three boolean results
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251222 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251222 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        bool blnAboveZero = false;
        bool blnBelowTwenty = false;
        bool blnInRangeBordersExcluded = false;

        if (intValue > 0)
        {
          blnAboveZero = true;
        }
        else
        // intValue <= 0
        {
        }
        // intValue > 0

        if (intValue < 20)
        {
          blnBelowTwenty = true;
        }
        else
        // intValue >= 20
        {
        }
        // intValue < 20

        if (blnAboveZero && blnBelowTwenty)
        {
          blnInRangeBordersExcluded = true;
        }
        else
        // Not blnAboveZero Or Not blnBelowTwenty
        {
        }
        // blnAboveZero And blnBelowTwenty

        return (blnAboveZero, blnBelowTwenty, blnInRangeBordersExcluded);
      }
      // (bool, bool, bool) CheckValue(int)


      (_, _, bool blnValid) = CheckValue(21);

      if (blnValid)
      {
        Console.WriteLine("The given value is in range");
      }
      else
      // Not blnValid
      {
        Console.WriteLine("The given value is outside the range");
      }
      // blnValid

      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning