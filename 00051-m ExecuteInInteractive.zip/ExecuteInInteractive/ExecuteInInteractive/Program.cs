﻿//***
// Action
//   - Try to find the issue in the code
//   - Execute the code in Interactive mode
// Created
//   - CopyPaste – 20251223 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251223 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using static System.Console;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251223 – VVDWa
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Start with a text
    //   - Split the text into an array (use space as delimiter)
    //   - Create a new text
    //   - Loop thru the array of words
    //     - Define a text to append
    //     - If word is "mainly"
    //       - Change it into "gently"
    //     - Add the result to the new text
    //   - Show new text on the console
    //   - Wait for user action
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - There are errors in the code
    //     - The goal is to replace the word 'mainly' with 'gently'
    //   - The goal is to use C# Interactive screen to debug the stuff
    //***
    {
      string[] arrWords;
      string strNewText;
      string strSomeText;

      strSomeText = "The rain falls mainly on the plain in Spain";
      arrWords = strSomeText.Split(' ');

      strNewText = "";

      foreach (string strWord in arrWords)
      {
        string strTextToAppend = strWord.Equals("mainly") ? "gently" : strWord;
        strNewText += strWord;
      }
      // in arrWords

      WriteLine(strNewText);
      WriteLine();
      WriteLine("Hit any key");
      ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    #region "Not used"

    // Correct the code below
    //   strNewText += strWord;
    // with
    //   strNewText += $"{strTextToAppend} ";

    #endregion

  }
  // cpProgram

}
// CopyPaste.Learning