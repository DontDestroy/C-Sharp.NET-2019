//***
// Action
//   - Print an icon
// Created
//   - CopyPaste � 20240527 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240527 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPrint: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label Label1;
    internal System.Drawing.Printing.PrintDocument prtDocument;
    internal System.Windows.Forms.TextBox txtFile;
    internal System.Windows.Forms.Button cmdPrint;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPrint));
      this.Label1 = new System.Windows.Forms.Label();
      this.prtDocument = new System.Drawing.Printing.PrintDocument();
      this.txtFile = new System.Windows.Forms.TextBox();
      this.cmdPrint = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // Label1
      // 
      this.Label1.Location = new System.Drawing.Point(24, 32);
      this.Label1.Name = "Label1";
      this.Label1.Size = new System.Drawing.Size(224, 16);
      this.Label1.TabIndex = 3;
      this.Label1.Text = "Type the name of the picture that you want to print.";
      // 
      // txtFile
      // 
      this.txtFile.Location = new System.Drawing.Point(24, 56);
      this.txtFile.Name = "txtFile";
      this.txtFile.Size = new System.Drawing.Size(240, 20);
      this.txtFile.TabIndex = 4;
      this.txtFile.Text = "sun.ico";
      // 
      // cmdPrint
      // 
      this.cmdPrint.Location = new System.Drawing.Point(96, 120);
      this.cmdPrint.Name = "cmdPrint";
      this.cmdPrint.Size = new System.Drawing.Size(88, 23);
      this.cmdPrint.TabIndex = 5;
      this.cmdPrint.Text = "&Print";
      this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
      // 
      // frmPrint
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.txtFile);
      this.Controls.Add(this.cmdPrint);
      this.Controls.Add(this.Label1);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPrint";
      this.Text = "Print Picture";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPrint'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPrint()
      //***
      // Action
      //   - Create instance of 'frmPrint'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPrint()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdPrint_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try
      //     - Define the print page action
      //     - Execute the print
      //   - When there is an error
      //     - Show error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - PrintGraphic(System.Object, PrintPageEventArgs)
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        prtDocument.PrintPage += new PrintPageEventHandler(PrintGraphic);
        prtDocument.Print();
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.ToString(), "Sorry, there is a print problem");
      }
      finally
      {
      }
    
    }
    // cmdPrint_Click(System.Object, System.EventArgs) Handles cmdPrint.Click

    #endregion

    #region "Functionality"

    #region "Event"

    private void PrintGraphic(System.Object theSender, PrintPageEventArgs thePrintPageEventArguments)
      //***
      // Action
      //   - The draw image becomes the icon defined by the current directory and the text on the form
      //   - This document has only one page
      // Called by
      //   - cmdPrint_Click(System.Object, System.EventArgs) Handles cmdPrint.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      thePrintPageEventArguments.Graphics.DrawImage(Image.FromFile(Environment.CurrentDirectory + "/" + txtFile.Text), thePrintPageEventArguments.Graphics.VisibleClipBounds);
      thePrintPageEventArguments.HasMorePages = false;
    }
    // PrintGraphic(System.Object, PrintPageEventArgs)

    #endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPrint
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmPrint()
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPrint());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPrint

}
// CopyPaste.Learning