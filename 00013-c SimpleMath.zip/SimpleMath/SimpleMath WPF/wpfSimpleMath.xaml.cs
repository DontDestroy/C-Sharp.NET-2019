﻿//***
// Action
//   - Examples of simple math calculations
// Created
//   - CopyPaste – 20220820 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20220820 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SimpleMath_WPF
{

  public partial class wpfSimpleMath : Window
  {

    #region "Constructors / Destructors"

    public wpfSimpleMath()
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220820 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220820 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfSimpleMath()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCalculate_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Do a calculation
    //   - If 'txtNumber01' is not a number, show error message
    //   - If 'txtNumber02' is not a number, show error message
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - Microsoft.VisualBasic.IsNumeric(string)
    //   - System.Windows.Forms.MessageBox.Show(string)
    //   - System.Convert.ToInt32(string)
    // Created
    //   - CopyPaste – 20220820 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220820 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //   - Rewrite this exercise using int.TryParse(input, output)
    //***
    {
      int intNumber01;
      int intNumber02;
      double dblResult;

      try
      {
        intNumber01 = int.Parse(txtNumber01.Text);
      }
      catch
      {
        MessageBox.Show("Please type a number in the first field.");
        txtNumber01.Focus();
        return;
      }

      try
      {
        intNumber02 = int.Parse(txtNumber02.Text);
      }
      catch
      {
        MessageBox.Show("Please type a number in the second field.");
        txtNumber02.Focus();
        return;
      }

      switch (lblOperator.Content)
      {
        case "+":
          {
            dblResult = intNumber01 + intNumber02;
            lblResult.Content = dblResult.ToString();
            break;
          }
        // lblOperator.Content = "+"
        case "-":
          {
            dblResult = intNumber01 - intNumber02;
            lblResult.Content = dblResult.ToString();
            break;
          }
        // lblOperator.Content = "-"
        case "*":
          {
            dblResult = intNumber01 * intNumber02;
            lblResult.Content = dblResult.ToString();
            break;
          }
        // lblOperator.Content = "*"
        case "/":
          {
            dblResult = intNumber01 / intNumber02;
            lblResult.Content = dblResult.ToString();
            break;
          }
        // lblOperator.Content == "/"
        case "%":
          {
            dblResult = intNumber01 % intNumber02;
            lblResult.Content = dblResult.ToString();
            break;
          }
          // lblOperator.Content == "%"

      }
      // lblOperator.Content

    }
    // cmdCalculate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCalculate.Click

    private void cmdQuit_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - End program
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220820 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220820 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.Close();
    }
    // cmdQuit_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdQuit.Click

    private void optAdd_Checked(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Change 'lblOperator' to "+"
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220820 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220820 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblOperator.Content = "+";
    }
    // optAdd_Checked(System.Object, System.Windows.RoutedEventArgs) Handles optAdd.Checked

    private void optDivide_Checked(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Change 'lblOperator' to "/"
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220820 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220820 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblOperator.Content = "/";
    }
    // optDivide_Checked(System.Object, System.Windows.RoutedEventArgs) Handles optDivide.Checked

    private void optMultiply_Checked(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Change 'lblOperator' to "*"
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220820 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220820 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblOperator.Content = "*";
    }
    // optMultiply_Checked(System.Object, System.Windows.RoutedEventArgs) Handles optMultiply.Checked

    private void optReminder_Checked(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Change 'lblOperator' to "%"
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220820 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220820 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblOperator.Content = "%";
    }
    // optReminder_Checked(System.Object, System.Windows.RoutedEventArgs) Handles optReminder.Checked

    private void optSubtract_Checked(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Change 'lblOperator' to "-"
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220820 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220820 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblOperator.Content = "-";
    }
    // optSubtract_Checked(System.Object, System.Windows.RoutedEventArgs) Handles optSubtract.Checked

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfSimpleMath

}
// SimpleMath_WPF