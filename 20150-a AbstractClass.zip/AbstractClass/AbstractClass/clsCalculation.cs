﻿//***
// Action
//   - Implementation of an abstract class cpCalculation
//     - There are internal classes, methods, properties, indexers or events not implemented (defined as abstract)
//     - This means, this class can't be instantiated
//     - To use the functionality, it must be inherited
// Created
//   - CopyPaste – 20260128 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260128 – VVDW
// Proposal (To Do)
//   - Pay attention to the modifier abstract
//   - Pay attention to the access modifier protected
//***

namespace CopyPaste.Learning
{

  public abstract class cpCalculation
  {

    #region "Constructors / Destructors"

    public cpCalculation()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance thru inheritance)
    //   - cpAdd()
    //   - cpAdd(int, int)
    //   - cpIntegerDivision()
    //   - cpIntegerDivision(int, int)
    //   - cpMultiplication()
    //   - cpMultiplication(int, int)
    //   - cpSubtraction()
    //   - cpSubtraction(int, int)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpCalculation()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    protected int _firstValue;
    protected int _secondValue;

    #endregion

    #region "Properties"

    public abstract int FirstValue { get; set; }
    // This is a virtual property that must be implemented by the child class (downwards inheritance)
    // int cpAdd.FirstValue
    // int cpIntegerDivision.FirstValue
    // int cpMultiplication.FirstValue
    // int cpSubtraction.FirstValue

    public abstract int SecondValue { get; set; }
    // This is a virtual property that must be implemented by the child class (downwards inheritance)
    // int cpAdd.SecondValue
    // int cpIntegerDivision.SecondValue
    // int cpMultiplication.SecondValue
    // int cpSubtraction.SecondValue

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public abstract int Calculate();
    // This is a virtual method that must be implemented by the child class (downwards inheritance)
    // int cpAdd.Calculate()
    // int cpIntegerDivision.Calculate()
    // int cpMultiplication.Calculate()
    // int cpSubtraction.Calculate()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning