﻿//***
// Action
//   - Demo of TextBlock Controls
// Created
//   - CopyPaste – 20220923 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220923 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;


namespace WPFTextBlock
{

  public partial class wpfTextBlock : Window
  {

    #region "Constructors / Destructors"

    public wpfTextBlock()
    //***
    // Action
    //   - Create an instance of 'wpfTextBlock'
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220923 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220923 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfTextBlock()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // wpfTextBlock

}
// WPFTextBlock