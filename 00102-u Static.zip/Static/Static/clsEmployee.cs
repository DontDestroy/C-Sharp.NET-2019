//***
// Action
//   - Implementation of cpEmployee
// Created
//   - CopyPaste � 20230802 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230802 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpEmployee
  {

    #region "Constructors / Destructors"

    static cpEmployee()
    //***
    // Action
    //   - Shared Constructor of cpEmployee
    //   - Set the CompanyParty to the first of september this year
    //   - While it is not a Friday
    //     - Add one day to CompanyParty
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - CompanyParty(DateTime) (Set)
    //   - DateTime CompanyParty (Get)
    // Created
    //   - CopyPaste � 20230802 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230802 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      CompanyParty = new DateTime(DateTime.Today.Year, 9, 1);

      while (CompanyParty.DayOfWeek != DayOfWeek.Friday)
      {
        CompanyParty = CompanyParty.AddDays(1);
      }
      // CompanyParty.DayOfWeek = DayOfWeek.Friday

    }
    // cpEmployee()

    public cpEmployee() : this("Unknown", aSex.Male, DateTime.Today)
    //***
    // Action
    //   - Default Constructor of cpEmployee
    //   - Name "Unknown", aSex Male and Date Today
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpEmployee(string, aSex, DateTime)
    // Created
    //   - CopyPaste � 20230802 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230802 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpEmployee()

    public cpEmployee(string strName, aSex theSex, DateTime dtmStartDate)
    //***
    // Action
    //   - Constructor of cpEmployee
    //   - Defines a name, a sex and a date
    // Called by
    //   - cpProgram.Main()
    //   - cpEmployee()
    // Calls
    //   - Name(string) (Set)
    //   - Sex(aSex) (Set)
    //   - StartDate(DateTime) (Set)
    // Created
    //   - CopyPaste � 20230802 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230802 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Name = strName;
      Sex = theSex;
      StartDate = dtmStartDate;
    }
    // cpEmployee(string, aSex, DateTime)

    #endregion

    #region "Designer"

    public enum aSex
    {
      Male,
      Female
    }
    // aSex

    #endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private aSex theSex;
    private static DateTime dtmCompanyParty; 
    private DateTime dtmStart;
    private DateTime dtmStartCompany = new DateTime(1991, 9, 1);
    private string strName;

    #endregion

    #region "Properties"

    public static DateTime CompanyParty
    {

      get
      //***
      // Action Get
      //   - Return dtmCompanyParty
      // Called by
      //   - bool TodayIsParty (Get)
      //   - cpEmployee()
      //   - ShowInfo()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230802 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230802 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return dtmCompanyParty;
      }
      // DateTime CompanyParty (Get)

      set
      //***
      // Action Set
      //   - dtmCompanyParty becomes value
      // Called by
      //   - cpProgram.Main()
      //   - cpEmployee()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230802 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230802 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        dtmCompanyParty = value;
      }
      // CompanyParty(DateTime) (Set)

    }
    // DateTime CompanyParty

    public string Name
    {

      get
      //***
      // Action Get
      //   - Return strName
      // Called by
      //   - ShowInfo()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230802 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230802 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return strName;
      }
      // string Name (Get)

      set
      //***
      // Action Set
      //   - strName becomes value
      // Called by
      //   - cpEmployee(string, aSex, DateTime)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230802 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230802 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        strName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    public aSex Sex
    {

      get
      //***
      // Action Get
      //   - Return theSex
      // Called by
      //   - ShowInfo()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230802 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230802 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return theSex;
      }
      // aSex Sex (Get)

      set
      //***
      // Action Set
      //   - theSex becomes value
      // Called by
      //   - cpEmployee(string, aSex, DateTime)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230802 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230802 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        theSex = value;
      }
      // Sex(aSex) (Set)

    }
    // aSex Sex

    public DateTime StartDate
    {

      get
      //***
      // Action Get
      //   - Return dtmStart
      // Called by
      //   - ShowInfo()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230802 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230802 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return dtmStart;
      }
      // DateTime StartDate (Get)

      set
      //***
      // Action Set
      //   - If dtmValue becomes after dtmStartCompany
      //     - dtmStart becomes dtmValue
      //   - If Not
      //    - dtmStart becomes dtmStartCompany
      // Called by
      //   - cpEmployee(string, aSex, DateTime)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230802 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230802 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if (value >= dtmStartCompany)
        {
          dtmStart = value;
        }
        else
          // value < dtmStartCompany
        {
          dtmStart = dtmStartCompany;
        }
        // value >= dtmStartCompany

      }
      // StartDate(DateTime) (Set)

    }
    // DateTime StartDate

    public static bool TodayIsParty
    {

      get
      //***
      // Action Get
      //   - Return CompanyParty = Today
      // Called by
      //   - ShowInfo()
      // Calls
      //   - DateTime CompanyParty (Get)
      // Created
      //   - CopyPaste � 20230802 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230802 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return CompanyParty == DateTime.Today;
      }
      // bool TodayIsParty (Get)

    }
    // bool TodayIsParty 

    public bool WorkAnniversary
    {

      get
      //***
      // Action Get
      //  - If month and Day of dtmStart and today are the same
      //    - Return True
      //  - If Not
      //    - Return False
      // Called by
      //   - ShowInfo()
      // Calls
      //   -
      // Created
      //   - CopyPaste � 20230802 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230802 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if ((dtmStart.Month == DateTime.Today.Month) && (dtmStart.Day == DateTime.Today.Day))
        {
          return true;
        }
        else
          // dtmStart.Month <> DateTime.Today.Month || dtmStart.Day <> DateTime.Today.Day 
        {
          return false;
        }
        // dtmStart.Month = DateTime.Today.Month && dtmStart.Day = DateTime.Today.Day 

      }
      // bool WorkAnniversary (Get)

    }
    // bool WorkAnniversary 

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ShowInfo()
    //***
    // Action
    //   - Show information of a cpEmployee
    //   - The name, sex, startdate, WorkAnniversary and CompanyParty
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - aSex Sex (Get)
    //   - bool WorkAnniversary (Get)
    //   - DateTime CompanyParty (Get)
    //   - DateTime StartDate() (Get)
    //   - string Name (Get)
    // Created
    //   - CopyPaste � 20230802 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230802 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine("Name: {0}", Name);
      Console.WriteLine("Sex: {0}", Sex.ToString());
      Console.WriteLine("Start date: {0}", StartDate);
      Console.WriteLine("Needs to buy a cake: {0}", WorkAnniversary);
      Console.WriteLine("Today is company party {0}: {1}", CompanyParty, TodayIsParty);
      Console.WriteLine();
    }
    // ShowInfo()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpEmployee

}
// CopyPaste.Learning