//***
// Action
//   - Test the cpEmployee class
// Created
//   - CopyPaste � 20220308 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220308 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Toolkit;
using System;

namespace Employee
{

  class cpProgram
	{

    static void Main()
    //***
    // Action
    //   - Define an output string
    //   - Show the current number of employees
    //   - Create 2 employees
    //   - Show the current number of employees
    //   - Destroy 1 employee
    //   - Do a garbage collection
    //   - Show the current number of employees
    //   - Destroy 1 employee
    //   - Do a garbage collection
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpEmployee.Finalize()
    //   - cpEmployee.New(string, string)
    //   - int cpEmployee.Count()
    //   - string cpEmployee.FirstName()
    //   - string cpEmployee.LastName()
    // Created
    //   - CopyPaste � 20220308 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220308 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Put the line in comment active and look at the behaviour
    //***
    {

      Console.WriteLine("Employees before instantiation: " + cpEmployee.Count);

      cpEmployee theFirstEmployee = new cpEmployee("Susan", "Baker");
      cpEmployee theSecondEmployee = new cpEmployee("Bob", "Jones");
      
      Console.WriteLine("\nEmployees after instantiation: \nvia cpEmployee.Count: " + cpEmployee.Count);
      Console.WriteLine("\nEmployee 1: " + theFirstEmployee.FirstName + " " + theFirstEmployee.LastName +
        "\nEmployee 2: " + theSecondEmployee.FirstName + " " + theSecondEmployee.LastName + "\n");
      
      theFirstEmployee = null;
      theSecondEmployee = null;
      
      System.GC.Collect();
      Console.WriteLine("\nEmployees after destroying: \nvia cpEmployee.Count: " + cpEmployee.Count + "\n");
      Console.ReadLine();
    }
    // Main()

  }
  // cpProgram

}
// Employee