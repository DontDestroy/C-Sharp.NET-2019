//***
// Action
//   - Create a country dataset in memory (no fysical database)
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   -
//***

using System.Data;

namespace CopyPaste.Learning
{

  public class cpCountry
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    public DataSet CreateCountryDataSet()
      //***
      // Action
      //   - Create a country dataset (containing continent and country data)
      //   - Create 5 columns
      //   - Create 2 data rows
      //   - Create 2 data tables
      //   - Create 1 data set
      //   - Define the 2 names of the data tables
      //   - Define the column of the key of the continent
      //   - Define the column of the name of the continent
      //   - Add the 2 columns to the data table
      //   - Define the primary key of the continent
      //   - Define a constraints for the key of the continent
      //   - Create 2 new data rows for the continent
      //   - Define the column of the key of the country
      //   - Define the column of the name of the country
      //   - Define the column of the continent key of the country
      //   - Add the 3 columns to the data table
      //   - Define the primary key of the country
      //   - Create a relationship (one to many) between continent and country
      //   - Create 4 new data rows for the country
      //   - Return the created data set
      // Called by
      //   - frmContinentCountry.frmContinentCountry_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      DataColumn dclContinent = new DataColumn();
      DataColumn dclContinentKey = new DataColumn();
      DataColumn dclCountry = new DataColumn();
      DataColumn dclKeyContinent = new DataColumn();
      DataColumn dclKeyCountry = new DataColumn();
      DataRow drwContinent;
      DataRow drwCountry;
      DataSet dsCountry = new DataSet();
      DataTable dtContinent = new DataTable();
      DataTable dtCountry = new DataTable();

      dtContinent.TableName = "Continent";
      dtCountry.TableName = "Country";

      dclKeyContinent.ColumnName = "lngIdContinent";
      dclKeyContinent.DataType = System.Type.GetType("System.Int32");
      dclKeyContinent.AutoIncrement = true;
      dclKeyContinent.AutoIncrementSeed = 1;
      dclKeyContinent.AutoIncrementStep = 1;

      dclContinent.ColumnName = "strContinent";
      dclContinent.DataType = System.Type.GetType("System.String");
      dclContinent.AllowDBNull = false;

      dtContinent.Columns.Add(dclKeyContinent);
      dtContinent.Columns.Add(dclContinent);

      DataColumn[] dclPrimaryKeyContinent = {dclKeyContinent};

      dtContinent.PrimaryKey = dclPrimaryKeyContinent;
      dtContinent.Constraints.Add(new UniqueConstraint(dclContinent));

      drwContinent = dtContinent.NewRow();
      drwContinent["strContinent"] = "Europe";
      dtContinent.Rows.Add(drwContinent);
      drwContinent = dtContinent.NewRow();
      drwContinent["strContinent"] = "South-America";
      dtContinent.Rows.Add(drwContinent);

      dclKeyCountry.ColumnName = "strCountryCode";
      dclKeyCountry.DataType = System.Type.GetType("System.String");

      dclCountry.ColumnName = "strCountry";
      dclCountry.DataType = System.Type.GetType("System.String");
      dclCountry.AllowDBNull = false;

      dclContinentKey.ColumnName = "lngContinentId";
      dclContinentKey.DataType = System.Type.GetType("System.Int32");
      dclContinentKey.AllowDBNull = false;

      dtCountry.Columns.Add(dclKeyCountry);
      dtCountry.Columns.Add(dclCountry);
      dtCountry.Columns.Add(dclContinentKey);

      DataColumn[] dclPrimaryKeyCountry = {dclKeyCountry};

      dtCountry.PrimaryKey = dclPrimaryKeyCountry;

      dsCountry.Tables.Add(dtCountry);
      dsCountry.Tables.Add(dtContinent);

      DataRelation theRelation = new DataRelation("CountryContinent", dclKeyContinent, dclContinentKey);

      dsCountry.Relations.Add(theRelation);
      theRelation.ChildKeyConstraint.DeleteRule = Rule.Cascade;

      drwCountry = dtCountry.NewRow();
      drwCountry["strCountryCode"] = "BE";
      drwCountry["strCountry"] = "Belgium";
      drwCountry["lngContinentId"] = 1;
      dtCountry.Rows.Add(drwCountry);
      drwCountry = dtCountry.NewRow();
      drwCountry["strCountryCode"] = "FR";
      drwCountry["strCountry"] = "France";
      drwCountry["lngContinentId"] = 1;
      dtCountry.Rows.Add(drwCountry);
      drwCountry = dtCountry.NewRow();
      drwCountry["strCountryCode"] = "MX";
      drwCountry["strCountry"] = "Mexico";
      drwCountry["lngContinentId"] = 2;
      dtCountry.Rows.Add(drwCountry);
      drwCountry = dtCountry.NewRow();
      drwCountry["strCountryCode"] = "BR";
      drwCountry["strCountry"] = "Brasil";
      drwCountry["lngContinentId"] = 2;
      dtCountry.Rows.Add(drwCountry);

      return dsCountry;
    }
    // DataSet CreateCountryDataSet()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBrewer

}
// CopyPaste.Learning