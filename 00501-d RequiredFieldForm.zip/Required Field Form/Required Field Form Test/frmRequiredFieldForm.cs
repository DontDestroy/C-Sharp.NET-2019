//***
// Action
//   - Test the default form control
// Created
//   - CopyPaste � 20250719 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250719 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Learning.UserInterface;
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmRequiredFieldForm: cpctlRequiredFieldForm
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdCancel;
    internal System.Windows.Forms.Button cmdOK;
    internal System.Windows.Forms.ListBox lstListBox;
    internal System.Windows.Forms.ComboBox cmbComboBox;
    internal System.Windows.Forms.TextBox txtText;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmRequiredFieldForm));
      this.cmdCancel = new System.Windows.Forms.Button();
      this.cmdOK = new System.Windows.Forms.Button();
      this.lstListBox = new System.Windows.Forms.ListBox();
      this.cmbComboBox = new System.Windows.Forms.ComboBox();
      this.txtText = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdCancel
      // 
      this.cmdCancel.Location = new System.Drawing.Point(251, 232);
      this.cmdCancel.Name = "cmdCancel";
      this.cmdCancel.TabIndex = 9;
      this.cmdCancel.Text = "Cancel";
      this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
      // 
      // cmdOK
      // 
      this.cmdOK.Location = new System.Drawing.Point(251, 192);
      this.cmdOK.Name = "cmdOK";
      this.cmdOK.TabIndex = 8;
      this.cmdOK.Text = "OK";
      this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
      // 
      // lstListBox
      // 
      this.lstListBox.Items.AddRange(new object[] {
                                                    "List Item One",
                                                    "List Item Two",
                                                    "List Item Three"});
      this.lstListBox.Location = new System.Drawing.Point(11, 120);
      this.lstListBox.Name = "lstListBox";
      this.lstListBox.Size = new System.Drawing.Size(224, 134);
      this.lstListBox.TabIndex = 7;
      // 
      // cmbComboBox
      // 
      this.cmbComboBox.Items.AddRange(new object[] {
                                                     "First One",
                                                     "Second One",
                                                     "Third One"});
      this.cmbComboBox.Location = new System.Drawing.Point(11, 80);
      this.cmbComboBox.Name = "cmbComboBox";
      this.cmbComboBox.Size = new System.Drawing.Size(184, 21);
      this.cmbComboBox.TabIndex = 6;
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(11, 32);
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(184, 20);
      this.txtText.TabIndex = 5;
      this.txtText.Text = "";
      // 
      // frmRequiredFieldForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(336, 262);
      this.Controls.Add(this.cmdCancel);
      this.Controls.Add(this.cmdOK);
      this.Controls.Add(this.lstListBox);
      this.Controls.Add(this.cmbComboBox);
      this.Controls.Add(this.txtText);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmRequiredFieldForm";
      this.Text = "RequiredFieldBaseForm Tester";
      this.ResumeLayout(false);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmRequiredFieldForm'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmRequiredFieldForm()
      //***
      // Action
      //   - Create instance of 'frmRequiredFieldForm'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      //   - cpctlRequiredFieldForm.RequiredControls(Control[]) (Set)
      // Created
      //   - CopyPaste � 20250719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();

      Control[] arrControl = {this.txtText, this.cmbComboBox, this.lstListBox};
      this.RequiredControls = arrControl;
    }
    // frmRequiredFieldForm()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCancel_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Cause the validation is switched off
      //   - Close the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.CausesValidation = false;
      this.Close();
    }
    // cmdCancel_Click(System.Object, System.EventArgs) Handles cmdCancel.Click

    private void cmdOK_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Close the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // cmdOK_Click(System.Object, System.EventArgs) Handles cmdOK.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmRequiredFieldForm
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmRequiredFieldForm()
      // Created
      //   - CopyPaste � 20250719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmRequiredFieldForm());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmRequiredFieldForm

}
// CopyPaste.Learning