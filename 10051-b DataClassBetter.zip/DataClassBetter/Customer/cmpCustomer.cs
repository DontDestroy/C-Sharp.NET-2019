//***
// Action
//   - Customer Component
//   - This contains
//     - Customer connection (Connection string)
//     - Customer data adapter
// Created
//   - CopyPaste � 20050508 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20050508 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

namespace CopyPaste.Learning
{

  public class cmpCustomer : System.ComponentModel.Component
	{

    #region Component Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Data.SqlClient.SqlCommand cmmDeleteCustomer;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwindScript;
    internal System.Data.SqlClient.SqlCommand cmmUpdateCustomer;
    internal System.Data.SqlClient.SqlCommand cmmInsertCustomer;
    internal System.Data.SqlClient.SqlDataAdapter dtaCustomer;
    internal System.Data.SqlClient.SqlCommand cmmSelectCustomer;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cmpCustomer));
      this.cmmDeleteCustomer = new System.Data.SqlClient.SqlCommand();
      this.cnncpNorthwindScript = new System.Data.SqlClient.SqlConnection();
      this.cmmUpdateCustomer = new System.Data.SqlClient.SqlCommand();
      this.cmmInsertCustomer = new System.Data.SqlClient.SqlCommand();
      this.dtaCustomer = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectCustomer = new System.Data.SqlClient.SqlCommand();
      // 
      // cmmDeleteCustomer
      // 
      this.cmmDeleteCustomer.CommandText = resources.GetString("cmmDeleteCustomer.CommandText");
      this.cmmDeleteCustomer.Connection = this.cnncpNorthwindScript;
      this.cmmDeleteCustomer.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_strIdCustomer", System.Data.SqlDbType.VarChar, 5, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strIdCustomer", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strAddress", System.Data.SqlDbType.VarChar, 60, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCity", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCity", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCompanyName", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCompanyName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strContactName", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strContactName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strContactTitle", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strContactTitle", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCountry", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCountry", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strFax", System.Data.SqlDbType.VarChar, 24, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strFax", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strPhone", System.Data.SqlDbType.VarChar, 24, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strPhone", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strPostalCode", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strPostalCode", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strRegion", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strRegion", System.Data.DataRowVersion.Original, null)});
      // 
      // cnncpNorthwindScript
      // 
      this.cnncpNorthwindScript.ConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthwindScript.FireInfoMessageEventOnUserErrors = false;
      // 
      // cmmUpdateCustomer
      // 
      this.cmmUpdateCustomer.CommandText = resources.GetString("cmmUpdateCustomer.CommandText");
      this.cmmUpdateCustomer.Connection = this.cnncpNorthwindScript;
      this.cmmUpdateCustomer.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@strIdCustomer", System.Data.SqlDbType.VarChar, 5, "strIdCustomer"),
            new System.Data.SqlClient.SqlParameter("@strCompanyName", System.Data.SqlDbType.VarChar, 40, "strCompanyName"),
            new System.Data.SqlClient.SqlParameter("@strContactName", System.Data.SqlDbType.VarChar, 30, "strContactName"),
            new System.Data.SqlClient.SqlParameter("@strContactTitle", System.Data.SqlDbType.VarChar, 30, "strContactTitle"),
            new System.Data.SqlClient.SqlParameter("@strAddress", System.Data.SqlDbType.VarChar, 60, "strAddress"),
            new System.Data.SqlClient.SqlParameter("@strCity", System.Data.SqlDbType.VarChar, 15, "strCity"),
            new System.Data.SqlClient.SqlParameter("@strRegion", System.Data.SqlDbType.VarChar, 15, "strRegion"),
            new System.Data.SqlClient.SqlParameter("@strPostalCode", System.Data.SqlDbType.VarChar, 10, "strPostalCode"),
            new System.Data.SqlClient.SqlParameter("@strCountry", System.Data.SqlDbType.VarChar, 15, "strCountry"),
            new System.Data.SqlClient.SqlParameter("@strPhone", System.Data.SqlDbType.VarChar, 24, "strPhone"),
            new System.Data.SqlClient.SqlParameter("@strFax", System.Data.SqlDbType.VarChar, 24, "strFax"),
            new System.Data.SqlClient.SqlParameter("@Original_strIdCustomer", System.Data.SqlDbType.VarChar, 5, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strIdCustomer", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strAddress", System.Data.SqlDbType.VarChar, 60, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCity", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCity", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCompanyName", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCompanyName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strContactName", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strContactName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strContactTitle", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strContactTitle", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCountry", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCountry", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strFax", System.Data.SqlDbType.VarChar, 24, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strFax", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strPhone", System.Data.SqlDbType.VarChar, 24, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strPhone", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strPostalCode", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strPostalCode", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strRegion", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strRegion", System.Data.DataRowVersion.Original, null)});
      // 
      // cmmInsertCustomer
      // 
      this.cmmInsertCustomer.CommandText = resources.GetString("cmmInsertCustomer.CommandText");
      this.cmmInsertCustomer.Connection = this.cnncpNorthwindScript;
      this.cmmInsertCustomer.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@strIdCustomer", System.Data.SqlDbType.VarChar, 5, "strIdCustomer"),
            new System.Data.SqlClient.SqlParameter("@strCompanyName", System.Data.SqlDbType.VarChar, 40, "strCompanyName"),
            new System.Data.SqlClient.SqlParameter("@strContactName", System.Data.SqlDbType.VarChar, 30, "strContactName"),
            new System.Data.SqlClient.SqlParameter("@strContactTitle", System.Data.SqlDbType.VarChar, 30, "strContactTitle"),
            new System.Data.SqlClient.SqlParameter("@strAddress", System.Data.SqlDbType.VarChar, 60, "strAddress"),
            new System.Data.SqlClient.SqlParameter("@strCity", System.Data.SqlDbType.VarChar, 15, "strCity"),
            new System.Data.SqlClient.SqlParameter("@strRegion", System.Data.SqlDbType.VarChar, 15, "strRegion"),
            new System.Data.SqlClient.SqlParameter("@strPostalCode", System.Data.SqlDbType.VarChar, 10, "strPostalCode"),
            new System.Data.SqlClient.SqlParameter("@strCountry", System.Data.SqlDbType.VarChar, 15, "strCountry"),
            new System.Data.SqlClient.SqlParameter("@strPhone", System.Data.SqlDbType.VarChar, 24, "strPhone"),
            new System.Data.SqlClient.SqlParameter("@strFax", System.Data.SqlDbType.VarChar, 24, "strFax")});
      // 
      // dtaCustomer
      // 
      this.dtaCustomer.DeleteCommand = this.cmmDeleteCustomer;
      this.dtaCustomer.InsertCommand = this.cmmInsertCustomer;
      this.dtaCustomer.SelectCommand = this.cmmSelectCustomer;
      this.dtaCustomer.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCustomer", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("strIdCustomer", "strIdCustomer"),
                        new System.Data.Common.DataColumnMapping("strCompanyName", "strCompanyName"),
                        new System.Data.Common.DataColumnMapping("strContactName", "strContactName"),
                        new System.Data.Common.DataColumnMapping("strContactTitle", "strContactTitle"),
                        new System.Data.Common.DataColumnMapping("strAddress", "strAddress"),
                        new System.Data.Common.DataColumnMapping("strCity", "strCity"),
                        new System.Data.Common.DataColumnMapping("strRegion", "strRegion"),
                        new System.Data.Common.DataColumnMapping("strPostalCode", "strPostalCode"),
                        new System.Data.Common.DataColumnMapping("strCountry", "strCountry"),
                        new System.Data.Common.DataColumnMapping("strPhone", "strPhone"),
                        new System.Data.Common.DataColumnMapping("strFax", "strFax")})});
      this.dtaCustomer.UpdateCommand = this.cmmUpdateCustomer;
      // 
      // cmmSelectCustomer
      // 
      this.cmmSelectCustomer.CommandText = resources.GetString("cmmSelectCustomer.CommandText");
      this.cmmSelectCustomer.Connection = this.cnncpNorthwindScript;
      this.cmmSelectCustomer.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@KeyCustomer", System.Data.SqlDbType.VarChar, 5, "strIdCustomer")});

    }
    #endregion

    #region "Constructors / Destructors"
    
    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cmpCustomer'
      // Called by
      //   - User action (Closing the component)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cmpCustomer()
      //***
      // Action
      //   - Create new instance of 'cmpCustomer'
      // Called by
      //   - cmpCustomer(System.ComponentModel.IContainer)
      //   - User action (Starting the component)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
    }
    // cmpCustomer()

		public cmpCustomer(System.ComponentModel.IContainer container) : this()
      //***
      // Action
      //   - Create new instance of 'cmpCustomer' (inside a container)
      //   - Add the component to the container
      // Called by
      //   - User action (Starting the component)
      // Calls
      //   - cmpCustomer()
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
			container.Add(this);
		}
    // cmpCustomer(System.ComponentModel.IContainer) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cmpCustomer

}
// CopyPaste.Learning