﻿//***
// Action
//   - A visualisation of a cpNetwork
// Created
//   - CopyPaste – 20230614 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230614 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.TelecomNetwork
{
  partial class frmNetwork
  {

    #region Windows Form Designer generated code

    private System.Windows.Forms.Label lblAddToNetWork;
    private System.Windows.Forms.Label lblWarning;
    private System.Windows.Forms.TextBox txtNumber;
    private System.Windows.Forms.Label lblNumber;
    private System.Windows.Forms.TextBox txtName;
    private System.Windows.Forms.Label lblName;
    private System.Windows.Forms.Button cmdShowPhone;
    private System.Windows.Forms.Button cmdCreate;
    private System.Windows.Forms.Label lblFind;
    private System.Windows.Forms.TextBox txtFind;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.ComboBox cmbPhone;

    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNetwork));
      this.lblFind = new System.Windows.Forms.Label();
      this.txtFind = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.cmbPhone = new System.Windows.Forms.ComboBox();
      this.lblAddToNetWork = new System.Windows.Forms.Label();
      this.lblWarning = new System.Windows.Forms.Label();
      this.txtNumber = new System.Windows.Forms.TextBox();
      this.lblNumber = new System.Windows.Forms.Label();
      this.txtName = new System.Windows.Forms.TextBox();
      this.lblName = new System.Windows.Forms.Label();
      this.cmdShowPhone = new System.Windows.Forms.Button();
      this.cmdCreate = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // lblFind
      // 
      this.lblFind.AutoSize = true;
      this.lblFind.Location = new System.Drawing.Point(22, 9);
      this.lblFind.Name = "lblFind";
      this.lblFind.Size = new System.Drawing.Size(175, 15);
      this.lblFind.TabIndex = 0;
      this.lblFind.Text = "Find phone by number or name";
      // 
      // txtFind
      // 
      this.txtFind.Location = new System.Drawing.Point(216, 6);
      this.txtFind.Name = "txtFind";
      this.txtFind.Size = new System.Drawing.Size(156, 23);
      this.txtFind.TabIndex = 1;
      this.txtFind.TextChanged += new System.EventHandler(this.txtFind_TextChanged);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(22, 40);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(130, 15);
      this.label1.TabIndex = 2;
      this.label1.Text = "List of available phones";
      // 
      // cmbPhone
      // 
      this.cmbPhone.FormattingEnabled = true;
      this.cmbPhone.Location = new System.Drawing.Point(216, 37);
      this.cmbPhone.Name = "cmbPhone";
      this.cmbPhone.Size = new System.Drawing.Size(156, 23);
      this.cmbPhone.TabIndex = 3;
      // 
      // lblAddToNetWork
      // 
      this.lblAddToNetWork.AutoEllipsis = true;
      this.lblAddToNetWork.AutoSize = true;
      this.lblAddToNetWork.Location = new System.Drawing.Point(22, 92);
      this.lblAddToNetWork.Name = "lblAddToNetWork";
      this.lblAddToNetWork.Size = new System.Drawing.Size(185, 15);
      this.lblAddToNetWork.TabIndex = 4;
      this.lblAddToNetWork.Text = "Fill to add a phone to the network";
      // 
      // lblWarning
      // 
      this.lblWarning.AutoSize = true;
      this.lblWarning.Location = new System.Drawing.Point(40, 111);
      this.lblWarning.Name = "lblWarning";
      this.lblWarning.Size = new System.Drawing.Size(352, 15);
      this.lblWarning.TabIndex = 5;
      this.lblWarning.Text = "(there is no check on duplicated phonenumbers, first found wins)";
      // 
      // txtNumber
      // 
      this.txtNumber.Location = new System.Drawing.Point(216, 149);
      this.txtNumber.Name = "txtNumber";
      this.txtNumber.Size = new System.Drawing.Size(156, 23);
      this.txtNumber.TabIndex = 7;
      // 
      // lblNumber
      // 
      this.lblNumber.AutoSize = true;
      this.lblNumber.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.lblNumber.Location = new System.Drawing.Point(111, 152);
      this.lblNumber.Name = "lblNumber";
      this.lblNumber.Size = new System.Drawing.Size(89, 15);
      this.lblNumber.TabIndex = 6;
      this.lblNumber.Text = "Phone number:";
      // 
      // txtName
      // 
      this.txtName.Location = new System.Drawing.Point(216, 178);
      this.txtName.Name = "txtName";
      this.txtName.Size = new System.Drawing.Size(156, 23);
      this.txtName.TabIndex = 9;
      // 
      // lblName
      // 
      this.lblName.AutoSize = true;
      this.lblName.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
      this.lblName.Location = new System.Drawing.Point(155, 181);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(42, 15);
      this.lblName.TabIndex = 8;
      this.lblName.Text = "Name:";
      // 
      // cmdShowPhone
      // 
      this.cmdShowPhone.Location = new System.Drawing.Point(391, 40);
      this.cmdShowPhone.Name = "cmdShowPhone";
      this.cmdShowPhone.Size = new System.Drawing.Size(92, 23);
      this.cmdShowPhone.TabIndex = 10;
      this.cmdShowPhone.Text = "Show Phone";
      this.cmdShowPhone.UseVisualStyleBackColor = true;
      this.cmdShowPhone.Click += new System.EventHandler(this.cmdShowPhone_Click);
      // 
      // cmdCreate
      // 
      this.cmdCreate.Location = new System.Drawing.Point(391, 178);
      this.cmdCreate.Name = "cmdCreate";
      this.cmdCreate.Size = new System.Drawing.Size(92, 23);
      this.cmdCreate.TabIndex = 11;
      this.cmdCreate.Text = "Create Phone";
      this.cmdCreate.UseVisualStyleBackColor = true;
      this.cmdCreate.Click += new System.EventHandler(this.cmdCreate_Click);
      // 
      // frmNetwork
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(529, 236);
      this.Controls.Add(this.cmdCreate);
      this.Controls.Add(this.cmdShowPhone);
      this.Controls.Add(this.txtName);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.txtNumber);
      this.Controls.Add(this.lblNumber);
      this.Controls.Add(this.lblWarning);
      this.Controls.Add(this.lblAddToNetWork);
      this.Controls.Add(this.cmbPhone);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.txtFind);
      this.Controls.Add(this.lblFind);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmNetwork";
      this.Text = "Network";
      this.Load += new System.EventHandler(this.frmNetwork_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmNetWork'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null)
        {
        }
        else
        // (components != null)
        {
          components.Dispose();
        }
        // (components == null)

      }
      else
      // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmNetwork

}
// CopyPaste.TelecomNetwork