//***
// Action
//   - Define a cpTime (an hour, a minute and a second)
//   - A constructor
// Created
//   - CopyPaste � 20220411 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220411 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Toolkit
{

  public class cpTime
	{

    #region "Constructors / Destructors"

    public cpTime(int mlngHour, int mlngMinute, int mlngSecond)
      //***
      // Action
      //   - Create a instance of cpTime
      //   - Define the hours, minutes and seconds
      // Called by
      //   - cpProgram.Main();
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      this.mlngHour = mlngHour;
      this.mlngMinute = mlngMinute;
      this.mlngSecond = mlngSecond;
    }
    // cpTime(int, int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mlngHour;
    private int mlngMinute;
    private int mlngSecond;

    #endregion
    
    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string BuildString()
      //***
      // Action
      //   - Return this.ToUniversalString() and ToUniversalString()
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - string ToUniversalString()
      // Created
      //   - CopyPaste � 20220411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "this.ToUniversalString(): " + this.ToUniversalString() + "\nToUniversalString(): " + ToUniversalString();
    }
    // string BuildString()

    public string ToUniversalString()
      //***
      // Action
      //   - Return Time in hours, minutes and seconds all in a 2-digit format
      // Called by
      //   - string BuildString()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return String.Format("{0:D2}:{1:D2}:{2:D2}", mlngHour, mlngMinute, mlngSecond);
    }
    // string ToUniversalString()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpTime

}
// CopyPaste.Learning.Toolkit