﻿//***
// Action
//   - ProductCategory class (in Models)
// Created
//   - CopyPaste – 20220824 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220824 – VVDW
// Proposal (To Do)
//   -
//***

using ProductCategory_WPF_MVVM.Utilities;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProductCategory_WPF_MVVM.Models
{
  public class ProductCategory : ObservableObject
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // ProductCategory

}
// ProductCategory_WPF_MVVM.Models