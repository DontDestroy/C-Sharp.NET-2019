﻿//***
// Action
//   - Implementation of cpMultiplication
// Created
//   - CopyPaste – 20260128 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260128 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpMultiplication: cpCalculation 
  {

    #region "Constructors / Destructors"

    public cpMultiplication() : this(1, 1)
    //***
    // Action
    //   - Basic constructor with no parameters
    // Called by
    //   - 
    // Calls
    //   - cpMultiplication(int, int)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpMultiplication()

    public cpMultiplication(int intFirstValue, int intSecondValue)
    //***
    // Action
    //   - Basic constructor with 2 parameters
    // Called by
    //   - cpMultiplication()
    //   - cpProgram.Main()
    // Calls
    //   - FirstValue(int) (Set)
    //   - SecondValue(int) (Set)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      FirstValue = intFirstValue;
      SecondValue = intSecondValue;
    }
    // cpMultiplication(int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public override int FirstValue
    {
      
      get
      //***
      // Action Get
      //   - Return _firstValue
      // Called by
      //   - int Calculate()
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        return _firstValue;
      }
      // int FirstValue (Get)

      set
      //***
      // Action Set
      //   - _firstValue becomes value
      // Called by
      //   - cpMultiplication(int, int)
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        _firstValue = value;
      }
      // FirstValue(int) (Set)

    }
    // int FirstValue

    public override int SecondValue
    {

      get
      //***
      // Action Get
      //   - Return _secondValue
      // Called by
      //   - int Calculate()
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        return _secondValue;
      }
      // int SecondValue (Get)

      set
      //***
      // Action Set
      //   - _secondValue becomes value
      // Called by
      //   - cpMultiplication(int, int)
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        _secondValue = value;
      }
      // FirstValue(int) (Set)

    }
    // int FirstValue

    #endregion

    #region "Methods"

    #region "Overrides"

    public override int Calculate()
    //***
    // Action
    //   - Return the multiplication of two values
    // Called by
    //   - cpProgram.Main() (Thru inheritance)
    // Calls
    //   - int FirstValue (Get)
    //   - int SecondValue (Get)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      int intResult;

      intResult = FirstValue * SecondValue;
      return intResult;
    }
    // int Calculate()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpMultiplication

}
// CopyPaste.Learning