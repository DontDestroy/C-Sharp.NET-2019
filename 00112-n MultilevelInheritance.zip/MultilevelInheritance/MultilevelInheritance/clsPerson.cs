//***
// Action
//   - Implementation of a cpPerson
// Created
//   - CopyPaste � 20240529 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240529 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpPerson
  {

    #region "Constructors / Destructors"

    public cpPerson(string strName, int lngAge)
      //***
      // Action
      //   - Create an instance of cpPerson
      // Called by
      //   - cpAthlete(string, int, string, string)
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mlngAge = lngAge;
      mstrName = strName;
    }
    // cpPerson(string, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public int mlngAge;
    public string mstrName;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Returns information about a cpPerson
      // Called by
      //   - cpProgram.Main()
      //   - string cpAthlete.ToString()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strResult;

      strResult = "Name: " + mstrName + Environment.NewLine;
      strResult += "Age: " + mlngAge + Environment.NewLine;

      return strResult;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPerson

}
// CopyPaste.Learning