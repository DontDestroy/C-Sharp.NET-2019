﻿//***
// Action
//   - Interface of a Strategy
// Created
//   - CopyPaste – 20251028 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251028 – VVDW
// Proposal (To Do)
//   -
//***

using kareltherobot;

namespace cpKarelTheRobot
{

	public interface cpinfStrategy
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		void DoIt(cpCopyPasteRobot aRobot);
    //***
    // Action
    //   - Functionality with name DoIt that will be executed
    //     - The parameter aRobot is the robot that must do something
    // Called by
    //   - cpBlockWalker.WalkASide()
    //   - cpSpyRobot.FollowStrategy()
    //   - cpStrategyBeeperLayer.PutBeepers()
    //   - cpStrategyBeeperLayerAlternative.PutBeepers()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpinfStrategy

}
// cpKarelTheRobot