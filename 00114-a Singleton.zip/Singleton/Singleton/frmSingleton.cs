//***
// Action
//   - Testroutine for the class cpSingleton
//   - Prove that there is only one instance of the class
// Created
//   - CopyPaste � 20240402 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240402 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSingleton: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdAddString;
    internal System.Windows.Forms.TextBox txtNew;
    internal System.Windows.Forms.ListBox lstTwo;
    internal System.Windows.Forms.ListBox lstOne;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSingleton));
      this.cmdAddString = new System.Windows.Forms.Button();
      this.txtNew = new System.Windows.Forms.TextBox();
      this.lstTwo = new System.Windows.Forms.ListBox();
      this.lstOne = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // cmdAddString
      // 
      this.cmdAddString.Location = new System.Drawing.Point(154, 151);
      this.cmdAddString.Name = "cmdAddString";
      this.cmdAddString.TabIndex = 7;
      this.cmdAddString.Text = "Add String";
      this.cmdAddString.Click += new System.EventHandler(this.cmdAddString_Click);
      // 
      // txtNew
      // 
      this.txtNew.Location = new System.Drawing.Point(18, 151);
      this.txtNew.Name = "txtNew";
      this.txtNew.Size = new System.Drawing.Size(120, 20);
      this.txtNew.TabIndex = 6;
      this.txtNew.Text = "";
      // 
      // lstTwo
      // 
      this.lstTwo.Location = new System.Drawing.Point(154, 23);
      this.lstTwo.Name = "lstTwo";
      this.lstTwo.Size = new System.Drawing.Size(120, 95);
      this.lstTwo.TabIndex = 5;
      // 
      // lstOne
      // 
      this.lstOne.Location = new System.Drawing.Point(18, 23);
      this.lstOne.Name = "lstOne";
      this.lstOne.Size = new System.Drawing.Size(120, 95);
      this.lstOne.TabIndex = 4;
      // 
      // frmSingleton
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 197);
      this.Controls.Add(this.cmdAddString);
      this.Controls.Add(this.txtNew);
      this.Controls.Add(this.lstTwo);
      this.Controls.Add(this.lstOne);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSingleton";
      this.Text = "Test clsSingleton";
      this.Load += new System.EventHandler(this.frmSingleton_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSingleton'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSingleton()
      //***
      // Action
      //   - Create instance of 'frmSingleton'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSingleton()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    cpSingleton mcpSingletonOne;
    cpSingleton mcpSingletonTwo;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdAddString_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - A string is added to mcpSingletonOne
      //   - The datasource of lstOne is removed
      //   - The list is cleared
      //   - lstOne becomes the list of mcpSingletonOne
      //   - The datasource of lstTwo is removed
      //   - The list is cleared
      //   - lstTwo becomes the list of mcpSingletonTwo
      //   - Whatever happens the lists stay the same, to prove it is a singleton (only one instance exists)
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpSingleton.AddString(string)
      //   - string[] cpSingleton.GetStrings()
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpSingletonOne.AddString(txtNew.Text);
      lstOne.DataSource = null;
      lstOne.Items.Clear();
      lstOne.DataSource = mcpSingletonOne.GetStrings();
      lstTwo.DataSource = null;
      lstTwo.Items.Clear();
      lstTwo.DataSource = mcpSingletonTwo.GetStrings();   
    }
    // cmdAddString_Click(System.Object, System.EventArgs) Handles cmdAddString.Click

    private void frmSingleton_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Use GetInstance() twice to fill 2 variables
      //   - The first execution will create the instance and return it
      //   - The second execution will return the same instance
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpSingleton cpSingleton.GetInstance() 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpSingletonOne = cpSingleton.GetInstance();
      mcpSingletonTwo = cpSingleton.GetInstance();
    }
    // frmSingleton_Load(System.Object, System.EventArgs) Handles this.Load
  
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSingleton
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSingleton());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSingleton

}
// CopyPaste.Learning