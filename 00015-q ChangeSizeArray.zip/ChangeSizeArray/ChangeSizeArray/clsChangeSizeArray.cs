//***
// Action
//   - Asking the names of sellers, until you type "stop"
//   - Add the typed name in an array
//   - Loop thru the sellers
//     - Show the names in the console
// Created
//   - CopyPaste � 20220216 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220216 � VVDW
// Proposal (To Do)
//   - Leap years are not taken into account
//***

using System;

namespace ChangeSizeArray
{

  class cpChangeSizeArray
	{

    static void Main()
      //***
      // Action
      //   - Loop asking name of seller
      //   - Add name to an array
      //   - If name equals "stop"
      //     - exit loop
      //   - If Not
      //     - adapt the counter
      //   - If there are items
      //     - Loop thru the items
      //       - Write name on the console
      //   - If Not
      //     - Do nothing
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Console.Write(string)
      //   - Console.WriteLine()
      //   - Console.WriteLine(string)
      //   - int Array.GetUpperBound(int)
      //   - string Console.ReadLine()
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int intCounter = 0;
      string[] arrstrSeller = new string[0];
      string strNewSeller;

      do
      {
        Console.Write("Enter the name of a seller. (End with stop): ");
        strNewSeller = Console.ReadLine();
        
        if (strNewSeller == "stop")
        {
        }
        else
        {
          // strNewSeller <> "stop"
          intCounter++;
          Array.Resize(ref arrstrSeller, intCounter);
          arrstrSeller[intCounter - 1] = strNewSeller;
        }
        // strNewSeller = "stop"

      }
      while (strNewSeller != "stop");
      // strNewSeller = "stop"

      Console.WriteLine();

      if (arrstrSeller.GetUpperBound(0) == 0)
      {
      }
      else
        // arrstrSeller.GetUpperBound(0) <> 0
      {

        foreach (string aSeller in arrstrSeller)
        {
          Console.WriteLine(aSeller);
        }
        // in arrstrSeller
      
      }
      // arrstrSeller.GetUpperBound(0) = 0

      Console.WriteLine();
      Console.ReadLine();
		}
    // Main()

	}
  // cpChangeSizeArray

}
// ChangeSizeArray