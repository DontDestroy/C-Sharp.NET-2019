﻿//***
// Action
//   - Demo of a Calendar Web Control
// Created
//   - CopyPaste – 20260528 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260528 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmCalendar : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.calSelectDay.SelectionChanged += new System.EventHandler(this.calSelectDay_SelectionChanged);
      this.ID = "wfrmCalendar";
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when initializing the page
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260528 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260528 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void calSelectDay_SelectionChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - The selected date on the calendar is shown in day/month/year format on the form
    // Called by
    //   - Page_Load(System.Object, System.EventArgs) Handles this.Load
    //   - User action (Selecting a date)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260528 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260528 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lblSelectedDay.Text = calSelectDay.SelectedDate.ToString("dd/MM/yyyy");
    }
    // calSelectDay_SelectionChanged(System.Object, System.EventArgs) Handles calSelectDay.SelectionChanged

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when the page is loaded
    //   - By default today is selected in the calendar
    //   - Text of selected day is shown
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - calSelectDay_SelectionChanged(System.Object, System.EventArgs) Handles calSelectDay.SelectionChanged
    // Created
    //   - CopyPaste – 20260528 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260528 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      calSelectDay.SelectedDate = DateTime.Today;
      calSelectDay_SelectionChanged(theSender, theEventArguments);
    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmCalendar

}
// CopyPaste.Learning