//***
// Action
//   - Demo form with a Menu and Toolbar
// Created
//   - CopyPaste � 20260701 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260701 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMenuAndToolbar : System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    private MenuStrip mnuStrip;
    private ToolStripMenuItem fileToolStripMenuItem;
    private ToolStripMenuItem mnuFileNew;
    private ToolStripMenuItem mnuFileOpen;
    private ToolStripSeparator toolStripSeparator;
    private ToolStripMenuItem mnuFileSave;
    private ToolStripMenuItem saveAsToolStripMenuItem;
    private ToolStripSeparator toolStripSeparator1;
    private ToolStripMenuItem printToolStripMenuItem;
    private ToolStripMenuItem printPreviewToolStripMenuItem;
    private ToolStripSeparator toolStripSeparator2;
    private ToolStripMenuItem exitToolStripMenuItem;
    private ToolStripMenuItem editToolStripMenuItem;
    private ToolStripMenuItem undoToolStripMenuItem;
    private ToolStripMenuItem redoToolStripMenuItem;
    private ToolStripSeparator toolStripSeparator3;
    private ToolStripMenuItem cutToolStripMenuItem;
    private ToolStripMenuItem copyToolStripMenuItem;
    private ToolStripMenuItem pasteToolStripMenuItem;
    private ToolStripSeparator toolStripSeparator4;
    private ToolStripMenuItem selectAllToolStripMenuItem;
    private ToolStripMenuItem toolsToolStripMenuItem;
    private ToolStripMenuItem customizeToolStripMenuItem;
    private ToolStripMenuItem optionsToolStripMenuItem;
    private ToolStripMenuItem helpToolStripMenuItem;
    private ToolStripMenuItem contentsToolStripMenuItem;
    private ToolStripMenuItem indexToolStripMenuItem;
    private ToolStripMenuItem searchToolStripMenuItem;
    private ToolStripSeparator toolStripSeparator5;
    private ToolStripMenuItem aboutToolStripMenuItem;
    private ToolStrip tlbStrip;
    private ToolStripButton cmdFileNew;
    private ToolStripButton cmdFileOpen;
    private ToolStripButton cmdFileSave;
    private ToolStripButton printToolStripButton;
    private ToolStripSeparator toolStripSeparator6;
    private ToolStripButton cutToolStripButton;
    private ToolStripButton copyToolStripButton;
    private ToolStripButton pasteToolStripButton;
    private ToolStripSeparator toolStripSeparator7;
    private ToolStripButton helpToolStripButton;
    private StatusStrip stbStrip;
    private RichTextBox rtxtText;
    private OpenFileDialog dlgFileOpen;
    private SaveFileDialog dlgFileSave;
    private ToolStripStatusLabel tssblStatus;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMenuAndToolbar));
      this.mnuStrip = new System.Windows.Forms.MenuStrip();
      this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.mnuFileNew = new System.Windows.Forms.ToolStripMenuItem();
      this.mnuFileOpen = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
      this.mnuFileSave = new System.Windows.Forms.ToolStripMenuItem();
      this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
      this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.redoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
      this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
      this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.customizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.contentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.indexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
      this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.tlbStrip = new System.Windows.Forms.ToolStrip();
      this.cmdFileNew = new System.Windows.Forms.ToolStripButton();
      this.cmdFileOpen = new System.Windows.Forms.ToolStripButton();
      this.cmdFileSave = new System.Windows.Forms.ToolStripButton();
      this.printToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
      this.cutToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.copyToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.pasteToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
      this.helpToolStripButton = new System.Windows.Forms.ToolStripButton();
      this.stbStrip = new System.Windows.Forms.StatusStrip();
      this.tssblStatus = new System.Windows.Forms.ToolStripStatusLabel();
      this.rtxtText = new System.Windows.Forms.RichTextBox();
      this.dlgFileOpen = new System.Windows.Forms.OpenFileDialog();
      this.dlgFileSave = new System.Windows.Forms.SaveFileDialog();
      this.mnuStrip.SuspendLayout();
      this.tlbStrip.SuspendLayout();
      this.stbStrip.SuspendLayout();
      this.SuspendLayout();
      // 
      // mnuStrip
      // 
      this.mnuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.helpToolStripMenuItem});
      this.mnuStrip.Location = new System.Drawing.Point(0, 0);
      this.mnuStrip.Name = "mnuStrip";
      this.mnuStrip.Size = new System.Drawing.Size(292, 24);
      this.mnuStrip.TabIndex = 0;
      this.mnuStrip.Text = "mnuStrip";
      // 
      // fileToolStripMenuItem
      // 
      this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFileNew,
            this.mnuFileOpen,
            this.toolStripSeparator,
            this.mnuFileSave,
            this.saveAsToolStripMenuItem,
            this.toolStripSeparator1,
            this.printToolStripMenuItem,
            this.printPreviewToolStripMenuItem,
            this.toolStripSeparator2,
            this.exitToolStripMenuItem});
      this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
      this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
      this.fileToolStripMenuItem.Text = "&File";
      // 
      // mnuFileNew
      // 
      this.mnuFileNew.Image = ((System.Drawing.Image)(resources.GetObject("mnuFileNew.Image")));
      this.mnuFileNew.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.mnuFileNew.Name = "mnuFileNew";
      this.mnuFileNew.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
      this.mnuFileNew.Size = new System.Drawing.Size(180, 22);
      this.mnuFileNew.Text = "&New";
      this.mnuFileNew.Click += new System.EventHandler(this.mnuFileNew_Click);
      // 
      // mnuFileOpen
      // 
      this.mnuFileOpen.Image = ((System.Drawing.Image)(resources.GetObject("mnuFileOpen.Image")));
      this.mnuFileOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.mnuFileOpen.Name = "mnuFileOpen";
      this.mnuFileOpen.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
      this.mnuFileOpen.Size = new System.Drawing.Size(180, 22);
      this.mnuFileOpen.Text = "&Open";
      this.mnuFileOpen.Click += new System.EventHandler(this.mnuFileOpen_Click);
      // 
      // toolStripSeparator
      // 
      this.toolStripSeparator.Name = "toolStripSeparator";
      this.toolStripSeparator.Size = new System.Drawing.Size(177, 6);
      // 
      // mnuFileSave
      // 
      this.mnuFileSave.Image = ((System.Drawing.Image)(resources.GetObject("mnuFileSave.Image")));
      this.mnuFileSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.mnuFileSave.Name = "mnuFileSave";
      this.mnuFileSave.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
      this.mnuFileSave.Size = new System.Drawing.Size(180, 22);
      this.mnuFileSave.Text = "&Save";
      this.mnuFileSave.Click += new System.EventHandler(this.cmdFileSave_Click);
      // 
      // saveAsToolStripMenuItem
      // 
      this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
      this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
      this.saveAsToolStripMenuItem.Text = "Save &As";
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      this.toolStripSeparator1.Size = new System.Drawing.Size(177, 6);
      // 
      // printToolStripMenuItem
      // 
      this.printToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripMenuItem.Image")));
      this.printToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.printToolStripMenuItem.Name = "printToolStripMenuItem";
      this.printToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
      this.printToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
      this.printToolStripMenuItem.Text = "&Print";
      // 
      // printPreviewToolStripMenuItem
      // 
      this.printPreviewToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printPreviewToolStripMenuItem.Image")));
      this.printPreviewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
      this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
      this.printPreviewToolStripMenuItem.Text = "Print Pre&view";
      // 
      // toolStripSeparator2
      // 
      this.toolStripSeparator2.Name = "toolStripSeparator2";
      this.toolStripSeparator2.Size = new System.Drawing.Size(177, 6);
      // 
      // exitToolStripMenuItem
      // 
      this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
      this.exitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
      this.exitToolStripMenuItem.Text = "E&xit";
      // 
      // editToolStripMenuItem
      // 
      this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoToolStripMenuItem,
            this.redoToolStripMenuItem,
            this.toolStripSeparator3,
            this.cutToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.toolStripSeparator4,
            this.selectAllToolStripMenuItem});
      this.editToolStripMenuItem.Name = "editToolStripMenuItem";
      this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
      this.editToolStripMenuItem.Text = "&Edit";
      // 
      // undoToolStripMenuItem
      // 
      this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
      this.undoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
      this.undoToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
      this.undoToolStripMenuItem.Text = "&Undo";
      // 
      // redoToolStripMenuItem
      // 
      this.redoToolStripMenuItem.Name = "redoToolStripMenuItem";
      this.redoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y)));
      this.redoToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
      this.redoToolStripMenuItem.Text = "&Redo";
      // 
      // toolStripSeparator3
      // 
      this.toolStripSeparator3.Name = "toolStripSeparator3";
      this.toolStripSeparator3.Size = new System.Drawing.Size(141, 6);
      // 
      // cutToolStripMenuItem
      // 
      this.cutToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripMenuItem.Image")));
      this.cutToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
      this.cutToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
      this.cutToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
      this.cutToolStripMenuItem.Text = "Cu&t";
      // 
      // copyToolStripMenuItem
      // 
      this.copyToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripMenuItem.Image")));
      this.copyToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
      this.copyToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
      this.copyToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
      this.copyToolStripMenuItem.Text = "&Copy";
      // 
      // pasteToolStripMenuItem
      // 
      this.pasteToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripMenuItem.Image")));
      this.pasteToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
      this.pasteToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
      this.pasteToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
      this.pasteToolStripMenuItem.Text = "&Paste";
      // 
      // toolStripSeparator4
      // 
      this.toolStripSeparator4.Name = "toolStripSeparator4";
      this.toolStripSeparator4.Size = new System.Drawing.Size(141, 6);
      // 
      // selectAllToolStripMenuItem
      // 
      this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
      this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
      this.selectAllToolStripMenuItem.Text = "Select &All";
      // 
      // toolsToolStripMenuItem
      // 
      this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customizeToolStripMenuItem,
            this.optionsToolStripMenuItem});
      this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
      this.toolsToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
      this.toolsToolStripMenuItem.Text = "&Tools";
      // 
      // customizeToolStripMenuItem
      // 
      this.customizeToolStripMenuItem.Name = "customizeToolStripMenuItem";
      this.customizeToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
      this.customizeToolStripMenuItem.Text = "&Customize";
      // 
      // optionsToolStripMenuItem
      // 
      this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
      this.optionsToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
      this.optionsToolStripMenuItem.Text = "&Options";
      // 
      // helpToolStripMenuItem
      // 
      this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contentsToolStripMenuItem,
            this.indexToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.toolStripSeparator5,
            this.aboutToolStripMenuItem});
      this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
      this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
      this.helpToolStripMenuItem.Text = "&Help";
      // 
      // contentsToolStripMenuItem
      // 
      this.contentsToolStripMenuItem.Name = "contentsToolStripMenuItem";
      this.contentsToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
      this.contentsToolStripMenuItem.Text = "&Contents";
      // 
      // indexToolStripMenuItem
      // 
      this.indexToolStripMenuItem.Name = "indexToolStripMenuItem";
      this.indexToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
      this.indexToolStripMenuItem.Text = "&Index";
      // 
      // searchToolStripMenuItem
      // 
      this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
      this.searchToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
      this.searchToolStripMenuItem.Text = "&Search";
      // 
      // toolStripSeparator5
      // 
      this.toolStripSeparator5.Name = "toolStripSeparator5";
      this.toolStripSeparator5.Size = new System.Drawing.Size(119, 6);
      // 
      // aboutToolStripMenuItem
      // 
      this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
      this.aboutToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
      this.aboutToolStripMenuItem.Text = "&About...";
      // 
      // tlbStrip
      // 
      this.tlbStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmdFileNew,
            this.cmdFileOpen,
            this.cmdFileSave,
            this.printToolStripButton,
            this.toolStripSeparator6,
            this.cutToolStripButton,
            this.copyToolStripButton,
            this.pasteToolStripButton,
            this.toolStripSeparator7,
            this.helpToolStripButton});
      this.tlbStrip.Location = new System.Drawing.Point(0, 24);
      this.tlbStrip.Name = "tlbStrip";
      this.tlbStrip.Size = new System.Drawing.Size(292, 25);
      this.tlbStrip.TabIndex = 1;
      this.tlbStrip.Text = "tlbStrip";
      // 
      // cmdFileNew
      // 
      this.cmdFileNew.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.cmdFileNew.Image = ((System.Drawing.Image)(resources.GetObject("cmdFileNew.Image")));
      this.cmdFileNew.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.cmdFileNew.Name = "cmdFileNew";
      this.cmdFileNew.Size = new System.Drawing.Size(23, 22);
      this.cmdFileNew.Text = "&New";
      this.cmdFileNew.Click += new System.EventHandler(this.cmdFileNew_Click);
      // 
      // cmdFileOpen
      // 
      this.cmdFileOpen.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.cmdFileOpen.Image = ((System.Drawing.Image)(resources.GetObject("cmdFileOpen.Image")));
      this.cmdFileOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.cmdFileOpen.Name = "cmdFileOpen";
      this.cmdFileOpen.Size = new System.Drawing.Size(23, 22);
      this.cmdFileOpen.Text = "&Open";
      this.cmdFileOpen.Click += new System.EventHandler(this.cmdFileOpen_Click);
      // 
      // cmdFileSave
      // 
      this.cmdFileSave.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.cmdFileSave.Image = ((System.Drawing.Image)(resources.GetObject("cmdFileSave.Image")));
      this.cmdFileSave.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.cmdFileSave.Name = "cmdFileSave";
      this.cmdFileSave.Size = new System.Drawing.Size(23, 22);
      this.cmdFileSave.Text = "&Save";
      this.cmdFileSave.Click += new System.EventHandler(this.cmdFileSave_Click);
      // 
      // printToolStripButton
      // 
      this.printToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.printToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("printToolStripButton.Image")));
      this.printToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.printToolStripButton.Name = "printToolStripButton";
      this.printToolStripButton.Size = new System.Drawing.Size(23, 22);
      this.printToolStripButton.Text = "&Print";
      // 
      // toolStripSeparator6
      // 
      this.toolStripSeparator6.Name = "toolStripSeparator6";
      this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
      // 
      // cutToolStripButton
      // 
      this.cutToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.cutToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("cutToolStripButton.Image")));
      this.cutToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.cutToolStripButton.Name = "cutToolStripButton";
      this.cutToolStripButton.Size = new System.Drawing.Size(23, 22);
      this.cutToolStripButton.Text = "C&ut";
      // 
      // copyToolStripButton
      // 
      this.copyToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.copyToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("copyToolStripButton.Image")));
      this.copyToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.copyToolStripButton.Name = "copyToolStripButton";
      this.copyToolStripButton.Size = new System.Drawing.Size(23, 22);
      this.copyToolStripButton.Text = "&Copy";
      // 
      // pasteToolStripButton
      // 
      this.pasteToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.pasteToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("pasteToolStripButton.Image")));
      this.pasteToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.pasteToolStripButton.Name = "pasteToolStripButton";
      this.pasteToolStripButton.Size = new System.Drawing.Size(23, 22);
      this.pasteToolStripButton.Text = "&Paste";
      // 
      // toolStripSeparator7
      // 
      this.toolStripSeparator7.Name = "toolStripSeparator7";
      this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
      // 
      // helpToolStripButton
      // 
      this.helpToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
      this.helpToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("helpToolStripButton.Image")));
      this.helpToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
      this.helpToolStripButton.Name = "helpToolStripButton";
      this.helpToolStripButton.Size = new System.Drawing.Size(23, 22);
      this.helpToolStripButton.Text = "He&lp";
      // 
      // stbStrip
      // 
      this.stbStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tssblStatus});
      this.stbStrip.Location = new System.Drawing.Point(0, 251);
      this.stbStrip.Name = "stbStrip";
      this.stbStrip.Size = new System.Drawing.Size(292, 22);
      this.stbStrip.TabIndex = 2;
      this.stbStrip.Text = "stbStrip";
      // 
      // tssblStatus
      // 
      this.tssblStatus.Name = "tssblStatus";
      this.tssblStatus.Size = new System.Drawing.Size(39, 17);
      this.tssblStatus.Text = "Ready";
      // 
      // rtxtText
      // 
      this.rtxtText.Dock = System.Windows.Forms.DockStyle.Fill;
      this.rtxtText.Location = new System.Drawing.Point(0, 49);
      this.rtxtText.Name = "rtxtText";
      this.rtxtText.Size = new System.Drawing.Size(292, 202);
      this.rtxtText.TabIndex = 3;
      this.rtxtText.Text = "";
      // 
      // frmMenuAndToolbar
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.rtxtText);
      this.Controls.Add(this.stbStrip);
      this.Controls.Add(this.tlbStrip);
      this.Controls.Add(this.mnuStrip);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MainMenuStrip = this.mnuStrip;
      this.Name = "frmMenuAndToolbar";
      this.Text = "Menu and Toolbar";
      this.mnuStrip.ResumeLayout(false);
      this.mnuStrip.PerformLayout();
      this.tlbStrip.ResumeLayout(false);
      this.tlbStrip.PerformLayout();
      this.stbStrip.ResumeLayout(false);
      this.stbStrip.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmMenuAndToolbar'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260701 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260701 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null)
        {
        }
        else
        // (components != null)
        {
          components.Dispose();
        }
        // (components == null)

      }
      else
      // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMenuAndToolbar()
    //***
    // Action
    //   - Create instance of 'frmMenuAndToolbar'
    // Called by
    //   - Main()
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste � 20260701 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260701 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmMenuAndToolbar()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFileNew_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Execute the file new routine
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - FileNew()
    // Created
    //   - CopyPaste � 20260701 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260701 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FileNew();
    }
    // cmdFileNew_Click(System.Object, System.EventArgs) Handles cmdFileNew.Click

    private void cmdFileOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Execute the file open routine
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - FileOpen()
    // Created
    //   - CopyPaste � 20260701 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260701 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FileOpen();
    }
    // cmdFileOpen_Click(System.Object, System.EventArgs) Handles cmdFileOpen.Click

    private void cmdFileSave_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Execute the file save routine
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - FileSave()
    // Created
    //   - CopyPaste � 20260701 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260701 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FileSave();
    }
    // cmdFileSave_Click(System.Object, System.EventArgs) Handles cmdFileSave.Click

    private void mnuFileNew_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Execute the file new routine
    // Called by
    //   - User action (Clicking a menu item)
    // Calls
    //   - FileNew()
    // Created
    //   - CopyPaste � 20260701 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260701 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FileNew();
    }
    // mnuFileNew_Click(System.Object, System.EventArgs) Handles mnuFileNew.Click

    private void mnuFileOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Execute the file open routine
    // Called by
    //   - User action (Clicking a menu item)
    // Calls
    //   - FileOpen()
    // Created
    //   - CopyPaste � 20260701 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260701 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FileOpen();
    }
    // mnuFileOpen_Click(System.Object, System.EventArgs) Handles mnuFileOpen.Click

    private void mnuFileSave_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Execute the file save routine
    // Called by
    //   - User action (Clicking a menu item)
    // Calls
    //   - FileOpen()
    // Created
    //   - CopyPaste � 20260701 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260701 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FileSave();
    }
    // mnuFileSave_Click(System.Object, System.EventArgs) Handles mnuFileSave.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void FileNew()
    //***
    // Action
    //   - Clear the rich text box
    //   - Set status bar to text "Ready"
    // Called by
    //   - cmdFileNew_Click(System.Object, System.EventArgs) Handles cmdFileNew.Click
    //   - mnuFileNew_Click(System.Object, System.EventArgs) Handles mnuFileNew.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260701 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260701 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      rtxtText.Text = null;
      tssblStatus.Text = "Ready";
    }
    // FileNew()

    public void FileOpen()
    //***
    // Action
    //   - Open a rich text file
    //   - Show a open file dialog with the correct properties
    //   - If file is choosen and open is clicked
    //     - Load the rich text file into the rich text box
    //   - If not
    //     - Do nothing
    // Called by
    //   - cmdFileOpen_Click(System.Object, System.EventArgs) Handles cmdFileOpen.Click
    //   - mnuFileOpen_Click(System.Object, System.EventArgs) Handles mnuFileOpen.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260701 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260701 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      dlgFileOpen.FileName = "";
      dlgFileOpen.Filter = "Rich Text Files|*.rtf";

      if (dlgFileOpen.ShowDialog() == DialogResult.OK)
      {
        rtxtText.LoadFile(dlgFileOpen.FileName, RichTextBoxStreamType.RichText);
      }
      else
      // dlgFileOpen.ShowDialog() <> DialogResult.OK
      {
      }
      // dlgFileOpen.ShowDialog() = DialogResult.OK

    }
    // FileOpen()

    public void FileSave()
    // Action
    //   - Save a rich text file
    //   - Show a save file dialog with the correct properties
    //   - If file is choosen and open is clicked
    //     - Load the rich text file into the rich text box
    //   - If not
    //     - Do nothing
    // Called by
    //   - cmdFileSave_Click(System.Object, System.EventArgs) Handles cmdFileSave.Click
    //   - mnuFileSave_Click(System.Object, System.EventArgs) Handles mnuFileSave.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260701 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260701 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      dlgFileSave.Filter = "Rich Text Files|*.rtf";

      if (dlgFileSave.ShowDialog() == DialogResult.OK)
      {
        rtxtText.SaveFile(dlgFileSave.FileName, RichTextBoxStreamType.RichText);
      }
      else
      // dlgFileOpen.ShowDialog() <> DialogResult.OK
      {
      }
      // dlgFileOpen.ShowDialog() = DialogResult.OK

    }
    // FileSave()

    [STAThread]
    public static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmMenuAndToolbar
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmMenuAndToolbar()
    // Created
    //   - CopyPaste � 20260701 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260701 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmMenuAndToolbar());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMenuAndToolbar

}
// CopyPaste.Learning