//***
// Action
//   - Demo of inheritance of constructors of Base and Derived classes
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmClass : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdCreate;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmClass));
      this.cmdCreate = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdCreate
      // 
      this.cmdCreate.Location = new System.Drawing.Point(64, 104);
      this.cmdCreate.Name = "cmdCreate";
      this.cmdCreate.Size = new System.Drawing.Size(152, 23);
      this.cmdCreate.TabIndex = 1;
      this.cmdCreate.Text = "Create Class";
      this.cmdCreate.Click += new System.EventHandler(this.cmdCreate_Click);
      // 
      // frmClass
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdCreate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmClass";
      this.Text = "Inheritance Constructors";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmClass'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmClass()
      //***
      // Action
      //   - Create instance of 'frmClass'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmClass()

    #endregion

    #region "Designer"

    public class cpBase
    {

      #region "Constructors / Destructors"
      
      public cpBase()
        //***
        // Action
        //   - Constructor of cpBase class
        //   - Shows a messagebox
        // Called by
        //   - cpDerived()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230804 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230804 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        MessageBox.Show("The Base Class Constructor is Running");
      }
      // cpBase()

      #endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      //#region "Fields"
      //#endregion

      //#region "Properties"
      //#endregion

      //#region "Methods"

      //#region "Overrides"
      //#endregion

      //#region "Controls"
      //#endregion

      //#region "Functionality"

      //#region "Event"
      //#endregion

      //#region "Sub / Function"
      //#endregion

      //#endregion

      //#endregion

      //#region "Not used"
      //#endregion

    }
    // cpBase

    public class cpDerived : cpBase
    {

      #region "Constructors / Destructors"
      
      public cpDerived()
        //***
        // Action
        //   - Constructor of cpDerived class
        //   - Shows a messagebox
        // Called by
        //   - cmdCreate_Click(System.Object, System.EventArgs) Handles cmdCreate.Click
        // Calls
        //   - cpBase()
        // Created
        //   - CopyPaste � 20230804 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230804 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        MessageBox.Show("The Derived Class Constructor is Running");
      }
      // cpDerived()

      #endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      //#region "Fields"
      //#endregion

      //#region "Properties"
      //#endregion

      //#region "Methods"

      //#region "Overrides"
      //#endregion

      //#region "Controls"
      //#endregion

      //#region "Functionality"

      //#region "Event"
      //#endregion

      //#region "Sub / Function"
      //#endregion

      //#endregion

      //#endregion

      //#region "Not used"
      //#endregion

    }
    // cpDerived

    #endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCreate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'cpDerived'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpDerived()
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpDerived theSample = new cpDerived();
    }
    // cmdCreate_Click(System.Object, System.EventArgs) Handles cmdCreate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmClass
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmClass());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmClass

}
// CopyPaste.Learning