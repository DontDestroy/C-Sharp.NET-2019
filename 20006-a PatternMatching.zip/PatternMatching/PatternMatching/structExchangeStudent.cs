﻿//***
// Action
//   - Definition of an ExchangeStudent struct
// Created
//   - CopyPaste – 20221211 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20221211 – VVDW
// Proposal (To Do)
//   -
//***

using static CopyPaste.Learning.cpProgram;

namespace CopyPaste.Learning
{

  public struct cpExchangeStudent
  {

    #region "Constructors / Destructors"

    public cpExchangeStudent()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20221211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20221211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpExchangeStudent()

    public cpExchangeStudent((string strFirstName, string strLastName, int intAge) thePersonDetails, cpUniversityCourses theShortCourse, DateTime dtmStudentVisaExpiryDate)
    //***
    // Action
    //   - Constructor with 3 parameters
    //     - personDetails: A tuple with the personal details firstname, lastname and age
    //     - theShortCourse: The short course the exchange student is enrolled for
    //     - dtmStudentVisaExpiryDate: The expiry date of the student visa
    // Called by
    //   - cpProgram.cpMain() 
    // Calls
    //   - FirstName(string) (Set)
    //   - LastName(string) (Set)
    //   - ShortCourse(string) (Set)
    //   - VisaExpiryDate(DateTime) (Set)
    // Created
    //   - CopyPaste – 20221211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20221211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      FirstName = thePersonDetails.strFirstName;
      LastName = thePersonDetails.strLastName;
      ShortCourse = theShortCourse;
      VisaExpiryDate = dtmStudentVisaExpiryDate;
    }
    // cpExchangeStudent((string, string, int), cpUniversityCourses, DateTime)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public cpUniversityCourses ShortCourse { get; }
    public DateTime VisaExpiryDate { get; }
    public string FirstName { get; set; }
    public string LastName { get; set; }

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public (string strFullName, string strShortCourse, int intDaysLeftOnVisa) ExchangeStudentDetails()
    //***
    // Action
    //   - Return information about the alumnus
    //     - A tuple of 2 strings and an integer is used
    // Called by
    //   - cpPatternMatching.GetPersonCourseBeforeCSharp07(System.Object)
    //   - cpPatternMatching.GetPersonCourseIsTypePattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchPattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchPatternNull(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchWhenPattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchWhenPatternExclusion(System.Object)
    // Calls
    //   - cpUniversityDegree ObtainedDegree (Get)
    //   - int CompletedYear (Get)
    //   - string FirstName (Get)
    //   - string LastName (Get)
    // Created
    //   - CopyPaste – 20221211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20221211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      double dblLengthOfVisa;

      dblLengthOfVisa = VisaExpiryDate.Subtract(DateTime.Now).TotalDays;
      (string, string, int) exchangeDetails = ($"{FirstName} {LastName}", ShortCourse.ToString(), Convert.ToInt32(dblLengthOfVisa));

      return exchangeDetails;
    }
    // (string, string, int) ExchangeStudentDetails()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpExchangeStudent

}
// CopyPaste.Learning