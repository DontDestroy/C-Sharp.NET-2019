﻿//***
// Action
//   - Show a table with the monthly payments
//   - There are some labels
//   - There is a data grid
// Created
//   - CopyPaste – 20260423 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260423 – VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmLoanPaymentSchedule : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.ID = "wfrmLoanPaymentSchedule";
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    DataColumn dclColumn1;
    DataColumn dclColumn2;
    DataColumn dclColumn3;
    DataColumn dclColumn4;
    DataColumn dclColumn5;
    DataColumn dclColumn6;

    DataSet dsSchedule;
    DataTable dtTable;
    Single sngPayment;
    Single sngRate;
    System.Int32 intLoanAmount;
    System.Int32 intTerm;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260423 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260423 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define and initialize a Belgian culture info
    //   - Define and initialize the wanted number format
    //   - Initialize the loan amount (getting from the cache)
    //   - Initialize the number of terms (getting from the cache)
    //   - Initialize the monthly payment (getting from the cache)
    //   - Initialize the interest rate (getting from the cache)
    //   - Show the details on the form in the correct format (Belgian)
    //   - Construct the table
    //   - Calculated the schedule
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - CalculateSchedule()
    //   - ConstructTable()
    // Created
    //   - CopyPaste – 20260423 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260423 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      CultureInfo culinfBelgium = new CultureInfo("fr-BE", false);
      NumberFormatInfo nfiBelgium = culinfBelgium.NumberFormat;

      intLoanAmount = Convert.ToInt32(Cache["cpLoanAmount"]);
      intTerm = Convert.ToInt32(Cache["cpTerm"]);
      sngPayment = Convert.ToSingle(Cache["cpPayment"]);
      sngRate = Convert.ToSingle(Cache["cpRate"]);
      lblDetails.Text = "Loan Amount: " + intLoanAmount.ToString("€ #,##0.00", nfiBelgium) +
        "    Rate:  " + sngRate.ToString("#,##0.00%", nfiBelgium) +
        "    Term:  " + intTerm.ToString() + " months.";
      ConstructTable();
      CalculateSchedule();
    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void CalculateSchedule()
    //***
    // Action
    //   - Define and initialize a Belgian culture info
    //   - Define a data row and some other variables for intermediate results
    //   - Loop thru the number of terms (months)
    //     - Add a new row using the the table "Schedule" definition from the dataset
    //     - Data row becomes the new row
    //     - Add the data row to the table "Schedule"
    //     - Calculate the paid to date
    //     - Calculate the principal
    //     - Calculate the total principal
    //     - Fill the data row with the correct numbers in the correct format (Belgian)
    //       - Inside that fill there is a calculation (showed the technique, but I prefer a variable)
    //       - Accept the changes in the dataset
    //   - Bind the data set result to the data grid on the form using a data view
    // Called by
    //   - Page_Load(System.Object, System.EventArgs) Handles this.Load
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260423 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260423 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      CultureInfo culinfBelgium = new CultureInfo("fr-BE", false);
      DataRow drDataRow;
      NumberFormatInfo nfiBelgium = culinfBelgium.NumberFormat;
      Single sngPaidToDate = 0;
      Single sngPrincipal;
      Single sngTotalPrincipal = intLoanAmount;

      for (System.Int32 intInstallment = 1; intInstallment <= intTerm; intInstallment++)
      {
        drDataRow = dsSchedule.Tables["Schedule"].NewRow();
        dsSchedule.Tables["Schedule"].Rows.Add(drDataRow);
        sngPaidToDate += sngPayment;
        sngPrincipal = Convert.ToSingle(Financial.PPmt(sngRate / 12, intInstallment, intTerm, -intLoanAmount, 0, DueDate.EndOfPeriod));
        sngTotalPrincipal -= sngPrincipal;

        drDataRow["Installment"] = intInstallment;
        drDataRow["Payment"] = sngPayment.ToString("€ #,##0.00", nfiBelgium);
        drDataRow["Principal"] = Math.Round(sngPrincipal, 2).ToString("€ #,##0.00", nfiBelgium);
        drDataRow["Interest"] = (sngPayment - sngPrincipal).ToString("€ #,##0.00", nfiBelgium);
        drDataRow["PrincipalRemaining"] = sngTotalPrincipal.ToString("€ #,##0.00", nfiBelgium);
        drDataRow["PaidToDate"] = sngPaidToDate.ToString("€ #,##0.00", nfiBelgium);
        dsSchedule.AcceptChanges();
      }
      // intInstallment = intTerm + 1

      dtgSchedule.PageSize = intTerm;
      dtgSchedule.DataSource = new DataView(dsSchedule.Tables["Schedule"]);
      dtgSchedule.DataBind();
    }
    // CalculateSchedule()

    private void ConstructTable()
    //***
    // Action
    //   - Initialize a new data set
    //   - Initialize a new data table
    //   - Add the data table to the data set
    //   - Create 6 new columns with the correct data type
    //   - Add the 6 columns to the data table
    // Called by
    //   - Page_Load(System.Object, System.EventArgs) Handles this.Load
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260423 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260423 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      dsSchedule = new DataSet("PaymentSchedule");
      dtTable = new DataTable("Schedule");

      dsSchedule.Tables.Add(dtTable);

      dclColumn1 = new DataColumn("Installment");
      dclColumn1.DataType = System.Type.GetType("System.Int32");
      dclColumn2 = new DataColumn("Payment");
      dclColumn2.DataType = System.Type.GetType("System.String");
      dclColumn3 = new DataColumn("Principal");
      dclColumn3.DataType = System.Type.GetType("System.String");
      dclColumn4 = new DataColumn("Interest");
      dclColumn4.DataType = System.Type.GetType("System.String");
      dclColumn5 = new DataColumn("PrincipalRemaining");
      dclColumn5.DataType = System.Type.GetType("System.String");
      dclColumn6 = new DataColumn("PaidToDate");
      dclColumn6.DataType = System.Type.GetType("System.String");

      dtTable.Columns.Add(dclColumn1);
      dtTable.Columns.Add(dclColumn2);
      dtTable.Columns.Add(dclColumn3);
      dtTable.Columns.Add(dclColumn4);
      dtTable.Columns.Add(dclColumn5);
      dtTable.Columns.Add(dclColumn6);
    }
    // ConstructTable()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmLoanPaymentSchedule

}
// CopyPaste.Learning