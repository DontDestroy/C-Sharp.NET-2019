//***
// Action
//   - Implementation of a cpHandWorker
//   - Inherits from cpEmployee
// Created
//   - CopyPaste � 20240410 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240410 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpHandWorker : cpEmployee
  {

    #region "Constructors / Destructors"

    public cpHandWorker(string strName) : base(strName)
      //***
      // Action
      //   - Constructor with Name
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee(string)
      // Created
      //   - CopyPaste � 20240410 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240410 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpHandWorker(string)
 
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private decimal mdecHourPrice = 12.5M;

    #endregion

    #region "Properties"

    public override decimal Amount
    {

      get
        //***
        // Action Get
        //   - Returns 2000 times the hourprice
        //     - 2000 is the estimated number of hours a handworker works every year
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240410 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240410 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecHourPrice * 2000;
      }
      // decimal Amount (Get)

    }
    // decimal Amount

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpHandWorker

}
// CopyPaste.Learning.Employee