﻿//***
// Action
//   - Implementation of a cpDisplayOutputWindow
//		 - The way a thing is displayed on the Output Window
// Created
//   - CopyPaste – 20240727 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240727 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Animal.Library
{

	public class cpDisplayOutputWindow: cpiDisplay
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpFlyNoWay
		/// </summary>
		public cpDisplayOutputWindow()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - cpDecoyDuck()
		//   - cpMallardDuck()
		//   - cpPlasticRubberDuck()
		//   - cpRedHeadDuck()
		//   - cpWoodDuck()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpDisplayOutputWindow()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing is shown in output window
		/// </summary>
		public void Display()
		//***
		// Action
		//   - Define how something is shown on the output window
		// Called by
		//   - cpDecoyDuck() (indirectly, thru delegate)
		//   - cpMallardDuck() (indirectly, thru delegate)
		//   - cpPlasticRubberDuck() (indirectly, thru delegate)
		//   - cpRedHeadDuck() (indirectly, thru delegate)
		//   - cpWoodDuck() (indirectly, thru delegate)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Representation of something");
		}
		// Display()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpDisplayOutputWindow

}
// CopyPaste.Game.Animal.Library