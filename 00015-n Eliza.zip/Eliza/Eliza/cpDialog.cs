//***
// Action
//   - Generating a response to the patient
// Created
//   - CopyPaste � 20220216 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220216 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Text;
using System.Collections.Specialized;

namespace Eliza
{

  public class cpDialog
  {

    #region "Constructors / Destructors"

    public cpDialog()
    {
    }
    // cpDialog()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    private bool mblnInitEliza = false;
    private char[] marrchrBlank = {' '};
    static int mintCurrentStock = 0;
    private int mintTalkingAboutMe = 0;
    private int mintPatientResponseCount = 0;
    private StringCollection mcolstrPatientsResponses = new StringCollection();
    private string mstrPatientResponse = "";
    private string mstrDoctorResponse = "";
    private string[] marrstrStockResponse = 
    {
      "Do your friends really like you?", 
      "Did you fight with your family?", 
      "Did you have a happy childhood?", 
      "Did you hate your father?", 
      "Are you afraid of your friends?", 
      "Why are you so angry?", 
      "Tell me about your involvement with horse racing.", 
      "Does the name Ruby Begonia mean anything to you?", 
      "Why do you have such dark secrets?", 
      "Why are you obsessed with your mortality?", 
      "Tell me about your criminal background."
    };
    private string[,] marrstrTranslate;
    #endregion

    //#Region "Properties"
    //#End Region
    
    #region "Methods"
    
    //#region "Overrides"
    //#endregion
    
    //#region "Controls"
    //#endregion
    
    #region "Functionality"
    
    //#region "Event"
    //#endregion
    
    #region "Sub / Function"
    
    public string GetElizaResponse(string strResponse)
      //***
      // Action
      //   - If nothing was typed, show "Please enter a question."
      //   - Set response by patient to lower letters
      //   - Add 1 to 'mlngPatientResponseCount'
      //   - Add the response to a collection
      //   - If Eliza is intialising
      //   - If Not
      //     - Initialize a translation
      //     - 'mblnInitEliza' becomes true
      //   - If IsDiscussingDoctor
      //     - Return 'strDoctorResponse'
      //   - If GetQuickResponse
      //     - Return 'strDoctorResponse'
      //   - If TryToTranslate
      //     - Return 'strDoctorResponse'
      //   - If GetRandomPhrase
      //     - Return 'strDoctorResponse'
      //   - Put a stock phrase into 'strDoctorResponse'
      //   - Return 'strDoctorResponse'
      // Called by
      //   - txtQuestion_KeyDown(System.Object, System.Windows.Forms.KeyEventArgs) Handles txtQuestion.KeyDown
      // Calls
      //   - bool GetQuickResponse() As Boolean
      //   - bool GetRandomPhrase() As Boolean
      //   - bool GetStockPhrase() As Boolean
      //   - bool IsDiscussingDoctor() As Boolean
      //   - bool TryToTranslate()
      //   - InitaTranslate()
      //   - int StringCollection.Add(String)
      //   - string String.ToLower()
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrDoctorResponse = "";
      
      if (strResponse.Length == 0)
      {
        return "Please enter a question.";
      }
      else
        // strResponse.Length <> 0
      {
      }
      // strResponse.Length = 0
      
      mstrPatientResponse = strResponse.ToLower();
      mintPatientResponseCount += 1;
      mcolstrPatientsResponses.Add(mstrPatientResponse);
      
      if (mblnInitEliza)
      {
      }
      else
        // Not mblnInitEliza
      {
        InitaTranslate();
        mblnInitEliza = true;
      }
      // mblnInitEliza

      if (IsDiscussingDoctor())
      {
        return mstrDoctorResponse;
      }
      else
        // Not IsDiscussingDoctor()
      {
      }
      // IsDiscussingDoctor()
      
      if (GetQuickResponse())
      {
        return mstrDoctorResponse;
      }
      else
        // Not GetQuickResponse()
      {
      }
      // GetQuickResponse()
      
      if (TryToTranslate())
      {
        return mstrDoctorResponse;
      }
      else
        // Not TryToTranslate()
      {
      }
      // TryToTranslate()
      
      if (GetRandomPhrase())
      {
        return mstrDoctorResponse;
      }      
      else
        // Not GetRandomPhrase()
      {
      }
      // GetRandomPhrase()
      
      mstrDoctorResponse = GetStockPhrase();
      return mstrDoctorResponse;
    }
    // string GetElizaResponse(string)

    private bool GetQuickResponse()
      //***
      // Action
      //   - A lot of if else nested statements
      //     - Check if something is in the answer
      //       - 'mstrDoctorResponse' becomes a quick response
      //       - Return True
      //     - Checked on
      //       - "yes"
      //       - "hate"
      //       - "mother"
      //       - "father"
      //       - "sister"
      //       - "brother"
      //       - "you are"
      //       - "i am"
      //       - "i'm"
      //       - "we "
      //       - "no "
      //       - "weather "
      //     - Others
      //       - Return False
      // Called by
      //   - string GetElizaResponse(string)
      // Calls
      //   - int String.IndexOf(string)
      //   - string String.SubString(int)
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int intIndex = 0;

      if (mstrPatientResponse.IndexOf("yes") > -1)
      {
        mstrDoctorResponse = "Ah...that is positive. Tell me more.";
        return true;
      }
      else if (mstrPatientResponse.IndexOf("hate") > -1)
      {
        mstrDoctorResponse = "Why are you so angry?";
        return true;
      }
      else if (mstrPatientResponse.IndexOf("mother") > -1)
      {
        mstrDoctorResponse = "Tell me more about your family...";
        return true;
      }
      else if (mstrPatientResponse.IndexOf("father") > -1)
      {
        mstrDoctorResponse = "Why were you angry at males in your family?";
        return true;
      }
      else if (mstrPatientResponse.IndexOf("sister") > -1) 
      {
        mstrDoctorResponse = "Why are you jealous of your sister?";
        return true;
      }
      else if (mstrPatientResponse.IndexOf("brother") > -1)
      {
        mstrDoctorResponse = "Why was your brother liked more than you?";
        return true;
      }
      else if (mstrPatientResponse.IndexOf("you are") > -1)
      {
        intIndex = mstrPatientResponse.IndexOf("you are");
        mstrDoctorResponse = "I am " + mstrPatientResponse.Substring(intIndex + 8) + "?";
        return true;
      }
      else if (mstrPatientResponse.IndexOf("i am") > -1)
      {
        intIndex = mstrPatientResponse.IndexOf("i am");
        mstrDoctorResponse = "Why are you " + mstrPatientResponse.Substring(intIndex + 5) + "?";
        return true;
      }
      else if (mstrPatientResponse.IndexOf("i'm") > -1)
      {
        intIndex = mstrPatientResponse.IndexOf("i'm");
        mstrDoctorResponse = "Why are you " + mstrPatientResponse.Substring(intIndex + 4) + "?";
        return true;
      }
      else if (mstrPatientResponse.IndexOf("we ") > -1)
      {
        mstrDoctorResponse = "Try not to discuss us � tell me about you.";
        return true;
      }
      else if (mstrPatientResponse.IndexOf("no ") > -1)
      {
        mstrDoctorResponse = "Why are you so negative?";
        return true;
      }
      else if (mstrPatientResponse.IndexOf("weather") > -1)
      {
        mstrDoctorResponse = "Did you want to be a meteorologist as a child?";
        return true;
      }
      else
        // mstrPatientResponse.IndexOf("yes") <= -1
        // mstrPatientResponse.IndexOf("hate") <= -1
        // mstrPatientResponse.IndexOf("mother") <= -1
        // mstrPatientResponse.IndexOf("father") <= -1
        // mstrPatientResponse.IndexOf("sister") <= -1
        // mstrPatientResponse.IndexOf("brother") <= -1
        // mstrPatientResponse.IndexOf("you are") <= -1
        // mstrPatientResponse.IndexOf("i am") <= -1
        // mstrPatientResponse.IndexOf("i'm") <= -1
        // mstrPatientResponse.IndexOf("we ") <= -1
        // mstrPatientResponse.IndexOf("no ") <= -1
        // mstrPatientResponse.IndexOf("weather") <= -1
      {
        return false;
      }
      // mstrPatientResponse.IndexOf("yes") > -1
      // mstrPatientResponse.IndexOf("hate") > -1
      // mstrPatientResponse.IndexOf("mother") > -1
      // mstrPatientResponse.IndexOf("father") > -1
      // mstrPatientResponse.IndexOf("sister") > -1
      // mstrPatientResponse.IndexOf("brother") > -1
      // mstrPatientResponse.IndexOf("you are") > -1
      // mstrPatientResponse.IndexOf("i am") > -1
      // mstrPatientResponse.IndexOf("i'm") > -1
      // mstrPatientResponse.IndexOf("we ") > -1
      // mstrPatientResponse.IndexOf("no ") > -1
      // mstrPatientResponse.IndexOf("weather") > -1

    }   
    // bool GetQuickResponse()

    private string GetStockPhrase()
      //***
      // Action
      //   - If Current stock is bigger than the responses
      //     - Return the first response
      //   - If Not
      //     - Return the Current stock response
      // Called by
      //   - string GetElizaResponse(string)
      // Calls
      //   - int Array.GetLowerBound(int)
      //   - int Array.GetUpperBound(int)
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (mintCurrentStock > marrstrStockResponse.GetUpperBound(0))
      {
        mintCurrentStock = marrstrStockResponse.GetLowerBound(0);
        return marrstrStockResponse[mintCurrentStock];
      }
      else
        // intCurrentStock <= marrstrStockResponse.GetUpperBound(0)
      {
        mintCurrentStock += 1;
        return marrstrStockResponse[mintCurrentStock - 1];
      }
      // intCurrentStock > marrstrStockResponse.GetUpperBound(0)

    }
    // string GetStockPhrase()

    private bool GetRandomPhrase()
      //***
      // Action
      //   - If patient responded a multiplication of 6
      //     - Get a random number
      //     - If random number is smaller or equal than the number of the patients responses
      //       - Get that response
      //       - Put the first letter to capital
      //       - Append in front "Please tell me more about: "
      //       - Append response (with capital)
      //       - Return True
      //   - Return False
      // Called by
      //   - string GetElizaResponse(string)
      // Calls
      //   - char Char.ToUpper(char)
      //   - char Convert.ToChar(char)
      //   - int Random.Next(int, int)
      //   - int StringCollection.Count() 
      //   - string String.Insert(int, char) 
      //   - string String.Remove(int, int)
      //   - StringBuilder StringBuilder.Append(string)
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (mintPatientResponseCount % 6 == 0)
      {
        int intLimit = mcolstrPatientsResponses.Count;
        int intPickResponse = 0;
        Random rndRandom = new Random();
        string strComment;
        StringBuilder strBuildPreviousComment = new StringBuilder();

        intPickResponse = rndRandom.Next(0, intLimit);
        
        if (intPickResponse <= mcolstrPatientsResponses.Count)
        {
          char chrFirstLetter;
          
          strComment = mcolstrPatientsResponses[intPickResponse];
          chrFirstLetter = Convert.ToChar(strComment[0]);
          chrFirstLetter = char.ToUpper(chrFirstLetter);
          strComment = strComment.Remove(0, 1);
          strComment = strComment.Insert(0, chrFirstLetter.ToString());
          strBuildPreviousComment.Append("Please tell me more about: \"");
          strBuildPreviousComment.Append(strComment + "\"");
          mstrDoctorResponse = strBuildPreviousComment.ToString();
          return true;
        }
        else
          // intPickResponse > mcolstrPatientsResponses.Count
        {
        }
        // intPickResponse <= mcolstrPatientsResponses.Count
      }
      else
        // mintPatientResponseCount % 6 <> 0
      {
      }
      // mintPatientResponseCount % 6 = 0

      return false;
    }
    // bool GetRandomPhrase()

    private void InitaTranslate()
      //***
      // Action
      //   - To define a response, we switch some words in a 2 dimensional array
      //     - i <--> you
      //     - your <--> my
      //     - am <--> are
      //     - me <--> you
      // Called by
      //   - string GetElizaResponse(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - The moment the words "They are" are used, It's not translated correctly
      //***
    {
      marrstrTranslate = new string[8, 2];

      marrstrTranslate[0, 0] = "i";
      marrstrTranslate[0, 1] = "you";
      marrstrTranslate[1, 0] = "you";
      marrstrTranslate[1, 1] = "I";
      marrstrTranslate[2, 0] = "your";
      marrstrTranslate[2, 1] = "my";
      marrstrTranslate[3, 0] = "my";
      marrstrTranslate[3, 1] = "your";
      marrstrTranslate[4, 0] = "am";
      marrstrTranslate[4, 1] = "are";
      marrstrTranslate[5, 0] = "you";
      marrstrTranslate[5, 1] = "i";
      marrstrTranslate[6, 0] = "are";
      marrstrTranslate[6, 1] = "am";
      marrstrTranslate[7, 0] = "me";
      marrstrTranslate[7, 1] = "you";
    }
    // InitaTranslate()

    private bool IsDiscussingDoctor()
      //***
      // Action
      //   - If response of patient contains "you"
      //     - 'mlngTalkingAboutMe' becomes one higher
      //     - 'mlngTalkingAboutMe' is an even number
      //       - If 'mlngTalkingAboutMe' is smaller than 3
      //         - 'mstrDoctorResponse' becomes "We are discussing you, not me"
      //       - If Not
      //         - 'mstrDoctorResponse' becomes "You have talked about me xx times. Shall we focus on you?"
      //     - Return True
      //   - Return False
      // Called by
      //   - string GetElizaResponse(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (mstrPatientResponse.IndexOf("you") > -1)
      {
        mintTalkingAboutMe += 1;
        
        if (mintTalkingAboutMe % 2 == 0)
        {
          
          if (mintTalkingAboutMe < 3)
          {
            mstrDoctorResponse = "We are discussing you, not me";
          }
          else
            // mintTalkingAboutMe >= 3
          {
            mstrDoctorResponse = "You have talked about me " + mintTalkingAboutMe.ToString() + " times.";
            mstrDoctorResponse += Environment.NewLine + "Shall we focus on you?";
          }
          // mintTalkingAboutMe < 3

          return true;
        }
        else
          //' mlngTalkingAboutMe % 2 <> 0
        {
        }
        // mlngTalkingAboutMe % 2 = 0

      }
      else
        // mstrPatientResponse.IndexOf("you") <= -1
      {
      }
      // strPatientResponse.IndexOf("you") > -1
      
      return false;
    }
    // bool IsDiscussingDoctor()

    private bool TryToTranslate()
      //***
      // Action
      //   - Create an array of all words in 'mstrPatientResponse'
      //   - Loop thru the array of words
      //     - Get the word
      //     - Loop thru the array of 'marrstrTranslate'
      //       - If found
      //         - If first word
      //           - Add translation towards 'strBuildDrResponse'
      //         - If Not
      //           - Add space and translation towards 'strBuildDrResponse'
      //         - Elisa could translate (blnCanTranslate is set to True)
      //         - Set 'blnAddQuestionMark' to True
      //         - Exit loop
      //     - If 'blnCanTranslate'
      //     - If Not
      //       - If first word
      //         - Add word towards 'strBuildDrResponse' 
      //       - If Not 
      //         - Add space and word towards 'strBuildDrResponse'
      //   - If 'blnAddQuestionMark' and lenght of 'strBuildDrResponse' is bigger than 5
      //     - Get First letter
      //     - Put it with a capital
      //     - Add Questionmark at the end
      //     - 'mstrDoctorResponse' becomes 'strBuildDrResponse'
      //     - Return True
      //   - If Not
      //     - Return False
      // Called by
      //   - string GetElizaResponse()
      // Calls
      //   - bool String.Equals(string)
      //   - int Array.GetLowerBound(int)
      //   - int Array.GetUpperBound(int)
      //   - int StringBuilder.Length() As Integer
      //   - string[] String.Split(char)
      //   - StringBuilder StringBuilder.Append(string)
      //   - StringBuilder StringBuilder.Insert(int, int)
      //   - StringBuilder StringBuilder.Remove(int, int)
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnAddQuestionMark = false;
      bool blnCanTranslate = false;
      int intTranslateLoop = 0;
      int intTranslateLower = marrstrTranslate.GetLowerBound(0);
      int intTranslateUpper = marrstrTranslate.GetUpperBound(0);
      int intWordLoop = 0;
      string strCurrentWord = "";
      StringBuilder strBuildDrResponse = new StringBuilder();
      string[] arrstrSentenceWord = mstrPatientResponse.Split(marrchrBlank);

      int intWordsLower = arrstrSentenceWord.GetLowerBound(0);
      int intWordsUpper = arrstrSentenceWord.GetUpperBound(0);

      for (intWordLoop = intWordsLower; intWordLoop <= intWordsUpper; intWordLoop++)
      {
        strCurrentWord = arrstrSentenceWord[intWordLoop];
        blnCanTranslate = false;

        for (intTranslateLoop = intTranslateLower; intTranslateLoop <= intTranslateUpper; intTranslateLoop++)
        {
        
          if (marrstrTranslate[intTranslateLoop, 0].Equals(strCurrentWord))
          {

            if (intWordLoop == 0)
            {
              strBuildDrResponse.Append(marrstrTranslate[intTranslateLoop, 1].TrimStart(marrchrBlank));
            }
            else
              // intWordLoop <> 0
            {
              strBuildDrResponse.Append(" " + marrstrTranslate[intTranslateLoop, 1].TrimStart(marrchrBlank));
            }
            // intWordLoop = 0
            
            blnCanTranslate = true;
            blnAddQuestionMark = true;
            break;
          }
          else
            // Not marrstrTranslate[intTranslateLoop, 0].Equals(strCurrentWord)
          {
          }
          // marrstrTranslate(intTranslateLoop, 0).Equals(strCurrentWord)

        }
        // intTranslateLoop = intTranslateUpper + 1

        if (blnCanTranslate)
        {
        }
        else
          // Not blnCanTranslate
        {
          if (intWordLoop == 0)
          {
            strBuildDrResponse.Append(strCurrentWord);
          }
          else
            // lngWordLoop <> 0
          {
            strBuildDrResponse.Append(" " + strCurrentWord);
          }
          // intWordLoop = 0
        }
        // blnCanTranslate

      }
      // intWordLoop = intWordsUpper + 1

      if ((blnAddQuestionMark == true) && (strBuildDrResponse.Length > 5))
      {
        char chrFirstLetter = Convert.ToChar(strBuildDrResponse[0]);

        chrFirstLetter = char.ToUpper(chrFirstLetter);
        strBuildDrResponse.Remove(0, 1);
        strBuildDrResponse.Insert(0, chrFirstLetter);
        strBuildDrResponse.Append("?");
        mstrDoctorResponse = strBuildDrResponse.ToString();
        return true;
      }
      else
        // (blnAddQuestionMark <> true) || (strBuildDrResponse.Length <= 5)
      {
        return false;
      }
      // (blnAddQuestionMark = true) && (strBuildDrResponse.Length > 5)

    }
    // bool TryToTranslate()

    #endregion
    
    #endregion
    
    #endregion
    
    //#Region "Not used"
    //#End Region

	}
  // cpDialog

}
// Eliza