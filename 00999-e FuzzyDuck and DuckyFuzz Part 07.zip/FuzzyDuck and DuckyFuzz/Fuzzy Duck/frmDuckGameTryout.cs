//***
// Action
//   - Tryout Startup screen of the duck game
// Created
//   - CopyPaste � 20240725 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240725 � VVDW
// Proposal (To Do)
//   - 
//***

namespace CopyPaste.Game.Duck
{

	public partial class frmDuckGameTryout : System.Windows.Forms.Form
	{

		#region "Constructors / Destructors"

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		//***
		// Action
		//   - Clean up instance of 'frmDuckGameTryout'
		// Called by
		//   - User action (Closing the form)
		// Calls
		//   - 
		// Created
		//   - CopyPaste � 20240725 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20240725 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{

			if (disposing)
			{

				if (components == null)
				{
				}
				else
				// (components != null)
				{
					components.Dispose();
				}
				// (components == null)

			}
			else
			// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		/// <summary>
		/// Constructor of the start screen of the Duck Game
		/// </summary>
		public frmDuckGameTryout()
		//***
		// Action
		//   - Create instance of 'frmDuckGameTryout'
		// Called by
		//   - Main()
		// Calls
		//   - InitializeComponent()
		// Created
		//   - CopyPaste � 20240725 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20240725 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			InitializeComponent();
		}
		// frmDuckGameTryout()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// frmDuckGameTryout

}
// CopyPaste.Game.Duck