﻿//***
// Action
//   - Demo of Client Server techniques
//     - Cookies, Cookies Techniques, Session
// Created
//   - CopyPaste – 20260705 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260705 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmClientServer : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cmdClick.Click += new System.EventHandler(this.cmdClick_Click);
      this.cmdCookieRead.Click += new System.EventHandler(this.cmdCookieRead_Click);
      this.cmdCookieWrite.Click += new System.EventHandler(this.cmdCookieWrite_Click);
      this.ID = "wfrmClientServer";
      this.Load += new System.EventHandler(this.Page_Load);

    }
    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static int intTeller;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when initializing the page
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260705 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260705 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdClick_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Part 01 (Working with a variable, not working correctly)
    //     - Define a static counter as integer
    //     - Add 1 to the counter
    //     - Show the result of the counter in the lblResult
    //     - Not 100% correct due to the fact that reloading the page is executing the code of the button Click here
    //   - Part 02 (Working with a hidden label)
    //     - Convert the text of the 'hidden' label to an integer
    //     - Increment that value
    //     - Convert it back to text and show it in the 'hidden' label
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260705 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260705 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***    
    {
      // VVDW - Part 01 (Variable solution, not working)
      intTeller += 1;
      lblResult.Text = intTeller.ToString();

      //// VVDW - Part 02 (Hidden solution)
      //lblHidden.Text = Convert.ToString(Convert.ToInt32(lblHidden.Text) + 1);
    }
    // cmdClick_Click(System.Object, System.EventArgs) Handles cmdClick.Click

    private void cmdCookieRead_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a carriage return in HTML
    //   - Part 01 (Cookies)
    //     - Get a request for all the cookies
    //     - If there are cookies
    //       - Show the number of cookies
    //       - Loop thru the cookies
    //         - Show name and value
    //     - If not
    //       - Do nothing
    //   - Part 02 (Cookies Techniques)
    //     - Show all the values of specific cookies
    //     - Loop thru the values of a specific cookie
    //   - Part 03 ()
    //     - Show the session ID
    //     - If number of sessions is 0
    //       - Do nothing
    //     - If not
    //       - Loop thru the sessions
    //         - Show session keys and its values
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260705 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260705 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***    
    {
      // VVDW - Pay attention (it is HTML)
      const string vbCrLf = "<br>";

      //VVDW - Part 01(Cookies)
      HttpCookieCollection theCookies = Request.Cookies;

      if (theCookies == null)
      {
      }
      else
      // theCookies <> null
      {
        lblCookieOut.Text = "Number of cookies = " + theCookies.Count;

        int intCounter;

        for (intCounter = 0; intCounter < theCookies.Count; intCounter++)
        {
          lblCookieOut.Text += vbCrLf + vbCrLf +
            "cookies(" + intCounter.ToString() + ").Name = " + theCookies[intCounter].Name + vbCrLf +
            "cookies(" + intCounter.ToString() + ").Value = " + theCookies[intCounter].Value;
        }
        // intCounter = theCookies.Count

      }
      // theCookies = null

      //// VVDW - Part 02 (Cookies Techniques)
      //lblCookieOut.Text = Request.Cookies["AddressInformation"].Value + vbCrLf +
      //  Request.Cookies["Name"].Value + vbCrLf +
      //  Request.Cookies["Address"].Value + vbCrLf +
      //  Request.Cookies["City"].Value + vbCrLf +
      //  Request.Cookies["theAddress"]["Name"] + vbCrLf +
      //  Request.Cookies["theAddress"]["Address"] + vbCrLf +
      //  Request.Cookies["theAddress"]["City"];

      //foreach (string strValue in Request.Cookies["theAddress"].Values)
      //{
      //  Debug.WriteLine(Request.Cookies[strValue].Value);
      //}
      //// in Request.Cookies["theAddress"].Values

      //// VVDW - Part 03 (Session)
      //lblCookieOut.Text = "Id = " + Session.SessionID;

      //if (Session.Count == 0)
      //{
      //}
      //else
      //// Session.Count <> 0
      //{
      //  int intCounter;

      //  for (intCounter = 0; intCounter < Session.Keys.Count; intCounter++)
      //  {
      //    lblCookieOut.Text += vbCrLf + Session.Keys[intCounter] + " = " + Session[intCounter].ToString();
      //  }
      //  // intCounter = Session.Keys.Count

      //}
      //// Session.Count = 0

    }
    // cmdCookieRead_Click(System.Object, System.EventArgs) Handles cmdCookieRead.Click

    private void cmdCookieWrite_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - If textbox is empty
    //     - Do nothing
    //   - If not
    //     - Part 01 (Cookies)
    //       - Set a cookie with a name (text) and a value (time)
    //     - Part 02 (Cookies techniques)
    //       - 
    //     - Part 03 (Session)
    //       - Set the session name with the content of the textbox
    //       - Set the session time to the current time
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260705 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260705 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***    
    {

      // VVDW - Part 01 (Cookies)
      if (txtCookieIn.Text.Trim() == "")
      {
      }
      else
      // txtCookieIn.Text.Trim() <> ""
      {
        Response.Cookies[txtCookieIn.Text.Trim()].Value = DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss");
      }
      // txtCookieIn.Text.Trim() = "" 

      //// VVDW - Part 02 (Cookies Techniques)
      //Response.Cookies["AddressInformation"].Value = "John Doe|Nowhere 1|CityVille";
      //Response.Cookies["Name"].Value = "John Doe";
      //Response.Cookies["Address"].Value = "Nowhere 1";
      //Response.Cookies["City"].Value = "CityVille";
      //Response.Cookies["theAddress"]["Name"] = "John Doe";
      //Response.Cookies["theAddress"]["Address"] = "Nowhere 1";
      //Response.Cookies["theAddress"]["City"] = "CityVille";

      //// VVDW - Part 03 (Session)
      //Session[txtCookieIn.Text.Trim()] = DateTime.Now.ToString("dd/MM/yyyy hh:mm:ss");
    }
    // cmdCookieWrite_Click(System.Object, System.EventArgs) Handles cmdCookieWrite.Click

    protected void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - If it is the first time a page is loaded
    //     - Set the text to "Call"
    //     - Set a 'hidden' label to 1
    //   - If not
    //     - Set the text to "(re-)Call"
    //     - 'hidden' label is adapted by other event on the page (Clicking a button)
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260705 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260705 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (IsPostBack)
      {
        lblResult.Text = "(re-)Call";
      }
      else
      // Not IsPostBack
      {
        lblResult.Text = "Call";
        lblHidden.Text = Convert.ToString(1);
      }
      // IsPostBack

    }
    // Page_Load(System.Object, System.EventArgs) Handles base.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmClientServer

}
// CopyPaste.Learning