<%@ Page Language="C#" %>

<html>
<head>
  <title>Store Variables</title>
</head>
<body>
  <center>
    <h1>Store Session and Application Variables</h1>
  </center>
  <hr />

  <%

    Session["Book"] = "C#.NET Programming Tips & Techniques";
    Session["Chapter"] = "Chapter 13";
    Application["Publisher"] = "McGraw-Hill/Osborne";
    Application["Author"] = "Jamsa";

  %>

  <br>
  <br>
  <a href="wfrmShowVariables.aspx">Link to an ASP.NET Page: wfrmShowVariables.aspx</a><br>
  <br>
</body>
</html>
