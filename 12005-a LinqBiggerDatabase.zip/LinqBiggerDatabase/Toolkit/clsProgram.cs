﻿//***
// Action
//   - Toolkit used to reverse engineer database with Entity Framework Core (version 5.0.17)
//   - The commands used for installing nuget packages can be found in the folder 'Executed Commands'
//   - Contains testroutines for Console visualisations
// Created
//   - CopyPaste – 20230707 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230707 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Toolkit
{

  class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Test the cpConsole routines
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpConsole.MainHeadLine(System.Object)
    //   - cpConsole.Print(System.Object)
    //   - cpConsole.Print(System.Object, ConsoleColor? = null, ConsoleColor? = null)
    //   - cpConsole.PrintDebug(System.Object)
    //   - cpConsole.PrintDebug(System.Object, ConsoleColor, ConsoleColor? = null)
    //   - cpConsole.PrintDebugError(System.Object)
    //   - cpConsole.PrintDebugOrVerbose(System.Object, ConsoleColor, ConsoleColor? = null)
    //   - cpConsole.PrintDebugSuccess(System.Object)
    //   - cpConsole.PrintError(System.Object)
    //   - cpConsole.PrintInternal(System.Object, ConsoleColor? = null, ConsoleColor? = null)
    //   - cpConsole.PrintSuccess(System.Object)
    //   - cpConsole.PrintVerbose(System.Object)
    //   - cpConsole.PrintVerbose(System.Object, ConsoleColor, ConsoleColor? = null)
    //   - cpConsole.PrintVerboseError(System.Object)
    //   - cpConsole.PrintVerboseSuccess(System.Object)
    //   - cpConsole.PrintVerboseWarning(System.Object)
    //   - cpConsole.PrintWarning(System.Object)
    //   - cpConsole.PrintWithCounter(System.Object, ConsoleColor, ConsoleColor? = null)
    //   - cpConsole.PrintWithTime(System.Object, ConsoleColor = ConsoleColor.White)
    // Created
    //   - CopyPaste – 20230707 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpConsole.PrintMainHeadLine("PrintInternal tests");
      cpConsole.PrintInternal("This is a PrintInternal test");
      cpConsole.PrintInternal("This is a PrintInternal test", ConsoleColor.DarkYellow);
      cpConsole.PrintInternal("This is a PrintInternal test");
      cpConsole.PrintInternal("This is a PrintInternal test", ConsoleColor.DarkYellow, ConsoleColor.DarkRed);
      cpConsole.PrintInternal("This is a PrintInternal test");
      cpConsole.PrintMainHeadLine("Print tests");
      cpConsole.Print("This is a Print test");
      cpConsole.Print("This is a Print test", ConsoleColor.DarkYellow);
      cpConsole.Print("This is a Print test", ConsoleColor.DarkYellow, ConsoleColor.DarkRed);
      cpConsole.PrintMainHeadLine("PrintDebug tests");
      cpConsole.PrintDebug("This is a PrintDebug test");
      cpConsole.PrintDebug("This is a PrintDebug test", ConsoleColor.DarkYellow);
      cpConsole.PrintDebug("This is a PrintDebug test", ConsoleColor.DarkYellow, ConsoleColor.DarkRed);
      cpConsole.PrintMainHeadLine("PrintDebugOrVerbose tests");
      cpConsole.PrintDebugOrVerbose("This is a PrintDebugOrVerbose test", ConsoleColor.DarkYellow);
      cpConsole.PrintDebugOrVerbose("This is a PrintDebugOrVerbose test", ConsoleColor.DarkYellow, ConsoleColor.DarkRed);
      cpConsole.PrintMainHeadLine("PrintWithCounter tests");
      cpConsole.PrintWithCounter("This is a PrintWithCounter test", ConsoleColor.DarkYellow);
      cpConsole.PrintWithCounter("This is a PrintWithCounter test", ConsoleColor.DarkYellow, ConsoleColor.DarkRed);
      cpConsole.PrintMainHeadLine("PrintWithTime tests");
      cpConsole.PrintWithTime("This is a PrintWithTime test");
      cpConsole.PrintWithTime("This is a PrintWithTime test", ConsoleColor.DarkYellow);
      cpConsole.PrintMainHeadLine("PrintVerbose tests");
      cpConsole.PrintVerbose("This is a PrintVerbose test");
      cpConsole.PrintVerbose("This is a PrintVerbose test", ConsoleColor.DarkYellow);
      cpConsole.PrintVerbose("This is a PrintVerbose test", ConsoleColor.DarkYellow, ConsoleColor.DarkRed);
      cpConsole.PrintMainHeadLine("Print Error tests");
      cpConsole.PrintVerboseError("This is a PrintVerboseError");
      cpConsole.PrintDebugError("This is a PrintDebugError");
      cpConsole.PrintError("This is a PrintError");
      cpConsole.PrintMainHeadLine("Print Warning tests");
      cpConsole.PrintVerboseWarning("This is a PrintVerboseWarning");
      cpConsole.PrintDebugWarning("This is a PrintDebugWarning");
      cpConsole.PrintWarning("This is a PrintWarning");
      cpConsole.PrintMainHeadLine("Print Success tests");
      cpConsole.PrintVerboseSuccess("This is a PrintVerboseSuccess");
      cpConsole.PrintDebugSuccess("This is a PrintDebugSuccess");
      cpConsole.PrintSuccess("This is a PrintSuccess");
      Console.WriteLine("\nHit any key ...");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Toolkit