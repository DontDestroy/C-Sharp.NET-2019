﻿//***
// Action
//   - Parsing an array of bytes into an array of integers
//     - A calculation is executed with every group of 8 bytes
// Created
//   - CopyPaste – 20260608 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260608 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Buffers;
using System.Collections.Generic;

namespace CopyPaste.Learning
{

  public class cpMessageParserAdvanced
  {

    #region "Constructors / Destructors"

    public cpMessageParserAdvanced()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpMessageParserAdvanced(byte[])
    //   - cpReuseInstances.MessageParserObjectPoolAdvanced()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260608 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260608 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpMessageParserAdvanced()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    const int intBufferLength = 8;
    private Memory<byte> arrMessage;
    private int intLength;
    private int intPosition;
    private Memory<int> arrResult;

    #endregion

    #region "Properties"

    public Memory<byte> Buffer
    {

      set
      //***
      // Action set
      //   - A given array is put in arrMessage
      //   - The length is set
      // Called by
      //   - cpMessageParserAdvanced(byte[])
      //   - cpReuseInstances.MessageParserObjectPoolAdvanced()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260608 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260608 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        arrMessage = value;
        intLength = value.Length / intBufferLength;
      }
      // Buffer(Memory<byte>) (Set)

    }
    // Memory<byte> Buffer

    public Memory<int> Result
    {

      set
      //***
      // Action set
      //   - A given array is put in arrMessage
      // Called by
      //   -
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260608 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260608 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        arrResult = value;
      }
      // Result(Memory<int>) (Set)

    }
    // Memory<int> Result

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Parse()
    //***
    // Action
    //   - A given array of bytes is rearranged in a range of integers
    //   - First intBufferLength bytes are added to the first integer
    //   - Second intBufferLength bytes are added to the second integer
    //   - Loop for every next 8 items
    // Called by    
    //   - cpReuseInstances.MessageParserObjectPoolAdvanced()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260607 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260607 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - An assumption is taken that the length of the given array is divisible by intBufferLength
    //***
    {
      Span<byte> spnMessage = arrMessage.Span;
      Span<int> spnResult = arrResult.Span;

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {
        intPosition = intCounter * intBufferLength;

        spnResult[intCounter] = spnMessage[intPosition] + spnMessage[intPosition + 1] + spnMessage[intPosition + 2] +
          spnMessage[intPosition + 3] + spnMessage[intPosition + 4] + spnMessage[intPosition + 5] +
          spnMessage[intPosition + 6] + spnMessage[intPosition + 7];
      }
      // intCounter = intLength

    }
    // Parse()

    public void Reset()
    //***
    // Action
    //   - Maybe it is needed to reinitialize the internal state for reuse
    //   - In this example it is not needed, but the method is here for clarity
    // Called by
    //   -
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260607 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260607 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // Reset()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpMessageParserAdvanced

}
// CopyPaste.Learning