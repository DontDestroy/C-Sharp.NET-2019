﻿//***
// Action
//   - Guessing Game
//     - Type to guess a number between 1 and 100
// Created
//   - CopyPaste – 20260619 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260619 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmGuess : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cmdGuess.Click += new System.EventHandler(this.cmdGuess_Click);
      this.ID = "wfrmGuess";
      this.Load += new System.EventHandler(this.Page_Load);
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions executed when page is initialized
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdGuess_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Get the item "intToGuess" from the view state, convert it to an integer
    //   - Get the typed text, convert it to an integer
    //   - Get the item "intNumberOfGuesses" from the view state, convert it to an integer
    //   - Depending on the value to guess
    //     - Equals to the guessed number
    //       - Label becomes "Congratulation"
    //       - Button is disabled, you finished the game
    //     - Is larger that the guessed number
    //       - Label becoms "too low"
    //     - Is smaller that the guessed number
    //       - Label becoms "too high"
    //   - Number of guesses is incremented
    //   - The number of guesses is shown on the screen
    //   - The number of guesses is added to the view state
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intToGuess = Convert.ToInt32(ViewState["intToGuess"]);
      int intNumber = Convert.ToInt32(txtGuess.Text);
      int intNumberOfGuesses = Convert.ToInt32(ViewState["intNumberOfGuesses"]);

      if (intToGuess == intNumber)
      {
        lblInfo.Text = "Congratulations";
        cmdGuess.Enabled = false;
      }
      else if (intToGuess > intNumber)
      // intToGuess <> intNumber
      {
        lblInfo.Text = "The number is too low";
      }
      else
      // intToGuess < intNumber
      {
        lblInfo.Text = "The number is too high";
      }

      intNumberOfGuesses += 1;
      lblNumberOfGuesses.Text = "NumberOfGuesses: " + intNumberOfGuesses.ToString();
      ViewState.Add("intNumberOfGuesses", intNumberOfGuesses);
    }
    // cmdGuess_Click(System.Object, System.EventArgs) Handles cmdGuess.Click

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - If IsPostBack
    //     - Do nothing
    //   - If not
    //     - Get a random number
    //     - The random number is added to the view state
    //     - The number of guesses is added to the view state with value 0
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (IsPostBack)
      {
      }
      else
      // Not IsPostBack 
      {
        Random rndGuess = new Random();
        int intToGuess = rndGuess.Next(1, 100);

        ViewState.Add("intToGuess", intToGuess);
        ViewState.Add("intNumberOfGuesses", 0);
      }
      // IsPostBack 

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmGuess

}
// CopyPaste.Learning