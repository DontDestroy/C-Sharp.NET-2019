//***
// Action
//   - Test checkbox controls
// Created
//   - CopyPaste � 20240119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240119 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmCheckBox: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblText;
    internal System.Windows.Forms.CheckBox chkJScript;
    internal System.Windows.Forms.CheckBox chkVB;
    internal System.Windows.Forms.CheckBox chkC;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCheckBox));
      this.lblText = new System.Windows.Forms.Label();
      this.chkJScript = new System.Windows.Forms.CheckBox();
      this.chkVB = new System.Windows.Forms.CheckBox();
      this.chkC = new System.Windows.Forms.CheckBox();
      this.SuspendLayout();
      // 
      // lblText
      // 
      this.lblText.Location = new System.Drawing.Point(38, 180);
      this.lblText.Name = "lblText";
      this.lblText.Size = new System.Drawing.Size(224, 56);
      this.lblText.TabIndex = 7;
      // 
      // chkJScript
      // 
      this.chkJScript.Location = new System.Drawing.Point(30, 116);
      this.chkJScript.Name = "chkJScript";
      this.chkJScript.Size = new System.Drawing.Size(144, 24);
      this.chkJScript.TabIndex = 6;
      this.chkJScript.Text = "JScript .Net";
      this.chkJScript.ThreeState = true;
      this.chkJScript.Click += new System.EventHandler(this.CheckBox_Click);
      // 
      // chkVB
      // 
      this.chkVB.Location = new System.Drawing.Point(30, 76);
      this.chkVB.Name = "chkVB";
      this.chkVB.Size = new System.Drawing.Size(136, 24);
      this.chkVB.TabIndex = 5;
      this.chkVB.Text = "Visual Basic .Net";
      this.chkVB.ThreeState = true;
      this.chkVB.Click += new System.EventHandler(this.CheckBox_Click);
      // 
      // chkC
      // 
      this.chkC.Location = new System.Drawing.Point(30, 36);
      this.chkC.Name = "chkC";
      this.chkC.TabIndex = 4;
      this.chkC.Text = "C# ";
      this.chkC.ThreeState = true;
      this.chkC.Click += new System.EventHandler(this.CheckBox_Click);
      // 
      // frmCheckBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.lblText);
      this.Controls.Add(this.chkJScript);
      this.Controls.Add(this.chkVB);
      this.Controls.Add(this.chkC);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCheckBox";
      this.Text = "CheckBox";
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmCheckBox'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240119 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � yyy20240119ymmdd � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmCheckBox()
			//***
			// Action
			//   - Create instance of 'frmCheckBox'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240119 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240119 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmCheckBox()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"
    
    private void CheckBox_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Depending on what checkbox is checked, set 'lblText'.'Text' to a value
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - CheckState System.Windows.Forms.CheckBox.CheckState (Get)
      //   - CheckState System.Windows.Forms.CheckState.Indeterminate()
      // Created
      //   - CopyPaste � 20080701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20080701 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblText.Text = "Choices: ";
      
      if (chkC.Checked)
      {
        lblText.Text += " " + chkC.Text;
      }
      else
        // Not chkC.Checked
      {
      }
      // chkC.Checked

      if (chkC.CheckState == CheckState.Indeterminate)
      {
        lblText.Text += " (Intermediate) ";
      }
      else
        // chkC.CheckState <> CheckState.Indeterminate 
      {
      }
      // chkC.CheckState = CheckState.Indeterminate 

      if (chkVB.Checked)
      {
        lblText.Text += " " + chkVB.Text;
      }
      else
        // Not chkVB.Checked
      {
      }
      // chkVB.Checked

      if (chkVB.CheckState == CheckState.Indeterminate)
      {
        lblText.Text += " (Intermediate) ";
      }
      else
        // chkVB.CheckState <> CheckState.Indeterminate 
      {
      }
      // chkVB.CheckState = CheckState.Indeterminate 

      if (chkJScript.Checked)
      {
        lblText.Text += " " + chkJScript.Text;
      }
      else
        // Not chkJScript.Checked
      {
      }
      // chkJScript.Checked

      if (chkJScript.CheckState == CheckState.Indeterminate)
      {
        lblText.Text += " (Intermediate) ";
      }
      else
        // chkJScript.CheckState <> CheckState.Indeterminate 
      {
      }
      // chkJScript.CheckState = CheckState.Indeterminate 
    
      lblText.Refresh();
    }
    // CheckBox_Click(System.Object theSender, System.EventArgs theEventArguments) Handles  chkC.Click, chkVB.Click, chkJScript.Click

		#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmCheckBox
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmCheckBox()
			// Created
			//   - CopyPaste � yyyymmdd � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � yyyymmdd � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmCheckBox());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmCheckBox

}
// CopyPaste.Learning