﻿//***
// Action
//   - Definition of a Lecturer class
// Created
//   - CopyPaste – 20221211 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20221211 – VVDW
// Proposal (To Do)
//   -
//***

using static CopyPaste.Learning.cpProgram;

namespace CopyPaste.Learning
{

  public class cpLecturer: cpPerson
  {

    #region "Constructors / Destructors"

    public cpLecturer() : base()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - 
    // Calls
    //   - cpPerson()
    // Created
    //   - CopyPaste – 20221211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20221211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpLecturer()
     
    public cpLecturer((string strFirstName, string strLastName, int intAge) thePersonDetails, string strEmployeeNumber, cpUniversityCourses theCourseSpecialization, DateTime dtmEmployed) : this()
    //***
    // Action
    //   - Constructor with 3 parameters
    //     - thePersonDetails: A tuple with the personal details firstname, lastname and age
    //     - strEmployeeNumber: The employee number
    //     - theCourseSpecialization: The course specialization of the lecturer
    //     - dtmEmployed: The date the lecturer was employed
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpStudent()
    //   - FirstName(string) (Set)
    //   - LastName(string) (Set)
    //   - Age(int) (Set)
    //   - StudentNumber(string) (Set)
    //   - EnrolledForCourse(cpUniversityCourses) (Set)
    // Created
    //   - CopyPaste – 20221211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20221211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Age = thePersonDetails.intAge;
      CourseSpecialization = theCourseSpecialization;
      DateEmployed = dtmEmployed;
      EmployeeNumber = strEmployeeNumber;
      FirstName = thePersonDetails.strFirstName;
      LastName = thePersonDetails.strLastName;
    }
    // cpLecturer(string, string, int), string, cpUniversityCourses, DateTime)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public cpUniversityCourses CourseSpecialization { get; }
    public DateTime DateEmployed { get; }
    public string EmployeeNumber { get; }

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public (string strFullName, string strEmployeeNumber, string strSpecialCourse, int intTotalDayesEmployed) LecturerDetails()
    //***
    // Action
    //   - Return information about the lecturer
    //     - A tuple of three strings and an integer is used
    // Called by
    //   - cpPatternMatching.GetPersonCourseBeforeCSharp07(System.Object)
    //   - cpPatternMatching.GetPersonCourseIsTypePattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchPattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchPatternNull(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchWhenPattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchWhenPatternExclusion(System.Object)
    // Calls
    //   - cpUniversityCourses CourseSpecialization (Get)
    //   - string EmployeeNumber (Get)
    //   - string FirstName (Get)
    //   - string LastName (Get)
    // Created
    //   - CopyPaste – 20221211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20221211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      double dblLengthOfServiceInDays;

      dblLengthOfServiceInDays = DateTime.Now.Subtract(DateEmployed).TotalDays;
      (string, string, string, int) lecturerDetails = ($"{FirstName} {LastName}", EmployeeNumber, CourseSpecialization.ToString(), Convert.ToInt32(dblLengthOfServiceInDays));

      return lecturerDetails;
    }
    // (string, string, string, int) LecturerDetails()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpLecturer

}
// CopyPaste.Learning