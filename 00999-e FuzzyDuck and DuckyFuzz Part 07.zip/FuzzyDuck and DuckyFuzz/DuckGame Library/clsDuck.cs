﻿//***
// Action
//   - Implementation of a cpDuck
//     - All ducks swim
//     - Display (how do I look like) is an abstract method
//       - All class that inherit must implement the Display method
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
//     - All ducks can have an implementation of walking and making some noise
//       - This is done thru delegates and events
//       - Meaning, that the functionality is outside the class of cpDuck
// Created
//   - CopyPaste – 20240725 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240725 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Duck.Library
{

	public abstract class cpDuck
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpDuck
		/// </summary>
		public cpDuck()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - cpDecoyDuck()
		//   - cpMallardDuck()
		//   - cpPlasticRubberDuck()
		//   - cpRedHeadDuck()
		//   - cpWoodDuck()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		public event cpDelegateFly PerformFly;
		// Fly()
		public event cpDelegateMakeNoise PerformMakeNoise;
		// MakeNoise()
		public event cpDelegateWalk PerformWalk;
		// Walk()

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		#region "Event"

		public delegate void cpDelegateFly();
		public delegate void cpDelegateMakeNoise();
		public delegate void cpDelegateWalk();

		#endregion

		#region "Sub / Function"

		/// <summary>
		/// The visualization (displaying) of a cpDuck
		/// </summary>
		public abstract void Display();
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()

		/// <summary>
		/// Define how the cpDuck moves in the air
		/// </summary>
		public void Fly()
		//***
		// Action
		//   - If PerformFly is null
		//     - Do nothing
		//   - If Not
		//     - Execute PerformFly
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - PerformFly()
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformFly == null)
			{
			}
			else
			// PerformFly <> null
			{
				PerformFly();
			}
			// PerformFly = null

		}
		// Fly()

		/// <summary>
		/// Define how the cpDuck makes some noise
		/// </summary>
		public void MakeNoise()
		//***
		// Action
		//   - If PerformMakeNoise is null
		//     - Do nothing
		//   - If Not
		//     - Execute PerformMakeNoise
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - PerformMakeNoise()
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformMakeNoise == null)
			{
			}
			else
			// PerformMakeNoise <> null
			{
				PerformMakeNoise();
			}
			// PerformMakeNoise = null

		}
		// PerformMakeNoise()

		/// <summary>
		/// How is a cpDuck moving on water
		/// </summary>
		public virtual void Swim()
		//***
		// Action
		//   - Define how the cpDuck moves in water
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("cpDuck is moving around in water");
		}
		// Swim()

		/// <summary>
		/// Define how the cpDuck makes some noise
		/// </summary>
		public void Walk()
		//***
		// Action
		//   - If PerformWalk is null
		//     - Do nothing
		//   - If Not
		//     - Execute PerformWalk
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - PerformWalk()
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformWalk == null)
			{
			}
			else
			// PerformWalk <> null
			{
				PerformWalk();
			}
			// PerformWalk = null

		}
		// PerformWalk()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpDuck

}
// CopyPaste.Game.Duck.Library