//***
// Action
//   - Example of a link label
// Created
//   - CopyPaste � 20240215 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240215 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmLinkLabel: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtPublisher;
    internal System.Windows.Forms.Label lblPublisher;
    internal System.Windows.Forms.LinkLabel lnlWebsite;
    internal System.Windows.Forms.TextBox txtAuthor;
    internal System.Windows.Forms.Label lblAuthor;
    internal System.Windows.Forms.TextBox txtTitle;
    internal System.Windows.Forms.Label lblTitle;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmLinkLabel));
      this.txtPublisher = new System.Windows.Forms.TextBox();
      this.lblPublisher = new System.Windows.Forms.Label();
      this.lnlWebsite = new System.Windows.Forms.LinkLabel();
      this.txtAuthor = new System.Windows.Forms.TextBox();
      this.lblAuthor = new System.Windows.Forms.Label();
      this.txtTitle = new System.Windows.Forms.TextBox();
      this.lblTitle = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // txtPublisher
      // 
      this.txtPublisher.Location = new System.Drawing.Point(134, 120);
      this.txtPublisher.Name = "txtPublisher";
      this.txtPublisher.ReadOnly = true;
      this.txtPublisher.Size = new System.Drawing.Size(136, 20);
      this.txtPublisher.TabIndex = 12;
      this.txtPublisher.Text = "McGraw-Hill/Osborne";
      // 
      // lblPublisher
      // 
      this.lblPublisher.Location = new System.Drawing.Point(26, 120);
      this.lblPublisher.Name = "lblPublisher";
      this.lblPublisher.TabIndex = 11;
      this.lblPublisher.Text = "Publisher:";
      // 
      // lnlWebsite
      // 
      this.lnlWebsite.Location = new System.Drawing.Point(26, 168);
      this.lnlWebsite.Name = "lnlWebsite";
      this.lnlWebsite.Size = new System.Drawing.Size(180, 23);
      this.lnlWebsite.TabIndex = 13;
      this.lnlWebsite.TabStop = true;
      this.lnlWebsite.Text = "View Publisher Web Site";
      this.lnlWebsite.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnlWebsite_LinkClicked);
      // 
      // txtAuthor
      // 
      this.txtAuthor.Location = new System.Drawing.Point(134, 80);
      this.txtAuthor.Name = "txtAuthor";
      this.txtAuthor.ReadOnly = true;
      this.txtAuthor.Size = new System.Drawing.Size(136, 20);
      this.txtAuthor.TabIndex = 10;
      this.txtAuthor.Text = "Jamsa";
      // 
      // lblAuthor
      // 
      this.lblAuthor.Location = new System.Drawing.Point(26, 80);
      this.lblAuthor.Name = "lblAuthor";
      this.lblAuthor.TabIndex = 9;
      this.lblAuthor.Text = "Author:";
      // 
      // txtTitle
      // 
      this.txtTitle.Location = new System.Drawing.Point(134, 40);
      this.txtTitle.Name = "txtTitle";
      this.txtTitle.ReadOnly = true;
      this.txtTitle.Size = new System.Drawing.Size(256, 20);
      this.txtTitle.TabIndex = 8;
      this.txtTitle.Text = "Visual Basic .Net Programming Tips & Techniques";
      // 
      // lblTitle
      // 
      this.lblTitle.Location = new System.Drawing.Point(26, 40);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.TabIndex = 7;
      this.lblTitle.Text = "Title:";
      // 
      // frmLinkLabel
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(416, 213);
      this.Controls.Add(this.txtPublisher);
      this.Controls.Add(this.lblPublisher);
      this.Controls.Add(this.lnlWebsite);
      this.Controls.Add(this.txtAuthor);
      this.Controls.Add(this.lblAuthor);
      this.Controls.Add(this.txtTitle);
      this.Controls.Add(this.lblTitle);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmLinkLabel";
      this.Text = "Link Label";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmLinkLabel'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmLinkLabel()
      //***
      // Action
      //   - Create instance of 'frmLinkLabel'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmLinkLabel()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void lnlWebsite_LinkClicked(System.Object theSender, System.Windows.Forms.LinkLabelLinkClickedEventArgs theLinkLabelLinkClickedEventArguments)
      //***
      // Action
      //   - Try to start a browser and a specific website
      //   - On fail, a message is shown
      // Called by
      //   - User action (Clicking on a link)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        Process.Start("msedge", "www.Osborne.com");
      }
      catch
      {
        MessageBox.Show("Error launching Internet Explorer");
      }
      finally
      {
      }
    
    }
    // lnlWebsite_LinkClicked(System.Object, System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnlWebsite.LinkClicked

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmLinkLabel
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240215 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmLinkLabel());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmLinkLabel

}
// CopyPaste.Learning