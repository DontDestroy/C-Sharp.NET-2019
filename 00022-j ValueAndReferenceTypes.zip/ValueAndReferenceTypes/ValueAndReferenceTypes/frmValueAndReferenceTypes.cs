//***
// Action
//   - 
// Created
//   - CopyPaste � yyyymmdd � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � yyyymmdd � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmValueAndReferenceTypes: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.GroupBox grpReference;
    internal System.Windows.Forms.Button cmdStringReference;
    internal System.Windows.Forms.Button cmdArray;
    internal System.Windows.Forms.Button cmdClass;
    internal System.Windows.Forms.GroupBox grpValue;
    internal System.Windows.Forms.Button cmdStringValue;
    internal System.Windows.Forms.Button cmdVariable;
    internal System.Windows.Forms.Button cmdStructure;
    internal System.Windows.Forms.Label lblMicrosoft;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmValueAndReferenceTypes));
      this.grpReference = new System.Windows.Forms.GroupBox();
      this.cmdStringReference = new System.Windows.Forms.Button();
      this.cmdArray = new System.Windows.Forms.Button();
      this.cmdClass = new System.Windows.Forms.Button();
      this.grpValue = new System.Windows.Forms.GroupBox();
      this.cmdStringValue = new System.Windows.Forms.Button();
      this.cmdVariable = new System.Windows.Forms.Button();
      this.cmdStructure = new System.Windows.Forms.Button();
      this.lblMicrosoft = new System.Windows.Forms.Label();
      this.grpReference.SuspendLayout();
      this.grpValue.SuspendLayout();
      this.SuspendLayout();
      // 
      // grpReference
      // 
      this.grpReference.Controls.Add(this.cmdStringReference);
      this.grpReference.Controls.Add(this.cmdArray);
      this.grpReference.Controls.Add(this.cmdClass);
      this.grpReference.Location = new System.Drawing.Point(152, 12);
      this.grpReference.Name = "grpReference";
      this.grpReference.Size = new System.Drawing.Size(120, 144);
      this.grpReference.TabIndex = 4;
      this.grpReference.TabStop = false;
      this.grpReference.Text = "Reference";
      // 
      // cmdStringReference
      // 
      this.cmdStringReference.Location = new System.Drawing.Point(24, 104);
      this.cmdStringReference.Name = "cmdStringReference";
      this.cmdStringReference.TabIndex = 2;
      this.cmdStringReference.Text = "String ??";
      this.cmdStringReference.Click += new System.EventHandler(this.cmdStringReference_Click);
      // 
      // cmdArray
      // 
      this.cmdArray.Location = new System.Drawing.Point(24, 24);
      this.cmdArray.Name = "cmdArray";
      this.cmdArray.TabIndex = 0;
      this.cmdArray.Text = "Array";
      this.cmdArray.Click += new System.EventHandler(this.cmdArray_Click);
      // 
      // cmdClass
      // 
      this.cmdClass.Location = new System.Drawing.Point(24, 56);
      this.cmdClass.Name = "cmdClass";
      this.cmdClass.TabIndex = 1;
      this.cmdClass.Text = "Class";
      this.cmdClass.Click += new System.EventHandler(this.cmdClass_Click);
      // 
      // grpValue
      // 
      this.grpValue.Controls.Add(this.cmdStringValue);
      this.grpValue.Controls.Add(this.cmdVariable);
      this.grpValue.Controls.Add(this.cmdStructure);
      this.grpValue.Location = new System.Drawing.Point(16, 12);
      this.grpValue.Name = "grpValue";
      this.grpValue.Size = new System.Drawing.Size(120, 144);
      this.grpValue.TabIndex = 3;
      this.grpValue.TabStop = false;
      this.grpValue.Text = "Value";
      // 
      // cmdStringValue
      // 
      this.cmdStringValue.Location = new System.Drawing.Point(24, 104);
      this.cmdStringValue.Name = "cmdStringValue";
      this.cmdStringValue.TabIndex = 2;
      this.cmdStringValue.Text = "String ??";
      this.cmdStringValue.Click += new System.EventHandler(this.cmdStringValue_Click);
      // 
      // cmdVariable
      // 
      this.cmdVariable.Location = new System.Drawing.Point(23, 24);
      this.cmdVariable.Name = "cmdVariable";
      this.cmdVariable.TabIndex = 0;
      this.cmdVariable.Text = "Variable";
      this.cmdVariable.Click += new System.EventHandler(this.cmdVariable_Click);
      // 
      // cmdStructure
      // 
      this.cmdStructure.Location = new System.Drawing.Point(24, 56);
      this.cmdStructure.Name = "cmdStructure";
      this.cmdStructure.TabIndex = 1;
      this.cmdStructure.Text = "Structure";
      this.cmdStructure.Click += new System.EventHandler(this.cmdStructure_Click);
      // 
      // lblMicrosoft
      // 
      this.lblMicrosoft.Font = new System.Drawing.Font("Microsoft Sans Serif", 3F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblMicrosoft.Location = new System.Drawing.Point(16, 164);
      this.lblMicrosoft.Name = "lblMicrosoft";
      this.lblMicrosoft.Size = new System.Drawing.Size(256, 96);
      this.lblMicrosoft.TabIndex = 5;
      this.lblMicrosoft.DoubleClick += new System.EventHandler(this.lblMicrosoft_DoubleClick);
      // 
      // frmValueAndReferenceTypes
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.grpReference);
      this.Controls.Add(this.grpValue);
      this.Controls.Add(this.lblMicrosoft);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmValueAndReferenceTypes";
      this.Text = "Value and Reference type";
      this.grpReference.ResumeLayout(false);
      this.grpValue.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmValueAndReferenceTypes'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmValueAndReferenceTypes()
      //***
      // Action
      //   - Create instance of 'frmValueAndReferenceTypes'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      lblMicrosoft.Text = "Microsoft : " + Environment.NewLine + Environment.NewLine + "An instance of String is \"immutable\" because its value cannot be modified once it has been created. Methods that appear to modify a String actually return a new instance of String containing the modification.";
    }
    // frmValueAndReferenceTypes()

    #endregion

    //#region "Designer"
    //#endregion

    #region "Structures"

    public struct cpStructure
    {
      public byte bytAge;
    }

    #endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdArray_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Two variables of data type Byte in an array with assignment
      //   - Values at the end are shown
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      byte[] arrbytAge01 = new byte[3];
      byte[] arrbytAge02 = new byte[3];

      arrbytAge01[0] = 20;
      arrbytAge02 = arrbytAge01;
      arrbytAge02[0] = 30;

      MessageBox.Show("Age01 = " + arrbytAge01[0] + " - Age02 = " + arrbytAge02[0]);
    }
    // cmdArray_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdArray.Click

    private void cmdClass_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Two variables of data type cpClass with assignment
      //   - Values at the end are shown
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpClass()
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpClass theClass01;
      cpClass theClass02;

      theClass01 = new cpClass();
      theClass01.mbytAge = 20;
      theClass02 = theClass01;
      theClass02.mbytAge = 30;

      MessageBox.Show("Age01 = " + theClass01.mbytAge + " - Age02 = " + theClass02.mbytAge);    
    }
    // cmdClass_Click(theSender, theEventArguments) Handles cmdClass.Click

    private void cmdStringReference_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Two variables of data type string with assignment
      //   - Values at the end are shown
      //   - Set one value to nothing
      //   - Values at the end are shown
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strAge01;
      string strAge02;

      strAge01 = "Age 20";
      strAge02 = strAge01;
      MessageBox.Show("Age01 = " + strAge01 + " - Age02 = " + strAge02);
      strAge02 = "Age 30";
      strAge01 = null;
      MessageBox.Show("Age01 = " + strAge01 + " - Age02 = " + strAge02);
    }
    // cmdStringReference_Click(System.Object, System.EventArgs) Handles cmdStringReference.Click

    private void cmdStringValue_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Two variables of data type string with assignment
      //   - Values at the end are shown
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strAge01;
      string strAge02;
      
      strAge01 = "Age 20";
      strAge02 = strAge01;
      strAge02 = "Age 30";
      MessageBox.Show("Age01 = " + strAge01 + " - Age02 = " + strAge02);
    }
    // cmdStringValue_Click(System.Object, System.EventArgs) Handles cmdStringValue.Click

    private void cmdStructure_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Called
      //   - Two variables of data type cpStructure with assignment
      //   - Values at the end are shown
      // Action by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpStructure theStructure01;
      cpStructure theStructure02;

      theStructure01 = new cpStructure();
      theStructure01.bytAge = 20;
      theStructure02 = theStructure01;
      theStructure02.bytAge = 30;

      MessageBox.Show("Age01 = " + theStructure01.bytAge + " - Age02 = " + theStructure02.bytAge);
    }
    // cmdStructure_Click(System.Object, System.EventArgs) Handles cmdStructure.Click

    private void cmdVariable_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Two variables of data type byte with assignment
      //   - Values at the end are shown
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      byte bytAge01;
      byte bytAge02;
      
      bytAge01 = 20;
      bytAge02 = bytAge01;
      bytAge02 = 30;
      MessageBox.Show("Age01 = " + bytAge01 + " - Age02 = " + bytAge02);    
    }
    // cmdVariable_Click(System.Object, System.EventArgs) Handles cmdVariable.Click
    
    private void lblMicrosoft_DoubleClick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the info in a readable font
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblMicrosoft.Font = Control.DefaultFont;
    }
    // lblMicrosoft_DoubleClick(System.Object, System.EventArgs) Handles lblMicrosoft.DoubleClick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmValueAndReferenceTypes
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmValueAndReferenceTypes()
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmValueAndReferenceTypes());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmValueAndReferenceTypes

}
// CopyPaste.Learning