﻿//***
// Action
//   - Create a service that handles mocked data
//   - We fake that the data comes from a database, by creating the needed entities and lists
// Created
//   - CopyPaste – 20220907 – VVDW
// Changed
//   - CopyPaste – 20260404 – VVDW – Added three new functionalities to the mocked data
//   - CopyPaste – 20260404 – VVDW – Changed some methods into properties
// Tested
//   - CopyPaste – 20260404 – VVDW
// Proposal (To Do)
//   -
//***

using ProductCategory_WPF_MVVM.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ProductCategory_WPF_MVVM.Services
{

  public class MockDataService : IDataService
  {

    #region "Constructors / Destructors"

    public MockDataService()
    //***
    // Action
    //   - Create an instance of "MockDataService"
    //   - Fill Product Category list with actual data
    //   - Fill Product list with actual data
    // Called by
    //   - StartupViewModel()
    // Calls
    //   - FillProduct()
    //   - FillProductCategory()
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      FillProductCategory();
      FillProduct();
    }
    // MockDataService()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private IList<Product> _lstProducts;
    private IList<ProductCategory> _lstProductCategories;

    #endregion

    #region "Properties"

    public IList<ProductCategory> AllProductCategories
    {

      get
      //***
      // Action Get
      //   - Return all the product categories
      // Called by
      //   - IList<ProductCategory> AddProductCategory(ProductCategory)
      //   - IList<ProductCategory> DeleteProductCategory(ProductCategory)
      //   - ProductCategoryViewModel(IDataService)
      //   - UpdateProductCategory(ProductCategory)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260404 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260404 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _lstProductCategories;
      }
      // IList<ProductCategory> AllProductCategories (Get)

    }
    // IList<ProductCategory> AllProductCategories

    public IList<Product> AllProducts
    {

      get
      //***
      // Action Get
      //   - Return all the products
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260404 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260404 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _lstProducts;
      }
      // IList<Product> AllProducts (Get)

    }
    // IList<Product> AllProducts

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public IList<ProductCategory> AddProductCategory(ProductCategory theProductCategory)
    //***
    // Action
    //   - Add a given product category to the list
    //   - Determine the product category key, depending on the biggest number already in the list
    // Called by
    //   - ProductCategoryViewModel.AddProductCategory()
    // Calls
    //   - IList<ProductCategory> AllProductCategories (Get)
    //   - int ProductCategory.ProductCategoryId (Get)
    //   - ProductCategory.ProductCategoryId(int) (Set)
    // Created
    //   - CopyPaste – 20260404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260404 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      int intProductCategoryKey;

      if (AllProductCategories.Count > 0)
      {
        intProductCategoryKey = AllProductCategories.Max(theProductCategory => theProductCategory.ProductCategoryId) + 1;
      }
      else
      // AllProductCategories.Count = 0
      {
        intProductCategoryKey = 1;
      }
      // AllProductCategories.Count > 0

      theProductCategory.ProductCategoryId = intProductCategoryKey;
      AllProductCategories.Add(theProductCategory);

      return AllProductCategories;
    }
    // IList<ProductCategory> AddProductCategory(ProductCategory)

    public IList<ProductCategory> DeleteProductCategory(ProductCategory theProductCategory)
    //***
    // Action
    //   - Delete a given product category from the list
    //   - Select the first item in the list (if any)
    //   - Return the list
    // Called by
    //   - ProductCategoryViewModel.AddProductCategory()
    // Calls
    //   - IList<ProductCategory> AllProductCategories (Get)
    // Created
    //   - CopyPaste – 20260404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260404 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - When mocking the data, this functionality is unnecessary
    //***
    {
      AllProductCategories.Remove(theProductCategory);
      return AllProductCategories;
    }
    // IList<ProductCategory> DeleteProductCategory(ProductCategory)

    private void FillProduct()
    //***
    // Action
    //   - Fill Product list with actual data
    // Called by
    //   - MockDataService()
    // Calls
    //   - Product(int, string, DateTime, string, decimal, DateTime?, ProductCategory?)
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      Product firstProduct = new Product(1, "Extending Bootstrap with CSS, JavaScript and jQuery", new DateTime(2015, 06, 11, 00, 0, 0), "http://bit.ly/1SNzc0i", 23, null, _lstProductCategories[0]);
      Product secondProduct = new Product(2, "Build your own Bootstrap Business Application Template in MVC", new DateTime(2015, 01, 29, 00, 0, 0), "http://bit.ly/1SNzc0i", 21, null, _lstProductCategories[0]);
      Product thirdProduct = new Product(3, "Building Mobile Web Sites Using Web Forms, Bootstrap, and HTML5", new DateTime(2014, 08, 28, 00, 0, 0), "http://bit.ly/1J2dcrj", 19, null, _lstProductCategories[0]);
      Product fourthProduct = new Product(4, "How to Start and Run A Consulting Business", new DateTime(2013, 09, 12, 00, 0, 0), "http://bit.ly/1L8kOwd", 9.99M, null, null);
      Product fifthProduct = new Product(5, "The Many Approaches to XML Processing in .NET Applications", new DateTime(2013, 07, 22, 00, 0, 0), "http://bit.ly/1DBfUqd", 9, new DateTime(2019, 03, 20, 00, 0, 0), _lstProductCategories[0]);
      Product sixthProduct = new Product(6, "WPF for the Business Programmer", new DateTime(2009, 06, 12, 00, 0, 0), "http://bit.ly/1UF858z", 29, null, _lstProductCategories[0]);
      Product seventhProduct = new Product(7, "WPF for the Visual Basic Programmer - Part 1", new DateTime(2013, 12, 16, 00, 0, 0), "http://bit.ly/1uFxS7C", 29, null, _lstProductCategories[0]);
      Product eighthProduct = new Product(8, "WPF for the Visual Basic Programmer - Part 2", new DateTime(2014, 02, 18, 00, 0, 0), "http://bit.ly/1MjQ9NG", 29, null, _lstProductCategories[0]);
      Product ninethProduct = new Product(10, "Practical Team Management for Software Engineers", new DateTime(2017, 05, 19, 00, 0, 0), "http://bit.ly/2qcWO5m", 15, null, _lstProductCategories[1]);
      Product tenthProduct = new Product(11, "Leadership and Communication Skills for Software Engineers", new DateTime(2016, 05, 13, 00, 0, 0), "http://bit.ly/2aq2i4F", 15, null, _lstProductCategories[1]);
      Product eleventhProduct = new Product(12, "Best Practices for Project Estimation	", new DateTime(2014, 12, 08, 00, 0, 0), "http://bit.ly/1ulLVJK", 15, null, _lstProductCategories[1]);
      Product twelvethProduct = new Product(23, "Using PowerShell", new DateTime(2019, 05, 28, 12, 40, 3), "www.fairwaytech.com", 100, new DateTime(2019, 08, 28, 12, 40, 3), _lstProductCategories[2]);

      _lstProducts = new List<Product>();

      _lstProducts.Add(firstProduct);
      _lstProducts.Add(secondProduct);
      _lstProducts.Add(thirdProduct);
      _lstProducts.Add(fourthProduct);
      _lstProducts.Add(fifthProduct);
      _lstProducts.Add(sixthProduct);
      _lstProducts.Add(seventhProduct);
      _lstProducts.Add(eighthProduct);
      _lstProducts.Add(ninethProduct);
      _lstProducts.Add(tenthProduct);
      _lstProducts.Add(eleventhProduct);
      _lstProducts.Add(twelvethProduct);
    }
    // FillProduct()

    private void FillProductCategory()
    //***
    // Action
    //   - Fill Product Category list with actual data
    // Called by
    //   - MockDataService()
    // Calls
    //   - ProductCategory(int, string)
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      ProductCategory firstProductCategory = new ProductCategory(1, "Development");
      ProductCategory secondProductCategory = new ProductCategory(2, "Soft Skills");
      ProductCategory thirdProductCategory = new ProductCategory(4, "DevOps");

      _lstProductCategories = new List<ProductCategory>();

      _lstProductCategories.Add(firstProductCategory);
      _lstProductCategories.Add(secondProductCategory);
      _lstProductCategories.Add(thirdProductCategory);
    }
    // FillProductCategory()

    public void UpdateProductCategory(ProductCategory theProductCategory)
    //***
    // Action
    //   - Update a given product category from the list
    //   - Get what index it is in the list, change the item in the list
    // Called by
    //   - ProductCategoryViewModel.UpdateProductCategory()
    // Calls
    //   - IList<ProductCategory> AllProductCategories (Get)
    //   - int ProductCategory.Key (Get)
    // Created
    //   - CopyPaste – 20260404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260404 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intIndex = AllProductCategories.IndexOf(theProductCategory);

      if (intIndex >= 0)
      {
        AllProductCategories[intIndex] = theProductCategory;
      }
      // intIndex >= 0

    }
    // UpdateProductCategory(ProductCategory)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // MockDataService

}
// ProductCategory_WPF_MVVM.Services