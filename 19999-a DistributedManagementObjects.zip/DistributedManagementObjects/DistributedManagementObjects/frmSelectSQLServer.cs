//***
// Action
//   - Form to select a SQL Server
//     - Load the different servers
//     - Load the databases on the selected server
//     - Connect to a selected one
// Created
//   - CopyPaste � 20260717 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260717 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSelectSQLServer: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtConnectString;
    internal System.Windows.Forms.Label lblConnectionString;
    internal System.Windows.Forms.Button cmdConnect;
    internal System.Windows.Forms.Label lblDatabase;
    internal System.Windows.Forms.ListBox lstDatabase;
    internal System.Windows.Forms.Label lblSQLServer;
    internal System.Windows.Forms.ListBox lstSQLServer;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSelectSQLServer));
      this.txtConnectString = new System.Windows.Forms.TextBox();
      this.lblConnectionString = new System.Windows.Forms.Label();
      this.cmdConnect = new System.Windows.Forms.Button();
      this.lblDatabase = new System.Windows.Forms.Label();
      this.lstDatabase = new System.Windows.Forms.ListBox();
      this.lblSQLServer = new System.Windows.Forms.Label();
      this.lstSQLServer = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // txtConnectString
      // 
      this.txtConnectString.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.txtConnectString.Location = new System.Drawing.Point(8, 152);
      this.txtConnectString.Multiline = true;
      this.txtConnectString.Name = "txtConnectString";
      this.txtConnectString.Size = new System.Drawing.Size(551, 72);
      this.txtConnectString.TabIndex = 13;
      this.txtConnectString.Text = "Not Connected";
      // 
      // lblConnectionString
      // 
      this.lblConnectionString.Location = new System.Drawing.Point(8, 128);
      this.lblConnectionString.Name = "lblConnectionString";
      this.lblConnectionString.Size = new System.Drawing.Size(160, 16);
      this.lblConnectionString.TabIndex = 12;
      this.lblConnectionString.Text = "Connection String";
      // 
      // cmdConnect
      // 
      this.cmdConnect.Enabled = false;
      this.cmdConnect.Location = new System.Drawing.Point(475, 70);
      this.cmdConnect.Name = "cmdConnect";
      this.cmdConnect.Size = new System.Drawing.Size(80, 32);
      this.cmdConnect.TabIndex = 11;
      this.cmdConnect.Text = "Connect";
      this.cmdConnect.Click += new System.EventHandler(this.cmdConnect_Click);
      // 
      // lblDatabase
      // 
      this.lblDatabase.Location = new System.Drawing.Point(221, 16);
      this.lblDatabase.Name = "lblDatabase";
      this.lblDatabase.Size = new System.Drawing.Size(150, 16);
      this.lblDatabase.TabIndex = 9;
      this.lblDatabase.Text = "Databases";
      // 
      // lstDatabase
      // 
      this.lstDatabase.Location = new System.Drawing.Point(221, 40);
      this.lstDatabase.Name = "lstDatabase";
      this.lstDatabase.Size = new System.Drawing.Size(199, 82);
      this.lstDatabase.TabIndex = 10;
      this.lstDatabase.SelectedIndexChanged += new System.EventHandler(this.lstDatabase_SelectedIndexChanged);
      // 
      // lblSQLServer
      // 
      this.lblSQLServer.Location = new System.Drawing.Point(8, 16);
      this.lblSQLServer.Name = "lblSQLServer";
      this.lblSQLServer.Size = new System.Drawing.Size(104, 16);
      this.lblSQLServer.TabIndex = 7;
      this.lblSQLServer.Text = "SQL Servers";
      // 
      // lstSQLServer
      // 
      this.lstSQLServer.Location = new System.Drawing.Point(8, 40);
      this.lstSQLServer.Name = "lstSQLServer";
      this.lstSQLServer.Size = new System.Drawing.Size(207, 82);
      this.lstSQLServer.TabIndex = 8;
      this.lstSQLServer.SelectedIndexChanged += new System.EventHandler(this.lstSQLServer_SelectedIndexChanged);
      // 
      // frmSelectSQLServer
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(567, 229);
      this.Controls.Add(this.txtConnectString);
      this.Controls.Add(this.lblConnectionString);
      this.Controls.Add(this.cmdConnect);
      this.Controls.Add(this.lblDatabase);
      this.Controls.Add(this.lstDatabase);
      this.Controls.Add(this.lblSQLServer);
      this.Controls.Add(this.lstSQLServer);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSelectSQLServer";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Create a Dialog to Connect to a New Database ";
      this.Load += new System.EventHandler(this.frmSelectSQLServer_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSelectSQLServer'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSelectSQLServer()
      //***
      // Action
      //   - Create instance of 'frmSelectSQLServer'
      // Called by
      //   - 
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSelectSQLServer()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdConnect_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and create an instance of SqlClien.SqlConnection
      //   - Try to
      //     - Create the connection string with the selected server and database
      //     - Open the connection
      //     - Show the connectionstring in the form
      //   - On possible error
      //     - Mention the error
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - string cpSQLDMORoutines.BuildConnection(string, string)
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      SqlConnection cnnConnect = new SqlConnection();

      try
      {
        cnnConnect.ConnectionString = cpSQLDMORoutines.BuildConnection(lstSQLServer.SelectedItem.ToString(), lstDatabase.SelectedItem.ToString());
        cnnConnect.Open();
        txtConnectString.Text = cnnConnect.ConnectionString;
      }
      catch
      {
        txtConnectString.Text = "Error with Connection";
      }
      finally
      {
      }
    
    }
    // cmdConnect_Click(System.Object, System.EventArgs) Handles cmdConnect.Click

    private void frmSelectSQLServer_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Load the list of SQL Servers
      // Called by
      //   - User action (Starting a form)
      // Calls
      //   - cpSQLDMORoutines.LoadSQLServer(�ListBox)
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpSQLDMORoutines.LoadSQLServer(ref lstSQLServer);
    }
    // frmSelectSQLServer_Load(System.Object, System.EventArgs) Handles this.Load


    private void lstDatabase_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there are items selected
      //     - Enable the connect button
      //   - If not
      //     - Disable the connect button
      // Called by
      //   - User action (Choosing an option)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if ((lstSQLServer.SelectedItems.Count > 0) && (lstDatabase.SelectedItems.Count > 0))
      {
        cmdConnect.Enabled = true;
      }
      else
        // lstSQLServer.SelectedItems.Count <= 0 OrElse lstDatabase.SelectedItems.Count <= 0
      {
        cmdConnect.Enabled = false;
      }
      // lstSQLServer.SelectedItems.Count > 0 AndAlso lstDatabase.SelectedItems.Count > 0
    
    }
    // lstDatabase_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstDatabase.SelectedIndexChanged

    private void lstSQLServer_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there are items selected
      //     - Enable connect button
      //   - If not
      //     - Disable connect button
      //   - Get SQL databases
      // Called by
      //   - User action (Choosing an option)
      // Calls
      //   - cpSQLDMORoutines.GetSQLDatabase(string, �ListBox)
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if ((lstSQLServer.SelectedItems.Count > 0) && (lstDatabase.SelectedItems.Count > 0))
      {
        cmdConnect.Enabled = true;
      }
      else
        // lstSQLServer.SelectedItems.Count <= 0 OrElse lstDatabase.SelectedItems.Count <= 0
      {
        cmdConnect.Enabled = false;
      }
      // lstSQLServer.SelectedItems.Count > 0 AndAlso lstDatabase.SelectedItems.Count > 0

      cpSQLDMORoutines.GetSQLDatabase(lstSQLServer.SelectedItem.ToString(), ref lstDatabase);
    }
    // lstSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstSQLServer.SelectedIndexChanged
                                                                                            // 
    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSelectSQLServer

}
// CopyPaste.Learning