﻿//***
// Action
//   - Having DataViews in database actions
// Created
//   - CopyPaste – 20210818 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210818 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Forms;

namespace EditingTryout
{

  public partial class frmEditingTryout : Form
  {

    #region "Constructors / Destructors"

    public frmEditingTryout()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Fill DataSet Employee with DataAdapter
    //   - Show the info of the current row (record)
    // Called by
    //   - Main()
    // Calls
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      InitializeComponent();
    }
    // frmEditingTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmEditingTryout

}
// EditingTryout