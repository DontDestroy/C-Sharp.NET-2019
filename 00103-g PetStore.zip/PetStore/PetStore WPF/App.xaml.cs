﻿//***
// Action
//   - Starting point of the application.
//   - Fill an array with pets (cpPet)
//   - Show a WPF form and treat the actions of cpPet or derived classes
//   - Working with properties (Get and Set) and methods in several classes, that can be reused
// Created
//   - CopyPaste – 20230407 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW
// Tested
//   - CopyPaste – 20230407 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace CopyPaste.Pet
{

  public partial class App : Application
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // App 

}
// CopyPaste.Pet