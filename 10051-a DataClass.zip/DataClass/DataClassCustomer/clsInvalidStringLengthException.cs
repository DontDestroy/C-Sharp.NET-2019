﻿//***
// Action
//   - Definition of a cpInvalidStringLengthException
// Created
//   - CopyPaste – 20260117 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260117 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpInvalidStringLengthException : System.ApplicationException
  {

    #region "Constructors / Destructors"

    public cpInvalidStringLengthException(System.Int32 lngMaximumLength, string strPropertyName, string strValue) : base("The value specified, " + strValue + ", exceeds the maximum length of " + lngMaximumLength + " allowable by the " + strPropertyName + " property.")
      //***
      // Action
      //   - Create new instance of 'cpInvalidStringLengthException'
      //   - Create a message that the string is too long for a specific property
      //   - Set 'mlngMaximumLength' to given maximum length
      // Called by
      //   - cpCustomer.Address(string) (Set)
      //   - cpCustomer.City(string) (Set)
      //   - cpCustomer.CompanyName(string) (Set)
      //   - cpCustomer.ContactName(string) (Set)
      //   - cpCustomer.ContactTitle(string) (Set)
      //   - cpCustomer.Country(string) (Set)
      //   - cpCustomer.Fax(string) (Set)
      //   - cpCustomer.Phone(string) (Set)
      //   - cpCustomer.PostalCode(string) (Set)
      //   - cpCustomer.Region(string) (Set)
      // Calls
      //   - MaximumLength(System.Int32) (Set)
      // Created
      //   - CopyPaste – 20260117 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260117 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MaximumLength = lngMaximumLength;
    }
    // cpInvalidStringLengthException(System.Int32, string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private System.Int32 mlngMaximumLength;
    private System.Int32 mlngMinimumLength;

    #endregion

    #region "Properties"

    public System.Int32 MaximumLength
    {

      get
        //***
        // Action Get
        //   - Return 'mlngMaximumLength'
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20260117 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20260117 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mlngMaximumLength;
      }
      // System.Int32 MaximumLength (Get)

      set
        //***
        // Action Set
        //   - 'mlngMaximumLength' becomes value
        // Called by
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20260117 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20260117 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mlngMaximumLength = value;
      }
      // MaximumLength(System.Int32) (Set)

    }
    // System.Int32 MaximumLength

    public System.Int32 MinimumLength
    {

      get
        //***
        // Action Get
        //   - Return 'mlngMinimumLength'
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20260117 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20260117 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mlngMinimumLength;
      }
      // System.Int32 MinimumLength (Get)

    }
    // System.Int32 MinimumLength

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
		//#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpInvalidStringLengthException

}
// CopyPaste.Learning