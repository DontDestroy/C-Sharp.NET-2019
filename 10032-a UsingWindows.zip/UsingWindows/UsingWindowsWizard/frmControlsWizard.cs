//***
// Action
//   - Demo of some bound controls (Checkbox, Combobox, NumericUpDown)
// Created
//   - CopyPaste � 20260113 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260113 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmControlsWizard: System.Windows.Forms.Form
  {
    private IContainer components;

    #region Windows Form Designer generated code
    internal System.Windows.Forms.CheckBox chkDiscontinued;
    internal System.Windows.Forms.NumericUpDown nudPrice;
    internal System.Windows.Forms.Label lblUnitPrice;
    internal System.Windows.Forms.TextBox txtProductName;
    internal System.Windows.Forms.TextBox txtIdProduct;
    internal System.Windows.Forms.Label lblName;
    internal System.Windows.Forms.Label lblCategory;
    internal System.Windows.Forms.TextBox txtPosition;
    internal System.Windows.Forms.Label lblIdProduct;
    internal System.Windows.Forms.ComboBox cmbCategory;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Button cmdLast;
    internal System.Windows.Forms.Button cmdPrevious;
    private UsingWindowsWizard.dsData dsData;
    private BindingSource bdsrcCategory;
    private UsingWindowsWizard.dsDataTableAdapters.tbaCategory tbaCategory;
    private BindingSource bdsrcProductExtended;
    private UsingWindowsWizard.dsDataTableAdapters.tbaProductExtended tbaProductExtended;
    internal System.Windows.Forms.Button cmdFirst;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmControlsWizard));
      this.chkDiscontinued = new System.Windows.Forms.CheckBox();
      this.nudPrice = new System.Windows.Forms.NumericUpDown();
      this.lblUnitPrice = new System.Windows.Forms.Label();
      this.txtProductName = new System.Windows.Forms.TextBox();
      this.txtIdProduct = new System.Windows.Forms.TextBox();
      this.lblName = new System.Windows.Forms.Label();
      this.lblCategory = new System.Windows.Forms.Label();
      this.txtPosition = new System.Windows.Forms.TextBox();
      this.lblIdProduct = new System.Windows.Forms.Label();
      this.cmbCategory = new System.Windows.Forms.ComboBox();
      this.cmdNext = new System.Windows.Forms.Button();
      this.cmdLast = new System.Windows.Forms.Button();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.cmdFirst = new System.Windows.Forms.Button();
      this.dsData = new UsingWindowsWizard.dsData();
      this.bdsrcCategory = new System.Windows.Forms.BindingSource(this.components);
      this.tbaCategory = new UsingWindowsWizard.dsDataTableAdapters.tbaCategory();
      this.bdsrcProductExtended = new System.Windows.Forms.BindingSource(this.components);
      this.tbaProductExtended = new UsingWindowsWizard.dsDataTableAdapters.tbaProductExtended();
      ((System.ComponentModel.ISupportInitialize)(this.nudPrice)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCategory)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcProductExtended)).BeginInit();
      this.SuspendLayout();
      // 
      // chkDiscontinued
      // 
      this.chkDiscontinued.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.bdsrcProductExtended, "blnDiscontinued", true));
      this.chkDiscontinued.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.chkDiscontinued.Location = new System.Drawing.Point(76, 99);
      this.chkDiscontinued.Name = "chkDiscontinued";
      this.chkDiscontinued.Size = new System.Drawing.Size(104, 24);
      this.chkDiscontinued.TabIndex = 20;
      this.chkDiscontinued.Text = "Discontinued";
      // 
      // nudPrice
      // 
      this.nudPrice.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.bdsrcProductExtended, "dblUnitPrice", true));
      this.nudPrice.DecimalPlaces = 2;
      this.nudPrice.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
      this.nudPrice.Location = new System.Drawing.Point(260, 103);
      this.nudPrice.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
      this.nudPrice.Name = "nudPrice";
      this.nudPrice.Size = new System.Drawing.Size(120, 20);
      this.nudPrice.TabIndex = 22;
      // 
      // lblUnitPrice
      // 
      this.lblUnitPrice.AutoSize = true;
      this.lblUnitPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblUnitPrice.Location = new System.Drawing.Point(192, 103);
      this.lblUnitPrice.Name = "lblUnitPrice";
      this.lblUnitPrice.Size = new System.Drawing.Size(67, 13);
      this.lblUnitPrice.TabIndex = 21;
      this.lblUnitPrice.Text = "Unit Price:";
      // 
      // txtProductName
      // 
      this.txtProductName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcProductExtended, "strProductName", true));
      this.txtProductName.Location = new System.Drawing.Point(96, 67);
      this.txtProductName.Name = "txtProductName";
      this.txtProductName.Size = new System.Drawing.Size(336, 20);
      this.txtProductName.TabIndex = 19;
      // 
      // txtIdProduct
      // 
      this.txtIdProduct.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcProductExtended, "intIdProduct", true));
      this.txtIdProduct.Location = new System.Drawing.Point(96, 39);
      this.txtIdProduct.Name = "txtIdProduct";
      this.txtIdProduct.Size = new System.Drawing.Size(104, 20);
      this.txtIdProduct.TabIndex = 17;
      // 
      // lblName
      // 
      this.lblName.AutoSize = true;
      this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblName.Location = new System.Drawing.Point(8, 67);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(43, 13);
      this.lblName.TabIndex = 18;
      this.lblName.Text = "Name:";
      // 
      // lblCategory
      // 
      this.lblCategory.AutoSize = true;
      this.lblCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblCategory.Location = new System.Drawing.Point(8, 11);
      this.lblCategory.Name = "lblCategory";
      this.lblCategory.Size = new System.Drawing.Size(61, 13);
      this.lblCategory.TabIndex = 14;
      this.lblCategory.Text = "Category:";
      // 
      // txtPosition
      // 
      this.txtPosition.Location = new System.Drawing.Point(76, 135);
      this.txtPosition.Name = "txtPosition";
      this.txtPosition.Size = new System.Drawing.Size(304, 20);
      this.txtPosition.TabIndex = 25;
      this.txtPosition.Text = "Position";
      // 
      // lblIdProduct
      // 
      this.lblIdProduct.AutoSize = true;
      this.lblIdProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblIdProduct.Location = new System.Drawing.Point(8, 39);
      this.lblIdProduct.Name = "lblIdProduct";
      this.lblIdProduct.Size = new System.Drawing.Size(84, 13);
      this.lblIdProduct.TabIndex = 16;
      this.lblIdProduct.Text = "Product Key::";
      // 
      // cmbCategory
      // 
      this.cmbCategory.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCategory, "strCategoryName", true));
      this.cmbCategory.DataSource = this.dsData;
      this.cmbCategory.DisplayMember = "tblCPCategory.strCategoryName";
      this.cmbCategory.Location = new System.Drawing.Point(96, 11);
      this.cmbCategory.Name = "cmbCategory";
      this.cmbCategory.Size = new System.Drawing.Size(121, 21);
      this.cmbCategory.TabIndex = 15;
      this.cmbCategory.ValueMember = "tblCPCategory.intIdCategory";
      // 
      // cmdNext
      // 
      this.cmdNext.Location = new System.Drawing.Point(388, 135);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(32, 23);
      this.cmdNext.TabIndex = 26;
      this.cmdNext.Text = ">";
      this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
      // 
      // cmdLast
      // 
      this.cmdLast.Location = new System.Drawing.Point(420, 135);
      this.cmdLast.Name = "cmdLast";
      this.cmdLast.Size = new System.Drawing.Size(32, 23);
      this.cmdLast.TabIndex = 27;
      this.cmdLast.Text = ">>|";
      this.cmdLast.Click += new System.EventHandler(this.cmdLast_Click);
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Location = new System.Drawing.Point(36, 135);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(32, 23);
      this.cmdPrevious.TabIndex = 24;
      this.cmdPrevious.Text = "<";
      this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
      // 
      // cmdFirst
      // 
      this.cmdFirst.Location = new System.Drawing.Point(4, 135);
      this.cmdFirst.Name = "cmdFirst";
      this.cmdFirst.Size = new System.Drawing.Size(32, 23);
      this.cmdFirst.TabIndex = 23;
      this.cmdFirst.Text = "|<<";
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // bdsrcCategory
      // 
      this.bdsrcCategory.DataMember = "tblCPCategory";
      this.bdsrcCategory.DataSource = this.dsData;
      // 
      // tbaCategory
      // 
      this.tbaCategory.ClearBeforeFill = true;
      // 
      // bdsrcProductExtended
      // 
      this.bdsrcProductExtended.DataMember = "ProductExtended";
      this.bdsrcProductExtended.DataSource = this.dsData;
      // 
      // tbaProductExtended
      // 
      this.tbaProductExtended.ClearBeforeFill = true;
      // 
      // frmControlsWizard
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(456, 169);
      this.Controls.Add(this.txtProductName);
      this.Controls.Add(this.txtIdProduct);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.lblCategory);
      this.Controls.Add(this.txtPosition);
      this.Controls.Add(this.lblIdProduct);
      this.Controls.Add(this.cmbCategory);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.cmdLast);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.cmdFirst);
      this.Controls.Add(this.chkDiscontinued);
      this.Controls.Add(this.nudPrice);
      this.Controls.Add(this.lblUnitPrice);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmControlsWizard";
      this.Text = "Windows Controls Wizard";
      ((System.ComponentModel.ISupportInitialize)(this.nudPrice)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCategory)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcProductExtended)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmControlsWizard'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmControlsWizard()
      //***
      // Action
      //   - Create new instance of 'frmControlsWizard'
      //   - Fill the data set tblCPCategory with data adapter category
      //   - Fill the data set ProductExtended with data adapter product
      //   - Update the display
      //   - The data source for the combo box becomes the data set
      //   - The selected item for the combo box is the product extented category key
      // Called by
      //   - frmMaster.cmdControls_Click(System.Object, System.EventArgs) Handles cmdControls.Click
      // Calls
      //   - InitializeComponent()
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
      tbaCategory.Fill(dsData.tblCPCategory);
      tbaProductExtended.Fill(dsData.ProductExtended);
      UpdateDisplay();
      cmbCategory.DataBindings.Add("SelectedValue", bdsrcProductExtended, "intCategoryId");
    }
    // frmControlsWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFirst_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the first position
      //   - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcProductExtended.Position = 0;
      UpdateDisplay();
    }
    // cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click

    private void cmdLast_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the last position
      //   - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcProductExtended.Position = tbaProductExtended.GetData().Count - 1;
      UpdateDisplay();
    }
    // cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click

    private void cmdNext_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If you are at the last position
      //     - Do nothing
      //   - If not
      //     - Go to the next position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcProductExtended.Position += 1;
      UpdateDisplay();
    }
    // cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click

    private void cmdPrevious_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If you are at the first position
      //     - Do nothing
      //   - If not
      //     - Go to the previous position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcProductExtended.Position -= 1;
      UpdateDisplay();
    }
    // cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void UpdateDisplay()
      //***
      // Action
      //   - Define a binding manager base
      //   - Assign the binding manager base to the data table ProductExtended from the data set
      //   - Show the current position
      // Called by
      //   - cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click
      //   - cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click
      //   - cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click
      //   - cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click
      //   - frmControlsWizard()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtPosition.Text = "Product " + (bdsrcProductExtended.Position + 1).ToString() +
        " of " + tbaProductExtended.GetData().Count.ToString();
    }
    // UpdateDisplay()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmControlsWizard

}
// CopyPaste.Learning