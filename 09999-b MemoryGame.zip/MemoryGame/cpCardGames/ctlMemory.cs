//***
// Action
//   - Implementation of a memory grid, with visualisation as a control
// Created
//   - CopyPaste � 20240310 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240310 � VVDW
// Proposal (To Do)
//   - Only references between cpctlCard, cpctlDeck, cpctlMemory, cpDeckGirdIncompatibilityException and cpGameOverEvent are documented
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace CopyPaste.CardGames
{

  // This event is the default event when you double click on the control
  [DefaultEventAttribute("GameOver")]
  public class cpctlMemory : System.Windows.Forms.UserControl
  {

    #region Component Designer generated code

    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      this.Name = "cpctlMemory";
    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpctlMemory'
      // Called by
      //   - User action (Closing the control)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpctlMemory()
      //***
      // Action
      //   - Create new instance of 'cpctlMemory'
      // Called by
      //   - User action (Starting the control)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // cpctlMemory()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpcmpDeck mcpDeck;
    public event GameOverHandler GameOver;
    // CardOver(System.Object, System.EventArgs)
    private int mlngClicks = 0;
    private int mlngColumns = 2;
    private int mlngRows = 2;
    private const int mlngSpacing = 10;

    #endregion

    #region "Properties"

    // This property will be shown in the category "Game" with a specific attribute
    [CategoryAttribute("Game"), DescriptionAttribute("Number of columns in the grid.")]
    public int Columns
    {

      get
        //***
        // Action Get
        //   - Returns mlngColumns
        // Called by
        //   - OnPaint(System.Windows.Forms.PaintEventArgs)
        //   - Play()
        //   - User action (as property of a control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240310 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240310 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mlngColumns;
      }
      // int Columns (Get)

      set
        //***
        // Action Set
        //   - If value is larger than zero
        //     - mlngColumns becomes value
        //     - Visualisation is refreshed
        // Called by
        //   - User action (as property of a control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240310 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240310 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (value > 0)
        {
          mlngColumns = value;
          this.Refresh();
        }
        else
          // value <= 0
        {
        }
        // value > 0

      }
      // Columns(int) (Set)

    }
    // int Columns

    // This property will be shown in the category "Game" with a specific attribute
    [CategoryAttribute("Game"), DescriptionAttribute("The deck to play with.")]
    public cpcmpDeck Deck
    {

      get
        //***
        // Action Get
        //   - Returns mcpDeck
        // Called by
        //   - User action (as property of a control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240310 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240310 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mcpDeck;
      }
      // cpcmpDeck Deck (Get)

      set
        //***
        // Action Set
        //   - mcpDeck becomes value
        // Called by
        //   - User action (as property of a control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240310 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240310 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mcpDeck = value;
      }
      // Deck(cpcmpDeck) (Set)

    }
    // cpcmpDeck Deck

    // This property will be shown in the category "Game" with a specific attribute
    [CategoryAttribute("Game"), DescriptionAttribute("Number of rows in the grid.")]
    public int Rows
    {

      get
        //***
        // Action Get
        //   - Returns mlngRows
        // Called by
        //   - OnPaint(System.Windows.Forms.PaintEventArgs)
        //   - Play()
        //   - User action (as property of a control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240310 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240310 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mlngRows;
      }
      // int Rows (Get)

      set
        //***
        // Action Set
        //   - If value is larger than zero
        //     - mlngRows becomes value
        //     - Visualisation is refreshed
        // Called by
        //   - User action (as property of a control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240310 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240310 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (value > 0)
        {
          mlngRows = value;
          this.Refresh();
        }
        else
          // value <= 0
        {
        }
        // value > 0

      }
      // Rows(int) (Set)

    }
    // int Rows

    #endregion

    #region "Methods"

    #region "Overrides"

    protected override void OnPaint(System.Windows.Forms.PaintEventArgs thePaintEventArguments)
      //***
      // Action
      //   - Visualise the memory control
      //   - Calculate the width, depending on the number of columns
      //   - Calculate the height, depending on the number of rows
      //   - For every row
      //     - For every column
      //       - Draw placeholder
      // Called by
      //   - System action (Drawing the memory)
      // Calls
      //   - int Columns (Get)
      //   - int Rows (Get)
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Graphics theGraphics = CreateGraphics();
      int lngColumn;
      int lngHeight = cpctlCard.mlngFixedHeight;
      int lngRow;
      int lngWidth = cpctlCard.mlngFixedWidth;

      Width = (lngWidth + mlngSpacing) * Columns + mlngSpacing;
      Height = (lngHeight + mlngSpacing) * Rows + mlngSpacing;

      for (lngRow = 0; lngRow < Rows; lngRow++)
      {

        for (lngColumn = 0; lngColumn < Columns; lngColumn++)
        {
          theGraphics.DrawRectangle(System.Drawing.Pens.Gray, lngColumn * (lngWidth + mlngSpacing) + mlngSpacing, lngRow * (lngHeight + mlngSpacing) + mlngSpacing, lngWidth, lngHeight);
        }
        //lngColumn = Columns

      }
      // lngRow = Rows

    }
    // OnPaint(System.Windows.Forms.PaintEventArgs)

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate void GameOverHandler(System.Object theSender, cpGameOverEventArguments thecpGameOverEventArguments);

    #endregion

    #region "Sub / Function"

    private void CardOver(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - This method will be linked to a card click
      //   - Cards are created at design time, so AddHandler is used to handle the events
      //   - theSender is casted to a cpctlCard (the clicked card)
      //   - The clicked card is turned around
      //   - The visualisation of the turned card is adapted
      //   - Number of clicks is incremented by 1
      //   - There is a check on pairs
      //   - If all cards are gone
      //     - The event of stopping the game is raised
      // Called by
      //   - CheckForPair()
      // Calls
      //   - bool cpctlCard.FaceUp (Get)
      //   - CheckForPair()
      //   - cpctlCard.FaceUp(bool) (Set)
      //   - cpGameOverEventArguments(int)
      //   - GameOver(System.Object, cpGameOverEventArguments)
      //   - Play()
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpctlCard thecpCard = (cpctlCard)theSender;

      thecpCard.FaceUp = !thecpCard.FaceUp;
      thecpCard.Refresh();
      mlngClicks += 1;
      CheckForPair();

      if (this.Controls.Count == 0)
      {
        GameOver(this, new cpGameOverEventArguments(mlngClicks));
      }
      else
        // ths.Controls.Count <> 0
      {
      }
      // this.Controls.Count = 0

    }
    // CardOver(System.Object, System.EventArgs)

    public void CheckForPair()
      //***
      // Action
      //   - Create an array of 2 cards
      //   - Wait half a second
      //   - Loop thru all the controls (of cpctlMemory)
      //     - Cast the control as a cpctlCard
      //     - If FaceUp
      //       - Card is added to the array
      //       - lngFaceUp is incremented by 1
      //   - If lngFaceUp is 2 (two cards are face up)
      //     - If FaceValue of both cards are the same
      //       - Both cards are removed from the form
      //       - Click handlers on both cards are removed
      //       - The visualisation of memory is adapted
      //     - If Not
      //       - Both cards are turned around (face down)
      // Called by
      //   - CardOver(System.Object, System.EventArgs)
      // Calls
      //   - bool cpctlCard.FaceUp (Get)
      //   - CardOver(System.Object, System.EventArgs)
      //   - cpctlCard.FaceUp(bool) (Set)
      //   - cpFaceValue cpctlCard.FaceValue (Get)
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpctlCard[] arrcpCard = new cpctlCard[2];
      int lngCounter;
      int lngFaceUp = 0;

      Thread.Sleep(500);

      for (lngCounter = 0; lngCounter < this.Controls.Count; lngCounter++)
      {
        cpctlCard thecpCard = (cpctlCard)this.Controls[lngCounter];

        if (thecpCard.FaceUp)
        {
          arrcpCard[lngFaceUp] = thecpCard;
          lngFaceUp += 1;
        }
        else
          // Not thecpCard.FaceUp
        {
        }
        // thecpCard.FaceUp

      }
      // lngCounter = this.Controls.Count

      if (lngFaceUp == 2)
      {

        if (arrcpCard[0].FaceValue == arrcpCard[1].FaceValue)
        {
          this.Controls.Remove(arrcpCard[0]);
          this.Controls.Remove(arrcpCard[1]);

          arrcpCard[0].Click -= new System.EventHandler(this.CardOver);
          arrcpCard[1].Click -= new System.EventHandler(this.CardOver);
          this.Refresh();
        }
        else
          // arrcpCard[0].FaceValue <> arrcpCard[1].FaceValue
        {
          arrcpCard[0].FaceUp = false;
          arrcpCard[1].FaceUp = false;
        }
        // arrcpCard[0].FaceValue = arrcpCard[1].FaceValue

      }
      else
        // lngFaceUp <> 2
      {
      }
      // lngFaceUp = 2

    }
    // CheckForPair()

    public void Play()
      //***
      // Action
      //   - Play a memory game
      //   - Loop thru all controls (of cpctlMemory)
      //     - Remove all the click handlers
      //   - Remove all controls from cpctlMemory
      //   - If mcpDeck is nothing
      //     - Do nothing
      //   - If Not (there is a deck of cards)
      //     - If number of cards in deck is the same as the number placeholders in cpctlMemory
      //       - Shuffle the cards
      //       - Loop thru the rows
      //         - Loop thru the columns
      //           - Define a card by taking it from the deck
      //           - Put face down
      //           - Add a click event
      //           - Add the control to cpctlMemory
      //           - Position it on the grid
      //           - Increment the card counter by 1
      //     - If not
      //       - Throw an error message
      // Called by
      //   - 
      // Calls
      //   - CardOver(System.Object, System.EventArgs)
      //   - cpcmpDeck.Shuffle()
      //   - cpctlCard cpcmpDeck.this[int]
      //   - cpctlCard.FaceUp(bool) (Set)
      //   - cpDeckGridIncompatibilityException(string)
      //   - int Columns (Get)
      //   - int cpcmpDeck.Count (Get)
      //   - int Rows (Get)
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      foreach (Control theControl in this.Controls)
      {
        theControl.Click -= new System.EventHandler(this.CardOver);
      }
      // in this.Controls

      this.Controls.Clear();

      if (mcpDeck == null)
      {
      }
      else
        // mcpDeck <> null
      {
        int lngCardCounter = 0;
        int lngColumn;
        int lngRow;

        if (mcpDeck.Count == Rows * Columns)
        {
          mlngClicks = 0;
          mcpDeck.Shuffle();

          for (lngRow = 0; lngRow < Rows; lngRow++)
          {

            for (lngColumn = 0; lngColumn < Columns; lngColumn++)
            {
              cpctlCard thecpCard = (cpctlCard)mcpDeck[lngCardCounter];
              
              thecpCard.FaceUp = false;
              thecpCard.Click += new EventHandler(this.CardOver);
              this.Controls.Add(thecpCard);
              thecpCard.Left = lngColumn * (cpctlCard.mlngFixedWidth + mlngSpacing) + mlngSpacing;
              thecpCard.Top = lngRow * (cpctlCard.mlngFixedHeight + mlngSpacing) + mlngSpacing;
              lngCardCounter += 1;
            }
            // lngColumn = Columns
            
          }
          // lngRow = Rows
        }
        else
          // mcpDeck.Count <> Rows * Columns
        {
          throw new cpDeckGridIncompatibilityException(String.Format("Cards:{0} Cells:{1}", mcpDeck.Count, Rows * Columns));
        }
        // mcpDeck.Count = Rows * Columns

      }
      // mcpDeck = null

    }
    // Play()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpctlMemory

}
// CopyPaste.CardGames