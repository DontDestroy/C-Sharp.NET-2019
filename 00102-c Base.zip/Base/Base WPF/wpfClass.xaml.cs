﻿//***
// Action
//   - Put content of WPF form in a class
// Created
//   - CopyPaste – 20230326 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230326 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace Base_WPF
{

  public partial class wpfClass : Window
  {

    #region "Constructors / Destructors"
    public wpfClass()
    //***
    // Action
    //   - Create instance of 'wpfClass'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230326 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230326 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfClass()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCreate_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //'***
    //' Action
    //'   - Do some checks before you create a class based on the information you have typed
    //'   - Check on length 0 for first name
    //'     - Show error if it is
    //'   - Check on length 0 for last name
    //'     - Show error if it is
    //'   - Check on length 0 for book title
    //'     - Show error if it is
    //'   - Check on length 0 for email address
    //'     - Show error if it is
    //'   - If not
    //'     - Create the author
    //'     - Show a message with the author information
    //' Called by
    //'   - User action (Clicking a button)
    //' Calls
    //'   - cpAuthor(string, string, string, string)
    //' Created
    //'   - CopyPaste – 20230325 – VVDW
    //' Changed
    //'   - CopyPaste – yyyymmdd – VVDW – What changed
    //' Tested
    //'   - CopyPaste – 20230325 – VVDW
    //' Keyboard key
    //'   -
    //' Proposal (To Do)
    //'   -
    //'***
    {

      if (txtFirstName.Text.Length == 0)
      {
        MessageBox.Show("Must specify first name");
      }
      else if (txtLastName.Text.Length == 0)
      {
        MessageBox.Show("Must specify last name");
      }
      else if (txtTitle.Text.Length == 0)
      {
        MessageBox.Show("Must specify book title");
      }
      else if (txtEmail.Text.Length == 0)
      {
        MessageBox.Show("Must specify email address");
      }
      else
      // txtFirstName.Text.Length <> 0
      // txtLastName.Text.Length <> 0
      // txtTitle.Text.Length <> 0
      // txtEmail.Text.Length <> 0
      {
        cpAuthor theAuthor = new cpAuthor(txtFirstName.Text, txtLastName.Text, txtTitle.Text, txtEmail.Text);
        MessageBox.Show("Name: " + theAuthor.mstrFirstName + " " + theAuthor.mstrLastName + " - Title: " + theAuthor.mstrBookTitle + " - Email: " + theAuthor.mstrEmailAddress);
      }
      // (txtFirstName.Text.Length = 0)

    }
    // cmdCreate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCreate.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfClass

  public class cpPerson
  {

    #region "Constructors / Destructors"

    public cpPerson(string strFirstName, string strLastName)
    //***
    // Action
    //   - Creating an instance op cpPerson
    // Called by
    //   - cpAuthor(string, string, string, string)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230326 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230326 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***

    {
      mstrFirstName = strFirstName;
      mstrLastName = strLastName;
    }
    // cpPerson(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public string mstrFirstName;
    public string mstrLastName;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpPerson

  public class cpAuthor : cpPerson
  {

    #region "Constructors / Destructors"

    public cpAuthor(string strFirstName, string strLastName, string strBookTitle, string strEmailAddress) : base(strFirstName, strLastName)
    //'***
    //' Action
    //'   - Creating an instance op cpAuthor
    //' Called by
    //'   - cmdCreate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCreate.Click
    //' Calls
    //'   - cpPerson(string, string)
    //' Created
    //'   - CopyPaste – 20230326 – VVDW
    //' Changed
    //'   - CopyPaste – yyyymmdd – VVDW – What changed
    //' Tested
    //'   - CopyPaste – 20230326 – VVDW
    //' Keyboard key
    //'   - 
    //' Proposal (To Do)
    //'   - 
    //'***
    {
      mstrBookTitle = strBookTitle;
      mstrEmailAddress = strEmailAddress;
    }
    // cpAuthor(string, string, string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public string mstrBookTitle;
    public string mstrEmailAddress;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpAuthor

}
// Base_WPF