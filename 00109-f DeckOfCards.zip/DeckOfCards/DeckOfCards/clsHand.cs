//***
// Action
//   - Implementation of a hand of cards
//   - List of cards
//   - Empty constructor
//   - Constructor that receives a list of cards
//   - Indexer / default value of the cards (get a specific one)
//   - Counter of the cards
//   - Adding a card to the hand
//   - Checking if a hand contains a specific card
//   - Checking if a hand contains a specific suit and face value
//   - Remove a card
//   - Checking on pairs of a card
//     - A pair are 2 cards with the same Face Value and the same colour
//       - Heart (Harten, Hertns) and Diamond (Ruiten, Koeksn) are red
//       - Spade (Schoppen, Piekns) and Clubs (Klaver, Klavers) are black
//   - Some comments are in Dutch for clarification
//   - Some comments are in West-Flemish for clarification
// Created
//   - CopyPaste � 20240128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240128 � VVDW
// Proposal (To Do)
//   - Only references between cpCard, cpDeck, cpHand and modDeckOfCardsTests are documented
//***

using System;
using System.Collections;

namespace CopyPaste.Learning.Games
{

  public class cpHand
  {

    #region "Constructors / Destructors"

    public cpHand()
      //***
      // Action
      //   - Empty Constructor
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpHand()

    public cpHand(cpCard[] arrcpCard)
      //***
      // Action
      //   - A list of cards is used to create a hand
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      marrCard.AddRange(arrcpCard);
    }
    // cpHand(cpCard[])

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private ArrayList marrCard = new ArrayList();

    #endregion

    #region "Properties"

    public int Count
      //***
      // Action Get
      //   - Returns a the number of Cards in the Hand
      // Called by
      //   - bool Contains(cpSuit, cpFaceValue)
      //   - cpCard this[int] (Get)
      //   - cpProgram.Main()
      //   - Remove(cpSuit, cpFaceValue)
      //   - RemovePairs()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      get
      {
        return marrCard.Count;
      }
      // int Count (Get)

    }
    // int Count

    public cpCard this[int lngIndex]
    {

      get
        //***
        // Action Get
        //   - If the index is accepted (possible)
        //     - Returns a specific Card from the Hand
        //   - If Not
        //     - An error is thrown
        // Called by
        //   - bool Contains(cpSuit, cpFaceValue)
        //   - cpProgram.Main()
        //   - Remove(cpSuit, cpFaceValue)
        //   - RemovePairs()
        // Calls
        //   - int Count() (Get)
        // Created
        //   - CopyPaste � 20240128 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240128 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (lngIndex >= 0 && lngIndex < Count)
        {
          return (cpCard)marrCard[lngIndex];
        }
        else
          // lngIndex < 0 Or lngIndex >= Count
        {
          throw new ArgumentOutOfRangeException("You ask an x-th card that is not part of the hand.");
        }
        // lngIndex >= 0 And lngIndex < Count

      }
      // cpCard this[int] (Get)

    }
    // cpCard this[int]

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Add(cpCard thecpCard)
      //***
      // Action
      //   - Add a Card to the Hand
      // Called by
      //   - cpDeck.Deal(cpHand[])
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      marrCard.Add(thecpCard);
    }
    // Add(cpCard)

    public bool Contains(cpCard thecpCardToFind)
      //***
      // Action
      //   - Check if a specific Card is in the Hand
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return marrCard.Contains(thecpCardToFind);
    }
    // bool Contains(cpCard)

    public bool Contains(cpSuit thecpSuitToFind, cpFaceValue thecpFaceValueToFind)
      //***
      // Action
      //   - Check if a specific Card (using the Suit and the FaceValue) is in the Hand
      //   - Loop thru the Cards of the Hand
      //     - When found, the loop is terminated
      //       - You can use exit for
      //       - I decided to change the loop counter to a value so the loop is terminated
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - int Count (Get)
      //   - cpCard this[int] (Get)
      //   - cpFaceValue cpCard.FaceValue (Get)
      //   - cpSuit cpCard.Suit (Get)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnFound = false;
      cpCard thecpCard;
      int lngCounter;

      for (lngCounter = 0; lngCounter < Count; lngCounter++)
      {
        thecpCard = this[lngCounter];

        if (thecpCard.Suit == thecpSuitToFind && thecpCard.FaceValue == thecpFaceValueToFind)
        {
          blnFound = true;
          lngCounter = Count;
          // break;
        }
        else
          // (thecpCard.Suit <> thecpSuitToFind Or thecpCard.FaceValue <> thecpFaceValueToFind)
        {
        }
        // (thecpCard.Suit = thecpSuitToFind And thecpCard.FaceValue = thecpFaceValueToFind)

      }
      // lngCounter = Count

      return blnFound;
    }
    // bool Contains(cpSuit, cpFaceValue)

    public void Remove(cpCard thecpCardToRemove)
      //***
      // Action
      //   - Check if a specific Card is in the Hand
      //   - If so
      //     - Remove it from the Hand
      //   - Important
      //     - The Card is not returned
      // Called by
      //   - cpProgram.Main()
      //   - Remove(cpSuit, cpFaceValue)
      //   - RemovePairs()
      // Calls
      //   - bool Contains(cpCard)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (Contains(thecpCardToRemove))
      {
        marrCard.Remove(thecpCardToRemove);
      }
      else
        // Not Contains(thecpCardToRemove)
      {
      }
      // Contains(thecpCardToRemove)

    }
    // Remove(cpCard)

    public void Remove(cpSuit thecpSuitToRemove, cpFaceValue thecpFaceValueToRemove)
      //***
      // Action
      //   - Check if a specific Card (using the Suit and the FaceValue) is in the Hand
      //   - Loop thru the Cards of the Hand
      //     - When found, the loop is terminated
      //       - Remove it from the Hand
      //       - You can use exit for
      //       - I decided to change the loop counter to a value so the loop is terminated
      //   - Important
      //     - The Card is not returned
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpCard this[int] (Get)
      //   - cpCard.Remove(cpCard)
      //   - cpFaceValue cpCard.FaceValue (Get)
      //   - cpSuit cpCard.Suit (Get)
      //   - int Count (Get)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngCounter;
      cpCard thecpCard;

      for (lngCounter = 0; lngCounter < Count;  lngCounter++)
      {
        thecpCard = this[lngCounter];

        if ((thecpCard.Suit == thecpSuitToRemove && thecpCard.FaceValue == thecpFaceValueToRemove))
        {
          lngCounter = Count;
          Remove(thecpCard);
          // break;
        }
        else
          // (thecpCard.Suit <> thecpSuitToFind Or thecpCard.FaceValue <> thecpFaceValueToFind)
        {
        }
        // (thecpCard.Suit = thecpSuitToFind And thecpCard.FaceValue = thecpFaceValueToFind)

      }
      // lngCounter = Count

    }
    // Remove(cpSuit, cpFaceValue)

    public void RemovePairs()
      //***
      // Action
      //   - An empty list of Cards is created (arrNoMatches)
      //   - Loop thru the Hand
      //     - The first Card is used to compare (thecpFindMatch)
      //     - All other Cards are checked if they are a match (thecpPossibleMatch)
      //       - Compare the Face Values (of thecpFindMatch and thecpPossibleMatch)
      //       - If the Face Values match
      //         - Compare the Suits (of thecpFindMatch and thecpPossibleMatch)
      //           - Compare Clubs with Spades
      //             - If so, there is a match
      //           - Compare Spaces with Clubs
      //             - If so, there is a match
      //           - Compare Diamonds with Hearts
      //             - If so, there is a match
      //           - Compare Hearts with Diamonds
      //             - If so, there is a match
      //       - If pair is found
      //         - Both cards are removed
      //         - Loop is exited
      //     - If pair is not found
      //       - thecpFindMatch is added to arrNoMatches
      //       - thecpFindMathc is removed from the Hand
      //   - List of the Cards of the Hand becomes arrNoMatches
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpCard this[int] (Get)
      //   - cpCard.Remove(cpCard)
      //   - cpFaceValue cpCard.FaceValue(Get)
      //   - cpSuit cpCard.Suit (Get)
      //   - int Count (Get)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - A lot of alternatives are possible
      //***
    {
      ArrayList arrNoMatches = new ArrayList();
      bool blnFound;
      cpCard thecpFindMatch;
      cpCard thecpPossibleMatch;
      int lngCounter;

      while (Count > 0)
      {
        blnFound = false;
        thecpFindMatch = this[0];

        for (lngCounter = 1; lngCounter < Count; lngCounter++)
        {
          thecpPossibleMatch = this[lngCounter];

          if (thecpPossibleMatch.FaceValue == thecpFindMatch.FaceValue)
          {

            switch (thecpPossibleMatch.Suit)
            {
              case cpSuit.Clubs:
              {

                if (thecpFindMatch.Suit == cpSuit.Spades)
                {
                  blnFound = true;
                }
                else
                  // thecpFindMatch.Suit <> cpSuit.Spades
                {
                }
                // thecpFindMatch.Suit = cpSuit.Spades

                break;
              }
              case cpSuit.Spades:
              {
                
                if (thecpFindMatch.Suit == cpSuit.Clubs)
                {
                  blnFound = true;
                }
                else
                  // thecpFindMatch.Suit <> cpSuit.Clubs
                {
                }
                // thecpFindMatch.Suit = cpSuit.Clubs

                break;
              }
              case cpSuit.Diamonds:
              {
                
                if (thecpFindMatch.Suit == cpSuit.Hearts)
                {
                  blnFound = true;
                }
                else
                  // thecpFindMatch.Suit <> cpSuit.Hearts
                {
                }
                // thecpFindMatch.Suit = cpSuit.Hearts

                break;
              }
              case cpSuit.Hearts:
              {

                if (thecpFindMatch.Suit == cpSuit.Diamonds)
                {
                  blnFound = true;
                }
                else
                  // thecpFindMatch.Suit <> cpSuit.Diamonds
                {
                }
                // thecpFindMatch.Suit = cpSuit.Diamonds

                break;
              }

            }
            // thecpPossibleMatch.Suit
            
            if (blnFound)
            {
              lngCounter = Count;
              Remove(thecpFindMatch);
              Remove(thecpPossibleMatch);
              // break;
            }
            else
              // Not blnFound 
            {
            }
            // blnFound 

          }
          else
            // thecpPossibleMatch.FaceValue <> thecpFindMatch.FaceValue
          {
          }
            // thecpPossibleMatch.FaceValue = thecpFindMatch.FaceValue

        }
        // lngCounter = Count

        if (blnFound)
        {
        }
        else
          // Not blnFound
        {
          arrNoMatches.Add(thecpFindMatch);
          Remove(thecpFindMatch);
        }
        // blnFound 

      }
      // Count > 0

      marrCard = arrNoMatches;
    }
    // RemovePairs()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpHand

}
// CopyPaste.Learning.Games