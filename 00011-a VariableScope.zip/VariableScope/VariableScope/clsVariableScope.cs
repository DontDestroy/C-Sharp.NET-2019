//***
// Action
//   - Project starts here
//   - Define 3 global variables (Internal, Private, Public)
//   - Internal, Private and Public are access modifiers (when it can be accessed)
//   - Static is a declaration modifier (how it behaves)
// Created
//   - CopyPaste � 20220128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220128 � VVDW
// Proposal (To Do)
//   - There are other access and declaration modifier
//***

using System;
using System.Windows.Forms;

namespace VariableScope
{

  class cpVariableScope
	{
    internal string strModuleLevelInternal = "Module level Internal (Part 1)";
    private static string strModuleLevelPrivate = "Module level Private (Part 1)";
    public string strModuleLevelPublic = "Module level Public (Part 1)";

    static void Main()
    //***
    // Action
    //   - If 'strModuleLevelPrivate' = "Module level Private (Part 1)"
    //     - Define local variable
    //     - Show some messageboxes
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpAnotherVariableScope.strModuleLevelPublic
    //   - cpVariableScopePart2.ShowVariables()
    //   - DialogResult System.Windows.Forms.MessageBox.Show(string) 
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      if (strModuleLevelPrivate == "Module level Private (Part 1)")
      {
        cpAnotherVariableScope aAnotherVariableScope;
        cpVariableScopePart2 aVariableScopePart2;
        string strBlockLevel = "Block level (Part 1)";

        aVariableScopePart2 = new cpVariableScopePart2();
        aAnotherVariableScope = new cpAnotherVariableScope();

        MessageBox.Show(strBlockLevel);
        MessageBox.Show(strModuleLevelPrivate);
        aVariableScopePart2.ShowVariables();
        MessageBox.Show(aAnotherVariableScope.strModuleLevelPublic);
        aAnotherVariableScope.VariableScopePart3();
        // MessageBox.Show(aAnotherVariableScope.VariableScopePart4());
      }
      else
        // Not (strModuleLevelPrivate == "Module level Private (Part 1)")
      {
      }
      // strModuleLevelPrivate == "Module level Private (Part 1)"

      // MessageBox.Show(strBlockLevel);
      MessageBox.Show(strModuleLevelPrivate);
    }
    // Main()

  }
  // cpVariableScope

}
// VariableScope