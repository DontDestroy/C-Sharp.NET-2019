//***
// Action
//   - Run methods with exceptions with throwing errors
// Created
//   - CopyPaste � 20230808 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230808 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Exception01()
      //***
      // Action
      //   - Run the method Exception02
      // Called by
      //   - Exception01()
      // Calls
      //   - Exception02()
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Exception02();
    }
    // Exception01()

    public static void Exception02()
      //***
      // Action
      //   - Throw an exception
      // Called by
      //   - Exception02()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      throw new ArgumentNullException();
    }
    // Exception02()

    public static void Main()
      //***
      // Action
      //   - Run the method Exception01
      //   - On exceptions, show some information
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Exception01()
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      string strString;

      try
      {
        Exception01();
      }
      catch (Exception theException)
      {
        strString = "Message: " + theException.Message + Environment.NewLine;
        strString += "Source: " + theException.Source + Environment.NewLine;
        strString += "Stack: " + theException.StackTrace + Environment.NewLine;
        strString += "Target: " + theException.TargetSite.Name + Environment.NewLine;
        strString += "ToString: " + theException.ToString();
        MessageBox.Show(strString);
      }
      finally
      {
      }

    }
    // Main()


    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning