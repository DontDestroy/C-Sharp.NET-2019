﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmImageBrokenPath.aspx.cs" Inherits="CopyPaste.Learning.wfrmImageBrokenPath" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Sharpen your pencil trivia</title>
</head>
<body>
  <form id="wfrmImageBrokenPath" runat="server">
    <p>How long a line can you draw with the typical pencil?</p>
    <p>
      <img src="../Resources/Pencil.png" alt="Pencil line 35 miles long">
    </p>
    <p>How long a line can you draw with the typical pencil?</p>
    <p>
      <img src="../Resources/Broken.png" alt="The typical new pencil can draw a line 56 kilometer long">
    </p>
  </form>
</body>
</html>
