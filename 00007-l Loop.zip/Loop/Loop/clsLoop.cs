//***
// Action
//   - Example of the different loop systems
// Created
//   - CopyPaste � 20220119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220119 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace Loop
{

  class cpLoop
	{

    static void Main()
    //***
    // Action
    //   - Define variables
    //   - Loop 0 to 10
    //   - Loop while < 100
    //   - Loop while >= 0
    //   - Fill array with files of current directory
    //   - Loop thru array
    //     - Show filename
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.Write(string)
    //   - System.Console.WriteLine()
    //   - string[] System.IO.Directory.GetFiles(string)
    // Created
    //   - CopyPaste � 20220119 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220119 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      double dblX = 0.0;
      long lngCounter;

      for (lngCounter = 0; lngCounter <= 10; lngCounter++)
      {
        Console.Write(lngCounter + " ");
      }
      // lngCounter = 11

      Console.WriteLine();
      
      while (dblX < 100)
      {
        Console.Write(dblX + " ");
        dblX += 25;
      }
      // dblX >= 100
      
      Console.WriteLine();
      
      do
      {
        Console.Write(dblX + " ");
        dblX -= 10;
      }
      while (dblX >= 0);
      // dblX = -10

      Console.WriteLine();
      
      string[] arrstrFile = Directory.GetFiles(".");

      foreach (string strFilename in arrstrFile)
      {
        Console.WriteLine(strFilename);
      }
      // in arrstrFile
      
      Console.ReadLine();
    }
    // Main()

  }
  // cpLoop

}
// Loop