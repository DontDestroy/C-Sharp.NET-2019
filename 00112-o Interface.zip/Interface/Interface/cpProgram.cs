//***
// Action
//   - Testroutine of cpiGreetUser using cpGreetingEnglish and cpGreetingSpanish
// Created
//   - CopyPaste � 20240529 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240529 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Saying Good Morning in Spanish
      // Called by
      //   - 
      // Calls
      //   - cpGreetingEnglish()
      //   - cpGreetingSpanish()
      //   - cpGreetingEnglish.GoodEvening(DateTime) Implements cpiGreetUser.GoodEvening
      //   - cpGreetingEnglish.GoodMorning()
      //   - cpGreetingSpanish.GoodEvening(DateTime) Implements cpiGreetUser.GoodEvening
      //   - cpGreetingSpanish.GoodMorning()
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpGreetingEnglish thecpEnglishHello = new cpGreetingEnglish();
      cpGreetingSpanish thecpSpanishHello = new cpGreetingSpanish();

      thecpEnglishHello.GoodMorning();
      thecpEnglishHello.GoodEvening(DateTime.Now);

      Console.WriteLine();

      thecpSpanishHello.GoodMorning();
      thecpSpanishHello.GoodEvening(DateTime.Now);

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx