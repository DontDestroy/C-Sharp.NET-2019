﻿//***
// Action
//   - Startup screen
// Created
//   - CopyPaste – 20220814 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220814 – VVDW
// Proposal (To Do)
//   -
//***


using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace CodeOnlyWPF
{
  public class cpStartupScreen : Window
  {

    #region "Constructors / Destructors"

    public cpStartupScreen()
    //***
    // Action
    //   - Initialize the Startup screen
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20220814 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220814 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // cpStartupScreen()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private Button cmdClick;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdClick_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Show a message to prove that you can attach code to a created button
    // Called by
    //   - User action
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220814 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220814 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cmdClick.Content = "Thank you.";
    }
    // cmdClick_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdClick.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void InitializeComponent()
    //***
    // Action
    //   - Building up the Startup screen from scratch (no XAML)
    //   - Size of the Startup screen
    //   - Position of the Startup screen
    //   - Create a Panel
    //   - Create a Container
    //   - Container becomes the Panel
    //   - Add Button to Container
    //   - Container becomes the Startup screen
    //   - Add Panel to Container
    //   - An alternative way is in comment (notice the difference in syntax)
    //     - Add the button to the panel
    //     - Add the panel to the Startup screen
    // Called by
    //   - cpStartupScreen()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220814 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220814 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      DockPanel dckPanel = new DockPanel(); // This will hold the cmdButton

      this.Height = 285;
      this.Width = 285;
      this.Left = 100;
      this.Top = 100;
      this.Title = "Copy Paste Code Only WPF";

      cmdClick = new Button();
      cmdClick.Content = "Please Click";
      cmdClick.Margin = new Thickness(30);

      cmdClick.Click += cmdClick_Click; // The defined event is added to the cmdClick click event

      IAddChild cntContainer = dckPanel;
      cntContainer.AddChild(cmdClick); // Add cmdClick to the Container

      cntContainer = this; // The Startup Screen contains the Container
      cntContainer.AddChild(dckPanel); // Add the Panel to the Container

      // dckPanel.Children.Add(cmdClick);
      // this.AddChild(dckPanel);
    }
    // InitializeComponent()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpStartupScreen

}
// CodeOnlyWPF