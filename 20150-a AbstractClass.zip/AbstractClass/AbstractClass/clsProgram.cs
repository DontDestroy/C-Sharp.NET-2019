﻿//***
// Action
//   - Example of an abstract class
// Created
//   - CopyPaste – 20260128 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260128 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Define a calculation with 2 values (starting with cpAdd)
    //   - Execute the calculation
    //   - Show the result of the calculation
    //   - Change the calculation into a subtraction
    //   - Execute the calculation
    //   - Show the result of the calculation
    //   - Change the calculation into a multiplication
    //   - Execute the calculation
    //   - Show the result of the calculation
    //   - Change the calculation into a division
    //   - Execute the calculation
    //   - Show the result of the calculation
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpAdd(int, int)
    //   - cpCalculation.Calculate() thru inheritance
    //   - cpIntegerDivision(int, int)
    //   - cpMultiplication(int, int)
    //   - cpSubtraction(int, int)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intOperantOne = 15;
      int intOperantTwo = 5;

      // cpCalculation theCalculation = new cpCalculation();
      // VVDW - The line above is impossible (you can't initialize from an abstract class)

      cpCalculation theCalculation = new cpAdd(intOperantOne, intOperantTwo);
      int intResult;

      intResult = theCalculation.Calculate();
      Console.WriteLine($"Result of calculation is: {intResult}");

      theCalculation = new cpSubtraction(intOperantOne, intOperantTwo);
      intResult = theCalculation.Calculate();
      Console.WriteLine($"Result of calculation is: {intResult}");

      theCalculation = new cpMultiplication(intOperantOne, intOperantTwo);
      intResult = theCalculation.Calculate();
      Console.WriteLine($"Result of calculation is: {intResult}");
      
      theCalculation = new cpIntegerDivision(intOperantOne, intOperantTwo);
      intResult = theCalculation.Calculate();
      Console.WriteLine($"Result of calculation is: {intResult}");
      Console.WriteLine();

      Console.WriteLine("Hit any key");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning