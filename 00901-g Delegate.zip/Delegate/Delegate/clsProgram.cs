﻿//***
// Action
//   - Two different delegates
//   - One with an action on two number that return a number
//   - One with an action on a text (no return value)
// Created
//   - CopyPaste – 20250714 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250714 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate double NumbersMethod(double dblFirst, double dblSecond);
    public delegate void StringMethod(string strText);

    #endregion

    #region "Sub / Function"

    public static double AddNumbers(double dblFirst, double dblSecond)
      // Action
      //   - Add two numbers
      //   - Return the result
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250714 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250714 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return dblFirst + dblSecond;
    }
    // double AddNumbers(double, double)

    public static void DisplayString(string strText)
      //***
      // Action
      //   - Show the text on the console
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250714 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250714 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine(strText);
    }
    // DisplayString(string)

    public static void Main()
      //***
      // Action
      //   - Define a variable that uses a delegate to do something with a string
      //   - Define a variable that uses a delegate to do something with two numbers
      //   - Run the string method
      //   - Change the method for strings
      //   - Run the string method again
      //   - Run the number method
      //   - Show the result on the screen
      //   - Change the number method
      //   - Run the number method
      //   - Show the result on the screen
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - DisplayString(string)
      //   - double AddNumbers(double, double)
      //   - double NumbersMethod(double, double)
      //   - double SubtractNumbers(double, double)
      //   - StringMethod(string)
      //   - UpperString(string)
      // Created
      //   - CopyPaste – 20250714 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250714 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      StringMethod theMethod = new StringMethod(DisplayString);
      NumbersMethod theNumbers = new NumbersMethod(SubtractNumbers);

      theMethod("Visual Basic .Net Programming");
      theMethod = new StringMethod(UpperString);
      theMethod("Visual Basic .Net Programming");
      Console.WriteLine(theNumbers(100, 50));
      theNumbers = new NumbersMethod(AddNumbers);
      Console.WriteLine(theNumbers(100, 50));
      Console.ReadLine();
    }
		// Main()

    public static double SubtractNumbers(double dblFirst, double dblSecond)
      // Action
      //   - Subtract two numbers
      //   - Return the result
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250714 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250714 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return dblFirst - dblSecond;
    }
    // double SubtractNumbers(double, double)

    public static void UpperString(string strText)
      //***
      // Action
      //   - Show the text in capitals on the console
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250714 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250714 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine(strText.ToUpper());
    }
    // UpperString(string)

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning