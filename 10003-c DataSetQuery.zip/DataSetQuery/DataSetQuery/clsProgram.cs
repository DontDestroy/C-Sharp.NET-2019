﻿//***
// Action
//   - Work with a data command, a data adapter and a data set
// Created
//   - CopyPaste – 20250806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250806 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Try to
      //     - Set a connection string
      //     - Open the connection
      //     - Show the database, server version and data source
      //     - Set a data command
      //     - Set a data adapter
      //     - Fill the data set by executing the data adapter
      //     - Close the connection
      //     - Loop thru the data set
      //       - Show the second column
      //   - On an error
      //     - Show the error exception message
      //     - Show the error to string
      //   - Wait for user input
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250806 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250806 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        int lngCounter;
        string strConnection = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integrated Security=True";
        SqlConnection theConnection = new SqlConnection(strConnection);

        theConnection.Open();
        
        Console.WriteLine("Database: " + theConnection.Database);
        Console.WriteLine("Server Version: " + theConnection.ServerVersion);
        Console.WriteLine("Data Source: " + theConnection.DataSource);
        Console.WriteLine();

        string strCommand = "SELECT * From tblCPEmployee";
        DataSet theDataset = new DataSet();
        SqlDataAdapter theDataAdapter = new SqlDataAdapter(strCommand, theConnection);
        
        theDataAdapter.Fill(theDataset);
        theConnection.Close(); 
        
        for (lngCounter = 0; lngCounter < theDataset.Tables[0].Rows.Count; lngCounter++)
        {
          Console.WriteLine(theDataset.Tables[0].Rows[lngCounter][1]);
        }
        // lngCounter = theDataset.Tables(0).Rows.Count

      }
      catch (Exception theException)
      {
        Console.WriteLine("Exception: " + theException.Message);
        Console.WriteLine(theException.ToString());
      }
      finally
      {
        Console.ReadLine();
      }

    }
		// Main()

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning