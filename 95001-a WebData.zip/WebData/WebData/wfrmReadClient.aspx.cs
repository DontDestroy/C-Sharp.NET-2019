﻿//***
// Action
//   - Basic connection to SQL Server Database
//   - Basic data command to SQL Server table
//   - Full CRUD operations on a SQL Server table
// Created
//   - CopyPaste – 20260826 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260826 – VVDW
// Proposal (To Do)
//   - Code is for demoing the functionality, it is not optimal
//   - The goal is to show some techniques
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;


namespace CopyPaste.Learning
{

  public partial class wfrmReadClient : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cnncpClient = new System.Data.SqlClient.SqlConnection();
      this.dtaClient = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmDeleteClient = new System.Data.SqlClient.SqlCommand();
      this.cmmInsertClient = new System.Data.SqlClient.SqlCommand();
      this.cmmSelectClient = new System.Data.SqlClient.SqlCommand();
      this.cmmUpdateClient = new System.Data.SqlClient.SqlCommand();
      this.cmdClear.Click += new System.EventHandler(this.cmdClear_Click);
      this.cmdDelete.Click += new System.EventHandler(this.cmdDelete_Click);
      this.cmdNew.Click += new System.EventHandler(this.cmdNew_Click);
      this.cmdChange.Click += new System.EventHandler(this.cmdChange_Click);
      this.cmdLast.Click += new System.EventHandler(this.cmdLast_Click);
      this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
      this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      this.cmdFindNameNumber.Click += new System.EventHandler(this.cmdFindNameNumber_Click);
      this.cmdFindNumber.Click += new System.EventHandler(this.cmdFindNumber_Click);
      // 
      // cnncpClient
      // 
      this.cnncpClient.ConnectionString = "Data Source=COPYPASTEPOWER\\COPYPASTE; Initial Catalog = cpClient; Integrated Security = True;";

      // 
      // dtaClient
      // 
      this.dtaClient.DeleteCommand = this.cmmDeleteClient;
      this.dtaClient.InsertCommand = this.cmmInsertClient;
      this.dtaClient.SelectCommand = this.cmmSelectClient;
      this.dtaClient.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
                                                                                        new System.Data.Common.DataTableMapping("Table", "tblClient", new System.Data.Common.DataColumnMapping[] {
                                                                                                                                                                                                   new System.Data.Common.DataColumnMapping("lngIdClient", "lngIdClient"),
                                                                                                                                                                                                   new System.Data.Common.DataColumnMapping("strName", "strName"),
                                                                                                                                                                                                   new System.Data.Common.DataColumnMapping("strAddress", "strAddress"),
                                                                                                                                                                                                   new System.Data.Common.DataColumnMapping("strZipCode", "strZipCode"),
                                                                                                                                                                                                   new System.Data.Common.DataColumnMapping("strCity", "strCity")})});
      this.dtaClient.UpdateCommand = this.cmmUpdateClient;
      // 
      // cmmDeleteClient
      // 
      this.cmmDeleteClient.CommandText = @"DELETE FROM tblClient WHERE (lngIdClient = @Original_lngIdClient) AND (strAddress = @Original_strAddress OR @Original_strAddress IS NULL AND strAddress IS NULL) AND (strCity = @Original_strCity OR @Original_strCity IS NULL AND strCity IS NULL) AND (strName = @Original_strName OR @Original_strName IS NULL AND strName IS NULL) AND (strZipCode = @Original_strZipCode OR @Original_strZipCode IS NULL AND strZipCode IS NULL)";
      this.cmmDeleteClient.Connection = this.cnncpClient;
      this.cmmDeleteClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_lngIdClient", System.Data.SqlDbType.BigInt, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "lngIdClient", System.Data.DataRowVersion.Original, null));
      this.cmmDeleteClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_strAddress", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "strAddress", System.Data.DataRowVersion.Original, null));
      this.cmmDeleteClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_strCity", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "strCity", System.Data.DataRowVersion.Original, null));
      this.cmmDeleteClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_strName", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "strName", System.Data.DataRowVersion.Original, null));
      this.cmmDeleteClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_strZipCode", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "strZipCode", System.Data.DataRowVersion.Original, null));
      // 
      // cmmInsertClient
      // 
      this.cmmInsertClient.CommandText = "INSERT INTO tblClient(strName, strAddress, strZipCode, strCity) VALUES (@strName," +
        " @strAddress, @strZipCode, @strCity); SELECT lngIdClient, strName, strAddress, s" +
        "trZipCode, strCity FROM tblClient WHERE (lngIdClient = @@IDENTITY)";
      this.cmmInsertClient.Connection = this.cnncpClient;
      this.cmmInsertClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@strName", System.Data.SqlDbType.NVarChar, 50, "strName"));
      this.cmmInsertClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@strAddress", System.Data.SqlDbType.NVarChar, 50, "strAddress"));
      this.cmmInsertClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@strZipCode", System.Data.SqlDbType.NVarChar, 50, "strZipCode"));
      this.cmmInsertClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@strCity", System.Data.SqlDbType.NVarChar, 50, "strCity"));
      // 
      // cmmSelectClient
      // 
      this.cmmSelectClient.CommandText = "SELECT lngIdClient, strName, strAddress, strZipCode, strCity FROM tblClient WHERE" +
        " (lngIdClient = @Param1)";
      this.cmmSelectClient.Connection = this.cnncpClient;
      this.cmmSelectClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Param1", System.Data.SqlDbType.BigInt, 8, "lngIdClient"));
      // 
      // cmmUpdateClient
      // 
      this.cmmUpdateClient.CommandText = @"UPDATE tblClient SET strName = @strName, strAddress = @strAddress, strZipCode = @strZipCode, strCity = @strCity WHERE (lngIdClient = @Original_lngIdClient) AND (strAddress = @Original_strAddress OR @Original_strAddress IS NULL AND strAddress IS NULL) AND (strCity = @Original_strCity OR @Original_strCity IS NULL AND strCity IS NULL) AND (strName = @Original_strName OR @Original_strName IS NULL AND strName IS NULL) AND (strZipCode = @Original_strZipCode OR @Original_strZipCode IS NULL AND strZipCode IS NULL); SELECT lngIdClient, strName, strAddress, strZipCode, strCity FROM tblClient WHERE (lngIdClient = @lngIdClient)";
      this.cmmUpdateClient.Connection = this.cnncpClient;
      this.cmmUpdateClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@strName", System.Data.SqlDbType.NVarChar, 50, "strName"));
      this.cmmUpdateClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@strAddress", System.Data.SqlDbType.NVarChar, 50, "strAddress"));
      this.cmmUpdateClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@strZipCode", System.Data.SqlDbType.NVarChar, 50, "strZipCode"));
      this.cmmUpdateClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@strCity", System.Data.SqlDbType.NVarChar, 50, "strCity"));
      this.cmmUpdateClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_lngIdClient", System.Data.SqlDbType.BigInt, 8, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "lngIdClient", System.Data.DataRowVersion.Original, null));
      this.cmmUpdateClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_strAddress", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "strAddress", System.Data.DataRowVersion.Original, null));
      this.cmmUpdateClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_strCity", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "strCity", System.Data.DataRowVersion.Original, null));
      this.cmmUpdateClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_strName", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "strName", System.Data.DataRowVersion.Original, null));
      this.cmmUpdateClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@Original_strZipCode", System.Data.SqlDbType.NVarChar, 50, System.Data.ParameterDirection.Input, false, ((System.Byte)(0)), ((System.Byte)(0)), "strZipCode", System.Data.DataRowVersion.Original, null));
      this.cmmUpdateClient.Parameters.Add(new System.Data.SqlClient.SqlParameter("@lngIdClient", System.Data.SqlDbType.BigInt, 8, "lngIdClient"));
      this.ID = "wfrmReadClient";
    }

    #endregion

    #region "Constructors / Destructors"

    ~wfrmReadClient()
    //***
    // Action
    //   - Dispose (Destroy) the Data adapter
    // Called by
    //   - System action (Disposing the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***

    {
      dsClient.Dispose();
      dtaClient.Dispose();
    }
    // ~wfrmReadClient()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private System.Data.DataSet dsClient = new System.Data.DataSet();
    private System.Data.DataView dvClient = new System.Data.DataView();

    protected System.Data.SqlClient.SqlCommand cmmDeleteClient;
    protected System.Data.SqlClient.SqlCommand cmmInsertClient;
    protected System.Data.SqlClient.SqlCommand cmmSelectClient;
    protected System.Data.SqlClient.SqlCommand cmmUpdateClient;
    protected System.Data.SqlClient.SqlConnection cnncpClient;
    protected System.Data.SqlClient.SqlDataAdapter dtaClient;

    protected System.Web.UI.WebControls.Button cmdChange;
    protected System.Web.UI.WebControls.Button cmdClear;
    protected System.Web.UI.WebControls.Button cmdDelete;
    protected System.Web.UI.WebControls.Button cmdFindNameNumber;
    protected System.Web.UI.WebControls.Button cmdFindNumber;
    protected System.Web.UI.WebControls.Button cmdFirst;
    protected System.Web.UI.WebControls.Button cmdLast;
    protected System.Web.UI.WebControls.Button cmdNew;
    protected System.Web.UI.WebControls.Button cmdNext;
    protected System.Web.UI.WebControls.Button cmdPrevious;

    protected System.Web.UI.WebControls.Label lblAction;
    protected System.Web.UI.WebControls.Label lblAddress;
    protected System.Web.UI.WebControls.Label lblCity;
    protected System.Web.UI.WebControls.Label lblClientNumber;
    protected System.Web.UI.WebControls.Label lblFindNumber;
    protected System.Web.UI.WebControls.Label lblName;
    protected System.Web.UI.WebControls.Label lblMessage;
    protected System.Web.UI.WebControls.Label lblNumber;
    protected System.Web.UI.WebControls.Label lblTitle;

    protected System.Web.UI.WebControls.TextBox txtAddress;
    protected System.Web.UI.WebControls.TextBox txtCity;
    protected System.Web.UI.WebControls.TextBox txtFindNumber;
    protected System.Web.UI.WebControls.TextBox txtName;
    protected System.Web.UI.WebControls.TextBox txtNumber;
    protected System.Web.UI.WebControls.TextBox txtZipCode;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when the page is initialized
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdChange_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Update an existing record
    //   - Sort order is set to the key of the client
    //   - Find the correct row in the data view
    //   - If found
    //     - All corresponding fields are updated of the correct row
    //     - Data set is updated
    //     - Correct message is shown
    //   - If not
    //     - Show error message
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int lngRow;

      dvClient.Sort = "lngIdClient";
      lngRow = dvClient.Find(txtNumber.Text);

      if (lngRow < 0)
      {
        lblMessage.Text = "This recordnumber does not exist!";
      }
      else
      // lngRow >= 0
      {
        dsClient.Tables["tblClient"].Rows[lngRow]["strName"] = txtName.Text;
        dsClient.Tables["tblClient"].Rows[lngRow]["strAddress"] = txtAddress.Text;
        dsClient.Tables["tblClient"].Rows[lngRow]["strZipCode"] = txtZipCode.Text;
        dsClient.Tables["tblClient"].Rows[lngRow]["strCity"] = txtCity.Text;
        dtaClient.Update(dsClient);
        lblAction.Text = "Update finished";
      }
      // lngRow < 0

    }
    // cmdChange_Click(System.Object, System.EventArgs) Handles cmdChange.Click

    private void cmdClear_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Clear the screen
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - Clear()
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Clear();
    }
    // cmdClear_Click(System.Object, System.EventArgs) Handles cmdClear.Click

    private void cmdDelete_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Depending on the sort order
    //     - The correct row number is found
    //   - Record is delete from table from data set
    //   - Data set is updated using the data adapter
    //   - Correct message is shown
    //   - Show the first record
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - Show(int)
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int lngCounter = -1;

      switch (dvClient.Sort)
      {
        case "lngIdClient":
          lngCounter = dvClient.Find(txtNumber.Text);
          break;
        case "strName":
          lngCounter = dvClient.Find(txtName.Text);
          break;
      }
      // dvClient.Sort

      if (lngCounter < 0)
      {
        lblMessage.Text = "No current record selected!";
      }
      else
      // lngCounter >= 0
      {
        dsClient.Tables["tblClient"].Rows[lngCounter].Delete();
        dtaClient.Update(dsClient);
        lblAction.Text = "Record deleted!";
        Show(0);
      }
      // lngCounter < 0

    }
    // cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click

    private void cmdFindNameNumber_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Clear the information on the screen
    //   - If number is typed
    //     - Sort order is on the key of the client
    //   - If not
    //     - Sort order is on the name of the client
    //   - Find the typed key or name
    //   - If found
    //     - Correct record information is show
    //   - If not
    //     - Correct message is shown
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int lngCounter;

      Clear();

      if (Information.IsNumeric(txtFindNumber.Text))
      {
        dvClient.Sort = "lngIdClient";
      }
      else
      // Not Microsoft.VisualBasic.Information.IsNumeric(txtFindNumber.Text) 
      {
        dvClient.Sort = "strName";
      }
      // Microsoft.VisualBasic.Information.IsNumeric(txtFindNumber.Text) 

      lngCounter = dvClient.Find(txtFindNumber.Text);

      if (lngCounter < 0)
      {
        lblMessage.Text = "Not Found!";
      }
      else
      // lngCounter >= 0
      {
        Show(lngCounter);
      }
      // lngCounter < 0

    }
    // cmdFindNameNumber_Click(System.Object, System.EventArgs) Handles cmdFindNameNumber.Click

    private void cmdFindNumber_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - If txtNumber is a number
    //     - Change the ? in the sql statement of the select command into txtNumber
    //     - Fill the data set with the result of the data adapter
    //     - If the number of rows in the first table of the dataset is 1
    //       - Show the information in the text boxes of the webpage
    //     - If not
    //       - Show error message on screen
    //   - If Not
    //     - Show error message on screen
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - Clear()
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strNumber = txtNumber.Text;

      Clear();

      if (Microsoft.VisualBasic.Information.IsNumeric(strNumber))
      {
        dtaClient.SelectCommand.Parameters[0].Value = strNumber;
        dtaClient.Fill(dsClient);

        if (dsClient.Tables["tblClient"].Rows.Count == 1)
        {
          txtNumber.Text = dsClient.Tables[0].Rows[0]["lngIdClient"].ToString();
          txtName.Text = dsClient.Tables[0].Rows[0]["strName"].ToString();
          txtAddress.Text = dsClient.Tables[0].Rows[0]["strAddress"].ToString();
          txtZipCode.Text = dsClient.Tables[0].Rows[0]["strZipCode"].ToString();
          txtCity.Text = dsClient.Tables[0].Rows[0]["strCity"].ToString();
        }
        else
        // dsClient.Tables["tblClient"].Rows.Count <> 1
        {
          lblMessage.Text = "Not found!";
          // VVDW - It is impossible to find 2 records with the same key
        }
        // dsClient.Tables["tblClient"].Rows.Count = 1

      }
      else
      // Not Microsoft.VisualBasic.Information.IsNumeric(strNumber)
      {
        lblMessage.Text = "Wrong number!";
      }
      // Microsoft.VisualBasic.Information.IsNumeric(strNumber)

    }
    // cmdFindNumber_Click(System.Object, System.EventArgs) Handles cmdFindNumber.Click

    private void cmdFirst_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Show the first record
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - Show(int)
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Show(0);
    }
    // cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click

    private void cmdLast_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Show the last record
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - Show(Int32)
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Show(dvClient.Count - 1);
    }
    // cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click

    private void cmdNew_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - A new data row is created
    //   - All columns (except the key) are filled
    //   - Data row is added to the correct table in the data set
    //   - Data set is updated using the data adapter
    //   - Corresponding message is shown
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      DataRow drNew = dsClient.Tables["tblClient"].NewRow();

      drNew["strName"] = txtName.Text;
      drNew["strAddress"] = txtAddress.Text;
      drNew["strCity"] = txtCity.Text;
      drNew["strZipCode"] = txtZipCode.Text;
      dsClient.Tables["tblClient"].Rows.Add(drNew);
      dtaClient.Update(dsClient);
      lblAction.Text = "Data entered!";
    }
    // cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click

    private void cmdNext_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Depending on the sort order, the next record is found
    //   - If you are on the last record
    //     - Show current
    //   - If not
    //     - Show next record
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - Show(Int32)
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int lngCounter = -1;

      switch (dvClient.Sort)
      {
        case "lngIdClient":
          lngCounter = dvClient.Find(txtNumber.Text);
          break;
        case "strName":
          lngCounter = dvClient.Find(txtName.Text);
          break;
      }
      // dvClient.Sort

      if (lngCounter == dvClient.Count - 1)
      {
        Show(dvClient.Count - 1);
      }
      else
      // lngCounter <> dvClient.Count - 1
      {
        Show(lngCounter + 1);
      }
      // lngCounter = dvClient.Count - 1

    }
    // cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click

    private void cmdPrevious_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Depending on the sort order, the previous record is found
    //   - If you are on the first record
    //     - Show current
    //   - If not
    //     - Show previous record
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - Show(Int32)
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int lngCounter = -1;

      switch (dvClient.Sort)
      {
        case "lngIdClient":
          lngCounter = dvClient.Find(txtNumber.Text);
          break;
        case "strName":
          lngCounter = dvClient.Find(txtName.Text);
          break;
      }
      // dvClient.Sort

      if (lngCounter == 0)
      {
        Show(lngCounter);
      }
      else
      // lngCounter <> 0
      {
        Show(lngCounter - 1);
      }
      // lngCounter = 0

    }
    // cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Part 001 - Find a record with a given key
    //     - All is commented out
    //   - Part 002 - Working with a data view
    //     - Enable and disable some controls on the webpage
    //     - Set the select command of client data adapter 
    //     - Fill the data set using client data adapter 
    //     - Define the client data view 
    //     - Set the client data view to the table tblClient from the data set
    //     - Sort the client data view on the key
    //     - If Postback
    //       - Do nothing
    //     - If not
    //       - Show first record (if there is one)
    //   - Part 003 - Working with a data view (Alternative)
    //     - Same functionality as is part 002 but in a different order
    // Called by
    //   - System action (Loading the page)
    // Calls
    //   - Show(int)
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      //*** VVDW - First part - Find a record with a given key
      // All is commented out

      //*** VVDW - Second part - Working with a data view

      //cmdChange.Enabled = true;
      //cmdClear.Enabled = false;
      //cmdDelete.Enabled = true;
      //cmdFindNameNumber.Enabled = true;
      //cmdFindNumber.Enabled = false;
      //cmdFirst.Enabled = true;
      //cmdLast.Enabled = true;
      //cmdNew.Enabled = true;
      //cmdNext.Enabled = true;
      //cmdPrevious.Enabled = true;

      //lblFindNumber.Enabled = true;
      //lblNumber.Enabled = false;

      //txtFindNumber.Enabled = true;
      //txtNumber.Enabled = false;

      //dtaClient.SelectCommand.CommandText = "Select * from tblClient";
      //dtaClient.SelectCommand.CommandType = CommandType.Text;
      //dtaClient.SelectCommand.Parameters.Clear();
      //dtaClient.Fill(dsClient);

      //dvClient.Table = dsClient.Tables["tblClient"];
      //dvClient.Sort = "lngIdClient";
      //// dvClient.Sort = "strName";

      //if (IsPostBack)
      //{
      //}
      //else
      //// Not IsPostBack 
      //{
      //  Show(0);
      //}
      //// IsPostBack 

      //*** VVDW - Third part - Working with a data view (Alternative way)

      //dtaClient.SelectCommand.CommandText = "Select * from tblClient";
      //dtaClient.SelectCommand.CommandType = CommandType.Text;
      //dtaClient.SelectCommand.Parameters.Clear();
      //dtaClient.Fill(dsClient);
      //dvClient.Table = dsClient.Tables["tblClient"];
      
      //if (IsPostBack)
      //{
        
      //  if (txtFindNumber.Text == "")
      //  {
      //    dvClient.Sort = "lngIdClient";
      //  }
      //  else
      //    // txtFindNumber.Text <> ""
      //  {
      
      //    if (Microsoft.VisualBasic.Information.IsNumeric(txtFindNumber.Text))
      //    {
      //      dvClient.Sort = "lngIdClient";
      //    }
      //    else
      //      // Not Microsoft.VisualBasic.Information.IsNumeric(txtFindNumber.Text)
      //    {
      //      dvClient.Sort = "strName";
      //    }
      //    // Microsoft.VisualBasic.Information.IsNumeric(txtFindNumber.Text)
        
      //  }
      //  // txtFindNumber.Text = ""
        
      //}
      //else
      //  // Not IsPostBack
      //{
      //  cmdChange.Enabled = true;
      //  cmdClear.Enabled = false;
      //  cmdDelete.Enabled = true;
      //  cmdFindNameNumber.Enabled = true;
      //  cmdFindNumber.Enabled = false;
      //  cmdFirst.Enabled = true;
      //  cmdLast.Enabled = true;
      //  cmdNew.Enabled = true;
      //  cmdNext.Enabled = true;
      //  cmdPrevious.Enabled = true;
      //  dvClient.Sort = "lngIdClient";
      
      //  lblFindNumber.Enabled = true;
      //  lblNumber.Enabled = false;
        
      //  txtFindNumber.Enabled = true;
      //  txtNumber.Enabled = false;
        
      //  Show(0);
      //}
      //// IsPostBack

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void Clear()
    //***
    // Action
    //   - Empty the webpage controls
    // Called by
    //   - cmdClear_Click(System.Object, System.EventArgs) Handles cmdClear.Click
    //   - cmdFindNameNumber_Click(System.Object, System.EventArgs) Handles cmdFindNameNumber.Click
    //   - cmdFindNumber_Click(System.Object, System.EventArgs) Handles cmdFindNumber.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lblAction.Text = "";
      lblMessage.Text = "";
      txtAddress.Text = "";
      txtCity.Text = "";
      txtName.Text = "";
      txtNumber.Text = "";
      txtZipCode.Text = "";
    }
    // Clear()

    private void Show(int lngRow)
    //***
    // Action
    //   - Try to
    //     - Fill the webpage controls with a given row number
    //   - On possible error
    //     - Enable the find button
    //     - Show corresponding error message on the screen
    // Called by
    //   - cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click
    //   - cmdFirst_Click(System.Object, .EventArgs) Handles cmdFirst.Click
    //   - cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click
    //   - cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click
    //   - cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click
    //   - Page_Load(System.Object, System.EventArgs) Handles MyBase.Load
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      try
      {
        txtAddress.Text = dvClient[lngRow]["strAddress"].ToString();
        txtCity.Text = dvClient[lngRow]["strCity"].ToString();
        txtName.Text = dvClient[lngRow]["strName"].ToString();
        txtNumber.Text = dvClient[lngRow]["lngIdClient"].ToString();
        txtZipCode.Text = dvClient[lngRow]["strZipCode"].ToString();
        lblMessage.Text = "";
      }
      catch (Exception theException)
      {
        txtAddress.Text = "";
        txtCity.Text = "";
        txtName.Text = "";
        txtNumber.Text = "";
        txtZipCode.Text = "";
        lblMessage.Text = "Record is not found!";
      }

    }
    // Show(int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmReadClient

}
// CopyPaste.Learning
