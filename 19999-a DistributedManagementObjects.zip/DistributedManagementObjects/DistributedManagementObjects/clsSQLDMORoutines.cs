//***
// Action
//   - Basic SQL DMO (Distributed Management Objects) routines
//     - Build Connection
//     - Get Backup Device
//     - Get SQL Database
//     - Load SQL Server
// Created
//   - CopyPaste � 20260717 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260717 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;
using System;
using System.Data;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpSQLDMORoutines
  {

    #region "Constructors / Destructors"

    public cpSQLDMORoutines()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - xxxx
    // Created
    //   - CopyPaste � 20260717 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260717 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpSQLDMORoutines()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static string BuildConnection(string strServer, string strDatabase)
      //***
      // Action
      //   - Create a connection string with a given server and database
      // Called by
      //   - frmSelectSQLServer.cmdConnect_Click(System.Object, System.EventArgs) Handles cmdConnect.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strTemp;

      strTemp = "Data Source=" + strServer + ";Initial Catalog=" + strDatabase + ";Integrated Security=True";
      // VVDW - With password
      // strTemp = "Data Source=" + strServer + ";Initial Catalog=" + strDatabase + ";Integrated Security=True;user id=sa;password=FullofInfo";
      return strTemp;
    }
    // string BuildConnection(String, String)
		
    public static void GetBackupDevice(string strSQLServer, ref ListBox lstBackupDevice)
      //***
      // Action
      //   - Define a backup device
      //   - Define and initialize a SQLServer
      //   - Try to
      //     - Set the login security to true
      //     - Connect to the SQL Server with Windows Security
      //     - Fill the listbox with backup devices after clearing it
      //     - Select the first item of the backup devices
      //   - On possible error
      //     - Show messageboxes with corresponding info 
      // Called by
      //   - frmBackup.lstSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstSQLServer.SelectedIndexChanged
      //   - frmRestore.lstSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstSQLServer.SelectedIndexChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - There must be already a backup device defined
      //***
    {
      Server theSQLServer;

      try
      {
        theSQLServer = new Server(strSQLServer);
        theSQLServer.ConnectionContext.Connect();
        lstBackupDevice.Items.Clear();

        foreach(BackupDevice theBackupDevice in theSQLServer.BackupDevices)
        {
          lstBackupDevice.Items.Add(theBackupDevice.Name);
        }
        // in theSQLServer.BackupDevices

        lstBackupDevice.SelectedIndex = 0;
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
        MessageBox.Show("There is a problem retrieving databases for this server. " +
          "Please check the name and try again. ", "Error with Server", MessageBoxButtons.OK, MessageBoxIcon.Information);
      }
      
    }
    // GetBackupDevice(string, �ListBox)

    public static void GetSQLDatabase(string strSQLServer, ref ListBox lstListBox)
      //***
      // Action
      //   - With a given SQL Server and a listbox to fill
      //   - Define a database
      //   - Define a sql server
      //   - Create a new instance of a SQLServer
      //   - Try to 
      //     - Set the login security to true
      //     - Connect to the SQL Server with Windows Security
      //     - Fill the listbox with databases after clearing it
      //     - Select the first item of the databases
      //   - On possible error
      //     - Show messageboxes with corresponding info 
      // Called by
      //   - frmBackup.lstSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstSQLServer.SelectedIndexChanged
      //   - frmDetachAttach.cmdAttach_Click(System.Object, System.EventArgs) Handles cmdAttach.Click
      //   - frmDetachAttach.cmdDetach_Click(System.Object, System.EventArgs) Handles cmdDetach.Click
      //   - frmDetachAttach.lstSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstSQLServer.SelectedIndexChanged
      //   - frmRestore.lstSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstSQLServer.SelectedIndexChanged
      //   - frmSelectSQLServer.lstSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstSQLServer.SelectedIndexChanged
      //   - frmTransferTables.lstFromSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstFromSQLServer.SelectedIndexChanged
      //   - frmTransferTables.lstToSQLServer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstToSQLServer.SelectedIndexChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Server theSQLServer;

      try
      {
        theSQLServer = new Server(strSQLServer);
        theSQLServer.ConnectionContext.Connect();

        lstListBox.Items.Clear();

        foreach(Database theDatabase in theSQLServer.Databases)
        {
          lstListBox.Items.Add(theDatabase.Name);
        }
        // in theSQLServer.Databases

        lstListBox.SelectedIndex = 0;
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
        MessageBox.Show("There is a problem retrieving databases for this server. " + 
          "Please check the name and try again. ", "Error with Server", MessageBoxButtons.OK, MessageBoxIcon.Information);
      }
      finally
      {
      }

    }
    // GetSQLDatabase(string, �ListBox)

    public static void LoadSQLServer(ref ListBox lstSQLServer)
      //***
      // Action
      //   - Define and initialize a SQLDMLO application
      //   - Define a counter
      //   - Define a namelist
      //   - List the available servers
      //   - If there are none
      //     - Show hardcoded the current one
      //   - If not
      //     - Do nothing
      //   - Loop thru the list
      //     - If the name is "(local)"
      //       - Show the hard coded one
      //     - If not 
      //       - Add the found item to the list of SQL servers
      //   - Select the first item of the list 
      // Called by
      //   - frmBackup.frmBackup_Load(System.Object, System.EventArgs) Handles MyBase.Load
      //   - frmRestore.frmRestore_Load(System.Object, System.EventArgs) Handles MyBase.Load
      //   - frmSelectSQLServer.frmSelectSQLServer_Load(System.Object, System.EventArgs) Handles MyBase.Load
      //   - frmTransferTables.frmTransferTables_Load(System.Object, System.EventArgs) Handles MyBase.Load
      //   - frmDetachAttach.frmDetachAttach_Load(System.Object, System.EventArgs) Handles MyBase.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - I have several servers on my machine, but only one is found
      //   - On SQL Server version 2000, there is only a local database
      //***
    {
      DataTable dtServerName;
      int lngCountSQLServer = 0;
      string strHardcodeServerName;

      strHardcodeServerName = "COPYPASTEPOWER\\COPYPASTE";

      dtServerName = SmoApplication.EnumAvailableSqlServers(true);

      if (dtServerName.Rows.Count == 0)
      {
        lstSQLServer.Items.Add(strHardcodeServerName);
      }
      else
      // dtServerName.Rows.Count <> 0
      {
      }
      // dtServerName.Rows.Count = 0

      foreach (DataRow drServerName in dtServerName.Rows)
      {

        if (dtServerName.Rows[lngCountSQLServer]["Name"].ToString() == "(localdb)\\mssqllocaldb")
        {
          lstSQLServer.Items.Add(strHardcodeServerName);
        }
        else
        // dtServerName.Rows[lngCountSQLServer]["Name"].ToString() <> "(localdb)\\mssqllocaldb"
        {
          lstSQLServer.Items.Add(drServerName["Name"].ToString());
        }
        // dtServerName.Rows[lngCountSQLServer]["Name"].ToString() = "(localdb)\\mssqllocaldb"

      }
      // in dtServerName.Rows

      lstSQLServer.SelectedIndex = 0;
    }
    // LoadSQLServer(�ListBox)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpSQLDMORoutines

}
// CopyPaste.Learning