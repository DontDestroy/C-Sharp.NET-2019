//***
// Action
//   - Implementation of cpBase
// Created
//   - CopyPaste � 20240705 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240705 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpBase
  {

    #region "Constructors / Destructors"

    public cpBase(string strProductId, double dblPrice, double dblWeight)
      //***
      // Action
      //   - Constructor of a cpBase with a given ProductId, Price and Weight
      // Called by
      //   - cpDerived(string, string, string, string, Double, Double)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mstrProductID = strProductId;
      Price = dblPrice;
      mdblWeight = dblWeight;
    }
    // cpBase(string, double, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private double mdblProductPrice;
    public double mdblWeight;
    public string mstrProductID;

    #endregion

    #region "Properties"

    public double Price
    {

      get
        //***
        // Action Get
        //   - Returns mdblProductPrice
        // Called by
        //   - ShowProduct()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240705 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240705 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdblProductPrice;
      }
      // double Price() (Get)

      set
        //***
        // Action Set
        //   - If dblValue is between 0 and 100
        //     - mdblProductPrice becomes value
        //   - If not
        //     - Show error message in console
        //     - mdblProductPrice becomes 0
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240705 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240705 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if ((value >= 0) && (value <= 100))
        {
          mdblProductPrice = value;
        }
        else
          // (value < 0) OrElse (value > 100)
        {
          Console.WriteLine("Invalid price for " + mstrProductID);
          mdblProductPrice = 0;
        }
        // (value >= 0) AndAlso (value <= 100)

      }
      // Price(double) (Set)

    }
    // double Price()

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ShowProduct()
      //***
      // Action
      //   - Show information about the object
      //   - ProductId, Weight and Price
      // Called by
      //   - cpDerived.ShowBook()
      // Calls
      //   - double Price() (Get)
      // Created
      //   - CopyPaste � 20240705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Product ID: " + mstrProductID);
      Console.WriteLine("Weight: " + mdblWeight);
      Console.WriteLine("Price: " + Price);
    }
		// ShowProduct()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBase

}
// CopyPaste.Learning