﻿//***
// Action
//   - A definition of a Calculator
// Created
//   - CopyPaste – 20251103 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251103 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpCalculator : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpCalculator(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpCalculator starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpCalculator(int, int, Directions.Direction, int) 
    //   - cpProgram.Calculator()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251103 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251103 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpCalculator(int, int, Directions.Direction, int, Color) 

    public cpCalculator(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpCalculator starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpCalculator(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251103 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251103 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpCalculator(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpCarrier theCarrier = new cpCarrier(1, 1, Directions.East, Directions.infinity, Color.blue);
    private cpChecker theChecker = new cpChecker(1, 1, Directions.East, 0, Color.yellow);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void AddAll()
    //***
    // Action
    //   - As long you are not on the second avenue
    //     - Add the column
    //     - Slide all robots to the left
    //   - Add the column
    // Called by
    //   - cpProgram.Calculator()
    // Calls
    //   - AddColumn()
    //   - bool OnSecondAvenue()
    //   - SlideAll()
    // Created
    //   - CopyPaste – 20251103 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251103 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (!OnSecondAvenue())
      {
        AddColumn();
        SlideAll();
      }
      // Not OnSecondAvenue()

      AddColumn();
    }
    // AddAll()

    public void AddColumn()
    //***
    // Action
    //   - Precondition: Looking North at the first street
    //   - Move forward 
    //   - Pick all the beepers above
    //   - Put all the beepers
    //   - Compute the quotient and the remainder (using the checker robot)
    //     - The moment you have counted ten, carry one to the next column
    // Called by
    //   - AddAll()
    // Calls
    //   - bool cpChecker.EnoughToCarry()
    //   - cpCarrier.CarryOne()
    //   - cpCopyPasteRobot.PickAllBeepersInFrontAndGoToBottom()
    //   - cpCopyPasteRobot.PutAllBeepers()
    // Created
    //   - CopyPaste – 20251103 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251103 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      move();
      PickAllBeepersInFrontAndGoToBottom();
      PutAllBeepers();

      while (theChecker.EnoughToCarry())
      {
        theCarrier.CarryOne();
      }
      // theChecker.EnoughToCarry()

    }
    // AddColumn()

    public void GatherHelpers()
    //***
    // Action
    //   - Let the carrier move to the calculator
    //   - Let the checker move to the calculator
    // Called by
    //   - cpProgram.Calculator()
    // Calls
    //   - cpCopyPasteRobot.MoveToRobot()
    // Created
    //   - CopyPaste – 20251103 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251103 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theCarrier.move();
      theCarrier.MoveToRobot();
      theCarrier.turnLeft();
      theChecker.MoveToRobot();
      theChecker.turnLeft();
    }
    // GatherHelpers()

    public bool OnSecondAvenue()
    //***
    // Action
    //   - Precondition: Looking North at the first street
    //   - Define a boolean variable that keeps the value to return
    //   - Turn left
    //   - Move forward
    //   - If front is clear
    //     - Variable becomes false
    //   - If not
    //     - Variable becomes true
    //   - Go back original position
    //   - Turn around
    //   - Move
    //   - Turn Left 
    //   - Return value of variable
    // Called by
    //   - AddAll()
    // Calls
    //   - cpCopyPasteRobot.TurnAround()
    // Created
    //   - CopyPaste – 20251103 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251103 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnReturn;

      turnLeft();
      move();

      if (frontIsClear())
      {
        blnReturn = false;
      }
      else
      // Not frontIsClear()
      {
        blnReturn = true;
      }
      // frontIsClear()

      TurnAround();
      move();
      turnLeft();

      return blnReturn;
    }
    // OnSecondAvenue()

    public void SlideAll()
    //***
    // Action
    //   - Turn left
    //   - Move one forward
    //   - Turn right
    //   - Do the same thing for the two helpers
    //   - The carrier picks all the rubbish with him
    // Called by
    //   - AddAll()
    // Calls
    //   - cpCopyPasteRobot.TurnRight()
    //   - cpCopyPasteRobot.PickAllBeepersInFrontAndGoToBottom()
    // Created
    //   - CopyPaste – 20251103 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251103 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      turnLeft();
      move();
      TurnRight();
      theCarrier.move();
      theCarrier.PickAllBeepersInFrontAndGoToBottom();
      theCarrier.turnLeft();
      theCarrier.move();
      theCarrier.TurnRight();
      theChecker.turnLeft();
      theChecker.move();
      theChecker.TurnRight();
    }
    // SlideAll()

    public void TurnHelpersOff()
    //***
    // Action
    //   -
    // Called by
    //   - cpProgram.Calculator()
   // Calls
    //   - cpCopyPasteRobot.FaceNorth()
    //   - cpCopyPasteRobot.GoToStartPosition()
    // Created
    //   - CopyPaste – 20251103 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251103 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theChecker.GoToStartPosition();
      theChecker.FaceNorth();
      theChecker.move();
      theChecker.turnOff();
      theCarrier.GoToStartPosition();
      theCarrier.FaceNorth();
      theCarrier.move();
      theCarrier.turnOff(); ;
    }
    // TurnHelpersOff()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCalculator

}
// cpKarelTheRobot