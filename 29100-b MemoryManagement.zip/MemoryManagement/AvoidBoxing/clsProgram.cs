﻿//***
// Action
//   - Demo some garbage collector pressure
//   - Compare different ways of using a list
// Created
//   - CopyPaste – 20260608 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260608 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections;
using System.Collections.Generic;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - 
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260531 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Benchmark the marked routines to compare the speed and the memory
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - ArrayList cpDemoSeveralLists.DemoArrayList()
    //   - cpDemoLinqAndExplicitLoops()
    //   - cpDemoSeveralLists()
    //   - cpDemoStringAndStringBuilder()
    //   - cpDemoStruct()
    //   - cpVector3D(float, float, float)
    //   - float cpDemoStruct.DemoDistance()
    //   - float cpDemoStruct.DemoDistanceIn()
    //   - float cpDemoStruct.DemoDistanceInMore()
    //   - float cpDemoStruct.DemoDistanceMore()
    //   - float cpVector3D.Distance(cpVector3D, cpVector3D)
    //   - float cpVector3D.DistanceIn(cpVector3D, cpVector3D)
    //   - List<int> cpDemoLinqAndExplicitLoops.DemoLinq()
    //   - List<int> cpDemoLinqAndExplicitLoops.DemoList()
    //   - List<int> cpDemoSeveralLists.DemoList()
    //   - string cpDemoStringAndStringBuilder.DemoString()
    //   - string cpDemoStringAndStringBuilder.DemoStringBuilder()
    // Created
    //   - CopyPaste – 20260531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260531 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      // BenchmarkRunner.Run<cpDemoSeveralLists>();

      // cpDemoSeveralLists theSplitExample = new cpDemoSeveralLists();
      // ArrayList arrlstExample;
      // List<int> arrExample;

      // arrlstExample = theSplitExample.DemoArrayList();
      // arrExample =  theSplitExample.DemoList();

      // BenchmarkRunner.Run<cpDemoStringAndStringBuilder>();
      // cpDemoStringAndStringBuilder theDemoStringAndStringBuilderExample = new cpDemoStringAndStringBuilder();
      // string strResult;

      // strResult = theDemoStringAndStringBuilderExample.DemoString();
      // strResult = theDemoStringAndStringBuilderExample.DemoStringBuilder();

      // BenchmarkRunner.Run<cpDemoStruct>();

      // cpVector3D cpFirst = new cpVector3D(1, 1, 1);
      // cpVector3D cpSecond = new cpVector3D(2, 2, 2);
      // cpVector3D cpThird = new cpVector3D(0, 0, 0);
      // float distance;

      // distance = cpVector3D.Distance(cpFirst, cpSecond);
      // Console.WriteLine("Distance between the 2 3D points is: {0}", distance);

      // distance = cpVector3D.DistanceIn(cpFirst, cpSecond);
      // Console.WriteLine("Distance between the 2 3D points is: {0}", distance);

      // BenchmarkRunner.Run<cpDemoLinqAndExplicitLoops>();
      // cpDemoLinqAndExplicitLoops theLinqAndListExample = new cpDemoLinqAndExplicitLoops();

      // List<int> lstResult;
      
      // lstResult = theLinqAndListExample.DemoLinq();
      // lstResult = theLinqAndListExample.DemoList();

      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadKey();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning