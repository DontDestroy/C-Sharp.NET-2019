//***
// Action
//   - Using visual inheritance
//   - This form is the parent
// Created
//   - CopyPaste � 20240218 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240218 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.Company
{

  public class frmCompany: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.LinkLabel hypWebsite;
    internal System.Windows.Forms.PictureBox picLogo;
    internal System.Windows.Forms.Button cmdHelp;
    internal System.Windows.Forms.Button cmdAbout;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCompany));
      this.hypWebsite = new System.Windows.Forms.LinkLabel();
      this.picLogo = new System.Windows.Forms.PictureBox();
      this.cmdHelp = new System.Windows.Forms.Button();
      this.cmdAbout = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // hypWebsite
      // 
      this.hypWebsite.Location = new System.Drawing.Point(199, 244);
      this.hypWebsite.Name = "hypWebsite";
      this.hypWebsite.Size = new System.Drawing.Size(96, 16);
      this.hypWebsite.TabIndex = 5;
      this.hypWebsite.TabStop = true;
      this.hypWebsite.Text = "Visit our Web Site";
      // 
      // picLogo
      // 
      this.picLogo.Image = ((System.Drawing.Image)(resources.GetObject("picLogo.Image")));
      this.picLogo.Location = new System.Drawing.Point(15, 12);
      this.picLogo.Name = "picLogo";
      this.picLogo.Size = new System.Drawing.Size(192, 64);
      this.picLogo.TabIndex = 6;
      this.picLogo.TabStop = false;
      // 
      // cmdHelp
      // 
      this.cmdHelp.Location = new System.Drawing.Point(223, 52);
      this.cmdHelp.Name = "cmdHelp";
      this.cmdHelp.TabIndex = 4;
      this.cmdHelp.Text = "&Help";
      this.cmdHelp.Click += new System.EventHandler(this.cmdHelp_Click);
      // 
      // cmdAbout
      // 
      this.cmdAbout.Location = new System.Drawing.Point(223, 12);
      this.cmdAbout.Name = "cmdAbout";
      this.cmdAbout.TabIndex = 3;
      this.cmdAbout.Text = "&About";
      this.cmdAbout.Click += new System.EventHandler(this.cmdAbout_Click);
      // 
      // frmCompany
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(312, 273);
      this.Controls.Add(this.hypWebsite);
      this.Controls.Add(this.picLogo);
      this.Controls.Add(this.cmdHelp);
      this.Controls.Add(this.cmdAbout);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCompany";
      this.Text = "Copy Paste Software";
      this.Load += new System.EventHandler(this.frmCompany_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDfrmCompanyefault'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmCompany()
      //***
      // Action
      //   - Create new instance of 'frmCompany'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmCompany()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAbout_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show information about Copy Paste
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strMessage = "Teaching since 1991." + Environment.NewLine + "Developing .NET applications since 2002.";

      MessageBox.Show(strMessage, "Copy Paste", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // cmdAbout_Click(System.Object, System.EventArgs) Handles cmdAbout.Click

    public virtual void cmdHelp_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    
    }
    // cmdHelp_Click(System.Object, System.EventArgs) Handles cmdHelp.Click

    private void frmCompany_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show information about Copy Paste
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show("Load Company form.", "Copy Paste");
    }
    // frmCompany_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmCompany
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmCompany());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmCompany

}
// CopyPaste.Learning.Company