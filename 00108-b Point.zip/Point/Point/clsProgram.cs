//***
// Action
//   - Testroutine of an instance of cpPoint
// Created
//   - CopyPaste � 20231230 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231230 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Math;
using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace Point
{

	public class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main()
			//***
			// Action
			//   - Create a new instance of a cpPoint
			//   - Get some properties
			//   - Set some properties
			//   - Use of ToString()
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - cpPoint()
			//   - cpPoint(int, int)
			//   - cpPoint.X(int) (Set)
			//   - cpPoint.Y(int) (Set)
			//   - int cpPoint.X (Get)
			//   - int cpPoint.Y (Get)
			//   - string cpPoint.ToString()
			// Created
			//   - CopyPaste � 20231230 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231230 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
  	{
	    cpPoint thecpPoint;
			cpPoint thecpPointZero;
	    string strOutput;

		  thecpPoint = new cpPoint(72, 115);
	    thecpPointZero = new cpPoint();

	    strOutput = "X coordinate is " + thecpPoint.X + ControlChars.CrLf + "Y coordinate is " + thecpPoint.Y;
	    MessageBox.Show(strOutput, "Demonstrating Class cpPoint");

	    strOutput = "X coordinate is " + thecpPointZero.X + ControlChars.CrLf + "Y coordinate is " + thecpPointZero.Y;
		  MessageBox.Show(strOutput, "Demonstrating Class cpPoint");

	    thecpPoint.X = 10;
		  thecpPoint.Y = 10;
	    strOutput = "The type of point is " + thecpPoint.ToString();
		  MessageBox.Show(strOutput, "Demonstrating Class cpPoint");
			strOutput = "The type of point is " + thecpPoint.GetType().ToString();
			MessageBox.Show(strOutput, "Demonstrating Class cpPoint");
		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpProgram

}
// Point