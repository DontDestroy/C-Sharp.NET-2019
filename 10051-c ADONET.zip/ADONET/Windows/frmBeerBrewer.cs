//***
// Action
//   - Show brewer and beer in 2 listboxes, with a splitter
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBeerBrewer: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.ListBox lstBeer;
    internal System.Windows.Forms.Splitter splVertical;
    internal System.Windows.Forms.ListBox lstBrewer;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBeerBrewer));
      this.lstBeer = new System.Windows.Forms.ListBox();
      this.splVertical = new System.Windows.Forms.Splitter();
      this.lstBrewer = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // lstBeer
      // 
      this.lstBeer.Dock = System.Windows.Forms.DockStyle.Fill;
      this.lstBeer.IntegralHeight = false;
      this.lstBeer.Location = new System.Drawing.Point(155, 0);
      this.lstBeer.Name = "lstBeer";
      this.lstBeer.Size = new System.Drawing.Size(477, 273);
      this.lstBeer.TabIndex = 5;
      // 
      // splVertical
      // 
      this.splVertical.Location = new System.Drawing.Point(152, 0);
      this.splVertical.Name = "splVertical";
      this.splVertical.Size = new System.Drawing.Size(3, 273);
      this.splVertical.TabIndex = 4;
      this.splVertical.TabStop = false;
      // 
      // lstBrewer
      // 
      this.lstBrewer.Dock = System.Windows.Forms.DockStyle.Left;
      this.lstBrewer.IntegralHeight = false;
      this.lstBrewer.Location = new System.Drawing.Point(0, 0);
      this.lstBrewer.Name = "lstBrewer";
      this.lstBrewer.Size = new System.Drawing.Size(152, 273);
      this.lstBrewer.TabIndex = 3;
      this.lstBrewer.SelectedIndexChanged += new System.EventHandler(this.lstBrewer_SelectedIndexChanged);
      // 
      // frmBeerBrewer
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(632, 273);
      this.Controls.Add(this.lstBeer);
      this.Controls.Add(this.splVertical);
      this.Controls.Add(this.lstBrewer);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBeerBrewer";
      this.Text = "Beer Brewer";
      this.Load += new System.EventHandler(this.frmBeerBrewer_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBeerBrewer'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBeerBrewer()
      //***
      // Action
      //   - Create new instance of 'frmBeerBrewer'
      // Called by
      //   - frmMain.cmdBeerAndBrewer_Click(System.Object, System.EventArgs) Handles cmdBeerAndBrewer.Click
      //   - User action (Starting the form)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
    }
    // frmBeerBrewer()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmBeerBrewer_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a command for brewer
      //   - Define a data reader for brewer
      //   - Create an instance of cpConnection for beer database
      //   - Try to
      //     - Create a command
      //     - Set an SQL statement to the command
      //     - Execute the command
      //     - Loop thru the data
      //       - Create a new instance of the brewer
      //       - Add the instance to the list of brewers
      //   - On possible error
      //     - Show exception message
      //   - Close brewer data row
      //   - Dispose connection
      //   - Create an instance of cpCountry
      //   - Create the country data set
      //   - Set the datasource of the continent list box to the country data set
      //   - Display the name of the continent in the list box
      //   - Set the datasource of the country list box to the country data set
      //   - Display the names of the countries in the list box that are of the chosen continent
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpBrewer(System.Int32, string)
      //   - cpConnection(string)
      //   - string cpBrewer.ToString()
      //   - thecpConnection.Dispose() Implements IDisposable.Dispose
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      IDbCommand cmmBrewer;
      IDataReader drdBrewer = null;
      cpConnection thecpConnection = new cpConnection("cpBeer");

      try
      {
        cmmBrewer = thecpConnection.Connection.CreateCommand();
        cmmBrewer.CommandType = CommandType.Text;
        cmmBrewer.CommandText = "SELECT lngIdBrewer, strBrewerName FROM tblCPBrewer ORDER BY strBrewerName";
        drdBrewer = cmmBrewer.ExecuteReader();

        while (drdBrewer.Read())
        {
          cpBrewer theBrewer = new cpBrewer(Convert.ToInt32(drdBrewer["lngIdBrewer"]), drdBrewer["strBrewerName"].ToString());
                    
          lstBrewer.Items.Add(theBrewer);
        }
        // Not drdBrewer.Read()
      
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
        drdBrewer.Close();
        thecpConnection.Dispose();
      }
    
    }
    // frmBeerBrewer_Load(System.Object, System.EventArgs) Handles this.Load

    private void lstBrewer_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a command for beer
      //   - Define a data reader for beer
      //   - Create an instance of cpConnection for beer database
      //   - Define a parameter for filtering beers on brewer
      //   - Try to
      //     - Clear the beer list box
      //     - Find the brewer key
      //     - Create a command
      //     - Set an SQL statement to the command
      //     - Create a parameter
      //     - Set the parameter
      //     - Add the parameter to the command
      //     - Execute the command
      //     - Loop thru the data
      //       - Add a text to the list of beers (the beer name)
      //   - On possible error
      //     - Show exception message
      //   - Close brewer data row
      //   - Dispose connection
      //   - Create an instance of cpCountry
      //   - Create the country data set
      //   - Set the datasource of the continent list box to the country data set
      //   - Display the name of the continent in the list box
      //   - Set the datasource of the country list box to the country data set
      //   - Display the names of the countries in the list box that are of the chosen continent
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpBrewer(System.Int32, string)
      //   - cpConnection.Dispose() Implements IDisposable.Dispose
      //   - cpConnection(string)
      //   - System.Int32 cpBrewer.KeyBrewer (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      IDbCommand cmmBeer;
      IDataReader drdBeer = null;
      System.Int32 lngKeyBrewer;
      cpConnection thecpConnection = new cpConnection("cpBeer");
      IDataParameter theParameterBrewer;

      try
      {
        lstBeer.Items.Clear();
        lngKeyBrewer = ((cpBrewer)lstBrewer.SelectedItem).KeyBrewer;
        cmmBeer = thecpConnection.Connection.CreateCommand();
        cmmBeer.CommandType = CommandType.Text;
        cmmBeer.CommandText = "SELECT strBeerName FROM tblCPBeer WHERE lngBrewerId = @KeyBrewer ORDER BY strBeerName";

        theParameterBrewer = cmmBeer.CreateParameter();
        theParameterBrewer.ParameterName = "@KeyBrewer";
        theParameterBrewer.Value = lngKeyBrewer;

        cmmBeer.Parameters.Add(theParameterBrewer);

        drdBeer = cmmBeer.ExecuteReader();

        while (drdBeer.Read())
        {
          lstBeer.Items.Add(drdBeer["strBeerName"]);
        }
        // Not drdBeer.Read
      
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
        drdBeer.Close();
        thecpConnection.Dispose();
      }
    
    }
    // lstBrewer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBrewer.SelectedIndexChanged

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBeerBrewer

}
// CopyPaste.Learning