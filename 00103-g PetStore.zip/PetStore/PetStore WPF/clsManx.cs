//***
// Action
//   - A pet store, the definition of a manx (base class, but inherits from cpCat)
//   - Working with properties (Get and Set) and methods in several classes, that can be reused
// Created
//   - CopyPaste � 20230407 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW
// Tested
//   - CopyPaste � 20230407 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace CopyPaste.Pet.Cat
{

  public class cpManx : cpCat
  {

    #region "Constructors / Destructors"

    public cpManx() : base ()
    //***
    // Action
    //   - Creating an instance of cpManx with default parameters
    //   - Breed becomes "Manx"
    //   - Cost becomes 100
    //   - Write a line "cpManx default constructor"
    // Called by
    //   - 
    // Calls
    //   - base()
    //   - CopyPaste.Pet.cpAnimal.Breed(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Cost(decimal) (Set)
    // Created
    //   - CopyPaste � 20230407 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20230407 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Breed = "Manx";
      Cost = 100;
      Console.WriteLine("cpManx default constructor");
    }
    // cpManx()

    public cpManx(string strName, string strColor) : base (strName)
    //***
    // Action
    //   - Creating an instance of cpManx with default parameters and strName
    //   - Breed becomes "Manx"
    //   - Cost becomes 100
    //   - Coloration becomes strColor
    //   - Write a line "cpManx overloaded constructor"
    // Called by
    //   - wpfPetStore.FillArray()
    // Calls
    //   - base(string)
    //   - CopyPaste.Pet.cpAnimal.Breed(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Coloration(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Cost(decimal) (Set)
    // Created
    //   - CopyPaste � 20230407 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20230407 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Breed = "Manx";
      Cost = 100;
      Coloration = strColor;
      Console.WriteLine("cpManx overloaded constructor");
    }
    // cpManx(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override string Speak()
    //***
    // Action
    //   - Write a line to the console with "CopyPaste.Pet.Cat.cpManx.Speak"
    //   - Return "(Name) says 'Meow, ffftttt!'"
    // Called by
    //   - wpfPetStore.cmdSpeak_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdSpeak.Click
    // Calls
    //   - string CopyPaste.Pet.cpPet.Name (Get)
    //   - Overrides string CopyPaste.Pet.cpAnimal.Speak()
    // Created
    //   - CopyPaste � 20230407 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20230407 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Console.WriteLine("CopyPaste.Pet.Cat.cpManx.Speak");
      return Name + " says 'Meow, ffftttt!'";
    }
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpManx

}
// CopyPaste.Pet.Cat