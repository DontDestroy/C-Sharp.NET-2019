﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="wfrmWelcome.aspx.vb" Inherits="Welcome.CopyPaste.Learning.wfrmWelcome" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Welcome</title>
</head>
<body ms_positioning="GridLayout">
  <form id="wfrmWelcome" method="post" runat="server">
    <asp:Label ID="lblToday" Style="z-index: 101; position: absolute; top: 24px; left: 32px" runat="server"></asp:Label>
    <asp:TextBox ID="txtName" Style="z-index: 106; position: absolute; top: 88px; left: 96px" runat="server"></asp:TextBox>
    <asp:Label ID="lblWelcome" Style="z-index: 105; position: absolute; top: 184px; left: 32px"
      runat="server"></asp:Label>
    <asp:Button ID="cmdOK" Style="z-index: 104; position: absolute; top: 144px; left: 32px" runat="server"
      Text="OK" Width="56px"></asp:Button>
    <asp:Label ID="lblName" Style="z-index: 103; position: absolute; top: 88px; left: 32px" runat="server">Name</asp:Label>
    <asp:Label ID="lblInfo" Style="z-index: 102; position: absolute; top: 56px; left: 32px" runat="server"></asp:Label>
  </form>
</body>
</html>
