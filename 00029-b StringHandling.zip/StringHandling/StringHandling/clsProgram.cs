//***
// Action
//   - String handling without using Microsoft.VisualBasic namespace
// Created
//   - CopyPaste � 20240216 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240216 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
		
    public static void Main()
      //***
      // Action
      //   - Define some variables
      //   - Show some info on the screen
      //     - Using IndexOf, LastIndexOf, Substring, ToLower, ToUpper, Trim, TrimStart
      // Called by
      //   - User action (Starting the program)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240216 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngPosition1;
      int lngPosition2;
      string strFirst;
      string strSecond;
      string strText = "A long time ago, in a galaxy far, far away ...";
      string strThird;

      Console.WriteLine("THE STRING HANDLING PROGRAM");
      Console.WriteLine("---------------------------");
      Console.WriteLine();
      Console.WriteLine("strText = " + strText);

      Console.WriteLine();
      Console.WriteLine("strText.Substring(0, 15)                   = " + strText.Substring(0, 15));
      Console.WriteLine("strText.Substring(17, 15)                  = " + strText.Substring(17, 15));
      Console.WriteLine("strText.Substring(strText.Length - 17, 17) = " + strText.Substring(strText.Length - 17, 17));
      Console.WriteLine();

      lngPosition1 = strText.IndexOf(",");
      lngPosition2 = strText.LastIndexOf(",");

      strFirst = strText.Substring(0, lngPosition1);
      strSecond = strText.Substring(lngPosition1 + 1, lngPosition2 - lngPosition1 - 1);
      strThird = strText.Substring(lngPosition2 + 1);

      Console.WriteLine("strFirst.Trim()      = " + strFirst.Trim());
      Console.WriteLine("strSecond.Trim()     = " + strSecond.Trim());
      Console.WriteLine("strThird.TrimStart() = " + strThird.TrimStart());
      Console.WriteLine();
      
      Console.WriteLine("strFirst.ToUpper()  = " + strFirst.ToUpper());
      Console.WriteLine("strSecond.ToUpper() = " + strSecond.ToUpper());
      Console.WriteLine("strThird.ToLower()  = " + strThird.ToLower());
      Console.WriteLine();

      Console.WriteLine("Press Enter...");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning