//***
// Action
//   - Setting some directory attributes
// Created
//   - CopyPaste � 20240719 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240719 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - If "C:\Windows\Temp" exists
      //     - Get the current date and time
      //     - Define a directory info
      //     - Try to
      //       - Set attributes
      //       - Show message that attributes are set
      //     - When error
      //       - Show error message
      //       - Show exception message
      //   - If not
      //     - Show error message
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (Directory.Exists("C:\\WINDOWS\\Temp"))
      {
        DateTime DateTimeNow = DateTime.Now;
        DirectoryInfo theDirectory = new DirectoryInfo("C:\\WINDOWS\\Temp");

        try
        {
          theDirectory.CreationTime = DateTimeNow;
          theDirectory.LastAccessTime = DateTimeNow;
          theDirectory.LastWriteTime = DateTimeNow;
          Console.WriteLine("Directory attributes updated");
        }
        catch (Exception theException)
        {
          Console.WriteLine("Error updating attributes");
          Console.WriteLine("Error {0}: ", theException.Message);
        }
        finally
        {
        }

      }
      else
        // Not Directory.Exists("C:\WINDOWS\Temp")
      {
        Console.WriteLine("C:\\WINDOWS\\Temp does not exist");
      }
      // Directory.Exists("C:\\WINDOWS\\Temp")

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning