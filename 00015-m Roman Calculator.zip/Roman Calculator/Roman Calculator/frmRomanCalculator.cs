//***
// Action
//   - Working with basic arrays
//   - Recalculate a number towards a Roman Number
// Created
//   - CopyPaste � 20220215 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220215 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Default
{

  public class frmRomanCalculator : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.Label lblDescription;
    internal System.Windows.Forms.Button cmdCalculate;
    internal System.Windows.Forms.TextBox txtInput;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmRomanCalculator));
      this.lblResult = new System.Windows.Forms.Label();
      this.lblDescription = new System.Windows.Forms.Label();
      this.cmdCalculate = new System.Windows.Forms.Button();
      this.txtInput = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // lblResult
      // 
      this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblResult.Location = new System.Drawing.Point(32, 168);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(200, 40);
      this.lblResult.TabIndex = 7;
      this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblDescription
      // 
      this.lblDescription.Location = new System.Drawing.Point(64, 128);
      this.lblDescription.Name = "lblDescription";
      this.lblDescription.Size = new System.Drawing.Size(128, 23);
      this.lblDescription.TabIndex = 6;
      this.lblDescription.Text = "Roman Numeral Result";
      this.lblDescription.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cmdCalculate
      // 
      this.cmdCalculate.Location = new System.Drawing.Point(64, 80);
      this.cmdCalculate.Name = "cmdCalculate";
      this.cmdCalculate.Size = new System.Drawing.Size(128, 24);
      this.cmdCalculate.TabIndex = 5;
      this.cmdCalculate.Text = "Calculate";
      this.cmdCalculate.Click += new System.EventHandler(this.cmdCalculate_Click);
      // 
      // txtInput
      // 
      this.txtInput.Location = new System.Drawing.Point(64, 40);
      this.txtInput.Name = "txtInput";
      this.txtInput.Size = new System.Drawing.Size(128, 20);
      this.txtInput.TabIndex = 4;
      this.txtInput.Text = "";
      // 
      // frmRomanCalculator
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(264, 229);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.lblDescription);
      this.Controls.Add(this.cmdCalculate);
      this.Controls.Add(this.txtInput);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmRomanCalculator";
      this.Text = "Roman Calculator";
      this.Load += new System.EventHandler(this.frmRomanCalculator_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmRomanCalculator'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220215 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmRomanCalculator()
      //***
      // Action
      //   - Create instance of 'frmRomanCalculator'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220215 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmRomanCalculator()

    #endregion
    
    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    const string mstrProgramName = "Copy Paste Tryout : Roman Calculator";
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCalculate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Setting an array of Arabic numbers
      //   - Setting an array of Roman numbers
      //   - Getting the lower and upper bound
      //   - Getting the number from the form
      //   - Loop from upperbound to lowerbound of the array
      //     - As long as the number is bigger than the Arabic number in the array
      //       - Add a roman digit
      //   - Show the Roman number on the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - int Array.GetLowerBound(int)
      //   - int Array.GetUpperBound(int)
      // Created
      //   - CopyPaste � 20220215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220215 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int[] arrArabics = new int[] {1, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000};
      long lngArabicLower = arrArabics.GetLowerBound(0);
      long lngArabicUpper = arrArabics.GetUpperBound(0);
      long lngCounter;
      long lngInput; 
      string[] arrRomans= new string[] {"I", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M"};
      string strInput = txtInput.Text;
      string strOutPut = "";

      lblResult.Text = "";
      lngInput = long.Parse(txtInput.Text);

      for (lngCounter = arrArabics.GetUpperBound(0); lngCounter >= arrArabics.GetLowerBound(0); lngCounter--)
      {

        while (lngInput >= arrArabics[lngCounter])
        {
          lngInput -= arrArabics[lngCounter];
          strOutPut += arrRomans[lngCounter];
        }
        // (lngInput < arrArabics[lngCounter])

      }
      // lngCounter = arrArabics.GetLowerBound(0) - 1
      
      lblResult.Text = strInput + " = " + strOutPut;
    }
    //cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click

    private void frmRomanCalculator_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the title of the form
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220215 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Text = mstrProgramName;
    }
    // frmRomanCalculator_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmRomanCalculator
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220215 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220215 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmRomanCalculator());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmRomanCalculator

}
// RomanCalculator