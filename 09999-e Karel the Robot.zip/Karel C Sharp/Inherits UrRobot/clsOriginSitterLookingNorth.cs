﻿//***
// Action
//   - Definition of a green robot at origin looking to the North
// Created
//   - CopyPaste – 20251011 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251011 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpOriginSitterLookingNorth : UrRobot
	{

		#region "Constructors / Destructors"

		public cpOriginSitterLookingNorth() : base(1, 1, Directions.North, 0, Color.green)
		//***
		// Action
		//   - Basic constructor (start situation)
	  //   - Robot becomes a green origin sitter starting at position (1, 1), looking to the North with no beepers in the bag
		//   - Nothing else happens
		// Called by
		//   - cpProgram.OriginSitterLookingNorth()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251011 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251011 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
  	}
		// cpOriginSitterLookingNorth()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// cpOriginSitterLookingNorth

}
// cpKarelTheRobot