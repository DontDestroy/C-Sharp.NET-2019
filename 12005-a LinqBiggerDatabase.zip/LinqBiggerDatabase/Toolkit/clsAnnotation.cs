﻿//***
// Action
//   - Create annotations (attributes) used to document some code
// Created
//   - CopyPaste – 20230719 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230719 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Text;

namespace CopyPaste.Toolkit
{

  [AttributeUsageAttribute(AttributeTargets.Class | AttributeTargets.Method | AttributeTargets.Property)]
  public class cpAnnotationAttribute: System.Attribute
  {

    #region "Constructors / Destructors"

    public cpAnnotationAttribute()
    //***
    // Action
    //   - Empty constructor of a cpAnnotation
    // Called by
    //   - cpAnnotationAttribute(string)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpAnnotationAttribute()

    public cpAnnotationAttribute(string strExampleTag) : this()
    //***
    // Action
    //   - Constructor of a cpAnnotation
    //   - The argument are some tags for the example
    // Called by
    //   - 
    // Calls
    //   - cpAnnotationAttribute()
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpAnnotationAttribute(string)

    public cpAnnotationAttribute(string strExampleTag, string strEntity) : this(strExampleTag)
    //***
    // Action
    //   - Constructor of a cpAnnotation
    //   - The first argument are some tags for the example
    //   - The second argument are some tags for the entity used
    // Called by
    //   - 
    // Calls
    //   - cpAnnotationAttribute(string)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpAnnotationAttribute(string, string)

    public cpAnnotationAttribute(string strExampleTag, string strEntity, string strTechnique) : this(strExampleTag, strEntity)
    //***
    // Action
    //   - Constructor of a cpAnnotation
    //   - The first argument are some tags for the example
    //   - The second argument are some tags for the entity used
    //   - The third argument are some tags for the techniques used
    // Called by
    //   - 
    // Calls
    //   - cpAnnotationAttribute(string, string)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpAnnotationAttribute(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpAnnotationAttribute

}
// CopyPaste.Toolkit