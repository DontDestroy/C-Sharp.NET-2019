﻿//***
// Action
//   - Definition of an AircraftType
// Created
//   - CopyPaste – 20230714 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230714 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CopyPaste.BusinessObjects
{

  public class AircraftType
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public virtual string Manufacturer { get; set; }
    public virtual string Name { get; set; }
    
    [KeyAttribute]
    public virtual byte TypeId { get; set; }

    // A relation towards entity class AircraftTypeDetail (the one part)
    // Towards AircraftTypeDetail it is a 1:1 relationship (unidirectional, no ForeignKey Property)
    public virtual AircraftTypeDetail Detail { get; set; }

    // A relation towards entity class Flight (the many part)
    public virtual List<Flight> Flight { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // AircraftType

}
// CopyPaste.BusinessObjects 