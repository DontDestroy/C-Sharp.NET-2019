﻿//***
// Action
//   - Implementation of a cpDuck
//     - All ducks quack and swim
//     - Display (how do I look like) is an abstract method
//       - All class that inherit must implement the Display method
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
// Created
//   - CopyPaste – 20240716 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240716 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Game.Duck.Library
{

	public abstract class cpDuck
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpDuck
		/// </summary>
		public cpDuck()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - User action (Creating an instance)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240716 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240716 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// The visualization (displaying) of a cpDuck
		/// </summary>
		public abstract void Display();

		/// <summary>
		/// What noise is the cpDuck making 
		/// </summary>
		public virtual void Quack()
		//***
		// Action
		//   - Define the noise that the cpDuck makes
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240716 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240716 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Represent the sound of a cpDuck");
		}
		// Quack()

		/// <summary>
		/// How is a cpDuck moving on water
		/// </summary>
		public virtual void Swim()
		//***
		// Action
		//   - Define how the cpDuck moves in water
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240716 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240716 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("cpDuck is moving around in water");
		}
		// Swim()

		/// <summary>
		/// How is a cpDuck moving on land
		/// </summary>
		public virtual void Walk()
		//***
		// Action
		//   - Define how the cpDuck moves on land
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240716 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240716 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("cpDuck is moving around on land");
		}
		// Walk()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpDuck

}
// CopyPaste.Game.Duck.Library