﻿//***
// Action
//   - A collection with the American Presidents
// Created
//   - CopyPaste – 20230427 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230427 – VVDW
// Proposal (To Do)
//   -
//***

namespace AmericanHistory
{

  public class cpPresident
  {

    #region "Constructors / Destructors"

    public cpPresident(string strName)
    //***
    // Action
    //   - Creating an instance of a cpPresident
    // Called by
    //   - FillPresidents()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230427 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - This is normally done by a database query
    //***
    {
      Name = strName;
    }
    // cpPresident(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    static private cpPresident[] arrPresidents;

    #endregion

    #region "Properties"

    static public cpPresident[] AllPresidents
    {
      //***
      // Action Get
      //   - Returning an array of cpPresidents
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20230427 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20230427 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      get
      {
        return arrPresidents;
      }
      // cpPresident[] AllPresidents (Get)

    }
    // cpPresident[] AllPresidents

    public string Name { get; set; }

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void FillPresidents()
    //***
    // Action
    //   - Creating an array with all the American presidents
    // Called by
    //   -  
    // Calls
    //   - cpPresident(string)
    // Created
    //   - CopyPaste – 20230427 – VVDW
    // Changed
    //   - CopyPaste – 20241226 – VVDW – Add new president
    // Tested
    //   - CopyPaste – 20230427 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      arrPresidents = new cpPresident[] {
        new cpPresident("George Washington"), new cpPresident("John Adams"), new cpPresident("Thomas Jefferson"),
        new cpPresident("James Madison"), new cpPresident("James Monroe"), new cpPresident("John Quincy Adams"),
        new cpPresident("Andrew Jackson"), new cpPresident("Martin Van Buren"), new cpPresident("William Henry Harrison"),
        new cpPresident("John Tyler"), new cpPresident("James K. Polk"), new cpPresident("Zachary Taylor"),
        new cpPresident("Millard Fillmore"), new cpPresident("Franklin Pierce"), new cpPresident("James Buchanan"),
        new cpPresident("Abraham Lincoln"), new cpPresident("Andrew Johnson"), new cpPresident("Ulysses S. Grant"),
        new cpPresident("Rutherford B. Hayes"), new cpPresident("James A. Garfield"), new cpPresident("Chester A. Arthur"),
        new cpPresident("Grover Cleveland"), new cpPresident("Benjamin Harrison"), new cpPresident("William McKinley"),
        new cpPresident("Theodore Roosevelt"), new cpPresident("William Howard Taft"), new cpPresident("Woordrow Wilson"),
        new cpPresident("Warren G. Harding"), new cpPresident("Calvin Coolidge"), new cpPresident("Herbert Hoover"),
        new cpPresident("Franklin D. Roosevelt"), new cpPresident("Harry S. Truman"),new cpPresident("Dwight D. Eisenhower"),
        new cpPresident("John F. Kennedy"), new cpPresident("Lyndon B. Johnson"), new cpPresident("Richard Nixon"),
        new cpPresident("Gerald Ford"), new cpPresident("Jimmy Carter"), new cpPresident("Ronald Reagan"),
        new cpPresident("George H. W. Bush"), new cpPresident("Bill Clinton"),new cpPresident("George W. Bush"),
        new cpPresident("Barack Obama"), new cpPresident("Donald Trump"), new cpPresident("Joe Biden"),
        new cpPresident("Donald Trump")
        };

    }
    // FillPresidents()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPresident

}
// AmericanHistory