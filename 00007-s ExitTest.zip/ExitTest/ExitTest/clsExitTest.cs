//***
// Action
//   - Example of Break For, Break Do, Break While
// Created
//   - CopyPaste � 20080601 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20080601 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace ExitTest
{

  class cpExitTest
	{

    static void Main()
      //***
      // Action
      //   - Loop from 1 to 10 (lngCounter)
      //     - At 3 exit loop
      //   - Prepare output
      //   - Loop while <= 10
      //     - At 5 exit loop
      //     - Add 1 to lngCounter
      //  �- Prepare output
      //   - Loop while <= 10
      //     - At 7 exit loop
      //     - Add 1 to lngCounter
      //   - Prepare output
      //   - Show result in messagebox
      // Called by
      //   - User action (Starting the application) 
      // Calls
      //   - DialogResult System.Windows.Forms.MessageBox.Show(string, string, System.Windows.Forms.MessageBoxButtons, System.Windows.Forms.MessageBoxIcon)
      // Created
      //   - CopyPaste � 20080601 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20080601 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      long lngCounter;
      string strOutput;

      for (lngCounter = 1; lngCounter <= 10; lngCounter++)
      {

        if (lngCounter == 3)
        {
          break;
        }
        else
          // lngCounter != 3
        {
        }
        // lngCounter == 3

      }
      // lngCounter = 11 Or Exit on lngCounter = 3

      strOutput = "Counter equals " + lngCounter + " after exiting For structure\n";

      do
      {
        
        if (lngCounter == 5)
        {
          break;
        }
        else
          //lngCounter != 5
        {
        }
        // lngCounter == 5

        lngCounter += 1;
      }
      while (lngCounter <= 10);
      // lngCounter > 10 Or Exit on lngCounter = 5

      strOutput += "Counter equals " + lngCounter + " after exiting Do While structure\n";
      
      while (lngCounter <= 10)
      {
        
        if (lngCounter == 7)
        {
          break;
        }
        else
          // lngCounter != 7 
        {
        }
        // lngCounter = 7 
        
        lngCounter += 1;
      }
      //End While
      // lngCounter > 10 or Exit on lngCounter = 7
      
      strOutput += "Counter equals " + lngCounter + " after exiting While structure";
      MessageBox.Show(strOutput, "Exit Test", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // Main()

  }
  // cpExitTest

}
// ExitTest