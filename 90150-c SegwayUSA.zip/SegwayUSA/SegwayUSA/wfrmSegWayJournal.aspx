﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmSegWayJournal.aspx.cs" Inherits="CopyPaste.Learning.wfrmSegWayJournal" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>My Trip Around the USA on a Segway</title>
  <link type="text/css" rel="stylesheet" href="cssJournal.css">
</head>
<body>
  <form id="wfrmSegWayJournal">
    <h1>Segway'n USA</h1>
    <p>
      Documenting my trip around the US on my very own Segway!
    </p>
    <h2>August 20, 2012</h2>
    <p>
      <img src="Resources/segway2.jpg" alt="Picture can't be found">
    </p>
    <p>
      Well I made it 1.931 km already, and I passed through some interesting places on the way: 
    </p>
    <table>
      <caption>
        The cities I visited on my Segway'n USA travels
      </caption>
      <tr>
        <th>City</th>
        <th>Date</th>
        <th>Temperature</th>
        <th>Altitude</th>
        <th>Population</th>
        <th>Diner Rating</th>
      </tr>
      <tr>
        <td>Walla Walla, WA</td>
        <td>June 15, 2012</td>
        <td class="right">24</td>
        <td class="right">367 m</td>
        <td class="right">29.686</td>
        <td class="center">4/5</td>
      </tr>
      <tr class="cellcolor">
        <td>Magic City, ID</td>
        <td>June 25, 2012</td>
        <td class="right">23</td>
        <td class="right">1.619 m</td>
        <td class="right">50</td>
        <td class="center">3/5</td>
      </tr>
      <tr>
        <td>Bountiful, UT</td>
        <td>July 10, 2012</td>
        <td class="right">33</td>
        <td class="right">1.288 m</td>
        <td class="right">41.173</td>
        <td class="center">4/5</td>
      </tr>
      <tr class="cellcolor">
        <td>Last Chance, CO</td>
        <td>July 23, 2012</td>
        <td class="right">39</td>
        <td class="right">1.457 m</td>
        <td class="right">265</td>
        <td class="center">3/5</td>
      </tr>
      <tr>
        <td rowspan="2">Truth or Consequences, NM</td>
        <td>August 9, 2012</td>
        <td class="right">34</td>
        <td class="right" rowspan="2" >1.293 m</td>
        <td class="right" rowspan="2" >7.289</td>
        <td class="center">5/5</td>
      </tr>
      <tr>
        <td>August 27, 2012</td>
        <td class="right">37</td>
        <td class="center">
          <table>
            <tr>
              <th class="noColor">Tess</th>
              <td>5/5</td>
            </tr>
            <tr>
              <th class="noColor">Tony</th>
              <td>4/5</td>
            </tr>
          </table>
        </td>
      </tr>
      <tr class="cellcolor">
        <td>Why, AZ</td>
        <td>August 18, 2012</td>
        <td class="right">40</td>
        <td class="right">262 m</td>
        <td class="right">480</td>
        <td class="center">3/5</td>
      </tr>
    </table>
    <h2>July 14, 2012</h2>
    <p>
      I saw some Burma Shave style signs on the side of the road today:
    </p>
    <blockquote>
      Passing cars,
      <br>
      When you can't see,
      <br>
      May get you,
      <br>
      A glimpse,
      <br>
      Of eternity.
      <br>
    </blockquote>
    <p>
      I definitely won't be passing any cars.
    </p>
    <h2>June 2, 2012</h2>
    <p>
      <img src="Resources/segway1.jpg" alt="Picture can't be found">
    </p>
    <p>
      My first day of the trip! I can't believe I finally got everything packed and ready to go.
      Because I'm on a Segway, I wasn't able to bring a whole lot with me:
    </p>
    <ul>
      <li>cellphone</li>
      <li>iPod</li>
      <li>digital camera</li>
      <li>and a protein bar</li>
    </ul>
    <p>
      Just the essentials. As Lao Tzu would have said,
      <q>A journey of a thousand km begins with one Segway.</q>
    </p>
  </form>
</body>
</html>
