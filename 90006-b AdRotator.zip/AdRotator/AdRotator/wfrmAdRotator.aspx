﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmAdRotator.aspx.cs" Inherits="CopyPaste.Learning.wfrmAdRotator" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
	<title>wfrmAdRotator</title>
</head>
	<body>
		<form id="wfrmAdRotator" method="post" runat="server">
			<asp:AdRotator id="adrAds" style="Z-INDEX: 101; LEFT: 80px; POSITION: absolute; TOP: 64px" runat="server"
				AdvertisementFile="Ads.xml"></asp:AdRotator>
		</form>
	</body>
</html>
