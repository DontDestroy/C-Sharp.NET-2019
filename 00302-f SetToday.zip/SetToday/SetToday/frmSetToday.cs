//***
// Action
//   - Select a file and set the date and time attributes to today and now
// Created
//   - CopyPaste � 20240902 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240902 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSetToday: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdSelect;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSetToday));
      this.cmdSelect = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdSelect
      // 
      this.cmdSelect.Location = new System.Drawing.Point(96, 96);
      this.cmdSelect.Name = "cmdSelect";
      this.cmdSelect.Size = new System.Drawing.Size(88, 32);
      this.cmdSelect.TabIndex = 1;
      this.cmdSelect.Text = "Select a File";
      this.cmdSelect.Click += new System.EventHandler(this.cmdSelect_Click);
      // 
      // frmSetToday
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdSelect);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSetToday";
      this.Text = "Set Today";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSetToday'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSetToday()
      //***
      // Action
      //   - Create instance of 'frmSetToday'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSetToday()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdSelect_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a file open dialog
      //   - Set the current date and time
      //   - Show the dialog
      //   - If OK button is clicked
      //     - Try
      //       - Set the creation time, access time and last write time ot current date and time
      //       - Show message that file is updated
      //     - On Error
      //       - Show error message with FileName
      //   - If not
      //     - Show message that used selected cancel
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      OpenFileDialog dlgFileOpen = new OpenFileDialog();
      DateTime dtmCurrent = DateTime.Now;

      if (dlgFileOpen.ShowDialog() == DialogResult.OK)
      {

        try
        {
          File.SetCreationTime(dlgFileOpen.FileName, dtmCurrent);
          File.SetLastAccessTime(dlgFileOpen.FileName, dtmCurrent);
          File.SetLastWriteTime(dlgFileOpen.FileName, dtmCurrent);
          
          MessageBox.Show(dlgFileOpen.FileName + " date and time updated");
        }
        catch (Exception theException)
        {
          MessageBox.Show("Error updating " + dlgFileOpen.FileName + " " + theException.Message);
        }
        finally
        {
        }

    }
      else
        // dlgFileOpen.ShowDialog() <> DialogResult.OK
      {
        MessageBox.Show("User selected Cancel");
      }
      // dlgFileOpen.ShowDialog() = DialogResult.OK

    }
    // cmdSelect_Click(System.Object, System.EventArgs) Handles cmdSelect.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSetToday
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSetToday()
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSetToday());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSetToday

}
// CopyPaste.Learning