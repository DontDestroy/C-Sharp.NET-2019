//***
// Action
//   - Trigger an exception handling
// Created
//   - CopyPaste � 20240515 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240515 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmShowException: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdToString;
    internal System.Windows.Forms.Button cmdMessage;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmShowException));
      this.cmdToString = new System.Windows.Forms.Button();
      this.cmdMessage = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdToString
      // 
      this.cmdToString.Location = new System.Drawing.Point(62, 144);
      this.cmdToString.Name = "cmdToString";
      this.cmdToString.Size = new System.Drawing.Size(168, 40);
      this.cmdToString.TabIndex = 3;
      this.cmdToString.Text = "Show Exception.ToString";
      this.cmdToString.Click += new System.EventHandler(this.cmdToString_Click);
      // 
      // cmdMessage
      // 
      this.cmdMessage.Location = new System.Drawing.Point(62, 56);
      this.cmdMessage.Name = "cmdMessage";
      this.cmdMessage.Size = new System.Drawing.Size(168, 40);
      this.cmdMessage.TabIndex = 2;
      this.cmdMessage.Text = "Show Exception.Message";
      this.cmdMessage.Click += new System.EventHandler(this.cmdMessage_Click);
      // 
      // frmShowException
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdToString);
      this.Controls.Add(this.cmdMessage);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmShowException";
      this.Text = "Show Exception";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmShowException'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmShowException()
      //***
      // Action
      //   - Create instance of 'frmShowException'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmShowException()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdMessage_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to divide 3 by 0
      //   - Show an error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngFirst;
      int lngRemainder;
      int lngSecond;

      lngFirst = 3;
      lngSecond = 0;

      try
      {
        lngRemainder = lngFirst % lngSecond;
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
    
    }
    // cmdMessage_Click(System.Object, System.EventArgs) Handles cmdMessage.Click

    private void cmdToString_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to divide 3 by 0
      //   - Show the ToString of an error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngFirst;
      int lngRemainder;
      int lngSecond;

      lngFirst = 3;
      lngSecond = 0;

      try
      {
        lngRemainder = lngFirst % lngSecond;
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.ToString());
      }
    
    }
    // cmdToString_Click(System.Object, System.EventArgs) Handles cmdToString.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmShowException
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmShowException()
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmShowException());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmShowException

}
// CopyPaste.Learning