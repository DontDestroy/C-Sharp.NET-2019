﻿//***
// Action
//   - Demo of a BackgroundWorker (not working 100% accurate)
// Created
//   - CopyPaste – 20220823 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220823 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace BackgroundWorker
{

  public partial class wpfBackgroundWorkerNotWorking : Window
  {

    #region "Constructors / Destructors"

    public wpfBackgroundWorkerNotWorking()
    //***
    // Action
    //   - Create an instance of wpfBackgroundWorkerNotWorking
    // Called by
    //   - User action (Starting the form)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfBackgroundWorkerNotWorking()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCancel_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Mention that the cancel button was clicked
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lblResult.Content = "Run Cancelled!";
    }
    // cmdCancel_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCancel.Click

    private void cmdStart_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Loop from 1 till 500
    //     - Loop from 1 till 10.000.000
    //   - Change the lable on the screen with value intValue
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lblResult.Content = "";

      for (int intOuterCounter = 1; intOuterCounter <= 500; intOuterCounter++)
      {

        for (int intInnerCounter = 1; intInnerCounter <= 10000000; intInnerCounter++)
        {
        }
        // intInnerCounter = 10000001

        lblCycles.Content = "Cycles: " + intOuterCounter.ToString();
      }
      // intOuterCounter = 501

      lblResult.Content = "Run Completed!";
    }
    // cmdStart_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdStart.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfBackgroundWorkerNotWorking

}
// BackgroundWorker