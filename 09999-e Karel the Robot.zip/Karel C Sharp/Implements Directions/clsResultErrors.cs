﻿//***
// Action
//   - Create a class cpResultErrors that uses the interface Directions
// Created
//   - CopyPaste – 20251011 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251011 – VVDW
// Proposal (To Do)
//   - It contains errors (on purpose)
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpResultErrors : Directions
	{

		#region "Constructors / Destructors"

		public cpResultErrors()
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Reset the world
		//   - Build the world according to the One Wall Segment specifications
		//   - Make the world visible
		//   - Move beeper to the North
		// Called by
		//   - cpProgram.ResultErrors()
		// Calls
		//   - moveBeeperToTheNorth()
		// Created
		//   - CopyPaste – 20251011 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251011 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - This code has a wrong result (on purpose)
		//***
		{
			World.reset();
			World.readWorld("Worlds\\02.08 One Beeper.kwld");
			World.setVisible(true);
			moveBeeperToTheNorth();
		}
    // cpResultErrors()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void moveBeeperToTheNorth()
    //***
    // Action
    //   - Karel becomes a green robot starting at position (1, 1), looking to the right with no beepers in the bag
    //   - Karel moves two forward
    //   - Karel picks the beeper
    //   - Karel moves one forward
    //   - Karel puts the beeper
    //   - Karel turns left
    //   - Karel moves one forward
    //   - Karel shutsdown
    // Called by
    //   - cpResultErrors()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251011 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251011 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - This code has a wrong result (on purpose)
    //***
    {
      UrRobot karel = new UrRobot(1, 1, Directions.East, 0, Color.green);

      karel.move(); // Moving one to the East (position Street 1, Avenue 2)
      karel.move(); // Moving one to the East (position Street 1, Avenue 3)
      karel.pickBeeper(); // Pick the Beeper at that position
      karel.move(); // Moving one to the East (position Street 1, Avenue 4)
      karel.putBeeper(); // Put the Beeper at that position
      karel.turnLeft(); // Turn to the left (Looking to the North)
      karel.move(); // Moving one to the North (position Street 2, Avenue 4)
      karel.turnOff(); // Robot karel is switched off
    }
    // moveBeeperToTheNorth()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpResultErrors

}
// cpKarelTheRobot