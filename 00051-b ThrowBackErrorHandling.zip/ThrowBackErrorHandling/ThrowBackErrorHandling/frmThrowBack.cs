//***
// Action
//   - Calculate from Arabic numbers to Roman numbers
//   - When there is an error, a catch is executed to show an error message
// Created
//   - CopyPaste � 20240506 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240506 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmThrowBack: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.Label lblDescription;
    internal System.Windows.Forms.Button cmdCalculate;
    internal System.Windows.Forms.TextBox txtInput;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmThrowBack));
      this.lblResult = new System.Windows.Forms.Label();
      this.lblDescription = new System.Windows.Forms.Label();
      this.cmdCalculate = new System.Windows.Forms.Button();
      this.txtInput = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // lblResult
      // 
      this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblResult.Location = new System.Drawing.Point(32, 168);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(200, 40);
      this.lblResult.TabIndex = 7;
      this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblDescription
      // 
      this.lblDescription.Location = new System.Drawing.Point(64, 128);
      this.lblDescription.Name = "lblDescription";
      this.lblDescription.Size = new System.Drawing.Size(128, 23);
      this.lblDescription.TabIndex = 6;
      this.lblDescription.Text = "Roman Numeral Result";
      this.lblDescription.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cmdCalculate
      // 
      this.cmdCalculate.Location = new System.Drawing.Point(64, 80);
      this.cmdCalculate.Name = "cmdCalculate";
      this.cmdCalculate.Size = new System.Drawing.Size(128, 24);
      this.cmdCalculate.TabIndex = 5;
      this.cmdCalculate.Text = "Calculate";
      this.cmdCalculate.Click += new System.EventHandler(this.cmdCalculate_Click);
      // 
      // txtInput
      // 
      this.txtInput.Location = new System.Drawing.Point(64, 40);
      this.txtInput.MaxLength = 4;
      this.txtInput.Name = "txtInput";
      this.txtInput.Size = new System.Drawing.Size(128, 20);
      this.txtInput.TabIndex = 4;
      this.txtInput.Text = "";
      // 
      // frmThrowBack
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(264, 229);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.lblDescription);
      this.Controls.Add(this.cmdCalculate);
      this.Controls.Add(this.txtInput);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmThrowBack";
      this.Text = "Roman Numbers";
      this.Load += new System.EventHandler(this.frmThrowBack_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmThrowBack'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmThrowBack()
      //***
      // Action
      //   - Create instance of 'frmThrowBack'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmThrowBack()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    const string mstrProgramName = "Throwback Caclulator (Roman Numbers)";

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdCalculate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Determine the needed Arabic numbers to recalculate it to Roman numbers
      //   - Determine the lis of Roman numbers
      //   - Get the lower and upper bound
      //   - Get the input of the form
      //   - Try to convert it to a number
      //   - Loop thru the Arabic numbers (from end till start)
      //     - While input is bigger than current Arabic number
      //       - Add the corresponding Roman number to the result
      //       - input is subtracted with the Arabic number
      //   - Put the result on the form
      //   - On several errors a message is shown
      //     - Input is not a numeric number
      //     - There is a format exception
      //     - There is a number that is too big
      //     - All other exceptions
      //   - At the end, the input is cleared and got the focus
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - bool IsNotNumeric(string)
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int[] arrlngArabic = new int[] {1, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000};
      string[] arrstrRoman = new string[] {"I", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M"};
      int lngArabicLower = arrlngArabic.GetLowerBound(0);
      int lngArabicUpper = arrlngArabic.GetUpperBound(0);
      int lngCounter;
      int lngInput;
      string strInput = txtInput.Text;
      string strOutPut = "";

      lblResult.Text = "";

      try
      {
        lngInput = Int32.Parse(strInput);

        for (lngCounter = lngArabicUpper; lngCounter >= lngArabicLower; lngCounter--)
        {

          while (lngInput >= arrlngArabic[lngCounter])
          {
            lngInput -= arrlngArabic[lngCounter];
            strOutPut += arrstrRoman[lngCounter];
          }
          // lngInput < arrlngArabic(lngCounter)

        }
        // lngCounter = lngArabicLower - 1

        lblResult.Text = strInput + " = " + strOutPut;
      }
      catch (System.Exception theException) when (IsNotNumeric(txtInput.Text))
      {
        MessageBox.Show(strInput + " is not a valid number. Please reenter.", mstrProgramName, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        lblResult.Text = "";
      }
      catch (System.FormatException theFormatException)
      {
        MessageBox.Show(strInput + " is not an integer. Please reenter.", mstrProgramName, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        lblResult.Text = "";
      }
      catch (System.OverflowException theOverflowException)
      {
        MessageBox.Show(strInput + " is too large or small. Please enter an integer from 1 to 9999.", mstrProgramName, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        lblResult.Text = "";
      }
      catch (System.Exception theException)
      {
        MessageBox.Show(theException.GetType().ToString(), mstrProgramName, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        lblResult.Text = "";
      }
      finally
      {
        txtInput.Clear();
        txtInput.Focus();
      }
    
    }
    // cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click

    private void frmThrowBack_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the correct title in the form
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Text = mstrProgramName;
    }
    // frmThrowBack_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static bool IsNotNumeric(string strText)
      //***
      // Action
      //   - Checks if a text is numeric
      //   - When there is a letter, it returns true, because it is an error
      // Called by
      //   - cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnLetter = false;

      foreach (char aLetter in strText)
      {

        if (char.IsDigit(aLetter))
        {
        }
        else
        // Not char.IsDigit(aLetter)
        {
          blnLetter = true;
        }
        // char.IsDigit(aLetter)

      }
      // in txtInput.Text

      return blnLetter; // Returns true for an error when there is a letter
    }
    // bool IsNotNumeric(strText)

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmThrowBack
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmThrowBack()
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmThrowBack());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmThrowBack

}
// CopyPaste.Learning