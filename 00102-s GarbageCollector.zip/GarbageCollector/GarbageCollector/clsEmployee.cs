//***
// Action
//   - Implementation of cpEmployee
// Created
//   - CopyPaste � 20230802 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230802 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpEmployee
  {

    #region "Constructors / Destructors"

    public cpEmployee(string strName, string strEmail)
    //***
    // Action
    //   - Constructor of cpEmployee
    //   - Defining a name and emailaddress
    //   - Show a message of the memory allocation
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230802 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230802 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      mstrName = strName;
      mstrEmail = strEmail;
      MessageBox.Show("Allocated memory " + GC.GetTotalMemory(true));
    }
    // cpEmployee(string, string)

    ~cpEmployee()
    //***
    // Action
    //   - Finalizer of cpEmployee
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230802 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230802 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      try
      {
        MessageBox.Show("In Finalize for " + mstrName);
      }
      catch (Exception theException)
      {
      }

    }
    // ~Finalize()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public string mstrEmail;
    public string mstrName;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpEmployee

}
// CopyPaste.Learning