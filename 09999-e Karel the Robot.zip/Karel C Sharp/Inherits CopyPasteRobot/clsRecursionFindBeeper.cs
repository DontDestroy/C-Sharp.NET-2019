﻿//***
// Action
//   - A definition of a RecursionFindBeeper
// Created
//   - CopyPaste – 20251101 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251101 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;
using System.Security.Policy;

namespace cpKarelTheRobot
{

	public class cpRecursionFindBeeper : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpRecursionFindBeeper(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpRecursionFindBeeper starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpRecursionFindBeeper(int, int, Directions.Direction, int) 
    //   - cpProgram.RecursionFindBeeper()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRecursionFindBeeper(int, int, Directions.Direction, int, Color) 

    public cpRecursionFindBeeper(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpRecursionFindBeeper starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpRecursionFindBeeper(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRecursionFindBeeper(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void FindBeeper()
    //***
    // Action
    //   - If next to a beeper
    //     - Turn to the left
    //     - Pick beeper
    //   - If not
    //     - Move one forward
    //     - Restart routine
    //   - Move forward (this is done after the beeper was found in the first street)
    // Called by
    //   - FindBeeper()
    //   - RetrieveTreasure()
    // Calls
    //   - FindBeeper()
    // Created
    //   - CopyPaste – 20251101 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251101 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (nextToABeeper())
      {
        turnLeft();
        pickBeeper();
      }
      else
      // Not nextToABeeper()
      {
        move();
        FindBeeper();
        move();
      }
      // nextToABeeper()
    }
    // FindBeeper()

    public void RetrieveTreasure()
    //***
    // Action
    //   - Find the beeper
    //   - Pick the beeper
    //   - Find the treasure
    //   - Pick the treasure
    //   - Go back to the origin
    // Called by
    //   - cpProgram.Recursion()
    // Calls
    //   - cpCopyPasteRobot.GoToStartPosition()
    //   - FindBeeper()
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FindBeeper();

      while (nextToABeeper())
      {
        pickBeeper();
      }
      // nextToABeeper()

      GoToStartPosition();
    }
    // RetrieveTreasure()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpRecursionFindBeeper

}
// cpKarelTheRobot