//***
// Action
//   - Change the position and size of the form
//   - The next time you start the form, the position and size are the same
// Created
//   - CopyPaste � 20260130 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260130 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmApplicationSettings: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmApplicationSettings));
      // 
      // frmApplicationSettings
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmApplicationSettings";
      this.Closing += new System.ComponentModel.CancelEventHandler(this.frmApplicationSettings_Closing);
      this.Load += new System.EventHandler(this.frmApplicationSettings_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmApplicationSettings'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmApplicationSettings()
      //***
      // Action
      //   - Create instance of 'frmApplicationSettings'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmApplicationSettings()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmApplicationSettings_Closing(System.Object theSender, System.ComponentModel.CancelEventArgs theCancelEventArguments)
      //***
      // Action
      //   - Try to 
      //     - Save four settings of 'frmApplicationSettings' to the configuration file
      //       - Size Width
      //       - Size Height
      //       - Position X
      //       - Position Y
      //   - On possible error
      //     - Show a messagebox with the exception
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - cpApplicationSettingsWriter()
      //   - cpApplicationSettingsWriter.SaveFile()
      //   - cpApplicationSettingsWriter.SaveKeyValue(string, string)
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        cpApplicationSettingsWriter thecpApplicationSettingsWriter = new cpApplicationSettingsWriter();

        thecpApplicationSettingsWriter.SaveKeyValue("frmApplicationSettings.Size.Width", ClientSize.Width.ToString());
        thecpApplicationSettingsWriter.SaveKeyValue("frmApplicationSettings.Size.Height", ClientSize.Height.ToString());
        thecpApplicationSettingsWriter.SaveKeyValue("frmApplicationSettings.X", DesktopLocation.X.ToString());
        thecpApplicationSettingsWriter.SaveKeyValue("frmApplicationSettings.Y", DesktopLocation.Y.ToString());
        thecpApplicationSettingsWriter.SaveFile();
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.ToString());
      }
      finally
      {
      }
    
    }
    // frmApplicationSettings_Closing(System.Object, System.ComponentModel.CancelEventArgs) Handles this.Closing

    private void frmApplicationSettings_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define four variable for the position and size of the form
      //   - Define an AppSettingsReader
      //   - Try to 
      //     - Create a new instance of AppSettingsReader
      //   - On possible error
      //     - Show a messagebox with the exception
      //   - Try to
      //     - Read four settings from the configuration file
      //     - Set the clientsize of the form with the found width and height
      //     - Set the desktoplocation of the form with the found X and Y
      //   - On possible error
      //     - Do nothing
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      System.Int32 lngHeight = 0;
      System.Int32 lngWidth = 0;
      System.Int32 lngX = 0;
      System.Int32 lngY = 0;
      AppSettingsReader theApplicationSettingsReader = null;

      try
      {
        theApplicationSettingsReader = new AppSettingsReader();
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.ToString());
      }
      finally
      {
      }

      try
      {
        lngWidth = (System.Int32)(theApplicationSettingsReader.GetValue("frmApplicationSettings.Size.Width", lngWidth.GetType()));
        lngHeight = (System.Int32)(theApplicationSettingsReader.GetValue("frmApplicationSettings.Size.Height", lngHeight.GetType()));
        lngX = (System.Int32)(theApplicationSettingsReader.GetValue("frmApplicationSettings.X", lngX.GetType()));
        lngY = (System.Int32)(theApplicationSettingsReader.GetValue("frmApplicationSettings.Y", lngY.GetType()));

        ClientSize = new System.Drawing.Size(lngWidth, lngHeight);
        DesktopLocation = new System.Drawing.Point(lngX, lngY);
      }
      catch (Exception theException)
      {
      }
      finally
      {
      }
          
    }
    // frmApplicationSettings_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmApplicationSettings
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmApplicationSettings()
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmApplicationSettings());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmApplicationSettings

}
// CopyPaste.Learning