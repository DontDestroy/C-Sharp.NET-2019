//***
// Action
//   - Implementation of a list of cpSortablePoints
//   - Interface IEnumerable is used
//   - The goal is this
//     - Make it possible to use a foreach in the list of cpSortablePoints
// Created
//   - CopyPaste � 20240314 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240314 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;

namespace CopyPaste.Learning
{

  public class cpSortedPointList : IEnumerable
  {

    #region "Constructors / Destructors"

    public cpSortedPointList() 
      //***
      // Action
      //   - Default constructor
      // Called by
      //   - frmPointCoordinate.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
      //   - frmPointList.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpSortedPointList()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private ArrayList marrPoint = new ArrayList();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void AddRandomPoints(int lngHowMany, int lngMaximum)
      //***
      // Action
      //   - Add a number of point to the list (lngHowMany)
      //   - The maximum coordinate for X and Y is also given (lngMaximum)
      //   - Clear the ArrayList
      //   - Loop from 0 till lngHowMany minus 1
      //     - Add a new cpSortablePoint to the ArrayList
      //   - Sort the ArrayList
      // Called by
      //   - frmPointCoordinate.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
      //   - frmPointList.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
      // Calls
      //   - cpPointEnumerator.New(ArrayList)
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpSortablePoint thecpSortablePoint;
      int lngCounter;
      Random rndGenerator = new System.Random();

      marrPoint.Clear();

      for (lngCounter = 0; lngCounter < lngHowMany; lngCounter++)
      {
        thecpSortablePoint = new cpSortablePoint(rndGenerator.Next(lngMaximum), rndGenerator.Next(lngMaximum));
        marrPoint.Add(thecpSortablePoint);
      }
      // lngCounter = lngHowMany

      marrPoint.Sort();
    }
    // AddRandomPoints(int, int)

    public IEnumerator GetEnumerator()
      //***
      // Action
      //   - An obligatory implementation due to IEnumerable
      //   - Returns a new instance of cpPointEnumerator with a given list
      // Called by
      //   - 
      // Calls
      //   - cpPointEnumerator(ArrayList)
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return new cpPointEnumerator(marrPoint);
    }
    // IEnumerator GetEnumerator()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpSortedPointList

}
// CopyPaste.Learning