﻿//***
// Action
//   - Event handles for the application
// Created
//   - CopyPaste – 20220902 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220902 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace EventHandles
{
  public partial class App : Application
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Application_Startup(System.Object theSender, System.Windows.StartupEventArgs theStartupEventArguments)
    //***
    // Action
    //   - Proves that the event of starting up the application is triggered
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220902 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220902 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      MessageBox.Show("The application is started");
    }
    // Application_Startup(System.Object, System.Windows.StartupEventArgs) Handles Application.Startup

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // App

}
// EventHandles