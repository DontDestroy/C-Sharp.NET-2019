//***
// Action
//   - A pet store, the definition of a cat (base class, but inherits from cpPet)
//   - Working with properties (Get and Set) and methods in several classes, that can be reused
// Created
//   - CopyPaste � 20220316 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20220316 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace CopyPaste.Pet
{

  public class cpCat : cpPet
  {

    #region "Constructors / Destructors"

    public cpCat() : base ("Cat", 4)
      //***
      // Action
      //   - Creating an instance of cpCat with default parameters
      //   - Creating an instance of cpPet with parameters "Cat" and 4
      //   - Food becomes "Tunafish"
      //   - Write a line "cpCat default constructor"
      // Called by
      //   - base(string, int)
      //   - CopyPaste.Pet.Cat.cpManx()
      //   - CopyPaste.Pet.Bird.cpSiamese()
      // Calls
      //   - CopyPaste.Pet.cpPet.Food(String) (Set)
      //   - CopyPaste.Pet.cpPet.New(String, Int32)
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      Food = "Tunafish";
      Console.WriteLine("cpCat default constructor");
    }
    // cpCat()

    public cpCat(string strName) : this()
      //***
      // Action
      //   - Creating an instance of cpCat with default parameters and set the name
      //   - Creating an instance of cpCat with default parameters
      //   - Name becomes strName
      //   - Write a line "cpCat overloaded constructor"
      // Called by
      //   - CopyPaste.Pet.Cat.cpManx(string, string)
      //   - CopyPaste.Pet.Cat.cpSiamese(string, string)
      //   - cpProgram.FillArray()
      // Calls
      //   - this()
      //   - CopyPaste.Pet.clsAnimal.Name(String) (Set)
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      Name = strName;
      Console.WriteLine("cpCat overloaded constructor");
    }
    // cpCat(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"
    
    public override string Play() 
      //***
      // Action
      //   - Write a line to the console with "CopyPaste.Pet.cpAnimal.cpCat.Play"
      //   - Return "(Name) attacks the yarn ball"
      // Called by
      //   - frmPetStore.cmdPlay_Click(System.Object, System.EventArgs) Handles cmdPlay.Click
      // Calls
      //   - Overrides string CopyPaste.Pet.cpAnimal.Play()
      //   - string CopyPaste.Pet.cpPet.Name (Get)
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      Console.WriteLine("CopyPaste.Pet.cpAnimal.cpCat.Play");
      return Name + " attacks the yarn ball";
    }
    // string Play()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCat

}
// CopyPaste.Pet