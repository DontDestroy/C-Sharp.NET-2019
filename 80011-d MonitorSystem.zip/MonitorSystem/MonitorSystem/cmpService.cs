//***
// Action
//   - Example of a Windows Service
//   - Execute a functionality every 5 minutes
//   - The functionality are two other threads
// Created
//   - CopyPaste � 20260902 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260902 � VVDW
// Proposal (To Do)
//   - This does not work
//   - Whatever I do the timer ticks is not triggered
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.ServiceProcess;
using System.Threading;

namespace CopyPaste.Learning
{

  public class cpService : System.ServiceProcess.ServiceBase
	{

    #region Component Designer generated code

    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      // 
      // cpService
      // 
      this.CanPauseAndContinue = true;
      this.CanShutdown = true;
      this.ServiceName = "cpService";
    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpService'
      // Called by
      //   - User action (Closing the service)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpService()
      //***
      // Action
      //   - Create instance of 'cpService'
      // Called by
      //   - Main()
      //   - User action (Starting the service)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }

    private System.Windows.Forms.Timer mtmrAlarm;
    // cpService()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static System.Threading.Timer mthrAlarm;
    private static TimeSpan mtsInterval = new TimeSpan(0, 5, 0);
    // VVDW - 5 minutes interval

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void OnContinue()
      //***
      // Action
      //   - Enable the timer
      //   - Try to
      //     - Write information to the application log
      //     - Make that the information sticks in the file
      // Called by
      //   - User action (Continuing the service)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mthrAlarm.Change(mtsInterval, mtsInterval);

      try
      {
        EventLog theLog = new EventLog("Application", ".", "cpService");
        string strText;

        strText = "Service continued at " + DateTime.Now.ToString("yyyyMMdd hh:mm:ss");
        theLog.Source = "cpService";
        theLog.WriteEntry(strText);
        theLog.Close();
      }
      catch (Exception theException)
      {
      }

    }
    // OnContinue()

    protected override void OnPause()
      //***
      // Action
      //   - Disable the timer
      //   - Try to
      //     - Write information to the application log
      //     - Make that the information sticks in the file
      // Called by
      //   - User action (Pauzing the service)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mthrAlarm.Change(Timeout.Infinite, Timeout.Infinite);

      try
      {
        EventLog theLog = new EventLog("Application", ".", "cpService");
        string strText;

        strText = "Service paused at " + DateTime.Now.ToString("yyyyMMdd hh:mm:ss");
        theLog.Source = "cpService";
        theLog.WriteEntry(strText);
        theLog.Close();
      }
      catch (Exception theException)
      {
      }

    }
    // OnPause()

    protected override void OnShutdown()
      //***
      // Action
      //   - Disable the timer
      //   - Try to
      //     - Write information to the application log
      //     - Make that the information sticks in the file
      // Called by
      //   - User action (Shutdown the service)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mthrAlarm.Change(Timeout.Infinite, Timeout.Infinite);

      try
      {
        EventLog theLog = new EventLog("Application", ".", "cpService");
        string strText;

        strText = "Service shutdown at " + DateTime.Now.ToString("yyyyMMdd hh:mm:ss");
        theLog.Source = "cpService";
        theLog.WriteEntry(strText);
        theLog.Close();
      }
      catch (Exception theException)
      {
      }

    }
    // OnShutDown()

    protected override void OnStart(string[] arrstrArgument)
      //***
      // Action
      //   - Enable the timer
      //   - Add an event handler to the timer
      //   - Start the timer
      //   - Try to
      //     - Write information to the application log
      //     - Make that the information sticks in the file
      // Called by
      //   - User action (Start the service)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mthrAlarm = new Timer(new TimerCallback(mthrAlarm_Tick), null, mtsInterval, mtsInterval);

      try
      {
        EventLog theLog = new EventLog("Application", ".", "cpService");
        string strText;

        strText = "Service started at " + DateTime.Now.ToString("yyyyMMdd hh:mm:ss");
        theLog.Source = "cpService";
        theLog.WriteEntry(strText);
        theLog.Close();
      }
      catch (Exception theException)
      {
      }

    }
    // OnStart(string[])

    protected override void OnStop()
      //***
      // Action
      //   - Disable the timer
      //   - Try to
      //     - Write information to the application log
      //     - Make that the information sticks in the file
      // Called by
      //   - User action (Stop the service)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mthrAlarm.Change(Timeout.Infinite, Timeout.Infinite);

      try
      {
        EventLog theLog = new EventLog("Application", ".", "cpService");
        string strText;

        strText = "Service paused at " + DateTime.Now.ToString("yyyyMMdd hh:mm:ss");
        theLog.Source = "cpService";
        theLog.WriteEntry(strText);
        theLog.Close();
      }
      catch (Exception theException)
      {
      }

    }
    // OnStop()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private static void mthrAlarm_Tick(System.Object theState)
      //***
      // Action
      //   - When timer has reached the trigger point
      //   - Count the files in the T:\ root
      //   - Write that information to the application log
      //   - Make that the information sticks in the file
      // Called by
      //   - System action (Trigger of timer is activated)
      // Calls
      //   - LogEventEntries()
      //   - LogExecutableFiles()
      // Created
      //   - CopyPaste � 20260902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - This does not work, the Tick is never been triggered
      //***
    {
      Thread thrExecutableCheck;
      Thread thrLogEntries;

      thrExecutableCheck = new Thread(new ThreadStart(LogExecutableFiles));
      thrLogEntries = new Thread(new ThreadStart(LogEventEntries));
      thrExecutableCheck.Start();
      thrLogEntries.Start();
    }
    // mthrAlarm_Tick(System.Object)

    #endregion

    #region "Sub / Function"

    public static long CountTree(string strDir, string strExtension)
      //***
      // Action
      //   - Count the executable files on a harddisk
      //   - Recursive routine
      // Called by
      //   - long CountTree(string, string)
      //   - LogExecutableFiles()
      // Calls
      //   - long CountTree(string, string)
      // Created
      //   - CopyPaste � 20260902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DirectoryInfo dirInfo = new DirectoryInfo(strDir);

      DirectoryInfo[] arrDirectories = dirInfo.GetDirectories("*.*");
      FileInfo[] arrFiles = dirInfo.GetFiles(strExtension);
      long lngCount = 0;

      foreach (DirectoryInfo dirInfoName in arrDirectories)
      {

        try
        {
          lngCount = lngCount + CountTree(dirInfoName.FullName, strExtension);
        }
        catch
        {
        }

      }
      // in arrDirectories

      lngCount = arrFiles.Length + lngCount;
      return lngCount;
    }
    // long CountTree(string, string)

    public static void LogEventEntries()
      //***
      // Action
      //   - Count the event entries
      // Called by
      //   - mthrAlarm_Tick(System.Object)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      EventLog theLog = new EventLog("Application", ".", "cpService");

      theLog.Source = "cpService";
      theLog.WriteEntry("Event log entries " + DateTime.Now.ToString("yyyyMMdd hh:mm:ss") + " is " + theLog.Entries.Count);
      theLog.Close();
    }
    // LogEventEntries()

    public static void LogExecutableFiles()
      //***
      // Action
      //   - Count the executable files on a harddisk
      // Called by
      //   - mthrAlarm_Tick(System.Object)
      // Calls
      //   - long CountTree(string)
      // Created
      //   - CopyPaste � 20260902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      EventLog theLog = new EventLog("Application", ".", "cpService");

      theLog.Source = "cpService";
      theLog.WriteEntry("Executable files at " + DateTime.Now.ToString("yyyyMMdd hh:mm:ss") + " is " + CountTree("T:\\", "*.exe"));
      theLog.Close();
    }
    // LogEventEntries()

    [MTAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Starting routine of the service
      //   - Define an array of ServicesToRun
      //   - Add a new cpService to it
      //   - Run them
      // Called by
      //   - User action (Starting the service)
      // Calls
      //   - cpService()
      // Created
      //   - CopyPaste � 20260902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      System.ServiceProcess.ServiceBase[] ServicesToRun;
	
      ServicesToRun = new System.ServiceProcess.ServiceBase[] { new cpService() };
      System.ServiceProcess.ServiceBase.Run(ServicesToRun);
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpService

}
// CopyPaste.Learning