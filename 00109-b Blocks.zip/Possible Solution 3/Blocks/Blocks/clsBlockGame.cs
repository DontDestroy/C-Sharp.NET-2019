//***
// Action
//   - A block game
//   - Working with properties (Get and Set) and methods in several classes, that can be used in another game
//   - Possible Solution 3
// Created
//   - CopyPaste � 20240214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240214 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning.Games
{

  public class cpBlockGame
  {

    #region "Constructors / Destructors"

    public cpBlockGame(Control ctlScore, Control ctlLives)
      //***
      // Action
      //   - Creating an instance of cpBlockGame with some default values and some values to set up
      //   - Set a score field
      //   - Set a lives field
      // Called by
      //   - 
      // Calls
      //   - LiveField(Control) (Set)
      //   - Lives(int) (Set)
      //   - NumberOfBlocks(int) (Set)
      //   - Score(int) (Set)
      //   - ScoreField(Control) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Lives = 3;
      NumberOfBlocks = 1;
      Score = 0;
      ScoreField = ctlScore;
      LiveField = ctlLives;
    }
    // cpBlockGame(Control, Control)

    public cpBlockGame(int lngLives, int lngScore, int lngNumberOfBlocks, Control ctlScore, Control ctlLives)
      //***
      // Action
      //   - Creating an instance of cpBlockGame with values that can be setup
      // Called by
      //   - frmBlock.frmBlock_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmMoveTest.frmBlock_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - Control LiveField (Get)
      //   - Control ScoreField (Get)
      //   - LiveField(Control) (Set)
      //   - Lives(int) (Set)
      //   - NumberOfBlocks(int) (Set)
      //   - Score(int) (Set)
      //   - ScoreField(Control) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Lives = lngLives;
      Score = lngScore;
      NumberOfBlocks = lngNumberOfBlocks;
      ScoreField = ctlScore;
      LiveField = ctlLives;
    }
    // cpBlock(int, int, int, Control, Control)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private bool mblnLostBall;
    private Control mctlLiveField;
    private Control mctlScoreField;
    private int mlngNumberOfBlocks;
    private int mlngLives;
    private int mlngScore;

    #endregion

    #region "Properties"

    public bool GameFinished
    {
      
      get
        //***
        // Action Get
        //   - Check if the game is finished (True or False)
        //   - If NumberOfBlocks equals zero
        //     - Return True
        //   - If Not
        //     - If LostBall
        //       - If Lives lower than 1 (equals zero)
        //         - Return True
        //       - If Not
        //         - Return False
        //     - If Not
        //       - Do Nothing
        // Called by
        //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - bool LostBall (Get)
        //   - int Lives (Get)
        //   - int NumberOfBlocks (Get)
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        bool blnResult = false;

        if (NumberOfBlocks == 0)
        {
          blnResult = true;
        }
        else
          // NumberOfBlocks <> 0
        {
          
          if (LostBall)
          {
            
            if (Lives < 1)
            {
              // MessageBox.Show("You have lost the game.", "OH NO!");
              blnResult = true;
            }
            else
              // Lives >= 1
            {
              // MessageBox.Show("You missed!", "OH NO");
              blnResult = false;
            }
            // Lives < 1

          }
          else
            // Not LostBall
          {
          }
          // LostBall
       
        }
        // NumberOfBlocks = 0

        return blnResult;
      }
      // bool GameFinished (Get)

    }
    // bool GameFinished 

    public int Lives
    {

      get
        //***
        // Action Get
        //   - Return the number of lives you still have in the game (mlngLives)
        // Called by
        //   - bool GameFinished (Get)
        //   - cpBlockGame(int, int, int, Control, Control)
        //   - frmBlock.UpdateLives()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngLives;
      }
      // int Lives (Get)

      set
        //***
        // Action Set
        //   - Set the number of lives you still have in the game (mlngLives becomes value)
        // Called by
        //   - bool GameFinished (Get)
        //   - cpBlockGame(Control, Control)
        //   - cpBlockGame(int, int, int, Control, Control)
        //   - frmBlock.UpdateLives()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngLives = value;
      }
      // Lives(int) (Set)

    }
    // int Lives

    public Control LiveField
    {

      get
        //***
        // Action Get
        //   - Return the control that shows the lives you still have in the game (mctlLiveField)
        // Called by
        //   - cpBlockGame(int, int, int, Control, Control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mctlLiveField;
      }
      // Control LiveField (Get)

      set
        //***
        // Action Set
        //   - Set the control that shows the lives you still have in the game (mctlLiveField becomes value)
        // Called by
        //   - cpBlockGame(Control, Control)
        //   - cpBlockGame(int, int, int, Control, Control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mctlLiveField = value;
      }
      // LiveField(Control) (Set)

    }
    // Control LiveField

    public bool LostBall
    {

      get
        //***
        // Action Get
        //   - Check if you have lost the ball (mblnLostBall)
        // Called by
        //   - bool GameFinished (Get)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mblnLostBall;
      }
      // bool LostBall (Get)

      set
        //***
        // Action Set
        //   - Set the boolean if you have lost the ball or not (mblnLostBall becomes value)
        // Called by 
        //   - 
        // Calls
        //   - UpdateLives()
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mblnLostBall = value;

        if (value) 
        {
          UpdateLives();
        }
        else
          // Not value
        {
        }
        // value


      }
      // LostBall(bool) (Set)

    }
    // bool LostBall

    public int NumberOfBlocks
    {

      get
        //***
        // Action Get
        //   - Return the number of blocks left in the game (mlngNumberOfBlocks)
        // Called by
        //   - cpCollision.CheckHit(cpMove, cpMove, bool)
        //   - bool GameFinished (Get)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngNumberOfBlocks;
      }
      // int NumberOfBlocks (Get)

      set
        //***
        // Action Set
        //   - Set the number of blocks left in the game (mlngNumberOfBlocks becomes value)
        // Called by
        //   - cpBlockGame(Control, Control)
        //   - cpBlockGame(int, int, int, Control, Control)
        //   - cpCollision.CheckHit(cpMove, cpMove, bool)
        //   - frmBlock.CheckCollision()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngNumberOfBlocks = value;
      }
      // NumberOfBlocks(int) (Set)

    }
    // int NumberOfBlocks

    public int Score
    {

      get
        //***
        // Action Get
        //   - Return the score of the game (mlngScore)
        // Called by
        //   - cpBlockGame(int, int, int, Control, Control)
        //   - UpdateScore()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngScore;
      }
      // int Score (Get)

      set
        //***
        // Action Set
        //   - Set the score of the game (mlngScore becomes value)
        // Called by
        //   - cpBlockGame(Control, Control)
        //   - cpBlockGame(int, int, int, Control, Control)
        //   - UpdateScore()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngScore = value;
      }
      // Score(int) (Set)

    }
    // int Score

    
    public Control ScoreField
    {

      get
        //***
        // Action Get
        //   - Return the control that shows the score you have in the game (mctlScoreField)
        // Called by
        //   - cpBlockGame(int, int, int, Control, Control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mctlScoreField;
      }
      // Control LiveField (Get)

      set
        //***
        // Action Set
        //   - Set the control that shows the score you have in the game (mctlScoreField becomes value)
        // Called by
        //   - cpBlockGame(Control, Control)
        //   - cpBlockGame(int, int, int, Control, Control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mctlScoreField = value;
      }
      // LiveField(Control) (Set)

    }
    // Control LiveField

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    public void UpdateLives()
      //***
      // Action
      //   - Subtract 1 from Lives
      //   - If Lives smaller than 1
      //     - Show messagebox that you lost the game
      //   - If Not
      //     - Show messagebox that you have lost a live
      //   - Show Number of Lives
      // Called by
      //   - LostBall(bool) (Set)
      // Calls
      //   - Control LiveField (Get)
      //   - int Lives (Get)
      //   - Lives(int) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Lives -= 1;
      
      if (Lives < 1)
      {
        MessageBox.Show("OH NO! You have lost the game", "GAME OVER");
      }
      else
        // Lives >= 1
      {
        MessageBox.Show("OH NO! You have lost a live", "BE CAREFULL");
      }
      // Lives < 1

      LiveField.Text = "Lives: " + Lives;
    }
    // UpdateLives()
    
    public void UpdateScore()
      //***
      // Action
      //   - Add 10 to Score
      //   - Show Score
      // Called by
      //   - cpCollission.CheckHit(cpMove, cpMove, bool)
      // Calls
      //   - Control ScoreField (Get)
      //   - int Score (Get)
      //   - Score(int) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Score += 10;
      ScoreField.Text = "Score: " + Score;
    }
    // UpdateScore()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBlockGame

}
// CopyPaste.Learning.Games