﻿//***
// Action
//   - Definition of a Flight
// Created
//   - CopyPaste – 20230714 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230714 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CopyPaste.BusinessObjects
{

  [SerializableAttribute]
  public class Flight
  {

    #region "Constructors / Destructors"

    public Flight()
    //***
    // Action
    //   - Constructor of Flight
    //   - Creates an empty list of Booking
    //   - Creates an empty list of Passenger
    //   - Prefill Departure and Destination with "(not set)"
    //   - Prefill the Date and the Price
    // Called by
    //   - 
    // Calls
    //   - Booking(ICollection<Booking>) (Set)
    //   - Date(DateTime) (Set)
    //   - Departure(string) (Set)
    //   - Destination(string) (Set)
    //   - Passenger(ICollection<Passenger>) (Set)
    //   - Price(decimal?) (Set)
    // Created
    //   - CopyPaste – 20230714 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - The default values can also be set in the method OnModelCreating()
    //***
    {
      // This is not really necessary, but it is clear if you do this
      this.Booking = new List<Booking>();
      // This is not really necessary, here it is put in comments
      // this.Passenger = new List<Passenger>();
      this.Departure = "(not set)";
      this.Destination = "(not set)";
      this.Date = DateTime.Now;
      this.Price = 123.45m;
    }
    // Flight()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    // A relation towards entity class AircraftType
    // By default the name of the foreign Key will be AircraftTypeTypeId (Type is twice in it)
    // A relation towards entity class AircraftType (the one part)
    [ForeignKey("AircraftTypeId")]
    public virtual AircraftType AircraftType { get; set; }
    
    // Remove the questionmark to force that there must be an AircraftType assigned
    public byte? AircraftTypeId { get; set; }

    // A relation towards entity class Airline (the one part)
    public virtual Airline Airline { get; set; }
    public string AirlineCode { get; set; }

    // A relation towards entity class Booking (the many part)
    public ICollection<Booking> Booking { get; set; }

    // A relation towards entity class Pilot (the one part)
    public Pilot CoPilot { get; set; }
    public int? CoPilotId { get; set; }

    // Name is forced to another name than the property
    // Order of the fields is also changed
    [ColumnAttribute("FlightDate", Order = 1)]
    public DateTime Date { get; set; }

    [StringLengthAttribute(50), MinLengthAttribute(3)]
    public string Departure { get; set; }

    [StringLengthAttribute(50), MinLengthAttribute(3)]
    public string Destination { get; set; }

    // Primary Key is not with the rules and conventions, see OnModelCreating for solution
    // This property must be the primary key, but it has no ID or <<class>>ID in the property
    // Entity Framework Core will think there is no Primary key
    // It must be forced in the OnModelCreating() method
    // The data annotations can be removed in newer versions of Entity Framework Core
    [KeyAttribute]
    [DatabaseGeneratedAttribute(DatabaseGeneratedOption.None)]
    public int FlightNo { get; set; }

    public short FreeSeats { get; set; }
    public string Memo { get; set; }
    public bool? NonSmokingFlight { get; set; }

    // A relation towards entity class Pilot (the one part)
    public Pilot Pilot { get; set; }
    public int PilotId { get; set; }

    public decimal? Price { get; set; }
    public short Seats { get; set; }

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
    //***
    // Action
    //   - Returns some information about the flight
    // Called by
    //   - 
    // Calls
    //   - DateTime Date (Get)
    //   - int FlightNo (Get)
    //   - short? FreeSeats (Get)
    //   - string Departure (Get)
    //   - string Destination (Get)
    // Created
    //   - CopyPaste – 20230714 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return String.Format($"Flight #{FlightNo}: from {Departure} to {Destination} on {Date:dd.MM.yy HH:mm}: {FreeSeats} free Seats.");
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string ToShortString()
    //***
    // Action
    //   - Returns some information about the flight
    // Called by
    //   - 
    // Calls
    //   - DateTime Date (Get)
    //   - int FlightNo (Get)
    //   - short? FreeSeats (Get)
    //   - string Departure (Get)
    //   - string Destination (Get)
    // Created
    //   - CopyPaste – 20230714 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return String.Format($"Flight #{FlightNo}: {Departure}->{Destination} {Date:dd.MM.yy HH:mm}: {FreeSeats} free Seats.");
    }
    // ToShortString()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Flight

}
// CopyPaste.BusinessObjects 