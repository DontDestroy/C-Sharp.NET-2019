﻿//***
// Action
//   - Having DataCommands and DataReaders towards a database
// Created
//   - CopyPaste – 20210701 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210701 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Data;
using System.Windows.Forms;

namespace DataCommandsWizard
{

  public partial class frmDataCommandsWizard : Form
  {

    #region "Constructors / Destructors"

    public frmDataCommandsWizard()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Setting command with 2 parameters for Select Order
    //   - Set properties for mcmmSelectCustomer
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //  - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmDataCommandsWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFillLists_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Clear Dataset
    //   - Fill TableAdapter Employee
    //   - Fill TableAdapter Customer
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      dsData.Clear();
      tbaEmployee.Fill(dsData.EmployeeList);
      tbaCustomer.Fill(dsData.CustomerList);
    }
    // cmdFillLists_Click(System.Object, System.EventArgs)

    private void cmdGetOrders_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Clear dsData.OrderTotals
    //   - Define 2 parameters
    //   - Fill TableAdpater Order with the 2 parameters
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      DataRowView drvCustomer;
      DataRowView drvEmployee;
      int intIdEmployee;
      string strIdCustomer;

      dsData.OrderTotals.Clear();
      drvCustomer = (System.Data.DataRowView)this.lstClient.SelectedItem;
      strIdCustomer = (String)drvCustomer["strIdCustomer"];
      drvEmployee = (System.Data.DataRowView)this.lstEmployee.SelectedItem;
      intIdEmployee = (int)drvEmployee["intIdEmployee"];
      tbaOrder.Fill(dsData.OrderTotals, strIdCustomer, intIdEmployee);
    }
    // cmdGetOrders_Click(System.Object, System.EventArgs)

    private void cmdOrderCount_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //  - Define 2 parameters
    //  - Execute CountOrders (lngCounter)
    //  - Show message
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      dsDataTableAdapters.tbaOrderCount tbaCountOrders;
      DataRowView drvCustomer;
      DataRowView drvEmployee;
      int intIdEmployee;
      int lngCounter;
      string strIdCustomer;
      string strMessage;

      tbaCountOrders = new dsDataTableAdapters.tbaOrderCount();
      dsData.OrderTotals.Clear();
      drvCustomer = (System.Data.DataRowView)this.lstClient.SelectedItem;
      strIdCustomer = (String)drvCustomer["strIdCustomer"];
      drvEmployee = (System.Data.DataRowView)this.lstEmployee.SelectedItem;
      intIdEmployee = (int)drvEmployee["intIdEmployee"];
      lngCounter = (int)tbaCountOrders.CountOrders(intIdEmployee, strIdCustomer);
      strMessage = "There are " + lngCounter.ToString() + " Orders for this Employee/Customer combination.";
      MessageBox.Show(strMessage);
    }
    // cmdOrderCount_Click(System.Object, System.EventArgs)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataCommandsWizard

}
// DataCommandsWizard