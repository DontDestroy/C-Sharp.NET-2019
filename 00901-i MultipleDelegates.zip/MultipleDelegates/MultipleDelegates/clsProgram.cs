﻿//***
// Action
//   - You can assign multiple delegates to an event
// Created
//   - CopyPaste – 20250715 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250715 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static NotifyInfo[] arrNotifyInfo = new NotifyInfo[3];

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private delegate void NotifyInfo();

    #endregion

    #region "Sub / Function"

    private static void EmailNotify()
      //***
      // Action
      //   - Show how to email Vincent
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250715 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250715 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Email Vincent at vincent@copypaste.be");
    }
    // EmailNotify()

    public static void Main()
      //***
      // Action
      //   - Set 3 events into an array
      //   - Add array to a delegate
      //   - Run the events
      //   - Remove the first event
      //   - Run the events
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - EmailNotify() (thru delegate)
      //   - NotifyInfo()
      //   - PhoneNotify() (thru delegate)
      //   - SMSNotify() (thru delegate)
      // Created
      //   - CopyPaste – 20250715 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250715 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      arrNotifyInfo[0] = new NotifyInfo(PhoneNotify);
      arrNotifyInfo[1] = new NotifyInfo(EmailNotify);
      arrNotifyInfo[2] = new NotifyInfo(SMSNotify);

      NotifyInfo notifyAll;

      notifyAll = (NotifyInfo)(NotifyInfo.Combine(arrNotifyInfo));
      notifyAll();

      Console.WriteLine();

      notifyAll = (NotifyInfo)(NotifyInfo.Remove(notifyAll, arrNotifyInfo[0]));
      notifyAll();
      Console.ReadLine();
    }
		// Main()

    private static void PhoneNotify()
      //***
      // Action
      //   - Show how to phone Vincent
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250715 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250715 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Call Vincent at +32 475 97 63 80");
    }
    // PhoneNotify()

    private static void SMSNotify()
      //***
      // Action
      //   - Show how to phone Vincent
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250715 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250715 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("SMS Vincent at +32 475 97 63 80");
    }
    // SMSNotify()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning