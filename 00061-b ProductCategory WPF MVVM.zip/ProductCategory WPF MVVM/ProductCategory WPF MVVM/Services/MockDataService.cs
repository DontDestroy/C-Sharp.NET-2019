﻿//***
// Action
//   - Create a service that handles mocked data
//   - We fake that the data comes from a database, by creating the needed entities and lists
// Created
//   - CopyPaste – 20220907 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220907 – VVDW
// Proposal (To Do)
//   -
//***

using ProductCategory_WPF_MVVM.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProductCategory_WPF_MVVM.Services
{

  public class MockDataService : IDataService
  {

    #region "Constructors / Destructors"

    public MockDataService()
    //***
    // Action
    //   - Create an instanc of "MockDataService"
    //   - Fill Product Category list with actual data
    //   - Fill Product list with actual data
    // Called by
    //   - StartupViewModel()
    // Calls
    //   - FillProductCategory();
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      FillProductCategory();
      FillProduct();
    }
    // MockDataService()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private IList<Product> _lstProducts;
    private IList<ProductCategory> _lstProductCategories;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public IList<ProductCategory> AllProductCategories()
    //***
    // Action
    //   - Return all the product categories
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      return _lstProductCategories;
    }
    // IList<ProductCategory> AllProductCategories()

    public IList<Product> AllProducts()
    //***
    // Action
    //   - Return all the products
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      return _lstProducts;
    }
    // IList<Product> AllProducts()

    private void FillProduct()
    //***
    // Action
    //   - Fill Product list with actual data
    // Called by
    //   - MockDataService()
    // Calls
    //   - Product(int, string, DateTime, string, decimal, DateTime?, ProductCategory?)
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Product firstProduct = new Product(1, "Extending Bootstrap with CSS, JavaScript and jQuery", new DateTime(2015, 06, 11, 00, 0, 0), "http://bit.ly/1SNzc0i", 23, null, _lstProductCategories[0]);
      Product secondProduct = new Product(2, "Build your own Bootstrap Business Application Template in MVC", new DateTime(2015, 01, 29, 00, 0, 0), "http://bit.ly/1SNzc0i", 21, null, _lstProductCategories[0]);
      Product thirdProduct = new Product(3, "Building Mobile Web Sites Using Web Forms, Bootstrap, and HTML5", new DateTime(2014, 08, 28, 00, 0, 0), "http://bit.ly/1J2dcrj", 19, null, _lstProductCategories[0]);
      Product fourthProduct = new Product(4, "How to Start and Run A Consulting Business", new DateTime(2013, 09, 12, 00, 0, 0), "http://bit.ly/1L8kOwd", 9.99M, null, null);
      Product fifthProduct = new Product(5, "The Many Approaches to XML Processing in .NET Applications", new DateTime(2013, 07, 22, 00, 0, 0), "http://bit.ly/1DBfUqd", 9, new DateTime(2019, 03, 20, 00, 0, 0), _lstProductCategories[0]);
      Product sixthProduct = new Product(6, "WPF for the Business Programmer", new DateTime(2009, 06, 12, 00, 0, 0), "http://bit.ly/1UF858z", 29, null, _lstProductCategories[0]);
      Product seventhProduct = new Product(7, "WPF for the Visual Basic Programmer - Part 1", new DateTime(2013, 12, 16, 00, 0, 0), "http://bit.ly/1uFxS7C", 29, null, _lstProductCategories[0]);
      Product eighthProduct = new Product(8, "WPF for the Visual Basic Programmer - Part 2", new DateTime(2014, 02, 18, 00, 0, 0), "http://bit.ly/1MjQ9NG", 29, null, _lstProductCategories[0]);
      Product ninethProduct = new Product(10, "Practical Team Management for Software Engineers", new DateTime(2017, 05, 19, 00, 0, 0), "http://bit.ly/2qcWO5m", 15, null, _lstProductCategories[1]);
      Product tenthProduct = new Product(11, "Leadership and Communication Skills for Software Engineers", new DateTime(2016, 05, 13, 00, 0, 0), "http://bit.ly/2aq2i4F", 15, null, _lstProductCategories[1]);
      Product eleventhProduct = new Product(12, "Best Practices for Project Estimation	", new DateTime(2014, 12, 08, 00, 0, 0), "http://bit.ly/1ulLVJK", 15, null, _lstProductCategories[1]);
      Product twelvethProduct = new Product(23, "Using PowerShell", new DateTime(2019, 05, 28, 12, 40, 3), "www.fairwaytech.com", 100, new DateTime(2019, 08, 28, 12, 40, 3), _lstProductCategories[2]);

      _lstProducts = new List<Product>();

      _lstProducts.Add(firstProduct);
      _lstProducts.Add(secondProduct);
      _lstProducts.Add(thirdProduct);
      _lstProducts.Add(fourthProduct);
      _lstProducts.Add(fifthProduct);
      _lstProducts.Add(sixthProduct);
      _lstProducts.Add(seventhProduct);
      _lstProducts.Add(eighthProduct);
      _lstProducts.Add(ninethProduct);
      _lstProducts.Add(tenthProduct);
      _lstProducts.Add(eleventhProduct);
      _lstProducts.Add(twelvethProduct);
    }
    // FillProductCategory()

    private void FillProductCategory()
    //***
    // Action
    //   - Fill Product Category list with actual data
    // Called by
    //   - MockDataService()
    // Calls
    //   - ProductCategory(int, string)
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      ProductCategory firstProductCategory = new ProductCategory(1, "Development");
      ProductCategory secondProductCategory = new ProductCategory(2, "Soft Skills");
      ProductCategory thirdProductCategory = new ProductCategory(4, "DevOps");

      _lstProductCategories = new List<ProductCategory>();

      _lstProductCategories.Add(firstProductCategory);
      _lstProductCategories.Add(secondProductCategory);
      _lstProductCategories.Add(thirdProductCategory);
    }
    // FillProductCategory()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // MockDataService

}
// ProductCategory_WPF_MVVM.Services