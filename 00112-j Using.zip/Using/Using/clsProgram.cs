//***
// Action
//   - Testroutine for cpCopyMachine, cpEmployee, cpHandWorker, cpOfficeWorker, cpManager and cpiCost
//   - Namespaces are defined to have a logical structure
// Created
//   - CopyPaste � 20240410 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240410 � VVDW
// Proposal (To Do)
//   - Not all getters and setters are tested, but the usual stuff is
//***

using Company;
using Company.Material;
using Company.Personel;
using System;

namespace CopyPaste.Learning.Employee
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Instantiation of a cpEmployee (not possible)
      //   - Instantiation of a cpCopyMachine
      //   - Instantiation of a cpHandWorker
      //   - Instantiation of a cpOfficeWorker
      //   - Instantiation of a cpManager
      //   - Add them all in an array
      //   - Loop the array
      //     - Show information of the item
      //     - Show information of the cost and if it is human
      //     - Add cost to the total
      //   - Show total
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - bool cpiCost.Human (Get)
      //   - cpCopyMachine()
      //   - cpCopyMachine.NumberOfPages(int) (Set)
      //   - cpCopyMachine.PageCost(decimal) (Set)
      //   - cpEmployee(string)
      //   - cpHandWorker(string)
      //   - cpManager(string)
      //   - cpOfficeWorker(string)
      //   - decimal cpiCost.Amount (Get)
      //   - string cpCopyMachine.ToString()
      // Created
      //   - CopyPaste � 20240410 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240410 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      // cpEmployee thecpEmployee = new cpEmployee("Alfons");
      cpCopyMachine thecpCopyMachine = new cpCopyMachine();
      cpHandWorker thecpHandWorker = new cpHandWorker("Xavier");
      cpManager thecpManager = new cpManager("Vincent");
      cpOfficeWorker thecpOfficeWorker = new cpOfficeWorker("Hilde");

      thecpCopyMachine.NumberOfPages = 54000;
      thecpCopyMachine.PageCost = 0.025M;

      cpiCost[] arrCost = new cpiCost[] {thecpHandWorker, thecpOfficeWorker, thecpManager, thecpCopyMachine}; 
      decimal decTotalCost = 0;

      foreach (cpiCost thecpCost in arrCost)
      {
        Console.WriteLine(thecpCost);
        Console.Write(thecpCost.Human);
        Console.Write(" - ");
        Console.WriteLine(thecpCost.Amount);
        decTotalCost += thecpCost.Amount;
      }
      // In arrCost

      Console.WriteLine();
      Console.WriteLine("Total: {0}", decTotalCost);
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning.Employee