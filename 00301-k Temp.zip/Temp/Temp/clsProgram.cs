//***
// Action
//   - Get some properties of the temp directory
// Created
//   - CopyPaste � 20240722 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240722 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Get a target directory
      //   - If the directory exists
      //     - Show creation time, last access time, last write time
      //   - If not
      //     - Show error message
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240722 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strTargetDirectory = "C:\\Windows\\Temp";

      if (Directory.Exists(strTargetDirectory))
      {
        Console.WriteLine("Creation time: {0}", Directory.GetCreationTime(strTargetDirectory));
        Console.WriteLine("Last access time: {0}", Directory.GetLastAccessTime(strTargetDirectory));
        Console.WriteLine("Last write time: {0}", Directory.GetLastWriteTime(strTargetDirectory));
      }
      else
        // Not Directory.Exists(strTargetDirectory)
      {
        Console.WriteLine("{0} does not exist", strTargetDirectory);
      }
      // Directory.Exists(strTargetDirectory)

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning