//***
// Action
//   - Beep (not working on some machine)
// Created
//   - CopyPaste � 20211018 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20211018 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace BeepMeUpScotty
{

  class cpBeep
	{

    static void Main()
    //***
    // Action
    //   - Loop 'lngCounter'
    //   - Beep a sound
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - Console.Beep()
    // Created
    //   - CopyPaste � 20211018 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20211018 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      long lngCounter;

      for (lngCounter = 1; lngCounter <= 5000000; lngCounter++)
      {
      }
      // lngCounter = 5000001

      Console.Beep();
    }
    // Main()

  }
  // cpBeep

}
// BeepMeUpScotty
