//***
// Action
//   - Create, Modify and Delete Tables
// Created
//   - CopyPaste � 20260114 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260114 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTableTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.IContainer components;
    internal System.Windows.Forms.Button cmdDeleteTable;
    internal System.Windows.Forms.Label lblDeleteTable;
    internal System.Windows.Forms.Label lblDeleteSQLStatement;
    internal System.Windows.Forms.Button cmdModifyTable;
    internal System.Windows.Forms.Button cmdCreateTable;
    internal System.Windows.Forms.Label lblCreateTable;
    internal System.Windows.Forms.Label lblCreateSQLStatement;
    internal System.Windows.Forms.Label lblModifyTable;
    internal System.Windows.Forms.Label lblModifySQLStatment;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTableTryout));
      this.cmdDeleteTable = new System.Windows.Forms.Button();
      this.lblDeleteTable = new System.Windows.Forms.Label();
      this.lblDeleteSQLStatement = new System.Windows.Forms.Label();
      this.cmdModifyTable = new System.Windows.Forms.Button();
      this.cmdCreateTable = new System.Windows.Forms.Button();
      this.lblCreateTable = new System.Windows.Forms.Label();
      this.lblCreateSQLStatement = new System.Windows.Forms.Label();
      this.lblModifyTable = new System.Windows.Forms.Label();
      this.lblModifySQLStatment = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdDeleteTable
      // 
      this.cmdDeleteTable.Location = new System.Drawing.Point(400, 360);
      this.cmdDeleteTable.Name = "cmdDeleteTable";
      this.cmdDeleteTable.Size = new System.Drawing.Size(80, 32);
      this.cmdDeleteTable.TabIndex = 17;
      this.cmdDeleteTable.Text = "Delete Table";
      this.cmdDeleteTable.Click += new System.EventHandler(this.cmdDeleteTable_Click);
      // 
      // lblDeleteTable
      // 
      this.lblDeleteTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblDeleteTable.Location = new System.Drawing.Point(16, 344);
      this.lblDeleteTable.Name = "lblDeleteTable";
      this.lblDeleteTable.Size = new System.Drawing.Size(368, 56);
      this.lblDeleteTable.TabIndex = 16;
      // 
      // lblDeleteSQLStatement
      // 
      this.lblDeleteSQLStatement.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblDeleteSQLStatement.Location = new System.Drawing.Point(16, 312);
      this.lblDeleteSQLStatement.Name = "lblDeleteSQLStatement";
      this.lblDeleteSQLStatement.Size = new System.Drawing.Size(216, 16);
      this.lblDeleteSQLStatement.TabIndex = 15;
      this.lblDeleteSQLStatement.Text = "SQL Statement To Delete a Table";
      // 
      // cmdModifyTable
      // 
      this.cmdModifyTable.Location = new System.Drawing.Point(400, 240);
      this.cmdModifyTable.Name = "cmdModifyTable";
      this.cmdModifyTable.Size = new System.Drawing.Size(80, 32);
      this.cmdModifyTable.TabIndex = 14;
      this.cmdModifyTable.Text = "Modify Table";
      this.cmdModifyTable.Click += new System.EventHandler(this.cmdModifyTable_Click);
      // 
      // cmdCreateTable
      // 
      this.cmdCreateTable.Location = new System.Drawing.Point(400, 80);
      this.cmdCreateTable.Name = "cmdCreateTable";
      this.cmdCreateTable.Size = new System.Drawing.Size(80, 32);
      this.cmdCreateTable.TabIndex = 11;
      this.cmdCreateTable.Text = "Create Table";
      this.cmdCreateTable.Click += new System.EventHandler(this.cmdCreateTable_Click);
      // 
      // lblCreateTable
      // 
      this.lblCreateTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblCreateTable.Location = new System.Drawing.Point(16, 32);
      this.lblCreateTable.Name = "lblCreateTable";
      this.lblCreateTable.Size = new System.Drawing.Size(368, 144);
      this.lblCreateTable.TabIndex = 10;
      // 
      // lblCreateSQLStatement
      // 
      this.lblCreateSQLStatement.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblCreateSQLStatement.Location = new System.Drawing.Point(16, 8);
      this.lblCreateSQLStatement.Name = "lblCreateSQLStatement";
      this.lblCreateSQLStatement.Size = new System.Drawing.Size(216, 16);
      this.lblCreateSQLStatement.TabIndex = 9;
      this.lblCreateSQLStatement.Text = "SQL Statement To Create a Table";
      // 
      // lblModifyTable
      // 
      this.lblModifyTable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblModifyTable.Location = new System.Drawing.Point(16, 216);
      this.lblModifyTable.Name = "lblModifyTable";
      this.lblModifyTable.Size = new System.Drawing.Size(368, 80);
      this.lblModifyTable.TabIndex = 13;
      // 
      // lblModifySQLStatment
      // 
      this.lblModifySQLStatment.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblModifySQLStatment.Location = new System.Drawing.Point(16, 192);
      this.lblModifySQLStatment.Name = "lblModifySQLStatment";
      this.lblModifySQLStatment.Size = new System.Drawing.Size(216, 16);
      this.lblModifySQLStatment.TabIndex = 12;
      this.lblModifySQLStatment.Text = "SQL Statement To Modify a Table";
      // 
      // frmTableTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(488, 405);
      this.Controls.Add(this.cmdDeleteTable);
      this.Controls.Add(this.lblDeleteTable);
      this.Controls.Add(this.lblDeleteSQLStatement);
      this.Controls.Add(this.cmdModifyTable);
      this.Controls.Add(this.cmdCreateTable);
      this.Controls.Add(this.lblCreateTable);
      this.Controls.Add(this.lblCreateSQLStatement);
      this.Controls.Add(this.lblModifyTable);
      this.Controls.Add(this.lblModifySQLStatment);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTableTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Create, Modify and Delete Tables Tryout";
      this.Load += new System.EventHandler(this.frmTableTryout_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTableTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTableTryout()
      //***
      // Action
      //   - Create instance of 'frmTableTryout'
      // Called by
      //   - frmMainTryout.cmdTable_Click(System.Object, System.EventArgs) Handles cmdTable.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTableTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdCreateTable_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Perform a task (to create a table)
      //   - If successful
      //     - Show message
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool PerformTask(string)
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdCreateTable_Click(System.Object, System.EventArgs) Handles cmdCreateTable.Click

    private void cmdDeleteTable_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Perform a task (to delete a table)
      //   - If successful
      //     - Show message
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool PerformTask(string)
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdDeleteTable_Click(System.Object, System.EventArgs) Handles cmdDeleteTable.Click

    private void cmdModifyTable_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Perform a task (to modify a table)
      //   - If successful
      //     - Show message
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool PerformTask(string)
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdModifyTable_Click(System.Object, System.EventArgs) Handles cmdModifyTable.Click

    private void frmTableTryout_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and set a SQL statement to create a table
      //   - Show it on the form
      //   - Define and set a SQL statement to modify a table
      //   - Show it on the form
      //   - Define and set a SQL statement to deletea table
      //   - Show it on the form
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmTableTryout_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private bool PerformTask(string strSQLStatement)
      //***
      // Action
      //   - Define a boolean
      //   - Create a new SQL command using a SQL statement
      //   - Set the connection to the command
      //   - Open the connection
      //   - The boolean becomes true
      //   - Try to
      //     - Execute the command
      //   - When error occurs
      //     - Show exception message
      //     - The boolean becomes foams
      //   - Close the connection
      //   - Return the boolean
      // Called by
      //   - cmdCreateTable_Click(System.Object, System.EventArgs) Handles cmdCreateTable.Click
      //   - cmdDeleteTable_Click(System.Object, System.EventArgs) Handles cmdDeleteTable.Click
      //   - cmdModifyTable_Click(System.Object, System.EventArgs) Handles cmdModifyTable.Click
      // Calls
      //   - cpGeneralRoutines()
      //   - SqlClient.SqlConnection cpGenerateRoutines.GetConnection()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return false;
    }
    // bool PerformTask(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTableTryout

}
// CopyPaste.Learning