//***
// Action
//   - Testroutine for cpBase and cpDerived
// Created
//   - CopyPaste � 20240618 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240618 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create a new instance of cpBase
      //   - Create a new instance of cpDerived
      //   - Execute all possible subroutines
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpBase()
      //   - cpBase.SubMustOverride()
      //   - cpBase.SubNotOverridable()
      //   - cpBase.SubOverLoad()
      //   - cpBase.SubOverLoad(String)
      //   - cpBase.SubOverridable()
      //   - cpBase.SubShadows()
      //   - cpBase.SubStatic()
      //   - cpBase.SubTestBase()
      //   - cpDerived()
      //   - cpDerived.SubOverridable()
      //   - cpDerived.SubShadows()
      //   - cpDerived.SubTestDerived()
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      cpBase thecpBase = new cpBase();
      cpDerived thecpDerived = new cpDerived();
      
      Console.WriteLine("Default startroutine in a module");
      Console.WriteLine();
      
      Console.WriteLine("Routines in base class");
      thecpBase.SubOverLoad();
      thecpBase.SubOverLoad("This is overloaded");
      thecpBase.SubOverridable();
      // theBase.SubNotOverridable();
      // theBase.SubMustOverride();
      thecpBase.SubShadows();
      cpBase.SubStatic();
      
      Console.WriteLine();
      thecpBase.SubTestBase();
      Console.WriteLine();
      
      Console.WriteLine("Routines in derived class");
      thecpDerived.SubOverLoad();
      thecpDerived.SubOverLoad("This is overloaded");
      thecpDerived.SubOverridable();
      // theDerived.SubNotOverridable();
      // theDerived.SubMustOverride();
      thecpDerived.SubShadows();
      cpDerived.SubStatic();
      
      Console.WriteLine();
      thecpDerived.SubTestDerived();
      Console.WriteLine();
      
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx