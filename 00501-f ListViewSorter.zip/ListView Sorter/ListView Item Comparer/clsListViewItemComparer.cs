﻿//***
// Action
//   - Define how items in a list are compared
// Created
//   - CopyPaste – 20250722 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250722 – VVDW
// Proposal (To Do)
//   - Pay attention here, all is compared with strings (so alphabetically)
//***

using System.Collections;
using System.Windows.Forms;

namespace CopyPaste.Learning.UserInterface
{

  public class cpListViewItemComparer: IComparer
  {

    #region "Constructors / Destructors"

    public cpListViewItemComparer() : this(0)
      //***
      // Action
      //   - Empty constructor
      //   - By default the column number is 0
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - cpListViewItemComparer(int)
      // Created
      //   - CopyPaste – 20250722 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250722 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpListViewItemComparer()

    public cpListViewItemComparer(int lngColumn)
      //***
      // Action
      //   - Basic constructor with a given columnnumber
      // Called by
      //   - cpListViewItemComparer()
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250722 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250722 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mlngColumn = lngColumn;
    }
    // cpListViewItemComparer()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    int mlngColumn;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int Compare(System.Object objX, System.Object objY)
      //***
      // Action
      //   - Two items (objX and objY) are compared with each other
      //   - This is done in alphabetical order on a specific column number
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250722 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250722 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return string.Compare(((ListViewItem)objX).SubItems[mlngColumn].Text, ((ListViewItem)objY).SubItems[mlngColumn].Text);
    }
    // int Compare(System.Object, System.Object) Implements IComparer.Compare

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpListViewItemComparer

}
// CopyPaste.Learning.UserInterface