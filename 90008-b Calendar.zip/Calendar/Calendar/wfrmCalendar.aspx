﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCalendar.aspx.cs" Inherits="CopyPaste.Learning.wfrmCalendar" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Calendar</title>
</head>
<body>
  <form id="wfrmCalendar" method="post" runat="server">
    <asp:Calendar ID="calSelectDay" Style="z-index: 101; position: absolute; top: 16px; left: 24px"
      runat="server" Width="464px" DayNameFormat="Full"></asp:Calendar>
    <asp:Label ID="lblSelectedDay" Style="z-index: 102; position: absolute; top: 216px; left: 24px"
      runat="server" Width="464px"></asp:Label>
  </form>
</body>
</html>
