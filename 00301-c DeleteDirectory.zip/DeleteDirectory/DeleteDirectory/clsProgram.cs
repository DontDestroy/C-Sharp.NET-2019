//***
// Action
//   - Demo of deleting directories
// Created
//   - CopyPaste � 20240717 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240717 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Show information
      //   - Try to
      //     - Delete "T:\Sample01"
      //   - When an error Show a corresponding message and the error message
      //   - Try to
      //     - Delete "T:\Temp\Sample02"
      //   - When an error Show a corresponding message and the error message
      //   - Try to
      //     - Delete "Sample03"
      //   - When an error Show a corresponding message and the error message
      //   - Show information
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Deleting directories...");

      try
      {
        Directory.Delete("T:\\Sample01", true);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error deleting directory T:\\Sample01");
        Console.WriteLine("Error {0}", theException.Message);
      }
      finally
      {
      }

      try
      {
        Directory.Delete("T:\\Temp\\Sample02", true);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error deleting directory T:\\Temp\\Sample02");
        Console.WriteLine("Error {0}", theException.Message);
      }
      finally
      {
      }

      try
      {
        Directory.Delete("Sample03", true);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error deleting directory Sample03");
        Console.WriteLine("Error {0}", theException.Message);
      }
      finally
      {
      }

      Console.WriteLine("Directories deleted");
      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning