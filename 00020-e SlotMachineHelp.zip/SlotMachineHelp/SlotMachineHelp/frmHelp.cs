//***
// Action
//   - Show the help screen
// Created
//   - CopyPaste � 20240411 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240411 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmHelp: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdOK;
    internal System.Windows.Forms.TextBox txtHelp;
    internal System.Windows.Forms.Label lblHelp;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmHelp));
      this.cmdOK = new System.Windows.Forms.Button();
      this.txtHelp = new System.Windows.Forms.TextBox();
      this.lblHelp = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdOK
      // 
      this.cmdOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdOK.Location = new System.Drawing.Point(625, 629);
      this.cmdOK.Name = "cmdOK";
      this.cmdOK.TabIndex = 5;
      this.cmdOK.Text = "OK";
      this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
      // 
      // txtHelp
      // 
      this.txtHelp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.txtHelp.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.txtHelp.Location = new System.Drawing.Point(13, 49);
      this.txtHelp.Multiline = true;
      this.txtHelp.Name = "txtHelp";
      this.txtHelp.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtHelp.Size = new System.Drawing.Size(684, 572);
      this.txtHelp.TabIndex = 4;
      this.txtHelp.Text = "";
      // 
      // lblHelp
      // 
      this.lblHelp.Location = new System.Drawing.Point(5, 9);
      this.lblHelp.Name = "lblHelp";
      this.lblHelp.Size = new System.Drawing.Size(296, 23);
      this.lblHelp.TabIndex = 3;
      this.lblHelp.Text = "User manual";
      // 
      // frmHelp
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(704, 661);
      this.Controls.Add(this.cmdOK);
      this.Controls.Add(this.txtHelp);
      this.Controls.Add(this.lblHelp);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmHelp";
      this.Text = "Help";
      this.Load += new System.EventHandler(this.frmHelp_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmHelp'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmHelp()
      //***
      // Action
      //   - Create instance of 'frmHelp'
      // Called by
      //   - frmSlotMachineLuckySeven.cmdHelp_Click(System.Object, System.EventArgs) Handles cmdHelp.Click
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmHelp()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdOK_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Closes the form (using properties, not code)
      //   - DialogResult.OK is the result of the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.DialogResult = DialogResult.OK;
    }
    // cmdOK_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdOK.Click
    
    private void frmHelp_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Read the text "ReadMe.txt" in the same directory as the application.
      //   - Read till the end
      //   - The content of the file becomes the text of a textbox
      //   - File is closed
      //   - Cursor is placed at the start of the text
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      StreamReader strReaderHelpText ;
    
      strReaderHelpText = new StreamReader(Environment.CurrentDirectory + "//ReadMe.txt");
      txtHelp.Text = strReaderHelpText.ReadToEnd();
      strReaderHelpText.Close();
      txtHelp.Select(0,0);
    }
    // frmHelp_Load(System.Object, System.EventArgs)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDefault

}
// CopyPaste.xxx