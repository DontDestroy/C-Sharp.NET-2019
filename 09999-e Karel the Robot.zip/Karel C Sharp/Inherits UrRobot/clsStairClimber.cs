﻿//***
// Action
//   - Definition of a green robot at origin looking to the East
//   - Add functionality to climb a stair
// Created
//   - CopyPaste – 20251012 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251012 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpStairClimber : UrRobot
	{

		#region "Constructors / Destructors"

		public cpStairClimber(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Robot becomes a theColor cpStairClimber starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
		//   - Nothing else happens
		// Called by
		//   - cpProgram.StairClimber()
		//   - cpStairClimber(int, int, Directions.Direction, int)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251012 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251012 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
		}
		// cpStairClimber(int, int, Directions.Direction, int, Color)

		public cpStairClimber(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Robot becomes a theColor cpStairClimber starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
		//   - Nothing else happens
		// Called by
		//   - 
		// Calls
		//   - cpStairClimber(int, int, Directions.Direction, int, Color)
		// Created
		//   - CopyPaste – 20251012 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251012 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
		}
		// cpStairClimber(int, int, Directions.Direction, int)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		private void ClimbOneStair()
		//***
		// Action
		//   - Turn to the left
		//   - Move one forward (in this case to the North)
		//   - Turn to the right
		//   - Move one forward (in this case to the East)
		// Called by
		//   - ClimbThreeStairs()
		// Calls
		//   - TurnRight()
		// Created
		//   - CopyPaste – 20251012 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251012 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			turnLeft();
			move();
			TurnRight();
			move();
		}
		// ClimbOneStair()

		private void ClimbThreeStairs()
		//***
		// Action
		//   - Robot will move up the stairs
		//   - Repeat 3 times the climb one stair
		// Called by
		//   - GetBeeper()
		// Calls
		//   - ClimbOneStair()
		// Created
		//   - CopyPaste – 20251012 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251012 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			ClimbOneStair();
			ClimbOneStair();
			ClimbOneStair();
		}
		// ClimbThreeStairs()

		public void GetBeeper()
		//***
		// Action
		//   - Robot will move up the stairs
		//   - Pick the beeper
		//   - Switch off the robot
		// Called by
		//   - cpProgram.StairClimber()
		// Calls
		//   - ClimbThreeStairs()
		// Created
		//   - CopyPaste – 20251012 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251012 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			ClimbThreeStairs();
			pickBeeper();
			turnOff();
		}
		// GetBeeper()

		private void TurnRight()
		//***
		// Action
		//   - Turn to the right by turning 3 times to the left
		// Called by
		//   - ClimbOneStair()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251012 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251012 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			turnLeft();
			turnLeft();
			turnLeft();
		}
		// TurnRight()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpStairClimber

}
// cpKarelTheRobot