//***
// Action
//   - Second form using cpSortablePoint
//   - Loop normal thru an ArrayList using cpSortedPointList
// Created
//   - CopyPaste � 20240314 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240314 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPointList: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdDraw;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPointList));
      this.cmdDraw = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdDraw
      // 
      this.cmdDraw.Location = new System.Drawing.Point(208, 240);
      this.cmdDraw.Name = "cmdDraw";
      this.cmdDraw.TabIndex = 2;
      this.cmdDraw.Text = "&Draw";
      this.cmdDraw.Click += new System.EventHandler(this.cmdDraw_Click);
      // 
      // frmPointList
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdDraw);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPointList";
      this.Text = "Point List";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPointList'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPointList()
      //***
      // Action
      //   - Create instance of 'frmPointList'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPointList()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdDraw_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Generate random 250 points in the cpSortedPointList
      //   - Loop using for each
      //     - Visualise the points on the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool cpPointEnumerator.MoveNext()
      //   - cpPointEnumerator(ArrayList)
      //   - cpSortedPointList.AddRandomPoints(int, int)
      //   - cpSortedPointList()
      //   - int cpSortablePoint.X (Get)
      //   - int cpSortablePoint.Y (Get)
      //   - System.Object cpPointEnumerator.Current() (Get)
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Color theColor;
      cpSortedPointList arrcpPoint = new cpSortedPointList();
      Graphics theGraph = this.CreateGraphics();
      int lngCounter = 1;
      
      arrcpPoint.AddRandomPoints(250, 200);

      foreach (cpSortablePoint thecpPoint in arrcpPoint)
      {
        theColor = System.Drawing.Color.FromArgb(25, 25, lngCounter);

        SolidBrush theBrush = new SolidBrush(theColor);
        lngCounter += 1;
        theGraph.FillEllipse(theBrush, thecpPoint.X, thecpPoint.Y, 10, 10);
        theBrush.Dispose();
      }
      // in arrcpPoint
   
    }
    // cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPointList
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPointList());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPointList

}
// CopyPaste.Learning