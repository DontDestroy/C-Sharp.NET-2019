﻿//***
// Action
//   - Example of a listbox in a web page
// Created
//   - CopyPaste – 20260415 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260415 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmListBox : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.lstName.SelectedIndexChanged += new System.EventHandler(this.lstName_SelectedIndexChanged);
      this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
    }
    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260415 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260415 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void cmdOK_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - If there is something selected
    //       - Set label on form what value, what item and what text has been selected
    //     - If not
    //       - Set label on form that something must be selected
    //   - On possible error
    //     - Set label on form that something must be selected
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260415 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260415 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      try
      {

        if (lstName.SelectedIndex == -1)
        {
          lblResult.Text = "You have to select a name";
        }
        else
        // lstName.SelectedIndex <> -1
        {
          lblResult.Text = "You have choosen: " + lstName.SelectedItem.Value + " (" +
            (lstName.SelectedIndex + 1) + "°) item with name : " +
            lstName.SelectedItem.Text;
        }
        // lstName.SelectedIndex = -1

      }
      catch (NullReferenceException theException)
      {
        lblResult.Text = "You have to select a name";
      }

    }
    // cmdOK_Click(System.Object, System.EventArgs) Handles cmdOK.Click

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260415 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260415 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // Page_Load(System.Object, System.EventArgs) Handles base.Load

    private void lstName_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a list item
    //   - Loop thru all the list items
    //     - Set all items with first letter as capital, and all other letters small
    //   - Selected item becomes full in capitals
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260415 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260415 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      foreach (ListItem theListItem in lstName.Items)
      {
        theListItem.Text = theListItem.Text.Substring(0, 1).ToUpper() + theListItem.Text.Substring(1).ToLower();
      }
      // in lstName.Items

      lstName.SelectedItem.Text = lstName.SelectedItem.Text.ToUpper();
    }
    // lstName_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstName.SelectedIndexChanged

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmListBox

}
// CopyPaste.Learning