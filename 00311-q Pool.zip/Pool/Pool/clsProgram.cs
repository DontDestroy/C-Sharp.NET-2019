//***
// Action
//   - Working with a shared thread pool
//   - A thread is waiting to do something (sitting in a pool)
//   - Generally used to program an ansychronous event or timer
//   - Threads will be placed in a queue and return if they are finished
// Created
//   - CopyPaste � 20250710 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250710 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Threading;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void DisplayLotOfA(System.Object theState)
      //***
      // Action
      //   - Display 251 times "A"
      //   - Wait a second
      //     - If you comment out the Sleep, the main thread exits before the thread pool task runs
      //     - The thread pool uses background threads, which do not keep the application running
      //     - This is a simple example of a race condition.)
      //   - Set the state to AutoResetEvent, so the waiting state is finished
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250710 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      AutoResetEvent theAutoResetEvent;

      for (int lngCounter = 0; lngCounter <= 250; lngCounter++)
      {
        Console.Write("A");
      }
      // lngCounter = 251

      Thread.Sleep(1000);
      theAutoResetEvent = (AutoResetEvent)theState;
      theAutoResetEvent.Set();
    }
    // DisplayLotOfA(System.Object)

    public static void DisplayLotOfB(System.Object theState)
      //***
      // Action
      //   - Display 251 times "B"
      //   - Wait a second
      //     - If you comment out the Sleep, the main thread exits before the thread pool task runs
      //     - The thread pool uses background threads, which do not keep the application running
      //     - This is a simple example of a race condition.)
      //   - Set the state to AutoResetEvent, so the waiting state is finished
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250710 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      AutoResetEvent theAutoResetEvent;

      for (int lngCounter = 0; lngCounter <= 250; lngCounter++)
      {
        Console.Write("B");
      }
      // lngCounter = 251

      Thread.Sleep(1000);
      theAutoResetEvent = (AutoResetEvent)theState;
      theAutoResetEvent.Set();
    }
    // DisplayLotOfB(System.Object)

    public static void DisplayLotOfC(System.Object theState)
      //***
      // Action
      //   - Display 251 times "C"
      //   - Wait a second
      //     - If you comment out the Sleep, the main thread exits before the thread pool task runs
      //     - The thread pool uses background threads, which do not keep the application running
      //     - This is a simple example of a race condition.)
      //   - Set the state to AutoResetEvent, so the waiting state is finished
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250710 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      AutoResetEvent theAutoResetEvent;

      for (int lngCounter = 0; lngCounter <= 250; lngCounter++)
      {
        Console.Write("C");
      }
      // lngCounter = 251

      Thread.Sleep(1000);
      theAutoResetEvent = (AutoResetEvent)theState;
      theAutoResetEvent.Set();
    }
    // DisplayLotOfC(System.Object)

    public static void Main()
      //***
      // Action
      //   - Define a thread count
      //   - Define a thread port
      //   - Set 3 AutoResetEvents to false
      //   - Create 3 WaitCallBack
      //   - Set 3 methods to the threadpool queue (the execution starts here)
      //   - Get the available threads
      //   - Show the size and the port of the threadpool
      //   - Say you will wait on the execution of all threads (the execution is already started)
      //   - All the threads receive a trigger that it is finished
      //   - Show the message that a routine is finished
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - DisplayLotOfA(System.Object)
      //   - DisplayLotOfB(System.Object)
      //   - DisplayLotOfC(System.Object)
      // Created
      //   - CopyPaste � 20250710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250710 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngThreadCount;
      int lngThreadPort;

      AutoResetEvent theAEventIsDone = new AutoResetEvent(false);
      AutoResetEvent theBEventIsDone = new AutoResetEvent(false);
      AutoResetEvent theCEventIsDone = new AutoResetEvent(false);

      WaitCallback theDisplayACallBack = new WaitCallback(DisplayLotOfA);
      WaitCallback theDisplayBCallBack = new WaitCallback(DisplayLotOfB);
      WaitCallback theDisplayCCallBack = new WaitCallback(DisplayLotOfC);

      ThreadPool.QueueUserWorkItem(theDisplayACallBack, theAEventIsDone);
      // From here on the routine is already running
      ThreadPool.QueueUserWorkItem(theDisplayBCallBack, theBEventIsDone);
      ThreadPool.QueueUserWorkItem(theDisplayCCallBack, theCEventIsDone);

      ThreadPool.GetAvailableThreads(out lngThreadCount, out lngThreadPort);

      Console.WriteLine("Thread pool size: {0}, port: {1}", lngThreadCount, lngThreadPort);
      Console.WriteLine();
      Console.WriteLine("Waiting for asynchronous threads to complete.");

      theAEventIsDone.WaitOne();
      Console.WriteLine();
      Console.WriteLine("A is done");

      theBEventIsDone.WaitOne();
      Console.WriteLine();
      Console.WriteLine("B is done");

      theCEventIsDone.WaitOne();
      Console.WriteLine();
      Console.WriteLine("C is done");

      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning