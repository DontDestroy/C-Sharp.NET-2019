﻿//***
// Action
//   - Implementation of a cpDuck
//     - All ducks swim
//       - All class that inherit must show information on the Output Window
//     - All ducks can have an implementation of displaying, flying, making some noise and walking
//       - This is done thru delegates and events
//       - Meaning, that the functionality is outside the class of cpDuck
// Created
//   - CopyPaste – 20240727 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240727 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Animal.Library;
using System.Diagnostics;

namespace CopyPaste.Game.Duck.Library
{

	public abstract class cpDuck
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpDuck
		/// </summary>
		public cpDuck()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - cpDecoyDuck()
		//   - cpMallardDuck()
		//   - cpPlasticRubberDuck()
		//   - cpRedHeadDuck()
		//   - cpWoodDuck()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private byte bytQuackAnNumberOfTimes;

		public event cpDelegateDisplay PerformDisplay;
		// Display()
		public event cpDelegateFly PerformFly;
		// Fly()
		public event cpDelegateMakeNoise PerformMakeNoise;
		// MakeNoise()
		public event cpDelegateWalk PerformWalk;
		// Walk()
		
		private cpiDisplay cpHowToDisplay;
		private cpiFly cpHowToFly;
		private cpiMakeNoise cpHowToMakeNoise;
		private cpiWalk cpHowToWalk;

		#endregion

		#region "Properties"

		public byte NumberOfQuacks
		{

			get
			//***
			// Action Get
			//   - Return bytQuackAnNumberOfTimes
			// Called by
			//   - CopyPaste.Game.Duck.cmdMakeSound_Click(System.Object, EventArgs) Handles cmdMakeSound.Click
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20240727 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240727 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return bytQuackAnNumberOfTimes;
			}
			// byte NumberOfQuacks (Get)

			set
			//***
			// Action Set
			//   - bytQuackAnNumberOfTimes becomes value
			// Called by
			//   - cpDecoyDuck()
			//   - cpMallardDuck()
			//   - cpPlasticRubberDuck()
			//   - cpRedHeadDuck()
			//   - cpWoodDuck()
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20240727 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240727 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				bytQuackAnNumberOfTimes = value;
			}
			// NumberOfQuacks(byte) (Set)

		}
		// byte NumberOfQuacks

		public cpiDisplay HowToDisplay
		{

			get
			//***
			// Action Get
			//   - Return cpHowToDisplay
			// Called by
			//   - cpDuck.HowToDisplay(cpiDisplay) (Set)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20240727 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240727 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return cpHowToDisplay;
			}
			// cpiFly HowToDisplay (Get)

			set
			//***
			// Action Set
			//   - We don't remove the previous behaviour from the event
			//   - cpHowToDisplay becomes value
			//   - Add the new functionality to the event
			// Called by
			//   - cpDecoyDuck()
			//   - cpMallardDuck()
			//   - cpPlasticRubberDuck()
			//   - cpRedHeadDuck()
			//   - cpWoodDuck()
			// Calls
			//   - cpiDisplay HowToDisplay (Get)
			//   - cpiDisplay.Display()
			// Created
			//   - CopyPaste – 20240727 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240727 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				cpHowToDisplay = value;
				PerformDisplay += new cpDelegateDisplay(HowToDisplay.Display);
			}
			// HowToDisplay(cpiDisplay) (Set)

		}
		// cpiDisplay HowToDisplay

		public cpiFly HowToFly
		{

			get
			//***
			// Action Get
			//   - Return cpHowToFly
			// Called by
			//   - cpDuck.HowToFly(cpiFly) (Set)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20240727 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240727 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return cpHowToFly;
			}
			// cpiFly HowToFly (Get)

			set
			//***
			// Action Set
			//   - Try to remove the previous behaviour from the event
			//   - cpHowToFly becomes value
			//   - Add the new functionality to the event
			// Called by
			//   - cpDecoyDuck()
			//   - cpMallardDuck()
			//   - cpPlasticRubberDuck()
			//   - cpRedHeadDuck()
			//   - cpWoodDuck()
			// Calls
			//   - cpiFly HowToFly (Get)
			//   - cpiFly.Fly()
			// Created
			//   - CopyPaste – 20240727 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240727 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{

				if (PerformFly == null)
				{
				}
				else
				// PerformFly <> null
				{
					PerformFly -= new cpDelegateFly(HowToFly.Fly);
					// Don't do the code above, if you want to add behaviour to the event instead of replacing the behaviour
				}
				// PerformFly = null

				cpHowToFly = value;
				PerformFly += new cpDelegateFly(HowToFly.Fly);
			}
			// HowToFly(cpiFly) (Set)

		}
		// cpiFly HowToFly

		public cpiMakeNoise HowToMakeNoise
		{

			get
			//***
			// Action Get
			//   - Return cpHowToMakeNoise
			// Called by
			//   - cpDuck.HowToMakeNoise(cpiMakeNoise) (Set)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20240727 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240727 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return cpHowToMakeNoise;
			}
			// cpiMakeNoise HowToMakeNoise (Get)

			set
			//***
			// Action Set
			//   - Try to remove the previous behaviour from the event
			//   - cpHowToMakeNoise becomes value
			//   - Add the new functionality to the event
			// Called by
			//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
			//   - cpDecoyDuck()
			//   - cpMallardDuck()
			//   - cpPlasticRubberDuck()
			//   - cpRedHeadDuck()
			//   - cpWoodDuck()
			// Calls
			//   - cpiMakeNoise HowToMakeNoise (Get)
			//   - cpiMakeNoise.MakeNoise()
			// Created
			//   - CopyPaste – 20240727 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240727 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{

				if (PerformMakeNoise == null)
				{
				}
				else
				// PerformMakeNoise <> null
				{
					PerformMakeNoise -= new cpDelegateMakeNoise(HowToMakeNoise.MakeNoise);
					// Don't do the code above, if you want to add behaviour to the event instead of replacing the behaviour
				}
				// PerformMakeNoise = null

				cpHowToMakeNoise = value;
				PerformMakeNoise += new cpDelegateMakeNoise(HowToMakeNoise.MakeNoise);
			}
			// HowToMakeNoise(cpiMakeNoise) (Set)

		}
		// cpiMakeNoise HowToMakeNoise

		public cpiWalk HowToWalk
		{

			get
			//***
			// Action Get
			//   - Return cpHowToWalk
			// Called by
			//   - cpDuck.HowToWalk(cpiWalk) (Set)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20240727 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240727 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return cpHowToWalk;
			}
			// cpiWalk HowToWalk (Get)

			set
			//***
			// Action Set
			//   - Try to remove the previous behaviour from the event
			//   - cpHowToMakeNoise becomes value
			//   - Add the new functionality to the event
			// Called by
			//   - cpDecoyDuck()
			//   - cpMallardDuck()
			//   - cpPlasticRubberDuck()
			//   - cpRedHeadDuck()
			//   - cpWoodDuck()
			// Calls
			//   - cpiWalk cpDuck.HowToWalk (Get)
			//   - cpiWalk.Walk()
			// Created
			//   - CopyPaste – 20240727 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240727 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{

				if (PerformWalk == null)
				{
				}
				else
				// PerformWalk <> null
				{
					PerformWalk -= new cpDelegateWalk(HowToWalk.Walk);
					// Don't do the code above, if you want to add behaviour to the event instead of replacing the behaviour
				}
				// PerformWalk = null

				cpHowToWalk = value;
				PerformWalk += new cpDelegateWalk(HowToWalk.Walk);
			}
			// HowToWalk(cpiWalk) (Set)

		}
		// cpiWalk HowToWalk

		#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		#region "Event"

		public delegate void cpDelegateDisplay();
		public delegate void cpDelegateFly();
		public delegate void cpDelegateMakeNoise();
		public delegate void cpDelegateWalk();

		#endregion

		#region "Sub / Function"

		/// <summary>
		/// Clean the existing behaviour from a cpDuck
		/// </summary>
		public void CleanBehaviour()
		//***
		// Action
		//   - If there is a behaviour for displaying
		//     - Remove it
		//   - If there is a behaviour for flying
		//     - Remove it
		//   - If there is a behaviour for making a sound
		//     - Remove it
		//   - If there is a behaviour for walking
		//     - Remove it
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - PerformDisplay()
		//   - PerformFly()
		//   - PerformMakeNoise()
		//   - PerformWalk()
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformDisplay == null)
			{
			}
			else
			// PerformDisplay <> null
			{
				PerformDisplay -= new cpDelegateDisplay(HowToDisplay.Display);
			}
			// PerformDisplay = null

			if (PerformFly == null)
			{
			}
			else
			// PerformFly <> null
			{
				PerformFly -= new cpDelegateFly(HowToFly.Fly);
			}
			// PerformFly = null

			if (PerformMakeNoise == null)
			{
			}
			else
			// PerformMakeNoise <> null
			{
				PerformMakeNoise -= new cpDelegateMakeNoise(HowToMakeNoise.MakeNoise);
			}
			// PerformMakeNoise = null

			if (PerformWalk == null)
			{
			}
			else
			// PerformWalk <> null
			{
				PerformWalk -= new cpDelegateWalk(HowToWalk.Walk);
			}
			// PerformWalk = null

		}
		// CleanBehaviour()

		/// <summary>
		/// Define how the cpDuck moves in the air
		/// </summary>
		public void Display()
		//***
		// Action
		//   - If PerformDisplay is null
		//     - Do nothing
		//   - If Not
		//     - Execute PerformDisplay
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - PerformDisplay()
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformDisplay == null)
			{
			}
			else
			// PerformDisplay <> null
			{
				PerformDisplay();
			}
			// PerformDisplay = null

		}
		// Display()

		/// <summary>
		/// Define how the cpDuck moves in the air
		/// </summary>
		public void Fly()
		//***
		// Action
		//   - If PerformFly is null
		//     - Do nothing
		//   - If Not
		//     - Execute PerformFly
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - PerformFly()
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformFly == null)
			{
			}
			else
			// PerformFly <> null
			{
				PerformFly();
			}
			// PerformFly = null

		}
		// Fly()

		/// <summary>
		/// Define how the cpDuck makes some noise
		/// </summary>
		public void MakeNoise()
		//***
		// Action
		//   - If PerformMakeNoise is null
		//     - Do nothing
		//   - If Not
		//     - Execute PerformMakeNoise
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		//   - CopyPaste.Game.Duck.frmDuckGame.cmdMakeSound_Click(System.Object, EventArgs) Handles cmdMakeSound.Click
		// Calls
		//   - PerformMakeNoise()
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformMakeNoise == null)
			{
			}
			else
			// PerformMakeNoise <> null
			{
				PerformMakeNoise();
			}
			// PerformMakeNoise = null

		}
		// MakeNoise()

		/// <summary>
		/// How is a cpDuck moving on water
		/// </summary>
		public virtual void Swim()
		//***
		// Action
		//   - Define how the cpDuck moves in water
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("cpDuck is moving around in water");
		}
		// Swim()

		public override string ToString()
		//***
		// Action
		//   - Define how the cpDuck class name is shown
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			return this.GetType().Name;
		}
		// string ToString()

		/// <summary>
		/// Define how the cpDuck makes some noise
		/// </summary>
		public void Walk()
		//***
		// Action
		//   - If PerformWalk is null
		//     - Do nothing
		//   - If Not
		//     - Execute PerformWalk
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - PerformWalk()
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformWalk == null)
			{
			}
			else
			// PerformWalk <> null
			{
				PerformWalk();
			}
			// PerformWalk = null

		}
		// Walk()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpDuck

}
// CopyPaste.Game.Duck.Library