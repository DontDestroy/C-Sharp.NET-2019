//***
// Action
//   - Testroutine for cpiAge, cpPerson, cpTree
// Created
//   - CopyPaste � 20230818 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230818 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Create an array of 2 elements of cpAgeAndName
      //   - Create a cpPerson
      //   - Create a cpTree
      //   - Add the person and the tree to the array
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpiAgeAndName()
      //   - cpPerson(string, string, int)
      //   - cpTree(int)
      //   - cpTree.AddRing()
      //   - int cpiAgeAndName.Age (Get)
      //   - int cpPerson.Age (Get)
      //   - int cpTree.Age (Get)
      //   - string cpiAgeAndName.Name (Get)
      //   - string cpPerson.Name (Get)
      //   - string cpTree.Name (Get)
      // Created
      //   - CopyPaste � 20230818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpiAgeAndName[] arrcpiAge = new cpiAgeAndName[2];
      cpPerson thecpPerson = new cpPerson("Bob", "Jones", 1983);
      cpTree thecpTree = new cpTree(1976);
      string strOutput;

      arrcpiAge[0] = thecpTree;
      arrcpiAge[1] = thecpPerson;

      strOutput = thecpTree.ToString() + ": " + thecpTree.Name + Environment.NewLine + "Age is " + thecpTree.Age;
      MessageBox.Show(strOutput, "Demonstrating Polymorphism");

      strOutput = thecpPerson.ToString() + ": " + thecpPerson.Name + Environment.NewLine + "Age is " + thecpPerson.Age;
      MessageBox.Show(strOutput, "Demonstrating Polymorphism");

      thecpTree.AddRing();

      foreach (cpiAgeAndName thecpiAge in arrcpiAge)
      {
        strOutput = thecpiAge.Name + ": " + "Age is " + thecpiAge.Age;
        MessageBox.Show(strOutput, "Demonstrating Polymorphism");
      }
      // in arrcpiAge

    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning