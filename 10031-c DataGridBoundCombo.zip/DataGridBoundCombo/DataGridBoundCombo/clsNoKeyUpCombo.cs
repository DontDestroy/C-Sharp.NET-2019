//***
// Action
//   - Define a cpNoKeyUpCombo
// Created
//   - CopyPaste � 20260706 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260706 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning.Data
{

  public class cpNoKeyUpCombo : System.Windows.Forms.ComboBox
  {

    #region "Constructors / Destructors"

    public cpNoKeyUpCombo()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - clsDataGridComboBoxColumn()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260706 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpNoKeyUpCombo()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private long mlngKeyUp = 0x101;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void WndProc(ref System.Windows.Forms.Message theMessage)
    {

      if (theMessage.Msg == mlngKeyUp)
      {
      }
      else
        // theMessage.Msg <> mlngKeyUp
      {
        base.WndProc (ref theMessage);
      }
      // theMessage.Msg = mlngKeyUp

    }
    // WndProc(�System.Windows.Forms.Message theMessage)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpNoKeyUpCombo

}
// CopyPaste.Learning.Data