//***
// Action
//   - Starting screen of application
//   - Nine buttons with actions about bound controls
// Created
//   - CopyPaste � 20251231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251231 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBoundControlsMainWizard: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    internal System.Windows.Forms.Button cmdDrillDown;
    internal System.Windows.Forms.Button cmdEnableButtons;
    internal System.Windows.Forms.Button cmdListBoxErrorHandling;
    internal System.Windows.Forms.Button cmdListBoxAddDelete;
    internal System.Windows.Forms.Button cmdListBoxUpdate;
    internal System.Windows.Forms.Button cmdComboBoxDataGrid;
    internal System.Windows.Forms.Button cmdListBoxSelect;
    internal System.Windows.Forms.ToolTip ttpComment;
    internal System.Windows.Forms.Button cmdListBoxLimit;
    internal System.Windows.Forms.Button cmdListbox;
    private System.ComponentModel.IContainer components;


    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBoundControlsMainWizard));
      this.cmdDrillDown = new System.Windows.Forms.Button();
      this.cmdEnableButtons = new System.Windows.Forms.Button();
      this.cmdListBoxErrorHandling = new System.Windows.Forms.Button();
      this.cmdListBoxAddDelete = new System.Windows.Forms.Button();
      this.cmdListBoxUpdate = new System.Windows.Forms.Button();
      this.cmdComboBoxDataGrid = new System.Windows.Forms.Button();
      this.cmdListBoxSelect = new System.Windows.Forms.Button();
      this.ttpComment = new System.Windows.Forms.ToolTip(this.components);
      this.cmdListBoxLimit = new System.Windows.Forms.Button();
      this.cmdListbox = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdDrillDown
      // 
      this.cmdDrillDown.Location = new System.Drawing.Point(152, 154);
      this.cmdDrillDown.Name = "cmdDrillDown";
      this.cmdDrillDown.Size = new System.Drawing.Size(112, 32);
      this.cmdDrillDown.TabIndex = 8;
      this.cmdDrillDown.Text = "Drill down";
      this.cmdDrillDown.Click += new System.EventHandler(this.cmdDrillDown_Click);
      // 
      // cmdEnableButtons
      // 
      this.cmdEnableButtons.Location = new System.Drawing.Point(152, 58);
      this.cmdEnableButtons.Name = "cmdEnableButtons";
      this.cmdEnableButtons.Size = new System.Drawing.Size(112, 32);
      this.cmdEnableButtons.TabIndex = 6;
      this.cmdEnableButtons.Text = "Enable Buttons";
      this.cmdEnableButtons.Click += new System.EventHandler(this.cmdEnableButtons_Click);
      // 
      // cmdListBoxErrorHandling
      // 
      this.cmdListBoxErrorHandling.Location = new System.Drawing.Point(152, 10);
      this.cmdListBoxErrorHandling.Name = "cmdListBoxErrorHandling";
      this.cmdListBoxErrorHandling.Size = new System.Drawing.Size(112, 32);
      this.cmdListBoxErrorHandling.TabIndex = 5;
      this.cmdListBoxErrorHandling.Text = "Error Handling";
      this.cmdListBoxErrorHandling.Click += new System.EventHandler(this.cmdListBoxErrorHandling_Click);
      // 
      // cmdListBoxAddDelete
      // 
      this.cmdListBoxAddDelete.Location = new System.Drawing.Point(64, 202);
      this.cmdListBoxAddDelete.Name = "cmdListBoxAddDelete";
      this.cmdListBoxAddDelete.Size = new System.Drawing.Size(144, 32);
      this.cmdListBoxAddDelete.TabIndex = 4;
      this.cmdListBoxAddDelete.Text = "Listbox Add && Delete";
      this.cmdListBoxAddDelete.Click += new System.EventHandler(this.cmdListBoxAddDelete_Click);
      // 
      // cmdListBoxUpdate
      // 
      this.cmdListBoxUpdate.Location = new System.Drawing.Point(8, 154);
      this.cmdListBoxUpdate.Name = "cmdListBoxUpdate";
      this.cmdListBoxUpdate.Size = new System.Drawing.Size(112, 32);
      this.cmdListBoxUpdate.TabIndex = 3;
      this.cmdListBoxUpdate.Text = "Listbox Update";
      this.cmdListBoxUpdate.Click += new System.EventHandler(this.cmdListBoxUpdate_Click);
      // 
      // cmdComboBoxDataGrid
      // 
      this.cmdComboBoxDataGrid.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmdComboBoxDataGrid.Location = new System.Drawing.Point(152, 106);
      this.cmdComboBoxDataGrid.Name = "cmdComboBoxDataGrid";
      this.cmdComboBoxDataGrid.Size = new System.Drawing.Size(112, 32);
      this.cmdComboBoxDataGrid.TabIndex = 7;
      this.cmdComboBoxDataGrid.Text = "Combobox && Datagrid";
      this.cmdComboBoxDataGrid.Click += new System.EventHandler(this.cmdComboBoxDataGrid_Click);
      // 
      // cmdListBoxSelect
      // 
      this.cmdListBoxSelect.Location = new System.Drawing.Point(8, 106);
      this.cmdListBoxSelect.Name = "cmdListBoxSelect";
      this.cmdListBoxSelect.Size = new System.Drawing.Size(112, 32);
      this.cmdListBoxSelect.TabIndex = 2;
      this.cmdListBoxSelect.Text = "Listbox Select";
      this.cmdListBoxSelect.Click += new System.EventHandler(this.cmdListBoxSelect_Click);
      // 
      // cmdListBoxLimit
      // 
      this.cmdListBoxLimit.Location = new System.Drawing.Point(8, 58);
      this.cmdListBoxLimit.Name = "cmdListBoxLimit";
      this.cmdListBoxLimit.Size = new System.Drawing.Size(112, 32);
      this.cmdListBoxLimit.TabIndex = 1;
      this.cmdListBoxLimit.Text = "Listbox Limit";
      this.cmdListBoxLimit.Click += new System.EventHandler(this.cmdListBoxLimit_Click);
      // 
      // cmdListbox
      // 
      this.cmdListbox.Location = new System.Drawing.Point(8, 10);
      this.cmdListbox.Name = "cmdListbox";
      this.cmdListbox.Size = new System.Drawing.Size(112, 32);
      this.cmdListbox.TabIndex = 0;
      this.cmdListbox.Text = "Listbox";
      this.cmdListbox.Click += new System.EventHandler(this.cmdListbox_Click);
      // 
      // frmBoundControlsMainWizard
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(272, 245);
      this.Controls.Add(this.cmdEnableButtons);
      this.Controls.Add(this.cmdListBoxErrorHandling);
      this.Controls.Add(this.cmdListBoxAddDelete);
      this.Controls.Add(this.cmdListBoxUpdate);
      this.Controls.Add(this.cmdComboBoxDataGrid);
      this.Controls.Add(this.cmdListBoxSelect);
      this.Controls.Add(this.cmdListBoxLimit);
      this.Controls.Add(this.cmdListbox);
      this.Controls.Add(this.cmdDrillDown);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBoundControlsMainWizard";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Bound Controls Main Form Wizard";
      this.Load += new System.EventHandler(this.frmBoundControlsMainWizard_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBoundControlsMainWizard'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBoundControlsMainWizard()
      //***
      // Action
      //   - Create instance of 'frmBoundControlsMainWizard'
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmBoundControlsMainWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdComboBoxDataGrid_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create an instance of frmComboBoxDataGridWizard
      //   - Show the form instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmComboBoxDataGridWizard()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmComboBoxDataGridWizard thefrmComboBoxDataGrid;

      thefrmComboBoxDataGrid = new frmComboBoxDataGridWizard();
      thefrmComboBoxDataGrid.Show();
    }
    // cmdComboBoxDataGrid_Click(System.Object, System.EventArgs) Handles cmdComboBoxDataGrid.Click

    private void cmdDrillDown_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create an instance of frmDataGridDrillDownWizard
      //   - Show the form instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmDataGridDrillDownWizard()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmDataGridDrillDownWizard thefrmDataGridDrillDown;

      thefrmDataGridDrillDown = new frmDataGridDrillDownWizard();
      thefrmDataGridDrillDown.Show();
    }
    // cmdDrillDown_Click(System.Object, System.EventArgs) Handles cmdDrillDown.Click

    private void cmdEnableButtons_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create an instance of frmListBoxEnableButtonsWizard
      //   - Show the form instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmListBoxEnableButtonsWizard()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmListBoxEnableButtonsWizard thefrmListBoxEnableButtons;

      thefrmListBoxEnableButtons = new frmListBoxEnableButtonsWizard();
      thefrmListBoxEnableButtons.Show();
    }
    // cmdEnableButtons_Click(System.Object, System.EventArgs) Handles cmdEnableButtons.Click

    private void cmdListbox_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create an instance of frmListBoxWizard
      //   - Show the form instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmListBoxWizard()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmListBoxWizard thefrmListbox;

      thefrmListbox = new frmListBoxWizard();
      thefrmListbox.Show();
    }
    // cmdListbox_Click(System.Object, System.EventArgs) Handles cmdListbox.Click

    private void cmdListBoxAddDelete_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create an instance of frmListBoxAddDeleteWizard
      //   - Show the form instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmListBoxAddDeleteWizard()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmListBoxAddDeleteWizard thefrmListBoxAddDelete;

      thefrmListBoxAddDelete = new frmListBoxAddDeleteWizard();
      thefrmListBoxAddDelete.Show();
    }
    // cmdListBoxAddDelete_Click(System.Object, System.EventArgs) Handles cmdListBoxAddDelete.Click

    private void cmdListBoxErrorHandling_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create an instance of frmListBoxErrorHandlingWizard
      //   - Show the form instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmListBoxErrorHandlingWizard()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmListBoxErrorHandlingWizard thefrmListBoxErrorHandling;

      thefrmListBoxErrorHandling = new frmListBoxErrorHandlingWizard();
      thefrmListBoxErrorHandling.Show();    
    }
    // cmdListBoxErrorHandling_Click(System.Object, System.EventArgs) Handles cmdListBoxErrorHandling.Click

    private void cmdListBoxLimit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create an instance of frmListBoxLimitWizard
      //   - Show the form instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmListBoxLimitWizard()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmListBoxLimitWizard thefrmListBoxLimit;

      thefrmListBoxLimit = new frmListBoxLimitWizard();
      thefrmListBoxLimit.Show();
    }
    // cmdListBoxLimit_Click(System.Object, System.EventArgs) Handles cmdListBoxLimit.Click
    
    private void cmdListBoxSelect_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create an instance of frmListBoxSelectWizard
      //   - Show the form instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - thefrmListBoxSelectWizard()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmListBoxSelectWizard thefrmListBoxSelect;

      thefrmListBoxSelect = new frmListBoxSelectWizard();
      thefrmListBoxSelect.Show();
    }
    // cmdListBoxSelect_Click(System.Object, System.EventArgs) Handles cmdListBoxSelect.Click

    private void cmdListBoxUpdate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create an instance of frmListBoxUpdateWizard
      //   - Show the form instance
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmListBoxUpdateWizard()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmListBoxUpdateWizard thefrmListBoxUpdate;

      thefrmListBoxUpdate = new frmListBoxUpdateWizard();
      thefrmListBoxUpdate.Show();
    }
    // cmdListBoxUpdate_Click(System.Object, System.EventArgs) Handles cmdListBoxUpdate.Click

    private void frmBoundControlsMainWizard_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set a tooltip for every button on the screen
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ttpComment.SetToolTip(cmdListbox, "Create a bound list box");
      ttpComment.SetToolTip(cmdListBoxLimit, "Limit data displayed in a list box");
      ttpComment.SetToolTip(cmdListBoxSelect, "Bind individual textboxes based on a selected listbox item");
      ttpComment.SetToolTip(cmdListBoxUpdate, "Edit and update data using bound controls");
      ttpComment.SetToolTip(cmdListBoxAddDelete, "Add and delete records using bound controls");
      ttpComment.SetToolTip(cmdListBoxErrorHandling, "Error handling with bound controls");
      ttpComment.SetToolTip(cmdEnableButtons, "Put finishing touches on a bound data entry form");
      ttpComment.SetToolTip(cmdComboBoxDataGrid, "Bind data to ComboBox and DataGrid controls");
      ttpComment.SetToolTip(cmdDrillDown, "Drill down to data in the data grid control");
    }
    // frmBoundControlsMainWizard_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBoundControlsMainWizard

}
// CopyPaste.Learning