//***
// Action
//   - Definition of cpToday
// Created
//   - CopyPaste � 20230530 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230530 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpToday
  {

   #region "Constructors / Destructors"

    public cpToday()
    //***
    // Action
    //   - Empty constructor
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230530 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230530 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpToday()

   #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static DateTime mdtmToday = DateTime.Now;
    public static long mlngDay  = DateTime.Now.Day;
    public static long mlngMonth = DateTime.Now.Month;
    public static long mlngNumericDayOfWeek = (long) DateTime.Now.DayOfWeek;
    public static long mlngYear = DateTime.Now.Year;
    public static string mstrDayOfWeek = DateTime.Now.DayOfWeek.ToString();
    
    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // 

}
// CopyPaste.Learning