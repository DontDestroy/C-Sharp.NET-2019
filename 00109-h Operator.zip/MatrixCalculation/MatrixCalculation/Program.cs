﻿using System;
using System.Text;

namespace MatrixCalculation
{

  public class cpMatrix
  {
    private int[,] aMatrix;

    public int Rows { get; set; }
    public int Columns { get; set; }

    public cpMatrix(int numberOfRows, int numberOfColumns)
    {
      Rows = Math.Abs(numberOfRows);
      Columns = Math.Abs(numberOfColumns);

      aMatrix = new int[Rows, Columns];
    }

    public int this[int theRow, int theColumn]
    {
      get
      {
        // Some checks if you are still inside the matrix should be added
        return this.aMatrix[Math.Abs(theRow), Math.Abs(theColumn)];
      }

      set
      {
        // Some checks if you are still inside the matrix should be added
        this.aMatrix[Math.Abs(theRow), Math.Abs(theColumn)] = value;
      }

    }

    public static cpMatrix operator +(cpMatrix matrix1, cpMatrix matrix2)
    {
      // There must be a check if both matrixes have the same size
      cpMatrix matrixResult = new cpMatrix(matrix1.Rows, matrix1.Columns);

      for (int theRow = 0; theRow < matrixResult.Rows; theRow++)
      {

        for (int theColumn = 0; theColumn < matrixResult.Columns; theColumn++)
        {
          matrixResult[theRow, theColumn] = matrix1[theRow, theColumn] + matrix2[theRow, theColumn];
        }

      }

      return matrixResult;
    }

    public static bool operator true(cpMatrix matrix1)
    {
      return AllOnes(matrix1);
    }

    public static bool operator false(cpMatrix matrix1)
    {
      return AllOnes(matrix1);
    }

    private static bool AllOnes(cpMatrix theMatrix)
    {

      foreach (int matrixItem in theMatrix.aMatrix)
      {

        if (matrixItem != 1)
        {
          return false;
        }

      }

      return true;
    }

    public override string ToString()
    {
      StringBuilder matrixVisualisation = new StringBuilder();

      for (int theRow = 0; theRow < Rows; theRow++)
      {

        for (int theColumn = 0; theColumn < Columns; theColumn++)
        {
          matrixVisualisation.AppendFormat("{0}\t", this.aMatrix[theRow, theColumn]);
        }

        matrixVisualisation.AppendLine();
      }

      return matrixVisualisation.ToString();
    }


  }

  class Program
  {
    static void Main()
    {
      cpMatrix aMatrix1 = new cpMatrix(3, 3);
      cpMatrix aMatrix2 = new cpMatrix(3, 3);

      aMatrix1[0, 0] = 1;
      aMatrix1[0, 1] = 2;
      aMatrix1[0, 2] = 0;
      aMatrix1[1, 0] = 0;
      aMatrix1[1, 1] = 1;
      aMatrix1[1, 2] = 2;
      aMatrix1[2, 0] = 1;
      aMatrix1[2, 1] = 0;
      aMatrix1[2, 2] = 2;

      aMatrix2[0, 0] = 1;
      aMatrix2[0, 1] = 1;
      aMatrix2[0, 2] = 1;
      aMatrix2[1, 0] = 1;
      aMatrix2[1, 1] = 1;
      aMatrix2[1, 2] = 1;
      aMatrix2[2, 0] = 1;
      aMatrix2[2, 1] = 1;
      aMatrix2[2, 2] = 1;

      Console.WriteLine("Matrix 1");
      Console.WriteLine(aMatrix1);

      if (aMatrix1)
      {
        Console.WriteLine("All ones");
      }
      else
      {
        Console.WriteLine("Not all ones");
      }

      Console.WriteLine();
      Console.WriteLine("Matrix 2");
      Console.WriteLine(aMatrix2);

      if (aMatrix2)
      {
        Console.WriteLine("All ones");
      }
      else
      {
        Console.WriteLine("Not all ones");
      }

      Console.WriteLine();
      Console.WriteLine("Matrix Sum");
      Console.WriteLine(aMatrix1 + aMatrix2);

      if (aMatrix1 + aMatrix2)
      {
        Console.WriteLine("All ones");
      }
      else
      {
        Console.WriteLine("Not all ones");
      }

      Console.ReadLine();
    }

  }

}
