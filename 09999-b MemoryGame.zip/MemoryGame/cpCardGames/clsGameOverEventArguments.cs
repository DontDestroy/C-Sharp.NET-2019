//***
// Action
//   - Implemenetation of cpGameOvrEventsArguments
//   - The number of clicks is given thru
// Created
//   - CopyPaste � 20240310 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240310 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.CardGames
{

  public class cpGameOverEventArguments : System.EventArgs
  {

    #region "Constructors / Destructors"

    public cpGameOverEventArguments(int lngClicks)
      //***
      // Action
      //   - Constructor that initialize the number of clicks
      // Called by
      //   - cpctlMemory.CardOver(System.Object, System.EventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mlngClicks = lngClicks;
    }
    // cpGameOverEventArguments()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mlngClicks;

    #endregion

    #region "Properties"

    public int Clicks
    {

      get
        //***
        // Action
        //   - Returns the number of clicks
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240310 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240310 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngClicks;
      }
      // int Clicks (Get)

    }
    // int Clicks

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpGameOverEventArguments

}
// CopyPaste.CardGames