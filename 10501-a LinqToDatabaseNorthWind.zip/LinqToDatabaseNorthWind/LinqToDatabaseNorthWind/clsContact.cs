﻿//***
// Action
//   - The definition of a cpContact
// Created
//   - CopyPaste – 20230329 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230329 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Common
{
  public class cpContact
  {

    #region "Constructors / Destructors"

    public cpContact(int intUniqueNumber, string strName)
    //***
    // Action
    //   - Creating an instance of a cpContact
    // Called by
    //   - cpProgram.BasicLinqCasting()
    // Calls
    //   - int ContactNumber (Set)
    //   - string Name (Set)
    // Created
    //   - CopyPaste – 20230329 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230329 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ContactNumber = intUniqueNumber;
      Name = strName;
    }
    // cpContact(int, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public int ContactNumber { get; set; }
    public string Name { get; set; }

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void PublishContacts(cpContact[] arrcpContacts)
    //***
    // Action
    //   - Loop thru a list of cpContacts
    // Called by
    //   - 
    // Calls
    //   - int ContactNumber (Get)
    //   - string Name (Get)
    // Created
    //   - CopyPaste – 20230329 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230329 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      foreach (cpContact theContact in arrcpContacts)
      {
        Console.WriteLine("Contact number: {0} - Contact: {1}", theContact.ContactNumber, theContact.Name);
      }
      // in arrcpContacts

    }
    // PublishContacts(cpContact[])

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpContact

}
// CopyPaste.Common
