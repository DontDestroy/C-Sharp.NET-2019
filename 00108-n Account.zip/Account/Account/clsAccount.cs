//***
// Action
//   - Definition of a cpAccount
//   - No instances can be made of this class (abstract)
// Created
//   - CopyPaste � 20240105 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240105 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;

namespace CopyPaste.Learning
{

	public abstract class cpAccount
	{

		#region "Constructors / Destructors"

		public cpAccount(long lngAccountNumber, decimal decAmount, DateTime dtmCreation, cpClient thecpOwner)
			//***
			// Action
			//   - Constructor with 4 arguments
			//   - An accountnumber, an amount, the creation date and the owner
			//   - Set the 4 properties
			// Called by
			//   - cpSavingAccount(long, decimal, DateTime, decimal, cpClient)
			//   - cpUsingAccount(long, decimal, DateTime, decimal, cpClient)
			// Calls
			//   - AccountNumber(long) (Set)
			//   - Amount(decimal) (Set)
			//   - Creation(DateTim) (Set)
			//   - Owner(cpClient) (Set)
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Amount = decAmount;
			AccountNumber = lngAccountNumber;
			Creation = dtmCreation;
			Owner = thecpOwner;
		}
		// cpAccount(long, decimal, DateTime, cpClient)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private cpClient mcpClient;
		private decimal mdecAmount;
		private DateTime mdtmCreation;
		private long mlngAccountNumber;

		#endregion

		#region "Properties"

		public long AccountNumber
		{
			
			get
				//***
				// Action Get
				//   - Returns mlngAccountNumber
				// Called by
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
	    {
				return mlngAccountNumber;
			}
			// long AccountNumber (Get)

			set
				//***
				// Action Set
				//   - Checks the account number on the old way of Belgian Bankaccounts
				//   - If check is correct
				//     - mlngAccountNumber becomes value
				//   - If not
				//     - Throw error message
				// Called by
				//   - cpAccount(long, decimal, DateTime, cpClient)
				// Calls
				//   - bool CheckAccount(long)
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
    	{

				if (CheckAccount(value))
				{
					mlngAccountNumber = value;
				}
				else
					//  Not (CheckAccount(value))
				{
					throw new ApplicationException("AccountNumber not correct");
        }
				// CheckAccount(value)

			}
			// AccountNumber(long) (Set)

		}
		// long AccountNumber

		public decimal Amount
		{
			
			get
				//***
				// Action Get
				//   - Returns mdecAmount
				// Called by
				//   - Add(decimal)
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mdecAmount;
			}
			// decimal Amount (Get)

			set
				//***
				// Action Set
				//   - mdecAmount becomes value
				// Called by
				//   - Add(decimal)
				//   - cpAccount(long, decimal, DateTime, cpClient)
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
					mdecAmount = value;
			}
			// Amount(decimal) (Set)

		}
		// decimal Amount

		public DateTime Creation
		{
			
			get
				//***
				// Action Get
				//   - Returns mdtmCreation
				// Called by
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mdtmCreation;
			}
			// DateTime Creation (Get)

			set
				//***
				// Action Set
				//   - If the date is after first of January 1900
				//     - mdtmCreation becomes value
				//   - If not
				//     - Throw error message
				// Called by
				//   - cpAccount(long, decimal, DateTime, cpClient)
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{

				if (value >= new DateTime(1900, 1, 1))
				{
					mdtmCreation = value;
				}
				else
					// value < new DateTime(1900, 1, 1)
				{
					throw new ApplicationException("Wrong date");
				}
				// value >= new DateTime(1900, 1, 1)

			}
			// Creation(DateTime) (Set)

		}
		// DateTime Creation

		public cpClient Owner
		{
			
			get
				//***
				// Action Get
				//   - Returns mcpClient
				// Called by
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mcpClient;
			}
			// cpClient Owner (Get)

			set
				//***
				// Action Set
				//   - mcpClient becomes value
				// Called by
				//   - cpAccount(long, decimal, DateTime, cpClient)
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				mcpClient = value;
			}
			// Owner(cpClient) (Set)

		}
		// cpClient Owner

		#endregion

		#region "Methods"

		#region "Overrides"

		public override string ToString()
			//***
			// Action
			//   - Return the accountnumber, the amount, the creation date and the owner
			// Called by
			//   - string cpSavingAccount.ToString()
			//   - string cpUsingAccount.ToString()
			//   - cpProgram.Main()
			// Calls
			//   - DateTime Creation() (Get)
			//   - decimal Amount() (Get)
			//   - long AccountNumber() (Get)
			//   - string cpClient.ToString() 
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
	  {
      string strInfo;

      strInfo = "Bank account: " + AccountNumber + ControlChars.CrLf + "Amount: " + Amount + ControlChars.CrLf + "Creation date: " + Creation;
      strInfo = strInfo + ControlChars.CrLf + Owner.ToString();

      return strInfo;
		}
		// string ToString()

		#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public void Add(decimal decValue)
			//***
			// Action
			//   - Add an amount to the account
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - Amount(decimal) (Set)
			//   - decimal Amount() (Get)
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Amount += decValue;
		}
		// Add(decimal)

		private bool CheckAccount(long lngOldBelgianBankAccount)
			//***
			// Action
			//   - Check a Belgian BankAccountNumber on correctness
			//   - A Belgian BankAcocunt has 12 digits
			//   - You take the first 10 (lngFirstTen)
			//   - You take the last 2 (lngLastTwo)
			//   - You divide lngFirstTen by 97 and you take the remainder of it (lngRemainder)
			//   - If lngRemainder equals lngLastTwo
			//     - Return true
			//   - If Not
			//'    - Return false
			// Called by
			//   - AccountNumber(long) (Set)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
  	{
      bool blnResult;
			long lngFirstTen;
			long lngLastTwo;
			long lngRemainder;
      
			lngFirstTen = lngOldBelgianBankAccount / 100;
			lngLastTwo = Convert.ToInt64(lngOldBelgianBankAccount % 100);
			lngRemainder = lngFirstTen % 97;

			if (lngRemainder == lngLastTwo)
			{
				blnResult = true;
			}
			else
				// lngRemainder <> lngLastTwo
			{
				blnResult = false;
			}
			// lngRemainder = lngLastTwo

   		return blnResult;
		}
		// bool CheckAccount(long)

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpAccount

}
// CopyPaste.Learning