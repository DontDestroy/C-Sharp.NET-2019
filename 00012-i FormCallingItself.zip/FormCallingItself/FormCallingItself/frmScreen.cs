//***
// Action
//   - Demo of a basic form that calls itself
// Created
//   - CopyPaste � 20260629 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260629 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmScreen: System.Windows.Forms.Form
  {
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    private Button cmdClick;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmScreen));
      this.cmdClick = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdClick
      // 
      this.cmdClick.Location = new System.Drawing.Point(72, 39);
      this.cmdClick.Name = "cmdClick";
      this.cmdClick.Size = new System.Drawing.Size(183, 74);
      this.cmdClick.TabIndex = 0;
      this.cmdClick.Text = "Click me";
      this.cmdClick.UseVisualStyleBackColor = true;
      this.cmdClick.Click += new System.EventHandler(this.cmdClick_Click);
      this.cmdClick.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cmdClick_MouseDown);
      this.cmdClick.MouseHover += new System.EventHandler(this.cmdClick_MouseHover);
      this.cmdClick.MouseUp += new System.Windows.Forms.MouseEventHandler(this.cmdClick_MouseUp);
      // 
      // frmScreen
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(13, 31);
      this.ClientSize = new System.Drawing.Size(768, 512);
      this.Controls.Add(this.cmdClick);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmScreen";
      this.Text = "Screen";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmScreen'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260629 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260629 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmScreen()
    //***
    // Action
    //   - Create instance of 'frmScreen'
    // Called by
    //   - cmdClick_Click(System.Object, System.EventArgs) Handles cmdClick.Click
    //   - Main()
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste � 20260629 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260629 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmScreen()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static int intCounter = 1;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdClick_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - If the button is clicked, create a new instance of 'frmScreen' and show it
    //     - Rule: intCounter is used to count the number of instances of 'frmScreen' created
    //   - If intCounter is smaller than 4
    //     - A new instance is created
    //   - If not
    //     - A nice message box is shown to the user
    // Called by
    //   - User action (Click the button down)
    // Calls
    //   - frmScreen()
    // Created
    //   - CopyPaste � 20260629 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260629 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (intCounter < 4)
      {
        intCounter += 1;
        frmScreen frmNewScreen = new frmScreen();
        frmNewScreen.Show();
      }
      else
      // intCounter >= 4
      {
        MessageBox.Show("C# Programming in easy steps");
      }
      // intCounter < 4

    }
    // cmdClick_Click(System.Object, System.EventArgs) Handles cmdClick.Click

    private void cmdClick_MouseDown(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change the background color of the button when mouse clicked into Lime
    // Called by
    //   - User action (Click the button down)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260629 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260629 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cmdClick.BackColor = Color.Lime;
    }
    // cmdClick_MouseDown(System.Object, System.EventArgs) Handles cmdClick.MouseDown

    private void cmdClick_MouseHover(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change the background color of the button when mouse hovers over it into Fuschia
    // Called by
    //   - User action (Hover over button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260629 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260629 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cmdClick.BackColor = Color.Fuchsia;
    }
    // cmdClick_MouseHover(System.Object, System.EventArgs) Handles cmdClick.MouseHover

    private void cmdClick_MouseUp(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change the background color of the button when mouse up into Aqua
    // Called by
    //   - User action (Click the button up)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260629 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260629 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cmdClick.BackColor = Color.Aqua;
    }
    // cmdClick_MouseUp(System.Object, System.EventArgs) Handles cmdClick.MouseUp

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmScreen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmScreen()
    // Created
    //   - CopyPaste � 20260629 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260629 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmScreen());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmScreen

}
// CopyPaste.Learning