//***
// Action
//   - Testroutine for cpPerson and cpNameFormatIncorrectException
// Created
//   - CopyPaste � 20230821 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230821 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPerson : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    internal System.Windows.Forms.Button cmdAddPerson;
    internal System.Windows.Forms.TextBox txtName;
    internal System.Windows.Forms.ListBox lstPerson;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPerson));
      this.cmdAddPerson = new System.Windows.Forms.Button();
      this.txtName = new System.Windows.Forms.TextBox();
      this.lstPerson = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // cmdAddPerson
      // 
      this.cmdAddPerson.Location = new System.Drawing.Point(16, 160);
      this.cmdAddPerson.Name = "cmdAddPerson";
      this.cmdAddPerson.Size = new System.Drawing.Size(120, 23);
      this.cmdAddPerson.TabIndex = 5;
      this.cmdAddPerson.Text = "Add";
      this.cmdAddPerson.Click += new System.EventHandler(this.cmdAddPerson_Click);
      // 
      // txtName
      // 
      this.txtName.Location = new System.Drawing.Point(16, 128);
      this.txtName.Name = "txtName";
      this.txtName.Size = new System.Drawing.Size(120, 20);
      this.txtName.TabIndex = 4;
      this.txtName.Text = "";
      // 
      // lstPerson
      // 
      this.lstPerson.Location = new System.Drawing.Point(16, 16);
      this.lstPerson.Name = "lstPerson";
      this.lstPerson.Size = new System.Drawing.Size(120, 95);
      this.lstPerson.Sorted = true;
      this.lstPerson.TabIndex = 3;
      // 
      // frmPerson
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(152, 198);
      this.Controls.Add(this.cmdAddPerson);
      this.Controls.Add(this.txtName);
      this.Controls.Add(this.lstPerson);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPerson";
      this.Text = "Person List";
      this.Load += new System.EventHandler(this.frmPerson_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPerson'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230821 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230821 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPerson()
      //***
      // Action
      //   - Create instance of 'frmPerson'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230821 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230821 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPerson()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAddPerson_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to add a cpPerson to a list (the list is sorted)
      //   - On any error of type cpNameFormatIncorrectException
      //     - Is there an inner exception
      //       - Show the inner error message
      //     - If not
      //       - Show the message and the inner error message
      //   - On any other error 
      //     - Show the error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpPerson(string)
      // Created
      //   - CopyPaste � 20230821 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230821 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    
      try
      {
        lstPerson.Items.Add(new cpPerson(txtName.Text));
      }
      catch (cpNameFormatIncorrectException theNameException)
      {

        if (theNameException.InnerException == null)
        {
          MessageBox.Show(theNameException.Message);
        }
        else
          // theNameException.InnerException <> null
        {
          MessageBox.Show(theNameException.Message + Environment.NewLine + theNameException.InnerException.Message);
        }
        // theNameException.InnerException == null

      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }

      txtName.Text = "";
    }
    // cmdAddPerson_Click(System.Object, System.EventArgs) Handles cmdAddPerson.Click

    private void frmPerson_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Starting the form
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230821 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230821 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmPerson_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPerson
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmPerson()
      // Created
      //   - CopyPaste � 20230821 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230821 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPerson());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmPerson

}
// CopyPaste.Learning