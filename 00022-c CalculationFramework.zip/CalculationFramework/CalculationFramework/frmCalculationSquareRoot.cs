//***
// Action
//   - Demo of one of the methods of System.Math
// Created
//   - CopyPaste � 20240417 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240417 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSquareRoot: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdSquareRoot;
    internal System.Windows.Forms.TextBox txtResult;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSquareRoot));
      this.cmdSquareRoot = new System.Windows.Forms.Button();
      this.txtResult = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdSquareRoot
      // 
      this.cmdSquareRoot.Location = new System.Drawing.Point(98, 24);
      this.cmdSquareRoot.Name = "cmdSquareRoot";
      this.cmdSquareRoot.Size = new System.Drawing.Size(96, 32);
      this.cmdSquareRoot.TabIndex = 4;
      this.cmdSquareRoot.Text = "&Square root";
      this.cmdSquareRoot.Click += new System.EventHandler(this.cmdSquareRoot_Click);
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(82, 80);
      this.txtResult.Name = "txtResult";
      this.txtResult.Size = new System.Drawing.Size(128, 20);
      this.txtResult.TabIndex = 3;
      this.txtResult.Text = "";
      // 
      // frmSquareRoot
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdSquareRoot);
      this.Controls.Add(this.txtResult);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSquareRoot";
      this.Text = "Square root";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSquareRoot'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240417 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240417 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSquareRoot()
      //***
      // Action
      //   - Create instance of 'frmSquareRoot'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240417 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240417 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSquareRoot()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdSquareRoot_Click(System.Object theSender, System.EventArgs theEventArguments)
    {
      double dblWork;

      try
      {
        dblWork = Math.Sqrt(Convert.ToDouble(txtResult.Text));
        txtResult.Text = dblWork.ToString();
      }
      catch
      {
        txtResult.Text = "Error";
      }

    }
    // cmdSquareRoot_Click(System.Object, System.EventArgs) Handles cmdSquareRoot.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSquareRoot
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSquareRoot()
      // Created
      //   - CopyPaste � 20240417 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240417 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSquareRoot());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSquareRoot

}
// CopyPaste.Learning