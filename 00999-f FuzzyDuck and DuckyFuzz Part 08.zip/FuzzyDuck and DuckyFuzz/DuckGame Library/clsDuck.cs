﻿//***
// Action
//   - Implementation of a cpDuck
//     - All ducks swim
//     - Display (how do I look like) is an abstract method
//       - All class that inherit must implement the Display method
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
//     - All ducks can have an implementation of flying making some noise and walking
//       - This is done thru delegates and events
//       - Meaning, that the functionality is outside the class of cpDuck
// Created
//   - CopyPaste – 20240726 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240726 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Animal.Library;
using System.Diagnostics;

namespace CopyPaste.Game.Duck.Library
{

	public abstract class cpDuck
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpDuck
		/// </summary>
		public cpDuck()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - cpDecoyDuck()
		//   - cpMallardDuck()
		//   - cpPlasticRubberDuck()
		//   - cpRedHeadDuck()
		//   - cpWoodDuck()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240726 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240726 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		public event cpDelegateFly PerformFly;
		// Fly()
		public event cpDelegateMakeNoise PerformMakeNoise;
		// MakeNoise()
		public event cpDelegateWalk PerformWalk;
		// Walk()

		private cpiFly cpHowToFly;
		private cpiMakeNoise cpHowToMakeNoise;
		private cpiWalk cpHowToWalk;

		#endregion

		#region "Properties"

		public cpiFly HowToFly
		{

			get
			//***
			// Action Get
			//   - Return cpHowToFly
			// Called by
			//   - cpDuck.HowToFly(cpiFly) (Set)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20240726 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240726 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return cpHowToFly;
			}
			// cpiFly HowToFly (Get)

			set
			//***
			// Action Set
			//   - Try to remove the previous behaviour from the event
			//   - cpHowToFly becomes value
			//   - Add the new functionality to the event
			// Called by
			//   - cpDecoyDuck()
			//   - cpMallardDuck()
			//   - cpPlasticRubberDuck()
			//   - cpRedHeadDuck()
			//   - cpWoodDuck()
			// Calls
			//   - cpiFly HowToFly (Get)
			//   - cpiFly.Fly()
			// Created
			//   - CopyPaste – 20240726 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240726 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{

				if (PerformFly == null)
				{
				}
				else
				// PerformFly <> null
				{
					PerformFly -= new cpDelegateFly(HowToFly.Fly);
					// Don't do the code above, if you want to add behaviour to the event instead of replacing the behaviour
				}
				// PerformFly = null

				cpHowToFly = value;
				PerformFly += new cpDelegateFly(HowToFly.Fly);
			}
			// HowToFly(cpiFly) (Set)

		}
		// cpiFly HowToFly

		public cpiMakeNoise HowToMakeNoise
		{

			get
			//***
			// Action Get
			//   - Return cpHowToMakeNoise
			// Called by
			//   - cpDuck.HowToMakeNoise(cpiMakeNoise) (Set)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20240726 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240726 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return cpHowToMakeNoise;
			}
			// cpiMakeNoise HowToMakeNoise (Get)

			set
			//***
			// Action Set
			//   - Try to remove the previous behaviour from the event
			//   - cpHowToMakeNoise becomes value
			//   - Add the new functionality to the event
			// Called by
			//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
			//   - cpDecoyDuck()
			//   - cpMallardDuck()
			//   - cpPlasticRubberDuck()
			//   - cpRedHeadDuck()
			//   - cpWoodDuck()
			// Calls
			//   - cpiMakeNoise HowToMakeNoise (Get)
			//   - cpiMakeNoise.MakeNoise()
			// Created
			//   - CopyPaste – 20240726 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240726 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{

				if (PerformMakeNoise == null)
				{
				}
				else
				// PerformMakeNoise <> null
				{
					PerformMakeNoise -= new cpDelegateMakeNoise(HowToMakeNoise.MakeNoise);
					// Don't do the code above, if you want to add behaviour to the event instead of replacing the behaviour
				}
				// PerformMakeNoise = null

				cpHowToMakeNoise = value;
				PerformMakeNoise += new cpDelegateMakeNoise(HowToMakeNoise.MakeNoise);
			}
			// HowToMakeNoise(cpiMakeNoise) (Set)

		}
		// cpiMakeNoise HowToMakeNoise

		public cpiWalk HowToWalk
		{

			get
			//***
			// Action Get
			//   - Return cpHowToWalk
			// Called by
			//   - cpDuck.HowToWalk(cpiWalk) (Set)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20240726 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240726 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return cpHowToWalk;
			}
			// cpiWalk HowToWalk (Get)

			set
			//***
			// Action Set
			//   - Try to remove the previous behaviour from the event
			//   - cpHowToMakeNoise becomes value
			//   - Add the new functionality to the event
			// Called by
			//   - cpDecoyDuck()
			//   - cpMallardDuck()
			//   - cpPlasticRubberDuck()
			//   - cpRedHeadDuck()
			//   - cpWoodDuck()
			// Calls
			//   - cpiWalk cpDuck.HowToWalk (Get)
			//   - cpiWalk.Walk()
			// Created
			//   - CopyPaste – 20240726 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240726 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{

				if (PerformWalk == null)
				{
				}
				else
				// PerformWalk <> null
				{
					PerformWalk -= new cpDelegateWalk(HowToWalk.Walk);
					// Don't do the code above, if you want to add behaviour to the event instead of replacing the behaviour
				}
				// PerformWalk = null

				cpHowToWalk = value;
				PerformWalk += new cpDelegateWalk(HowToWalk.Walk);
			}
			// HowToWalk(cpiWalk) (Set)

		}
		// cpiWalk HowToWalk

		#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		#region "Event"

		public delegate void cpDelegateFly();
		public delegate void cpDelegateMakeNoise();
		public delegate void cpDelegateWalk();

		#endregion

		#region "Sub / Function"

		/// <summary>
		/// Clean the existing behaviour from a cpDuck
		/// </summary>
		public void CleanBehaviour()
		//***
		// Action
		//   - If there is a behaviour for flying
		//     - Remove it
		//   - If there is a behaviour for making a sound
		//     - Remove it
		//   - If there is a behaviour for walking
		//     - Remove it
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240726 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240726 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformFly == null)
			{
			}
			else
			// PerformFly <> null
			{
				PerformFly -= new cpDelegateFly(HowToFly.Fly);
			}
			// PerformFly = null

			if (PerformMakeNoise == null)
			{
			}
			else
			// PerformMakeNoise <> null
			{
				PerformMakeNoise -= new cpDelegateMakeNoise(HowToMakeNoise.MakeNoise);
			}
			// PerformMakeNoise = null

			if (PerformWalk == null)
			{
			}
			else
			// PerformWalk <> null
			{
				PerformWalk -= new cpDelegateWalk(HowToWalk.Walk);
			}
			// PerformWalk = null

		}

		/// <summary>
		/// The visualization (displaying) of a cpDuck
		/// </summary>
		public abstract void Display();
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()

		/// <summary>
		/// Define how the cpDuck moves in the air
		/// </summary>
		public void Fly()
		//***
		// Action
		//   - If PerformFly is null
		//     - Do nothing
		//   - If Not
		//     - Execute PerformFly
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - PerformFly()
		// Created
		//   - CopyPaste – 20240726 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240726 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformFly == null)
			{
			}
			else
			// PerformFly <> null
			{
				PerformFly();
			}
			// PerformFly = null

		}
		// Fly()

		/// <summary>
		/// Define how the cpDuck makes some noise
		/// </summary>
		public void MakeNoise()
		//***
		// Action
		//   - If PerformMakeNoise is null
		//     - Do nothing
		//   - If Not
		//     - Execute PerformMakeNoise
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - PerformMakeNoise()
		// Created
		//   - CopyPaste – 20240726 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240726 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformMakeNoise == null)
			{
			}
			else
			// PerformMakeNoise <> null
			{
				PerformMakeNoise();
			}
			// PerformMakeNoise = null

		}
		// PerformMakeNoise()

		/// <summary>
		/// How is a cpDuck moving on water
		/// </summary>
		public virtual void Swim()
		//***
		// Action
		//   - Define how the cpDuck moves in water
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240726 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240726 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("cpDuck is moving around in water");
		}
		// Swim()

		/// <summary>
		/// Define how the cpDuck makes some noise
		/// </summary>
		public void Walk()
		//***
		// Action
		//   - If PerformWalk is null
		//     - Do nothing
		//   - If Not
		//     - Execute PerformWalk
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - PerformWalk()
		// Created
		//   - CopyPaste – 20240726 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240726 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformWalk == null)
			{
			}
			else
			// PerformWalk <> null
			{
				PerformWalk();
			}
			// PerformWalk = null

		}
		// PerformWalk()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpDuck

}
// CopyPaste.Game.Duck.Library