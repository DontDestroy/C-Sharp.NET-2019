//***
// Action
//   - Testroutine for cpSourceFile
// Created
//   - CopyPaste � 20240124 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240124 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  /// <summary>
  /// Form where class cpSourceFile is tested
  /// </summary>
  public class frmCodeAnalysis: System.Windows.Forms.Form
  {

		#region Windows Form Designer generated code

		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdDisplay;
    internal System.Windows.Forms.OpenFileDialog dlgOpenSourceFile;
    internal System.Windows.Forms.Button cmdBrowse;
    internal System.Windows.Forms.DataGrid dgrFiles;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCodeAnalysis));
      this.cmdDisplay = new System.Windows.Forms.Button();
      this.dlgOpenSourceFile = new System.Windows.Forms.OpenFileDialog();
      this.cmdBrowse = new System.Windows.Forms.Button();
      this.dgrFiles = new System.Windows.Forms.DataGrid();
      ((System.ComponentModel.ISupportInitialize)(this.dgrFiles)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdDisplay
      // 
      this.cmdDisplay.Location = new System.Drawing.Point(208, 232);
      this.cmdDisplay.Name = "cmdDisplay";
      this.cmdDisplay.TabIndex = 5;
      this.cmdDisplay.Text = "Display";
      this.cmdDisplay.Click += new System.EventHandler(this.cmdDisplay_Click);
      // 
      // cmdBrowse
      // 
      this.cmdBrowse.Location = new System.Drawing.Point(8, 232);
      this.cmdBrowse.Name = "cmdBrowse";
      this.cmdBrowse.TabIndex = 4;
      this.cmdBrowse.Text = "Browse";
      this.cmdBrowse.Click += new System.EventHandler(this.cmdBrowse_Click);
      // 
      // dgrFiles
      // 
      this.dgrFiles.DataMember = "";
      this.dgrFiles.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrFiles.Location = new System.Drawing.Point(8, 8);
      this.dgrFiles.Name = "dgrFiles";
      this.dgrFiles.Size = new System.Drawing.Size(280, 216);
      this.dgrFiles.TabIndex = 3;
      // 
      // frmCodeAnalysis
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.Add(this.cmdBrowse);
      this.Controls.Add(this.dgrFiles);
      this.Controls.Add(this.cmdDisplay);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCodeAnalysis";
      this.Text = "Code Analysis";
      this.Load += new System.EventHandler(this.frmCodeAnalysis_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrFiles)).EndInit();
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

    /// <summary>
    /// Code executed when form is not used anymore
    /// </summary>
    /// <param name="disposing">To dispose all components in the form, set true</param>
    protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmCodeAnalysis'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240124 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240124 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
    {

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

    /// <summary>
    /// Constructor of frmCodeAnalysis
    /// </summary>
		public frmCodeAnalysis()
			//***
			// Action
			//   - Create instance of 'frmCodeAnalysis'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240124 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240124 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmCodeAnalysis()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

    private int mlngFiles = 0;
    private const int mlngMaxFiles = 10;
    private cpSourceFile[] marrcpSourceFile = new cpSourceFile[mlngMaxFiles]; 

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"
    
    private void cmdBrowse_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to do something
      //     - Show a file open dialog
      //     - If you click OK (or corresponding button)
      //       - Create a new instance of the cpSourceFile
      //       - Add it to the arary of sourcefiles
      //       - Add 1 to the number of files
      //     - If the number of files gets to big
      //       - Subtract 1 of the number of files
      //     - Refresh the datagrid
      //   - When it fails
      //     - Show an error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpSourceFile(string)
      // Created
      //   - CopyPaste � 20240124 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240124 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        DialogResult dlgResult;

        dlgOpenSourceFile.Filter = "C# Files (*.cs)|*.cs";
        dlgResult = dlgOpenSourceFile.ShowDialog();

        if (dlgResult == DialogResult.OK)
        {
          cpSourceFile thecpFile = new cpSourceFile(dlgOpenSourceFile.FileName);

          marrcpSourceFile[mlngFiles] = thecpFile;
          mlngFiles++;
          // marrcpSourceFile[mlngFiles++] = thecpFile;

          if (mlngFiles == marrcpSourceFile.Length)
          {
            mlngFiles = marrcpSourceFile.Length - 1;
          }
            // mlngFiles <> marrcpSourceFile.Length
          else
          {
          }
          // mlngFiles = marrcpSourceFile.Length

        }
        else
          // dlgResult <> DialogResult.OK
        {
        }
        // dlgResult = DialogResult.OK

        dgrFiles.Refresh();
      }
      catch (System.Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // cmdBrowse_Click(System.Object, System.EventArgs) Handles cmdBrowse.Click
    
    private void cmdDisplay_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Determine the row where you have clicked
      //   - Is that smaller than the number of files
      //     - Define a cpSourceFile
      //     - Loop thru all the classes of that file
      //       - Generate a message
      //     - Show the message
      //   - If Not
      //     - Show an error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - int cpSourceFile.ClassCount (Get)
      //   - string cpSourceFile.FileName (Get)
      //   - string cpSourceFile.GetClass(int)
      // Created
      //   - CopyPaste � 20240124 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240124 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngRow = dgrFiles.CurrentCell.RowNumber;

      if (lngRow < mlngFiles)
      {
        int lngIndex;
        string strMessage = "";
        cpSourceFile thecpFile = marrcpSourceFile[lngRow];
        
        for (lngIndex = 0; lngIndex <= thecpFile.ClassCount - 1; lngIndex++)
        {
          strMessage += thecpFile.GetClass(lngIndex) + ControlChars.CrLf;
        }
        // lngIndex = thecpFile.ClassCount
        
        MessageBox.Show(strMessage, "Classes in " + thecpFile.FileName);
      }
      else
        // lngRow >= mlngFiles
      {
        MessageBox.Show("Please select a row with data.");
      }
      // lngRow < mlngFiles
    
    }
    // cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click

    
    private void frmCodeAnalysis_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The datagrid data source is linked to the array 'marrcpSourceFile'
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240124 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240124 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dgrFiles.DataSource = marrcpSourceFile;
    }
    // frmCodeAnalysis_Load(System.Object, System.EventArgs) Handles frmCodeAnalysis.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmCodeAnalysis
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmDefault()
			// Created
			//   - CopyPaste � 20240124 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240124 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmCodeAnalysis());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmCodeAnalysis

}
// CopyPaste.Learning