//'***
//' Action
//'   - Testroutine for cpCircle, cpCylinder, cpiShape and cpPoint
//'   - Showing the way polymorphisme works
//' Created
//'   - CopyPaste � 20230818 � VVDW
//' Changed
//'   - CopyPaste � yyyymmdd � VVDW � What changed
//' Tested
//'   - CopyPaste � 20230818 � VVDW
//' Proposal (To Do)
//'   -
//'***

using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThread]
    static void Main()
      //***
      // Action
      //   - Create an array of 6 cpShapes
      //   - Define a cpCircle
      //   - Define a cpCylinder
      //   - Define a cpPoint
      //   - Define a cpShape
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpCircle(int, int, double)
      //   - cpCylinder(int, int, double, double)
      //   - cpiShape()
      //   - cpPoint(int, int)
      //   - double cpiShape.Area()
      //   - double cpiShape.Volume()
      //   - string cpCircle.Name (Get)
      //   - string cpCircle.ToString()
      //   - string cpCylinder.Name (Get)
      //   - string cpCylinder.ToString()
      //   - string cpiShape.Name (Get)
      //   - string cpiShape.ToString()
      //   - string cpPoint.Name (Get)
      //   - string cpPoint.ToString()
      // Created
      //   - CopyPaste � 20230818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpiShape[] arrShape = new cpiShape[6];
      string strOutput = "";

      cpCircle thecpCircle = new cpCircle(22, 8, 3.5);
      cpCylinder thecpCylinder = new cpCylinder(10, 10, 3.3, 10);
      cpPoint thecpPoint = new cpPoint(7, 11);

      cpCircle thecpCircleWithPoint = new cpCircle(thecpPoint, 5);
      cpCylinder thecpCylinderWithPoint = new cpCylinder(thecpPoint, 5, 10);
      cpCylinder thecpCylinderWithCircle = new cpCylinder(thecpCircle, 10);

      arrShape[0] = thecpPoint;
      arrShape[1] = thecpCircle;
      arrShape[2] = thecpCylinder;
      arrShape[3] = thecpCircleWithPoint;
      arrShape[4] = thecpCylinderWithPoint;
      arrShape[5] = thecpCylinderWithCircle;

      strOutput = thecpPoint.Name + ": " + thecpPoint.ToString() + Environment.NewLine +
        thecpCircle.Name + ": " + thecpCircle.ToString() + Environment.NewLine +
        thecpCylinder.Name + ": " + thecpCylinder.ToString();

      foreach (cpiShape thecpShape in arrShape)
      {
        strOutput += Environment.NewLine + Environment.NewLine +
          thecpShape.Name + ": " + thecpShape.ToString() + Environment.NewLine +
          "Area = " + String.Format("{0:F}", thecpShape.Area()) + Environment.NewLine +
          "Volume = " + String.Format("{0:F}", thecpShape.Volume());
      }
      // in arrShape

      MessageBox.Show(strOutput, "Demonstrating Polymorphism");
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning