//***
// Action
//   - Loop thru some text, character by character
// Created
//   - CopyPaste � 20220112 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220112 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Declaration
{

  class cpDeclaration
	{

    static void Main()
    //***
    // Action
    //   - Ask for a text
    //   - Loop thru letters to that text
    //     - Show info at the console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - char String.Chars(int)
    //   - int String.Length()
    //   - string System.Console.ReadLine()
    //   - System.Console.Write(string)
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220112 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220112 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      int intCounter;
      string strName;
      
      Console.Write("Type your name: ");
      strName = Console.ReadLine();
      
      for (intCounter = 0; intCounter < strName.Length; intCounter++)
      {
        char chrLetter;

        chrLetter = strName[intCounter];
        Console.WriteLine(intCounter + 1 + ":" + chrLetter);
      }
      // intCounter = Name.Length

      Console.ReadLine();
    }
    // Main()

  }
  // cpDeclaration

}
// Declaration