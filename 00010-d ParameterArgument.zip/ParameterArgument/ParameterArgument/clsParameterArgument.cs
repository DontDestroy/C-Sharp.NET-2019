//***
// Action
//   - Example of difference calling procedure with parameters by value or by reference
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace ParameterArgument
{

  class cpParameterArgument
	{

    static void Main()
    //***
    // Action
    //   - Initialise variable
    //   - Call procedure by value
    //   - Show variable at console screen and messagebox
    //   - Call procedure by reference
    //   - Show variable at console screen and messagebox
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - DialogResult System.Windows.Forms.MessageBox.Show(String) 
    //   - GetTextByVal(string)
    //   - GetTextByRef(�string)
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strText01;

      strText01 = "Text One";
      MessageBox.Show("Start Value: " + strText01);
      Console.WriteLine("Start Value: " + strText01);
      GetTextByVal(strText01);
      MessageBox.Show("After ByVal: " + strText01);
      Console.WriteLine("After ByVal: " + strText01);
      GetTextByRef(ref strText01);
      MessageBox.Show("After ByRef: " + strText01);
      Console.WriteLine("After ByRef: " + strText01);
      Console.ReadLine();
    }
    // Main()

    static void GetTextByVal(string strText)
    //***
    // Action
    //   - Change parameter value (no change in caller routine)
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      strText = "Text Two";
    }
    // GetTextByVal(string)

    static void GetTextByRef(ref string strText)
    //***
    // Action
    //   - Change parameter value (change in caller routine)
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      strText = "Text Two";
    }
    // GetTextByRef(�string)

  }
  // cpParameterArgument

}
// ParameterArgument