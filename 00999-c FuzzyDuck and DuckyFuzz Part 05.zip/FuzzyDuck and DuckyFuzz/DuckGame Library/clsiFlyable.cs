﻿//***
// Action
//   - Interface for the method Fly
// Created
//   - CopyPaste – 20240718 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240718 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Game.Duck.Library
{

	internal interface cpiFlyable
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing can move in the air
		/// </summary>
		public void Fly();
		// Fly()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpiFlyable

}
// CopyPaste.Game.Duck.Library