//***
// Action
//   - Get a certain directory
//   - Show all the subdirectories and all the files
// Created
//   - CopyPaste � 20240722 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240722 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Fill an array with directories
      //   - Fill an array with files
      //   - Loop thru the array of files
      //   - Loop thru the array of directories
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240722 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string[] arrstrDirectory = Directory.GetDirectories("C:\\");
      string[] arrstrFile = Directory.GetFiles("C:\\");

      Console.WriteLine("Root Files");
      Console.WriteLine("----------");

      foreach (string strFilename in arrstrFile)
      {
        Console.WriteLine(strFilename);
      }
      // in arrstrFile

      Console.WriteLine();
      Console.WriteLine("Root Directories");
      Console.WriteLine("----------------");

      foreach (string strDirectoryName in arrstrDirectory)
      {
        Console.WriteLine(strDirectoryName);
      }
      // in arrstrDirectory

      Console.WriteLine();
      Console.WriteLine("Press Enter to Continue ...");
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning