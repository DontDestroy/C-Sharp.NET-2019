//***
// Action
//   - Testroutine of an instance of cpCircle
// Created
//   - CopyPaste � 20231230 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231230 � VVDW
// Proposal (To Do)
//   - The example contains an error in behaviour
//   - Try to find a solution
//***

using CopyPaste.Learning.Math;
using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace Circle
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Create a new instance of a cpCircle
    //   - Get some properties
    //   - Set some properties
    //   - Use of ToString()
    //   - Show the diameter
    //   - Show the circumference
    //   - Show the area
    //   - The wrong behaviour is put in comments
    //     - Study it
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpCircle()
    //   - cpCircle(int, int, double)
    //   - cpCircle.Radius(double) (Set)
    //   - cpCircle.X(int) (Set)
    //   - cpCircle.Y(int) (Set)
    //   - double cpCircle.Area()
    //   - double cpCircle.Circumference()
    //   - double cpCircle.Diameter()
    //   - double cpCircle.Radius() (Get)
    //   - int cpPoint.X() (Get)
    //   - int cpPoint.Y() (Get)
    //   - string cpCircle.ToString()
    // Created
    //   - CopyPaste � 20231230 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20231230 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - At the bottom there is a flow that does not work correctly
    //   - Try to solve it (after you understand what is going wrong)
    //   - In later examples, this is corrected
    //***
    {
      string strOutput;
      cpCircle thecpCircle;

      thecpCircle = new cpCircle();

      strOutput = thecpCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      thecpCircle = new cpCircle(37, 43, 2.5);

      strOutput = thecpCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      thecpCircle.X = 2;
      thecpCircle.Y = 2;
      thecpCircle.Radius = 4.25;

      strOutput = "The new location and radius of circle are " + Environment.NewLine + thecpCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Diameter is " + String.Format("{0:F}", thecpCircle.Diameter());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Circumference is " + String.Format("{0:F}", thecpCircle.Circumference());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Area is " + String.Format("{0:F}", thecpCircle.Area());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      /*
        // Not happy flow - Why are the outputs different below
        MessageBox.Show("Some wrong results", "Demonstrating Class cpCircle");

        cpCircle thecpFirstCircleThatGoesWrong;
        cpCircle thecpSecondCircleThatGoesWrong;

        thecpFirstCircleThatGoesWrong = new cpCircle(); // X = 0; Y = 0; Radius = 0;
        thecpSecondCircleThatGoesWrong = new cpCircle(); // X = 0; Y = 0; Radius = 0;

        thecpFirstCircleThatGoesWrong.X = 1; // X = 1; Y = 0; Radius = 0; You change the coordinates of the circle
        thecpSecondCircleThatGoesWrong.Center.X = 1; // Center.X = 1; Center.Y = 0; Radius = 0; You change the coordinates of the center of the circle

        strOutput = thecpFirstCircleThatGoesWrong.ToString();
        MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

        strOutput = "X coordinate is " + thecpFirstCircleThatGoesWrong.Center.X + ControlChars.CrLf +
          "Y coordinate is " + thecpFirstCircleThatGoesWrong.Center.Y + Environment.NewLine +
          "Radius is " + thecpFirstCircleThatGoesWrong.Radius;
        MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

        strOutput = thecpSecondCircleThatGoesWrong.ToString();
        MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

        strOutput = "X coordinate is " + thecpSecondCircleThatGoesWrong.Center.X + ControlChars.CrLf +
          "Y coordinate is " + thecpSecondCircleThatGoesWrong.Center.Y + Environment.NewLine +
          "Radius is " + thecpSecondCircleThatGoesWrong.Radius;
        MessageBox.Show(strOutput, "Demonstrating Class cpCircle");
      */
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// Circle