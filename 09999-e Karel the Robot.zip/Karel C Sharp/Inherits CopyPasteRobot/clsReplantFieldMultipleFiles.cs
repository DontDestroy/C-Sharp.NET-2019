﻿//***
// Action
//   - A definition of a ReplantFieldMultipleFiles
// Created
//   - CopyPaste – 20251016 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251016 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpReplantFieldMultipleFiles : cpReplantField
	{

		#region "Constructors / Destructors"

		public cpReplantFieldMultipleFiles(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpReplantFieldMultipleFiles starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpProgram.ReplantFieldMultipleFiles()
    // Calls
    //   - cpReplantField(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251016 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251016 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpReplantFieldMultipleFiles(int, int, Directions.Direction, int, Color) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ReplantTheField()
    //***
    // Action
    //   - Move one forward
    //   - Replant 2 rows
    //   - Set the robot good for the next replant of 2 rows
    //   - Repeat this
    //   - Replant the last 2 rows
    //   - Move one forward
    // Called by
    //   - cpProgram.ReplantFieldMultipleFiles()
    // Calls
    //   - cpReplanter.PositionForNextReplant()
    //   - cpReplanter.ReplantTwoRows();
    // Created
    //   - CopyPaste – 20251016 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251016 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      move();
      ReplantTwoRows();
      PositionForNextReplant();
      ReplantTwoRows();
      PositionForNextReplant();
      ReplantTwoRows();
      move();
    }
    // ReplantTheField()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpReplantFieldMultipleFiles

}
// cpKarelTheRobot