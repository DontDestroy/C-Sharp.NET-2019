//***
// Action
//   - Definition of a cpPoint
// Created
//   - CopyPaste � 20230818 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230818 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpPoint : cpShape
  {

    #region "Constructors / Destructors"
    
    public cpPoint()
      //***
      // Action
      //   - Constructor of a cpPoint
      // Called by
      //   - cpCircle()
      // Calls
      //   - cpShape()
      //   - X(int) (Set)
      //   - Y(int) (Set)
      // Created
      //   - CopyPaste � 20230818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      X = 0;
      Y = 0;
    }
    // cpPoint()

    public cpPoint(int lngX, int lngY)
      //***
      // Action
      //   - Constructor of a cpPoint
      // Called by
      //   - cpCircle(int, int, double)
      //   - cpProgram.Main()
      // Calls
      //   - cpShape()
      //   - X(int) (Set)
      //   - Y(int) (Set)
      // Created
      //   - CopyPaste � 20230818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      X = lngX;
      Y = lngY;
    }
    // cpPoint(int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mlngX;
    private int mlngY;

    #endregion

    #region "Properties"

    public override string Name
    {

      get
        //***
        // Action Get
        //   - Return text "cpPoint"
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return "cpPoint";
      }
      // string Name (Get)

    }
    // string Name

    public int X
    {

      get
        //***
        // Action Get
        //   - Return mlngX
        // Called by
        //   - cpCircle.Center(cpPoint) (Set)
        //   - cpCylinder.Base(cpCircle) (Set)
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngX;
      }
      // int X (Get)

      set
        //***
        // Action Set
        //   - mlngX becomes value
        // Called by
        //   - cpCircle.Center(cpPoint) (Set)
        //   - cpCylinder.Base(cpCircle) (Set)
        //   - cpPoint()
        //   - cpPoint(int, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngX = value;
      }
      // X(int) (Set)

    }
    // int X

    public int Y
    {

      get
        //***
        // Action Get
        //   - Return mlngY
        // Called by
        //   - cpCircle.Center(cpPoint) (Set)
        //   - cpCylinder.Base(cpCircle) (Set)
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngY;
      }
      // int Y (Get)

      set
        //***
        // Action Set
        //   - mlngY becomes lngValue
        // Called by
        //   - cpCircle.Center(cpPoint) (Set)
        //   - cpCylinder.Base(cpCircle) (Set)
        //   - cpPoint()
        //   - cpPoint(int, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngY = value;
      }
      // Y(int) (Set)

    }
    // int Y

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Return the X and Y coordinate in the format [X, Y]
      // Called by
      //   - cpProgram.Main()
      //   - string cpCircle.ToString()
      // Calls
      //   - int X (Get)
      //   - int Y (Get)
      // Created
      //   - CopyPaste � 20230818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "[" + X + ", " + Y + "]";
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPoint

}
// CopyPaste.Learning