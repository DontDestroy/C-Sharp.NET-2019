//***
// Action
//   - Implementation of cpDivision
// Created
//   - CopyPaste � 20240608 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240608 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Employee;

namespace CopyPaste.Learning.CompanyDivision
{

  public class cpDivision : cpEmployee
  {

    #region "Constructors / Destructors"

    public cpDivision() : base()
      //***
      // Action
      //   - Basic constructor
      //   - Create an cpEmployee
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee()
      // Created
      //   - CopyPaste � 20240608 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240608 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDivision()

    public cpDivision(string strFirstName, string strLastName) : base(strFirstName, strLastName)
      //***
      // Action
      //   - Basic constructor with 2 parameters
      //   - Use the basic constructor of cpEmployee
      //     - Set the first name
      //     - Set the last name
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee(string, string)
      // Created
      //   - CopyPaste � 20240608 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240608 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpDivision(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    int mintMonthsInDivision = -1;
    string mstrDivision = "";

    #endregion

    #region "Properties"

    public string Division
    {

      get
        //***
        // Action Get
        //   - Returns the division
        // Called by
        //   - bool Serialize()
        //   - cpProgram.ShowEmployee(cpDivision)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240608 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240608 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrDivision;
      }
      // string Division (Get)

      set
        //***
        // Action Set
        //   - Division becomes value
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240608 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240608 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrDivision = value;
      }
      // Division(string) (Set)

    }
    // string Division

    public int MonthsInDivision
    {

      get
        //***
        // Action Get
        //   - Returns the number of months working in the division
        // Called by
        //   - bool Serialize()
        //   - cpProgram.ShowEmployee(cpDivision)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240608 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240608 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mintMonthsInDivision;
      }
      // int MonthsInDivision (Get)

      set
        //***
        // Action Set
        //   - Number of months working in division becomes value
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240608 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240608 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mintMonthsInDivision = value;
      }
      // MonthsInDivision(int) (Set)

    }
    // int MonthsInDivision

    #endregion

    #region "Methods"

    #region "Overrides"

    public override bool Serialize()
      //***
      // Action
      //   - Checks if the object (cpDivision) is serializable or not
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - bool cpEmployee.Serialize()
      //   - int MonthsInDivision (Get)
      //   - string Division (Get)
      // Created
      //   - CopyPaste � 20240608 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240608 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;

      if ((Division == "") || (MonthsInDivision < 0))
      {
        blnResult = false;
      }
      else
        // (Division <> "") And (MonthsInDivision >= 0)
      {

        if (base.Serialize())
        {
          blnResult = true;
        }
        else
        {
          blnResult = false;
        }

      }
      // (Division = "") || (MonthsInDivision < 0)

      return blnResult;
    }
    // bool Serialize()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDivision

}
// CopyPaste.Learning.CompanyDivision