﻿//***
// Action
//   - Check the validations on a string
// Created
//   - CopyPaste – 20260121 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260121 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public abstract class cpCheckString
  {

    #region "Constructors / Destructors"

    public cpCheckString()
      //***
      // Action
      //   - Define the valid characters
      // Called by
      //   - cpCheckBelgianBankAccount(string)
      //   - cpCheckPhoneNumber(string)
      // Calls
      //   - DefineValidCharacters()
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpCheckString()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public string StringValue
    {

      get
        //***
        // Action Get
        //   - Return 'mstrValue'
        // Called by
        //   - bool cpCustomer.Save() Implements cpiCustomer.Save
        //   - cpCheckBusinessPhoneNumber(cpCheckPhoneNumber)
        //   - cpCheckExtension(cpCheckPhoneNumber)
        //   - cpCheckPhoneNumber(cpCheckPhoneNumber)
        //   - string cpCheckBusinessPhoneNumber.ToString()
        //   - string cpCustomer.ToString() Implements cpiCustomer.ToString
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string StringValue (Get)

      set
        //***
        // Action Set
        //   - If Validation is correct
        //     - Raise the event StringValueBeforeUpdate
        //     - If Change is cancelled
        //       - Do nothing
        //     - If not
        //       - mstrValue becomes value
        //   - If not
        //     - Throw an exception with information
        // Called by
        //   - cpCheckBelgianBankAccount(string)
        //   - cpCheckExtension(string)
        //   - cpCheckPhoneNumber(string)
        //   - cpCustomer.ReadValuesFromDataRow()
        // Calls
        //   - bool IsValid(string)
        //   - cpInvalidStringException ThrowException(string)
        //   - StringValueBeforeUpdate(string, bool)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // StringValue(string) (Set)

    }
    // string StringValue

    #endregion

    #region "Methods"

    #region "Overrides"

    protected abstract void DefineValidCharacters();
      // New()
    protected abstract cpInvalidStringException ThrowException(string strInvalidString);
      // StringValue(string) (Set)

    public override string ToString()
      //***
      // Action
      //   - Define the string to return by default
      //   - Return mstrValue
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "";
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public virtual bool IsValid(string strText)
      //***
      // Action
      //   - Define the lower bound
      //   - Define the upper bound
      //   - Loop from lower to upper bound
      //     - Replace the character with nohting
      //   - Trim the text
      //   - If there is still text
      //     - The given text is not valid
      //   - If not
      //     - The given text is valid
      // Called by
      //   - bool cpCheckBelgianBankAccount.IsValid(string)
      //   - string StringValue()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return false;
    }
    // bool IsValid(string)

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCheckString

}
// CopyPaste.Learning