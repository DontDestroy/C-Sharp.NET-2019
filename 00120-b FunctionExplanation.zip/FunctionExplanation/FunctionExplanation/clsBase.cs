//***
// Action
//   - Definition of a base class cpBase
// Created
//   - CopyPaste � 20240617 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240617 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpBase
  {

    #region "Constructors / Destructors"

    public cpBase()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpDerived()
      //   - cpProgram.Main() 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpBase()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    internal bool FunctionInternal()
      //***
      // Action
      //   - Internal FunctionRoutine
      //   - Internal elements are accessible from within the program
      //     that contains their declaration and from anywhere else 
      //     in the same assembly
      // Called by
      //   - cpProgram.Main()
      //   - SubTestBase()
      //   - SubTestDerived()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Function Internal");
      return true;
    }
    // FunctionInternal()

    private bool FunctionPrivate()
      //***
      // Action
      //   - Private FunctionRoutine
      //   - Private elements are accessible only from within their
      //     declaration context, including from members of any nested types,
      //     for example from within a nested procedure or from
      //     an assignment expression in a nested enumeration
      // Called by
      //   - cpProgram.Main()
      //   - SubTestBase()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Function Private");
      return true;
    }
    // FunctionPrivate()

    protected bool FunctionProtected()
      //***
      // Action
      //   - Protected FunctionRoutine
      //   - Protected elements are accessible only from within their
      //     own class or from a derived class
      //   - Protected access is not a superset of friend access
      // Called by
      //   - cpProgram.Main()
      //   - FunctionTestBase()
      //   - FunctionTestDerived()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Function Protected");
      return true;
    }
    // FunctionProtected()

    protected internal bool FunctionProtectedInternal()
      //***
      // Action
      //   - Protected Friend FunctionRoutine
      //   - This combination confers both friend and protected access
      //     on the declared elements, so they are accessible from
      //     the same assembly, from their own class,
      //     and from any derived classes
      // Called by
      //   - cpProgram.Main()
      //   - SubTestBase()
      //   - SubTestDerived()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Function Protected Internal");
      return true;
    }
    // FunctionProtectedInternal()

    public bool FunctionPublic()
      //***
      // Action
      //   - Public FunctionRoutine
      //   - There are no restrictions on the accessibility of public elements
      // Called by
      //   - cpProgram.Main()
      //   - SubTestBase()
      //   - SubTestDerived()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Function Public");
      return true;
    }
    // SubPublic()

    public void FunctionTestBase()
      //***
      // Action
      //   - Test base functionroutines
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - bool FunctionInternal()
      //   - bool FunctionPrivate()
      //   - bool FunctionProtected()
      //   - bool FunctionProtectedInternal()
      //   - bool FunctionPublic()
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;

      blnResult = FunctionInternal();
      Console.WriteLine("Result of FunctionInternal: {0}", blnResult);
      blnResult = FunctionPrivate();
      Console.WriteLine("Result of FunctionPrivate: {0}", blnResult);
      blnResult = FunctionProtected();
      Console.WriteLine("Result of FunctionProtected: {0}", blnResult);
      blnResult = FunctionProtectedInternal();
      Console.WriteLine("Result of FunctionProtectedInternal: {0}", blnResult);
      blnResult = FunctionPublic();
      Console.WriteLine("Result of FunctionPublic: {0}", blnResult);
    }
    // FunctionTestBase()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBase

}
// CopyPaste.Learning