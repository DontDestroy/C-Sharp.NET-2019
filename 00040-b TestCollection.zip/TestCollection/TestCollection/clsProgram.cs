//***
// Action
//   - Working with a collection of collections
// Created
//   - CopyPaste � 20240228 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240228 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Define 2 collections (a main and a sub collection)
      //   - Define a counter
      //   - Loop from 1 till 10
      //     - Create a sub collection
      //     - Add 2 items to it
      //     - Add the sub collection to the main collection
      //     - Destroy the sub collection
      //   - Show a messagebox with the elements in the main collection
      //   - Loop thru the main collection with a counter
      //     - Get the item (cast it to a collection)
      //     - Show the 2 items in that item
      //     - Destroy the item
      //   - Loop thru the main collection
      //     - Show the 2 items in that item
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Collection colMain = new Collection();
      Collection colSub;
      int lngCounter;

      for (lngCounter = 1; lngCounter <= 10; lngCounter++)
      {
        colSub = new Collection();
        colSub.Add(lngCounter + 3, "ValuePlusThree", null, null);
        colSub.Add(lngCounter + 6, "ValuePlusSix", null, null);
        colMain.Add(colSub, lngCounter.ToString(), null, null);
        colSub = null;
      }
      // lngCounter = 10

      MessageBox.Show(colMain.Count.ToString());

      for (lngCounter = 1; lngCounter <= colMain.Count; lngCounter++)
      {
        colSub = (Collection) colMain[lngCounter.ToString()];
        Console.WriteLine("3 + " + lngCounter + " = " + colSub["ValuePlusThree"].ToString());
        Console.WriteLine("6 + " + lngCounter + " = " + colSub["ValuePlusSix"].ToString());
        colSub = null;
      }
      // lngCounter = colMain.Count + 1

      Console.WriteLine();
      lngCounter = 1;

      foreach (Collection aCollection in colMain)
      {
        Console.WriteLine("3 + " + lngCounter + " = " + aCollection["ValuePlusThree"].ToString());
        Console.WriteLine("6 + " + lngCounter + " = " + aCollection["ValuePlusSix"].ToString());
        lngCounter += 1;
      }
      // in colMain

      Console.WriteLine();
      Console.WriteLine("Hit enter to stop.");
      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning