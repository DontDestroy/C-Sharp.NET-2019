//***
// Action
//   - Startup screen of the duck game
// Created
//   - CopyPaste � 20240727 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240727 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Game.Animal.Library;
using CopyPaste.Game.Duck.Library;
using System.Reflection;

namespace CopyPaste.Game.Duck
{

	public partial class frmDuckGame : System.Windows.Forms.Form
	{

		#region "Constructors / Destructors"

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		//***
		// Action
		//   - Clean up instance of 'frmDuckGame'
		// Called by
		//   - User action (Closing the form)
		// Calls
		//   - 
		// Created
		//   - CopyPaste � 20240727 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20240727 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{

			if (disposing)
			{

				if (components == null)
				{
				}
				else
				// (components != null)
				{
					components.Dispose();
				}
				// (components == null)

			}
			else
			// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		/// <summary>
		/// Constructor of the start screen of the Duck Game
		/// </summary>
		public frmDuckGame()
		//***
		// Action
		//   - Create instance of 'frmDuckGame'
		// Called by
		//   - Main()
		// Calls
		//   - InitializeComponent()
		//   - FillComboBoxWithChildsOfcpDuck()
		// Created
		//   - CopyPaste � 20240727 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20240727 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			InitializeComponent();
			FillComboBoxWithChildsOfcpDuck();
		}
		// frmDuckGame()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"

		private void cmbChooseDuck_SelectedIndexChanged(System.Object theSender, EventArgs theEventArguments)
		//***
		// Action
		//   - If nothing is selected
		//     - Do nothing
		//   - If not
		//     - Define a duck with the selected type
		//     - Define how the duck is displayed
		//     - Display duck
		// Called by
		//   - User action (Choosing an option in the combo box)
		// Calls
		//   - CopyPaste.Game.Animal.Library.cpDisplayPicture()
		//   - CopyPaste.Game.Duck.Library.Display()
		// Created
		//   - CopyPaste � 20240727 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20240727 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{

			if (cmbChooseDuck.SelectedIndex == -1)
			{
			}
			else
			// cmbChooseDuck.SelectedIndex <> -1
			{
				cpDuck aDuck = cmbChooseDuck.SelectedItem as cpDuck;
				aDuck.HowToDisplay = new cpDisplayPicture(this);
				aDuck.Display();
			}
			// cmbChooseDuck.SelectedIndex = -1

		}
		// cmbChooseDuck_SelectedIndexChanged(System.Object, EventArgs) Handles cmbChooseDuck.SelectedIndexChanged

		private void cmdMakeSound_Click(System.Object theSender, EventArgs theEventArguments)
		//***
		// Action
		//   - If nothing is selected
		//     - Do nothing
		//   - If not
		//     - Define a duck with the selected type
		//     - Define how to make a noise
		//     - Loop a number of times (defined in the duck)
		//       - Make noise
		// Called by
		//   - User action (Choosing an option in the combo box)
		// Calls
		//   - byte cpDuck.NumberOfQuacks() (Get)
		//   - CopyPaste.Game.Animal.Library.cpQuack()
		//   - CopyPaste.Game.Duck.Library.MakeNoise()
		// Created
		//   - CopyPaste � 20240727 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20240727 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{

			if (cmbChooseDuck.SelectedIndex == -1)
			{
			}
			else
			// cmbChooseDuck.SelectedIndex <> -1
			{
				cpDuck aDuck = cmbChooseDuck.SelectedItem as cpDuck;
				aDuck.HowToMakeNoise = new cpQuack();
				// Not using the basic Quack functionality from the library, but the one created in the current project

				for (int intCounter = 0; intCounter < aDuck.NumberOfQuacks; intCounter++)
				{
					aDuck.MakeNoise();
				}
				// intCounter = aDuck.NumberOfQuacks

			}
			// cmbChooseDuck.SelectedIndex = -1

		}
		// cmdMakeSound_Click(System.Object, EventArgs) Handles cmdMakeSound.Click

		#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Fill the combo box on the screen with all the childs of cpDuck
		/// </summary>
		private void FillComboBoxWithChildsOfcpDuck()
		//***
		// Action
		//   - Use cpDuck (data type)
		//     - Needed because I want to find the attached DuckGameLibrary assembly
		//   - Get the assembly of cpDuck
		//   - Loop thru all the types
		//     - If the type (class) had a base class of cpDuck
		//       - Define a duck of that type
		//       - Add the duck to the combo box (ToString() is shown)
		//     - If not
		//       - Do nothing
		// Called by
		//   - frmDuckGame()
		// Calls
		//   - CopyPaste.Game.Duck.Library.cpDuck.ToString()
		// Created
		//   - CopyPaste � 20240727 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20240727 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		////***
		{
			Type typBaseClass = typeof(cpDuck);
			Assembly theAssembly = typBaseClass.Assembly;
			// Assembly theAssembly = Assembly.GetExecutingAssembly();
			// VVDW - This can be used if the classes are inside the current assembly
			// VVDW - In this battleplan solution it is not the case
			// VVDW - So I look up the assembly where cpDuck is defined

			foreach (Type theType in theAssembly.GetTypes())
			{

				if (theType.BaseType == typBaseClass)
				{
					cpDuck aDuck = (cpDuck)theAssembly.CreateInstance(theType.FullName);
					cmbChooseDuck.Items.Add(aDuck);
				}
				else
				// theType.BaseType <> typBaseClass
				{
				}
				// theType.BaseType = typBaseClass

			}
			// in theAssembly.GetTypes()

		}
		// FillComboBoxWithChildsOfcpDuck()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmDuckGame

}
// CopyPaste.Game.Duck