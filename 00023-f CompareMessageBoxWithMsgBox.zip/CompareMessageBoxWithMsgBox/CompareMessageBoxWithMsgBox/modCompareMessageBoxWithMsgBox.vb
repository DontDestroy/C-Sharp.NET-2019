'***
' Action
'   - Comparing the functionality Msgbox and MessageBox
' Created
'   - CopyPaste � 20210831 � VVDW
' Changed
'   - Organisation � yyyymmdd � Initials of programmer � What changed
' Tested
'   - CopyPaste � 20210831 � VVDW
' Proposal (To Do)
'   - List of actions that can be added to the functionality
'***

Option Explicit On 
Option Strict On

Imports Microsoft.VisualBasic
Imports System.Windows.Forms

Module modCompareMessageBoxWithMsgBox

  Sub Main()
    '***
    ' Action
    '   - Using Msgbox Functionality
    '   - Using MessageBox Functionality
    '   - Hardcoded by comment to choose one of the two
    ' Called by
    '   - User action (starting the program)
    ' Calls
    '   - MsgBoxTest()
    '   - MesssageBoxTest()
    ' Created
    '   - CopyPaste � 20210831 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210831 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    ' MsgBoxTest()
    MessageBoxTest()
  End Sub
  ' Main()

  Sub MesssageBoxCheckResult(ByVal intResult As Int32)
    '***
    ' Action
    '   - Depending on result (intResult)
    '     - Show messagebox that you clicked Abort
    '     - Show messagebox that you clicked Cancel
    '     - Show messagebox that you clicked Ignore
    '     - Show messagebox that you clicked No
    '     - Show messagebox that you clicked on nothing
    '     - Show messagebox that you clicked OK
    '     - Show messagebox that you clicked Retry
    '     - Show messagebox that you clicked Yes
    '     - Show messagebox that you clicked on something for future use
    ' Called by
    '   - MessageBoxTest()
    ' Calls
    '   - System.Windows.Forms.MessageBox.Show(String, and a bunch of parameters / overloads)
    ' Created
    '   - CopyPaste � 20210831 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210831 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    Select Case intResult
      Case DialogResult.Abort
        MessageBox.Show("You clicked the Abort button", "Copy Paste Result", MessageBoxButtons.OK)
      Case DialogResult.Cancel
        MessageBox.Show("You clicked the Cancel button", "Copy Paste Result", MessageBoxButtons.OK)
      Case DialogResult.Ignore
        MessageBox.Show("You clicked the Ignore button", "Copy Paste Result", MessageBoxButtons.OK)
      Case DialogResult.No
        MessageBox.Show("You clicked the No button", "Copy Paste Result", MessageBoxButtons.OK)
      Case DialogResult.None
        MessageBox.Show("The modal dialogbox is still running", "Copy Paste", MessageBoxButtons.OK)
      Case DialogResult.OK
        MessageBox.Show("You clicked the OK button", "Copy Paste Result", MessageBoxButtons.OK)
      Case DialogResult.Retry
        MessageBox.Show("You clicked the Retry button", "Copy Paste Result", MessageBoxButtons.OK)
      Case DialogResult.Yes
        MessageBox.Show("You clicked the Yes button", "Copy Paste Result", MessageBoxButtons.OK)
      Case Else
        MessageBox.Show("Can be used for future changes", "Copy Paste Result", MessageBoxButtons.OK)
    End Select
    ' intResult

  End Sub
  ' MesssageBoxCheckResult(Int32)

  Sub MessageBoxTest()
    '***
    ' Action
    '   - Using MessageBox Functionality
    '   - Define 2 variables (strText and strTitle)
    '   - Show a messagebox with 3 buttons, an asterix, third button default, Desktop only
    '   - Show a messagebox with OK button, an error, Right align
    '   - Show a messagebox with 2 buttons, an exclamation, second button default, Left reading order
    '   - Show a messagebox with 2 buttons, a hand, first button default, ServiceNotification
    '   - Show a messagebox with 2 buttons, an information
    '   - Show a messagebox with 3 buttons, no icon
    '   - Show a messagebox with OK button, a question mark
    '   - Show a messagebox with OK button, a stop sign
    '   - Show a messagebox with OK button, a warning
    '   - Remember the result of Show a messagebox with Yes and No button
    '   - Show the chosen result
    ' Called by
    '   - Main()
    ' Calls
    '   - MesssageBoxCheckResult(Int32)
    ' Created
    '   - CopyPaste � 20210831 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210831 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    Dim strText As String = "This is the message"
    Dim strTitle As String = "Copy Paste"

    MessageBox.Show(strText, strTitle, MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button3, MessageBoxOptions.DefaultDesktopOnly)
    MessageBox.Show(strText, strTitle, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RightAlign)
    MessageBox.Show(strText, strTitle, MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading)
    MessageBox.Show(strText, strTitle, MessageBoxButtons.RetryCancel, MessageBoxIcon.Hand, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification)
    MessageBox.Show(strText, strTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Information)
    MessageBox.Show(strText, strTitle, MessageBoxButtons.YesNoCancel, MessageBoxIcon.None)
    MessageBox.Show(strText, strTitle, MessageBoxButtons.OK, MessageBoxIcon.Question)
    MessageBox.Show(strText, strTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop)
    MessageBox.Show(strText, strTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning)
    MesssageBoxCheckResult(MessageBox.Show(strText, strTitle, MessageBoxButtons.YesNo))
  End Sub
  ' MessageBoxTest()

  Sub MsgBoxCheckResult(ByVal intResult As Int32)
    '***
    ' Action
    '   - Depending on result (intResult)
    '     - Show messagebox that you clicked Abort
    '     - Show messagebox that you clicked Cancel
    '     - Show messagebox that you clicked Ignore
    '     - Show messagebox that you clicked No
    '     - Show messagebox that you clicked OK
    '     - Show messagebox that you clicked Retry
    '     - Show messagebox that you clicked Yes
    '     - Show messagebox that you clicked on something for future use
    ' Called by
    '   - MsgBoxTest()
    ' Calls
    '   - Msgbox(Object, MsgBoxStyle, [Object]) As MsgBoxResult
    ' Created
    '   - CopyPaste � 20210831 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210831 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    Select Case intResult
      Case MsgBoxResult.Abort
        MsgBox("You clicked the Abort button", MsgBoxStyle.OKOnly, "Copy Paste Result")
      Case MsgBoxResult.Cancel
        MsgBox("You clicked the Cancel button", MsgBoxStyle.OKOnly, "Copy Paste Result")
      Case MsgBoxResult.Ignore
        MsgBox("You clicked the Ignore button", MsgBoxStyle.OKOnly, "Copy Paste Result")
      Case MsgBoxResult.No
        MsgBox("You clicked the No button", MsgBoxStyle.OKOnly, "Copy Paste Result")
      Case MsgBoxResult.OK
        MsgBox("You clicked the OK button", MsgBoxStyle.OKOnly, "Copy Paste Result")
      Case MsgBoxResult.Retry
        MsgBox("You clicked the Retry button", MsgBoxStyle.OKOnly, "Copy Paste Result")
      Case MsgBoxResult.Yes
        MsgBox("You clicked the Yes button", MsgBoxStyle.OKOnly, "Copy Paste Result")
      Case Else
        MsgBox("Can be used for future changes", MsgBoxStyle.OKOnly, "Copy Paste Result")
    End Select
    ' intResult

  End Sub
  ' MsgBoxCheckResult(Int32)

  Sub MsgBoxTest()
    '***
    ' Action
    '   - Using MsgBox Functionality
    '   - Define 1 variable (strText)
    '   - Show a messagebox with 1 button and corresponding title
    '   - Show a messagebox with critical icon and corresponding title
    '   - Show a messagebox with exclamation icon and corresponding title
    '   - Show a messagebox with information icon and corresponding title
    '   - Show a messagebox with question icon and corresponding title
    '   - Show a messagebox with 2 buttons and corresponding title
    '   - Show a messagebox with 2 buttons, second default and corresponding title
    '   - Show a messagebox with 2 buttons and corresponding title
    '   - Show a messagebox with 3 buttons, third default and corresponding title
    '   - Show a messagebox with 3 buttons and corresponding title
    '   - Show a messagebox with help and corresponding title
    '   - Show a messagebox with Right and corresponding title
    '   - Show a messagebox with Right to left reading and corresponding title
    '   - Show a messagebox with on the foreground and corresponding title
    '   - Show a messagebox with modal application and corresponding title
    '   - Show a messagebox with modal system and corresponding title
    '   - Remember the result of Show a messagebox with Yes and No button and corresponding title
    '   - Show the chosen result
    ' Called by
    '   - Main()
    ' Calls
    '   - MsgBoxCheckResult(Int32)
    ' Created
    '   - CopyPaste � 20210831 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210831 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    Dim strText As String = "This is the message"

    MsgBox(strText, MsgBoxStyle.OKOnly, "MsgBoxStyle.OKOnly")
    MsgBox(strText, MsgBoxStyle.Critical, "MsgBoxStyle.Critical")
    MsgBox(strText, MsgBoxStyle.Exclamation, "MsgBoxStyle.Exclamation")
    MsgBox(strText, MsgBoxStyle.Information, "MsgBoxStyle.Information")
    MsgBox(strText, MsgBoxStyle.Question, "MsgBoxStyle.Question")

    MsgBox(strText, MsgBoxStyle.OKCancel, "MsgBoxStyle.OKCancel")
    MsgBox(strText, MsgBoxStyle.YesNo Or MsgBoxStyle.DefaultButton2, "MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2")
    MsgBox(strText, MsgBoxStyle.RetryCancel, "MsgBoxStyle.RetryCancel")
    MsgBox(strText, MsgBoxStyle.YesNoCancel Or MsgBoxStyle.DefaultButton3, "MsgBoxStyle.YesNoCancel + MsgBoxStyle.DefaultButton3")
    MsgBox(strText, MsgBoxStyle.AbortRetryIgnore, "MsgBoxStyle.AbortRetryIgnore")

    MsgBox(strText, MsgBoxStyle.MsgBoxHelp, "MsgBoxStyle.MsgBoxHelp")
    MsgBox(strText, MsgBoxStyle.MsgBoxRight, "MsgBoxStyle.MsgBoxRight")
    MsgBox(strText, MsgBoxStyle.MsgBoxRtlReading, "MsgBoxStyle.MsgBoxRtlReading")
    MsgBox(strText, MsgBoxStyle.MsgBoxSetForeground, "MsgBoxStyle.MsgBoxSetForeground")

    MsgBox(strText, MsgBoxStyle.ApplicationModal, "MsgBoxStyle.ApplicationModal")
    MsgBox(strText, MsgBoxStyle.SystemModal, "MsgBoxStyle.SystemModal")
    MsgBoxCheckResult(MsgBox(strText, MsgBoxStyle.YesNo, "Return Result"))
  End Sub
  ' MsgBoxTest()

End Module
' modCompareMessageBoxWithMsgBox