//***
// Action
//   - Try to divide 2 numbers
// Created
//   - CopyPaste � 20220823 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220823 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace DivideByZero
{

  public class frmDivideByZero : System.Windows.Forms.Form
  {
    internal System.Windows.Forms.Label lblOutput;
    internal System.Windows.Forms.Button cmdDivide;
    internal System.Windows.Forms.TextBox txtDenominator;
    internal System.Windows.Forms.TextBox txtNumerator;
    internal System.Windows.Forms.Label lblDenominator;
    internal System.Windows.Forms.Label lblNumerator;

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDivideByZero));
      this.lblOutput = new System.Windows.Forms.Label();
      this.cmdDivide = new System.Windows.Forms.Button();
      this.txtDenominator = new System.Windows.Forms.TextBox();
      this.txtNumerator = new System.Windows.Forms.TextBox();
      this.lblDenominator = new System.Windows.Forms.Label();
      this.lblNumerator = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // lblOutput
      // 
      this.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblOutput.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOutput.Location = new System.Drawing.Point(144, 88);
      this.lblOutput.Name = "lblOutput";
      this.lblOutput.Size = new System.Drawing.Size(104, 24);
      this.lblOutput.TabIndex = 11;
      // 
      // cmdDivide
      // 
      this.cmdDivide.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmdDivide.Location = new System.Drawing.Point(16, 80);
      this.cmdDivide.Name = "cmdDivide";
      this.cmdDivide.Size = new System.Drawing.Size(104, 32);
      this.cmdDivide.TabIndex = 10;
      this.cmdDivide.Text = "Click to Divide";
      this.cmdDivide.Click += new System.EventHandler(this.cmdDivide_Click);
      // 
      // txtDenominator
      // 
      this.txtDenominator.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtDenominator.Location = new System.Drawing.Point(144, 40);
      this.txtDenominator.Name = "txtDenominator";
      this.txtDenominator.Size = new System.Drawing.Size(104, 22);
      this.txtDenominator.TabIndex = 9;
      // 
      // txtNumerator
      // 
      this.txtNumerator.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.txtNumerator.Location = new System.Drawing.Point(144, 8);
      this.txtNumerator.Name = "txtNumerator";
      this.txtNumerator.Size = new System.Drawing.Size(104, 22);
      this.txtNumerator.TabIndex = 7;
      // 
      // lblDenominator
      // 
      this.lblDenominator.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblDenominator.Location = new System.Drawing.Point(8, 40);
      this.lblDenominator.Name = "lblDenominator";
      this.lblDenominator.Size = new System.Drawing.Size(120, 23);
      this.lblDenominator.TabIndex = 8;
      this.lblDenominator.Text = "Enter denominator";
      // 
      // lblNumerator
      // 
      this.lblNumerator.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblNumerator.Location = new System.Drawing.Point(8, 8);
      this.lblNumerator.Name = "lblNumerator";
      this.lblNumerator.Size = new System.Drawing.Size(104, 23);
      this.lblNumerator.TabIndex = 6;
      this.lblNumerator.Text = "Enter numerator";
      // 
      // frmDivideByZero
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(264, 133);
      this.Controls.Add(this.lblOutput);
      this.Controls.Add(this.cmdDivide);
      this.Controls.Add(this.txtDenominator);
      this.Controls.Add(this.txtNumerator);
      this.Controls.Add(this.lblDenominator);
      this.Controls.Add(this.lblNumerator);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDivideByZero";
      this.Text = "Divide by Zero Test";
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmDivideByZero'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220823 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220823 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null)
        {
        }
        else
        // (components != null)
        {
          components.Dispose();
        }
        // (components == null)

      }
      else
      // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDivideByZero()
    //***
    // Action
    //   - Create instance of 'frmDivideByZero'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220823 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220823 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmDivideByZero()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdDivide_Click(System.Object theSender, System.EventArgs theSystemEventArguments)
    //***
    // Action
    //   - Result becomes empty string
    //   - Try to divide the content of 2 textboxes
    //     - Show the result
    //   - When format fails
    //     - Show corresponding error message
    //   - When divided by zero
    //     - Show corresponding error message
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220823 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220823 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblOutput.Text = "";

      try
      {
        long lngDenominator = Convert.ToInt32(txtDenominator.Text);
        long lngNumerator = Convert.ToInt32(txtNumerator.Text);
        long lngResult = lngNumerator / lngDenominator;

        lblOutput.Text = lngResult.ToString();
      }
      catch (FormatException theFormatException)
      {
        MessageBox.Show("You must enter two integers", "Invalid Number Format", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
      catch (DivideByZeroException theDivideByZeroException)
      {
        MessageBox.Show(theDivideByZeroException.Message, "Attempted to Divide by Zero", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }

    }
    // cmdDivide_Click(System.Object, System.EventArgs) Handles cmdDivide.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmDivideByZero
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220823 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220823 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmDivideByZero());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDivideByZero

}
// DivideByZero