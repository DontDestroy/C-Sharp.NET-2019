//***
// Action
//   - Testroutine for cpctlRichTextBoxKeyWord
// Created
//   - CopyPaste � 20250721 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250721 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Learning.UserInterface;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmRichTextBoxKeyWord: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    private cpctlRichTextBoxKeyWord rtxtText;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmRichTextBoxKeyWord));
      this.rtxtText = new CopyPaste.Learning.UserInterface.cpctlRichTextBoxKeyWord();

      this.rtxtText.Dock = System.Windows.Forms.DockStyle.Fill;
      this.rtxtText.Location = new System.Drawing.Point(0, 0);
      this.rtxtText.Name = "rtxtText";
      this.rtxtText.Separator = new Char[] {';', ' ', ',', ':', '!', '@', '#', '$', '%', '^', '&',
                                            '*', '(', ')', '[', ']', '<', '>', '/', '"', (char)Keys.LineFeed};
      this.rtxtText.Size = new System.Drawing.Size(368, 334);
      this.rtxtText.TabIndex = 0;
      this.rtxtText.Text = "";

      // 
      // frmRichTextBoxKeyWord
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(368, 334);
      this.Controls.Add(this.rtxtText);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmRichTextBoxKeyWord";
      this.Text = "RichTextbox Keyword (Customer, Id, Info, Order)";
    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDefault'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmRichTextBoxKeyWord()
      //***
      // Action
      //   - Create instance of 'frmDefault'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"
    
    protected override void OnLoad(EventArgs theEventArguments)
    {
      char[] arrchrSeparator = rtxtText.Separator;
      char[] arrchrNewSeparator = new char[arrchrSeparator.Length];

      Array.Copy(arrchrSeparator, arrchrNewSeparator, arrchrSeparator.Length);
      arrchrNewSeparator[arrchrNewSeparator.Length - 2] = '=';
      arrchrNewSeparator[arrchrNewSeparator.Length - 1] = '.';
      rtxtText.Separator = arrchrNewSeparator;

      rtxtText.KeyWord.Add("info", new cpKeyWordFormat(Color.Red));
      rtxtText.KeyWord.Add("order", new cpKeyWordFormat(Color.Blue));
      rtxtText.KeyWord.Add("customer", new cpKeyWordFormat(Color.Green));
      rtxtText.KeyWord.Add("id", new cpKeyWordFormat(new Font(rtxtText.Font, FontStyle.Bold)));
    }
    // OnLoad(EventArgs)

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmRichTextBoxKeyWord
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmRichTextBoxKeyWord()
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmRichTextBoxKeyWord());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // frmRichTextBoxKeyWord

}
// CopyPaste.Learning