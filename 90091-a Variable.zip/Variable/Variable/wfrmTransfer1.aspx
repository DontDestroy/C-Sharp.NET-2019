﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmTransfer1.aspx.cs" Inherits="CopyPaste.Learning.wfrmTransfer1" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Transfer</title>
</head>
<body>
  <form id="wfrmTransfer1" method="post" runat="server">
    <asp:Label ID="lblName" Style="z-index: 106; position: absolute; top: 104px; left: 64px" runat="server">Name</asp:Label>
    <asp:Button ID="cmdOK" Style="z-index: 105; position: absolute; top: 184px; left: 64px" runat="server"
      Text="OK" TabIndex="3"></asp:Button>
    <asp:TextBox ID="txtEmail" Style="z-index: 104; position: absolute; top: 144px; left: 136px"
      runat="server" TabIndex="2"></asp:TextBox>
    <asp:TextBox ID="txtName" Style="z-index: 103; position: absolute; top: 104px; left: 136px" runat="server"
      TabIndex="1"></asp:TextBox>
    <asp:Label ID="lblEmail" Style="z-index: 102; position: absolute; top: 144px; left: 64px" runat="server">E-mail</asp:Label>
  </form>
</body>
</html>
