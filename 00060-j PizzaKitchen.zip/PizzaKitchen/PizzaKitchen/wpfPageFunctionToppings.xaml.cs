﻿//***
// Action
//   - Select some toppings for your pizza
// Created
//   - CopyPaste – 20220819 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220819 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PizzaKitchen
{

  public partial class wpfPageFunctionToppings : PageFunction<System.Object>, IProvideCustomContentState
  {

    #region "Constructors / Destructors"

    public wpfPageFunctionToppings()
    //***
    // Action
    //   - Creating an instance of wpfPageFunctionToppings
    // Called by
    //   - wpfChoosePizza.cmdSelectTopping_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdSelectTopping.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfPageFunctionToppings()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAddToppings_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Define a listbox for the available toppings
    //   - Define a listbox for the chosen toppings
    //   - Add this information as back entry
    //   - Move selected item from available topping to chosen topping
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - cpToppingCustomJournalEntry(List<ListBoxItem>, List<ListBoxItem>, ReplayDelegate)
    // Created
    //   - CopyPaste – 20220819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      List<ListBoxItem> theAvailableToppings = new List<ListBoxItem>();
      List<ListBoxItem> theChosenToppings = new List<ListBoxItem>();

      foreach (ListBoxItem lstitemAvailableTopping in lstToppings.Items)
      {
        theAvailableToppings.Add(lstitemAvailableTopping);
      }
      // in lstToppings.Items

      foreach (ListBoxItem lstitemChosenTopping in lstChosenToppings.Items)
      {
        theChosenToppings.Add(lstitemChosenTopping);
      }
      // in lstChosenToppings.Items

      NavigationService.AddBackEntry(new cpToppingCustomJournalEntry(theAvailableToppings, theChosenToppings, ReplayCallback));
      ListBoxItem lstitemSelected = (ListBoxItem)lstToppings.SelectedItem;
      lstToppings.Items.Remove(lstitemSelected);
      lstChosenToppings.Items.Add(lstitemSelected);
    }
    // cmdAddToppings_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAddTopping.Click

    private void cmdReady_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Stopping the selecting of toppings and return to the Choose Pizza screen
    //   - OnReturn event is triggered
    // Called by
    //   - wpfChoosePizza.cmdSelectTopping_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdSelectTopping.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      List<string> lstItems = new List<string>();

      foreach (ListBoxItem lstitemChosenTopping in lstChosenToppings.Items)
      {
        lstItems.Add(lstitemChosenTopping.Content.ToString());
      }
      // in lstChosenToppings.Items

      ReturnEventArgs<System.Object> theReturnEventArguments = new ReturnEventArgs<System.Object>((System.Object)lstItems);
      OnReturn(theReturnEventArguments);
    }
    // cmdReady_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdReady.Click

    private void cmdRemoveToppings_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Define a listbox for the available toppings
    //   - Define a listbox for the chosen toppings
    //   - Add this information as back entry
    //   - Move selected item from chosen topping to available topping
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - cpToppingCustomJournalEntry(List<ListBoxItem>, List<ListBoxItem>, ReplayDelegate)
    // Created
    //   - CopyPaste – 20220819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      List<ListBoxItem> theAvailableToppings = new List<ListBoxItem>();
      List<ListBoxItem> theChosenToppings = new List<ListBoxItem>();

      foreach (ListBoxItem lstitemAvailableTopping in lstToppings.Items)
      {
        theAvailableToppings.Add(lstitemAvailableTopping);
      }
      // in lstToppings.Items

      foreach (ListBoxItem lstitemChosenTopping in lstChosenToppings.Items)
      {
        theChosenToppings.Add(lstitemChosenTopping);
      }
      // in lstChosenToppings.Items

      NavigationService.AddBackEntry(new cpToppingCustomJournalEntry(theAvailableToppings, theChosenToppings, ReplayCallback));
      ListBoxItem lstitemSelected = (ListBoxItem)lstChosenToppings.SelectedItem;
      lstChosenToppings.Items.Remove(lstitemSelected);
      lstToppings.Items.Add(lstitemSelected);
    }
    // cmdRemoveToppings_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdRemoveToppings.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public System.Windows.Navigation.CustomContentState GetContentState()
    //***
    // Action
    //   - Filling a ToppingCustomJournalEntry with the needed information
    //   - The available toppings
    //   - The chosen toppings
    //   - Returns a filled in ToppingCustomJournalEntry
    // Called by
    //   -
    // Calls
    //   - cpToppingCustomJournalEntry(List<ListBoxItem>, List<ListBoxItem>, ReplayDelegate)
    //   - ReplayCallback(cpToppingCustomJournalEntry)
    // Created
    //   - CopyPaste – 20220819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      List<ListBoxItem> theAvailableToppings = new List<ListBoxItem>();
      List<ListBoxItem> theChosenToppings = new List<ListBoxItem>();

      foreach (ListBoxItem lstitemAvailableTopping in lstToppings.Items)
      {
        theAvailableToppings.Add(lstitemAvailableTopping);
      }
      // in lstToppings.Items

      foreach (ListBoxItem lstitemChosenTopping in lstChosenToppings.Items)
      {
        theChosenToppings.Add(lstitemChosenTopping);
      }
      // in lstChosenToppings.Items

      return new cpToppingCustomJournalEntry(theAvailableToppings, theChosenToppings, ReplayCallback);
    }
    // System.Windows.Navigation.CustomContentState GetContentState()

    private void ReplayCallback(cpToppingCustomJournalEntry theToppingCustomJournalEntry)
    //***
    // Action
    //   - Method that will be used as delegate
    //   - Clear the listboxes on the screen
    //   - Fill the listboxes again
    // Called by
    //   - cmdAddToppings_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAddTopping.Click
    //   - cmdRemoveToppings_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdRemoveToppings.Click
    //   - cpToppingCustomJournalEntry.Replay(System.Windows.Navigation.NavigationService, System.Windows.Navigation.NavigationMode)
    //   - System.Windows.Navigation.CustomContentState GetContentState()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lstToppings.Items.Clear();
      lstChosenToppings.Items.Clear();

      foreach (ListBoxItem lstitemTopping in theToppingCustomJournalEntry.AvailableToppings)
      {
        lstToppings.Items.Add(lstitemTopping);
      }
      // in theToppingCustomJournalEntry.AvailableToppings

      foreach (ListBoxItem lstitemChosenTopping in theToppingCustomJournalEntry.ChosenToppings)
      {
        lstChosenToppings.Items.Add(lstitemChosenTopping);
      }
      // in theToppingCustomJournalEntry.AvailableToppings

    }
    // ReplayCallback(cpToppingCustomJournalEntry)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfPageFunctionToppings

}
// PizzaKitchen