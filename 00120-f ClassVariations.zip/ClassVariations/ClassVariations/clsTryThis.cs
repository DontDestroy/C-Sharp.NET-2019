//***
// Action
//   - Try to inherit from a not inheritable class
// Created
//   - CopyPaste � 20240617 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240617 � VVDW
// Proposal (To Do)
//   - Remove the comment in line 17
//***

namespace CopyPaste.Learning
{

  public class cpCantCreateThisClass // : cpNotABase
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpCantCreateThisClass

}
// CopyPaste.Learning