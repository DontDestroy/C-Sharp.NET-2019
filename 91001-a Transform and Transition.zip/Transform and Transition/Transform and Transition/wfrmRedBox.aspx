﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmRedBox.aspx.cs" Inherits="CopyPaste.Learning.wfrmRedBox" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>CSS Transforms and Transitions</title>
  <style>

    #box {
      position: absolute;
      top: 100px;
      left: 100px;
      width: 200px;
      height: 200px;
      background-color: red;
      transition: transform 2s;
      -webkit-transition: -webkit-transform 2s;
      -moz-transition: -moz-transform 2s;
      -o-transition: -o-transform 2s;
      /* There is no transition for microsoft yet*/
    }

      #box:hover {
        transform: rotate(45deg);
        -webkit-transform: rotate(45deg); /* Safari, Chrome, mobile Safari, and Android */
        -moz-transform: rotate(45deg); /* Firefox */
        -o-transform: rotate(45deg); /* Opera */
        -ms-transform: rotate(45deg); /* Edge */
      }

  </style>
</head>
<body>
  <form id="wfrmRedBox">
    <div id="box">
    </div>
  </form>
</body>
</html>
