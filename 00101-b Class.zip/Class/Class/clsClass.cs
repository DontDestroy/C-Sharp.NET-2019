//***
// Action
//   - A simple class
// Created
//   - CopyPaste � 20220301 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220301 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Class
{

  class cpClass
	{

    static void Main()
    //***
    // Action
    //   - Show absolute value of -1
    //   - Show the square root of 144
    //   - Show PI
    //   - Show 10 to the power 2
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - Console.WriteLine(string)
    //   - DateTime DateTime.Now 
    //   - DayOfWeek DateTime.DayOfWeek() (Get)
    //   - int DateTime.DaysInMonth(int, int)
    //   - long DateTime.Day() (Get)
    //   - long DateTime.Month() (Get)
    //   - long DateTime.Ticks() (Get)
    //   - long DateTime.Year() (Get)
    //   - string Console.ReadLine()
    //   - string DateTime.ToLongDateString()
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      DateTime dtmInfo = new DateTime(DateTime.Now.Ticks);

      Console.WriteLine("Date: " + dtmInfo.Day + "/" + dtmInfo.Month + "/" + dtmInfo.Year);
      Console.WriteLine("Date: " + dtmInfo.ToLongDateString());
      Console.WriteLine("Today is: " + dtmInfo.DayOfWeek);
      Console.WriteLine("Days in February, 2008: " + DateTime.DaysInMonth(2008, 2));
      Console.ReadLine();
    }
    // Main()

  }
  // cpClass

}
// Class