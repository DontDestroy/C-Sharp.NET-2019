//***
// Action
//   - Demo of looping and filling a textbox
// Created
//   - CopyPaste � 20230807 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230807 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmForNext : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    internal System.Windows.Forms.TextBox txtResult;
    internal System.Windows.Forms.Button cmdLoop;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmForNext));
      this.txtResult = new System.Windows.Forms.TextBox();
      this.cmdLoop = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // txtResult
      // 
      this.txtResult.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left)));
      this.txtResult.Location = new System.Drawing.Point(32, 72);
      this.txtResult.Multiline = true;
      this.txtResult.Name = "txtResult";
      this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtResult.Size = new System.Drawing.Size(224, 176);
      this.txtResult.TabIndex = 3;
      this.txtResult.Text = "";
      // 
      // cmdLoop
      // 
      this.cmdLoop.Location = new System.Drawing.Point(96, 24);
      this.cmdLoop.Name = "cmdLoop";
      this.cmdLoop.TabIndex = 2;
      this.cmdLoop.Text = "&Loop";
      this.cmdLoop.Click += new System.EventHandler(this.cmdLoop_Click);
      // 
      // frmForNext
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.txtResult);
      this.Controls.Add(this.cmdLoop);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmForNext";
      this.Text = "For ... Next";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmForNext'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmForNext()
      //***
      // Action
      //   - Create instance of 'frmForNext'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdLoop_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define the way of entering a new line
      //   - Loop from 1 till 25
      //     - Add Line + actual number to the result
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int intCounter;
      string strWrap;

      strWrap = Environment.NewLine;

      for (intCounter = 1; intCounter <= 25; intCounter++)
      {
        txtResult.Text += "Line " + intCounter + strWrap;
      }
      // intCounter = 26

    }
    // cmdLoop_Click(System.Object, System.EventArgs) Handles cmdLoop.Click
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmForNext
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmForNext());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmForNext

}
// CopyPaste.Learning