﻿//***
// Action
//   - Implementation of a cpFlyWithWings
//		 - The way a thing moves in the air using wings
// Created
//   - CopyPaste – 20240727 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240727 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Animal.Library
{

	public class cpFlyWithWings : cpiFly
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpFlyWithWings
		/// </summary>
		public cpFlyWithWings()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - cpMallardDuck() (indirectly, thru delegate)
		//   - cpRedHeadDuck() (indirectly, thru delegate)
		//   - cpWoodDuck() (indirectly, thru delegate)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpFlyWithWings()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing moves in the air using wings
		/// </summary>
		public void Fly()
		//***
		// Action
		//   - Define how something is flying with wings
		// Called by
		//   - cpMallardDuck()
		//   - cpRedHeadDuck()
		//   - cpWoodDuck()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Something is moving around in the air using wings");
		}
		// Fly()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpFlyWithWings

}
// CopyPaste.Game.Animal.Library