﻿//***
// Action
//   - Implementation of a cpRoadVehicle
// Created
//   - CopyPaste – 20260128 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260128 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpRoadVehicle : cpVehicle
  {

    #region "Constructors / Destructors"

    public cpRoadVehicle(): this("1FA6P8CF3G5100000", 4, 180, 30)
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpCar()
    //   - cpProgram.Main()
    // Calls
    //   - cpVehicle(string, int, int)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpRoadVehicle()

    public cpRoadVehicle(string strVehicleIdentificationNumber, uint intWheelCount, uint intMaximumSpeedForward, uint intMaximumSpeedBackward)
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpCar(string, uint, uint, uint)
    //   - cpProgram.Main()
    //   - cpVehicle()
    // Calls
    //   - CurrentSpeed(int) (Set)
    //   - DirectionForward(bool) (Set)
    //   - MaximumSpeedBackward(uint) (Set)
    //   - MaximumSpeedForward(uint) (Set)
    //   - VehicelIndentificationNumber(string) (Set)
    //   - WheelCount(uint) (Set)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      DirectionForward = true;
      CurrentSpeed = 0;
      VehicleIdentificationNumber = strVehicleIdentificationNumber;
      WheelCount = intWheelCount;
      MaximumSpeedForward = intMaximumSpeedForward;
      MaximumSpeedBackward = intMaximumSpeedBackward;
    }
    // cpRoadVehicle(string, uint, uint, uint)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public override uint CurrentSpeed
    {

      get
      //***
      // Action Get
      //   - Return _currentSpeed
      // Called by
      //   - BreakingDown(uint)
      //   - DirectionForward(bool) (Set)
      //   - MaximumSpeedBackward(uint) (Set)
      //   - MaximumSpeedForward(uint) (Set)
      //   - SpeedingUp(uint)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        return _currentSpeed;
      }
      // uint CurrentSpeed (Get)

      set
      //***
      // Action Set
      //   - If you are moving forward
      //     - If the value is larger than the maximum speed forward
      //       - _currentSpeed becomes maximum speed forward
      //     - If not
      //       - _currentSpeed becomes value
      //   - If not (you are moving backward)
      //     - If the value is larger than the maximum speed backward
      //       - _currentSpeed becomes maximum speed backward
      //     - If not
      //       - _currentSpeed becomes value
      // Called by
      //   - BreakingDown(uint)
      //   - cpProgram.Main()
      //   - cpRoadVehicle(string, uint, uint, uint)
      //   - DirectionForward(bool) (Set)
      //   - MaximumSpeedBackward(uint) (Set)
      //   - MaximumSpeedForward(uint) (Set)
      //   - SpeedingUp(uint)
      // Calls
      //   - bool DirectionForward (Get)
      //   - uint MaximumSpeedBackward (Get)
      //   - uint MaximumSpeedForward (Get)
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {

        if (DirectionForward)
        {

          if (value > MaximumSpeedForward)
          {
            _currentSpeed = MaximumSpeedForward;
          }
          else
          // value <= MaximumSpeedForward
          {
            _currentSpeed = value;
          }
          // value > MaximumSpeedForward

        }
        else
        // Not DirectionForward
        {

          if (value > MaximumSpeedBackward)
          {
            _currentSpeed = MaximumSpeedBackward;
          }
          else
          // value <= MaximumSpeedBackward
          {
            _currentSpeed = value;
          }
          // value > MaximumSpeedBackward

        }
        // DirectionForward

      }
      // CurrentSpeed(uint) (Set)

    }
    // uint CurrentSpeed

    public override bool DirectionForward
    {

      get
      //***
      // Action Get
      //   - Return _drivingForward
      // Called by
      //   - ChangeDirection()
      //   - CurrentSpeed(uint) (Set)
      //   - DirectionForward(bool) (Set)
      //   - MaximumSpeedBackward(uint) (Set)
      //   - MaximumSpeedForward(uint) (Set)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        return _drivingForward;
      }
      // bool DirectionForward (Get)

      set
      //***
      // Action Set
      //   - _drivingForward becomes value
      //   - If driving forward
      //     - If current speed is larger than maximum speed forward
      //       - current speed is changed to maximum
      //     - If not
      //       - Nothing happens
      //  - If not (driving backwards)  
      //     - If current speed is larger than maximum speed backwards
      //       - current speed is changed to maximum
      //     - If not
      //       - Nothing happens
      // Called by
      //   - ChangeDirection()
      //   - cpProgram.Main()
      //   - cpRoadVehicle(string, uint, uint, uint)
      // Calls
      //   - bool DirectionForward (Get)
      //   - CurrentSpeed(int) (Set)
      //   - uint CurrentSpeed (Get)
      //   - uint MaximumSpeedBackward (Get)
      //   - uint MaximumSpeedForward (Get)
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        _drivingForward = value;

        if (DirectionForward)
        {

          if (CurrentSpeed > MaximumSpeedForward)
          {
            CurrentSpeed = MaximumSpeedForward;
          }
          else
          // CurrentSpeed > MaximumSpeedForward
          {
          }
          // CurrentSpeed <= MaximumSpeedForward

        }
        else
        // Not DirectionForward
        {

          if (CurrentSpeed > MaximumSpeedBackward)
          {
            CurrentSpeed = MaximumSpeedBackward;
          }
          else
          // CurrentSpeed > MaximumSpeedBackward
          {
          }
          // CurrentSpeed <= MaximumSpeedBackward

        }
        // DirectionForward

      }
      // DirectionForward(bool) (Set)

    }
    // bool DirectionForward

    public override uint MaximumSpeedBackward 
    {

      get
      //***
      // Action Get
      //   - Return _maximumSpeedBackward
      // Called by
      //   - CurrentSpeed(uint) (Set)
      //   - DirectionForward(bool) (Set)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        return _maximumSpeedBackward;
      }
      // uint MaximumSpeedBackward (Get)

      set
      //***
      // Action Set
      //   - _maximumSpeedBackward becomes value
      //   - If driving forward
      //     - Nothing happens
      //   - If not (driving backwards)
      //     - If current speed is higher than value
      //       - Current speed becomes value
      //     - If not
      //       - Nothing happens
      // Called by
      //   - cpProgram.Main()
      //   - cpRoadVehicle(string, uint, uint, uint)
      // Calls
      //   - bool DirectionForward (Get)
      //   - CurrentSpeed(uint) (Get)
      //   - int CurrentSpeed (Get)
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        _maximumSpeedBackward = value;

        if (DirectionForward)
        {
        }
        else
        // Not DirectionForward
        {

          if (CurrentSpeed > value)
          {
            CurrentSpeed = value;
          }
          else
          // CurrentSpeed <= value
          {
          }
          // CurrentSpeed > value

        }
        // DirectionForward

      }
      // MaximumSpeedBackward(uint) (Set)

    }
    // uint MaximumSpeedBackward 

    public override uint MaximumSpeedForward
    {

      get
      //***
      // Action Get
      //   - Return _maximumSpeedForward
      // Called by
      //   - CurrentSpeed(int) (Set)
      //   - DirectionForward(bool) (Set)
      //   - MaximumSpeedBackward(uint) (Set)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        return _maximumSpeedForward;
      }
      // uint MaximumSpeedForward (Get)

      set
      //***
      // Action Set
      //   - _maximumSpeedForward becomes value
      //   - If driving forward
      //     - If current speed is higher than value
      //       - Current speed becomes value
      //     - If not
      //       - Nothing happens
      //   - If not (driving backwards)
      //     - Nothing happens
      // Called by
      //   - cpProgram.Main()
      //   - cpRoadVehicle(string, uint, uint, uint)
      // Calls
      //   - bool DirectionForward (Get)
      //   - CurrentSpeed(uint) (Set)
      //   - uint CurrentSpeed (Get)
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        _maximumSpeedForward = value;

        if (DirectionForward)
        {

          if (CurrentSpeed > value)
          {
            CurrentSpeed = value;
          }
          else
          // CurrentSpeed <= value
          {
          }
          // CurrentSpeed > value

        }
        else
        // Not DirectionForward
        {
        }
        // DirectionForward

      }
      // MaximumSpeedForward(uint) (Set)

    }
    // uint MaximumSpeedForward 

    public override string VehicleIdentificationNumber
    {
      
      get
      //***
      // Action Get
      //   - Return _vehicleIdentificationNumber
      // Called by
      //   - cpCar.VehicleIdentificationNumberCheck(cpCar)
      //   - cpSuv.VehicleIdentificationNumberCheck(cpSuv)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        return _vehicleIdentificationNumber;
      }
      // string VehicleIdentificationNumber (Get)

      set
      //***
      // Action Set
      //   - _vehicleIdentificationNumber becomes value
      // Called by
      //   - cpProgram.Main()
      //   - cpRoadVehicle(string, uint, uint, uint)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        _vehicleIdentificationNumber = value;
      }
      // VehicleIdentificationNumber(string) (Set)

    }
    // string VehicleIdentificationNumber

    public override uint WheelCount
    {

      get
      //***
      // Action Get
      //   - Return _wheelCount
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        return _wheelCount;
      }
      // uint WheelCount (Get)

      set
      //***
      // Action Set
      //   - _wheelCount becomes value
      // Called by
      //   - cpProgram.Main()
      //   - cpRoadVehicle(string, uint, uint, uint)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        _wheelCount = value;
      }
      // WheelCount(uint) (Set)

    }
    // uint WheelCount 

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override void BreakingDown(uint intVelocity)
    //***
    // Action
    //   - The speed can't go below zero
    //     - If slowing down is bigger than the current speed
    //       - You are standing still
    //       - Current speed becomes zero
    //     - If not
    //       - Slow down the road vehicle with the velocity going down
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - CurrentSpeed(uint) (Set)
    //   - int CurrentSpeed() (Get)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      if (CurrentSpeed < intVelocity)
      {
        CurrentSpeed = 0;
      }
      else
      // CurrentSpeed >= intVelocity
      {
        CurrentSpeed -= intVelocity;
      }
      // CurrentSpeed < intVelocity

    }
    // BreakingDown(uint)

    public override void ChangeDirection()
    //***
    // Action
    //   - You switch from moving forward to moving backwards and vice versa
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - bool DirectionForward() (Get)
    //   - DirectionForward(bool) (Set)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      DirectionForward = !DirectionForward;
    }
    // ChangeDirection()

    public override void SpeedingUp(uint intVelocity)
    //***
    // Action
    //   - The speed can't go above maximum speed (handled with the properties
    //   - Speed up the road vehicle with the velocity going up
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - CurrentSpeed(uint) (Set)
    //   - int CurrentSpeed() (Get)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      CurrentSpeed += intVelocity;
    }
    // SpeedingUp(uint)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpVehicle

}
// CopyPaste.Learning