//***
// Action
//   - A block game, the moves
//   - Working with properties (Get and Set) and methods in several classes, that can be used in another game
//   - Possible Solution 2
// Created
//   - CopyPaste � 20240214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240214 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.Games
{

  public class cpMove
  {

    #region "Constructors / Destructors"

    public cpMove(Control ctlMovingObject, Rectangle recBoundaries, double dblDirection, int lngSpeed)
      //***
      // Action
      //   - Creating an instance of cpMove with given parameters
      // Called by
      //   - frmBlock.frmBlock_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - Degree(double) (Set)
      //   - MoveBoundaries(Rectangle) (Set)
      //   - MovingObject(Control) (Set)
      //   - Speed(int) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MovingObject = ctlMovingObject;
      MoveBoundaries = recBoundaries;
      Speed = lngSpeed;
      Degree = dblDirection;
    }
    // cpMove(Control, Rectangle, double, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private Control mctlObject;
    private double mdblDegree;
    private double mdblRadian;
    private double mdblSpeedFactor;
    private int mlngSpeed;
    private PointF mpntExactPosition;
    private Point mpntScreenPosition;
    private Rectangle mrecBoundaries;
    private Rectangle mrecMoveBoundaries;
    private Single msngExactPositionX;
    private Single msngExactPositionY;

    #endregion

    #region "Properties"

    public Rectangle Boundaries
    {
      
      get
        //***
        // Action Get
        //   - Return the rectangle of the moving object (mrecBoundaries)
        // Called by
        //   - bool cpCollision.Hit(cpMove, cpMove)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mrecBoundaries;
      }
      // Rectangle Boundaries (Get)

      set
        //***
        // Action Set
        //   - Set the rectangle of the moving object (mrecBoundaries becomes value)
        // Called by
        //   - MovingObject(Control) (Set)
        //   - ScreenPosition(Point) (Set)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mrecBoundaries = value;
      }
      // Boundaries(Rectangle) (Set)

    }
    // Rectangle Boundaries

    public double Degree
    {

      get
        //***
        // Action Get
        //   - Return the Degrees of the moving object (mdblDegree)
        // Called by
        //   - Bounce(double)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdblDegree;
      }
      // double Degree (Get)

      set
        //***
        // Action Set
        //   - Set the Degrees of the moving object (mdblDegree becomes dblValue)
        //   - Calculate the Radians (mdblRadian) (2 * PI radians in a full circle)
        // Called by
        //   - Bounce(double)
        //   - cpMove(Control, Rectangle, double, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mdblDegree = value % 360;
        mdblRadian = mdblDegree * Math.PI / 180;
      }
      // Degree(double) (Set)

    }
    // double Degree

    public PointF ExactPosition
    {

      get
        //***
        // Action Get
        //   - Return the ExactPosition of the moving object (mpntExactPosition)
        // Called by
        //   - Move()
        //   - MovingObject(Control) (Set)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mpntExactPosition;
      }
      // PointF ExactPosition (Get)

      set
        //***
        // Action Set
        //   - Set the ExactPosition of the moving object (mpntExactPosition becomes value)
        //   - ExactPositionX becomes pntValue X coordinate
        //   - ExactPositionY becomes pntValue Y coordinate
        // Called by
        //   - Move()
        // Calls
        //   - ExactPositionX(Single) (Set)
        //   - ExactPositionY(Single) (Set)
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mpntExactPosition = value;
        ExactPositionX = value.X;
        ExactPositionY = value.Y;
      }
      // ExactPosition(PointF) (Set)

    }
    // PointF ExactPosition()

    public Single ExactPositionX
    {

      get
        //***
        // Action Get
        //   - Return the X coordinate of ExactPosition of the moving object (msngExactPositionX)
        // Called by
        //   - Move()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return msngExactPositionX;
      }
      // Single ExactPositionX (Get)

      set
        //***
        // Action Set
        //   - Set the X coordinate of ExactPosition of the moving object (msngExactPositionX becomes value)
        // Called by
        //   - ExactPosition(PointF) (Set)
        //   - Move()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        msngExactPositionX = value;
      }
      // ExactPositionX(Single) (Set)

    }
    // Single ExactPositionX()

    public Single ExactPositionY
    {

      get
        //***
        // Action Get
        //   - Return the Y coordinate of ExactPosition of the moving object (msngExactPositionX)
        // Called by
        //   - Move()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return msngExactPositionY;
      }
      // Single ExactPositionY (Get)

      set
        //***
        // Action Set
        //   - Set the Y coordinate of ExactPosition of the moving object (msngExactPositionX becomes value)
        // Called by
        //   - ExactPosition(PointF) (Set)
        //   - Move()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        msngExactPositionY = value;
      }
      // ExactPositionY(Single) (Set)

    }
    // Single ExactPositionX()
    
    public Rectangle MoveBoundaries
    {
      
      get
        //***
        // Action Get
        //   - Return the rectangle that is moving (mrecMoveBoundaries)
        // Called by
        //   - Move()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - When the moving object is not a Rectangle, the behaviour of moving can will be wrong
        //***
      {
        return mrecMoveBoundaries;
      }
      // Rectangle MoveBoundaries (Get)

      set
        //***
        // Action Set
        //   - Set the rectangle that is moving (mrecMoveBoundaries becomes value)
        // Called by
        //   - cpMove(Control, Rectangle, double, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - When the moving object is not a Rectangle, the behaviour of moving can will be wrong
        //***
      {
        mrecMoveBoundaries = value;
      }
      // MoveBoundaries(Rectangle) (Set)

    }
    // Rectangle MoveBoundaries

    public Control MovingObject
    {

      get
        //***
        // Action Get
        //   - Return the object that is moving (mctlObject)
        // Called by
        //   - bool cpCollision.Hit(cpMove, cpMove)
        //   - Move()
        //   - ScreenPosition(Point) (Set)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mctlObject;
      }
      // Control MovingObject (Get)

      set
        //***
        // Action Set
        //   - Set the object that is moving (mctlObject becomes value)
        //   - Set the screen position to the TopLeft of the object
        //   - Set the Exact position to the TopLeft of the object
        //   - Determine the boundaries of the object (rectangle Left, Top, Width, Height)
        // Called by
        //   - cpMove(Control, Rectangle, double, int)
        //   - frmBlock.panMovingArea_MouseMove(System.Object, System.Windows.Forms.MouseEventArgs) Handles panMovingArea.MouseMove
        // Calls
        //   - Boundaries(Rectangle) (Set)
        //   - ExactPosition(PointF) (Set)
        //   - Point ScreenPosition (Get)
        //   - ScreenPosition(Point) (Set)
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mctlObject = value;
        ScreenPosition = new Point(value.Left, value.Top);
        ExactPosition = new PointF(value.Left, value.Top);
        Boundaries = new Rectangle(ScreenPosition.X, ScreenPosition.Y, value.Width, value.Height);
      }
      // MovingObject(Control) (Set)

    }
    // Control MovingObject 

    public double Radian
    {

      get
        //***
        // Action Get
        //   - Return the Radians of the moving object (mdblRadian)
        // Called by
        //   - Move()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdblRadian;
      }
      // double Radian (Get)

      set
        //***
        // Action Set
        //   - Set the Degrees of the moving object (mdblRadian becomes value)
        //   - Calculate the Degree (mdblDegree) (360 degrees in a full circle)
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mdblRadian = value % (2 * Math.PI);
        mdblDegree = mdblDegree * 180 / Math.PI;
      }
      // Radian(double) (Set)

    }
    // double Radian

    public Point ScreenPosition
    {

      get
        //'***
        //' Action Get
        //'   - Return the screen position of the moving object (mpntScreenPosition)
        //' Called by
        //'   - Move()
        //'   - MovingObject(Control) (Set)
        //' Calls
        //'   - 
        //' Created
        //'   - CopyPaste � 20240214 � VVDW
        //' Changed
        //'   - CopyPaste � yyyymmdd � VVDW � What changed
        //' Tested
        //'   - CopyPaste � 20240214 � VVDW
        //' Keyboard key
        //'   - 
        //' Proposal (To Do)
        //'   - 
        //'***
      {
        return mpntScreenPosition;
      }
      // Point ScreenPosition (Get)

      set
        //***
        // Action Set
        //   - Set the screen position of the moving object (mpntScreenPosition becomes value)
        //   - Set the left of the moving object to the X-coordinate
        //   - Set the left of the moving object to the Y-coordinate
        //   - Determine the boundaries of the moving object (a rectangle)
        // Called by
        //   - Move()
        //   - MovingObject(Control) (Set)
        // Calls
        //   - Boundaries(Rectangle) (Set)
        //   - Control MovingObject (Get)
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mpntScreenPosition = value;
        MovingObject.Left = value.X;
        MovingObject.Top = value.Y;
        Boundaries = new Rectangle(value.X, value.Y, MovingObject.Width, MovingObject.Height);
      }
      // ScreenPosition(Point) (Set)

    }
    // Point ScreenPosition

    public int Speed
    {

      get
        //***
        // Action Get
        //   - Return the speed of the moving object (mlngSpeed)
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngSpeed;
      }
      // int Speed (Get)

      set
        //***
        // Action Set
        //   - Set the speed of the moving object (mlngSpeed becomes value)
        //   - Depending on value
        //     - Case lower than zero
        //       - mlngSpeed becomes 0
        //     - Case larger than ten
        //       - mlngSpeed becomes 10
        //     - Other cases
        //       - mlngSpeed becomes value
        //   - SpeedFactor becomes mlngSpeed
        // Called by
        //   - cpMove(Control, Rectangle, double, int)
        // Calls
        //   - SpeedFactor(double) (Set)
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value < 0)
        {
          mlngSpeed = 0;
        }
        else if (value > 10)
          // value >= 0
        {
          mlngSpeed = 10;
        }
        else
          // value >= 0
          // value <= 10
        {
          mlngSpeed = value;
        }

        SpeedFactor = mlngSpeed;
      }
      // Speed(int) (Set)

    }
    // int Speed

    public double SpeedFactor
    {

      get
        //***
        // Action Get
        //   - Return the speed factor of the moving object (mlngSpeedFactor)
        // Called by
        //   - Move()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdblSpeedFactor;
      }
      // double SpeedFactor (Get)

      set
        //***
        // Action Set
        //   - Set the speed factor of the moving object (mlngSpeedFactor becomes value)
        //   - Add 30 percent to the speed
        // Called by
        //   - Speed(int) (Set)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mdblSpeedFactor = value * 1.3;
      }
      // SpeedFactor(double) (Set)

    }
    // double SpeedFactor

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Bounce(double dblDegreeBounceInto)
      //***
      // Action
      //   - After that the moving object hits something, it should bounce back
      //   - Degrees of bouncing back is 
      //     - 360 (2*PI*Radian) minus ...
      //     - Direction plus ...
      //     - Two times the hitting angle of the bounce
      //   - An example
      //     - You are moving with an angle of 45 degrees, and you bounce into it on 90 degrees
      //       - Bounce back at 135 degrees
      //     - Picture is not 100% accurate, but explains it well
      //
      //      135�\ |
      //           \|
      //           /|
      //          / |
      //         /  |
      //        /   |
      //       /45� |90�
      //       --------
      //   - A second example
      //     - You are moving with an angle of 45 degrees, and you bounce into it on 180 degrees
      //       - Bounce back at 315 degrees
      //     - Picture is not 100% accurate, but explains it well
      //
      //       ----------- 180�
      //           /\
      //          /  \
      //         /    \315�
      //        /   
      //       /45� 
      //       --------
      //
      // Called by
      //   - bool cpCollision.Hit(cpMove, cpMove)
      //   - Move()
      // Calls
      //   - Degree(double) (Set)
      //   - double Degree (Get)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Degree = (360 - Degree + 2 * dblDegreeBounceInto) % 360;
    }
    // Bounce(double)

    public void Move()
      //***
      // Action
      //   - Move an object
      //   - If SpeedFactor equals zero
      //     - There is no movement
      //   - If Not
      //     - ExactPositionX is updated to the new position
      //     - ExactPositionY is updated to the new position
      //     - ExactPosition is determined
      //     - ScreenPosition is determined (not the same as ExactPosition, due to pixels)
      //       - e.g. when movement is very slow
      //     - Depending on X coordinate of ScreenPositionX (is it going out of the move boundaries)
      //       - Case smaller or equal than the X coordinate of the MoveBoundaries
      //         - Bounce back with 90 degrees
      //       - Case larger or equal than the width of the MoveBoundaries minus the width of the moving object
      //         - Bounce back with 90 degrees
      //       - Case else
      //         - Do Nothing
      //     - Depending on Y coordinate of ScreenPositionY (is it going out of the move boundaries)
      //       - Case smaller or equal than the Y coordinate of the MoveBoundaries
      //         - Bounce back with 0 degrees
      //       - Case larger or equal than the height of the MoveBoundaries minus the height of the moving object
      //         - Bounce back with 0 degrees
      //       - Case else
      //         - Do Nothing
      // Called by
      //   - frmBlock.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      //   - frmMoveTest.tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - Bounce(double)
      //   - Control MovingObject (Get)
      //   - double Radian (Get)
      //   - double SpeedFactor (Get)
      //   - ExactPosition(PointF) (Set)
      //   - ExactPositionX(Single) (Set)
      //   - ExactPositionY(Single) (Set)
      //   - Point ScreenPosition (Get)
      //   - PointF ExactPosition (Get)
      //   - Rectangle MoveBoundaries (Get)
      //   - ScreenPosition(Point) (Set)
      //   - Single ExactPositionX() (Get)
      //   - Single ExactPositionY (Get)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (SpeedFactor == 0)
      {
      }
      else
        // SpeedFactor <> 0
      {
        ExactPositionX += Convert.ToSingle(Math.Cos(Radian) * SpeedFactor);
        ExactPositionY -= Convert.ToSingle(Math.Sin(Radian) * SpeedFactor);
        ExactPosition = new PointF(ExactPositionX, ExactPositionY);
        ScreenPosition = Point.Ceiling(ExactPosition);

        if (ScreenPosition.X <= MoveBoundaries.X)
        {
          Bounce(90);
        }
        else if (ScreenPosition.X >= (MoveBoundaries.Width - MovingObject.Width))
          // ScreenPosition.X > MoveBoundaries.X
        {
          Bounce(90);
        }
        else
          // ScreenPosition.X > MoveBoundaries.X
          // ScreenPosition.X < (MoveBoundaries.Width - MovingObject.Width)
        {
        }
        // ScreenPosition.X <= MoveBoundaries.X
        // ScreenPosition.X >= (MoveBoundaries.Width - MovingObject.Width)

        if (ScreenPosition.Y <= MoveBoundaries.Y)
        {
          Bounce(0);
        }
        else if (ScreenPosition.Y >= (MoveBoundaries.Height - MovingObject.Height))
          // ScreenPosition.Y > MoveBoundaries.Y
        {
          Bounce(0);
        }
        else
          // ScreenPosition.Y > MoveBoundaries.Y
          // ScreenPosition.Y < (MoveBoundaries.Height - MovingObject.Height)
        {
        }
        // ScreenPosition.Y <= MoveBoundaries.Y
        // ScreenPosition.Y >= (MoveBoundaries.Height - MovingObject.Height)

      }
      // SpeedFactor = 0

    }
    // Move()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCollision

}
// CopyPaste.Learning.Games