//***
// Action
//   - Definition of a cpPaperValue
// Created
//   - CopyPaste � 20240105 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240105 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;

namespace CopyPaste.Learning
{

	public class cpPaperValue : cpiSaveMethod
	{

		#region "Constructors / Destructors"

		public cpPaperValue(decimal decAmount, int lngRunTime, decimal decIntrest, DateTime dtmBuy, cpClient thecpClient)
			//***
			// Action
			//   - Constructor with 5 arguments
			//   - An amount, a run time (length), an intrest rate, a buy date and an owner
			//   - Set the properties with the given argument
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - Amount(decimal) (Set)
			//   - Buy(DateTime) (Set)
			//   - Intrest(decimal) (Set)
			//   - Owner(cpClient) (Set)
			//   - RunTime(int) (Set)
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
  	{
      Amount = decAmount;
      Buy = dtmBuy;
      Intrest = decIntrest;
      Owner = thecpClient;
      RunTime = lngRunTime;
		}
		// cpPaperValue(decimal, int, decimal, DateTime, cpClient)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private cpClient mcpClient;
		private DateTime mdtmBuy;
		private decimal mdecAmount;
		private decimal mdecIntrest;
		private int mlngRunTime;

		#endregion

		#region "Properties"

		public decimal Amount
		{
			
			get
				//***
				// Action Get
				//   - Returns mdecAmount
				// Called by
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mdecAmount;
			}
			// decimal Amount (Get)

			set
				//***
				// Action Set
				//   - mdecAmount becomes value
				// Called by
				//   - cpPaperValue(decimal, int, decimal, DateTime, cpClient)
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				mdecAmount = value;
			}
			// Amount(decimal) (Set)

		}
		// decimal Amount

		public DateTime Buy
		{
			
			get
				//***
				// Action Get
				//   - Returns mdtmBuy
				// Called by
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mdtmBuy;
			}
			// DateTime Buy (Get)

			set
				//***
				// Action Set
				//   - If the value is after or equal first of January 1900
				//     - mdtmBuy becomes value
				//   - If not
				//     - Throw error message
				// Called by
				//   - cpPaperValue(decimal, int, decimal, DateTime, cpClient)
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{

				if (value >= new DateTime(1900, 1, 1))
				{
					mdtmBuy = value;
				}
				else
					// value < new DateTime(1900, 1, 1)
				{
					throw new ApplicationException("Wrong date");
				}
				// value >= new DateTime(1900, 1, 1)

			}
			// Buy(DateTime) (Set)

		}
		// DateTime Buy

		public decimal Intrest
		{
			
			get
				//***
				// Action Get
				//   - Returns mdecIntrest
				// Called by
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mdecIntrest;
			}
			// decimal Intrest (Get)

			set
				//***
				// Action Set
				//   - Checks if value is positive or zero
				//	 - If check is correct
				//     - mdecIntrest becomes value
				//   - If not
				//     - Throw error message
				// Called by
				//   - cpPaperValue(decimal, int, decimal, DateTime, cpClient)
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{

				if (value >= 0)
				{
					mdecIntrest = value;
				}
					// value < 0
				else
				{
					throw new ApplicationException("Intrest % is not acceptable");
				}
				// value >= 0

			}
			// Intrest(decimal) (Set)

		}
		// decimal Intrest

		public cpClient Owner
		{
			
			get
				//***
				// Action Get
				//   - Returns mcpClient
				// Called by
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mcpClient;
			}
			// cpClient Owner (Get)

			set
				//***
				// Action Set
				//   - mcpClient becomes value
				// Called by
				//   - cpPaperValue(decimal, int, decimal, DateTime, cpClient)
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				mcpClient = value;
			}
			// Owner(cpClient) (Set)

		}
		// cpClient Owner

		public int RunTime
		{
			
			get
				//***
				// Action Get
				//   - Returns mlngRunTime
				// Called by
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mlngRunTime;
			}
			// int RunTime (Get)

			set
				//***
				// Action Set
				//   - Checks if value is negative or zero
				//	 - If check is correct
				//     - mlngRunTime becomes value
				//   - If not
				//     - Throw error message
				// Called by
				//   - cpPaperValue(decimal, int, decimal, DateTime, cpClient)
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
        mlngRunTime = value;
			}
			// RunTime(int) (Set)

		}
		// int RunTime

		#endregion

		#region "Methods"

		#region "Overrides"
		
		public override string ToString()
			//***
			// Action
			//   - Return the buy date, the amount, the run time, the intrest rate and the owner
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - DateTime Buy (Get)
			//   - decimal Amount (Get)
			//   - decimal Intrest (Get)
			//   - int RunTime (Get)
			//   - string cpClient.ToString()
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
      string strInfo;

			strInfo = "Buy date: " + Buy + ControlChars.CrLf;
			strInfo = strInfo + "Amount: " + Amount + ControlChars.CrLf;
			strInfo = strInfo + "Run time: " + RunTime + ControlChars.CrLf;
			strInfo = strInfo + "Intrest: " + Intrest + ControlChars.CrLf;
			strInfo = strInfo + Owner.ToString();
      
			return strInfo;
		}
		// string ToString()

		#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpPaperValue

}
// CopyPaste.Learning