﻿//***
// Action
//   - Having dataviews in database actions
// Created
//   - CopyPaste – 20210818 – VVDW
// Changed
//   - Organisation – yyyym– Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210818 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace EditingWizard
{
  public partial class frmEditingWizard : Form
  {

    #region "Constructors / Destructors"

    public frmEditingWizard()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Fill DataSet Employee with DataAdapter
    //   - Show the info of the current row (record)
    // Called by
    //   - User Action (Starting form)
    // Calls
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
      tbaEmployee.Fill(dsEmployee.tblCPEmployee);
      UpdateDisplay();
    }
    // frmEditingWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAccept_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Accept the changes in the dataset
    //   - Show the info of the current row (record)
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      dsEmployee.AcceptChanges();
      UpdateDisplay();
    }
    // cmdAccept_Click(System.Object, System.EventArgs)

    private void cmdAdd_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a new DataRow (drwNew)
    //   - drwNew becomes a new row of tblCPEmployee of dsEmployee
    //   - Set the value for "strFirstName"
    //   - Set the value for "strLastName"
    //   - Add drwNew to the rows of tblCPEmployee
    //   - Go to the last row
    //   - Set focus to txtFirstName
    // Called by
    //   - GetRow() As DataRow
    //   - User action (Clicking a button) 
    // Calls
    //   - cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast_Click
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //   - Learn also the systax of the code in comment
    //***
    {
      DataRow drwNew;

      drwNew = dsEmployee.tblCPEmployee.NewRow();
      drwNew["strFirstName"] = "New First";
      drwNew["strLastName"] = "New Last";
      dsEmployee.tblCPEmployee.Rows.Add(drwNew);
      cmdLast.PerformClick();
      txtFirstName.Focus();

      // dsEmployee.tblCPEmployeeRow drwNewEmployee;

      // drwNewEmployee = this.dsEmployee.tblCPEmployee.NewtblCPEmployeeRow();
      // drwNewEmployee["strFirstName"] = "New First";
      // drwNewEmployee["strLastName"] = "New Last";
      // this.dsEmployee.tblCPEmployee.AddtblCPEmployeeRow(drwNewEmployee);
      // cmdLast.PerformClick();
      // txtFirstName.Focus();
    }
    // cmdAdd_Click(System.Object, System.EventArgs)

    private void cmdCommand_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a DataRow (Current Row)
    //   - Define a Command (Update Command)
    //   - Set 3 parameters for the 3 fields (New Version)
    //   - Set 3 parameters for the 3 fields (Original Version)
    //   - Open Connection
    //   - Execute Command
    //   - Close Connection
    //   - Accept the changes
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //   - What must be done to visualize the changes?
    //***
    {
      DataRow drwCurrent;
      SqlCommand cmmUpdate;
      SqlConnection cnncpNorthwindScript;

      cmmUpdate = tbaEmployee.Adapter.UpdateCommand;
      cnncpNorthwindScript = tbaEmployee.Connection;
      drwCurrent = GetRow();

      cmmUpdate.Parameters["@strFirstName"].Value = drwCurrent["strFirstName"].ToString();
      cmmUpdate.Parameters["@strLastName"].Value = drwCurrent["strLastName"].ToString() + " Changed";
      cmmUpdate.Parameters["@intIdEmployee"].Value = drwCurrent["intIdEmployee"].ToString();
      cmmUpdate.Parameters["@Original_intIdEmployee"].Value = drwCurrent["intIdEmployee", DataRowVersion.Original].ToString();
      cmmUpdate.Parameters["@Original_strFirstName"].Value = drwCurrent["strFirstName", DataRowVersion.Original].ToString();
      cmmUpdate.Parameters["@Original_strLastName"].Value = drwCurrent["strLastName", DataRowVersion.Original].ToString();

      cnncpNorthwindScript.Open();
      cmmUpdate.ExecuteNonQuery();
      cnncpNorthwindScript.Close();
    }
    // cmdCommand_Click(System.Object, System.EventArgs)

    private void cmdDefer_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a new DataRow (drwCurrent) (the row to edit)
    //   - Get the current row
    //   - Start editing
    //   - Set the value for "strFirstName"
    //   - Show the proposed version of "strFirstName"
    //   - Cancel editing
    //   - Show the info of the current row (record)
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //   - What does EndEdit do
    //***
    {
      DataRow drwCurrent;

      drwCurrent = GetRow();

      drwCurrent.BeginEdit();
      drwCurrent["strFirstName"] = "Proposed Name";
      MessageBox.Show(drwCurrent["strFirstName", DataRowVersion.Proposed].ToString());
      drwCurrent.CancelEdit();
      // drwCurrent.EndEdit()
      UpdateDisplay();
    }
    // cmdDefer_Click(System.Object, System.EventArgs)

    private void cmdDelete_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a DataRow (drwDelete) (the row to delete)
    //   - Get the current row
    //   - Delete it
    //   - Show the info of the current row (record)
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - GetRow() As DataRow
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //   - What is the difference with the line in comment
    //***
    {
      DataRow drwDelete;

      drwDelete = GetRow();
      drwDelete.Delete();
      UpdateDisplay();

      // dsEmployee.tblCPEmployee.Rows.Remove(drwDelete);
      // MessageBox.Show(drwDelete.RowState.ToString());
      // UpdateDisplay();
    }
    // cmdDelete_Click(System.Object, System.EventArgs)

    private void cmdEdit_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a DataRow (drwCurrent) (the row to edit)
    //   - Get the current row
    //   - Change the firstname
    //   - Show the info of the current row (record)
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - GetRow() As DataRow
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //  - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      DataRow drwCurrent;

      drwCurrent = GetRow();
      drwCurrent["strFirstName"] = "Changed";
      UpdateDisplay();
    }
    // cmdEdit_Click(System.Object, System.EventArgs)

    private void cmdFill_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Remove rows from tblCPEmployee
    //   - Fill rows with current situation
    //   - Show the info of the current row (record)
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      dsEmployee.tblCPEmployee.Clear();
      tbaEmployee.Fill(dsEmployee.tblCPEmployee);
      UpdateDisplay();
    }
    // cmdFill_Click(System.Object, System.EventArgs)

    private void cmdFirst_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Determine the first position within the BindingSource of tblCPEmployee
    //   - Show the info of the current row (record)
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      bdsrcEmployee.Position = 0;
      UpdateDisplay();
    }
    // cmdFirst_Click(System.Object, System.EventArgs)

    private void cmdLast_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Determine the last position within the BindingSource of tblCPEmployee
    //   - Show the info of the current row (record)
    // Called by
    //   - cmdAdd_Click(System.Object, System.EventArgs)
    //   - User action (Clicking a button) 
    // Calls
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      bdsrcEmployee.Position = bdsrcEmployee.Count - 1;
      UpdateDisplay();
    }
    // cmdLast_Click(System.Object, System.EventArgs)

    private void cmdNext_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Determine the next position within the BindingSource of tblCPEmployee
    //   - We need to check if there is a next one
    //   - Show the info of the current row (record)
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (bdsrcEmployee.Position == bdsrcEmployee.Count - 1)
      {
      }
      else
      // (bdsrcEmployee.Position != bdsrcEmployee.Count - 1)
      {
        bdsrcEmployee.Position += 1;
        UpdateDisplay();
      }
      // (bdsrcEmployee.Position == bdsrcEmployee.Count - 1)

    }
    // cmdNext_Click(System.Object, System.EventArgs)

    private void cmdPrevious_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Determine the previous position within the BindingSource of tblCPEmployee
    //   - We need to check if there is a next one
    //   - Show the info of the current row (record)
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      if (bdsrcEmployee.Position == 0)
      {
      }
      else
      // (bdsrcEmployee.Position != 0)
      {
        bdsrcEmployee.Position -= 1;
        UpdateDisplay();
      }
      // (bdsrcEmployee.Position == 0)

    }
    // cmdPrevious_Click(System.Object, System.EventArgs)

    private void cmdReject_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Reject the changes in the dataset
    //   - Show the info of the current row (record)
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.dsEmployee.RejectChanges();
      UpdateDisplay();
    }
    // cmdReject_Click(System.Object, System.EventArgs)

    private void cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a DataRowView with the current row
    //   - End Edit
    //   - Show the info of the current row (record)
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      DataRowView drvDataRowView;

      drvDataRowView = (DataRowView)bdsrcEmployee.Current;
      drvDataRowView.EndEdit();
      UpdateDisplay();
    }
    // cmdSave_Click(System.Object, System.EventArgs)

    private void cmdUpdate_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Update DataAdapter of Employee using table "tblCPEmployee" in DataSet
    //   - Show the info of the current row (record)
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      tbaEmployee.Update(dsEmployee.tblCPEmployee);
      // tbaEmployee.Update(dsEmployee);
      UpdateDisplay();
    }
    // cmdUpdate_Click(System.Object, System.EventArgs)

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private DataRow GetRow()
    //***
    // Action
    //   - Define a DataRowView (drvDataRowView)
    //   - If there is no binding context
    //     - Add a row
    //   - If Not
    //     - Do nothing
    //   - Get the current DataRowView
    //   - Return the Row of the DataRowView
    // Called by
    //   - cmdDefer_Click(System.Object, System.EventArgs) Handles cmdDefer_Click
    //   - cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete_Click
    //   - cmdEdit_Click(System.Object, System.EventArgs) Handles cmdEdit_Click
    //   - UpdateDisplay()
    // Calls
    //   - cmdAdd_Click(System.Object, System.EventArgs) Handles cmdAdd_Click
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      DataRowView drvDataRowView;

      if (bdsrcEmployee.Count == 0)
      {
        cmdAdd.PerformClick();
      }
      else
      // (bdsrcEmployee.Count != 0)
      {
      }
      // (bdsrcEmployee.Count == 0)

      drvDataRowView = (DataRowView)bdsrcEmployee.Current;
      return drvDataRowView.Row;
    }
    // DataRow GetRow()

    private void UpdateDisplay()
    //***
    // Action
    //   - Define a DataRow (drwDataRow)
    //   - Get the current row
    //   - Show Key, FirstName and LastName
    //   - If there is a version
    //     - Show original Key, FirstName and LastName
    //   - If Not
    //     - Show empty original Key, FirstName and LastName
    //   - Depending on the RowState
    //     - Set the correct option button
    //   - Set the correct text for txtPosition (Employee 1 of n)
    // Called by
    //   - cmdAccept_Click(System.Object, System.EventArgs) Handles cmdAccept_Click
    //   - cmdDefer_Click(System.Object, System.EventArgs) Handles cmdDefer_Click
    //   - cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete_Click
    //   - cmdEdit_Click(System.Object, System.EventArgs) Handles cmdEdit_Click
    //   - cmdFill_Click(System.Object, System.EventArgs) Handles cmdFill_Click
    //   - cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst_Click
    //   - cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast_Click
    //   - cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext_Click
    //   - cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious_Click
    //   - cmdReject_Click(System.Object, System.EventArgs) Handles cmdReject_Click
    //   - cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave_Click
    //   - cmdUpdate_Click(System.Object, System.EventArgs) Handles cmdUpdate_Click
    //   - frmEditing()
    // Calls
    //   - DataRow GetRow() 
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      DataRow drwDataRow;
      drwDataRow = GetRow();

      txtCurrentKey.Text = drwDataRow["intIdEmployee"].ToString();
      txtCurrentFirstName.Text = drwDataRow["strFirstName"].ToString();
      txtCurrentLastName.Text = drwDataRow["strLastName"].ToString();

      if (drwDataRow.HasVersion(DataRowVersion.Original))
      {
        txtOriginalKey.Text = drwDataRow["intIdEmployee", DataRowVersion.Original].ToString();
        txtOriginalFirstName.Text = drwDataRow["strFirstName", DataRowVersion.Original].ToString();
        txtOriginalLastName.Text = drwDataRow["strLastName", DataRowVersion.Original].ToString();
      }
      else
      // Not (drwDataRow.HasVersion(DataRowVersion.Original))
      {
        txtOriginalKey.Text = "";
        txtOriginalFirstName.Text = "";
        txtOriginalLastName.Text = "";
      }
      // (drwDataRow.HasVersion(DataRowVersion.Original))

      switch (drwDataRow.RowState)
      {
        case DataRowState.Added:
          optNew.Checked = true;
          break;
        case DataRowState.Deleted:
          optDeleted.Checked = true;
          break;
        case DataRowState.Modified:
          optChanged.Checked = true;
          break;
        case DataRowState.Unchanged:
          optUnchanged.Checked = true;
          break;
      }
      // (drwDataRow.RowState)

     txtPosition.Text = "Employee " +
       (bdsrcEmployee.Position + 1).ToString() +
       " of " + bdsrcEmployee.Count.ToString();
    }
    // UpdateDisplay()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmEditingWizard
}
// EditingWizard