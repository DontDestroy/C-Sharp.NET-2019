﻿//***
// Action
//   - Convert the collaps of something into an invisibility
//   - Convert the expand of something into a visibility
// Created
//   - CopyPaste – 20260409 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260409 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace ProductCategory_WPF_MVVM.Helpers
{

  public class ExpandedToVisibiltyConverter : IValueConverter
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public System.Object Convert(System.Object theValue, Type theType, System.Object theparameter, CultureInfo theCultureInfo)
    //***
    // Action
    //   - If the given value is Expanded
    //     - Return Visibility visible
    //   - If not
    //     - Return Visibility hidden
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260409 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260409 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Visibility theResult;

      if ((bool)theValue)
      {
        theResult = Visibility.Visible;
      }
      else
      // Not (bool)theValue
      {
        theResult = Visibility.Hidden;
      }
      // (bool)theValue

      return theResult;
    }
    // System.Object Convert(System.Object, Type, System.Object, CultureInfo)

    #endregion

    #endregion

    #endregion

    #region "Not used"

    public System.Object ConvertBack(System.Object theValue, Type theType, System.Object theParameter, CultureInfo theCultureInfo)
    //***
    // Action
    //   - We will not use this
    //   - Can be used to convert the value back
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260409 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260409 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return null;
    }
    // System.Object ConvertBack(System.Object, Type, System.Object, CultureInfo)

    #endregion

  }
  // ExpandedToVisibiltyConverter

}
// ProductCategory_WPF_MVVM.Helpers