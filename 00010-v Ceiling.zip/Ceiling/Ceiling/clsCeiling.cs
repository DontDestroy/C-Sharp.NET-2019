//***
// Action
//   - Ceiling (Math) example
//   - Import or not
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Ceiling
{

  class cpCeiling
	{

    static void Main()
    //***
    // Action
    //   - Show some variables at the console screen 
    // Called by
    //   - 
    // Calls
    //   - double System.Math.Ceiling(double)
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(double)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      Console.WriteLine(Math.Ceiling(12.1));
      Console.WriteLine(Math.Ceiling(12.5));
      Console.WriteLine(Math.Ceiling(-12.1));
      Console.WriteLine(Math.Ceiling(-12.8));
      Console.WriteLine();
      // Console.WriteLine(System.Math.Ceiling(12.1));
      // Console.WriteLine(System.Math.Ceiling(12.5));
      // Console.WriteLine(System.Math.Ceiling(-12.1));
      // Console.WriteLine(System.Math.Ceiling(-12.8));
      // Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

  }
  // cpCeiling

}
// Ceiling