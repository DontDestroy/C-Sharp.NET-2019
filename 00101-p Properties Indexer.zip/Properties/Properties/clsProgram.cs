//***
// Action
//   - Testroutine for cpEmployee
// Created
//   - CopyPaste � 20220308 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220308 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Toolkit;
using System;

namespace Properties
{

  class cpProgram
	{

    static void Main()
    //***
    // Action
    //   - Create an instance of cpEmployee
    //   - Give a Name
    //   - Define the wage constants
    //   - Show the values of the properties
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpEmployee.Name(string) (Set)
    //   - cpEmployee.New()
    //   - cpEmployee.Wage(decimal) (Set)
    //   - cpEmployee.WageConstant
    //   - decimal cpEmployee.Wage(WageConstant) (Get)
    //   - string cpEmployee.Name (Get)
    // Created
    //   - CopyPaste � 20220308 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220308 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      cpEmployee thecpEmployee = new cpEmployee();
      
      thecpEmployee.Name = "Vincent";
      thecpEmployee[cpEmployee.WageConstant.Rate] = Convert.ToDecimal(75.0);
      thecpEmployee[cpEmployee.WageConstant.OverTime] = Convert.ToDecimal(75.0 * 1.5);
      thecpEmployee[cpEmployee.WageConstant.Weekend] = Convert.ToDecimal(75.0 * 1.75);
      thecpEmployee[cpEmployee.WageConstant.WeekendOverTime] = Convert.ToDecimal(75.0 * 2.25);

      Console.WriteLine("Name: " + thecpEmployee.Name);
      Console.WriteLine("Rate: " + thecpEmployee[cpEmployee.WageConstant.Rate]);
      Console.WriteLine("OverTime: " + thecpEmployee[cpEmployee.WageConstant.OverTime]);
      Console.WriteLine("Weekend: " + thecpEmployee[cpEmployee.WageConstant.Weekend]);
      Console.WriteLine("Weekend OverTime: " + thecpEmployee[cpEmployee.WageConstant.WeekendOverTime]);
      thecpEmployee = null;
      
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

	}
  // cpProgram

}
// Properties