//***
// Action
//   - Define a hardcoded connection string
// Created
//   - CopyPaste � 20260114 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260114 � VVDW
// Proposal (To Do)
//   -
//***

using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpGeneralRoutines
  {

    #region "Constructors / Destructors"

    public cpGeneralRoutines()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - bool frmTableTryout.PerformTask(string)
      //   - frmNotCorrespondingTryout.frmNotCorrespondingTryout_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmSubQueriesTryout.frmSubQueriesTryout_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmTableDataTryout.cmdExecute_Click(System.Object, System.EventArgs) Handles cmdExecute.Click
      //   - frmUniqueRecordTryout.GenerateData(bool)
      //   - frmUserDefinedFunctionTryout.cmdCreateUDF_Click(System.Object, System.EventArgs) Handles cmdCreateUDF.Click
      //   - frmUserDefinedFunctionTryout.GenerateData()
      //   - frmVariablesTryout.frmVariablesTryout_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmWildcardsTryout.GenerateData()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpGeneralRoutines()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string BuildConnectionString()
      //***
      // Action
      //   - Return a hardcoded connection string
      // Called by
      //   - frmNotCorrespondingTryout.frmNotCorrespondingTryout_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmSubQueriesTryout.frmSubQueriesTryout_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmUniqueRecordTryout.GenerateData(bool)
      //   - frmVariablesTryout.frmVariablesTryout_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmWildcardsTryout.GenerateData()
      //   - SqlClient.SqlConnection GetConnection() 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "";
    }
    // string BuildConnectionString()

    public SqlConnection GetConnection()
      //***
      // Action
      //   - Create a new SQL connection
      //   - Assign the connection string to it
      //   - Return the connection
      // Called by
      //   - bool frmTableTryout.PerformTask(string)
      //   - frmNotCorrespondingTryout.frmNotCorrespondingTryout_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmSubQueriesTryout.frmSubQueriesTryout_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmTableDataTryout.cmdExecute_Click(System.Object, System.EventArgs) Handles cmdExecute.Click
      //   - frmUniqueRecordTryout.GenerateData(bool)
      //   - frmUserDefinedFunctionTryout.cmdCreateUDF_Click(System.Object, System.EventArgs) Handles cmdCreateUDF.Click
      //   - frmUserDefinedFunctionTryout.GenerateData()
      //   - frmVariablesTryout.frmVariablesTryout_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmWildcardsTryout.GenerateData()
      // Calls
      //   - string BuildConnectionString()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return new SqlConnection("");
    }
    // SqlClient.SqlConnection GetConnection()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpGeneralRoutines

}
// CopyPaste.Learning