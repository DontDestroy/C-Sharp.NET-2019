//***
// Action
//   - Demo of a typed and untyped dataset
// Created
//   - CopyPaste � 20240408 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240408 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDataset: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Data.OleDb.OleDbConnection cnncpPoints;
    internal System.Windows.Forms.Button cmdDisplay;
    internal System.Windows.Forms.Button cmdLoadTyped;
    internal System.Data.OleDb.OleDbCommand cmmSelectPoints;
    internal System.Windows.Forms.Button cmdLoadUntyped;
    internal System.Windows.Forms.DataGrid dgrXYPoints;
    private CopyPaste.Learning.dsData dsData;
    internal System.Data.OleDb.OleDbDataAdapter dtaPoints;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataset));
      this.cnncpPoints = new System.Data.OleDb.OleDbConnection();
      this.cmdDisplay = new System.Windows.Forms.Button();
      this.cmdLoadTyped = new System.Windows.Forms.Button();
      this.cmmSelectPoints = new System.Data.OleDb.OleDbCommand();
      this.cmdLoadUntyped = new System.Windows.Forms.Button();
      this.dgrXYPoints = new System.Windows.Forms.DataGrid();
      this.dtaPoints = new System.Data.OleDb.OleDbDataAdapter();
      this.dsData = new CopyPaste.Learning.dsData();
      ((System.ComponentModel.ISupportInitialize)(this.dgrXYPoints)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.SuspendLayout();
      // 
      // cnncpPoints
      // 
      this.cnncpPoints.ConnectionString = "Provider=SQLNCLI11;Data Source=COPYPASTEPOWER\\COPYPASTE;Integrated Security=SSPI;" +
    "Initial Catalog=cpPoints";
      // 
      // cmdDisplay
      // 
      this.cmdDisplay.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdDisplay.Location = new System.Drawing.Point(205, 226);
      this.cmdDisplay.Name = "cmdDisplay";
      this.cmdDisplay.Size = new System.Drawing.Size(75, 23);
      this.cmdDisplay.TabIndex = 7;
      this.cmdDisplay.Text = "Display";
      this.cmdDisplay.Click += new System.EventHandler(this.cmdDisplay_Click);
      // 
      // cmdLoadTyped
      // 
      this.cmdLoadTyped.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdLoadTyped.Location = new System.Drawing.Point(109, 226);
      this.cmdLoadTyped.Name = "cmdLoadTyped";
      this.cmdLoadTyped.Size = new System.Drawing.Size(88, 23);
      this.cmdLoadTyped.TabIndex = 6;
      this.cmdLoadTyped.Text = "Load Typed";
      this.cmdLoadTyped.Click += new System.EventHandler(this.cmdLoadTyped_Click);
      // 
      // cmmSelectPoints
      // 
      this.cmmSelectPoints.CommandText = "SELECT lngIdPoint, lngX, lngY FROM tblCPPoint";
      this.cmmSelectPoints.Connection = this.cnncpPoints;
      // 
      // cmdLoadUntyped
      // 
      this.cmdLoadUntyped.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdLoadUntyped.Location = new System.Drawing.Point(13, 226);
      this.cmdLoadUntyped.Name = "cmdLoadUntyped";
      this.cmdLoadUntyped.Size = new System.Drawing.Size(88, 23);
      this.cmdLoadUntyped.TabIndex = 5;
      this.cmdLoadUntyped.Text = "Load Untyped";
      this.cmdLoadUntyped.Click += new System.EventHandler(this.cmdLoadUntyped_Click);
      // 
      // dgrXYPoints
      // 
      this.dgrXYPoints.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrXYPoints.DataMember = "";
      this.dgrXYPoints.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrXYPoints.Location = new System.Drawing.Point(13, 18);
      this.dgrXYPoints.Name = "dgrXYPoints";
      this.dgrXYPoints.Size = new System.Drawing.Size(264, 184);
      this.dgrXYPoints.TabIndex = 4;
      // 
      // dtaPoints
      // 
      this.dtaPoints.SelectCommand = this.cmmSelectPoints;
      this.dtaPoints.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPPoint", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("lngIdPoint", "lngIdPoint"),
                        new System.Data.Common.DataColumnMapping("lngX", "lngX"),
                        new System.Data.Common.DataColumnMapping("lngY", "lngY")})});
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // frmDataset
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.Add(this.cmdLoadUntyped);
      this.Controls.Add(this.dgrXYPoints);
      this.Controls.Add(this.cmdDisplay);
      this.Controls.Add(this.cmdLoadTyped);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataset";
      this.Text = "Test Dataset";
      this.Load += new System.EventHandler(this.frmDataset_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrXYPoints)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDataset'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDataset()
      //***
      // Action
      //   - Create instance of 'frmDataset'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDataset()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private DataSet mdsPoint = new DataSet();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdDisplay_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If data member of datagrid is "tblCPPoint" (Untyped dataset)
      //     - Get X from the selected row of the untyped dataset
      //     - Get Y from the selected row of the untyped dataset
      //   - If Not (typed dataset)
      //     - Get X from the selected row of the typed dataset
      //     - Get Y from the selected row of the typed dataset
      //   - A string is created with the selected information
      //   - String is shown in a messagebox
      //   - On error an errormessage is shown
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngRow = dgrXYPoints.CurrentCell.RowNumber;
      int lngX;
      int lngY;
      string strPoint;

      try
      {

        if (dgrXYPoints.DataMember == "tblCPPoint")
        {
          lngX = Convert.ToInt32(mdsPoint.Tables["tblCPPoint"].Rows[lngRow]["X"]);
          lngY = Convert.ToInt32(mdsPoint.Tables["tblCPPoint"].Rows[lngRow]["Y"]);
        }
        else
          // dgrXYPoints.DataMember <> "tblCPPoint"
        {
          lngX = dsData.tblCPPoint[lngRow].lngX;
          lngY = dsData.tblCPPoint[lngRow].lngY;
        }
        // dgrXYPoints.DataMember = "tblCPPoint"

        strPoint = String.Format("({0},{1})", lngX, lngY);
        MessageBox.Show(strPoint);
      }
      catch
      {
        MessageBox.Show("There was no data loaded!", "Copy Paste");
      }
      finally
      {
      }
    
    }
    // cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click

    private void cmdLoadUntyped_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The DataSet becomes the DataSource of the DataGrid
      //   - The DataMember of the DataGrid becomes the table "tblCPPoint"
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dgrXYPoints.DataSource = mdsPoint;
      dgrXYPoints.DataMember = "tblCPPoint";
    }
    // cmdLoadUntyped_Click(System.Object, System.EventArgs) Handles cmdLoadUntyped.Click
  
    private void cmdLoadTyped_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - DataAdapter is filled with Dataset
      //   - The Dataset becomes the DataSource of the DataGrid
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dtaPoints.Fill(dsData);
      dgrXYPoints.DataSource = dsData.tblCPPoint;
    }
    // cmdLoadTyped_Click(System.Object, System.EventArgs) Handles cmdLoadTyped.Click

    private void frmDataset_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create 2 DataColumns (X and Y)
      //   - Create a DataTable
      //   - Add the DataTable to the Dataset
      //   - Add the 2 DataColumns to the DataTable
      //   - Add 49 rows to the DataTable
      //     - Loop lngX from 0 till 6
      //       - Loop lngY from 0 till 6
      //         - Create a new DataRow
      //         - Fill the data with lngX and lngY
      //         - Add DataRow to the DataTable
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DataColumn dclX = new DataColumn("X", typeof(int));
      DataColumn dclY = new DataColumn("Y", typeof(int));
      DataTable dtPoint = new DataTable("tblCPPoint");
      int lngX;
      int lngY;

      mdsPoint.Tables.Add(dtPoint);
      dtPoint.Columns.Add(dclX);
      dtPoint.Columns.Add(dclY);

      for (lngX = 0; lngX <= 6; lngX++)
      {

        for (lngY = 0; lngY <= 6; lngY++)
        {
          DataRow drwNew = dtPoint.NewRow();
          
          drwNew["X"] = lngX;
          drwNew["Y"] = lngY;
          dtPoint.Rows.Add(drwNew);
        }
        //lngY = 7

      }
      // lngX = 7
    
    }
    // frmDataset_Load(System.Object theSender, System.EventArgs theEventArguments) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDataset
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDataset()
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDataset());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataset

}
// CopyPaste.Learning