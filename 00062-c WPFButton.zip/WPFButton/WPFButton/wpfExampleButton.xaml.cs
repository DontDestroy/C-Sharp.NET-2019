﻿//***
// Action
//   - Some examples of Buttons
// Created
//   - CopyPaste – 20220909 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220909 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;
using System.Windows;

namespace WPFButton
{

  public partial class wpfExampleButton : Window
  {

    #region "Constructors / Destructors"

    public wpfExampleButton()
    //***
    // Action
    //   - Create an instance of 'wpfExampleButton'
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220909 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220909 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***

    {
      InitializeComponent();
    }
    // wpfExampleButton()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdClickDrawing_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Prove that you have clicked on a button
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220909 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220909 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Debug.Print("You have clicked the button with the drawing \"cmdDrawing\".");
    }
    // cmdClickDrawing_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdClickDrawing.Click

    private void cmdClickMeLong_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Prove that you have clicked on a button
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220909 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220909 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Debug.Print("You have clicked the repeat button \"cmdClickMeLong\".");
    }
    // cmdClickMeLong_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdClickMeLong.Click

    private void cmdClickMeOnce_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Prove that you have clicked on a button
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220909 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220909 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Debug.Print("You have clicked the simple button \"cmdClickMeOnce\".");
    }
    // cmdClickMeOnce_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdClickMeOnce.Click

    private void cmdClickRedOrBlue_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Prove that you have clicked on a button
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220909 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220909 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Debug.Print("You have to click on one of the pictures inside \"cmdClickRedOrBlue\".");
    }
    // cmdClickRedOrBlue_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdClickRedOrBlue.Click

    private void picBluePill_MouseDown(System.Object theSender, System.Windows.Input.MouseButtonEventArgs theMouseButtonEventArguments)
    //***
    // Action
    //   - Prove that you have clicked on the Blue Pill
    //   - Stop the rest of the events from happening
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220909 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220909 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Debug.Print("You stay where you are in ignorance and will life in an illusion.");
      theMouseButtonEventArguments.Handled = true;
    }
    // picBluePill_MouseDown(System.Object, System.Windows.Input.MouseButtonEventArgs) Handles picBluePill.MouseDown

    private void picRedPill_MouseDown(System.Object theSender, System.Windows.Input.MouseButtonEventArgs theMouseButtonEventArguments)
    //***
    // Action
    //   - Prove that you have clicked on the Red Pill
    //   - Stop the rest of the events from happening
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220909 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220909 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Debug.Print("You will find the thruth about your life.");
      theMouseButtonEventArguments.Handled = true;
    }
    // picRedPill_MouseDown(System.Object, System.Windows.Input.MouseButtonEventArgs) Handles picRedPill.MouseDown

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfExampleButton

}
// WPFButton