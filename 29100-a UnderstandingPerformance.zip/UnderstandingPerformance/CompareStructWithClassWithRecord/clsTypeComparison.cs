﻿//***
// Action
//   - A demo of benchmarking
//     - Used BenchMarkDotNet.Attributes
//       - BenchMarkDotNET and Microsoft.VisualStudio.DiagnosticksHub.BenchmarkDotNetDiagnosers are NuGet packages
//   - Comparing class, with struct, with record
//   - A demo of stopwatch
// Created
//   - CopyPaste – 20260525 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260525 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpTypeComparison
  {

    #region "Constructors / Destructors"

    public cpTypeComparison()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpPoint(double, double)
    //   - rcdPoint(double, double)
    //   - structPoint(double, double)
    //   - double SumClass()
    //   - double SumLengthClass()
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      double dblClassLength = 0;
      double dblClassSum = 0;
      double dblRecordLength = 0;
      double dblRecordSum = 0;
      double dblStructLength = 0;
      double dblStructSum = 0;

      arrClass = Enumerable.Range(0, intNumberOfItems).Select(intNumber => new cpPoint(intNumber, intNumber)).ToArray();
      arrRecord = Enumerable.Range(0, intNumberOfItems).Select(intNumber => new rcdPoint(intNumber, intNumber)).ToArray();
      arrStruct = Enumerable.Range(0, intNumberOfItems).Select(intNumber => new structPoint(intNumber, intNumber)).ToArray();

      dblClassSum = SumClass();
      dblClassLength = SumLengthClass();

      Console.WriteLine("Class Sum is {0:#,##0}", dblClassSum);
      Console.WriteLine("Class Sum Length is {0:#,##0}", dblClassLength);
      Console.WriteLine();

      dblRecordSum = SumRecord();
      dblRecordLength = SumLengthRecord();

      Console.WriteLine("Record Sum is {0:#,##0}", dblRecordSum);
      Console.WriteLine("Record Sum Length is {0:#,##0}", dblRecordLength);
      Console.WriteLine();

      dblStructSum = SumStruct();
      dblStructLength = SumLengthStruct();

      Console.WriteLine("Struct Sum is {0:#,##0}", dblStructSum);
      Console.WriteLine("Struct Sum Length is {0:#,##0}", dblStructLength);
      Console.WriteLine();
    }
    // cpTypeComparison()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpPoint[] arrClass;
    private int intNumberOfItems = 1_000_000;
    private rcdPoint[] arrRecord;
    private structPoint[] arrStruct;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [BenchmarkAttribute]
    public double SumClass()
      => arrClass.Sum(point => point.Sum());
    // cpTypeComparison()

    [BenchmarkAttribute]
    public double SumLengthClass()
      => arrClass.Sum(point => point.Length());
    // cpTypeComparison()

    [BenchmarkAttribute]
    public double SumLengthRecord()
      => arrRecord.Sum(point => point.Length());
    // cpTypeComparison()

    [BenchmarkAttribute]
    public double SumLengthStruct()
      => arrStruct.Sum(point => point.Length());
    // cpTypeComparison()

    [BenchmarkAttribute]
    public double SumRecord()
      => arrRecord.Sum(point => point.Sum());
    // cpTypeComparison()

    [BenchmarkAttribute]
    public double SumStruct()
      => arrStruct.Sum(point => point.Sum());
    // cpTypeComparison()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpTypeComparison

}
// CopyPaste.Learning