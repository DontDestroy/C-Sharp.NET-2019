﻿//***
// Action
//   - Demo of Conversion with Linq, Element with Linq, Generation with Linq
//   - Keyword Cast
//   - Keyword OfType
//   - Keyword DefaultIfEmpty
//   - Keyword Range
//   - Keyword Repeat
//   - Keyword Empty
// Created
//   - CopyPaste – 20230516 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230516 – VVDW
// Proposal (To Do)
//   -
//***

using AmericanHistory;
using CopyPaste.HumanResources;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace DeferredOperatorLinq
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void CastSequence()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Cast operators return an output sequence of elemements of a specific type
    //     - The input sequence is of the form IEnumerable (it is created for old C# code)
    //     - The output sequence is of the form IEnumerable<T>
    //   - Cast has 1 overload
    //     - Return the elements of a collection converted (casted) to a certain type
    //   - Fill an arraylist with all the employees of Copy Paste
    //   - Show the type of the result
    //   - Cast the arraylist to cpEmployees
    //   - Show the type of the result
    //   - Order the result on LastName (Lambda Linq Dot Notation)
    //   - Loop thru the elements of the result
    //   - Order the result on LastName (Linq Fluent Syntax Query Expression)
    //   - Loop thru the elements of the result
    // Called by
    //   - Main()
    // Calls
    //   - ArrayList cpCompany.AllEmployees (Get)
    //   - cpCompany(string)
    //   - ShowContentOfEmployeeSequence(IEnumerable<cpEmployee>, string)
    //   - string cpEmployee.LastName (Get)
    // Created
    //   - CopyPaste – 20230516 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230516 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ArrayList arrlstCopyPasteEmployees;
      cpCompany theCopyPasteCompany;
      IEnumerable<cpEmployee> colEmployees;
      IEnumerable<cpEmployee> colResultExpression;
      IEnumerable<cpEmployee> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      theCopyPasteCompany = new cpCompany("Copy Paste");

      arrlstCopyPasteEmployees = theCopyPasteCompany.AllEmployees;
      Console.WriteLine("The data type of arrlstCopyPasteEmployees is {0}", arrlstCopyPasteEmployees.GetType());

      colEmployees = arrlstCopyPasteEmployees.Cast<cpEmployee>();
      // Cast takes an input sequence and returns an object that, when enumerated,
      // enumerates the input sequence, cast the element to a specific type and yield that casted element
      // Cast is an extension method, so we use it on an instance of a sequence that is enumerable (AllEmployees)

      Console.WriteLine("The data type of colEmployees is {0}", colEmployees.GetType());

      colResultLambda = colEmployees.OrderBy(anEmployee => anEmployee.LastName);
      ShowContentOfEmployeeSequence(colResultLambda, "The list of all employees: (Lambda Linq Dot Notation)");

      colResultExpression = from anEmployee in colEmployees
                            orderby anEmployee.LastName
                            select anEmployee;

      Console.WriteLine();
      ShowContentOfEmployeeSequence(colResultExpression, "The list of all employees: (Linq Fluent Syntax Query Expression)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // CastSequence()

    public static void DefaultIfEmptySequence()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - DefaultIfEmpty operator returns an output default element of a specific type
    //   - DefaultIfEmpty has 2 overloads
    //     - DefaultIfEmpty creates an default element of a the type of IEnumerable<T>
    //     - DefaultIfEmpty creates an default element of a the type of IEnumerable<T> with a default value
    //   - Fill the array with presidents
    //   - Filter the array with presidents by name "George" (Lambda Linq Dot Notation)
    //   - Show result by displaying the name of the presidents
    //     - We are sure there is one
    //   - Filter the array with presidents by name "William" (Linq Fluent Syntax Query Expression)
    //   - Show result by displaying the name of the presidents
    //     - We are sure there is one
    //   - Filter the array with presidents by name "Vincent" and take the first (Lambda Linq Dot Notation)
    //   - Show result by displaying the name of the first president
    //     - We are sure there is none, DefaultIfEmpty is needed
    //   - Filter the array with presidents by name "Vincent" and take the first (Lambda Linq Dot Notation)
    //   - Show result by displaying the name of the first president
    //     - We are sure there is none, DefaultIfEmpty is needed that creates a president with name "Vincent Van De Walle"
    //   - Filter the array with presidents by name "Gertrude" and take the first (Linq Fluent Syntax Query Expression)
    //   - Show result by displaying the name of the first president
    //     - We are sure there is none, DefaultIfEmpty is needed
    //   - Filter the array with presidents by name "Gertrude" and take the first (Linq Fluent Syntax Query Expression)
    //   - Show result by displaying the name of the first president
    //     - We are sure there is none, DefaultIfEmpty is needed that creates a president with name "Gertrude Gryson"
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)
    // Created
    //   - CopyPaste – 20230522 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230522 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpPresident> cpResultExpression;
      IEnumerable<cpPresident> cpResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();
      cpResultLambda = cpPresident.AllPresidents.Where(aPresident => aPresident.Name.StartsWith("George"));

      ShowContentOfPresidentSequence(cpResultLambda, "The American Presidents after filter 'George': (Lambda Linq Dot Notation) ");

      cpResultExpression = (from aPresident in cpPresident.AllPresidents
                            where aPresident.Name.StartsWith("William")
                            select aPresident);

      Console.WriteLine();
      ShowContentOfPresidentSequence(cpResultExpression, "The American Presidents after filter 'William': (Linq Fluent Syntax Query Expression) ");

      cpResultLambda = cpPresident.AllPresidents.Where(aPresident => aPresident.Name.StartsWith("Vincent")).Take(1);
      // The statement above will contain no presidents where the name starts with 'Vincent'
      Console.WriteLine();
      ShowContentOfPresidentSequence(cpResultLambda, "The first American Presidents after filter 'Vincent': (Lambda Linq Dot Notation) ");

      cpResultLambda = cpPresident.AllPresidents.Where(aPresident => aPresident.Name.StartsWith("Vincent")).DefaultIfEmpty().Take(1);
      // The statement above will contain 1 empty president where the name starts with 'Vincent'
      // DefaultIfEmpty takes an input sequence and returns an object, when enumerated,
      // enumerates throught the input source sequence yielding elements unless the input source sequence is empty,
      // in which case it returns a sequence yielding a single element of default<T>
      // DefaultIfEmpty is an extension method, so we use it on an instance of a sequence that is enumerable (AllPresidents)

      Console.WriteLine();
      ShowContentOfPresidentSequence(cpResultLambda, "The first American Presidents after filter 'Vincent': (Lambda Linq Dot Notation) ");

      cpResultLambda = cpPresident.AllPresidents.Where(aPresident => aPresident.Name.StartsWith("Vincent")).DefaultIfEmpty(new cpPresident("Vincent Van De Walle")).Take(1);
      // The statement above will contain 1 president where the name starts with 'Vincent'
      // DefaultIfEmpty takes an input sequence and returns an object, when enumerated,
      // enumerates throught the input source sequence yielding elements unless the input source sequence is empty,
      // in which case it returns a sequence yielding a single created element <T>
      // DefaultIfEmpty is an extension method, so we use it on an instance of a sequence that is enumerable (AllPresidents)

      Console.WriteLine();
      ShowContentOfPresidentSequence(cpResultLambda, "The first American Presidents after filter 'Vincent': (Lambda Linq Dot Notation) ");

      cpResultExpression = (from aPresident in cpPresident.AllPresidents
                            where aPresident.Name.StartsWith("Gertrude")
                            select aPresident).Take(1);
      // The statement above will contain no presidents where the name starts with 'Gertrude'
      Console.WriteLine();
      ShowContentOfPresidentSequence(cpResultExpression, "The first American Presidents after filter 'Gertrude': (Linq Fluent Syntax Query Expression) ");

      cpResultExpression = (from aPresident in cpPresident.AllPresidents
                            where aPresident.Name.StartsWith("Gertrude")
                            select aPresident).DefaultIfEmpty().Take(1);

      Console.WriteLine();
      ShowContentOfPresidentSequence(cpResultExpression, "The first American Presidents after filter 'Gertrude': (Linq Fluent Syntax Query Expression) ");

      cpResultExpression = (from aPresident in cpPresident.AllPresidents
                            where aPresident.Name.StartsWith("Gertrude")
                            select aPresident).DefaultIfEmpty(new cpPresident("Gertrude Gryson")).Take(1);

      Console.WriteLine();
      ShowContentOfPresidentSequence(cpResultExpression, "The first American Presidents after filter 'Gertrude': (Linq Fluent Syntax Query Expression) ");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // DefaultIfEmptySequence()

    public static void EmptySequence()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Empty operators returns an output sequence of a certain type, but with no elements in it
    //     - The input is an object of a certain data type
    //     - The output sequence is of the form IEnumerable<T> with the object 0 times in it
    //   - Empty has 1 overload
    //     - Return the elements of a collection of a certain data type, 0 times
    //   - Generate a empty sequence (Lambda Linq Dot Notation)
    //   - Loop thru the elements of the result 
    // Called by
    //   - Main()
    // Calls
    //   - ShowContentOfSequence<T>(IEnumerable<T>, string)
    // Created
    //   - CopyPaste – 20230525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;
      IEnumerable<int> lstNumbers;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      lstNumbers = Enumerable.Empty<int>();
      // Empty takes one input (type T) and returns an object that, when enumerated,
      // enumerates yield an empty range of T
      // Empty is not an extension method, it does not extend IEnumerable<T>
      // It is a static method on System.Linq.Enumerable

      ShowContentOfSequence(lstNumbers, "The list of numbers: ");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // EmptySequence()

    public static void LeftOuterJoinTwoSequences()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Joining operators return an output sequence of elements that are two input sequences combined
    //     - The input sequences are of the form IEnumerable<T>
    //       - There is an outer sequence and an inner sequence
    //     - The output sequence is of the form IEnumerable<T>
    //   - GroupJoin has 2 overloads (only one is in the example)
    //     - Return the elements of an outer collection using a keySelector delegate and an inner collection grouped using a keySelector delegate into a sequence
    //   - Fill an array with employees (original an old school arraylist) (the outer collection)
    //   - Fill an array with investments (original an array) (the inner collection)
    //   - GroupJoin the employees with the corresponding investments grouped (Lambda Linq Dot Notation)
    //   - Show result (without LeftOuterJoin)
    //   - GroupJoin the employees wiht the corresponding investments grouped (Linq Fluent Syntax Query Expression)
    //   - Show result (without LeftOuterJoin)
    //   - GroupJoin the employees with the corresponding investments grouped (Lambda Linq Dot Notation)
    //   - Show result (with LeftOuterJoin)
    //   - GroupJoin the employees wiht the corresponding investments grouped (Linq Fluent Syntax Query Expression)
    //   - Show result (with LeftOuterJoin)
    // Called by
    //   - Main()
    // Calls
    //   - ArrayList cpCompany.AllEmployees (Get)
    //   - cpCompany(string)
    //   - cpInvestment[] cpCompany.AllInvestments (Get)
    //   - int cpEmployee.EmployeeNumber (Get)
    //   - int cpInvestment.EmployeeNumber (Get)
    //   - long cpInvestment.Amount (Get)
    //   - ShowContentOfSequence<T>(IEnumerable<T>, string)
    //   - string cpEmployee.Name (Get)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpCompany theCopyPasteCompany;
      cpEmployee[] arrCopyPasteEmployees;
      cpInvestment[] arrCopyPasteInvestments;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      theCopyPasteCompany = new cpCompany("Copy Paste");

      arrCopyPasteEmployees = (cpEmployee[])theCopyPasteCompany.AllEmployees.ToArray(typeof(cpEmployee));
      // This is done because AllEmployees is an ArrayList (does not inherit from IEnumarable<T>)
      // ArrayList is an old school Data Type in C# (before Linq existed)
      arrCopyPasteInvestments = theCopyPasteCompany.AllInvestments;

      var colResultLambda = arrCopyPasteEmployees       // Outer sequence
        .GroupJoin(arrCopyPasteInvestments,             // Inner sequence
        anEmployee => anEmployee.EmployeeNumber,        // Outer KeySelector
        anInvestment => anInvestment.EmployeeNumber,    // Inner KeySelector
        (anEmployee, theInvestments) => theInvestments  // Select all investments
        .Select(anInvestment => new                     // Joining both in an anonymous Data type
        {
          EmployeeNumber = anEmployee.EmployeeNumber,
          Name = anEmployee.Name,
          Amount = anInvestment == null ? 0 : anInvestment.Amount
        }))
        .SelectMany(EmployeeWithInvestment => EmployeeWithInvestment);

      ShowContentOfSequence(colResultLambda, "The list of all employees with their investments: (Lambda Linq Dot Notation)");
      // An employee with no investments is not in the list

      var colResultExpression = from anEmployee in arrCopyPasteEmployees
                                join anInvestment in arrCopyPasteInvestments
                                on anEmployee.EmployeeNumber equals anInvestment.EmployeeNumber
                                select new { EmployeeNumber = anEmployee.EmployeeNumber, Name = anEmployee.Name, Amount = anInvestment.Amount };

      Console.WriteLine();
      ShowContentOfSequence(colResultExpression, "The list of all employees with their investments: (Linq Fluent Syntax Query Expression)");
      // An employee with no investments is not in the list

      var colResultLeftOuterJoinLambda = arrCopyPasteEmployees       // Outer sequence
        .GroupJoin(arrCopyPasteInvestments,                          // Inner sequence
        anEmployee => anEmployee.EmployeeNumber,                     // Outer KeySelector
        anInvestment => anInvestment.EmployeeNumber,                 // Inner KeySelector
        (anEmployee, theInvestments) => theInvestments               // Select all investments
        .DefaultIfEmpty()                                            // When there are no investments, create a default
        .Select(anInvestment => new                                  // Joining both in an anonymous Data type
        {
          EmployeeNumber = anEmployee.EmployeeNumber,
          Name = anEmployee.Name,
          Amount = anInvestment == null ? 0 : anInvestment.Amount
        }))
        .SelectMany(EmployeeWithInvestment => EmployeeWithInvestment);

      Console.WriteLine();
      ShowContentOfSequence(colResultLeftOuterJoinLambda, "The list of all employees with their investments: (Lambda Linq Dot Notation)");
      // An employee with no investments is in the list

      var colResultLeftOuterJoinExpression = from anEmployee in arrCopyPasteEmployees
                                             join anInvestment in arrCopyPasteInvestments
                                             on anEmployee.EmployeeNumber equals anInvestment.EmployeeNumber into theInvestments
                                             from anInvestmentOrNull in theInvestments.DefaultIfEmpty()
                                             select new { EmployeeNumber = anEmployee.EmployeeNumber, Name = anEmployee.Name, Amount = anInvestmentOrNull == null ? 0 : anInvestmentOrNull.Amount };

      Console.WriteLine();
      ShowContentOfSequence(colResultLeftOuterJoinExpression, "The list of all employees with their investments: (Linq Fluent Syntax Query Expression)");
      // An employee with no investments is in the list

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // LeftOuterJoinTwoSequences()

    public static void Main()
    //***
    // Action
    //   - Study the methods in order
    //   - Try to experiment, your own location to try things out
    //   - Cast a sequence to a sequence of a specific data type
    //   - TypeOf a sequence to a sequence of a specific data type
    //   - DefaultIfEmpty to determine if there is an element in the result sequence
    //   - DefaultIfEmpty to determine if there is an element in the result sequence with Left Outer Join
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - CastSequence()
    //   - DefaultIfEmptySequence()
    //   - EmptySequence()
    //   - LeftOuterJoinTwoSequences()
    //   - TypeOfSequence()
    //   - TryToExperiment()
    // Created
    //   - CopyPaste – 20230516 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230516 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      TryToExperiment();
      // CastSequence();
      // TypeOfSequence();
      // DefaultIfEmptySequence();
      // LeftOuterJoinTwoSequences();
      // RangeSequence();
      // RepeatSequence();
      // EmptySequence();
      Console.ReadLine();
    }
    // Main()

    public static void RangeSequence()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Range operators returns an output sequence of integers
    //     - The input is a from and a certain amount
    //     - The output sequence is of the form IEnumerable<int>
    //   - Range has 1 overload
    //     - Return the elements of a collection of integers, from 5, 4 integers --> 5, 6, 7, 8
    //   - Generate a range of ten numbers, starting with 3 (Lambda Linq Dot Notation)
    //   - Loop thru the elements of the result 
    // Called by
    //   - Main()
    // Calls
    //   - ShowContentOfSequence<T>(IEnumerable<T>, string)
    // Created
    //   - CopyPaste – 20230523 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230523 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;
      IEnumerable<int> lstNumbers;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      lstNumbers = Enumerable.Range(3, 10);
      // Range takes two integer inputs and returns an object that, when enumerated,
      // enumerates yield a range of integers from a certain point, a number of integers
      // Range is not an extension method, it does not extend IEnumerable<T>
      // It is a static method on System.Linq.Enumerable

      ShowContentOfSequence(lstNumbers, "The list of numbers: ");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // RangeSequence()

    public static void RepeatSequence()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Repeat operators returns an output sequence of a certain type
    //     - The input is an object and a certain amount
    //     - The output sequence is of the form IEnumerable<T> with the same object x times
    //   - Repeat has 1 overload
    //     - Return the elements of a collection of a certain data type, x times
    //   - Generate a range of ten numbers, all numbers are 21 (Lambda Linq Dot Notation)
    //   - Loop thru the elements of the result 
    // Called by
    //   - Main()
    // Calls
    //   - ShowContentOfSequence<T>(IEnumerable<T>, string)
    // Created
    //   - CopyPaste – 20230523 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230523 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;
      IEnumerable<int> lstNumbers;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      lstNumbers = Enumerable.Repeat(21, 10);
      // Repeat takes two inputs (one of type T and one integer) and returns an object that, when enumerated,
      // enumerates yield a range of T a certain amount of times
      // Repeat is not an extension method, it does not extend IEnumerable<T>
      // It is a static method on System.Linq.Enumerable

      ShowContentOfSequence(lstNumbers, "The list of numbers: ");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // RepeatSequence()

    private static void ShowContentOfEmployeeSequence(IEnumerable<cpEmployee> colSequence, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type cpEmployee in a sequence
    // Called by
    //   - CastSequence()
    //   - TypeOfSequence()
    // Calls
    //   - string cpEmployee.FirstName (Get)
    //   - string cpEmployee.LastName (Get)
    // Created
    //   - CopyPaste – 20230516 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230516 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine(strTitle);

      foreach (cpEmployee anEmployee in colSequence)
      {
        Console.WriteLine("{0} {1}", anEmployee.FirstName, anEmployee.LastName);
      }
      // in colSequence

    }
    // ShowContentOfEmployeeSequence(IEnumerable<cpEmployee>, string)

    private static void ShowContentOfPresidentSequence(IEnumerable<cpPresident> colSequence, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type cpPresident in a sequence
    //   - It is possible there are none
    // Called by
    //   - DefaultIfEmptySequence()
    // Calls
    //   - string cpPresident.Name() (Get)
    // Created
    //   - CopyPaste – 20230417 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230417 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine(strTitle);

      if (colSequence.Count() == 0)
      {
        Console.WriteLine("There are no presidents in the list");
      }
      else
      // colSequence.Count() <> 0
      {

        foreach (cpPresident aPresident in colSequence)
        {

          if (aPresident == null)
          {
            Console.WriteLine("There is an empty element the list");
          }
          else
          // aPresident <> null
          {
            Console.WriteLine(aPresident.Name);
          }
          // aPresident = null

        }
        // in colSequence

      }
      // colSequence.Count() = 0

    }
    // ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)

    private static void ShowContentOfSequence<T>(IEnumerable<T> colSequence, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type T in a sequence
    // Called by
    //   - RangeSequence()
    //   - RepeatSequence()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230522 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230522 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine(strTitle);

      foreach (T anElement in colSequence)
      {
        Console.WriteLine(anElement);
      }
      // in colSequence

    }
    // ShowContentOfSequence<T>(IEnumerable<T>, string)

    public static void TypeOfSequence()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - TypeOf operators return an output sequence of elemements of a specific type
    //     - The input sequence is of the form IEnumerable (it is created for old C# code)
    //     - The output sequence is of the form IEnumerable<T>
    //   - Cast has 1 overload
    //     - Return the elements of a collection converted (casted) to a certain type, and only the elements that can be converted
    //   - Fill an arraylist with all the employees of Copy Paste
    //   - Add an investment to it
    //   - Add again the employees of Copy Paste to it
    //   - TypeOf the arraylist to cpEmployees
    //   - Show the type of the result
    //   - Order the result on LastName descending (Lambda Linq Dot Notation)
    //   - Loop thru the elements of the result
    //   - Order the result on LastName descending (Linq Fluent Syntax Query Expression)
    //   - Loop thru the elements of the result
    //   - Demo what goes wrong when you use Cast instead
    // Called by
    //   - Main()
    // Calls
    //   - ArrayList cpCompany.AllEmployees (Get)
    //   - cpCompany(string)
    //   - cpInvestment[] cpCompany.AllInvestments (Get)
    //   - ShowContentOfEmployeeSequence(IEnumerable<cpEmployee>, string)
    //   - string cpEmployee.LastName (Get)
    // Created
    //   - CopyPaste – 20230516 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230516 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ArrayList arrlstCopyPasteEmployees;
      cpCompany theCopyPasteCompany;
      IEnumerable<cpInvestment> theInvestment;
      IEnumerable<cpEmployee> colEmployees;
      IEnumerable<cpEmployee> colResultExpression;
      IEnumerable<cpEmployee> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      theCopyPasteCompany = new cpCompany("Copy Paste");
      arrlstCopyPasteEmployees = theCopyPasteCompany.AllEmployees;
      theInvestment = theCopyPasteCompany.AllInvestments.Take(1);

      arrlstCopyPasteEmployees.Add(theInvestment);
      arrlstCopyPasteEmployees.AddRange(theCopyPasteCompany.AllEmployees);

      colEmployees = arrlstCopyPasteEmployees.OfType<cpEmployee>();
      // OfType takes an input sequence and returns an object that, when enumerated,
      // enumerates the input sequence, cast the element to a specific type and yield that casted element when successful
      // OfType is an extension method, so we use it on an instance of a sequence that is enumerable (AllEmployees)

      colResultLambda = colEmployees.OrderBy(anEmployee => anEmployee.LastName);
      ShowContentOfEmployeeSequence(colResultLambda, "The list of all employees in descending order: (Lambda Linq Dot Notation)");

      colResultExpression = from anEmployee in colEmployees
                            orderby anEmployee.LastName descending
                            select anEmployee;

      Console.WriteLine();
      ShowContentOfEmployeeSequence(colResultExpression, "The list of all employees in descending order: (Linq Fluent Syntax Query Expression)");

      colEmployees = arrlstCopyPasteEmployees.Cast<cpEmployee>();
      // This will go wrong, the moment you try to loop thru it

      Console.WriteLine();
      Console.WriteLine("Attempt to use the Cast operator (but not all elements are employees) ...");

      try
      {
        ShowContentOfEmployeeSequence(colEmployees, "The list of all employees:");
        // Loop fails the moment one element is not a cpEmployee
      }
      catch (Exception theException)
      {
        Console.WriteLine("{0} - {1}", theException.Message, System.Environment.NewLine);
      }

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // TypeOfSequence()


    public static void TryToExperiment()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Method used for experimenting
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230515 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230515 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      //  Do your stuff here

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // TryToExperiment()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion  

  }
  // cpProgram

}
// DeferredOperatorLinq