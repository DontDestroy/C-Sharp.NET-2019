﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmAppleStore.aspx.cs" Inherits="CopyPaste.Learning.wfrmAppleStore" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>myPod: Apple Store</title>
  <style type="text/css">
    body {
      background-color: #eaf3da;
    }
  </style>
</head>
<body>
  <form id="wfrmAppleStore" runat="server">
    <h1>Apple Store</h1>
    <p>
      <img src="../Resources/AppleStore.jpg" alt="An iPod at the Birmingham Apple store" />
    </p>
  </form>
</body>
</html>
