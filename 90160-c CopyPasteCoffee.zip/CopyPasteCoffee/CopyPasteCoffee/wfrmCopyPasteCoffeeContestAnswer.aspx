﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCopyPasteCoffeeContestAnswer.aspx.cs" Inherits="CopyPaste.Learning.wfrmCopyPasteCoffeeContestAnswer" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Copy Paste Coffee Contest</title>
</head>
<body>
  <form id="wfrmCopyPasteCoffeeContestAnswer" method="post">
    <asp:Label ID="lblAnswer" Style="z-index: 102; position: absolute; top: 80px; left: 120px" runat="server"></asp:Label>
  </form>
</body>
</html>
