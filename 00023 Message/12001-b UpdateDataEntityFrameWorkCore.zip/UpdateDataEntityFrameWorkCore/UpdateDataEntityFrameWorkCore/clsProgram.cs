﻿//***
// Action
//   - Use DemoDataEntityFrameWorkCore to create the database
//   - Query the two tables 
//   - Update one value
//   - Query the two tables 
// Created
//   - CopyPaste – 20230401 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230401 – VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace UpdateDataEntityFrameWorkCore
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Create a cpApplicationDatabaseContext
    //   - Read data from the database
    //   - Update some information
    //   - Read data from the database
    //   - Cleaning up the cpApplicationDatabaseContext
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpApplicationDatabaseContext()
    //   - ReadTestData(cpApplicationDatabaseContext)
    //   - UpdateTestData(cpApplicationDatabaseContext)
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      using (cpApplicationDatabaseContext theDatabaseContext = new cpApplicationDatabaseContext())
      {
        ReadTestData(theDatabaseContext);
        // Read data from the two tables thru the context
        UpdateTestData(theDatabaseContext);
        // Update data in one table thru the context
        ReadTestData(theDatabaseContext);
        // Read data from the two tables thru the context
        Console.ReadLine();
      }
      // cpApplicationDatabaseContext theDatabaseContext

    }
    // Main()

    public static void ReadTestData(cpApplicationDatabaseContext theDatabaseContext)
    //***
    // Action
    //   - Reads all the books
    //   - AsNoTracking() says this is a read-only access
    //   - The include causes the cpAuthor information to be loaded with each cpBook
    //   - Loop thru all the books
    // Called by
    //   - Main()
    // Calls
    //   - cpAuthor cpBook.Author (Get)
    //   - DateTime cpBook.dtmPublishedOn (Get)
    //   - DbSet<cpBook> cpApplicationDatabaseContext.cpBook (Get)
    //   - string cpAuthor.strName (Get)
    //   - string cpAuthor.strWebUrl (Get)
    //   - string cpBook.strTitle (Get)
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strWebUrl;

      foreach (cpBook aBook in theDatabaseContext.cpBook.AsNoTracking().Include(theBook => theBook.Author))
      {

        if (aBook.Author.strWebUrl == null)
        {
          strWebUrl = "- no web url given yet -";
        }
        // aBook.Author.strWebUrl <> null
        else
        {
          strWebUrl = aBook.Author.strWebUrl;
        }
        // aBook.Author.strWebUrl = null

        Console.WriteLine($"{aBook.strTitle} by {aBook.Author.strName}");
        Console.WriteLine($"     Published on {aBook.dtmPublishedOn:dd/MM/yyyy}.");
        Console.WriteLine($"     More info can be found on the internet: {strWebUrl}");
        Console.WriteLine();
      }
      // in theDatabaseContext.cpBook.AsNoTracking().Include(theBook => theBook.Author)

    }
    // ReadTestData(cpApplicationDatabaseContext)

    public static void UpdateTestData(cpApplicationDatabaseContext theDatabaseContext)
    //***
    // Action
    //   - Ask thru the console the new website of a book in the future
    //   - Read a specific book and the author information thru (I need a snapshot)
    //     - Only the book with the title "Quantum Networking" is selected
    //   - The read data is changed with the information given thru the console
    //   - The SaveChanges() thru the context checks for any change to the data that has been read in and write out
    // Called by
    //   - Main()
    // Calls
    //   - cpAuthor cpBook.Author (Get)
    //   - cpAuthor.strWebUrl(string) (Set)
    //   - DbSet<cpBook> cpApplicationDatabaseContext.cpBook (Get)
    //   - string cpBook.strTitle (Get)
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.Write("New Quantum Networking WebUrl > ");
      string strNewWebUrl = Console.ReadLine();

      cpBook theBook = theDatabaseContext.cpBook
        .Include(theBook => theBook.Author)
        .Single(theBook => theBook.strTitle == "Quantum Networking");

      if (strNewWebUrl == "")
      {
        theBook.Author.strWebUrl = null;
      }
      else
      // strNewWebUrl <> ""
      {
        theBook.Author.strWebUrl = strNewWebUrl;
      }
      // strNewWebUrl = ""

      theDatabaseContext.SaveChanges();
      Console.WriteLine("... SaveChanges called.");
      Console.WriteLine();
    }
    // UpdateTestData(cpApplicationDatabaseContext)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// UpdateDataEntityFrameWorkCore