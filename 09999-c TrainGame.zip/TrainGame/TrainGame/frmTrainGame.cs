//***
// Action
//   - The actual game
//   - A railroad is drawn
//   - A fire is placed at the end
//   - A train is placed at the beginning
// Created
//   - CopyPaste � 20240228 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240228 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Games;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTrainGame: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal CopyPaste.Learning.Games.cpctlTrain cpctlTrain;
    internal CopyPaste.Learning.Games.cpctlTrack cpctlTrack;
    internal System.Windows.Forms.Button cmdRestart;
    internal System.Windows.Forms.TrackBar trbThrottle;
    internal System.Windows.Forms.PictureBox picFire;

    private void InitializeComponent()
    {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTrainGame));
			this.cpctlTrain = new CopyPaste.Learning.Games.cpctlTrain();
			this.cpctlTrack = new CopyPaste.Learning.Games.cpctlTrack();
			this.cmdRestart = new System.Windows.Forms.Button();
			this.trbThrottle = new System.Windows.Forms.TrackBar();
			this.picFire = new System.Windows.Forms.PictureBox();
			((System.ComponentModel.ISupportInitialize)(this.trbThrottle)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.picFire)).BeginInit();
			this.SuspendLayout();
			// 
			// cpctlTrain
			// 
			this.cpctlTrain.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cpctlTrain.BackgroundImage")));
			this.cpctlTrain.Location = new System.Drawing.Point(11, 72);
			this.cpctlTrain.Name = "cpctlTrain";
			this.cpctlTrain.Size = new System.Drawing.Size(32, 32);
			this.cpctlTrain.Speed = 0;
			this.cpctlTrain.TabIndex = 11;
			this.cpctlTrain.cpDistanceChanged += new CopyPaste.Learning.Games.cpctlTrain.cpDistanceChangedEventHandler(this.cpctlTrain_cpDistanceChanged);
			// 
			// cpctlTrack
			// 
			this.cpctlTrack.FireFrequency = 0;
			this.cpctlTrack.Location = new System.Drawing.Point(11, 104);
			this.cpctlTrack.Name = "cpctlTrack";
			this.cpctlTrack.Size = new System.Drawing.Size(462, 15);
			this.cpctlTrack.TabIndex = 10;
			this.cpctlTrack.cpRepositionFire += new CopyPaste.Learning.Games.cpctlTrack.cpRepositionFireEventHandler(this.cpctlTrack_cpRepositionFire);
			// 
			// cmdRestart
			// 
			this.cmdRestart.Location = new System.Drawing.Point(499, 128);
			this.cmdRestart.Name = "cmdRestart";
			this.cmdRestart.Size = new System.Drawing.Size(75, 23);
			this.cmdRestart.TabIndex = 9;
			this.cmdRestart.Text = "&New Game";
			this.cmdRestart.Click += new System.EventHandler(this.cmdRestart_Click);
			// 
			// trbThrottle
			// 
			this.trbThrottle.LargeChange = 10;
			this.trbThrottle.Location = new System.Drawing.Point(507, 16);
			this.trbThrottle.Maximum = 50;
			this.trbThrottle.Name = "trbThrottle";
			this.trbThrottle.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbThrottle.Size = new System.Drawing.Size(45, 104);
			this.trbThrottle.SmallChange = 5;
			this.trbThrottle.TabIndex = 8;
			this.trbThrottle.TickFrequency = 10;
			this.trbThrottle.ValueChanged += new System.EventHandler(this.trbThrottle_ValueChanged);
			// 
			// picFire
			// 
			this.picFire.Image = ((System.Drawing.Image)(resources.GetObject("picFire.Image")));
			this.picFire.Location = new System.Drawing.Point(435, 72);
			this.picFire.Name = "picFire";
			this.picFire.Size = new System.Drawing.Size(32, 32);
			this.picFire.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.picFire.TabIndex = 7;
			this.picFire.TabStop = false;
			// 
			// frmTrainGame
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(603, 178);
			this.Controls.Add(this.cpctlTrain);
			this.Controls.Add(this.cpctlTrack);
			this.Controls.Add(this.cmdRestart);
			this.Controls.Add(this.trbThrottle);
			this.Controls.Add(this.picFire);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmTrainGame";
			this.Text = "Train Game";
			((System.ComponentModel.ISupportInitialize)(this.trbThrottle)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.picFire)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTrainGame'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTrainGame()
      //***
      // Action
      //   - Create instance of 'frmTrainGame'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTrainGame()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdRestart_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The label of the form is reset
      //   - The distance of the train is restarted
      //   - The speed of the train is zero
      //   - The train is put back on its starting position
      //   - The fire is put back at the end of the track
      //   - The frequency of 3 second that the fire changes position
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpctlTrack.FireFrequency(int) (Set)
      //   - cpctlTrain.ReStart()
      //   - cpctlTrain.Speed(int) (Set)
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Text = "Train Game";
      cpctlTrain.Restart();
      trbThrottle.Value = 0;
      cpctlTrain.Speed = 0;
      cpctlTrain.Left = cpctlTrack.Left;
      picFire.Left = cpctlTrack.Width - picFire.Width;
      cpctlTrack.FireFrequency = 3;
    }
    // cmdRestart_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdRestart.Click

    private void cpctlTrack_cpRepositionFire(System.Object theSender, cpCaughtOnFireEventArguments thecpCaughtOnFireEventArguments)
      //***
      // Action
      //   - Reposition the fire next to the track
      //   - Using a point with 2 coordinates
      //     - X (left side of the track + location of the fire)
      //     - Y (Top of the track - height of the fire)
      //   - Fire is repositioned
      //   - Check if train caught the fire
      //   - If so
      //     - You loose the game
      // Called by
      //   - System action (Event triggered by the timer in the track)
      // Calls
      //   - CheckTrainInFire()
      //   - int cpCaughtOnFireEventArguments.Location (Get)
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      picFire.Location = new Point(cpctlTrack.Left + thecpCaughtOnFireEventArguments.Location, cpctlTrack.Top - picFire.Height);
      CheckTrainInFire();
    }
    // cpctlTrack_cpRepositionFire(System.Object, cpCaughtOnFireEventArguments) Handles cpctlTrack.cpRepositionFire

    private void cpctlTrain_cpDistanceChanged(System.Object theSender, cpDistanceChangedEventArguments thecpDistanceChangedEventArguments)
      //***
      // Action
      //   - Reposition the train next to the track
      //   - Using the left side of the track and the distance travelled by the train
      //   - Train is repositioned
      //   - Check if train caught the fire
      //   - If so
      //     - You loose the game
      //   - Check if train is at the end of the track
      //   - If so
      //     - You win the game
      // Called by
      //   - System action (Event triggered by the timer in the train)
      // Calls
      //   - CheckTrainInFire()
      //   - cpctlTrack.FireFrequency(int) (Set)
      //   - cpctlTrain.Speed(int) (Set)
      //   - int cpDistanceChangedEventArguments.Distance (Get)
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpctlTrain.Left = cpctlTrack.Left + thecpDistanceChangedEventArguments.Distance;
      CheckTrainInFire();

      if (cpctlTrain.Right >= cpctlTrack.Right)
      {
        cpctlTrain.Speed = 0;
        trbThrottle.Value = 0;
        cpctlTrack.FireFrequency = 0;
        this.Text = "The train is at the end of the track. Game won";
      }
      else
        // cpctlTrain.Right < cpctlTrack.Right 
      {
      }
      // cpctlTrain.Right >= cpctlTrack.Right 
    
    }
    // cpctlTrain_cpDistanceChanged(System.Object, cpDistanceChangedEventArguments) Handles cpctlTrain.cpDistanceChanged

    private void trbThrottle_ValueChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The speed of the train is changed
      // Called by
      //   - User action (Changing the trackbar)
      // Calls
      //   - cpctlTrain.Speed(Int32) (Set)
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (cpctlTrain.Right < cpctlTrack.Right)
      {
        cpctlTrain.Speed = trbThrottle.Value;
      }
      else
        // cpctlTrain.Right >= cpctlTrack.Right 
      {
        cpctlTrain.Speed = 0;
      }
      // cpctlTrain.Right < cpctlTrack.Right 
    
    }
    // trbThrottle_ValueChanged(System.Object, System.EventArgs) Handles trbThrottle.ValueChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void CheckTrainInFire()
      //***
      // Action
      //   - Determine the begin position of the train
      //   - If that position is somewhere in the fire
      //     - You loose the game.
      //     - Speed of the train is set to zero
      //     - Throttle is set to zero
      //     - Fire frequency change is stopped
      //     - A label at the top of the window says that the game is over
      // Called by
      //   - cpctlTrack.FireFrequency(int) (Set)
      //   - cpctlTrack_cpRepositionFire(System.Object, cpCaughtOnFireEventArguments) Handles cpctlTrack.cpRepositionFire
      //   - cpctlTrain.Speed(int) (Set)
      //   - cpctlTrain_cpDistanceChanged(System.Object, cpDistanceChangedEventArguments) Handles cpctlTrain.cpDistanceChanged
      // Calls
      //   - cpctlTrain.Speed(Int32) (Set)
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngBeginOfTrain = cpctlTrain.Left + cpctlTrain.Width;

      if ((lngBeginOfTrain >= picFire.Left) && (lngBeginOfTrain <= picFire.Left + picFire.Width)) 
      {
        cpctlTrain.Speed = 0;
        trbThrottle.Value = 0;
        cpctlTrack.FireFrequency = 0;
        this.Text = "The train is on fire. Game over";
      }
      else
        // lngBeginOfTrain < picFire.Left Or lngBeginOfTrain > picFire.Left + picFire.Width 
      {
      }
      // lngBeginOfTrain >= picFire.Left And lngBeginOfTrain <= picFire.Left + picFire.Width 

    }
    // CheckTrainInFire()

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTrainGame
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTrainGame());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTrainGame

}
// CopyPaste.Learning