
// Action
//   - Show brewer and beer in a data grid (brewer can be filters on the first letter)
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBeerBrewerTypedFilterDatagrid: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Panel panBottom;
    internal System.Windows.Forms.DataGrid dgrBrewerBeer;
    internal System.Windows.Forms.Panel panTop;
    internal System.Windows.Forms.ComboBox cmbFilter;
    internal System.Windows.Forms.Label lblChoose;
    private  Code.dsData dsData;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBeerBrewerTypedFilterDatagrid));
      this.panBottom = new System.Windows.Forms.Panel();
      this.dgrBrewerBeer = new System.Windows.Forms.DataGrid();
      this.panTop = new System.Windows.Forms.Panel();
      this.cmbFilter = new System.Windows.Forms.ComboBox();
      this.lblChoose = new System.Windows.Forms.Label();
      this.dsData = new Code.dsData();
      this.panBottom.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgrBrewerBeer)).BeginInit();
      this.panTop.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.SuspendLayout();
      // 
      // panBottom
      // 
      this.panBottom.Controls.Add(this.dgrBrewerBeer);
      this.panBottom.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panBottom.Location = new System.Drawing.Point(0, 48);
      this.panBottom.Name = "panBottom";
      this.panBottom.Size = new System.Drawing.Size(888, 557);
      this.panBottom.TabIndex = 4;
      // 
      // dgrBrewerBeer
      // 
      this.dgrBrewerBeer.AlternatingBackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(128)));
      this.dgrBrewerBeer.DataMember = "";
      this.dgrBrewerBeer.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgrBrewerBeer.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrBrewerBeer.Location = new System.Drawing.Point(0, 0);
      this.dgrBrewerBeer.Name = "dgrBrewerBeer";
      this.dgrBrewerBeer.ReadOnly = true;
      this.dgrBrewerBeer.Size = new System.Drawing.Size(888, 557);
      this.dgrBrewerBeer.TabIndex = 0;
      // 
      // panTop
      // 
      this.panTop.Controls.Add(this.cmbFilter);
      this.panTop.Controls.Add(this.lblChoose);
      this.panTop.Dock = System.Windows.Forms.DockStyle.Top;
      this.panTop.Location = new System.Drawing.Point(0, 0);
      this.panTop.Name = "panTop";
      this.panTop.Size = new System.Drawing.Size(888, 48);
      this.panTop.TabIndex = 3;
      // 
      // cmbFilter
      // 
      this.cmbFilter.Location = new System.Drawing.Point(104, 16);
      this.cmbFilter.Name = "cmbFilter";
      this.cmbFilter.Size = new System.Drawing.Size(72, 21);
      this.cmbFilter.TabIndex = 2;
      this.cmbFilter.SelectedIndexChanged += new System.EventHandler(this.cmbFilter_SelectedIndexChanged);
      // 
      // lblChoose
      // 
      this.lblChoose.Location = new System.Drawing.Point(16, 16);
      this.lblChoose.Name = "lblChoose";
      this.lblChoose.Size = new System.Drawing.Size(88, 23);
      this.lblChoose.TabIndex = 1;
      this.lblChoose.Text = "Choose a letter";
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.Locale = new System.Globalization.CultureInfo("en-US");
      // 
      // frmBeerBrewerTypedFilterDatagrid
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(888, 605);
      this.Controls.Add(this.panBottom);
      this.Controls.Add(this.panTop);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBeerBrewerTypedFilterDatagrid";
      this.Text = "Beer Brewer Typed Datagrid";
      this.Load += new System.EventHandler(this.frmBeerBrewerTypedFilterDatagrid_Load);
      this.panBottom.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgrBrewerBeer)).EndInit();
      this.panTop.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBeerBrewerTypedFilterDatagrid'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBeerBrewerTypedFilterDatagrid()
      //***
      // Action
      //   - Create new instance of 'frmBeerBrewerTypedFilterDatagrid'
      // Called by
      //   - frmMain.cmdBeerAndBrewerTypedFilterDatagrid_Click(System.Object, System.EventArgs) Handles cmdBeerAndBrewerTypedFilterDatagrid.Click
      //   - User action (Starting the form)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
    }
    // frmBeerBrewerTypedFilterDatagrid()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmbFilter_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new data view
      //   - Set the table of the data view to the table brewer of the data set
      //   - Set row filter (with the option of the combo box)
      //   - Set the data source of the data grid to the data view
      // Called by
      //   - User action (Changing the option in a combo box)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DataView dtvBrewerBeer = new DataView();

      // VVDW - Code below is done because there is an error when you change the filter when beers are shown
      dgrBrewerBeer.DataSource = dsData;
      dgrBrewerBeer.DataMember = "tblCPBrewer";

      dtvBrewerBeer.Table = dsData.tblCPBrewer;
      dtvBrewerBeer.RowFilter = "strBrewerName LIKE '" + cmbFilter.SelectedItem.ToString() + "%'";
      dgrBrewerBeer.DataSource = dtvBrewerBeer;
    }
    // cmbFilter_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbFilter.SelectedIndexChanged

    private void frmBeerBrewerTypedFilterDatagrid_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a character 'A'
      //   - Create a new instance of cpCommand
      //   - Try to
      //     - Merge the found data set of brewers and beers (default option for brewer and beer is true)
      //     - Set the data source of the data grid to the data set
      //     - Starting point is the brewer
      //     - Loop till the letter 'Z' is reached
      //       - Add the letter to the combo box (to filter)
      //       - Go to the next letter
      //   - On possible error
      //     - Show exception message
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCommand()
      //   - dsData cpCommand.FindBrewerBeersTypedDataSet()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      char chrLetter = 'A';
      cpCommand thecpCommand = new cpCommand();

      try
      {
        dsData.Merge(thecpCommand.FindBrewerBeersTypedDataSet(true, true));
        dgrBrewerBeer.DataSource = dsData;
        dgrBrewerBeer.DataMember = "tblCPBrewer";

        while (chrLetter <= 'Z')
        {
          cmbFilter.Items.Add(chrLetter);
          chrLetter = Convert.ToChar(Convert.ToInt32(chrLetter) + 1);
        }
        // chrLetter > 'Z'
      
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // frmBeerBrewerTypedFilterDatagrid_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBeerBrewerTypedFilterDatagrid

}
// CopyPaste.Learning