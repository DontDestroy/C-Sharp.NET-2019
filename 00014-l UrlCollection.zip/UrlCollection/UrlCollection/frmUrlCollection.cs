//***
// Action
//   - A textbox and 2 buttons
//   - An url is typed, and the url is visited
//   - All visited urls are remembered
// Created
//   - CopyPaste � 20240708 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240708 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmUrlCollection: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdList;
    internal System.Windows.Forms.Button cmdVisitSite;
    internal System.Windows.Forms.TextBox txtURL;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmUrlCollection));
      this.cmdList = new System.Windows.Forms.Button();
      this.cmdVisitSite = new System.Windows.Forms.Button();
      this.txtURL = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdList
      // 
      this.cmdList.Location = new System.Drawing.Point(162, 55);
      this.cmdList.Name = "cmdList";
      this.cmdList.Size = new System.Drawing.Size(120, 23);
      this.cmdList.TabIndex = 5;
      this.cmdList.Text = "List all Visited Sites";
      this.cmdList.Click += new System.EventHandler(this.cmdList_Click);
      // 
      // cmdVisitSite
      // 
      this.cmdVisitSite.Location = new System.Drawing.Point(74, 55);
      this.cmdVisitSite.Name = "cmdVisitSite";
      this.cmdVisitSite.TabIndex = 4;
      this.cmdVisitSite.Text = "Visit Site";
      this.cmdVisitSite.Click += new System.EventHandler(this.cmdVisitSite_Click);
      // 
      // txtURL
      // 
      this.txtURL.Location = new System.Drawing.Point(10, 15);
      this.txtURL.Name = "txtURL";
      this.txtURL.Size = new System.Drawing.Size(272, 20);
      this.txtURL.TabIndex = 3;
      this.txtURL.Text = "www.microsoft.com";
      // 
      // frmUrlCollection
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 93);
      this.Controls.Add(this.cmdList);
      this.Controls.Add(this.cmdVisitSite);
      this.Controls.Add(this.txtURL);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmUrlCollection";
      this.Text = "Type an URL and visit it";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmUrlCollection'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240708 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240708 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmUrlCollection()
      //***
      // Action
      //   - Create instance of 'frmUrlCollection'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240708 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240708 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmUrlCollection()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    ArrayList URLsVisited = new ArrayList();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdList_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - List thru all the visited urls
      //     - Generate a text that contains them
      //   - Show the result
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240708 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240708 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strAllURLs = "";

      foreach (string strURLName in URLsVisited)
      {
        strAllURLs = strAllURLs + strURLName + Environment.NewLine;
      }
      // in URLsVisited

      MessageBox.Show(strAllURLs, "Web sites visited", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // cmdList_Click(System.Object, System.EventArgs) Handles cmdList.Click

    private void cmdVisitSite_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Add the url to the collection
      //   - Go to the website in the Internet Explorer browser
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240708 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240708 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      URLsVisited.Add(txtURL.Text);
      System.Diagnostics.Process.Start(txtURL.Text);
    }
    // cmdVisitSite_Click(System.Object, System.EventArgs) Handles cmdVisitSite.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmUrlCollection
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDefault()
      // Created
      //   - CopyPaste � 20240708 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240708 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmUrlCollection());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmUrlCollection

}
// CopyPaste.Learning