//***
// Action
//   - A block game
//   - Working with properties (Get and Set) and methods in a class
//   - Possible Solution 3
// Created
//   - CopyPaste � 20240214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240214 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Learning.Games;
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMoveTest: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.IContainer components;
    internal System.Windows.Forms.Timer tmrTimer;
    internal System.Windows.Forms.Panel panMovingArea;
    internal System.Windows.Forms.Label lblBlock;
    internal System.Windows.Forms.PictureBox picBall;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMoveTest));
      this.tmrTimer = new System.Windows.Forms.Timer(this.components);
      this.panMovingArea = new System.Windows.Forms.Panel();
      this.lblBlock = new System.Windows.Forms.Label();
      this.picBall = new System.Windows.Forms.PictureBox();
      this.panMovingArea.SuspendLayout();
      this.SuspendLayout();
      // 
      // tmrTimer
      // 
      this.tmrTimer.Interval = 20;
      this.tmrTimer.Tick += new System.EventHandler(this.tmrTimer_Tick);
      // 
      // panMovingArea
      // 
      this.panMovingArea.BackColor = System.Drawing.Color.Transparent;
      this.panMovingArea.Controls.Add(this.lblBlock);
      this.panMovingArea.Controls.Add(this.picBall);
      this.panMovingArea.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panMovingArea.Location = new System.Drawing.Point(0, 0);
      this.panMovingArea.Name = "panMovingArea";
      this.panMovingArea.Size = new System.Drawing.Size(342, 219);
      this.panMovingArea.TabIndex = 23;
      // 
      // lblBlock
      // 
      this.lblBlock.BackColor = System.Drawing.Color.Red;
      this.lblBlock.ForeColor = System.Drawing.Color.Yellow;
      this.lblBlock.Location = new System.Drawing.Point(96, 80);
      this.lblBlock.Name = "lblBlock";
      this.lblBlock.Size = new System.Drawing.Size(160, 56);
      this.lblBlock.TabIndex = 23;
      this.lblBlock.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // picBall
      // 
      this.picBall.BackColor = System.Drawing.Color.Brown;
      this.picBall.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBall.Location = new System.Drawing.Point(56, 96);
      this.picBall.Name = "picBall";
      this.picBall.Size = new System.Drawing.Size(10, 10);
      this.picBall.TabIndex = 22;
      this.picBall.TabStop = false;
      // 
      // frmMoveTest
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(342, 219);
      this.Controls.Add(this.panMovingArea);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMoveTest";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Move Test";
      this.Load += new System.EventHandler(this.frmMoveTest_Load);
      this.panMovingArea.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMoveTest'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMoveTest()
      //***
      // Action
      //   - Create instance of 'frmMoveTest'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMoveTest()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpMove mcpBall;
    private cpMove mcpBlock01;
    private cpBlockGame mcpBlockGame;
    private Rectangle mrecMovingArea;
    private cpCollision mcpCollision;
    private int mlngCounter;
    
    #endregion

    #region "Properties"

    private Rectangle MovingArea
    {

      get
        //***
        // Action Get
        //   - Return the MovingArea for the moving object (mrecMovingArea)
        // Called by
        //   - frmMoveTest_Load(System.Object, System.EventArgs) Handles this.Load
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mrecMovingArea;
      }
      // Rectangle MovingArea (Get)

      set
        //***
        // Action Set
        //   - Set the MovingArea for the moving object (mrecMovingArea becomes value)
        // Called by
        //   - frmMoveTest_Load(System.Object, System.EventArgs) Handles this.Load
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mrecMovingArea = value;
      }
      // MovingArea(Rectangle) (Set)

    }
    // Rectangle MovingArea

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmMoveTest_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Preparing the startup of the game
      //   - Determine a moving area (movements can't go outside this)
      //   - Determine the block game
      //   - Determine the collision
      //   - Determine the movement of the ball
      //   - Determine the movement of the block
      //   - Enable the timer
      // Called by
      //   - Starting the application (when this form is marked as startup object)
      // Calls
      //   - cpBlockGame(int, int, int, Control, Control)
      //   - cpCollision(cpBlockGame)
      //   - cpMove(Control, Rectangle, double, int)
      //   - MovingArea(Rectangle) (Set)
      //   - Rectangle MovingArea (Get)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MovingArea = new Rectangle(panMovingArea.Left, panMovingArea.Top, panMovingArea.Width, panMovingArea.Height);
      mcpBlockGame = new cpBlockGame(lblBlock, lblBlock);
      mcpCollision = new cpCollision(mcpBlockGame);
      mcpBall = new cpMove(picBall, MovingArea, 60, 3);
      mcpBlock01 = new cpMove(lblBlock, MovingArea, 0, 0);
      tmrTimer.Enabled = true;
    }
    // frmMoveTest_Load(System.Object, System.EventArgs) Handles this.Load
    
    private void tmrTimer_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Actions to be taken every time the games progresses
      //   - Move the ball
      //   - Move the block
      //   - Checked on collision
      // Called by
      //   - Program action (The beating heart of the game)
      // Called by
      //   - 
      // Calls
      //   - CheckCollision()
      //   - cpMove.Move()
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mcpBall.Move();
      mcpBlock01.Move();
      CheckCollision();
    }
    // tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void CheckCollision()
      //***
      // Action
      //   - Check if the ball is hitting something
      // Called by
      //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - cpCollision.CheckHit(cpMove, cpMove, bool)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mcpCollision.CheckHit(mcpBall, mcpBlock01, false);
    }
    // CheckCollision()

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMoveTest
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMoveTest());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMoveTest

}
// CopyPaste.Learning