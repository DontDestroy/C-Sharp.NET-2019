﻿//***
// Action
//   - An example of working with Tuples
// Created
//   - CopyPaste – 20251130 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251130 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpTuple
  {

    #region "Constructors / Destructors"

    public cpTuple()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251130 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpTuple()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public (string, int) GetGuitarType()
    //***
    // Action
    //   - Return a tuple (string, int)
    //     - The type / brand of the Guitar
    //     - The number of strings of the Guitar
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251130 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return ("Classical Guitar", 6);
    }
    // (string, int) GetGuitarType()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpTuple

}
// CopyPaste.Learning