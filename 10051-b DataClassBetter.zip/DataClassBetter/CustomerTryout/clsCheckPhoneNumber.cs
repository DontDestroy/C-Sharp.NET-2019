﻿//***
// Action
//   - Check the validations on a phone number
// Created
//   - CopyPaste – 20260121 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260121 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpCheckPhoneNumber: cpCheckString
  {

    #region "Constructors / Destructors"

    public cpCheckPhoneNumber(cpCheckPhoneNumber thePhoneNumber): this(thePhoneNumber.StringValue)
      //***
      // Action
      //   - Define a new instance with a given check phone number
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - cpCheckPhoneNumber(string)
      //   - string cpCheckString.StringValue (Get)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpCheckPhoneNumber(cpCheckPhoneNumber)

    public cpCheckPhoneNumber(string strPhoneNumber): base()
      //***
      // Action
      //   - Define a new instance with a given phone number
      // Called by
      //   - cpCheckBusinessPhoneNumber(string, cpCheckExtension)
      //   - cpCustomer(cpKeyCustomer, string)
      //   - User action (Creating an instance)
      // Calls
      //   - cpCheckString.StringValue(string) (Set)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpCheckPhoneNumber(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void DefineValidCharacters()
      //***
      // Action
      //   - Define the valid characters for a phone number
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // DefineValidCharacters()

    protected override cpInvalidStringException ThrowException(string strInvalidPhone)
      //***
      // Action
      //   - Throw an exception with information
      // Called by
      //   - 
      // Calls
      //   - cpInvalidPhoneNumberException(string)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return null;
    }
    // cpInvalidStringException ThrowException(string)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
		//#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCheckPhoneNumber

}
// CopyPaste.Learning