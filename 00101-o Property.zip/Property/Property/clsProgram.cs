//***
// Action
//   - Test a cpBook
// Created
//   - CopyPaste � 20220308 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220308 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Toolkit;
using System;

namespace Property
{

  class cpProgram
	{

    static void Main()
      //***
      // Action
      //   - Define 2 books, with 2 variabels and 2 properties
      //   - Show the values of the variabels and properties of the 2 books
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpBook(String, String)
      //   - cpBook.Pages(int) (Set)
      //   - cpBook.Price(double) (Set)
      //   - double cpBook.Price (Get)
      //   - int cpBook.Pages (Get)
      // Created
      //   - CopyPaste � 20220308 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220308 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBook Palm = new cpBook("Instant Palm OS Applications", "Jamsa");
      cpBook Upgrading = new cpBook("PC Performance Tuning & Upgrading Tips & Techniques", "Jamsa");
      
      Palm.Price = 49.99;
      Palm.Pages = 2000;
      // Palm.Pages = 3456;
      Console.WriteLine("Palm Title: " + Palm.mstrTitle);
      Console.WriteLine("Palm Author: " + Palm.mstrAuthor);
      Console.WriteLine("Palm Price: " + Palm.Price);
      Console.WriteLine("Palm Pages: " + Palm.Pages);
      Console.WriteLine();
      
      Upgrading.Price = 99.99;
      // Upgrading.Price = 519.99;
      Upgrading.Pages = 600;
      Console.WriteLine("Upgrading Title: " + Upgrading.mstrTitle);
      Console.WriteLine("Upgrading Author: " + Upgrading.mstrAuthor);
      Console.WriteLine("Upgrading Price: " + Upgrading.Price);
      Console.WriteLine("Upgrading Pages: " + Upgrading.Pages);
      Console.ReadLine();

    }
    // Main()

	}
  // cpProgram

}
// Property