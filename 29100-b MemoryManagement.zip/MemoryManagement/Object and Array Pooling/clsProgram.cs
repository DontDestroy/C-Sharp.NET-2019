﻿//***
// Action
//   - Demo some Object Pooling and Array Pooling
//   - Compare different ways of parsing with buffers
// Created
//   - CopyPaste – 20260608 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260608 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - Main()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260608 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260608 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Benchmark the marked routines to compare the speed and the memory
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpReuseInstances()
    //   - cpReuseInstances.MessageParserArray()
    //   - cpReuseInstances.MessageParserArrayPool()
    //   - cpReuseInstances.MessageParserObjectPool()
    // Created
    //   - CopyPaste – 20260608 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260608 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      BenchmarkRunner.Run<cpReuseInstances>();

      // cpReuseInstances theInstance = new cpReuseInstances();
            
      // theInstance.MessageParserArray();
      // theInstance.MessageParserArrayPool();
      // theInstance.MessageParserObjectPool();
      // theInstance.MessageParserObjectPoolAdvanced();

      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadKey();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning