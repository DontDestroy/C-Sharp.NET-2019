﻿//***
// Action
//   - A definition of a ThreadContractor
// Created
//   - CopyPaste – 20251104 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251104 – VVDW
// Proposal (To Do)
//   -
//***

using java.lang;
using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpThreadContractor : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpThreadContractor(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpThreadContractor starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpThreadContractor(int, int, Directions.Direction, int) 
    //   - cpProgram.Contractor()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpThreadContractor(int, int, Directions.Direction, int, Color) 

    public cpThreadContractor(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpThreadContractor starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpThreadContractor(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpThreadContractor(int, int, Directions.Direction, int) 

    #endregion

    #region "Designer"

    public class cpCarpenterRunner : Runnable
    {
      // For clearness not all comments according to Copy Paste Normal Comments are added in this class

      public void run()
      //***
      // Action
      //   - Define what must be runned
      // Called by
      //   - cpProgram.ThreadContractor()
      // Calls
      //   - CarpenterTask()
      // Created
      //   - CopyPaste – 20251104 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251104 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        CarpenterTask();
      }
      // run()

    }
    // cpCarpenterRunner

    public class cpMasonRunner : Runnable
    {
      // For clearness not all comments according to Copy Paste Normal Comments are added in this class

      public void run()
      //***
      // Action
      //   - Define what must be runned
      // Called by
      //   - cpProgram.ThreadContractor()
      // Calls
      //   - MasonTask()
      // Created
      //   - CopyPaste – 20251104 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251104 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        MasonTask();
      }
      // run()

    }
    // cpMasonRunner 

    public class cpRooferRunner : Runnable
    {
      // For clearness not all comments according to Copy Paste Normal Comments are added in this class

      public void run()
      //***
      // Action
      //   - Define what must be runned
      // Called by
      //   - cpProgram.ThreadContractor()
      // Calls
      //   - RooferTask()
      // Created
      //   - CopyPaste – 20251105 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251105 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        RooferTask();
      }
      // run()

    }
    // cpRooferRunner

    #endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void CarpenterTask()
    //***
    // Action
    //   - Go back to the origin
    //   - Go to the position for the door
    //   - Build the wall
    //   - Go back to the origin
    //   - Go to the position for the first window
    //   - Build the window
    //   - Go back to the origin
    //   - Go to the position for the second window
    //   - Build the window
    //   - Go back to the origin
    //   - Switch the robot off
    // Called by
    //   - cpCarpenterRunner.run()
    // Calls
    //   - cpCopyPasteRobot.GoToStartPosition()
    //   - cpThreadCarpenter(int, int, Directions.Direction, int, Color) 
    //   - cpThreadCarpenter.BuildDoor()
    //   - cpThreadCarpenter.BuildWindow()
    //   - cpThreadCarpenter.GoToStartDoor()
    //   - cpThreadCarpenter.GoToStartFirstWindow()
    //   - cpThreadCarpenter.GoToStartSecondWindow()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpThreadCarpenter josephTheCarpenter = new cpThreadCarpenter(1, 1, Directions.East, Directions.infinity, Color.yellow);

      josephTheCarpenter.GoToStartDoor();
      josephTheCarpenter.BuildDoor();
      josephTheCarpenter.GoToStartPosition();
      josephTheCarpenter.GoToStartFirstWindow();
      josephTheCarpenter.BuildWindow();
      josephTheCarpenter.GoToStartPosition();
      josephTheCarpenter.GoToStartSecondWindow();
      josephTheCarpenter.BuildWindow();
      josephTheCarpenter.GoToStartPosition();
      josephTheCarpenter.turnOff();
    }
    // CarpenterTask()

    public static void MasonTask()
    //***
    // Action
    //   - Go back to the origin
    //   - Go to the position for the first wall
    //   - Build the wall
    //   - Go back to the origin
    //   - Go to the position for the second wall
    //   - Build the wall
    //   - Go back to the origin
    //   - Switch the robot off
    // Called by
    //   - cpMasonRunner.run()
    // Calls
    //   - cpCopyPasteRobot.GoToStartPosition()
    //   - cpThreadMason(int, int, Directions.Direction, int, Color) 
    //   - cpThreadMason.BuildWall()
    //   - cpThreadMason.GoToStartFirstWall()
    //   - cpThreadMason.GoToStartSecondWall()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpThreadMason bobTheBuilder = new cpThreadMason(1, 1, Directions.East, Directions.infinity, Color.red);

      bobTheBuilder.GoToStartFirstWall();
      bobTheBuilder.BuildWall();
      bobTheBuilder.GoToStartPosition();
      bobTheBuilder.GoToStartSecondWall();
      bobTheBuilder.BuildWall();
      bobTheBuilder.GoToStartPosition();
    }
    // MasonTask()

    public static void RooferTask()
    //***
    // Action
    //   - Go back to the origin
    //   - Go to the position for the roof
    //   - Build the wall
    //   - Go back to the origin
    //   - Switch the robot off
    // Called by
    //   - cpRooferRunner.run()
    // Calls
    //   - cpCopyPasteRobot.GoToStartPosition()
    //   - cpThreadRoofer(int, int, Directions.Direction, int, Color) 
    //   - cpThreadRoofer.BuildRoof()
    //   - cpThreadRoofer.GoToStartRoof()
    // Created
    //   - CopyPaste – 20251105 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251105 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpThreadRoofer fidlerTheRoofer = new cpThreadRoofer(1, 1, Directions.East, Directions.infinity, Color.blue);

      fidlerTheRoofer.GoToStartPosition();
      fidlerTheRoofer.GoToStartRoof();
      fidlerTheRoofer.BuildRoof();
      fidlerTheRoofer.GoToStartPosition();
      fidlerTheRoofer.turnOff();
    }
    // RooferTask()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpThreadContractor

}
// cpKarelTheRobot