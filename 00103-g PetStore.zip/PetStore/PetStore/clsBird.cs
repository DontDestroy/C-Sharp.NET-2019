//***
// Action
//   - A pet store, the definition of a bird (base class, but inherits from cpPet)
//   - Working with properties (Get and Set) and methods in several classes, that can be reused
// Created
//   - CopyPaste � 20220316 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20220316 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace CopyPaste.Pet
{

  public class cpBird : cpPet
  {

    #region "Constructors / Destructors"

    public cpBird() : base ("Bird", 2)
      //***
      // Action
      //   - Creating an instance of cpBird with default parameters
      //   - Creating an instance of cpPet with parameters "Bird" and 2
      //   - Food becomes "Birdseed"
      //   - Write a line "cpBird default constructor"
      // Called by
      //   - CopyPaste.Pet.Bird.cpCockatiel()
      //   - CopyPaste.Pet.Bird.cpParakeet()
      // Calls
      //   - base(string, int)
      //   - CopyPaste.Pet.cpPet.Food(string) (Set)
      //   - CopyPaste.Pet.cpPet(string, int)
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      Food = "Birdseed";
      Console.WriteLine("cpBird default constructor");
    }
    // cpBird()

    public cpBird(string strName) : this()
      //***
      // Action
      //   - Creating an instance of cpBird with default parameters and set the name
      //   - Creating an instance of cpBird with default parameters
      //   - Name becomes strName
      //   - Write a line "cpBird overloaded constructor"
      // Called by
      //   - CopyPaste.Pet.Bird.cpParakeet(string, string)
      //   - CopyPaste.Pet.Bird.cpCockatiel(string, string)
      //   - cpProgram.FillArray()
      // Calls
      //   - CopyPaste.Pet.clsAnimal.Name(string) (Set)
      //   - this()
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      Name = strName;
      Console.WriteLine("cpBird overloaded constructor");
    }
    // cpBird(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"
    
    public override string Play() 
      //***
      // Action
      //   - Write a line to the console with "CopyPaste.Pet.cpAnimal.cpBird.Play"
      //   - Return "(Name) bites your finger"
      // Called by
      //   - frmPetStore.cmdPlay_Click(System.Object, System.EventArgs) Handles cmdPlay.Click
      // Calls
      //   - Overrides string CopyPaste.Pet.cpAnimal.Play()
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      Console.WriteLine("CopyPaste.Pet.cpAnimal.cpBird.Play");
      return Name + " bites your finger.";
    }
    // string Play()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBird

}
// CopyPaste.Pet