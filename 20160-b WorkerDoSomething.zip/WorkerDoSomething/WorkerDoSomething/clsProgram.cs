﻿//***
// Action
//   - Example of priority of extension methods
// Created
//   - CopyPaste – 20260130 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260130 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260130 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Extension methods do have a priority
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpWorker()
    //   - cpWorker.DoSomething()
    //   - cpWorkerExtension()
    //   - cpWorkerExtension.DoSomething(cpWorker) (Can't be executed)
    //   - cpWorkerExtension.DoSomething(cpWorker, int)
    // Created
    //   - CopyPaste – 20260130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260130 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpWorker theWorker = new cpWorker();

      theWorker.DoSomething();
      theWorker.DoSomething(3);

      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning