//***
// Action
//   - Class definition of cpEmployee
// Created
//   - CopyPaste � 20230419 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230419 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpEmployee
  {

    #region "Constructors / Destructors"
    
    public cpEmployee()
    //***
    // Action
    //   - Constructor of cpEmployee
    //   - Default values are given to the properties
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - Name(string) (Set)
    //   - StartDate(DateTime) (Set)
    // Created
    //   - CopyPaste � 20230419 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230419 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Name = "";
      StartDate = DateTime.Today;
    }
    // cpEmployee()

    public cpEmployee(string Name, aSex Sex, DateTime StartDate)
    //***
    // Action
    //   - Constructor of cpEmployee
    //   - Values are given to the properties using parameters (with same name)
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - Name(string) (Set)
    //   - Sex(aSex) (Set)
    //   - StartDate(DateTime) (Set)
    // Created
    //   - CopyPaste � 20230419 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230419 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      this.Name = Name;
      this.Sex = Sex;
      this.StartDate = StartDate;
    }
    // cpEmployee(string, aSex, DateTime)

    #endregion

    #region "Designer"

    public enum aSex
    {
      Male,
      Female
    }
    // aSex

    #endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private aSex theSex;
    private DateTime dtmStart;
    private readonly DateTime dtmStartCompany = new DateTime(2000, 10, 15);
    private string strName;

    #endregion

    #region "Properties"

    public string Name
    {

      get
      //***
      // Action Get
      //   - Returns strName
      // Called by
      //   - ShowInfo()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230419 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230419 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return strName;
      }
      // string Name (Get)

      set
      //***
      // Action Set
      //   - strName becomes value
      // Called by
      //   - cpEmployee()
      //   - cpEmployee(string, aSex, DateTime)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230419 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230419 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        strName = value;
      }
      // strName(string) (Set)

    }
    // string Name

    public aSex Sex
    {

      get
      //***
      // Action Get
      //   - Returns theSex
      // Called by
      //   - ShowInfo()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230419 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230419 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return theSex;
      }
      // aSex Sex (Get)

      set
      //***
      // Action Set
      //   - theSex becomes theValue
      // Called by
      //   - cpEmployee(string, aSex, DateTime)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230419 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230419 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        theSex = value;
      }
      // Sex(aSex) (Set)

    }
    // aSex Sex

    public DateTime StartDate
    {

      get
      //***
      // Action Get
      //   - Returns dtmStart
      // Called by
      //   - ShowInfo()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230419 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230419 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return dtmStart;
      }
      // DateTime StartDate (Get)

      set
      //***
      // Action Get
      //   - If dtmValue is before dtmStartCompany
      //     - dtmStart becomes dtmStartCompany
      //   - If Not
      //     - dtmStart becomes dtmValue
      // Called by
      //   - cpEmployee()
      //   - cpEmployee(string, aSex, DateTime)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230419 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230419 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if (value >= dtmStartCompany)
        {
          dtmStart = value;
        }
        else
          // value < dtmStartCompany
        {
          dtmStart = dtmStartCompany;
        }
        // value >= dtmStartCompany

      }
      // StartDate(DateTime) (Set)

    }
    // DateTime StartDate

    public bool WorkAnniversary
    {

      get
      //***
      // Action Get
      //   - If month and day are equal for today and start date
      //     - Returns True
      //   - If Not
      //'     - Returns False
      // Called by
      //   - ShowInfo()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230419 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230419 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if ((dtmStart.Month == DateTime.Today.Month) && (dtmStart.Day == DateTime.Today.Day))
        {
          return true;
        }
        else
          // dtmStart.Month <> Date.Today.Month || dtmStart.Day <> Date.Today.Day 
        {
          return false;
        }
        // dtmStart.Month = Date.Today.Month && dtmStart.Day = Date.Today.Day

      }
      // bool WorkAnniversary (Get)

    }
    // bool WorkAnniversary

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ShowInfo()
    //***
    // Action
    //   - Show the name
    //   - Show the gender
    //   - Show the startdate
    //   - Show if a cake must be bought
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - aSex Sex (Get)
    //   - bool WorkAnniversary() (Get)
    //   - DateTime StartDate() (Get)
    //   - string Name (Get)
    // Created
    //   - CopyPaste � 20230419 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230419 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine("Name: {0}", Name);
      Console.WriteLine("Sex: {0}", Sex.ToString());
      Console.WriteLine("Start date: {0}", StartDate);
      Console.WriteLine("Needs to buy a cake: {0}", WorkAnniversary);
    }
    // ShowInfo()
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpEmployee

}
// CopyPaste.Learning