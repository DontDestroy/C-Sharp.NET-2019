//***
// Action
//   - Testroutine fo cpiAnimal and cpWolf
// Created
//   - CopyPaste � 20240628 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240628 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create an instance of a cpWolf
      //   - Shows the name
      //   - Shows the noise a cpWolf makes
      //   - Shows the food a cpWolf eats
      //   - Destroys the cpWorf
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpWolf()
      //   - string cpWolf.Eat()
      //   - string cpWolf.Name (Get)
      //   - string cpWolf.NoiseSound()
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpWolf thecpWolf = new cpWolf();

      Console.WriteLine("Name: " + thecpWolf.Name);
      Console.WriteLine("Noise: " + thecpWolf.NoiseSound());
      Console.WriteLine("Eats: " + thecpWolf.Eat());
      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadLine();
      thecpWolf = null;
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning