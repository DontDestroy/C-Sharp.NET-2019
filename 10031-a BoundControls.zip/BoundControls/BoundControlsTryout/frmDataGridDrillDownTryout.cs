//***
// Action
//   - Drill down to data in the data grid control
// Created
//   - CopyPaste � 20251231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251231 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDataGridDrillDownTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdOrderDetail;
    internal System.Windows.Forms.Label lblChooseCustomer;
    internal System.Windows.Forms.DataGrid dgrOrder;
    internal System.Windows.Forms.ComboBox cmbCustomer;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDataGridDrillDownTryout));
      this.cmdOrderDetail = new System.Windows.Forms.Button();
      this.lblChooseCustomer = new System.Windows.Forms.Label();
      this.dgrOrder = new System.Windows.Forms.DataGrid();
      this.cmbCustomer = new System.Windows.Forms.ComboBox();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdOrderDetail
      // 
      this.cmdOrderDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdOrderDetail.Location = new System.Drawing.Point(316, 280);
      this.cmdOrderDetail.Name = "cmdOrderDetail";
      this.cmdOrderDetail.Size = new System.Drawing.Size(80, 23);
      this.cmdOrderDetail.TabIndex = 7;
      this.cmdOrderDetail.Text = "Order detail";
      this.cmdOrderDetail.Click += new System.EventHandler(this.cmdOrderDetail_Click);
      // 
      // lblChooseCustomer
      // 
      this.lblChooseCustomer.Location = new System.Drawing.Point(20, 16);
      this.lblChooseCustomer.Name = "lblChooseCustomer";
      this.lblChooseCustomer.Size = new System.Drawing.Size(160, 16);
      this.lblChooseCustomer.TabIndex = 4;
      this.lblChooseCustomer.Text = "Customers to List Orders For:";
      // 
      // dgrOrder
      // 
      this.dgrOrder.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrOrder.DataMember = "tblCPOrder";
      this.dgrOrder.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrOrder.Location = new System.Drawing.Point(28, 56);
      this.dgrOrder.Name = "dgrOrder";
      this.dgrOrder.ReadOnly = true;
      this.dgrOrder.Size = new System.Drawing.Size(368, 208);
      this.dgrOrder.TabIndex = 6;
      // 
      // cmbCustomer
      // 
      this.cmbCustomer.DisplayMember = "tblCPCustomer.strCompanyName";
      this.cmbCustomer.DropDownWidth = 192;
      this.cmbCustomer.Location = new System.Drawing.Point(196, 16);
      this.cmbCustomer.Name = "cmbCustomer";
      this.cmbCustomer.Size = new System.Drawing.Size(192, 21);
      this.cmbCustomer.TabIndex = 5;
      this.cmbCustomer.ValueMember = "tblCPCustomer.strIdCustomer";
      this.cmbCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbCustomer_SelectedIndexChanged);
      // 
      // frmDataGridDrillDownTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(416, 317);
      this.Controls.Add(this.cmbCustomer);
      this.Controls.Add(this.cmdOrderDetail);
      this.Controls.Add(this.lblChooseCustomer);
      this.Controls.Add(this.dgrOrder);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataGridDrillDownTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Bind Data To ComboBox and DataGrid Controls Tryout";
      this.Load += new System.EventHandler(this.frmDataGridDrillDownTryout_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDataGridDrillDownTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDataGridDrillDownTryout()
      //***
      // Action
      //   - Create instance of 'frmDataGridDrillDownTryout'
      //   - Set the global variable to this instance
      // Called by
      //   - frmBoundCountrolsMainTryout.cmdDrillDown_Click(System.Object, System.EventArgs) Handles cmdDrillDown.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDataGridDrillDownTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmbCustomer_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Refresh the orders
      // Called by
      //   - User action (Choosing an item in a combo box)
      // Calls
      //   - RefreshOrders()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmbCustomer_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbCustomer.SelectedIndexChanged

    private void cmdOrderDetail_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmOrderDetail
      //   - Show it on the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmOrderDetail()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdOrderDetail_Click(System.Object, System.EventArgs) Handles cmdOrderDetail.Click

    private void frmDataGridDrillDownTryout_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Fill the data set customers (using the data adapter)
      //   - Refresh the orders
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - RefreshOrders()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmComboBoxDataGridTryout_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void RefreshOrders()
      //***
      // Action
      //   - Clear the data set of the orders
      //   - If a customer is selected
      //     - Declare and initialize a data row view to the selected record
      //     - Set the command to a data adapter (using the unique key of the customer)
      //     - Fill the data set using the data adapter
      //   - If not
      //     - Do nothing
      // Called by
      //   - cmbCustomer_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbCustomer.SelectedIndexChanged
      //   - frmComboBoxDataGridTryout_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // RefreshOrders()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataGridDrillDownTryout

}
// CopyPaste.Learning