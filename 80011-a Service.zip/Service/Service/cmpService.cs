//***
// Action
//   - Example of a Windows Service
// Created
//   - CopyPaste � 20260831 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260831 � VVDW
// Proposal (To Do)
//   - To be able to install, Visual Studio must be started wit Administrator privileges
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.ServiceProcess;

namespace CopyPaste.Learning
{

  public class cpService : System.ServiceProcess.ServiceBase
	{

    #region Component Designer generated code

    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      this.CanPauseAndContinue = true;
      this.CanShutdown = true;
      this.ServiceName = "cpService";
    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpService'
      // Called by
      //   - User action (Closing the service)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260831 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260831 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpService()
      //***
      // Action
      //   - Create instance of 'cpService'
      // Called by
      //   - Main()
      //   - User action (Starting the service)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260831 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260831 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // cpService()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private StreamWriter mstrWriter;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    protected override void OnContinue()
      //***
      // Action
      //   - Try to
      //     - Write information to the log file
      //     - Make that the information sticks in the file
      // Called by
      //   - User action (Continuing the service)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260831 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260831 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        mstrWriter.WriteLine("Service continued at " + DateTime.Now.ToString("yyyyMMdd hh:mm:ss"));
        mstrWriter.Flush();
      }
      catch (Exception theException)
      {
      }

    }
    // OnContinue()

    protected override void OnPause()
      //***
      // Action
      //   - Try to
      //     - Write information to the log file
      //     - Make that the information sticks in the file
      // Called by
      //   - User action (Pauzing the service)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260831 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260831 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        mstrWriter.WriteLine("Service paused at " + DateTime.Now.ToString("yyyyMMdd hh:mm:ss"));
        mstrWriter.Flush();
      }
      catch (Exception theException)
      {
      }

    }
    // OnPause()

    protected override void OnShutdown()
      //***
      // Action
      //   - Try to
      //     - Write information to the log file
      //     - Close the file
      // Called by
      //   - User action (Shutdown the service)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260831 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260831 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        mstrWriter.WriteLine("Service shutdown at " + DateTime.Now.ToString("yyyyMMdd hh:mm:ss"));
        mstrWriter.Close();
      }
      catch (Exception theException)
      {
      }

    }
    // OnShutDown()

    protected override void OnStart(string[] arrstrArgument)
      //***
      // Action
      //   - Try to
      //     - Create a new stream writer to a specific location, that appends information
      //     - Write information to the log file
      //     - Make that the information sticks in the file
      // Called by
      //   - User action (Start the service)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260831 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260831 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        mstrWriter = new StreamWriter("T:\\cpEvents.log", true);
        mstrWriter.WriteLine("Service started at " + DateTime.Now.ToString("yyyyMMdd hh:mm:ss"));
        mstrWriter.Flush();
      }
      catch (Exception theException)
      {
      }

    }
    // OnStart(string[])
 
    protected override void OnStop()
      //***
      // Action
      //   - Try to
      //     - Write information to the log file
      //     - Close the file
      // Called by
      //   - User action (Stop the service)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260831 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260831 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        mstrWriter.WriteLine("Service stopped at " + DateTime.Now.ToString("yyyyMMdd hh:mm:ss"));
        mstrWriter.Flush();
      }
      catch (Exception theException)
      {
      }

    }
    // OnStop()

    #endregion

    #region "Sub / Function"

    [MTAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Starting routine of the service
      //   - Define an array of ServicesToRun
      //   - Add a new cpService to it
      //   - Run them
      // Called by
      //   - User action (Starting the service)
      // Calls
      //   - cpService()
      // Created
      //   - CopyPaste � 20260831 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260831 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      System.ServiceProcess.ServiceBase[] ServicesToRun;
	
      ServicesToRun = new System.ServiceProcess.ServiceBase[] { new cpService() };
      System.ServiceProcess.ServiceBase.Run(ServicesToRun);
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpService

}
// CopyPaste.Learning