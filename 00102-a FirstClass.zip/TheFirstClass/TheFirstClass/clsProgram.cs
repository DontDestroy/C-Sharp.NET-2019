//***
// Action
//   - Test a cpEmployee and cpDivision
// Created
//   - CopyPaste � 20220411 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220411 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  class cpProgram
	{

    static void Main()
      //***
      // Action
      //   - Define 2 Divisions
      //   - Fill in the properties for the first employee
      //   - Fill in the properties for the second employee
      //   - Show the information of the first employee
      //   - If the type of the second employee is cpDivision
      //     - If Serialize
      //       - Show the information of the first employee
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - bool cpDivision.Serialize()
      //   - cpDivision.Division(string) (Set)
      //   - cpDivision.MonthsInDivision(int) (Set)
      //   - cpEmployee.FirstName(string) (Set)
      //   - cpEmployee.FirstName(string) (Set)
      //   - ShowEmployee(cpDivision)
      // Created
      //   - CopyPaste � 20220411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpDivision theEmployee1 = new cpDivision();
      cpDivision theEmployee2 = new cpDivision("Vincent", "Van De Walle");

      theEmployee1.FirstName = "Hilde";
      theEmployee1.LastName = "Saelens";
      theEmployee1.Division = "Secretary";
      theEmployee1.MonthsInDivision = 18;

      ShowEmployee(theEmployee1);

      theEmployee2.Division = "Management";
      theEmployee2.MonthsInDivision = 142;
            
      if (theEmployee2.GetType().ToString() == "CopyPaste.Learning.cpDivision")
      {

        if (theEmployee2.Serialize())
        {
          ShowEmployee(theEmployee2);
        }
        else
          // Not theEmployee2.Serialize()
        {
        }
        // theEmployee2.Serialize()

      }

    }
    // Main()

    static void ShowEmployee(cpDivision theCurrentEmployee)
      //***
      // Action
      //   - Create a display string
      //   - Show a messagebox with that display string
      // Called by
      //   - Main()
      // Calls
      //   - int cpDivision.MonthsInDivision() (Get)
      //   - int cpEmployee.EmployeeNumber() (Get)
      //   - string cpDivision.Division() (Get)
      //   - string cpEmployee.FirstName() (Get)
      //   - string cpEmployee.LastName() (Get)
      // Created
      //   - CopyPaste � 20070205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070205 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strDisplayString;

      strDisplayString = "Employee Name: " + theCurrentEmployee.FirstName + " " + theCurrentEmployee.LastName + "\n";  
      strDisplayString += "Employee Division: " + theCurrentEmployee.Division + "\n";
      strDisplayString += "Employee Months: " + theCurrentEmployee.MonthsInDivision + "\n";
      strDisplayString += "Employee Number: " + theCurrentEmployee.EmployeeNumber + "\n";
      
      MessageBox.Show(strDisplayString, "Employee Scanner", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // ShowEmployee(cpDivision)

	}
  // cpProgram

}
// CopyPaste.Learning