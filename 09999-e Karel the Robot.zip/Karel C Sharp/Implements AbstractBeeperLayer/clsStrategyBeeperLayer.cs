﻿//***
// Action
//   - A definition of a StrategyBeeperLayer
// Created
//   - CopyPaste – 20251028 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251028 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

  public class cpStrategyBeeperLayer : cpAbstractBeeperLayer
  {

    #region "Constructors / Destructors"

    public cpStrategyBeeperLayer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor, cpinfStrategy theStrategy) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpStrategyBeeperLayer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Assign the given strategy to myStrategy
    // Called by
    //   - cpProgram.StrategyDelegation()
    //   - cpStrategyBeeperLayer(int, int, Directions.Direction, int, cpinfStrategy)
    // Calls
    //   - cpStrategyBeeperLayer(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      myStrategy = theStrategy;
    }
    // cpStrategyBeeperLayer(int, int, Directions.Direction, int, Color, cpinfStrategy) 

    public cpStrategyBeeperLayer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, cpinfStrategy theStrategy) : this(intStreet, intAvenue, theDirection, intBeepers, null, theStrategy)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpStrategyBeeperLayer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpStrategyBeeperLayer(int, int, Directions.Direction, int, Color, cpinfStrategy)
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpStrategyBeeperLayer(int, int, Directions.Direction, int, cpinfStrategy) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpinfStrategy myStrategy = null;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override void PutBeepers()
    //***
    // Action
    //   - Execute by delegation the given strategy in the constructor
    // Called by
    //   - cpProgram.StrategyDelegation()
    // Calls
    //   - cpinfStrategy.DoIt(cpCopyPasteRobot);
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      myStrategy.DoIt(this);
    }
    // PutBeepers()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpStrategyBeeperLayer

}
// cpKarelTheRobot