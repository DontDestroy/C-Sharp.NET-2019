//***
// Action
//   - Two ways of generating a random number
// Created
//   - CopyPaste � 20240409 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240409 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;

namespace CopyPaste.Learning
{

  public class cpRandom
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Find a random number between a lowest and highest value using 2 different methods
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Method1
      //   - Method2
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Method1();
      Console.WriteLine();
      Method2();
      Console.WriteLine();
      Console.ReadLine();
    }
		// Main()

    public static void Method1()
      //***
      // Action
      //   - Find a random number between a lowest and highest value (both included)
      //   - Randomize with a Visual Basic statement
      //   - Get x times a random number (till you have the lowest possible number)
      //     - Subtract lowest from highest
      //     - Multiply with a random value between 0 (included) and 1 (excluded)
      //     - Add the lowest number to it
      //     - Take the integer value
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngHighest = 20;
      int lngLowest = 10;
      int lngResult = 0;

      VBMath.Randomize();
      Console.WriteLine("First method");
      Console.WriteLine("------------");

      while (lngResult != lngLowest)
      {
        lngResult = Convert.ToInt32((lngHighest - lngLowest) * VBMath.Rnd() + lngLowest);
        Console.WriteLine(lngResult);
      }
      // lngResult = lngLowest

    }
    // Method1()

    public static void Method2()
      //***
      // Action
      //   - Find a random number between a lowest (included) and highest value (encluded) using a seed value
      //   - Randomize with a .NET object
      //   - Get x times a random number (till you have the lowest possible number)
      //     - Subtract lowest from highest
      //     - Multiply with a random value between 0 (included) and 1 (excluded)
      //     - Add the lowest number to it
      //     - Take the integer value
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngHighest = 21;
      int lngLowest = 10;
      int lngResult = 0;
      int lngSeed = DateTime.Now.Millisecond;
      Random rndRandom = new Random(lngSeed);

      Console.WriteLine("Second method");
      Console.WriteLine("-------------");

      while (lngResult != lngLowest)
      {
        lngResult = rndRandom.Next(lngLowest, lngHighest);
        Console.WriteLine(lngResult);
      }
      // lngResult = lngLowest

    }
    // Method2()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpRandom

}
// CopyPaste.Learning