//***
// Action
//   - Definition of a derived class cpDerived
// Created
//   - CopyPaste � 20240617 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240617 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpDerived : cpBase
  {

    #region "Constructors / Destructors"

    public cpDerived() : base()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpProgram.Main() 
      // Calls
      //   - cpBase()
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDerived()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void SubTestDerived()
      //***
      // Action
      //   - Test SubTestDerived subroutines
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - SubInternal()
      //   - SubProtected()
      //   - SubProtectedInternal()
      //   - SubPublic()
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      SubInternal();
      // SubPrivate();
      SubProtected();
      SubProtectedInternal();
      SubPublic();
    }
    // SubTestDerived()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDerived

}
// CopyPaste.Learning