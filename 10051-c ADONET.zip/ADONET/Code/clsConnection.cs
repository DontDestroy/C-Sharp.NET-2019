//***
// Action
//   - Definition of a cpConnection
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpConnection: IDisposable
  {

    #region "Constructors / Destructors"

    public cpConnection(string strDataBaseName)
      //***
      // Action
      //   - Creating an instance of cpConnection with a given database name
      //   - Try to
      //     - Set the Database name
      //     - Open the connection
      //   - On possible error
      //     - Throw new exception with information
      // Called by
      //   - bool cpCommand.DoTransaction(string, string, decimal)
      //   - bool cpCommand.UpdateAccount(string, decimal) 
      //   - bool cpCommand.UpdateAccountWithStoredProcedure(string, decimal)
      //   - bool cpCommand.UpdateBrewer(dsData)
      //   - bool cpCommand.UpdateBrewerMultiUser(dsData)
      //   - cpInfoAccount cpCommand.FindInfoAccount(string)
      //   - decimal cpCommand.FindAmountAccount(string)
      //   - DataSet cpCommand.FindBrewerBeer()
      //   - dsData cpCommand.FindBrewerBeersTypedDataSet([bool], [bool])
      //   - frmBeerAndAccount.cmdBeerDll_Click(System.Object, System.EventArgs) Handles cmdBeerDll.Click
      //   - frmBeerBrewer.frmBeerBrewer_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmBeerBrewer.lstBrewer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBrewer.SelectedIndexChanged
      //   - System.Int32 cpCommand.AddAccountClient(string) 
      // Calls
      //   - DatabaseName(String) (Set)
      //   - Open()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        DatabaseName = strDataBaseName;
        Open();
      }
      catch (Exception theException)
      {
        throw new Exception(theException.Message);
      }
      finally
      {
      }

    }
    // cpConnection(string)
    
    public void Dispose()
      //***
      // Action
      //   - Dispose (Close the database connection)
      //   - Clean everything from the garbage collector
      // Called by
      //   - bool cpCommand.DoTransaction(string, string, decimal)
      //   - bool cpCommand.UpdateAccount(string, decimal)
      //   - bool cpCommand.UpdateAccountWithStoredProcedure(string, decimal)
      //   - bool UpdateBrewer(dsData)
      //   - bool UpdateBrewerMultiUser(dsData)
      //   - cpInfoAccount cpCommand.FindInfoAccount(string) 
      //   - Dataset cpCommand.FindBrewerBeer()
      //   - decimal cpCommand.FindAmountAccount(string)
      //   - dsData cpCommand.FindBrewerBeersTypedDataSet([bool], [bool])
      //   - frmBeerBrewer.frmBeerBrewer_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmBeerBrewer.lstBrewer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBrewer.SelectedIndexChanged
      //   - System.Int32 cpCommand.AddAccountClient(string) 
      //   - System.Int32 cpCommand.IntrestOnAllAccounts()
      // Calls
      //   - Dispose(bool)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Dispose(true);
      GC.SuppressFinalize(this);
    }
    // Dispose() Implements IDisposable.Dispose

    protected virtual void Dispose(bool blnDisposing)
      //***
      // Action
      //   - If blnDisposing is true
      //     - Close the connection
      //   - If not
      //     - Do nothing
      // Called by
      //   - Dispose() Implements IDisposable.Dispose
      //   - ~cpConnection()
      // Calls
      //   - Close()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (blnDisposing)
      {
        Close();
      }
      else
        // Not blnDisposing
      {
      }
      // blnDisposing

    }
    // Dispose(bool)

    ~cpConnection()
        //***
        // Action
        //   - Stop the instance, don't close the connection
        // Called by
        //   - 
        // Calls
        //   - Dispose(bool)
        // Created
        //   - CopyPaste � 20260204 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260204 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
    {
      Dispose(false);
    }
    // ~cpConnection()


    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private IDbConnection mtheConnection;
    private string mstrConnectionString;
    private string mstrDatabaseName;
    private string mstrKindOfDatabase;

    #endregion

    #region "Properties"

    public IDbConnection Connection
    {

      get
        //***
        // Action Get
        //   - Return 'mtheConnection'
        // Called by
        //   - bool cpCommand.DoTransaction(string, string, decimal)
        //   - bool cpCommand.UpdateAccount(string, decimal)
        //   - bool cpCommand.UpdateAccountWithStoredProcedure(string, decimal)
        //   - bool cpCommand.UpdateBrewer(dsData)
        //   - bool cpCommand.UpdateBrewerMultiUser(dsData)
        //   - Close()
        //   - cpInfoAccount cpCommand.FindInfoAccount(string)
        //   - DataSet cpCommand.FindBrewerBeer()
        //   - decimal cpCommand.FindAmountAccount(string)
        //   - dsData cpCommand.FindBrewerBeersTypedDataSet([bool], [bool])
        //   - System.Int32 cpCommand.AddAccountClient(string)
        //   - System.Int32 cpCommand.IntrestOnAllAccounts()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260204 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260204 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mtheConnection;
      }
      // IDbConnection Connection (Get)

    }
    // IDbConnection Connection

    private string DatabaseName
    {
      get
        //***
        // Action Get
        //   - Return 'mstrDatabaseName'
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260204 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260204 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrDatabaseName;
      }
      // string DatabaseName (Get)

      set
        //***
        // Action Set
        //   - 'mstrDatabaseName' becomes 'value'
        // Called by
        //   - cpConnection(string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260204 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260204 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrDatabaseName = value;
      }
      // DatabaseName(string) (Set)

    }
    // string DatabaseName

    public string KindOfDatabase
    {

      get
        //***
        // Action Get
        //   - Return 'mstrKindOfDatabase'
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260204 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260204 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrKindOfDatabase;
      }
      // string KindOfDatabase (Get)

    }
    // string KindOfDatabase

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void Close()
      //***
      // Action
      //   - Close the connection
      // Called by
      //   - Dispose(bool)
      // Calls
      //   - IDbConnection Connection (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Connection.Close();
    }
    // Close()

    private void Open()
      //***
      // Action
      //   - Try to
      //     - Get the kind of database from the application configuration
      //       - Pay attention, this is a configuration in the application that runs, not the class library
      //     - Depending on the kind of database
      //       - When "Access"
      //         - Create a new OleDB connection
      //         - Create a connectionstring
      //       - When "SQL"
      //         - Create a new SQL connection
      //         - Create a connectionstring
      //       - When something else
      //         - Throw new exception with information about the wrong kind of database
      //     - Set the connection string of the connection
      //     - Open the connection
      //   - On possible error
      //     - Throw new exception with information
      // Called by
      //   - cpConnection(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        mstrKindOfDatabase = System.Configuration.ConfigurationSettings.AppSettings["KindOfDatabase"];

        switch (mstrKindOfDatabase)
        {
          case "Access":
            mtheConnection = new OleDbConnection();
            mstrConnectionString = System.Configuration.ConfigurationSettings.AppSettings[mstrDatabaseName + "Access"];
            break;
          case "SQL":
            mtheConnection = new SqlConnection();
            mstrConnectionString = System.Configuration.ConfigurationSettings.AppSettings[mstrDatabaseName + "SQL"];
            break;
          default:
            throw new Exception("Wrong value in 'KindOfDatabase'=" + mstrKindOfDatabase);
        }
        // mstrKindOfDatabase

        mtheConnection.ConnectionString = mstrConnectionString;
        mtheConnection.Open();
      }
      catch (Exception theException)
      {
        throw new Exception(theException.Message);
      }
      finally
      {
      }
      
    }
    // Open()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpConnection

}
// CopyPaste.Learning