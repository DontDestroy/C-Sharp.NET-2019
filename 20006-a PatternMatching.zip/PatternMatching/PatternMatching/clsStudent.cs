﻿//***
// Action
//   - Definition of a Student class
// Created
//   - CopyPaste – 20221211 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20221211 – VVDW
// Proposal (To Do)
//   -
//***

using static CopyPaste.Learning.cpProgram;

namespace CopyPaste.Learning
{

  public class cpStudent : cpPerson
  {

    #region "Constructors / Destructors"

    public cpStudent() : base()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - cpPerson()
    // Created
    //   - CopyPaste – 20221211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20221211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpStudent()

    public cpStudent((string strFirstName, string strLastName, int intAge) thePersonDetails, string strStudentNumber, cpUniversityCourses theEnrolledCourse) : this()
    //***
    // Action
    //   - Constructor with 3 parameters
    //     - thePersonDetails: A tuple with the personal details firstname, lastname and age
    //     - strStudentNumber: The student number
    //     - theEnrolledCourse: The course the student is enrolled for
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - cpStudent()
    //   - FirstName(string) (Set)
    //   - LastName(string) (Set)
    //   - Age(int) (Set)
    //   - StudentNumber(string) (Set)
    //   - EnrolledForCourse(cpUniversityCourses) (Set)
    // Created
    //   - CopyPaste – 20221211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20221211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Age = thePersonDetails.intAge;
      EnrolledForCourse = theEnrolledCourse;
      FirstName = thePersonDetails.strFirstName;
      LastName = thePersonDetails.strLastName;
      StudentNumber = strStudentNumber;
    }
    // cpStudent(string, string, int), string, cpUniversityCourses)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public cpUniversityCourses EnrolledForCourse { get; }
    public string StudentNumber { get; }

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public (string strFullName, string strStudentNumber, string strCourse) StudentDetails()
    //***
    // Action
    //   - Return information about the student
    //     - A tuple of three strings is used
    // Called by
    //   - cpPatternMatching.GetPersonCourseBeforeCSharp07(System.Object)
    //   - cpPatternMatching.GetPersonCourseIsTypePattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchPattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchPatternNull(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchWhenPattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchWhenPatternExclusion(System.Object)
    // Calls
    //   - cpUniversityCourses CourseEnrolledFor (Get)
    //   - string FirstName (Get)
    //   - string LastName (Get)
    //   - string StudentNumber (Get)
    // Created
    //   - CopyPaste – 20221211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20221211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      (string, string, string) studentDetails = ($"{FirstName} {LastName}", StudentNumber, EnrolledForCourse.ToString());
    
      return studentDetails;
    }
    // (string, string, string) StudentDetails()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpStudent

}
// CopyPaste.Learning