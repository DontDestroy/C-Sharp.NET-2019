﻿//***
// Action
//   - Bind the data set information to controls on the form
// Created
//   - CopyPaste – 20251119 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251119 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Forms;

namespace CopyPaste.Learning
{

  static class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Starting the application frmDataBindingWizard
    // Called by
    //   -
    // Calls
    //   - frmDataSetsWizard()
    // Created
    //   - CopyPaste – 20251119 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251119 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run(new frmDataBindingWizard());
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
//  CopyPaste.Learning