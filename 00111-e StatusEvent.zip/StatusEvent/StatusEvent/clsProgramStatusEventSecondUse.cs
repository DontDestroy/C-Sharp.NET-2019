//***
// Action
//   - Second demo of cpStatus
// Created
//   - CopyPaste � 20240522 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240522 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Event;
using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgramStatusEventSecondUse
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    public static cpStatus mcpTryout;
    private static int mlngCountFrom = 2000;
    private static int mlngCountTo = 950;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private static void CountDown(string strMessage, ref bool blnCancel)
      //***
      // Action
      //   - Show a messagebox with a strMessage
      //   - If DialogResult equals Yes
      //     - blnCancel becomes true
      //   - If not
      //     - blnCancel stays false
      //   - If blnCancel
      //     - Countdown from 1000 till mlngCountTo
      //   - If Not
      //     - Countdown from mlngCountFrom till mlngCountTo
      // Called by
      //   - cpStatus.TryThis(string, string, int, int)
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      DialogResult theAnswer;
      int lngCounter;

      theAnswer = MessageBox.Show(strMessage, "Copy Paste", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

      if (theAnswer == DialogResult.Yes)
      {
        blnCancel = true;
      }
      else
        // theAnswer <> DialogResult.Yes
      {
      }
      // theAnswer = DialogResult.Yes

      if (blnCancel)
      {

        for (lngCounter = 1000; lngCounter >= mlngCountTo; lngCounter--)
        {
          Console.WriteLine(lngCounter);
        }
        //lngCounter = mlngCountTo - 1

      }
      else
        // Not blnCancel
      {

        for (lngCounter = mlngCountFrom; lngCounter >= mlngCountTo; lngCounter--)
        {
          Console.WriteLine(lngCounter);
        }
        // lngCounter = mlngCountTo - 1

      }
      // blnCancel

    }
    // CountDown(string, �bool)

    #endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define an instance of cpStatus
      //   - Execute the TryThis method
      //     - This triggers an event "CountDown" but changes the starting point of the countdown
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - bool cpStatus.TryThis(string, string, int, int)
      //   - CountDown(string, �bool)
      //   - cpStatus()
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mcpTryout = new cpStatus();

      if (mcpTryout == null)
      {
      }
      else
        // mcpTryout <> null
      {
        mcpTryout.DoSomething += new cpStatus.cpAction(CountDown);
        mcpTryout.TryThis("Start with 1000?", mlngCountFrom + " changed to 1000", mlngCountFrom, mlngCountTo);
      }
      // mcpTryout = null

      Console.WriteLine();
      Console.WriteLine("Hit Enter");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgramStatusEventSecondUse

}
// CopyPaste.Learning