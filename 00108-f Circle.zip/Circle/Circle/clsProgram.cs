//***
// Action
//   - Testroutine of an instance of cpCircle
// Created
//   - CopyPaste � 20231230 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231230 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Math;
using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace Circle
{

	public class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main()
			//***
			// Action
			//   - Create a new instance of a cpCircle
			//   - Get some properties
			//   - Set some properties
			//   - Use of ToString()
			//   - Show the diameter
			//   - Show the circumference
			//   - Show the area
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - cpCircle(cpPoint, double)
			//   - cpCircle(int, int, double)
			//   - cpCircle.Radius(double) (Set)
			//   - cpCircle.X(int) (Set)
			//   - cpCircle.Y(int) (Set)
			//   - cpPoint(int, int)
			//   - double cpCircle.Area()
			//   - double cpCircle.Circumference()
			//   - double cpCircle.Diameter()
			//   - double cpCircle.Radius() (Get)
			//   - int cpCircle.X() (Get)
			//   - int cpCircle.Y() (Get)
			//   - string cpCircle.ToString()
			// Created
			//   - CopyPaste � 20231230 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231230 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			cpCircle thecpFirstCircle;
			cpCircle thecpSecondCircle;
			cpPoint thecpPointCenter;
			string strOutput;

			thecpPointCenter = new cpPoint(37, 43);
			thecpFirstCircle = new cpCircle(37, 43, 2.5);
			thecpSecondCircle = new cpCircle(thecpPointCenter, 2.5);

			strOutput = "X coordinate is " + thecpFirstCircle.X + ControlChars.CrLf + 
				"Y coordinate is " + thecpFirstCircle.Y + Environment.NewLine + 
				"Radius is " + thecpFirstCircle.Radius;
			MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

			thecpFirstCircle.X = 2;
			thecpFirstCircle.Y = 2;
			thecpFirstCircle.Radius = 4.25;

			strOutput = "The new location and radius of circle are " + Environment.NewLine + thecpFirstCircle.ToString();
			MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

			strOutput = "X coordinate is " + thecpSecondCircle.X + ControlChars.CrLf + 
				"Y coordinate is " + thecpSecondCircle.Y + Environment.NewLine + 
				"Radius is " + thecpSecondCircle.Radius;
			MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

			thecpSecondCircle.X = 2;
			thecpSecondCircle.Y = 2;
			thecpSecondCircle.Radius = 4.25;

			strOutput = "The new location and radius of circle are " + Environment.NewLine + thecpSecondCircle.ToString();
			MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

			strOutput = "Diameter is " + String.Format("{0:F}", thecpFirstCircle.Diameter());
			MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

			strOutput = "Circumference is " + String.Format("{0:F}", thecpFirstCircle.Circumference());
			MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

			strOutput = "Area is " + String.Format("{0:F}", thecpFirstCircle.Area());
			MessageBox.Show(strOutput, "Demonstrating Class cpCircle");
		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpProgram

}
// Circle