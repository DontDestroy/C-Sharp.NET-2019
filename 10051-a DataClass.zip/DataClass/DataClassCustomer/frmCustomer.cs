//***
// Action
//   - Show a customer (used a a test form)
// Created
//   - CopyPaste � 20260117 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260117 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmCustomer: ifrmCustomer
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCustomer));
      // 
      // cmdNew
      // 
      this.cmdNew.Name = "cmdNew";
      // 
      // cmdDelete
      // 
      this.cmdDelete.Name = "cmdDelete";
      // 
      // cmdSave
      // 
      this.cmdSave.Name = "cmdSave";
      // 
      // cmdRetrieve
      // 
      this.cmdRetrieve.Name = "cmdRetrieve";
      // 
      // txtFax
      // 
      this.txtFax.Name = "txtFax";
      // 
      // txtPhone
      // 
      this.txtPhone.Name = "txtPhone";
      // 
      // txtRegion
      // 
      this.txtRegion.Name = "txtRegion";
      // 
      // txtCountry
      // 
      this.txtCountry.Name = "txtCountry";
      // 
      // txtZip
      // 
      this.txtZip.Name = "txtZip";
      // 
      // txtCity
      // 
      this.txtCity.Name = "txtCity";
      // 
      // txtAddress
      // 
      this.txtAddress.Name = "txtAddress";
      // 
      // txtContactTitle
      // 
      this.txtContactTitle.Name = "txtContactTitle";
      // 
      // txtIdCustomer
      // 
      this.txtIdCustomer.Name = "txtIdCustomer";
      // 
      // txtContactName
      // 
      this.txtContactName.Name = "txtContactName";
      // 
      // txtCompanyName
      // 
      this.txtCompanyName.Name = "txtCompanyName";
      // 
      // frmCustomer
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(688, 325);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCustomer";
      this.Load += new System.EventHandler(this.frmCustomer_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmCustomer'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - ifrmCustomer.Dispose(bool)
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmCustomer() : base()
      //***
      // Action
      //   - Create new instance of 'frmCustomer'
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCustomer()
      //   - ifrmCustomer()
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
      mcpCustomer = new cpCustomer();
    }
    // frmCustomer()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    cpCustomer mcpCustomer;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void TextBoxChange(string strProperty, string strValue)
      //***
      // Action
      //   - Try to
      //     - Depending on the textbox (property)
      //       - Fill the corresponding property of the customer instance (linked to the form)
      //     - Fill the rich text box with the customer info (ToString())
      //   - When there is no cpCustomer instance
      //     - Do nothing
      //   - When other exception
      //     - Show exception message
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCustomer.Address(string) (Set)
      //   - cpCustomer.City(string) (Set)
      //   - cpCustomer.CompanyName(string) (Set)
      //   - cpCustomer.ContactName(string) (Set)
      //   - cpCustomer.ContactTitle(string) (Set)
      //   - cpCustomer.Country(string) (Set)
      //   - cpCustomer.Fax(string) (Set)
      //   - cpCustomer.Phone(string) (Set)
      //   - cpCustomer.Region(string) (Set)
      //   - cpCustomer.PostalCode(string) (Set)
      //   - string cpCustomer.ToString()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {

        switch (strProperty)
        {
          case "Address":
            mcpCustomer.Address = strValue;
            break;
          case "City":
            mcpCustomer.City = strValue;
            break;
          case "CompanyName":
            mcpCustomer.CompanyName = strValue;
            break;
          case "ContactName":
            mcpCustomer.ContactName = strValue;
            break;
          case "ContactTitle":
            mcpCustomer.ContactTitle = strValue;
            break;
          case "Country":
            mcpCustomer.Country = strValue;
            break;
          case "Fax":
            mcpCustomer.Fax = strValue;
            break;
          case "Phone":
            mcpCustomer.Phone = strValue;
            break;
          case "Region":
            mcpCustomer.Region = strValue;
            break;
          case "Zip":
            mcpCustomer.PostalCode = strValue;
            break;
        }
        // strProperty

        rtxtToString.Text = mcpCustomer.ToString();
      }
      catch (NullReferenceException theNullReferenceException)
      {
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }

    }
    // TextBoxChange(string, string)
  
    #endregion

    #region "Controls"

    private void frmCustomer_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Fill dummy data to the form
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtAddress.Text = "Hazebos 13";
      txtCity.Text = "Zonnebeke";
      txtCompanyName.Text = "Copy Paste";
      txtContactName.Text = "Vincent Van De Walle";
      txtContactTitle.Text = "Mister";
      txtCountry.Text = "Belgium";
      txtFax.Text = "+32 (0)57/21.25.72";
      txtPhone.Text = "+32 (0)57/21.25.71";
      txtRegion.Text = "West-Vlaanderen";
      txtZip.Text = "8980";
    }
    // frmCustomer_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmCustomer

}
// CopyPaste.Learning