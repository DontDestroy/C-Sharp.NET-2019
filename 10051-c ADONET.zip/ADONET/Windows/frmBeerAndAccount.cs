//***
// Action
//   - Beer and account functionality thru a lot of buttons
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBeerAndAccount: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.GroupBox grpCommand;
    internal System.Windows.Forms.Button cmdChangeStoredProcedure;
    internal System.Windows.Forms.TextBox txtAmount;
    internal System.Windows.Forms.TextBox txtAccount;
    internal System.Windows.Forms.Label lblAmount;
    internal System.Windows.Forms.Label lblAccount;
    internal System.Windows.Forms.Button cmdChangeAmount;
    internal System.Windows.Forms.Button cmdIntrestOnAllAccounts;
    internal System.Windows.Forms.Label lblStatus;
    internal System.Windows.Forms.GroupBox grpConnection;
    internal System.Windows.Forms.Button cmdBeer;
    internal System.Windows.Forms.Button cmdBeerInterface;
    internal System.Windows.Forms.Button cmdBeerDll;
    internal System.Windows.Forms.Button cmdBeerRelative;
    internal System.Windows.Forms.Button cmdBeerConfig;
    internal System.Windows.Forms.Button cmdBeerSQL;
    internal System.Windows.Forms.Button cmdBeerSQLConfig;
    internal System.Windows.Forms.GroupBox grpTransaction;
    internal System.Windows.Forms.Button cmdDoTransaction;
    internal System.Windows.Forms.TextBox txtAccountTo;
    internal System.Windows.Forms.Label lblAccountTo;
    internal System.Windows.Forms.TextBox txtAmountFromTo;
    internal System.Windows.Forms.TextBox txtAccountFrom;
    internal System.Windows.Forms.Label lblAmountFromTo;
    internal System.Windows.Forms.Label lblAccountFrom;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBeerAndAccount));
      this.grpCommand = new System.Windows.Forms.GroupBox();
      this.cmdChangeStoredProcedure = new System.Windows.Forms.Button();
      this.txtAmount = new System.Windows.Forms.TextBox();
      this.txtAccount = new System.Windows.Forms.TextBox();
      this.lblAmount = new System.Windows.Forms.Label();
      this.lblAccount = new System.Windows.Forms.Label();
      this.cmdChangeAmount = new System.Windows.Forms.Button();
      this.cmdIntrestOnAllAccounts = new System.Windows.Forms.Button();
      this.lblStatus = new System.Windows.Forms.Label();
      this.grpConnection = new System.Windows.Forms.GroupBox();
      this.cmdBeer = new System.Windows.Forms.Button();
      this.cmdBeerInterface = new System.Windows.Forms.Button();
      this.cmdBeerDll = new System.Windows.Forms.Button();
      this.cmdBeerRelative = new System.Windows.Forms.Button();
      this.cmdBeerConfig = new System.Windows.Forms.Button();
      this.cmdBeerSQL = new System.Windows.Forms.Button();
      this.cmdBeerSQLConfig = new System.Windows.Forms.Button();
      this.grpTransaction = new System.Windows.Forms.GroupBox();
      this.cmdDoTransaction = new System.Windows.Forms.Button();
      this.txtAccountTo = new System.Windows.Forms.TextBox();
      this.lblAccountTo = new System.Windows.Forms.Label();
      this.txtAmountFromTo = new System.Windows.Forms.TextBox();
      this.txtAccountFrom = new System.Windows.Forms.TextBox();
      this.lblAmountFromTo = new System.Windows.Forms.Label();
      this.lblAccountFrom = new System.Windows.Forms.Label();
      this.grpCommand.SuspendLayout();
      this.grpConnection.SuspendLayout();
      this.grpTransaction.SuspendLayout();
      this.SuspendLayout();
      // 
      // grpCommand
      // 
      this.grpCommand.Controls.Add(this.cmdChangeStoredProcedure);
      this.grpCommand.Controls.Add(this.txtAmount);
      this.grpCommand.Controls.Add(this.txtAccount);
      this.grpCommand.Controls.Add(this.lblAmount);
      this.grpCommand.Controls.Add(this.lblAccount);
      this.grpCommand.Controls.Add(this.cmdChangeAmount);
      this.grpCommand.Controls.Add(this.cmdIntrestOnAllAccounts);
      this.grpCommand.Location = new System.Drawing.Point(256, 16);
      this.grpCommand.Name = "grpCommand";
      this.grpCommand.Size = new System.Drawing.Size(224, 312);
      this.grpCommand.TabIndex = 6;
      this.grpCommand.TabStop = false;
      this.grpCommand.Text = "Command";
      // 
      // cmdChangeStoredProcedure
      // 
      this.cmdChangeStoredProcedure.Location = new System.Drawing.Point(16, 184);
      this.cmdChangeStoredProcedure.Name = "cmdChangeStoredProcedure";
      this.cmdChangeStoredProcedure.Size = new System.Drawing.Size(192, 32);
      this.cmdChangeStoredProcedure.TabIndex = 6;
      this.cmdChangeStoredProcedure.Text = "Change (Update With Stored Procedure)";
      this.cmdChangeStoredProcedure.Click += new System.EventHandler(this.cmdChangeStoredProcedure_Click);
      // 
      // txtAmount
      // 
      this.txtAmount.Location = new System.Drawing.Point(72, 104);
      this.txtAmount.Name = "txtAmount";
      this.txtAmount.TabIndex = 4;
      this.txtAmount.Text = "";
      // 
      // txtAccount
      // 
      this.txtAccount.Location = new System.Drawing.Point(72, 72);
      this.txtAccount.Name = "txtAccount";
      this.txtAccount.TabIndex = 2;
      this.txtAccount.Text = "";
      // 
      // lblAmount
      // 
      this.lblAmount.Location = new System.Drawing.Point(16, 104);
      this.lblAmount.Name = "lblAmount";
      this.lblAmount.Size = new System.Drawing.Size(56, 23);
      this.lblAmount.TabIndex = 3;
      this.lblAmount.Text = "Amount";
      // 
      // lblAccount
      // 
      this.lblAccount.Location = new System.Drawing.Point(16, 72);
      this.lblAccount.Name = "lblAccount";
      this.lblAccount.Size = new System.Drawing.Size(56, 23);
      this.lblAccount.TabIndex = 1;
      this.lblAccount.Text = "Account";
      // 
      // cmdChangeAmount
      // 
      this.cmdChangeAmount.Location = new System.Drawing.Point(16, 144);
      this.cmdChangeAmount.Name = "cmdChangeAmount";
      this.cmdChangeAmount.Size = new System.Drawing.Size(192, 32);
      this.cmdChangeAmount.TabIndex = 5;
      this.cmdChangeAmount.Text = "Change (Update With Parameter)";
      this.cmdChangeAmount.Click += new System.EventHandler(this.cmdChangeAmount_Click);
      // 
      // cmdIntrestOnAllAccounts
      // 
      this.cmdIntrestOnAllAccounts.Location = new System.Drawing.Point(16, 24);
      this.cmdIntrestOnAllAccounts.Name = "cmdIntrestOnAllAccounts";
      this.cmdIntrestOnAllAccounts.Size = new System.Drawing.Size(192, 32);
      this.cmdIntrestOnAllAccounts.TabIndex = 0;
      this.cmdIntrestOnAllAccounts.Text = "Intrest On All Accounts (Update)";
      this.cmdIntrestOnAllAccounts.Click += new System.EventHandler(this.cmdIntrestOnAllAccounts_Click);
      // 
      // lblStatus
      // 
      this.lblStatus.Location = new System.Drawing.Point(16, 336);
      this.lblStatus.Name = "lblStatus";
      this.lblStatus.Size = new System.Drawing.Size(704, 56);
      this.lblStatus.TabIndex = 4;
      // 
      // grpConnection
      // 
      this.grpConnection.Controls.Add(this.cmdBeer);
      this.grpConnection.Controls.Add(this.cmdBeerInterface);
      this.grpConnection.Controls.Add(this.cmdBeerDll);
      this.grpConnection.Controls.Add(this.cmdBeerRelative);
      this.grpConnection.Controls.Add(this.cmdBeerConfig);
      this.grpConnection.Controls.Add(this.cmdBeerSQL);
      this.grpConnection.Controls.Add(this.cmdBeerSQLConfig);
      this.grpConnection.Location = new System.Drawing.Point(16, 16);
      this.grpConnection.Name = "grpConnection";
      this.grpConnection.Size = new System.Drawing.Size(224, 312);
      this.grpConnection.TabIndex = 5;
      this.grpConnection.TabStop = false;
      this.grpConnection.Text = "Connection";
      // 
      // cmdBeer
      // 
      this.cmdBeer.Location = new System.Drawing.Point(16, 24);
      this.cmdBeer.Name = "cmdBeer";
      this.cmdBeer.Size = new System.Drawing.Size(192, 32);
      this.cmdBeer.TabIndex = 0;
      this.cmdBeer.Text = "Open Database Beer (normal)";
      this.cmdBeer.Click += new System.EventHandler(this.cmdBeer_Click);
      // 
      // cmdBeerInterface
      // 
      this.cmdBeerInterface.Location = new System.Drawing.Point(16, 224);
      this.cmdBeerInterface.Name = "cmdBeerInterface";
      this.cmdBeerInterface.Size = new System.Drawing.Size(192, 32);
      this.cmdBeerInterface.TabIndex = 5;
      this.cmdBeerInterface.Text = "Open Database Beer (Interface)";
      this.cmdBeerInterface.Click += new System.EventHandler(this.cmdBeerInterface_Click);
      // 
      // cmdBeerDll
      // 
      this.cmdBeerDll.Location = new System.Drawing.Point(16, 264);
      this.cmdBeerDll.Name = "cmdBeerDll";
      this.cmdBeerDll.Size = new System.Drawing.Size(192, 32);
      this.cmdBeerDll.TabIndex = 6;
      this.cmdBeerDll.Text = "Open Database Beer (DLL)";
      this.cmdBeerDll.Click += new System.EventHandler(this.cmdBeerDll_Click);
      // 
      // cmdBeerRelative
      // 
      this.cmdBeerRelative.Location = new System.Drawing.Point(16, 64);
      this.cmdBeerRelative.Name = "cmdBeerRelative";
      this.cmdBeerRelative.Size = new System.Drawing.Size(192, 32);
      this.cmdBeerRelative.TabIndex = 1;
      this.cmdBeerRelative.Text = "Open Database Beer (Relative)";
      this.cmdBeerRelative.Click += new System.EventHandler(this.cmdBeerRelative_Click);
      // 
      // cmdBeerConfig
      // 
      this.cmdBeerConfig.Location = new System.Drawing.Point(16, 104);
      this.cmdBeerConfig.Name = "cmdBeerConfig";
      this.cmdBeerConfig.Size = new System.Drawing.Size(192, 32);
      this.cmdBeerConfig.TabIndex = 2;
      this.cmdBeerConfig.Text = "Open Database Beer (Config)";
      this.cmdBeerConfig.Click += new System.EventHandler(this.cmdBeerConfig_Click);
      // 
      // cmdBeerSQL
      // 
      this.cmdBeerSQL.Location = new System.Drawing.Point(16, 144);
      this.cmdBeerSQL.Name = "cmdBeerSQL";
      this.cmdBeerSQL.Size = new System.Drawing.Size(192, 32);
      this.cmdBeerSQL.TabIndex = 3;
      this.cmdBeerSQL.Text = "Open Database Beer (SQL)";
      this.cmdBeerSQL.Click += new System.EventHandler(this.cmdBeerSQL_Click);
      // 
      // cmdBeerSQLConfig
      // 
      this.cmdBeerSQLConfig.Location = new System.Drawing.Point(16, 184);
      this.cmdBeerSQLConfig.Name = "cmdBeerSQLConfig";
      this.cmdBeerSQLConfig.Size = new System.Drawing.Size(192, 32);
      this.cmdBeerSQLConfig.TabIndex = 4;
      this.cmdBeerSQLConfig.Text = "Open Database Beer (SQL Config)";
      this.cmdBeerSQLConfig.Click += new System.EventHandler(this.cmdBeerSQLConfig_Click);
      // 
      // grpTransaction
      // 
      this.grpTransaction.Controls.Add(this.cmdDoTransaction);
      this.grpTransaction.Controls.Add(this.txtAccountTo);
      this.grpTransaction.Controls.Add(this.lblAccountTo);
      this.grpTransaction.Controls.Add(this.txtAmountFromTo);
      this.grpTransaction.Controls.Add(this.txtAccountFrom);
      this.grpTransaction.Controls.Add(this.lblAmountFromTo);
      this.grpTransaction.Controls.Add(this.lblAccountFrom);
      this.grpTransaction.Location = new System.Drawing.Point(496, 16);
      this.grpTransaction.Name = "grpTransaction";
      this.grpTransaction.Size = new System.Drawing.Size(224, 312);
      this.grpTransaction.TabIndex = 7;
      this.grpTransaction.TabStop = false;
      this.grpTransaction.Text = "Transaction";
      // 
      // cmdDoTransaction
      // 
      this.cmdDoTransaction.Location = new System.Drawing.Point(16, 144);
      this.cmdDoTransaction.Name = "cmdDoTransaction";
      this.cmdDoTransaction.Size = new System.Drawing.Size(192, 32);
      this.cmdDoTransaction.TabIndex = 6;
      this.cmdDoTransaction.Text = "Transaction From --> To";
      this.cmdDoTransaction.Click += new System.EventHandler(this.cmdDoTransaction_Click);
      // 
      // txtAccountTo
      // 
      this.txtAccountTo.Location = new System.Drawing.Point(96, 72);
      this.txtAccountTo.Name = "txtAccountTo";
      this.txtAccountTo.TabIndex = 3;
      this.txtAccountTo.Text = "";
      // 
      // lblAccountTo
      // 
      this.lblAccountTo.Location = new System.Drawing.Point(16, 72);
      this.lblAccountTo.Name = "lblAccountTo";
      this.lblAccountTo.Size = new System.Drawing.Size(72, 23);
      this.lblAccountTo.TabIndex = 2;
      this.lblAccountTo.Text = "Account To";
      // 
      // txtAmountFromTo
      // 
      this.txtAmountFromTo.Location = new System.Drawing.Point(96, 104);
      this.txtAmountFromTo.Name = "txtAmountFromTo";
      this.txtAmountFromTo.TabIndex = 5;
      this.txtAmountFromTo.Text = "";
      // 
      // txtAccountFrom
      // 
      this.txtAccountFrom.Location = new System.Drawing.Point(96, 40);
      this.txtAccountFrom.Name = "txtAccountFrom";
      this.txtAccountFrom.TabIndex = 1;
      this.txtAccountFrom.Text = "";
      // 
      // lblAmountFromTo
      // 
      this.lblAmountFromTo.Location = new System.Drawing.Point(16, 104);
      this.lblAmountFromTo.Name = "lblAmountFromTo";
      this.lblAmountFromTo.Size = new System.Drawing.Size(56, 23);
      this.lblAmountFromTo.TabIndex = 4;
      this.lblAmountFromTo.Text = "Amount";
      // 
      // lblAccountFrom
      // 
      this.lblAccountFrom.Location = new System.Drawing.Point(16, 40);
      this.lblAccountFrom.Name = "lblAccountFrom";
      this.lblAccountFrom.Size = new System.Drawing.Size(80, 23);
      this.lblAccountFrom.TabIndex = 0;
      this.lblAccountFrom.Text = "Account From";
      // 
      // frmBeerAndAccount
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(736, 405);
      this.Controls.Add(this.grpCommand);
      this.Controls.Add(this.lblStatus);
      this.Controls.Add(this.grpConnection);
      this.Controls.Add(this.grpTransaction);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBeerAndAccount";
      this.Text = "Beers and Accounts";
      this.grpCommand.ResumeLayout(false);
      this.grpConnection.ResumeLayout(false);
      this.grpTransaction.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBeerAndAccount'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBeerAndAccount()
      //***
      // Action
      //   - Create instance of 'frmBeerAndAccount'
      // Called by
      //   - 
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmBeerAndAccount()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdBeer_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Define a connection to cpBeer access database (hardcoded)
      //     - Create a connection string and assign it to the connection
      //     - Open the connection
      //     - Set a text on the form
      //     - Close the connection
      //   - On possible error
      //     - Set the exception message to the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        OleDbConnection cnncpBeer = new OleDbConnection();

        cnncpBeer.ConnectionString = "Data Source=\"S:\\Data\\cpBeer 2003.mdb\";Provider=\"Microsoft.Jet.OLEDB.4.0\"";
        cnncpBeer.Open();
        lblStatus.Text = "Access database cpBeer 2003 is open";
        cnncpBeer.Close();
      }
      catch (Exception theException)
      {
        lblStatus.Text = theException.Message;
      }
      finally
      {
      }
    
    }
    // cmdBeer_Click(System.Object, System.EventArgs) Handles cmdBeer.Click

    private void cmdBeerConfig_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Define a connection to cpBeer access database (using configuration file)
      //     - Create a connection string and assign it to the connection
      //     - Open the connection
      //     - Set a text on the form
      //     - Close the connection
      //   - On possible error
      //     - Set the exception message to the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        OleDbConnection cnncpBeer = new OleDbConnection();
        string strConnectionString;

        strConnectionString = System.Configuration.ConfigurationSettings.AppSettings["cpBeerAccess"];
        cnncpBeer.ConnectionString = strConnectionString;
        cnncpBeer.Open();
        lblStatus.Text = "Access database cpBeer 2003 is open";
        cnncpBeer.Close();
      }
      catch (Exception theException)
      {
        lblStatus.Text = theException.Message;
      }
      finally
      {
      }

    }
    // cmdBeer_Click(System.Object, System.EventArgs) Handles cmdBeer.Click

    private void cmdBeerDll_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Define a connection to cpBeer access or SQL database (using DLL file) (the Class Library)
      //     - Create a connection string and assign it to the connection
      //     - Open the connection
      //     - Set a text on the form
      //     - Close the connection
      //   - On possible error
      //     - Set the exception message to the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpConnection(string)
      //   - cpConnection.Dispose() Implements IDisposable.Dispose
      //   - string cpConnection.KindOfDatabase (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        cpConnection theConnection = new cpConnection("cpBeer");

        lblStatus.Text = theConnection.KindOfDatabase + " database cpBeer can be opened";
        theConnection.Dispose();
      }
      catch (Exception theException)
      {
        lblStatus.Text = theException.Message;
      }
      finally
      {
      }
    
    }
    // cmdBeerDll_Click(System.Object, System.EventArgs) Handles cmdBeerDll.Click

    private void cmdBeerInterface_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Define a connection to cpBeer access or SQL database (using configuration file)
      //     - Create a connection string and assign it to the connection
      //     - Open the connection
      //     - Set a text on the form
      //     - Close the connection
      //   - On possible error
      //     - Set the exception message to the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        IDbConnection cnncpBeer;
        string strConnectionString;
        string strKindOfDatabase;

        strKindOfDatabase = System.Configuration.ConfigurationSettings.AppSettings["KindOfDatabase"];

        switch (strKindOfDatabase)
        {
          case "Access":
            cnncpBeer = new OleDbConnection();
            strConnectionString = System.Configuration.ConfigurationSettings.AppSettings["cpBeerAccess"];
            break;
          case "SQL":
            cnncpBeer = new SqlConnection();
            strConnectionString = System.Configuration.ConfigurationSettings.AppSettings["cpBeerSQL"];
            break;
          default:
            throw new Exception("Wrong value in 'KindOfDatabase'=" + strKindOfDatabase);
            break;
        }
        // strKindOfDatabase

        cnncpBeer.ConnectionString = strConnectionString;
        cnncpBeer.Open();
        lblStatus.Text = strKindOfDatabase + " database cpBeer is (" + strKindOfDatabase + ") open";
        cnncpBeer.Close();
      }
      catch (Exception theException)
      {
        lblStatus.Text = theException.Message;
      }
      finally
      {
      }
    
    }
    // cmdBeerInterface_Click(System.Object, System.EventArgs) Handles cmdBeerInterface.Click

    private void cmdBeerRelative_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Define a connection to cpBeer access database (hardcoded but relative to current path)
      //     - Create a connection string and assign it to the connection
      //     - Open the connection
      //     - Set a text on the form
      //     - Close the connection
      //   - On possible error
      //     - Set the exception message to the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    
      try
      {
        OleDbConnection cnncpBeer = new OleDbConnection();
        string strFullPath;
        string strPath;

        strFullPath = System.Reflection.Assembly.GetExecutingAssembly().Location;
        strPath = System.IO.Path.GetDirectoryName(strFullPath);

        cnncpBeer.ConnectionString = "Data Source=\"" + strPath + "\\cpBeer 2003.mdb\";Provider=\"Microsoft.Jet.OLEDB.4.0\"";
        cnncpBeer.Open();
        lblStatus.Text = "Access database cpBeer 2003 is open";
        cnncpBeer.Close();
      }
      catch (Exception theException)
      {
        lblStatus.Text = theException.Message;
      }
      finally
      {
      }

    }
    // cmdBeerRelative_Click(System.Object, System.EventArgs) Handles cmdBeerRelative.Click

    private void cmdBeerSQL_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Define a connection to cpBeer SQL database (hardcoded)
      //     - Create a connection string and assign it to the connection
      //     - Open the connection
      //     - Set a text on the form
      //     - Close the connection
      //   - On possible error
      //     - Set the exception message to the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        SqlConnection cnncpBeer = new SqlConnection();
       
        cnncpBeer.ConnectionString = "workstation id=COPYPASTESERVER;packet size=4096;integrated security=SSPI;data source=COPYPASTESERVER;persist security info=False;initial catalog=cpBeer";
        cnncpBeer.Open();
        lblStatus.Text = "SQL database cpBeer is open";
        cnncpBeer.Close();
      }
      catch (Exception theException)
      {
        lblStatus.Text = theException.Message;
      }
      finally
      {
      }
    
    }
    // cmdBeerSQL_Click(System.Object, System.EventArgs) Handles cmdBeerSQL.Click

    private void cmdBeerSQLConfig_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Define a connection to cpBeer SQL database (using configuration file)
      //     - Create a connection string and assign it to the connection
      //     - Open the connection
      //     - Set a text on the form
      //     - Close the connection
      //   - On possible error
      //     - Set the exception message to the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    
      try
      {
        SqlConnection cnncpBeer = new SqlConnection();
        string strConnectionString;

        strConnectionString = System.Configuration.ConfigurationSettings.AppSettings["cpBeerSQL"];
        cnncpBeer.ConnectionString = strConnectionString;
        cnncpBeer.Open();
        lblStatus.Text = "SQL database cpBeer is open";
        cnncpBeer.Close();
      }
      catch (Exception theException)
      {
        lblStatus.Text = theException.Message;
      }
      finally
      {
      }

    }
    // cmdBeerSQLConfig_Click(System.Object, System.EventArgs) Handles cmdBeerSQLConfig.Click

    private void cmdChangeAmount_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Convert the typed amount to a decimal
      //     - Try to
      //     - On possible error
      //     - Show exception message on the form
      //   - On possible error
      //     - Show message on the form that you must type a number
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool cpCommand.UpdateAccount(string, decimal)
      //   - cpCommand()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      
      try
      {
        decimal decAmount = Convert.ToDecimal(txtAmount.Text);

        try
        {
          cpCommand thecpCommand = new cpCommand();

          if (thecpCommand.UpdateAccount(txtAccount.Text, decAmount))
          {
            lblStatus.Text = "Account is updated";
          }
          else
            // Not thecpCommand.UpdateAccount(txtAccount.Text, decAmount)
          {
            lblStatus.Text = "Account is not found";
          }
          // thecpCommand.UpdateAccount(txtAccount.Text, decAmount)
        
        }
        catch (Exception theException)
        {
          lblStatus.Text = theException.Message;
        }
        finally
        {
        }
      
      }
      catch (Exception theException)
      {
        lblStatus.Text = "Amount is not a number";
      }
      finally
      {
      }
    
    }
    // cmdChangeAmount_Click(System.Object, System.EventArgs) Handles cmdChangeAmount.Click

    private void cmdChangeStoredProcedure_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Convert the typed amount to a decimal
      //     - Try to
      //       - Create an instance of cpCommand
      //       - Update account with stored procedure
      //       - If successful
      //         - Show corresponding message to the form
      //       - If not
      //         - Show corresponding message to the form
      //     - On possible error
      //       - Show exception message to the form
      //   - On possible error
      //     - Show that amount is not a number
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool cpCommand.UpdateAccountWithStoredProcedure(string, decimal)
      //   - cpCommand()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        decimal decAmount = Convert.ToDecimal(txtAmount.Text);

        try
        {
          cpCommand thecpCommand = new cpCommand();

          if (thecpCommand.UpdateAccountWithStoredProcedure(txtAccount.Text, decAmount))
          {
            lblStatus.Text = "Account is updated";
          }
          else
            // Not thecpCommand.UpdateAccountWithStoredProcedure(txtAccount.Text, decAmount)
          {
            lblStatus.Text = "Account is not found";
          }
          // thecpCommand.UpdateAccountWithStoredProcedure(txtAccount.Text, decAmount)
        
        }
        catch (Exception theException)
        {
          lblStatus.Text = theException.Message;
        }
        finally
        {
        }
      
      }
      catch (Exception theException)
      {
        lblStatus.Text = "Amount is not a number";
      }
      finally
      {
      }
    
    }
    // cmdChangeStoredProcedure_Click(System.Object, System.EventArgs) Handles cmdChangeStoredProcedure.Click

    private void cmdDoTransaction_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Convert the typed amount to a decimal
      //     - Try to
      //       - Define a new command
      //     - On possible error
      //       - Show exception message to the form
      //   - On possible error
      //     - Show on the form that the amount is not a number
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool cpCommand.DoTransaction(string, string, decimal)
      //   - cpCommand()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        decimal decAmount = Convert.ToDecimal(txtAmountFromTo.Text);

        try
        {
          cpCommand thecpCommand = new cpCommand();

          if (thecpCommand.DoTransaction(txtAccountFrom.Text, txtAccountTo.Text, decAmount))
          {
            lblStatus.Text = "Transaction is correctly handled";
          }
          else
            // Not thecpCommand.DoTransaction(txtAccountFrom.Text, txtAccountTo.Text, decAmount)
          {
            lblStatus.Text = "Transaction has an error and a rollback was carried out";
          }
          // thecpCommand.DoTransaction(txtAccountFrom.Text, txtAccountTo.Text, decAmount)
        
        }
        catch (Exception theException)
        {
          lblStatus.Text = theException.Message;
        }
        finally
        {
        }

      }
      catch (Exception theException)
      {
        lblStatus.Text = "Amount is not a number";
      }
      finally
      {
      }
    
    }
    // cmdDoTransaction_Click(System.Object, System.EventArgs) Handles cmdDoTransaction.Click

    private void cmdIntrestOnAllAccounts_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Define a number of records changed
      //     - Create a new command
      //     - Execute a command
      //     - Return the number of records on the form
      //   - On possible error
      //     - Show exception message to the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpCommand()
      //   - System.Int32 cpCommand.IntrestOnAllAccounts()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        System.Int32 lngNumberOfRecordsChanged;
        cpCommand thecpCommand = new cpCommand();

        lngNumberOfRecordsChanged = thecpCommand.IntrestOnAllAccounts();
        lblStatus.Text = lngNumberOfRecordsChanged.ToString() + " records changed";
      }
      catch (Exception theException)
      {
        lblStatus.Text = theException.Message;
      }
      finally
      {
      }
    
    }
    // cmdIntrestOnAllAccounts_Click(System.Object, System.EventArgs) Handles cmdIntrestOnAllAccounts.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBeerAndAccount

}
// CopyPaste.Learning