//***
// Action
//   - First demo of cpStatus
// Created
//   - CopyPaste � 20240522 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240522 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Event;
using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgramStatusEventFirstUse
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    public static cpStatus mcpTryout;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private static void UpdateRecord(string strMessage, ref bool blnCancel)
      //***
      // Action
      //   - Show a messagebox with a strMessage
      //   - If DialogResult equals Yes
      //     - blnCancel stays false
      //   - If not
      //     - blnCancel becomes true
      // Called by
      //   - cpStatus.TryThis(string, string, int, int)
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      DialogResult theAnswer;

      theAnswer = MessageBox.Show(strMessage, "Copy Paste", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

      if (theAnswer == DialogResult.Yes)
      {
      }
      else
        // theAnswer <> DialogResult.Yes
      {
        blnCancel = true;
      }
      // theAnswer = DialogResult.Yes

    }
    // UpdateRecord(string, �bool)

    #endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define an instance of cpStatus
      //   - Execute the TryThis method
      //     - This triggers an event "UpdateRecord" in certain situations
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpStatus()
      //   - cpStatus.TryThis(string, string, int, int)
      //   - UpdateRecord(string, �bool)
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mcpTryout = new cpStatus();

      if (mcpTryout == null)
      {
      }
      else
        // mcpTryout <> null
      {
        mcpTryout.DoSomething += new cpStatus.cpAction(UpdateRecord);
        mcpTryout.TryThis("Must 1100 be lowered?", "Abandoning the try", 1100, 1000);
      }
      // mcpTryout = null

      Console.WriteLine();
      Console.WriteLine("Hit Enter");
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgramStatusEventFirstUse

}
// CopyPaste.Learning