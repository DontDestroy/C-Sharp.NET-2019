﻿//***
// Action
//   - Demo some garbage collector pressure
//   - Compare different ways of using a string and array calculations
// Created
//   - CopyPaste – 20260531 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260531 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - 
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260531 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Benchmark the marked routines to compare the speed and the memory
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpNormalizeData()
    //   - cpNormalizeData.ArrayCalculations()
    //   - cpNormalizeData.PrepareData()
    //   - cpNormalizeData.MemoryCalculations()
    //   - cpSplitString()
    //   - cpSplitString.ArrayOfStrings()
    //   - cpSplitString.SpanOfStrings()
    // Created
    //   - CopyPaste – 20260531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260531 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      // BenchmarkRunner.Run<cpSplitString>();

      // cpSplitString theSplitExample = new cpSplitString();

      // theSplitExample.ArrayOfStrings();
      // theSplitExample.SpanOfStrings();

      BenchmarkRunner.Run<cpNormalizeData>();

      // cpNormalizeData theNormalizeDataExample = new cpNormalizeData();
      
      // theNormalizeDataExample.PrepareData();
      // theNormalizeDataExample.ArrayCalculations();
      // theNormalizeDataExample.MemoryCalculations();

      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadKey();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning