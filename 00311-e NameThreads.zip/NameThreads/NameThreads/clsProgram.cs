//***
// Action
//   - Explanation of the code in this module or class
// Created
//   - CopyPaste � 20250709 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250709 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Threading;

namespace NameThreads
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static Thread thrLotOfA;
    public static Thread thrLotOfB;
    public static Thread thrLotOfC;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Display()
      //***
      // Action
      //   - Show 251 times the name of the current thread
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250709 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250709 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      for (int lngCounter = 0; lngCounter <= 250; lngCounter++)
      {
        Console.Write(Thread.CurrentThread.Name);
      }
      // lngCounter = 251

    }
    // Display()

    public static void Main()
      //***
      // Action
      //   - Create 3 threads
      //   - Name the first thread "First"
      //   - Start First
      //   - Name the second thread "Second"
      //   - Start Second
      //   - Name the third thread "Third"
      //   - Start Third
      // Called by
      //   - User action (Start the application)
      // Calls
      //   - Display()
      // Created
      //   - CopyPaste � 20250709 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250709 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      thrLotOfA = new Thread(new ThreadStart(Display));
      thrLotOfB = new Thread(new ThreadStart(Display));
      thrLotOfC = new Thread(new ThreadStart(Display));

      thrLotOfA.Name = "First";
      thrLotOfA.Start();

      thrLotOfB.Name = "Second";
      thrLotOfB.Start();

      thrLotOfC.Name = "Third";
      thrLotOfC.Start();

      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning