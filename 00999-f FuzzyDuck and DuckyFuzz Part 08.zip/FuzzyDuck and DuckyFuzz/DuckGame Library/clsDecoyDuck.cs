﻿//***
// Action
//   - Implementation of a cpDecoyDuck
//     - Inherits from cpDuck, where Display (how do I look like) is an abstract method
//       - All class that inherit from cpDuck must implement the Display method
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
//   - The way a cpDecoyDuck moves on water is inherited
//     - All cpDuck and child classes moves on water the same way
//   - The sound that a cpDecoyDuck makes is given thru a delegate and an event
//   - The way a cpDecoyDuck moves on land is given thru a delegate and an event
//   - The way a cpDecoyDuck moves in the air is given thru a delegate and an event
// Created
//   - CopyPaste – 20240726 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240726 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Animal.Library;
using System.Diagnostics;

namespace CopyPaste.Game.Duck.Library
{

	public class cpDecoyDuck : cpDuck
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpDecoyDuck
		/// </summary>
		public cpDecoyDuck() : base()
		//***
		// Action
		//   - Basic constructor
		//   - Define how a cpDecoyDuck flies (not)
		//   - Define how a cpDecoyDuck makes some noise (not)
		//   - Define how a cpDecoyDuck walks (not)
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - cpDuck()
		//   - cpDuck.HowToFly(cpiFly) (Set)
		//   - cpDuck.HowToMakeNoise(cpiMakeNoise) (Set)
		//   - cpDuck.HowToWalk(cpiWalk) (Set)
		//   - cpFlyNoWay()
		//   - cpMute()
		//   - cpWalkNoWay()
		// Created
		//   - CopyPaste – 20240726 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240726 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			HowToFly = new cpFlyNoWay();
			HowToMakeNoise = new cpMute();
			HowToWalk = new cpWalkNoWay();
		}
		// cpDecoyDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		#region "Overrides"

		/// <summary>
		/// The visualization (displaying) of a cpDecoyDuck
		/// </summary>
		public override void Display()
		//***
		// Action
		//   - Define how a cpDecoyDuck looks like
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240726 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240726 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Representation of a cpDecoyDuck");
		}
		// Display()

		#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpDecoyDuck

}
// CopyPaste.Game.Duck.Library