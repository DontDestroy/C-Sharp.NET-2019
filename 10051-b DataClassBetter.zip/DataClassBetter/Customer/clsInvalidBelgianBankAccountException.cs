﻿//***
// Action
//   - Define the Invalid Belgian Bank Account Exception
// Created
//   - CopyPaste – 20260121 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260121 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpInvalidBelgianBankAccountException: cpInvalidStringException
  {

    #region "Constructors / Destructors"

    public cpInvalidBelgianBankAccountException(string strBelgianBankAccount): base("The Belgian Bank Account specified, " + strBelgianBankAccount + ", is not valid.")
      //***
      // Action
      //   - Define a new instance with a given string
      // Called by
      //   - cpInvalidStringException cpCheckBelgianBankAccount.ThrowException(string)
      // Calls
      //   - cpInvalidStringException(string)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpInvalidBelgianBankAccountException(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
		//#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpInvalidBelgianBankAccountException

}
// CopyPaste.Learning