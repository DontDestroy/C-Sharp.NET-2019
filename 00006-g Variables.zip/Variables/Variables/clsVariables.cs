//***
// Action
//   - Initialise variables
// Created
//   - CopyPaste � 20220111 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220111 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Variables
{

  class cpVariables
	{

    static void Main()
    //***
    // Action
    //   - Initialise variables
    //   - Show values at console screen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - Declaration1()
    //   - Declaration2()
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine()
    //   - System.Console.WriteLine(bool)
    //   - System.Console.WriteLine(byte)
    //   - System.Console.WriteLine(char)
    //   - System.Console.WriteLine(DateTime)
    //   - System.Console.WriteLine(float)
    //   - System.Console.WriteLine(int)
    //   - System.Console.WriteLine(long)
    //   - System.Console.WriteLine(short)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      bool blnMarried;
      byte bytStatesUSA;
      char chrGender;
      DateTime dtmBirth;
      float fltDuvelAlcohol;
      int intDistanceToMoon;
      long lngNumberOfPeople;
      short shtBelgianBeer;

      blnMarried = false;
      bytStatesUSA = 0;
      chrGender = ' ';
      dtmBirth = new DateTime(1, 1, 1, 0, 0, 0);
      fltDuvelAlcohol = 0f;
      intDistanceToMoon = 0;
      lngNumberOfPeople = 0;
      shtBelgianBeer = 0;

      Console.WriteLine(blnMarried);
      Console.WriteLine(bytStatesUSA);
      Console.WriteLine(chrGender);
      Console.WriteLine(dtmBirth);
      Console.WriteLine(fltDuvelAlcohol);
      Console.WriteLine(intDistanceToMoon);
      Console.WriteLine(lngNumberOfPeople);
      Console.WriteLine(shtBelgianBeer);
      Console.WriteLine();

      Declaration1();
      Console.WriteLine();
      Declaration2();

    Console.ReadLine();
		}
    // Main()

    static void Declaration1()
    //***
    // Action
    //   - Initialise variables
    //   - Show values at console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine()
    //   - System.Console.WriteLine(bool)
    //   - System.Console.WriteLine(byte)
    //   - System.Console.WriteLine(char)
    //   - System.Console.WriteLine(DateTime)
    //   - System.Console.WriteLine(float)
    //   - System.Console.WriteLine(int)
    //   - System.Console.WriteLine(long)
    //   - System.Console.WriteLine(short)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      bool blnMarried;
      byte bytStatesUSA;
      char chrGender;
      DateTime dtmBirth;
      float fltDuvelAlcohol;
      int intDistanceToMoon;
      long lngNumberOfPeople;
      short shtBelgianBeer;

      blnMarried = true;
      bytStatesUSA = 50;
      chrGender = 'M';
      dtmBirth = new DateTime(1970, 5, 6, 13, 05, 0);
      fltDuvelAlcohol = 8.5f;
      intDistanceToMoon = 382170;
      lngNumberOfPeople = 6122567014;
      shtBelgianBeer = 1400;

      Console.WriteLine(blnMarried);
      Console.WriteLine(bytStatesUSA);
      Console.WriteLine(chrGender);
      Console.WriteLine(dtmBirth);
      Console.WriteLine(fltDuvelAlcohol);
      Console.WriteLine(intDistanceToMoon);
      Console.WriteLine(lngNumberOfPeople);
      Console.WriteLine(shtBelgianBeer);
      Console.WriteLine();
    }
    // Declaration1()

    static void Declaration2()
    //***
    // Action
    //   - Initialise variables
    //   - Show values at console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine()
    //   - System.Console.WriteLine(bool)
    //   - System.Console.WriteLine(byte)
    //   - System.Console.WriteLine(char)
    //   - System.Console.WriteLine(DateTime)
    //   - System.Console.WriteLine(float)
    //   - System.Console.WriteLine(int)
    //   - System.Console.WriteLine(long)
    //   - System.Console.WriteLine(short)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      bool blnMarried = true;;
      byte bytStatesUSA = 50;
      char chrGender = 'M';
      DateTime dtmBirth = new DateTime(1970, 5, 6, 13, 05, 0);
      float fltDuvelAlcohol = 8.5f;
      int intDistanceToMoon = 382170;
      long lngNumberOfPeople = 6122567014;
      short shtBelgianBeer = 1400;

      Console.WriteLine(blnMarried);
      Console.WriteLine(bytStatesUSA);
      Console.WriteLine(chrGender);
      Console.WriteLine(dtmBirth);
      Console.WriteLine(fltDuvelAlcohol);
      Console.WriteLine(intDistanceToMoon);
      Console.WriteLine(lngNumberOfPeople);
      Console.WriteLine(shtBelgianBeer);
      Console.WriteLine();
    }
    // Declaration2()

  }
  // cpVariables

}
// Variables