﻿//***
// Action
//   - Erase a database if it already exists
//   - Create a database based on the class cpBook using Entity Framework Core (version 5.0.17)
//   - Fill two tables with data
//   - Query the two tables 
// Created
//   - CopyPaste – 20230401 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230401 – VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace DemoEntityFrameWorkCore
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void CreateTestData(cpApplicationDatabaseContext theDatabaseContext)
    //***
    // Action
    //   - Create a list of cpBooks
    //   - Create a cpAuthor
    //   - Create a cpBook
    //   - Add three other cpBooks to the list
    //   - Add a cpBook to the database (with the corresponding cpAuthor)
    //     - For demo purposes this method is used (one item)
    //   - Add a list of cpBooks to the database (with the corresponding cpAuthors)
    //     - For demo purposes this method is used (more items)
    // Called by
    //   - Main()
    // Calls
    //   - cpApplicationDatabaseContext.DbSet<cpBook> cpBook (Get)
    //   - cpAuthor()
    //   - cpAuthor.strName(string) (Set)
    //   - cpAuthor.strWebUrl(string) (Set)
    //   - cpBook()
    //   - cpBook.Author(cpAuthor) (Set)
    //   - cpBook.dtmPublishedOn(DateTime) (Set)
    //   - cpBook.strDescription(string) (Set)
    //   - cpBook.strTitle(string) (Set)
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpAuthor martinFowler;
      cpBook aBook;
      List<cpBook> lstBooks = new List<cpBook>();

      martinFowler = new cpAuthor
      {
        strName = "Martin Fowler",
        strWebUrl = "http://martinfowler.com/"
      };

      aBook = new cpBook
      {
        strTitle = "Refactoring",
        strDescription = "Improving the design of existing code",
        dtmPublishedOn = new DateTime(1999, 7, 8),
        Author = martinFowler
      };

      lstBooks.Add(
        new cpBook
        {
          strTitle = "Patterns of Enterprise Application Architecture",
          strDescription = "Written in direct response to the stiff challenges",
          dtmPublishedOn = new DateTime(2002, 11, 15),
          Author = martinFowler
        });

      lstBooks.Add(
        new cpBook
        {
          strTitle = "Domain-Driven Design",
          strDescription = "Linking business needs to software design",
          dtmPublishedOn = new DateTime(2003, 8, 30),
          Author = new cpAuthor { strName = "Eric Evans", strWebUrl = "http://domainlanguage.com/" }
        });

      lstBooks.Add(
        new cpBook
        {
          strTitle = "Quantum Networking",
          strDescription = "Entangled quantum networking provides faster-than-light data communications",
          dtmPublishedOn = new DateTime(2057, 1, 1),
          Author = new cpAuthor { strName = "Future Person" }
        });

      theDatabaseContext.cpBook.Add(aBook);
      theDatabaseContext.cpBook.AddRange(lstBooks);
      theDatabaseContext.SaveChanges();
    }
    // CreateTestData(cpApplicationDatabaseContext)

    public static void Main()
    //***
    // Action
    //   - Create a cpApplicationDatabaseContext
    //   - Delete the database if it already exists
    //   - Create the database
    //   - Push data towards the database
    //   - Read data from the database
    //   - Cleaning up the cpApplicationDatabaseContext
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpApplicationDatabaseContext()
    //   - CreateTestData(cpApplicationDatabaseContext)
    //   - ReadTestData(cpApplicationDatabaseContext)
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      using (cpApplicationDatabaseContext theDatabaseContext = new cpApplicationDatabaseContext())
      {
        theDatabaseContext.Database.EnsureDeleted();
        // Delete the database thru the context if it already exists
        theDatabaseContext.Database.EnsureCreated();
        // Create a new databse thru the context
        CreateTestData(theDatabaseContext);
        // Add data to the two tables thru the context
        ReadTestData(theDatabaseContext);
        // Read data from the two tables thru the context
        Console.ReadLine();
      }
      // cpApplicationDatabaseContext theDatabaseContext

    }
    // Main()

    public static void ReadTestData(cpApplicationDatabaseContext theDatabaseContext)
    //***
    // Action
    //   - Reads all the books
    //   - AsNoTracking() says this is a read-only access
    //   - The include causes the cpAuthor information to be loaded with each cpBook
    //   - Loop thru all the books
    // Called by
    //   - Main()
    // Calls
    //   - cpApplicationDatabaseContext.DbSet<cpBook> cpBook (Get)
    //   - cpAuthor cpBook.Author (Get)
    //   - DateTime cpBook.dtmPublishedOn (Get)
    //   - string cpAuthor.strName (Get)
    //   - string cpAuthor.strWebUrl (Get)
    //   - string cpBook.strTitle (Get)
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strWebUrl;

      foreach (cpBook aBook in theDatabaseContext.cpBook.AsNoTracking().Include(theBook => theBook.Author))
      {

        if (aBook.Author.strWebUrl == null)
        {
          strWebUrl = "- no web url given yet -";
        }
        // aBook.Author.strWebUrl <> null
        else
        {
          strWebUrl = aBook.Author.strWebUrl;
        }
        // aBook.Author.strWebUrl = null

        Console.WriteLine($"{aBook.strTitle} by {aBook.Author.strName}");
        Console.WriteLine($"     Published on {aBook.dtmPublishedOn:dd/MM/yyyy}.");
        Console.WriteLine($"     More info can be found on the internet: {strWebUrl}");
        Console.WriteLine();
      }
      // in theDatabaseContext.cpBook.AsNoTracking().Include(theBook => theBook.Author)

    }
    // ReadTestData(cpApplicationDatabaseContext)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// DemoEntityFrameWorkCore