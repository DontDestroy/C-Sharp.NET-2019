﻿//***
// Action
//   - An example of the Func delegate with the American presidents
// Created
//   - CopyPaste – 20230414 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230414 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace FuncExample
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static string[] FillArray()
    //***
    // Action
    //   - Creating an array with all the American presidents
    // Called by
    //   - FilterAnArrayOnTheFirst(string)
    //   - FilterAnArrayHavingALetterOnPosition(int)
    //   - FilterAnArrayStartingWith(string)
    //   - LoopAnArrayThatChangesBetweenTwoQueries(string)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230414 – VVDW
    // Changed
    //   - CopyPaste – 20241226 – VVDW – Added new president
    // Tested
    //   - CopyPaste – 20230414 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      string[] arrAmericanPresidents;

      arrAmericanPresidents = new string[] {
        "George Washington", "John Adams", "Thomas Jefferson", "James Madison",
        "James Monroe", "John Quincy Adams", "Andrew Jackson", "Martin Van Buren",
        "William Henry Harrison", "John Tyler", "James K. Polk", "Zachary Taylor",
        "Millard Fillmore", "Franklin Pierce", "James Buchanan", "Abraham Lincoln",
        "Andrew Johnson", "Ulysses S. Grant", "Rutherford B. Hayes", "James A. Garfield",
        "Chester A. Arthur", "Grover Cleveland", "Benjamin Harrison", "William McKinley",
        "Theodore Roosevelt", "William Howard Taft", "Woordrow Wilson", "Warren G. Harding",
        "Calvin Coolidge", "Herbert Hoover", "Franklin D. Roosevelt", "Harry S. Truman",
        "Dwight D. Eisenhower", "John F. Kennedy", "Lyndon B. Johnson", "Richard Nixon",
        "Gerald Ford", "Jimmy Carter", "Ronald Reagan", "George H. W. Bush", "Bill Clinton",
        "George W. Bush", "Barack Obama", "Donald Trump", "Joe Biden", "Donald Trump"};

      return arrAmericanPresidents;
    }
    // FillArray()

    static void FilterWithFuncDelegate(string strStarting)
    //***
    // Action
    //   - Fill an array with all the American presidents
    //   - Every collection that has implemented with IEnumerable<T> or IENumerable can be queried with Linq
    //   - Give me the presidents that starts with 'strStarting' using Linq Lambda Expression (dot notation) and a Func Delegate
    //   - Show result
    //   - Give me the presidents that starts with 'strStarting' using Linq Fluent Expression and a Func Delegate
    //   - Show result
    // Called by
    //   - Main()
    // Calls
    //   - FillArray()
    //   - LoopResult(IEnumerable<string>)
    // Created
    //   - CopyPaste – 20230414 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230414 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      IEnumerable<string> colPresidentsLambda;
      string strCurrentMethodName;
      string[] arrAmericanPresidents;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      arrAmericanPresidents = FillArray();

      Func<string, bool> StartsWithText = aPresident => aPresident.StartsWith(strStarting);

      colPresidentsLambda = arrAmericanPresidents.Where(StartsWithText);

      Console.WriteLine("The presidents that starts with \"" + strStarting + "\": (Lambda Linq dot notation)");
      LoopResult(colPresidentsLambda);

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // FilterWithFuncDelegate(string)

    static void LoopResult(IEnumerable<string> colResult)
    //***
    // Action
    //   - Loop thru the elements of a collection
    //     - Show result
    // Called by
    //   - FilterWithFuncDelegate(string)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230414 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230414 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      foreach (string strItem in colResult)
      {
        Console.WriteLine(strItem);
      }
      // in colResult

    }
    // LoopResult(IEnumerable<string>)

    static void Main()
    //***
    // Action
    //   - Filter a basic array
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - FilterWithFuncDelegate(string)
    // Created
    //   - CopyPaste – 20230414 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230414 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      FilterWithFuncDelegate("James");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// FuncExample