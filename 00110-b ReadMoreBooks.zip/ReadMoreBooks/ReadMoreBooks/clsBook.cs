//***
// Action
//   - Implementation of cpBook
// Created
//   - CopyPaste � 20240106 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240106 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

	public class cpBook
	{

		#region "Constructors / Destructors"

		public cpBook()
			//***
			// Action
			//   - Empty Constructor
			// Called by
			//   - cpBook(string, string)
      // Calls
			//   - 
			// Created
			//   - CopyPaste � 20240106 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240106 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
	  {
		}
		// cpBook()

    public cpBook(string strTitle, string strText) : this()
      //***
      // Action
      //   - Constructor with 2 arguments
      //     - Title and Text are given
      //   - If an error occurs, the received exception is thrown
      // Called by
      //   - frmReadMoreBooks.frmReadMoreBooks_Load(System.Object, System.EventArgs) Handles MyBase.Load
      // Calls
      //   - cpBook()
      //   - cpBook.Text(String) (Set)
      //   - cpBook.Title(String) (Set)
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      
      try
      {
        Title = strTitle;
        Text = strText;
      }
      catch (Exception theException)
      {
        throw theException;
      }

    }
    // cpBook(string, string)

    #endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		public int mlngPageLength = 10;
		private string mstrText;
		private string mstrTitle;
		
		#endregion

		#region "Properties"

    public string Text
    {

      get
        //***
        // Action Get
        //   - Returns mstrText
        // Called by
        //   - frmReadMoreBooks.lstBooks_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBooks.SelectedIndexChanged
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240106 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240106 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrText;
      }
      // string Text (Get)

      set
        //***
        // Action Set
        //   - If value is not empty string or null
        //     - mstrText becomes value
        //   - If Not
        //     - Throw error message
        // Called by
        //   - cpBook(string, string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240106 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240106 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if ((value == "") || (value == null))
        {
          throw new Exception("Text is an empty string or not filled in.");
        }
        else
          // (value <> "") And (value <> null)
        {
          mstrText = value;
        }
        // (value = "") Or (value = null)

      }
      // Text(string) (Set)

    }
    // string Text

		public string Title
		{

			get
				//***
				// Action Get
				//   - Returns mstrTitle
				// Called by
				//   - frmReadMoreBooks.lstBooks_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBooks.SelectedIndexChanged
        //   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240106 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240106 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
    	{
				return mstrTitle;
			}
			// string Title (Get)

			set
				//***
				// Action Set
        //   - If value is not empty string or null
        //     - mstrTitle becomes value
        //   - If Not
        //     - Throw error message
				// Called by
				//   - cpBook(string, string)
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240106 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240106 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
	    {

        if ((value == "") || (value == null))
        {
          throw new Exception("Title is an empty string or not filled in.");
        }
        else
          // (value <> "") And (value <> null)
        {
          mstrTitle = value;
        }
        // (value = "") Or (value = null)

			}
			// Title(string) (Set)

		}
		// string Title

		#endregion

		#region "Methods"

		#region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Returns Title
      // Called by
      //   - 
      // Calls
      //   - string Title (Get)
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Title;
    }
    // string ToString()

    #endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public string GetPage(int lngPageNumber)
			//***
			// Action
			//   - The text of the books is divided in pages
			//   - Every page has a certain length of characters
			//     - This is the value of mlngPageLength (Default 10)
			//   - Find the start position of the searched page (lngStart)
			//   - Using lngStart, the needed page is searched
			//   - If the page is found
			//     - The content of that page is returned
			//   - If Not
			//     - An empty string is returned
			// Called by
      //   - frmReadMoreBooks.lstBooks_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBooks.SelectedIndexChanged
      // Calls
			//   - 
			// Created
			//   - CopyPaste � 20240106 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240106 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
      int lngStart;
      int lngTextLength;
			string strPageContent;

      lngStart = (lngPageNumber - 1) * mlngPageLength;
      lngTextLength = mstrText.Length;

			if ((lngStart < lngTextLength) && (lngStart >= 0))
			{
				// lngStart is somewhere in the text

				if ((lngStart + mlngPageLength) < lngTextLength)
				{
					// There is a full page
					strPageContent = mstrText.Substring(lngStart, mlngPageLength);
				}
				else
					// (lngStart + mlngPageLength) >= lngTextLength
				{
					// There is no full page
					strPageContent = mstrText.Substring(lngStart, lngTextLength - lngStart);
				}
				// (lngStart + mlngPageLength) < lngTextLength

			}
			else
				// (lngStart <= lngTextLength) Or (lngStart < 0)
			{
				// There is no page found at that location
				strPageContent = "";
			}
			// (lngStart < lngTextLength) And (lngStart >= 0)

      return strPageContent;
		}
		// string GetPage(int)

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpBook

}
// CopyPaste.Learning