//***
// Action
//   - Customer Component
//   - This contains
//     - Customer connection (Connection string)
//     - Customer data adapter
// Created
//   - CopyPaste � 20050508 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20050508 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

namespace CopyPaste.Learning
{

  public class cmpCustomerTryout : System.ComponentModel.Component
	{

    #region Component Designer generated code

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {

    }
    #endregion

    #region "Constructors / Destructors"
    
    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cmpCustomerTryout'
      // Called by
      //   - User action (Closing the component)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cmpCustomerTryout()
      //***
      // Action
      //   - Create new instance of 'cmpCustomerTryout'
      // Called by
      //   - cmpCustomerTryout(System.ComponentModel.IContainer)
      //   - User action (Starting the component)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
    }
    // cmpCustomer()

		public cmpCustomerTryout(System.ComponentModel.IContainer container) : this()
      //***
      // Action
      //   - Create new instance of 'cmpCustomer' (inside a container)
      //   - Add the component to the container
      // Called by
      //   - User action (Starting the component)
      // Calls
      //   - cmpCustomerTryout()
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
			container.Add(this);
		}
    // cmpCustomer(System.ComponentModel.IContainer) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cmpCustomerTryout

}
// CopyPaste.Learning