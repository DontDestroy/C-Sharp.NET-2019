﻿//***
// Action
//   - Demo in a WPF form for cpTime
// Created
//   - CopyPaste – 20230320 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20230320 – VVDW
// Proposal (To Do)
//   - There are errors when you clear the textboxes
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CopyPaste.Learning.Toolkit.Time
{

  public partial class wpfTime : Window
  {

    #region "Constructors / Destructors"

    public wpfTime()
    //***
    // Action
    //   - Creating an instance of "wpfTime"
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230320 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20230320 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfTime()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    cpTime thecpTime = new cpTime();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAddSecond_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Add a second to seconds
    //   - When needed, add a minute and set seconds to 0
    //   - When needed, add an hour and set minutes to 0
    //   - When needed, set hour to 0
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - int cpTime.Hour() (Get)
    //   - int cpTime.Minute() (Get)
    //   - int cpTime.Second() (Get)
    //   - cpTime.Hour(int) (Set)
    //   - cpTime.Minute(int) (Set)
    //   - cpTime.Second(int) (Set)
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20230320 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230320 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      thecpTime.Second = (thecpTime.Second + 1) % 60;
      txtSetSecond.Text = thecpTime.Second.ToString();

      if (thecpTime.Second == 0)
      {
        thecpTime.Minute = (thecpTime.Minute + 1) % 60;
        txtSetMinute.Text = thecpTime.Minute.ToString();

        if (thecpTime.Minute == 0)
        {
          thecpTime.Hour = (thecpTime.Hour + 1) % 24;
          txtSetHour.Text = thecpTime.Hour.ToString();
        }
        else
        // thecpTime.Minute <> 0
        {
          thecpTime.Minute = 0;
        }
        // thecpTime.Minute = 0

      }
      else
      // thecpTime.Second <> 0
      {
      }
      // thecpTime.Second = 0

      UpdateDisplay();
    }
    // cmdAddSecond_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAddSecond.Click

    private void txtSetHour_TextChanged(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Set second
    //   - Update display
    // Called by
    //   - User action (Changing text)
    // Calls
    //   - cpTime.Hour(int) (Set)
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20230320 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230320 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - The application fails when text is cleared
    //***
    {
      thecpTime.Hour = Convert.ToInt32(txtSetHour.Text);
      UpdateDisplay();
    }
    // txtSetHour_TextChanged(System.Object, System.Windows.RoutedEventArgs) Handles txtSetHour.TextChanged

    private void txtSetMinute_TextChanged(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Set minute
    //   - Update display
    // Called by
    //   - User action (Changing text)
    // Calls
    //   - cpTime.Minute(int) (Set)
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20230320 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230320 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - The application fails when text is cleared
    //***
    {
      thecpTime.Minute = Convert.ToInt32(txtSetMinute.Text);
      UpdateDisplay();
    }
    // txtSetMinute_TextChanged(System.Object, System.Windows.RoutedEventArgs) Handles txtSetMinute.TextChanged

    private void txtSetSecond_TextChanged(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Set second
    //   - Update display
    // Called by
    //   - User action (Changing text)
    // Calls
    //   - cpTime.Second(int) (Set)
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste – 20220301 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220301 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - The application fails when text is cleared
    //***
    {
      thecpTime.Second = Convert.ToInt32(txtSetSecond.Text);
      UpdateDisplay();
    }
    // txtSetSecond_TextChanged(System.Object, System.Windows.RoutedEventArgs) Handles txtSetSecond.TextChanged

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void UpdateDisplay()
    //***
    // Action
    //   - Update 2 outputs
    // Called by
    //   - cmdAddSecond_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAddSecond.Click
    //   - txtSetHour_TextChanged(System.Object, System.Windows.RoutedEventArgs) Handles txtSetHour.TextChanged
    //   - txtSetMinute_TextChanged(System.Object, System.Windows.RoutedEventArgs) Handles txtSetMinute.TextChanged
    //   - txtSetSecond_TextChanged(System.Object, System.Windows.RoutedEventArgs) Handles txtSetSecond.TextChanged
    // Calls
    //   - int cpTime.Hour() (Get)
    //   - int cpTime.Minute() (Get)
    //   - int cpTime.Second() (Get)
    //   - string cpTime.ToAmericanString()
    //   - string cpTime.ToUniversalString()
    // Created
    //   - CopyPaste – 20230320 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230320 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lblOutput1.Content = "Hour: " + thecpTime.Hour + "; Minute: " + thecpTime.Minute + "; Second: " + thecpTime.Second;
      lblOutput2.Content = "Standard time is: " + thecpTime.ToAmericanString() + "; Universal Time is: " + thecpTime.ToUniversalString();
    }
    // UpdateDisplay()

    #endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfTime 

}
// Time_WPF