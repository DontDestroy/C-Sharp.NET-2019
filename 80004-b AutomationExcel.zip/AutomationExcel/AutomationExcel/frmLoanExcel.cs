//***
// Action
//   - Example of using an Excel Com element
//   - Server (Excel) - Client (My application)
// Created
//   - CopyPaste � 20251227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251227 � VVDW
// Proposal (To Do)
//   -  Make sure your .NET application is 64-bit or 32-bit according to your Office 365
//   -  Here it is set to x86 (32-bit office), because this is my installed version of Office
//***

using System;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Office.Interop;

namespace CopyPaste.Learning
{

  public class frmLoanExcel: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblTitle;
    internal System.Windows.Forms.Label lblAmount;
    internal System.Windows.Forms.Label lblMonths;
    internal System.Windows.Forms.Label lblIntrest;
    internal System.Windows.Forms.TextBox txtAmount;
    internal System.Windows.Forms.TextBox txtMonths;
    internal System.Windows.Forms.TextBox txtIntrest;
    internal System.Windows.Forms.Button cmdCalculation;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmLoanExcel));
      this.lblTitle = new System.Windows.Forms.Label();
      this.lblAmount = new System.Windows.Forms.Label();
      this.lblMonths = new System.Windows.Forms.Label();
      this.lblIntrest = new System.Windows.Forms.Label();
      this.txtAmount = new System.Windows.Forms.TextBox();
      this.txtMonths = new System.Windows.Forms.TextBox();
      this.txtIntrest = new System.Windows.Forms.TextBox();
      this.cmdCalculation = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // lblTitle
      // 
      this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblTitle.Location = new System.Drawing.Point(14, 8);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(264, 24);
      this.lblTitle.TabIndex = 8;
      this.lblTitle.Text = "Payment calculation in Excel";
      this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblAmount
      // 
      this.lblAmount.Location = new System.Drawing.Point(46, 128);
      this.lblAmount.Name = "lblAmount";
      this.lblAmount.Size = new System.Drawing.Size(72, 24);
      this.lblAmount.TabIndex = 13;
      this.lblAmount.Text = "Amount";
      // 
      // lblMonths
      // 
      this.lblMonths.Location = new System.Drawing.Point(46, 88);
      this.lblMonths.Name = "lblMonths";
      this.lblMonths.Size = new System.Drawing.Size(64, 16);
      this.lblMonths.TabIndex = 11;
      this.lblMonths.Text = "Months";
      // 
      // lblIntrest
      // 
      this.lblIntrest.Location = new System.Drawing.Point(46, 48);
      this.lblIntrest.Name = "lblIntrest";
      this.lblIntrest.Size = new System.Drawing.Size(64, 16);
      this.lblIntrest.TabIndex = 9;
      this.lblIntrest.Text = "Intrest";
      // 
      // txtAmount
      // 
      this.txtAmount.Location = new System.Drawing.Point(118, 128);
      this.txtAmount.Name = "txtAmount";
      this.txtAmount.Size = new System.Drawing.Size(128, 20);
      this.txtAmount.TabIndex = 14;
      this.txtAmount.Text = "";
      // 
      // txtMonths
      // 
      this.txtMonths.Location = new System.Drawing.Point(118, 88);
      this.txtMonths.Name = "txtMonths";
      this.txtMonths.Size = new System.Drawing.Size(128, 20);
      this.txtMonths.TabIndex = 12;
      this.txtMonths.Text = "";
      // 
      // txtIntrest
      // 
      this.txtIntrest.Location = new System.Drawing.Point(118, 48);
      this.txtIntrest.Name = "txtIntrest";
      this.txtIntrest.Size = new System.Drawing.Size(128, 20);
      this.txtIntrest.TabIndex = 10;
      this.txtIntrest.Text = "";
      // 
      // cmdCalculation
      // 
      this.cmdCalculation.Location = new System.Drawing.Point(102, 184);
      this.cmdCalculation.Name = "cmdCalculation";
      this.cmdCalculation.Size = new System.Drawing.Size(88, 32);
      this.cmdCalculation.TabIndex = 15;
      this.cmdCalculation.Text = "&Calculation";
      this.cmdCalculation.Click += new System.EventHandler(this.cmdCalculation_Click);
      // 
      // frmLoanExcel
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 245);
      this.Controls.Add(this.lblTitle);
      this.Controls.Add(this.lblAmount);
      this.Controls.Add(this.lblMonths);
      this.Controls.Add(this.lblIntrest);
      this.Controls.Add(this.txtAmount);
      this.Controls.Add(this.txtMonths);
      this.Controls.Add(this.txtIntrest);
      this.Controls.Add(this.cmdCalculation);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmLoanExcel";
      this.Text = "Loan calculation in Excel";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmLoanExcel'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmLoanExcel()
      //***
      // Action
      //   - Create instance of 'frmLoanExcel'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmLoanExcel()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCalculation_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a variable for the result
      //   - Start an Excel application
      //   - Set the culture to English (I will use the English formulas)
      //   - Execute the worksheet function PMT
      //   - Show the result in a certain format
      //   - Stop an Excel application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      double dblLoanPayment;
      Microsoft.Office.Interop.Excel.Application theExcelApplication = new Microsoft.Office.Interop.Excel.Application();

      Thread.CurrentThread.CurrentCulture = System.Globalization.CultureInfo.CreateSpecificCulture("en-US");
      dblLoanPayment = theExcelApplication.WorksheetFunction.Pmt(Convert.ToDouble(txtIntrest.Text) / 100 / 12, Convert.ToDouble(txtMonths.Text), Convert.ToDouble(txtAmount.Text), null, null);
      MessageBox.Show("The monthly payment is " + Math.Abs(dblLoanPayment).ToString("� #,##0.00"), "Loan");
      theExcelApplication.Quit();
    }
    // cmdCalculation_Click(System.Object, System.EventArgs) Handles cmdCalculation.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmLoanExcel
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmLoanExcel()
      // Created
      //   - CopyPaste � 20251227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      System.Windows.Forms.Application.Run(new frmLoanExcel());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmLoanExcel

}
// CopyPaste.Learning