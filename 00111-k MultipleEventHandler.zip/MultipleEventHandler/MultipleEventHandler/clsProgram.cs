//***
// Action
//   - TestRoutines of cpMorning
// Created
//   - CopyPaste � 20240524 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240524 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static cpMorning mcpMorning;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private static void AutomateHouse(string strItem, DateTime dtmStart)
      //***
      // Action
      //   - Show that an item is started at a certain time
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Starting " + strItem + " at: " + dtmStart);
    }
    // AutomateHouse(string, DateTime)

    #endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Add three events to cpMorning
      //   - Generate the events
      //   - Show to hit enter
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - AutomateHouse(string, DateTime)
      //   - cpMorning()
      //   - cpMorning.GenerateEvents()
      //   - cpMorning.StartCoffee(string, DateTime)
      //   - cpMorning.StartShower(string, DateTime)
      //   - cpMorning.TurnOnTV(string, DateTime)
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mcpMorning = new cpMorning();

      if (mcpMorning == null)
      {
      }
      else
        // mcpMorning <> null
      {
        mcpMorning.StartCoffee += new cpMorning.cpStartCoffee(AutomateHouse);
        mcpMorning.StartShower += new cpMorning.cpStartShower(AutomateHouse); 
        mcpMorning.TurnOnTV += new cpMorning.cpTurnOnTV(AutomateHouse); 

        mcpMorning.GenerateEvents();
        Console.WriteLine();

        cpMorning.cpStartCoffee theCoffee = AutomateHouse;
        theCoffee("Coffee with milk", DateTime.Now.AddMinutes(-10));
        // theCoffee.Invoke("Coffee with milk", DateTime.Now.AddMinutes(-10));
        cpMorning.cpStartShower theShower = AutomateHouse;
        theShower("Cold shower", DateTime.Now.AddMinutes(-5));
        // theShower.Invoke("Cold shower", DateTime.Now.AddMinutes(-5));
        cpMorning.cpTurnOnTV theTV = AutomateHouse;
        theTV("Sport Channel", DateTime.Now);
        // theTV.Invoke("Sport Channel", DateTime.Now);
      }
      // mcpMorning = null

      Console.WriteLine();
      Console.WriteLine("Hit enter to stop program");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning