//***
// Action
//   - TestRoutine for cpEmployee and cpDay
// Created
//   - CopyPaste � 20220308 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220308 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace Composition
{

  class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Create an instance of cpEmployee
    //   - Show its value
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpEmployee(string, string, int, int, int, int, int, int)
    // Created
    //   - CopyPaste � 20220308 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220308 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpEmployee theCPEmployee = new cpEmployee("Bob", "Jones", 27, 7, 1949, 12, 3, 1988);

      MessageBox.Show(theCPEmployee.ToStandardString(), "Testing Class Employee");
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// Composition