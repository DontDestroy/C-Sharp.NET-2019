//***
// Action
//   - Demo of a pattern maker
//     - There are patters
//     - Patterns have an editor
//     - New instances of the patterns can be created
//   - There are 2 different type of patterns
//     - Bitmap pattern (a picture)
//     - Drawing pattern (a drawing with lines)
//   - Both patterns have an editor
//   - The patterns and the pattern editors do have polymorph behaviour
//   - The goals is to make it easy to implement a third kind of pattern
//   - Due to polymorphism
//     - No need to repeat some code
//     - Base and child classes do the trick
//     - Using the base instance, the childs functionality can be triggered
// Created
//   - CopyPaste � 20240330 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240330 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPatternMaker: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.GroupBox grpEditor;
    internal System.Windows.Forms.Panel panPattern;
    internal System.Windows.Forms.Panel panTemplate;
    internal System.Windows.Forms.Label lblPattern;
    internal System.Windows.Forms.Label lblEditor;
    internal System.Windows.Forms.Label lblTemplate;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPatternMaker));
      this.grpEditor = new System.Windows.Forms.GroupBox();
      this.panPattern = new System.Windows.Forms.Panel();
      this.panTemplate = new System.Windows.Forms.Panel();
      this.lblPattern = new System.Windows.Forms.Label();
      this.lblEditor = new System.Windows.Forms.Label();
      this.lblTemplate = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // grpEditor
      // 
      this.grpEditor.Location = new System.Drawing.Point(120, 37);
      this.grpEditor.Name = "grpEditor";
      this.grpEditor.Size = new System.Drawing.Size(200, 175);
      this.grpEditor.TabIndex = 17;
      this.grpEditor.TabStop = false;
      // 
      // panPattern
      // 
      this.panPattern.AutoScroll = true;
      this.panPattern.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panPattern.Location = new System.Drawing.Point(16, 253);
      this.panPattern.Name = "panPattern";
      this.panPattern.Size = new System.Drawing.Size(304, 90);
      this.panPattern.TabIndex = 16;
      // 
      // panTemplate
      // 
      this.panTemplate.AutoScroll = true;
      this.panTemplate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panTemplate.Location = new System.Drawing.Point(16, 45);
      this.panTemplate.Name = "panTemplate";
      this.panTemplate.Size = new System.Drawing.Size(90, 168);
      this.panTemplate.TabIndex = 15;
      // 
      // lblPattern
      // 
      this.lblPattern.Location = new System.Drawing.Point(16, 229);
      this.lblPattern.Name = "lblPattern";
      this.lblPattern.TabIndex = 14;
      this.lblPattern.Text = "&Patterns";
      // 
      // lblEditor
      // 
      this.lblEditor.Location = new System.Drawing.Point(120, 21);
      this.lblEditor.Name = "lblEditor";
      this.lblEditor.TabIndex = 13;
      this.lblEditor.Text = "&Editor";
      // 
      // lblTemplate
      // 
      this.lblTemplate.Location = new System.Drawing.Point(16, 21);
      this.lblTemplate.Name = "lblTemplate";
      this.lblTemplate.TabIndex = 12;
      this.lblTemplate.Text = "&Templates";
      // 
      // frmPatternMaker
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(336, 365);
      this.Controls.Add(this.grpEditor);
      this.Controls.Add(this.panPattern);
      this.Controls.Add(this.panTemplate);
      this.Controls.Add(this.lblPattern);
      this.Controls.Add(this.lblEditor);
      this.Controls.Add(this.lblTemplate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPatternMaker";
      this.Text = "Pattern Maker";
      this.Load += new System.EventHandler(this.frmPatternMaker_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPatternMaker'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPatternMaker()
      //***
      // Action
      //   - Create instance of 'frmPatternMaker'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPatternMaker()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpPattern mthePattern = null;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmPatternMaker_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - 2 drawnpatterns and 1 bitmap pattern are shown as template
      //   - Points are added to the first drawing
      //   - Points are added to the second drawing
      //   - A bitmap is added to the first bitmap
      //   - The 3 patters are added to an array
      //   - The array is looped
      //   - For every Pattern in the array
      //     - A cpctlPatternButton is added
      //     - It is given a position
      //     - It is added to the panel of the templates
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpctlPatternButton(cpPattern)
      //   - TemplateClick(System.Object, System.EventArgs)
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpDrawnPattern theDrawn01 = new cpDrawnPattern();
      cpDrawnPattern theDrawn02 = new cpDrawnPattern();
      cpBitmapPattern theBitmap01 = new cpBitmapPattern();
      
      int intPattern;

      theDrawn01.Points = new Point[] { new Point(0, 30), 
                                        new Point(60, 30), 
                                        new Point(60, 0), 
                                        new Point(30, 0), 
                                        new Point(30, 60)
                                      };

      theDrawn02.Points = new Point[] { new Point(30, 0), 
                                        new Point(60, 30), 
                                        new Point(30, 60), 
                                        new Point(0, 30), 
                                        new Point(30, 0), 
                                        new Point(0, 0)
                                      };
      theBitmap01.BitmapFile = Directory.GetCurrentDirectory() + "\\BearPawBlue.bmp";

      cpPattern[] thePatterns = {theDrawn01, theDrawn02, theBitmap01};

      for (intPattern = 0; intPattern < thePatterns.Length; intPattern++)
      {
        cpctlPatternButton theButton = new cpctlPatternButton(thePatterns[intPattern]);
        theButton.Top = 70 * intPattern;
        theButton.Left = 5;
        theButton.Click += new EventHandler(this.TemplateClick);
        panTemplate.Controls.Add(theButton);
      }
      // intPattern = thePatterns.Length

    }
    // frmPatternMaker_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    #region "Event"

    private void PatternSaved(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The moment the pattern is saved, the control is removed and disposed
      //   - The clone of the template that is saved becomes a cpctlPatternButton
      //   - Position is determined
      //   - Button becomes not clickable
      //   - The saved pattern is added to the list of patterns
      // Called by
      //   - TemplateClick(System.Object, System.EventArgs) Handles this.Load
      //   - User action (Clicking a cpctlPatternButton)
      // Calls
      //   - cpctlPatternButton.New(cpPattern)
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Controls.Remove((Control)theSender);
      ((Control)theSender).Dispose();

      cpctlPatternButton theButton = new cpctlPatternButton(mthePattern);

      theButton.Left = panPattern.Controls.Count * 70;
      theButton.Top = 5;
      theButton.Enabled = false;
      panPattern.Controls.Add(theButton);
      panTemplate.Enabled = true;
    }
    // PatternSaved(System.Object, System.EventArgs)

    private void TemplateClick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The trigger of the event is determined by theSender
      //   - A clone is made of that cpPattern
      //   - The editor of that pattern is determined
      //   - A location of that editor is given as a point
      //   - The editor is added as a control in the grpEditor
      //   - The event PatternSaved is handles by the cpSaved event
      // Called by
      //   - frmPatternMaker_Load(System.Object, System.EventArgs) Handles MyBase.Load
      //   - User action (Clicking a cpctlPatternButton)
      // Calls
      //   - cpctlPatternEditor cpPattern.cpGetEditor()
      //     - cpctlPatternEditor cpBitmapPattern.cpGetEditor() 
      //     - cpctlPatternEditor cpDrawnPattern.cpGetEditor()
      //   - cpctlPatternEditor.cpSaved(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs)
      //   - cpPattern cpctlPatternButton.Pattern (Get)
      //   - cpPattern cpPattern.cpClone()
      //     - cpPattern cpBitmapPattern.cpClone()
      //     - cpPattern cpDrawnPattern.cpClone()
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpctlPatternButton theButton = (cpctlPatternButton)theSender;

      mthePattern = theButton.Pattern.cpClone();

      cpctlPatternEditor theEditor = mthePattern.cpGetEditor();
      
      theEditor.Location = new Point(10, 10);
      this.grpEditor.Controls.Add(theEditor);
      theEditor.cpSaved += new cpctlPatternEditor.cpSavedEventHandler(this.PatternSaved);
      panTemplate.Enabled = false;
    }
    // TemplateClick(System.Object, System.EventArgs)

    #endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPatternMaker
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPatternMaker());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPatternMaker

}
// CopyPaste.Learning