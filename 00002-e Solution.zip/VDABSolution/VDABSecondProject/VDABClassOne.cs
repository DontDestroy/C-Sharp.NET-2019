//***
// Action
//   - 
// Created
//   - CopyPaste � 20211018 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20211018 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace VDAB.SecondProject
{

  class VDABClassOne
	{

    static void Main()
    //***
    // Action
    //   - 
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20211018 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20211018 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // Main()

  }
  // VDABClassOne

}
// VDAB.SecondProject