//***
// Action
//   - Count different grades
// Created
//   - CopyPaste � 20220119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220119 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace SwitchTest
{

  class cpSwitchTest
	{

    static void Main()
    //***
    // Action
    //   - Ask for a grade (lngGrade)
    //   - While 'lngGrade' is not -1
    //     - Depending on 'lngGrade'
    //       - Show grade
    //       - Count grade
    //       - Ask for a grade (lngGrade)
    //   - Show results at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - int System.Convert.ToInt32(string)
    //   - string System.Console.ReadLine()
    //   - System.Console.Write(string)
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220119 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220119 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngGrade = 0;
      long lngACount = 0;
      long lngBCount = 0;
      long lngCCount = 0;
      long lngDCount = 0;
      long lngFCount = 0;

      Console.Write("Enter a grade, -1 to quit: ");
      lngGrade = Convert.ToInt32(Console.ReadLine());

      while (lngGrade != -1)
      {

        switch (lngGrade)
        {
          case 100:
            Console.WriteLine("Perfect Score!\nLetter grade: A");
            lngACount += 1;
            break;
          case 0:
            Console.WriteLine("No Score!\nLetter grade: F");
            lngFCount += 1;
            break;
          case long lngValue when lngValue >= 90:
            Console.WriteLine("Letter Grade: A\n");
            lngACount += 1;
            break;
          case long lngValue when lngValue >= 80:
            Console.WriteLine("Letter Grade: B\n");            
            lngBCount += 1;
            break;
          case long lngValue when lngValue >= 70:
            Console.WriteLine("Letter Grade: C\n");
            lngCCount += 1;
            break;
          case long lngValue when lngValue >= 60:
            Console.WriteLine("Letter Grade: D\n");
            lngDCount += 1;
            break;
          case long lngValue when lngValue >= 10:
            Console.WriteLine("Letter Grade: F\n");
            lngFCount += 1;
            break;
          case long lngValue when lngValue < 10:
            Console.WriteLine("Invalid Input. Please enter a valid grade.\n");
            break;
        }
        // lngGrade

        Console.Write("Enter a grade, -1 to quit: ");
        lngGrade = Convert.ToInt32(Console.ReadLine());
      }
      // lngGrade <> -1

      Console.WriteLine("\nTotals for each letter grade are: \n" +
        "A: " + lngACount +
        "\nB: " + lngBCount +
        "\nC: " + lngCCount +
        "\nD: " + lngDCount +
        "\nF: " + lngFCount);
      Console.ReadLine();
    }
    // Main()

  }
  // cpSwitchTest

}
// SwitchTest