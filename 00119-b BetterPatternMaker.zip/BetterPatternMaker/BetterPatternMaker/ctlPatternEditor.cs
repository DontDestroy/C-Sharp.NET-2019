//***
// Action
//   - Control pattern editor inherits from UserControl
//     - It can be placed at runtime on the form
//   - Base class for all the editors
//     - A save functionality must be implemented in the childs (using events)
//   - No abstract class is used here
//     - Abstract classes can't be used in Windows Forms Designer
// Created
//   - CopyPaste � 20240409 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240409 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpctlPatternEditor : System.Windows.Forms.UserControl
	{

		#region Component Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdSave;

    private void InitializeComponent()
		{
      this.cmdSave = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdSave
      // 
      this.cmdSave.Location = new System.Drawing.Point(88, 112);
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.TabIndex = 1;
      this.cmdSave.Text = "Save";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // cpctlPatternEditor
      // 
      this.Controls.Add(this.cmdSave);
      this.Name = "cpctlPatternEditor";
      this.Size = new System.Drawing.Size(175, 150);
      this.ResumeLayout(false);

    }

		#endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpctlPatternEditor'
      // Called by
      //   - User action (Closing the control)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpctlPatternEditor()
      //***
      // Action
      //   - Create instance of 'cpctlPatternEditor'
      // Called by
      //   - cpBitmapPatternEditor(cpBitmapPattern)
      //   - cpDrawnPatternEditor(cpDrawnPattern)
      //   - User action (Starting the control)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // cpctlPatternEditor()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public virtual event cpSavedEventHandler cpSaved;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Does nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - SavePattern()
      //   - cpSaved(System.Object, System.EventArgs)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      SavePattern();

      if (this.cpSaved == null)
      {
      }
      else
        // this.cpSaved <> null
      {
        this.cpSaved(this, new System.EventArgs());
      }
      // this.cpSaved = null

    }
    // cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click

    #endregion

    #region "Functionality"

    #region "Event"
    
    public delegate void cpSavedEventHandler(System.Object theSender, System.EventArgs theEventArguments);

    #endregion

    #region "Sub / Function"

    public virtual void SavePattern()
      //***
      // Action
      //   - Does nothing
      // Called by
      //   - cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // SavePattern()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpctlPatternEditor

}
// CopyPaste.Learning