//***
// Action
//   - Testroutine of cpCounter
//   - There is a problem with this code, do you find the issue
// Created
//   - CopyPaste � 20240305 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240305 � VVDW
// Proposal (To Do)
//   - There is an issue with the code that is programmed here
//   - Technically there is not a problem
//   - Functionally it does not make any sense
//   - Do you find the issue
//***

using CopyPaste.Learning;
using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create an instance of cpCounter
      //   - Increment twice
      //   - Decrement
      //   - Increment
      //   - Show the value
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpCounter.Decrement()
      //   - cpCounter.Increment()
      //   - cpCounter.New()
      //   - cpCounter.ShowCounter()
      // Created
      //   - CopyPaste � 20240305 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240305 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpCounter thecpCounter = new cpCounter();
      
      thecpCounter.Increment();
      thecpCounter.Increment();
      thecpCounter.Decrement();
      thecpCounter.Increment();
      MessageBox.Show("Counter: " + thecpCounter.ShowCounter());
    }
    // Main()
		
    public static Object ShowObjectValue(cpCounter thecpCounter)
      //***
      // Action
      //   - Show the value of a given counter
      // Called by
      //   - int cpCounter.ShowCounter()
      // Calls
      //   - Counter() As Int32 (Get)
      // Created
      //   - CopyPaste � 20240305 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240305 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return thecpCounter.Counter;
    }
    // Object ShowObjectValue(thecpCounter)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// CopyPaste.Learning