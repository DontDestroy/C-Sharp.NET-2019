//***
// Action
//   - Implementation of cpBase
// Created
//   - CopyPaste � 20240618 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240618 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpBase
  // public abstract class cpBase
  {

    #region "Constructors / Destructors"

    public cpBase()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpDerived()
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpBase()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    // public abstract void SubMustOverride();

    // public sealed void SubNotOverridable()
    // {
    //   Console.WriteLine("Sub Not Overridable in Base");
    // }
    // // SubNotOverridable()

    public void SubOverLoad()
      //***
      // Action
      //   - Show that the subroutine is overloaded
      // Called by
      //   - cpDerived.SubTestDerived()
      //   - cpProgram.Main()
      //   - SubTestBase()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Sub Overload in Base");
    }
    // SubOverLoad()

    public void SubOverLoad(string strString)
      //***
      // Action
      //   - Show that the subroutine is overloaded
      // Called by
      //   - cpDerived.SubTestDerived()
      //   - cpProgram.Main()
      //   - SubTestBase()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Sub Overload in Base with string: " + strString);
    }
    // SubOverLoad(string)

    public virtual void SubOverridable()
      //***
      // Action
      //   - Show that the subroutine is overridable
      // Called by
      //   - cpProgram.Main()
      //   - SubTestBase()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Sub Overridable in Base");
    }
    // SubOverridable()

    public void SubShadows()
      //***
      // Action
      //   - Show that the subroutine is shadowed
      // Called by
      //   - modSub.Main()
      //   - SubTestBase()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Sub Shadows in Base");
    }
    // SubShadows()

    public static void SubStatic()
      //***
      // Action
      //   - Show that the subroutine is shared
      // Called by
      //   - cpDerived.SubTestDerived()
      //   - cpProgram.Main()
      //   - SubTestBase()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Sub Static in Base");
    }
    // SubStatic()

    public void SubTestBase()
      //***
      // Action
      //   - Execute all subroutines
      // Called by
      //   - modSub.Main()
      // Calls
      //   - SubMustOverride()
      //   - SubNotOverridable()
      //   - SubOverLoad()
      //   - SubOverLoad(String)
      //   - SubOverridable()
      //   - SubShadows()
      //   - SubStatic()
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      SubOverLoad();
      SubOverLoad("This is overloaded");
      SubOverridable();
      // SubNotOverridable();
      // SubMustOverride();
      SubShadows();
      SubStatic();
    }
    // SubTestBase()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBase

}
// CopyPaste.Learning