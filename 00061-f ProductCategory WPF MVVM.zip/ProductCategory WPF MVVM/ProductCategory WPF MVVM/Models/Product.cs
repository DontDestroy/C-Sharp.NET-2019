﻿//***
// Action
//   - Product class (in Models)
//   - Will be used to create a table in SQL Server Database
//   - None of the namings are according to the Copy Paste naming conventions
//   - There is a link towards the class Product Category (also here there is a mismatch between the naming conventions)
// Created
//   - CopyPaste – 20220824 – VVDW
// Changed
//   - CopyPaste – 20260407 – VVDW – Added some comments for connection to SQL Server Database
// Tested
//   - CopyPaste – 20220824 – VVDW
// Proposal (To Do)
//   -
//***

using ProductCategory_WPF_MVVM.Utilities;
using System;

namespace ProductCategory_WPF_MVVM.Models
{

  public class Product : ObservableObject
  {

    #region "Constructors / Destructors"

    public Product()
    //***
    // Action
    //   - Create an instance of 'Product'
    // Called by
    //   - 
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    { 
    }
    // Product()

    public Product(int intIdProduct, string strProductName, DateTime dtmIntroduction, string strUrl, decimal decPrice, DateTime? dtmRetire, ProductCategory? theProductCategory) : this()
    //***
    // Action
    //   - Create an instance of 'Product'
    //     - Fill the property Key
    //     - Fill the property Name
    //     - Fill the property IntroductionDate
    //     - Fill the property Url
    //     - Fill the property Price
    //     - Fill the property RetireDate
    //     - Fill the property Category
    // Called by
    //   - MockDataService.FillProduct()
    //   - EntityFrameWorkDataService.FillProduct(cpApplicationDatabaseContext)
    // Calls
    //   - ProductCategoryId(ProductCategory) (Set)
    //   - ProductId(int) (Set)
    //   - IntroductionDate(DateTime) (Set)
    //   - Name(string) (Set)
    //   - Price(decimal) (Set)
    //   - RetireDate(DateTime) (Set)
    //   - Url(string) (Set)
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ProductId = intIdProduct;
      Name = strProductName;
      IntroductionDate = dtmIntroduction;
      Url = strUrl;
      Price = decPrice;
      RetireDate = dtmRetire;
      ProductCategory = theProductCategory;
    }
    // Product(int, string, DateTime, string, decimal, DateTime?, ProductCategory?)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int _intIdProduct;
    private string _strProductName;
    private DateTime _dtmIntroduction;
    private string _strUrl;
    private decimal _decPrice;
    private DateTime? _dtmRetire;
    private ProductCategory? _ProductCategory;
    private int? _intProductCategoryId;

    #endregion

    #region "Properties"

    public DateTime IntroductionDate
    {

      get
      //***
      // Action Get
      //   - Return _dtmIntroduction
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _dtmIntroduction;
      }
      // DateTime IntroductionDate (Get)

      set
      //***
      // Action Set
      //   - Sets _dtmIntroduction with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - Product(int, string, DateTime, string, decimal, DateTime?, ProductCategory?)
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        OnPropertyChanged(ref _dtmIntroduction, value);
      }
      // IntroductionDate(DateTime) (Set)

    }
    // DateTime IntroductionDate

    public string Name
    {

      get
      //***
      // Action Get
      //   - Return _strProductName
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _strProductName;
      }
      // string Name (Get)

      set
      //***
      // Action Set
      //   - Sets _strProductName with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - Product(int, string, DateTime, string, decimal, DateTime?, ProductCategory?)
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        OnPropertyChanged(ref _strProductName, value);
      }
      // Name(string) (Set)

    }
    // string Name

    public decimal Price
    {

      get
      //***
      // Action Get
      //   - Return _decPrice
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _decPrice;
      }
      // decimal Price (Get)

      set
      //***
      // Action Set
      //   - Sets _decPrice with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - Product(int, string, DateTime, string, decimal, DateTime?, ProductCategory?)
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        OnPropertyChanged(ref _decPrice, value);
      }
      // Price(decimal) (Set)

    }
    // decimal Price

    public int? ProductCategoryId
    {

      get
      //***
      // Action Get
      //   - Return _intProductCategoryId
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260408 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260408 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _intProductCategoryId;
      }
      // int? ProductCategoryId (Get)

      set
      //***
      // Action Set
      //   - Sets _intProductCategoryId with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   -
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260408 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260408 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        OnPropertyChanged(ref _intProductCategoryId, value);
      }
      // ProductCategoryId(int?) (Set)

    }
    // int? ProductCategoryId

    public ProductCategory? ProductCategory
    {

      get
      //***
      // Action Get
      //   - Return _ProductCategory
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _ProductCategory;
      }
      // ProductCategory? ProductCategory (Get)

      set
      //***
      // Action Set
      //   - Sets _ProductCategory with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - Product(int, string, DateTime, string, decimal, DateTime?, ProductCategory?)
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        OnPropertyChanged(ref _ProductCategory, value);
      }
      // ProductCategory(ProductCategory?) (Set)

    }
    // ProductCategory? ProductCategory

    public int ProductId
    {

      get
      //***
      // Action Get
      //   - Return _intIdProduct
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _intIdProduct;
      }
      // int ProductId (Get)

      set
      //***
      // Action Set
      //   - Sets _intIdProduct with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - Product(int, string, DateTime, string, decimal, DateTime?, ProductCategory?)
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        OnPropertyChanged(ref _intIdProduct, value);
      }
      // ProductId(int) (Set)

    }
    // int ProductId

    public DateTime? RetireDate
    {

      get
      //***
      // Action Get
      //   - Return _dtmRetire
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _dtmRetire;
      }
      // DateTime? RetireDate (Get)

      set
      //***
      // Action Set
      //   - Sets _dtmRetire with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - Product(int, string, DateTime, string, decimal, DateTime?, ProductCategory?)
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        OnPropertyChanged(ref _dtmRetire, value);
      }
      // RetireDate(DateTime?) (Set)

    }
    // DateTime? RetireDate

    public string Url
    {

      get
      //***
      // Action Get
      //   - Return _strUrl
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _strUrl;
      }
      // string Url (Get)

      set
      //***
      // Action Set
      //   - Sets _strProductName with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - Product(int, string, DateTime, string, decimal, DateTime?, ProductCategory?)
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        OnPropertyChanged(ref _strUrl, value);
      }
      // Url(string) (Set)

    }
    // string Url

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // Product

}
// ProductCategory_WPF_MVVM.Models