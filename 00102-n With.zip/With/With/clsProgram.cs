//***
// Action
//   - Testroutine for cpLunchOrder
// Created
//   - CopyPaste � 20230424 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230424 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;

namespace With
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Testroutine for cpLunchOrder
    //   - The with keyword does not exist in C# like it is used in Visual Basic
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpLunchOrder(string, string, string, string)
    // Created
    //   - CopyPaste � 20230424 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230424 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***

    {
      cpLunchOrder theLunch = new cpLunchOrder("Spinach", "Pasta", "Red Wine", "Cookies");

      Console.WriteLine("Salid: " + theLunch.mstrSalad);
      Console.WriteLine("Meal: " + theLunch.mstrMeal);
      Console.WriteLine("Beverage: " + theLunch.mstrBeverage);
      Console.WriteLine("Dessert: " + theLunch.mstrDessert);
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// With