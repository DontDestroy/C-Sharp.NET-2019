//***
// Action
//   - Implementation of cpFileMonitorService
// Created
//   - CopyPaste � 20240718 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240718 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.ServiceProcess;
using CopyPaste.Learning.Toolkit.Tool;

namespace CopyPaste.Learning.Toolkit.Tool
{

  public class cpFileMonitorService : System.ServiceProcess.ServiceBase
  {

    #region " Component Designer generated code"

    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      components = new System.ComponentModel.Container();
      this.ServiceName = "cpFileMonitorService";
    }
    
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpFileMonitorService'
      // Called by
      //   - System action (Closing the service)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpFileMonitorService()
      //***
      // Action
      //   - Create instance of 'cpFileMonitorService'
      //   - Enable the event logger
      //   - Set AutoLog to true
      //   - Set CanStop to true
      //   - Create an instance of cpSentinel for the hard disk T:
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyy20240718mmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      
      EventLog.EnableRaisingEvents = true;
      this.AutoLog = true;
      this.CanStop = true;

      theSentinel = new cpSentinel("T:\\");
    }
    // cpFileMonitorService()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpSentinel theSentinel;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void OnStart(string[] strarrArguments)
      //***
      // Action
      //   - Code when service is started
      //   - Start the cpSentinel
      //   - Write an event log
      // Called by
      //   - System action (Starting the service)
      // Calls
      //   - cpSentinel.StartLogging()
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240718 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      theSentinel.StartLogging();
      EventLog.WriteEntry("Started Copy Paster File Monitor Service");
    }
    // OnStart(string[])

    protected override void OnStop()
      //***
      // Action
      //   - Code when service is stopped
      //   - Start the cpSentinel
      //   - Write an event log
      // Called by
      //   - System action (Stopping the service)
      // Calls
      //   - cpSentinel.StopLogging()
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240718 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      theSentinel.StopLogging();
      EventLog.WriteEntry("Stopped Copy Paster File Monitor Service");
    }
    // OnStop()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [MTAThreadAttribute()]
    public static void Main()
      //***
      // Action
      //   - Starting the servive
      // Called by
      //   - System action (Starting the service)
      // Calls
      //   - cpFileMonitorService()
      // Created
      //   - CopyPaste � 20240718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      System.ServiceProcess.ServiceBase[] ServicesToRun;
	
      // More than one user Service may run within the same process. To add
      // another service to this process, change the following line to
      // create a second service object. For example,
      //
      //   ServicesToRun = new System.ServiceProcess.ServiceBase[] {new Service1(), new MySecondUserService()};
      //
      ServicesToRun = new System.ServiceProcess.ServiceBase[] { new cpFileMonitorService() };
      System.ServiceProcess.ServiceBase.Run(ServicesToRun);
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#Region "Not used"
    //#endregion

  }
  // cpFileMonitorService

}
// CopyPaste.Learning.Toolkit.Tool