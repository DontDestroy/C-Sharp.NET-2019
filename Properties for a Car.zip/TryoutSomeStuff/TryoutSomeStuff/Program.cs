﻿using System;

namespace LearnCSharp
{

  class Auto
  {
    private string brand;
    private string colour;

    public Auto(string strBrand, string strColour)
    {
      Brand = strBrand;
      Colour = strColour;
    }

    public string Brand
    {
      get
      {
        return "Brandname " + brand.ToUpper();
      }

      set
      {
        brand = value;
      }

    }

    public string Colour
    {
      get
      {
        return colour;
      }

      set
      {

        if (value == "Black" || value == "White")
        {
          colour = value;
        }
        else
        {
          colour = "Black";
        }

      }

    }

    public void Drive()
    {
      Console.WriteLine("The car {0} is going forward", Brand);
    }

  }

  class TestSomeStuff
  {

    static void Main()
    {
      // Give a demo of what is possible
      Auto car = new Auto("Volvo", "Red");
      Auto tuuttuut = new Auto("Mercedes", "Green");

      Console.WriteLine(car.Colour);
      Console.WriteLine(tuuttuut.Colour);
      Console.WriteLine(car.Brand);

      car.Drive();

      Console.ReadLine();
    }

  }

}