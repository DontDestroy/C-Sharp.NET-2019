//***
// Action
//   - Update records with a stored procedure
//   - Execute parameterized stored procedures in ADO.NET
// Created
//   - CopyPaste � 20251209 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251209 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmStoredProcedureTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtResults;
    internal System.Windows.Forms.Button cmdView;
    internal System.Windows.Forms.TextBox txtIdCustomer;
    internal System.Windows.Forms.Label lblCustomer;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmStoredProcedureTryout));
      this.txtResults = new System.Windows.Forms.TextBox();
      this.cmdView = new System.Windows.Forms.Button();
      this.txtIdCustomer = new System.Windows.Forms.TextBox();
      this.lblCustomer = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // txtResults
      // 
      this.txtResults.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.txtResults.Location = new System.Drawing.Point(8, 48);
      this.txtResults.Multiline = true;
      this.txtResults.Name = "txtResults";
      this.txtResults.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtResults.Size = new System.Drawing.Size(456, 216);
      this.txtResults.TabIndex = 7;
      this.txtResults.Text = "";
      // 
      // cmdView
      // 
      this.cmdView.Location = new System.Drawing.Point(368, 8);
      this.cmdView.Name = "cmdView";
      this.cmdView.Size = new System.Drawing.Size(96, 24);
      this.cmdView.TabIndex = 6;
      this.cmdView.Text = "&View";
      this.cmdView.Click += new System.EventHandler(this.cmdView_Click);
      // 
      // txtIdCustomer
      // 
      this.txtIdCustomer.Location = new System.Drawing.Point(216, 16);
      this.txtIdCustomer.Name = "txtIdCustomer";
      this.txtIdCustomer.Size = new System.Drawing.Size(72, 20);
      this.txtIdCustomer.TabIndex = 5;
      this.txtIdCustomer.Text = "ALFKI";
      // 
      // lblCustomer
      // 
      this.lblCustomer.Location = new System.Drawing.Point(16, 16);
      this.lblCustomer.Name = "lblCustomer";
      this.lblCustomer.Size = new System.Drawing.Size(192, 16);
      this.lblCustomer.TabIndex = 4;
      this.lblCustomer.Text = "Products and Quantities Ordered By:";
      // 
      // frmStoredProcedureTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(472, 273);
      this.Controls.Add(this.txtResults);
      this.Controls.Add(this.cmdView);
      this.Controls.Add(this.txtIdCustomer);
      this.Controls.Add(this.lblCustomer);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmStoredProcedureTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Execute Parameterized Stored Procedures in ADO.NET Tryout";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmStoredProcedureTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmStoredProcedureTryout()
      //***
      // Action
      //   - Create instance of 'frmStoredProcedureTryout'
      // Called by
      //   - frmChangingDataMainTryout.cmdStoredProcedure_Click(System.Object, System.EventArgs) Handles cmdStoredProcedure.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmStoredProcedureTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdView_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a connection string
      //   - Create a command (with the name of a stored procedure)
      //   - Create a data reader
      //   - Try to
      //     - Set the command type
      //     - Add a parameter
      //     - Open the connection
      //     - Execute the command
      //     - Loop thru the resultset
      //       - Adapt the text of the form
      //   - On error
      //     - Show exception message
      //   - Close the connection
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpConnectionString()
      //   - string cpConnectionString.BuildConnectionString()
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdView_Click(System.Object, System.EventArgs) Handles cmdView.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmStoredProcedureTryout

}
// CopyPaste.Learning