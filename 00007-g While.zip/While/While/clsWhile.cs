//***
// Action
//   - Loop with While ... End While
// Created
//   - CopyPaste � 20220119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220119 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace While
{

  class cpWhile
	{

    static void Main()
    //***
    // Action
    //   - Show message
    //   - Ask for number
    //   - While number is not 0
    //     - Add number to total
    //     - Ask for number
    //   - Show total
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - int System.Convert.ToInt32(String)
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    //   - System.Console.WriteLine(string, System.Object)
    // Created
    //   - CopyPaste � 20220119 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220119 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngNumber = 1;
      long lngTotal = 0;
      
      Console.WriteLine("Type some numbers. Stop with 0 (zero)");

      while (lngNumber != 0)
      {
        lngNumber = Convert.ToInt32(Console.ReadLine());
        lngTotal += lngNumber;
      }
      // lngNumber = 0
      
      Console.WriteLine("Total is {0}", lngTotal);
      Console.ReadLine();
    }
    // Main()

  }
  // cpWhile

}
// While