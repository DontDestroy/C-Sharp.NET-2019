//***
// Action
//   - Working with panels
// Created
//   - CopyPaste � 20260717 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260717 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPanel: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Panel panFirst;
    internal System.Windows.Forms.Button cmdDone;
    internal System.Windows.Forms.TextBox txtText;
    internal System.Windows.Forms.Panel panSecond;
    internal System.Windows.Forms.DateTimePicker dtpDate;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPanel));
      this.panFirst = new System.Windows.Forms.Panel();
      this.cmdDone = new System.Windows.Forms.Button();
      this.txtText = new System.Windows.Forms.TextBox();
      this.panSecond = new System.Windows.Forms.Panel();
      this.dtpDate = new System.Windows.Forms.DateTimePicker();
      this.panFirst.SuspendLayout();
      this.panSecond.SuspendLayout();
      this.SuspendLayout();
      // 
      // panFirst
      // 
      this.panFirst.BackColor = System.Drawing.SystemColors.Info;
      this.panFirst.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.panFirst.Controls.Add(this.cmdDone);
      this.panFirst.Controls.Add(this.txtText);
      this.panFirst.Location = new System.Drawing.Point(16, 24);
      this.panFirst.Name = "panFirst";
      this.panFirst.Size = new System.Drawing.Size(200, 100);
      this.panFirst.TabIndex = 2;
      // 
      // cmdDone
      // 
      this.cmdDone.Location = new System.Drawing.Point(64, 56);
      this.cmdDone.Name = "cmdDone";
      this.cmdDone.Size = new System.Drawing.Size(75, 23);
      this.cmdDone.TabIndex = 1;
      this.cmdDone.Text = "Done";
      this.cmdDone.Click += new System.EventHandler(this.cmdDone_Click);
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(16, 16);
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(100, 20);
      this.txtText.TabIndex = 0;
      // 
      // panSecond
      // 
      this.panSecond.BackColor = System.Drawing.SystemColors.ControlLightLight;
      this.panSecond.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.panSecond.Controls.Add(this.dtpDate);
      this.panSecond.Location = new System.Drawing.Point(56, 160);
      this.panSecond.Name = "panSecond";
      this.panSecond.Size = new System.Drawing.Size(288, 128);
      this.panSecond.TabIndex = 3;
      // 
      // dtpDate
      // 
      this.dtpDate.Location = new System.Drawing.Point(48, 48);
      this.dtpDate.Name = "dtpDate";
      this.dtpDate.Size = new System.Drawing.Size(200, 20);
      this.dtpDate.TabIndex = 0;
      // 
      // frmPanel
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(384, 309);
      this.Controls.Add(this.panFirst);
      this.Controls.Add(this.panSecond);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPanel";
      this.Text = "Panel";
      this.panFirst.ResumeLayout(false);
      this.panFirst.PerformLayout();
      this.panSecond.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPanel'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPanel()
      //***
      // Action
      //   - Create instance of 'frmPanel'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPanel()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdDone_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the choosen date in the textbox in the format "yyyy-MM-dd"
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtText.Text = dtpDate.Value.ToString("yyyy-MM-dd");
    }
    // cmdDone_Click(System.Object, System.EventArgs) Handles cmdDone.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPanel
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmPanel()
      // Created
      //   - CopyPaste � 20260717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPanel());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPanel

}
// CopyPaste.Learning