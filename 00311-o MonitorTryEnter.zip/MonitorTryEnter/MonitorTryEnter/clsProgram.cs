﻿//***
// Action
//   - Recognizing the race conditions between threads
//   - This is the Producer and Consumer design pattern (Observer Pattern)
//   - Threads are interfering with each other because the CPU switches, and you have no control
//   - The producer creates something
//   - The consumer uses the thing
//   - There is a change that the consumer comes before the producer, and then you have a problem
//   - And you want to produce the next thing after the previous thing is consumed
//   - The possible problems are here covered with monitoring the threads
// Created
//   - CopyPaste – 20250710 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250710 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Threading;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static bool mblnBufferEmpty = true;
    public static int mlngBuffer;
    public static Object mtheMonitorLock = new Object();
    public static Thread thrConsumer;
    public static Thread thrProducer;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Consumer()
      //***
      // Action
      //   - A value is defined
      //   - An infinite loop is started
      //     - If trying to enter the thread is successful
      //       - If buffer is empty
      //         - Do nothing
      //       - If not
      //         - Buffer is placed in the value
      //         - Content of value is shown in the consumer routine
      //         - Buffer is marked as empty
      //         - Wait a tenth of a second
      //         - Exit the monitor
      //      - If not
      //        - Show a "C" on the screen
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250710 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250710 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - It is very important the have the settings of the buffer correct
      //   - If your first command is switching the setting, the execution of your threads is wrong
      //     - The early swich is put in comment here
      //   - The error is not always, because you have no control on when the switch happens
      //   - The possible error is covered with monitoring the thread
      //***
    {
      int lngValue;

      while (true)
      {

        if (Monitor.TryEnter(mtheMonitorLock))
        {

          if (mblnBufferEmpty)
          {
          }
          else
            // Not mblnBufferEmpty
          {
            // mblnBufferEmpty = true;
            lngValue = mlngBuffer;
            Console.WriteLine("\nConsumer: " + lngValue);
            Thread.Sleep(100);
            mblnBufferEmpty = true;
          }
          // mblnBufferEmpty

          Monitor.Exit(mtheMonitorLock);
        }
        else
          // Not Monitor.TryEnter(mtheMonitorLock)
        {
          Console.Write("C");
        }
        // Monitor.TryEnter(mtheMonitorLock)

      }
      // true

    }
    // Consumer()

    public static void Main()
      //***
      // Action
      //   - Two threads are started.
      //     - The producer creates an object that the consumer uses
      //     - The consumer uses an object that the producer has created
      //   - The goal is that both threads wait on each other
      //     - You can't consume something that is not produced yet
      //     - You can't produce a new thing before the previous is consumed
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Consumer()
      //   - Producer()
      // Created
      //   - CopyPaste – 20250710 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250710 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      thrProducer = new Thread(new ThreadStart(Producer));
      thrConsumer = new Thread(new ThreadStart(Consumer));

      Console.WriteLine("The routine starts");
      thrProducer.Start();
      thrConsumer.Start();

      Console.ReadLine();
    }
		// Main()

    public static void Producer()
      //***
      // Action
      //   - A value is put to zero
      //   - An infinite loop is started
      //     - If trying to enter the thread is successful
      //       - If buffer is empty
      //         - If value is 0
      //           - Value becomes 1
      //         - If not
      //           - Value becomes 0
      //         - Value is placed in the buffer
      //         - Content of buffer is shown in the producer routine
      //         - Buffer is marked as full
      //         - Wait a quarter of a second
      //       - If not
      //         - Do nothing
      //       - Exit the monitor
      //     - If not
      //       - Show a letter "P" on the screen
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250710 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250710 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - It is very important the have the settings of the buffer correct
      //   - If your first command is switching the setting, the execution of your threads is wrong
      //     - The early swich is put in comment here
      //   - The error is not always, because you have no control on when the switch happens
      //   - The possible error is covered with monitoring the thread
      //***
    {
      int lngValue = 0;

      while (true)
      {

        if (Monitor.TryEnter(mtheMonitorLock))
        {

          if (mblnBufferEmpty)
          {
            // mblnBufferEmpty = false;

            if (lngValue == 0)
            {
              lngValue = 1;
            }
            else
              // lngValue <> 0
            {
              lngValue = 0;
            }
            // lngValue = 0

            mlngBuffer = lngValue;
            Console.WriteLine("\nProducer: " + mlngBuffer);
            Thread.Sleep(100);
            mblnBufferEmpty = false;
          }
          else
            // Monitor.TryEnter(mtheMonitorLock)
          {
          }
          // Monitor.TryEnter(mtheMonitorLock)

          Monitor.Exit(mtheMonitorLock);
        }
        else
          // Not mblnBufferEmpty
        {
          Console.Write("P");
        }
        // mblnBufferEmpty

      }
      // true

    }
    // Producer()

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning