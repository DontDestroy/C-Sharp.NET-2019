﻿//***
// Action
//   - Definition of a Customer (linked with customer interface)
//   - This contains (thru the customer component interface)
//     - Customer connection (Connection string)
//     - Customer data adapter
//   - This contains (thru the customer class interface)
//     - Properties
//     - Methods
// Created
//   - CopyPaste – 20050508 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20050508 – VVDW
// Proposal (To Do)
//   -
//***

using Customer;
using System;
using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpCustomer: cmpCustomer, cpiCustomer
  {

    #region "Constructors / Destructors"

    public cpCustomer()
      //***
      // Action
      //   - Create new instance of 'cpCustomer'
      // Called by
      //   - cpCustomer(cpKeyCustomer, string)
      //   - cpCustomer(string)
      //   - frmCustomerValidationBetter()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpCustomer()

    public cpCustomer(string strKeyCustomer) : this()
      //***
      // Action
      //   - Create new instance of 'cpCustomer' with a unique key
      //   - Set an instance of dsCustomer
      //   - Try to
      //     - Set the parameter for the data adapter command (strKeyCustomer)
      //     - Fill the data set using the data adapter
      //     - If there is one record found
      //       - Fill the data row with the found record
      //       - Read the values from the dat row
      //     - If not (there are none)
      //       - Throw the application exception that the customer was not found
      //       - Attention: Thru database constraints it is impossible
      //   - When error occurs
      //     - Throw new application exception that customer row could not be retrieved
      // Called by
      //   - frmCustomerValidationBetter.cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click
      // Calls
      //   - bool ValidateKeyCustomer(string)
      //   - cpCustomer()
      //   - cpInvalidKeyCustomer(string)
      //   - ReadValuesFromDataRow()
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdsCustomer = new dsCustomer();

      try
      {
        base.dtaCustomer.SelectCommand.Parameters["@KeyCustomer"].Value = strKeyCustomer;
        dtaCustomer.Fill(mdsCustomer, "tblCPCustomer");

        if (mdsCustomer.tblCPCustomer.Rows.Count == 1)
        {
          mdrwCustomer = (dsCustomer.tblCPCustomerRow)mdsCustomer.tblCPCustomer.Rows[0];
          ReadValuesFromDataRow();
        }
        else
          // mdsCustomer.tblCPCustomer.Rows.Count <> 1
        {
          throw new ApplicationException("The customer " + strKeyCustomer + " was not found.");
        }
        // mdsCustomer.tblCPCustomer.Rows.Count = 1
      
      }
      catch (Exception theException)
      {
        throw new ApplicationException("The customer row could not be retrieved." + Environment.NewLine + theException.Message);
      }
      finally
      {
      }

    }
    // cpCustomer(string)

    public cpCustomer(cpKeyCustomer theKeyCustomer, string strCompanyName) : this()
      //***
      // Action
      //   - Create new instance of 'cpCustomer' with a unique key and a company name
      //   - If strKeyCustomer already exists
      //     - Set an instance of dsCustomer
      //     - Set boolean new to true
      //     - Set customer Id
      //     - Set Company name to given company name
      //     - All other properties are set to empty string
      //   - Try to
      //     - Set the parameter for the data adapter command (strKeyCustomer)
      //     - Fill the data set using the data adapter
      //     - If there is one record found
      //       - Fill the data row with the found record
      //       - Read the values from the dat row
      //     - If not (there are none)
      //       - Throw the application exception that the customer was not found
      //       - Attention: Thru database constraints it is impossible
      //   - When error occurs
      //     - Throw new application exception that customer row could not be retrieved
      // Called by
      //   - frmCustomerValidationBetter.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      // Calls
      //   - Address(string) (Set)
      //   - bool cpKeyCustomer.Exists(string)
      //   - City(string) (Set)
      //   - CompanyName(string) (Set)
      //   - ContactName(string) (Set)
      //   - ContactTitle(string) (Set)
      //   - Country(string) (Set)
      //   - cpCheckPhoneNumber(string)
      //   - cpCheckString.CheckBeforeUpdate(string, °bool)
      //   - cpCustomer()
      //   - cpInvalidKeyCustomerException(string)
      //   - cpKeyCustomer(cpKeyCustomer)
      //   - cpKeyCustomer cpKeyCustomer.IdCustomer (Get)
      //   - Fax(cpCheckPhoneNumber) (Set)
      //   - Phone(cpCheckPhoneNumber) (Set)
      //   - PostalCode(string) (Set)
      //   - ReadValuesFromDataRow()
      //   - Region(string) (Set)
      //   - string cpKeyCustomer.KeyCustomer (Get)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (theKeyCustomer.Exists(theKeyCustomer.KeyCustomer))
      {
        throw new cpInvalidKeyCustomerException(theKeyCustomer.IdCustomer.KeyCustomer);
      }
      else
        // Not theKeyCustomer.Exists(theKeyCustomer.KeyCustomer)
      {
        mdsCustomer = new dsCustomer();

        mblnNew = true;
        mtheIdCustomer = new cpKeyCustomer(theKeyCustomer);

        CompanyName = strCompanyName;
        ContactName = "";
        ContactTitle = "";
        Address = "";
        City = "";
        Region = "";
        Country = "";
        PostalCode = "";
        Phone = new cpCheckPhoneNumber("");
        Fax = new cpCheckPhoneNumber("");
      }
      // theKeyCustomer.Exists(theKeyCustomer.KeyCustomer)

    }
    // cpCustomer(cpKeyCustomer, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private bool mblnNew;
    private bool mblnValidation;
    private cpCheckPhoneNumber mtheFax;
    private cpCheckPhoneNumber mthePhone;
    private cpKeyCustomer mtheIdCustomer;
    private dsCustomer.tblCPCustomerRow mdrwCustomer;
    private dsCustomer mdsCustomer;
    private string mstrAddress;
    private string mstrCity;
    private string mstrCompanyName;
    private string mstrContactName;
    private string mstrContactTitle;
    private string mstrCountry;
    private string mstrPostalCode;
    private string mstrRegion;

    #endregion

    #region "Properties"

    public string Address
    {

      get
        //***
        // Action Get
        //   - Return 'mstrAddress'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerValidationBetter.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrAddress;
      }
      // string Address (Get)

      set
        //***
        // Action Set
        //   - If Validation is true
        //     - If length of strValue > 60
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrAddress becomes value
        //   - If not
        //     - mstrAddress becomes value
        // Called by
        //   - Clear()
        //   - cpCustomer(cpKeyCustomer, string)
        //   - frmCustomerValidationBetter.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetter.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {
          
          if (value.Length > 60)
          {
            throw new cpInvalidStringLengthException(60, "Address", value);
          }
          else
            // value.Length <= 60
          {
            mstrAddress = value;
          }
          // value.Length > 60

        }
        else
          // Not Validation
        {
          mstrAddress = value;
        }
        // Validation

      }
      // Address(string) (Set)

    }
    // string Address Implements cpiCustomer.Address

    public string City
    {

      get
        //***
        // Action Get
        //   - Return 'mstrCity'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerValidationBetter.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrCity;
      }
      // string City (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 15
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrCity becomes strValue
        //   - If not
        //     - mstrCity becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomer(cpKeyCustomer, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        //   - frmCustomerValidationValidation.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationValidation.TextBoxChange(String, String)
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 15)
          {
            throw new cpInvalidStringLengthException(15, "City", value);
          }
          else
            // value.Length <= 15
          {
            mstrCity = value;
          }
        // strValue.Length > 15
      
        }
        else
          // Not Validation
        {
          mstrCity = value;
        }
        // Validation

      }
      // City(string) (Set)

    }
    // string City Implements cpiCustomer.City

    public string CompanyName
    {

      get
        //***
        // Action Get
        //   - Return 'mstrCompanyName'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerValidationBetter.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrCompanyName;
      }
      // string CompanyName (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 40
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrCompanyName becomes strValue
        //   - If not
        //     - mstrCompanyName becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomer(cpKeyCustomer, String)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        //   - frmCustomerValidationBetter.TextBoxChange(string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 40)
          {
            throw new cpInvalidStringLengthException(40, "CompanyName", value);
          }
          else
            // value.Length <= 40
          {
            mstrCompanyName = value;
          }
          // value.Length > 40
        
        }
        else
          // Not Validation
        {
          mstrCompanyName = value;
        }
        // Validation

      }
      // CompanyName(string) (Set)

    }
    // string CompanyName Implements cpiCustomer.CompanyName

    public string ContactName
    {

      get
        //***
        // Action Get
        //   - Return 'mstrContactName'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerValidationBetter.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrContactName;
      }
      // string ContactName (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 30
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrContactName becomes strValue
        //   - If not
        //     - mstrContactName becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomer(cpKeyCustomer, string)
        //   - frmCustomerValidationBetter.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetter.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {
          
          if (value.Length > 30)
          {
            throw new cpInvalidStringLengthException(30, "ContactName", value);
          }
          else
            // strValue.Length <= 30
          {
            mstrContactName = value;
          }
          // value.Length > 30
        
        }
        else
          // Not Validation
        {
          mstrContactName = value;
        }
        // Validation

      }
      // ContactName(string) (Set)

    }
    // string ContactName Implements cpiCustomer.ContactName

    public string ContactTitle
    {

      get
        //***
        // Action Get
        //   - Return 'mstrContactTitle'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerValidationBetter.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrContactTitle;
      }
      // string ContactTitle (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 30
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrContactTitle becomes strValue
        //   - If not
        //     - mstrContactTitle becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomer(cpKeyCustomer, string)
        //   - frmCustomerValidationBetter.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetter.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 30)
          {
            throw new cpInvalidStringLengthException(30, "ContactTitle", value);
          }
          else
            // value.Length <= 30 
          {
            mstrContactTitle = value;
          }
          // value.Length > 30 
        
        }
        else
          // Not Validation
        {
          mstrContactTitle = value;
        }
        // Validation

      }
      // ContactTitle(string) (Set)

    }
    // string ContactTitle Implements cpiCustomer.ContactTitle

    public string Country
    {

      get
        //***
        // Action Get
        //   - Return 'mstrContry'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerValidationBetter.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrCountry;
      }
      // string Country (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 15
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrCountry becomes strValue
        //   - If not
        //     - mstrCountry becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomer(cpKeyCustomer, string)
        //   - frmCustomerValidationBetter.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetter.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 15)
          {
            throw new cpInvalidStringLengthException(15, "Country", value);
          }
          else
            // value.Length >= 15
          {
            mstrCountry = value;
          }
          // value.Length > 15
        
        }
        else
          // Not Validation
        {
          mstrCountry = value;
        }
        // Validation

      }
      // Country(string) (Set)

    }
    // string Country Implements cpiCustomer.Country

    public cpCheckPhoneNumber Fax
    {

      get
        //***
        // Action Get
        //   - Return 'mtheFax'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerValidationBetter.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mtheFax;
      }
      // cpCheckPhoneNumber Fax (Get)

      set
        //***
        // Action
        //   - mtheFax becomes value
        // Called by
        //   - Clear()
        //   - cpCustomer(cpKeyCustomer, string)
        //   - frmCustomerValidationBetter.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetter.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mtheFax = value;
        mtheFax.StringValueBeforeUpdate += new CopyPaste.Learning.cpCheckString.CheckBeforeUpdate(mtheFax_StringValueBeforeUpdate);
      }
      // Fax(cpCheckPhoneNumber) (Set)

    }
    // cpCheckPhoneNumber Fax Implements cpiCustomer.Fax

    public cpKeyCustomer IdCustomer
    {

      get
        //***
        // Action Get
        //   - Return 'mtheIdCustomer'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - cpCustomer(cpKeyCustomer, String)
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mtheIdCustomer;
      }
      // cpKeyCustomer IdCustomer (Get)

      set
        //***
        // Action Set
        //   - 'mtheIdCustomer' becomes value
        // Called by
        //   - Clear()
        //   - ReadValuesFromDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mtheIdCustomer = value;

        if (value == null)
        {
        }
        else
          // value <> null
        {
          mtheIdCustomer.StringValueBeforeUpdate += new CopyPaste.Learning.cpKeyCustomer.CheckBeforeUpdate(mtheIdCustomer_StringValueBeforeUpdate);
        }
        // value = null
      
      }
      // IdCustomer(cpKeyCustomer) (Set)

    }
    // cpKeyCustomer IdCustomer Implements cpiCustomer.IdCustomer

    public cpCheckPhoneNumber Phone
    {

      get
        //***
        // Action Get
        //   - Return 'mthePhone'
        // Called by
        //   - bool Save() As Boolean Implements cpiCustomer.Save 
        //   - frmCustomerValidationBetter.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
      {
        return mthePhone;
      }
      // cpCheckPhoneNumber Phone (Get)

      set
        //***
        // Action
        //   - mthePhone becomes value
        // Called by
        //   - Clear()
        //   - cpCustomer(cpKeyCustomer, string)
        //   - frmCustomerValidationBetter.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetter.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mthePhone = value;
        mthePhone.StringValueBeforeUpdate += new CopyPaste.Learning.cpCheckString.CheckBeforeUpdate(mthePhone_StringValueBeforeUpdate);
      }
      // Phone(cpCheckPhoneNumber) (Set)

    }
    // cpCheckPhoneNumber Phone Implements cpiCustomer.Phone

    public string PostalCode
      //***
      // Action Get
      //   - Return 'mstrPostalCode'
      // Called by
      //   - bool Save() Implements cpiCustomer.Save 
      //   - frmCustomerValidationBetter.CustomerProperties()
      //   - string ToString() Implements cpiCustomer.ToString
      //   - WriteValuesToDataRow()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      get
      {
        return mstrPostalCode;
      }
      // string PostalCode (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 10
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrPostalCode becomes strValue
        //   - If not
        //     - mstrPostalCode becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomer(cpKeyCustomer, string)
        //   - frmCustomerValidationBetter.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetter.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        
        if (Validation)
        {

          if (value.Length > 10)
          {
            throw new cpInvalidStringLengthException(10, "Postal Code", value);
          }
          else
            // strValue.Length <= 10
          {
            mstrPostalCode = value;
          }
          // value.Length > 10
        
        }
        else
          // Not Validation 
        {
          mstrPostalCode = value;
        }
        // Validation 

      }
      // PostalCode(string) (Set)

    }
    // string PostalCode Implements cpiCustomer.PostalCode

    public string Region
    {

      get
        //***
        // Action Get
        //   - Return 'mstrRegion'
        // Called by
        //   - bool Save() Implements cpiCustomer.Save 
        //   - frmCustomerValidationBetter.CustomerProperties()
        //   - string ToString() Implements cpiCustomer.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrRegion;
      }
      // string Region (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 10
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrRegion becomes strValue
        //   - If not
        //     - mstrRegion becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomer(cpKeyCustomer, string)
        //   - frmCustomerValidationBetter.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetter.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (Validation)
        {

          if (value.Length > 15)
          {
            throw new cpInvalidStringLengthException(15, "Region", value);
          }
          else
            // value.Length <= 15
          {
            mstrRegion = value;
          }
          // value.Length > 15

        }
        else
          // Not Validation
        {
          mstrRegion = value;
        }
        // Validation

      }
      // Region(string) (Set)

    }
    // string Region Implements cpiCustomer.Region

    public bool Validation
    {

      get
        //***
        // Action Get
        //   - Return 'mblnValidation'
        // Called by
        //   - Address(string) (Set)
        //   - City(string) (Set) 
        //   - CompanyName(string) (Set)
        //   - ContactName(string) (Set)
        //   - ContactTitle(string) (Set)
        //   - Country(string) (Set)
        //   - mtheFax_StringValueBeforeUpdate(string, °bool) Handles mtheFax.StringValueBeforeUpdate
        //   - mthePhone_StringValueBeforeUpdate(string, °bool) Handles mthePhone.StringValueBeforeUpdate
        //   - PostalCode(string) (Set)
        //   - Region(string) (Set)
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mblnValidation;
      }
      // bool Validation (Get)

      set
        //***
        // Action
        //   - mblnValidation becomes blnValue
        // Called by
        //   - frmCustomerValidationBetter()
        //   - frmCustomerValidationBetter.cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mblnValidation = value;
      }
      // Validation(bool) (Set)

    }
    // bool Validation

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Create the default return value of a cpCustomer
      // Called by
      //   - frmCustomerValidationBetter.TextBoxChange(string, string)
      // Calls
      //   - cpCheckPhoneNumber Fax (Get)
      //   - cpCheckPhoneNumber Phone (Get)
      //   - cpKeyCustomer IdCustomer (Get)
      //   - string Address (Get)
      //   - string City (Get)
      //   - string CompanyName (Get)
      //   - string ContactName (Get)
      //   - string ContactTitle (Get)
      //   - string Country (Get)
      //   - string cpCheckPhoneNumber.StringValue (Get)
      //   - string cpKeyCustomer.KeyCustomer (Get)
      //   - string PostalCode (Get)
      //   - string Region (Get)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strReturn;

      strReturn = "Key:         " + IdCustomer.KeyCustomer + Environment.NewLine +
        "Company:     " + CompanyName + Environment.NewLine +
        "Contact:     " + ContactName + Environment.NewLine +
        "Title:       " + ContactTitle + Environment.NewLine +
        "Address:     " + Address + Environment.NewLine +
        "City:        " + City + Environment.NewLine +
        "Postal Code: " + PostalCode + Environment.NewLine +
        "Country:     " + Country + Environment.NewLine +
        "Phone:       " + Phone.StringValue + Environment.NewLine +
        "Fax:         " + Fax.StringValue + Environment.NewLine +
        "Region       " + Region + Environment.NewLine;

      return strReturn;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private void mtheFax_StringValueBeforeUpdate(string strFaxNumber, out bool blnCancel)
      //***
      // Action
      //   - If Validation is true
      //     - If length of fax number is larger than 24
      //       - Set cancel to true
      //       - Throw an invalid string length exception with information
      //     - If not
      //       - Set cancel to false
      //   - If not
      //     - Set cancel to false
      // Called by
      //   - 
      // Calls
      //   - bool Validation (Get)
      //   - cpInvalidStringLenghtException(System.Int32, string, string)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (Validation)
      {

        if (strFaxNumber.Length > 24)
        {
          blnCancel = true;
          throw new cpInvalidStringLengthException(24, "Fax", strFaxNumber);
        }
        else
          // strFaxNumber.Length <= 24
        {
          blnCancel = false;
        }
        // strFaxNumber.Length > 24

      }
      else
        // Not Validation
      {
        blnCancel = false;
      }
      // Validation

    }
    // mtheFax_StringValueBeforeUpdate(string, °bool)

    private void mtheIdCustomer_StringValueBeforeUpdate(string strKeyCustomer, out bool blnCancel)
      //***
      // Action
      //   - Set cancel to true
      // Called by
      //   - cpKeyCustomer.StringValueBeforeUpdate(string, °bool)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      blnCancel = true;
    }
    // mtheIdCustomer_BeforeUpdate(string, °bool) Handles mtheIdCustomer.BeforeUpdate

    private void mthePhone_StringValueBeforeUpdate(string strPhoneNumber, out bool blnCancel)
      //***
      // Action
      //   - If Validation is true
      //     - If length of fax number is larger than 24
      //       - Set cancel to true
      //       - Throw an invalid string length exception with information
      //     - If not
      //       - Set cancel to false
      //   - If not
      //     - Set cancel to false
      // Called by
      //   - 
      // Calls
      //   - bool Validation (Get)
      //   - cpInvalidStringLenghtException(System.Int32, string, string)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (Validation)
      {

        if (strPhoneNumber.Length > 24)
        {
          blnCancel = true;
          throw new cpInvalidStringLengthException(24, "Phone", strPhoneNumber);
        }
        else
          // strPhoneNumber.Length <= 24
        {
          blnCancel = false;
        }
        // strPhoneNumber.Length > 24

      }
      else
        // Not Validation
      {
        blnCancel = false;
      }
      // Validation

    }
    // mthePhone_StringValueBeforeUpdate(string, °bool)

    #endregion

    #region "Sub / Function"

    private void Clear()
      //***
      // Action
      //   - Set the data row of the customer to nothing
      //   - Clear the data set of the customer to nothing
      //   - Set the unique key of the customer to nothing
      //   - Clear all properties
      //     - Address
      //     - City
      //     - CompanyName
      //     - ContactName
      //     - ContactTitle
      //     - Country
      //     - Fax
      //     - Phone
      //     - PostalCode
      //     - Region
      // Called by
      //   - bool Delete() Implements cpiCustomer.Delete
      // Calls
      //   - Address(string) (Set)
      //   - City(string) (Set)
      //   - CompanyName(string) (Set)
      //   - ContactName(string) (Set)
      //   - ContactTitle(string) (Set)
      //   - Country(string) (Set)
      //   - Fax(cpCheckPhoneNumber) (Set)
      //   - IdCustomer(cpCheckString) (Set)
      //   - Phone(cpCheckPhoneNumber) (Set)
      //   - PostalCode(string) (Set)
      //   - Region(string) (Set)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdrwCustomer = null;
      mdsCustomer = null;
      IdCustomer = null;
      Address = null;
      City = null;
      CompanyName = null;
      ContactName = null;
      ContactTitle = null;
      Country = null;
      Fax = null;
      Phone = null;
      PostalCode = null;
      Region = null;
    }
    // Clear()

    public bool Delete()
      //***
      // Action
      //   - Define a result value
      //   - If you are busy adding a new customer
      //     - Clear the information
      //     - Set return value to true
      //   - If not
      //     - Delete the data row of the customer
      //     - Write the changes to the database
      //     - If successful
      //       - Clear the information
      //       - Set return value to true
      //     - If not
      //       - Reject the changes of the customer data row
      //       - Set return value to false
      //   - Return result
      // Called by
      //   - frmCustomerValidationBetter.cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click
      // Calls
      //   - bool WriteChangesToDatabase(DataRowState)
      //   - Clear()
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnReturn;

      if (mblnNew)
      {
        Clear();
        blnReturn = true;
      }
      else
        // Not mblnNew
      {
        mdrwCustomer.Delete();

        if (WriteChangesToDatabase(DataRowState.Deleted))
        {
          Validation = false;
          Clear();
          blnReturn = true;
        }
        else
          // Not WriteChangesToDatabase(DataRowState.Deleted)
        {
          mdrwCustomer.RejectChanges();
          blnReturn = false;
        }
        // WriteChangesToDatabase(DataRowState.Deleted)

      }
      // mblnNew

      return blnReturn;
    }
    // bool Delete() Implements cpiCustomer.Delete

    private void ReadValuesFromDataRow()
      //***
      // Action
      //   - Set values from Customer Data Row into cpCustomer
      //   - mstrIdCustomer becomse strIdCustomer
      //   - CompanyName becomes strCompanyName
      //   - Do routine for strAddress, strCity, strContactName, strContactTitle,
      //     - strCountry, strFax, strPhone, strPostalCode, strRegion)
      //   - Routine:
      //     - If strXxx Is null Then
      //       - Property becomes empty string
      //     - If not
      //       - Property becomes strXxx
      // Called by
      //   - New(String)
      // Calls
      //   - Address(string) (Set)
      //   - City(string) (Set)
      //   - CompanyName(string) (Set)
      //   - ContactName(string) (Set)
      //   - ContactTitle(string) (Set)
      //   - Country(string) (Set)
      //   - cpCheckPhoneNumber(string)
      //   - cpCheckString.StringValue(string) (Set)
      //   - cpKeyCustomer(string)
      //   - cpKeyCustomer.KeyCustomer(string) (Set)
      //   - Fax(cpCheckPhoneNumber) (Set)
      //   - Phone(cpCheckPhoneNumber) (Set)
      //   - PostalCode(string) (Set)
      //   - Region(string) (Set)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      IdCustomer = new cpKeyCustomer(mdrwCustomer.strIdCustomer);
      mtheIdCustomer.KeyCustomer = mdrwCustomer.strIdCustomer;
      CompanyName = mdrwCustomer.strCompanyName;

      if (mdrwCustomer.IsstrPhoneNull())
      {
        Phone = new cpCheckPhoneNumber("");
      }
      else
        // Not mdrwCustomer.IsstrPhoneNull()
      {
        Phone = new cpCheckPhoneNumber(mdrwCustomer.strPhone);
      }
      // mdrwCustomer.IsstrPhoneNull()

      if (mdrwCustomer.IsstrFaxNull())
      {
        Fax = new cpCheckPhoneNumber("");
      }
      else
        // Not mdrwCustomer.IsstrFaxNull()
      {
        Fax = new cpCheckPhoneNumber(mdrwCustomer.strFax);
      }
      // mdrwCustomer.IsstrFaxNull()

      if (mdrwCustomer.IsstrAddressNull())
      {
        Address = "";
      }
      else
        // Not mdrwCustomer.IsstrAddressNull()
      {
        Address = mdrwCustomer.strAddress;
      }
      // mdrwCustomer.IsstrAddressNull()

      if (mdrwCustomer.IsstrCityNull())
      {
        City = "";
      }
      else
        // Not mdrwCustomer.IsstrCityNull()
      {
        City = mdrwCustomer.strCity;
      }
      // mdrwCustomer.IsstrCityNull()

      if (mdrwCustomer.IsstrContactNameNull())
      {
        ContactName = "";
      }
      else
        // Not mdrwCustomer.IsstrContactNameNull() 
      {
        ContactName = mdrwCustomer.strContactName;
      }
        // mdrwCustomer.IsstrContactNameNull() 

      if (mdrwCustomer.IsstrContactTitleNull())
      {
        ContactTitle = "";
      }
      else
        // Not mdrwCustomer.IsstrContactTitleNull() 
      {
        ContactTitle = mdrwCustomer.strContactTitle;
      }
      // mdrwCustomer.IsstrContactTitleNull() 

      if (mdrwCustomer.IsstrCountryNull())
      {
        Country = "";
      }
      else
        // Not mdrwCustomer.IsstrCountryNull() 
      {
        Country = mdrwCustomer.strCountry;
      }
      // mdrwCustomer.IsstrCountryNull() 

      if (mdrwCustomer.IsstrFaxNull())
      {
        mtheFax.StringValue = "";
      }
      else
        // Not mdrwCustomer.IsstrFaxNull() 
      {
        mtheFax.StringValue = mdrwCustomer.strFax;
      }
        // mdrwCustomer.IsstrFaxNull() 

      if (mdrwCustomer.IsstrPhoneNull())
      {
        mthePhone.StringValue = "";
      }
      else
        // Not mdrwCustomer.IsstrPhoneNull() 
      {
        mthePhone.StringValue = mdrwCustomer.strPhone;
      }
        // mdrwCustomer.IsstrPhoneNull() 

      if (mdrwCustomer.IsstrPostalCodeNull())
      {
        PostalCode = "";
      }
      else
        // Not mdrwCustomer.IsstrPostalCodeNull()
      {
        PostalCode = mdrwCustomer.strPostalCode;
      }
      // mdrwCustomer.IsstrPostalCodeNull() 

      if (mdrwCustomer.IsstrRegionNull())
      {
        Region = "";
      }
      else
        // Not mdrwCustomer.IsstrRegionNull() 
      {
        Region = mdrwCustomer.strRegion;
      }
      // mdrwCustomer.IsstrRegionNull() 

    }
    // ReadValuesFromDataRow()

    public bool Save()
      //***
      // Action
      //   - Define a row state
      //   - If blnNew
      //     - Set the data row of customer an added row to the data set
      //     - Put the state to added
      //     - Set blnNew to false
      //   - If not
      //     - Set the state to modified
      //   - Try to
      //     - Start editing the data row
      //     - Write the values to the data row
      //     - Stop editing the data row
      //     - Write the changes to the data base
      //     - If successful
      //       - Set return value to true
      //     - If not
      //       - Reject the changes of the data row
      //       - Set return value to false
      //   - When error occurs
      //     - Cancel editing the data row
      //     - Reject the changes of the data row
      //     - Set return value to false
      //   - Return result
      // Called by
      //   - frmCustomerValidationBetter.cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      //   - WriteChangesToDatabase(DataRowState)
      //   - WriteValuesToDataRow()
      // Calls
      //   - cpCheckPhoneNumber Fax (Get)
      //   - cpCheckPhoneNumber Phone (Get)
      //   - cpKeyCustomer IdCustomer (Get)
      //   - string Address (Get)
      //   - string City (Get)
      //   - string CompanyName (Get)
      //   - string ContactName (Get)
      //   - string ContactTitle (Get)
      //   - string Country (Get)
      //   - string cpCheckString.StringValue (Get)
      //   - string PostalCode (Get)
      //   - string Region (Get)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnResult;
      DataRowState theDataRowState;
      
      if (mblnNew)
      {
        mdrwCustomer = mdsCustomer.tblCPCustomer.AddtblCPCustomerRow( 
          IdCustomer.KeyCustomer, CompanyName, ContactName, ContactTitle, Address, City, 
          Region, PostalCode, Country, Phone.StringValue, Fax.StringValue);

        theDataRowState = DataRowState.Added;
        mblnNew = false;
      }
      else
        // Not mblnNew 
      {
        theDataRowState = DataRowState.Modified;
      }
      // mblnNew 

      try
      {
        mdrwCustomer.BeginEdit();
        WriteValuesToDataRow();
        mdrwCustomer.EndEdit();
      }
      catch (Exception theException)
      {
        mdrwCustomer.CancelEdit();
        mdrwCustomer.RejectChanges();
        blnResult = false;
      }
      finally
      {
      }

      if (WriteChangesToDatabase(theDataRowState))
      {
        blnResult = true;
      }
      else
        // Not WriteChangesToDatabase(theDataRowState) 
      {
        mdrwCustomer.RejectChanges();
        blnResult = false;
      }
      // WriteChangesToDatabase(theDataRowState) 

      return blnResult;
    }
    // bool Save() Implements cpiCustomer.Save

    private bool WriteChangesToDatabase(DataRowState theDataRowState)
      //'***
      //' Action
      //'   - Define a return value
      //'   - Try to
      //'     - Define and set a dataset with the changes of the customer data set
      //'     - Update the changes using the data adapter
      //'     - Accept the changes of the customer data set
      //'     - Return value becomes true
      //'   - When error occurs
      //'     - Reject the changes of the customer data set
      //'     - Return value becomes false
      //' Called by
      //'   - bool Delete() Implements cpiCustomer.Delete
      //'   - bool Save() Implements cpiCustomer.Save
      //' Calls
      //'   - 
      //' Created
      //'   - CopyPaste – 20050508 – VVDW
      //' Changed
      //'   - CopyPaste – yyyymmdd – VVDW – What changed
      //' Tested
      //'   - CopyPaste – 20050508 – VVDW
      //' Keyboard key
      //'   -
      //' Proposal (To Do)
      //'   -
      //'***
    {
      bool blnReturn;

      try
      {
        DataSet dsChanges = mdsCustomer.GetChanges(theDataRowState);

        dtaCustomer.Update(dsChanges);
        mdsCustomer.AcceptChanges();
        blnReturn = true;
      }
      catch (Exception theException)
      {
        mdsCustomer.RejectChanges();
        blnReturn = false;
      }
      finally
      {
      }

      return blnReturn;
    }
    // WriteChangesToDatabase(DataRowState)

    private void WriteValuesToDataRow()
      //***
      // Action
      //   - Write property values from instance to data row
      //     - strCompanyName becomes CompanyName 
      //   - Do routine for Address, City, ContactName, ContactTitle,
      //     - Country, Fax, Phone, PostalCode, Region)
      //   - Routine:
      //   - If Xxx.Length = 0 Then
      //     - Property becomes null
      //   - If not
      //     - Property becomes Xxx
      // Called by
      //   - bool Save() Implements cpiCustomer.Save
      // Calls
      //   - cpCheckPhoneNumber Fax (Get)
      //   - cpCheckPhoneNumber Phone (Get)
      //   - string Address (Get)
      //   - string City (Get)
      //   - string CompanyName (Get)
      //   - string ContactName (Get)
      //   - string ContactTitle (Get)
      //   - string Country (Get)
      //   - string cpCheckPhoneNumber.StringValue (Get)
      //   - string PostalCode (Get)
      //   - string Region (Get)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdrwCustomer.strCompanyName = CompanyName;

      if (Address.Length == 0)
      {
        mdrwCustomer.SetstrAddressNull();
      }
      else
        // Address.Length <> 0
      {
        mdrwCustomer.strAddress = Address;
      }
      // Address.Length = 0

      if (City.Length == 0)
      {
        mdrwCustomer.SetstrCityNull();
      }
      else
        // City.Length <> 0
      {
        mdrwCustomer.strCity = City;
      }
      // City.Length = 0

      if (ContactName.Length == 0)
      {
        mdrwCustomer.SetstrContactNameNull();
      }
      else
        // ContactName.Length <> 0
      {
        mdrwCustomer.strContactName = ContactName;
      }
      // ContactName.Length = 0

      if (ContactTitle.Length == 0)
      {
        mdrwCustomer.SetstrContactTitleNull();
      }
      else
        // ContactTitle.Length <> 0
      {
        mdrwCustomer.strContactTitle = ContactTitle;
      }
      // ContactTitle.Length = 0

      if (Country.Length == 0)
      {
        mdrwCustomer.SetstrCountryNull();
      }
      else
        // Country.Length <> 0
      {
        mdrwCustomer.strCountry = Country;
      }
        // Country.Length = 0

      if (Fax.StringValue.Length == 0)
      {
        mdrwCustomer.SetstrFaxNull();
      }
      else
        // Fax.StringValue.Length <> 0
      {
        mdrwCustomer.strFax = Fax.StringValue;
      }
      // Fax.StringValue.Length = 0

      if (Phone.StringValue.Length == 0)
      {
        mdrwCustomer.SetstrPhoneNull();
      }
      else
        // Phone.StringValue.Length <> 0
      {
        mdrwCustomer.strPhone = Phone.StringValue;
      }
        // Phone.StringValue.Length = 0

      if (PostalCode.Length == 0)
      {
        mdrwCustomer.SetstrPostalCodeNull();
      }
      else
        // PostalCode.Length <> 0
      {
        mdrwCustomer.strPostalCode = PostalCode;
      }
      // PostalCode.Length = 0

      if (Region.Length == 0)
      {
        mdrwCustomer.SetstrRegionNull();
      }
      else
        // Region.Length <> 0
      {
        mdrwCustomer.strRegion = Region;
      }
      // Region.Length = 0

    }
    // WriteValuesToDataRow()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCustomer

}
// CopyPaste.Learning