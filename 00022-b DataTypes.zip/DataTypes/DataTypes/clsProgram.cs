//***
// Action
//   - Some actions on the default data type methods
//     - Equals, GetType, GetHashCode
// Created
//   - CopyPaste � 20240415 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240415 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Start 2 testroutines
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Test1()
      //   - Test2()
      // Created
      //   - CopyPaste � 20240415 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240415 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Test1();
      Test2();
    }
    // Main()

    private static void Test1()
      //***
      // Action
      //   - Create 2 collections (ArrayList)
      //   - Create 2 integers with value 12
      //   - Compare the 2 integers
      //   - Compare the 2 collections
      //   - First collection becomes second collection
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240415 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240415 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      ArrayList colFirst = new ArrayList();
      ArrayList colSecond = new ArrayList();
      int lngFirst = 12;
      int lngSecond = 12;

      MessageBox.Show("lngFirst = lngSecond : " + lngFirst.Equals(lngSecond).ToString(), "Copy Paste");
      MessageBox.Show("colFirst = colSecond : " + colFirst.Equals(colSecond).ToString(), "Copy Paste");
      colFirst = colSecond;
      MessageBox.Show("colFirst = colSecond : " + colFirst.Equals(colSecond).ToString(), "Copy Paste");
    }
    // Test1()

    private static void Test2()
      //***
      // Action
      //   - Create 2 objects
      //   - First object gets a text
      //   - Second object gets a number
      //   - Show the 2 types
      //   - Show the 2 hascodes
      //   - Show if they are equal
      //   - The first object becomes the second object
      //   - Show the 2 types
      //   - Show the 2 hascodes
      //   - Show if they are equal
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240415 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240415 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      System.Object theObjectFirst;
      System.Object theObjectSecond;

      theObjectFirst = "Hello C# .NET";
      theObjectSecond = 42;

      MessageBox.Show("Type First Object : " + theObjectFirst.GetType().ToString() + Environment.NewLine + "Type Second Object : " + theObjectSecond.GetType().ToString());
      MessageBox.Show("HashCode First Object : " + theObjectFirst.GetHashCode().ToString() + Environment.NewLine + "HashCode Second Object : " + theObjectSecond.GetHashCode().ToString());
      MessageBox.Show("Equal = " + theObjectFirst.Equals(theObjectSecond).ToString());
      theObjectFirst = theObjectSecond;
      MessageBox.Show("Type First Object : " + theObjectFirst.GetType().ToString() + Environment.NewLine + "Type Second Object : " + theObjectSecond.GetType().ToString());
      MessageBox.Show("HashCode First Object : " + theObjectFirst.GetHashCode().ToString() + Environment.NewLine + "HashCode Second Object : " + theObjectSecond.GetHashCode().ToString());
      MessageBox.Show("Equal = " + theObjectFirst.Equals(theObjectSecond).ToString());
    }
    // Test2()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning