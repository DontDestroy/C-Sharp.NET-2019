//***
// Action
//   - Define a hardcoded connection string
// Created
//   - CopyPaste � 20260114 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260114 � VVDW
// Proposal (To Do)
//   -
//***

using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpGeneralRoutines
  {

    #region "Constructors / Destructors"

    public cpGeneralRoutines()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - bool frmTable.PerformTask(string)
      //   - frmNotCorresponding.frmNotCorresponding_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmSubQueries.frmSubQueries_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmTableData.cmdExecute_Click(System.Object, System.EventArgs) Handles cmdExecute.Click
      //   - frmUniqueRecord.GenerateData(bool)
      //   - frmUserDefinedFunction.cmdCreateUDF_Click(System.Object, System.EventArgs) Handles cmdCreateUDF.Click
      //   - frmUserDefinedFunction.GenerateData()
      //   - frmVariables.frmVariables_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmWildcards.GenerateData()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpGeneralRoutines()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string BuildConnectionString()
      //***
      // Action
      //   - Return a hardcoded connection string
      // Called by
      //   - frmNotCorresponding.frmNotCorresponding_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmSubQueries.frmSubQueries_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmUniqueRecord.GenerateData(bool)
      //   - frmVariables.frmVariables_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmWildcards.GenerateData()
      //   - SqlClient.SqlConnection GetConnection() 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integrated Security=True";
    }
    // string BuildConnectionString()

    public SqlConnection GetConnection()
      //***
      // Action
      //   - Create a new SQL connection
      //   - Assign the connection string to it
      //   - Return the connection
      // Called by
      //   - bool frmTable.PerformTask(string)
      //   - frmNotCorresponding.frmNotCorresponding_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmSubQueries.frmSubQueries_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmTableData.cmdExecute_Click(System.Object, System.EventArgs) Handles cmdExecute.Click
      //   - frmUniqueRecord.GenerateData(bool)
      //   - frmUserDefinedFunction.cmdCreateUDF_Click(System.Object, System.EventArgs) Handles cmdCreateUDF.Click
      //   - frmUserDefinedFunction.GenerateData()
      //   - frmVariables.frmVariables_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmWildcards.GenerateData()
      // Calls
      //   - string BuildConnectionString()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      SqlConnection theConnection = new SqlConnection();

      theConnection.ConnectionString = BuildConnectionString();
      return theConnection;
    }
    // SqlClient.SqlConnection GetConnection()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpGeneralRoutines

}
// CopyPaste.Learning