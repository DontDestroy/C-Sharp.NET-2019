﻿//***
// Action
//   - Implementation of a cpMessageMorseBySound
//		 - The way a Morse code is send by sound (beeps)
// Created
//   - CopyPaste – 20241227 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20241227 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.MorseCode.Library
{

	public class cpMorseBySound : cpiMessageMorse
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpMorseBySound
		/// </summary>
		public cpMorseBySound()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - CopyPaste.MorseCode.frmMorseCode.cmdSend_Click(System.Object, EventArgs) Handles cmdSend.Click
		//   - CopyPaste.MorseCode.Test.cpProgram()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20241227 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20241227 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpMorseBySound()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private int intHertzSound = 800;

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		///  Define how a message is send by sound
		/// </summary>
		/// <param name="lstMessage"></param>
		/// <returns>A list of cpSignalItem</returns>
		public void SendMessage(List<cpSignalItem> lstMessage)
		//***
		// Action
		//   - Define how a list of signal items is send in Morse (by sound)
		//   - Loop for all the signals
		//     - If there is a signal
		//       - Play a sound of 800 hertz for a specific length
		//     - If not
		//       - Wait a specific length
		// Called by
		//   - cpMorse() (indirectly, thru delegates)
		// Calls
		//   - int cpSignalItem.Length (Get)
		//   - string cpSignalItem.Signal (Get)
		// Created
		//   - CopyPaste – 20241227 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20241227 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Message of {0} items is send by sound", lstMessage.Count);

			foreach (cpSignalItem theSignalItem in lstMessage)
			{
				Debug.Print("Send {0} for {1} milliseconds by sound", theSignalItem.Signal, theSignalItem.Length);

				if (theSignalItem.Signal)
				{
					Console.Beep(intHertzSound, theSignalItem.Length);
				}
				// Not theSignalItem.Signal
				else
				{
					Thread.Sleep(theSignalItem.Length);
				}
				// theSignalItem.Signal

			}
			// in lstMessage

		}
		// List<cpSignalItem> SendMessage(string)

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpMorseBySound

}
// CopyPaste.MorseCode.Library