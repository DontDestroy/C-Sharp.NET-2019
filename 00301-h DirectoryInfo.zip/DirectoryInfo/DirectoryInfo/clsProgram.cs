//***
// Action
//   - Showing some information about a directory
// Created
//   - CopyPaste � 20240722 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240722 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define a directory info
      //   - Set the info about "C:\"
      //   - Define a file info
      //   - Define an array of directory infos of "C:\"
      //   - Define an array of file infos of "C:\"
      //   - For every file in array of file infos
      //     - Try to
      //       - Show full name, length and last access time
      //     - On error
      //       - Show an error
      //   - For every directory in array of directory infos
      //     - Try to
      //       - Show full name, number of files and number of directories
      //     - On error
      //       - Show an error
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240722 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      DirectoryInfo theDirectoryInfo;

      theDirectoryInfo = new DirectoryInfo("C:\\");

      DirectoryInfo[] arrDirectory = theDirectoryInfo.GetDirectories("*.*");
      FileInfo[] arrFile = theDirectoryInfo.GetFiles("*.*");

      Console.WriteLine("Root Files");
      Console.WriteLine("----------");

      foreach (FileInfo theFile in arrFile)
      {

        try
        {
          Console.Write(theFile.FullName);
          Console.Write(" Size: {0} bytes", theFile.Length);
          Console.WriteLine(" Last use: {0}", theFile.LastAccessTime);
        }
        catch
        {
          Console.WriteLine("*** Error accessing ***");
        }
        finally
        {
        }

      }
      // in arrFiles

      Console.WriteLine();
      Console.WriteLine("Root Directories");
      Console.WriteLine("----------------");

      foreach (DirectoryInfo theDirectory in arrDirectory)
      {

        try
        {
          Console.Write(theDirectory.FullName);
          Console.Write(" contains {0} files ", theDirectory.GetFiles().Length);
          Console.WriteLine("and {0} subdirectories ", theDirectory.GetDirectories().Length);
        }
        catch
        {
          Console.WriteLine("*** Error accessing ***");
        }
        finally
        {
        }

      }
      // In arrDirectory

      Console.WriteLine("Press Enter to Continue ...");
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx