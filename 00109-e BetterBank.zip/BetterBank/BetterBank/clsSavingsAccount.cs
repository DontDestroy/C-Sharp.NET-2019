//***
// Action
//   - Implementation of cpSavingsAccount
//   - This is a bankAccount, but you can add an interest on it
// Created
//   - CopyPaste � 20240227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240227 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;

namespace CopyPaste.Learning
{

  public class cpSavingsAccount : cpBankAccount
  {

    #region "Constructors / Destructors"

    public cpSavingsAccount(string strOwner) : base()
      //***
      // Action
      //   - Constructor of a cpSavingsAccount that defines an owner
      // Called by
      //   - frmBetterBank()
      // Calls
      //   - cpBankAccount()
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mstrOwner = strOwner;
    }
    // cpCheckingAccount(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private decimal mdecInterest = 0.03M;
    private decimal mdecTotalInterest = 0M;
    private string mstrOwner;

    #endregion

    #region "Properties"

    public override string Id
    {
      
      get
        //***
        // Action Get
        //   - Returns the Id (owner) with a "-S" added at the end
        // Called by
        //   - frmBetterBank.cmdAddInterest_Click(System.Object, System.EventArgs) Handles cmdAddInterest.Click
        //   - PrintStatement() As String
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240227 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240227 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrOwner + "-S";
      }
      // string Id (Get)

    }
    // string Id

    public decimal Interest
    {

      get
        //***
        // Action Get
        //   - Returns the Interest of a cpSavingsAccount
        // Called by
        //   - decimal AddInterest()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240227 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240227 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecInterest;
      }
      // decimal Interest (Get)

      set
        //***
        // Action Set
        //   - Set the Interest of a cpSavingsAccount to value
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240227 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240227 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mdecInterest = value;
      }
      // Interest(decimal) (Set)

    }
    // decimal Interest

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string PrintStatement()
      //***
      // Action
      //   - Define an array of 6 values (calculated or not)
      //     - An enter, the owner, the total deposits, the total withdrawals
      //     - the total of interest, the balance
      //   - Define a message
      //   - Format the message using the 6 values of the array
      //   - Return the message
      // Called by
      //   - 
      // Calls
      //   - decimal cpBankAccount.Balance (Get)
      //   - decimal cpBankAccount.TotalDeposits (Get)
      //   - decimal cpBankAccount.TotalWithDrawals (Get)
      //   - string Id (Get)
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      

      Object[] objInformation =
        {Environment.NewLine, 
         Id, 
         TotalDeposits - mdecTotalInterest, 
         TotalWithDrawals, 
         mdecTotalInterest, 
         Balance};

      string strMessage;

      strMessage = string.Format("{1}{0}" +
          "Opening balance:�0.00{0}" +
          "Deposits: {2:C}{0}" +
          "WithDrawals: {3:C}{0}" +
          "Interest: {4:C}{0}" +
          "Ending balance: {5:C}{0}",
        objInformation);

      return strMessage;
    }
    // string PrintStatement()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public decimal AddInterest()
      //***
      // Action
      //   - A certain amount (Balance * Interest) is added to the balance of the cpSavingsAccount
      // Called by
      //   - frmBetterBank.cmdAddInterest_Click(System.Object, System.EventArgs) Handles cmdAddInterest.Click
      // Calls
      //   - decimal cpBankAccount.Balance (Get)
      //   - decimal cpBankAccount.Deposit(decimal)
      //   - decimal Interest (Get)
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      decimal decBalance;
      decimal decInterestAmount = Interest * Balance;

      mdecTotalInterest += decInterestAmount;
      decBalance = Deposit(decInterestAmount);

      return Balance;
    }
    // decimal AddInterest()
    
    #endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCheckingAccount

}
// CopyPaste.Learning