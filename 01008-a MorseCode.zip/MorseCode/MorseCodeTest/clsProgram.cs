﻿//***
// Action
//   - Testroutine for cpMorse, cpSignalItem, cpMorseByLight, cpMorseByOutputWindow, cpMorseBySound, cpiMessageMorse
// Created
//   - CopyPaste – 20241227 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20241227 – VVDW
// Proposal (To Do)
//   - clsiMessageMorse
//   - clsMorseByLight
//   - clsMorseByOutputWindow
//   - clsMorseBySound
//   - clsMorse
//***

using CopyPaste.MorseCode.Library;
using System.Diagnostics;

namespace CopyPaste.MorseCode.Test
{

	internal static class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		///  The main entry point for the test application
		/// </summary>
		public static void Main()
		//***
		// Action
		//   - Start application
		//   - Create an instance of cpMorse with speed 250 milliseconds
		//   - Show some info about cpMorse instance
		//   - Change the speed into 500 milliseconds
		//   - Show some info about cpMorse instance
		//   - Create an instance of cpSignalItem
		//   - Show some info about cpSignalItem instance
		//   - Create an instance of cpSignalItem
		//   - Show some info about cpSignalItem instance
		//   - Add the 2 instances of cpSignalItem to the cpMorse signal
		//   - Send the message
		//   - Loop thru the ways the signal is send (this put in comment)
		//		 - Light, Sound and back to Output Window
		//     - Send the message
		//   - Set the speed to 250
		//   - Set the message to "SOS"
		//   - Set the way the message is send to sound
		//     - Send the message
		//   - Wait for the user to hit the keyboard
		// Called by
		//   - User action (Starting the application)
		// Calls
		//   - bool CopPaste.MorseCode.Library.cpSignalItem.Signal (Get)
		//   - CopPaste.MorseCode.Library.cpMorse()
		//   - CopPaste.MorseCode.Library.cpMorse(int)
		//   - CopPaste.MorseCode.Library.cpMorse.Add(cpSignalItem)
		//   - CopPaste.MorseCode.Library.cpMorse.CleanBehaviour()
		//   - CopPaste.MorseCode.Library.cpMorse.Message (Get)
		//   - CopPaste.MorseCode.Library.cpMorse.SendMessage()
		//   - CopPaste.MorseCode.Library.cpMorse.Speed(int) (Set)
		//   - CopPaste.MorseCode.Library.cpMorseByOutputWindow(int)
		//   - CopPaste.MorseCode.Library.cpMorseByLight(PictureBox)
		//   - CopPaste.MorseCode.Library.cpMorseBySound()
		//   - CopPaste.MorseCode.Library.cpSignalItem(bool, int)
		//   - CopPaste.MorseCode.Library.cpSignalItem.Length(int) (Set)
		//   - CopPaste.MorseCode.Library.cpSignalItem.Signal(bool) (Set)
		//   - int CopPaste.MorseCode.Library.cpMorse.Speed (Get)
		//   - int CopPaste.MorseCode.Library.cpSignalItem.Length (Get)
		// Created
		//   - CopyPaste – 20241227 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20241227 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			cpMorse thecpMorse = new cpMorse(250);
			cpSignalItem theSignal01 = new cpSignalItem(true, 500);
			cpSignalItem theSignal02 = new cpSignalItem(true, 1000);

			Debug.Print("Showing some info of cpMorse");
			Debug.Print("The speed is {0}", thecpMorse.Speed);
			Debug.Print("");

			thecpMorse.Speed = 500;

			Debug.Print("Showing some changed info of cpMorse");
			Debug.Print("The speed is {0}", thecpMorse.Speed);
			Debug.Print("");

			Debug.Print("Showing some info of a cpSignal");
			Debug.Print("The signal is {0} for {1}", theSignal01.Signal, theSignal01.Length);
			Debug.Print("");

			theSignal02.Signal = false;
			theSignal02.Length = 2000;

			Debug.Print("Showing some changed info of a cpSignal");
			Debug.Print("The signal is {0} for {1}", theSignal02.Signal, theSignal02.Length);
			Debug.Print("");

  		Debug.Print("Executing the behaviour of cpMorse");

			// Add 2 signals and send the message (immediate / output window)
			thecpMorse.Add(theSignal01);
			thecpMorse.Add(theSignal02);
			thecpMorse.SendMessage();
			Debug.Print("");

			//// Change the behaviour, send the message (light)
			//thecpMorse.CleanBehaviour();
			//thecpMorse.HowToSendMessage = new cpMorseByLight(aPicturebox);
			//// this will only work in a windows form where there is a picturebox
			//thecpMorse.SendMessage();
			//Debug.Print("");

			//// Change the behaviour, send the message (sound)
			//thecpMorse.CleanBehaviour();
			//thecpMorse.HowToSendMessage = new cpMorseBySound();
			//thecpMorse.SendMessage();
			//Debug.Print("");

			//// Change the behaviour, send the message (immediate / output window)
			//thecpMorse.CleanBehaviour();
			//thecpMorse.HowToSendMessage = new cpMorseByOutputWindow(thecpMorse.Speed);
			//thecpMorse.SendMessage();
			//Debug.Print("");

			// Change the behaviour, set a message, send the message (sound)
			thecpMorse.Speed = 250;
			thecpMorse.CleanBehaviour();
			thecpMorse.Message = "SOS";
			thecpMorse.HowToSendMessage = new cpMorseBySound();
			thecpMorse.SendMessage();
			Debug.Print("");

			Console.WriteLine("Information about the execution of methods can be found in the immediate / output window");
			Console.WriteLine();
			Console.WriteLine("Hit any key to exit the program ...");
			Console.ReadLine();
		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#Region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.MorseCode.Test