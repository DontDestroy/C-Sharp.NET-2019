//***
// Action
//   - Example of the use of subroutines with parameters
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Parameter
{

  class cpParameter
	{

    static void Main()
    //***
    // Action
    //   - Write info at the console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine()
    //   - System.Console.WriteLine(string)
    //   - TextCharacterLine(string, char)
    //   - TextLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      TextLine("Main menu");
      Console.WriteLine("1. From cm to inch.");
      TextLine("2. From inch to cm.");
      Console.WriteLine();
      TextCharacterLine("Make your choice:", '~');
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

    static void TextCharacterLine(string strText, char chrCharacter)
    //***
    // Action
    //   - Write 'strText' at console screen
    //   - Write a line of the same length with 'chrCharacter'
    // Called by
    //   - Main()
    // Calls
    //   - int System.String.Length() (non-shared)
    //   - System.Console.Write("-")
    //   - System.Console.WriteLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter;
      
      Console.WriteLine(strText);

      for (lngCounter = 1; lngCounter <= strText.Length; lngCounter++)
      {
        Console.Write(chrCharacter);
      }
      // lngCounter = strText.Length + 1

      Console.WriteLine();
    }
    // TextLine(string, char)

    static void TextLine(string strText)
    //***
    // Action
    //   - Write 'strText' at console screen
    //   - Write a line of the same length
    // Called by
    //   - Main()
    // Calls
    //   - int System.String.Length() (non-shared)
    //   - System.Console.Write("-")
    //   - System.Console.WriteLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter;

      Console.WriteLine(strText);

      for (lngCounter = 1; lngCounter <= strText.Length; lngCounter++)
      {
        Console.Write('-');
      }
      // lngCounter = strText.Length + 1
      
      Console.WriteLine();
    }
    // TextLine(string)

	}
  // cpParameter

}
// Parameter