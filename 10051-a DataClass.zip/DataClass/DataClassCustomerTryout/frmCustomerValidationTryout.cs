//***
// Action
//   - Update a customer with validation
//   - Retrieved with a given key
// Created
//   - CopyPaste � 20260117 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260117 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmCustomerValidationTryout: ifrmCustomerTryout
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCustomerValidationTryout));
      // 
      // cmdNew
      // 
      this.cmdNew.Enabled = true;
      this.cmdNew.Name = "cmdNew";
      this.cmdNew.Click += new System.EventHandler(this.cmdNew_Click);
      // 
      // cmdDelete
      // 
      this.cmdDelete.Enabled = true;
      this.cmdDelete.Name = "cmdDelete";
      this.cmdDelete.Click += new System.EventHandler(this.cmdDelete_Click);
      // 
      // cmdSave
      // 
      this.cmdSave.Enabled = true;
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // cmdRetrieve
      // 
      this.cmdRetrieve.Enabled = true;
      this.cmdRetrieve.Name = "cmdRetrieve";
      this.cmdRetrieve.Click += new System.EventHandler(this.cmdRetrieve_Click);
      // 
      // txtFax
      // 
      this.txtFax.Name = "txtFax";
      // 
      // txtPhone
      // 
      this.txtPhone.Name = "txtPhone";
      // 
      // txtRegion
      // 
      this.txtRegion.Name = "txtRegion";
      // 
      // txtCountry
      // 
      this.txtCountry.Name = "txtCountry";
      // 
      // txtZip
      // 
      this.txtZip.Name = "txtZip";
      // 
      // txtCity
      // 
      this.txtCity.Name = "txtCity";
      // 
      // txtAddress
      // 
      this.txtAddress.Name = "txtAddress";
      // 
      // txtContactTitle
      // 
      this.txtContactTitle.Name = "txtContactTitle";
      // 
      // txtIdCustomer
      // 
      this.txtIdCustomer.Name = "txtIdCustomer";
      // 
      // txtContactName
      // 
      this.txtContactName.Name = "txtContactName";
      // 
      // txtCompanyName
      // 
      this.txtCompanyName.Name = "txtCompanyName";
      // 
      // frmCustomerValidationTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(688, 325);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCustomerValidationTryout";

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmCustomerValidationTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - ifrmCustomerTryout.Dispose(bool)
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmCustomerValidationTryout()
      //***
      // Action
      //   - Create new instance of 'frmCustomerValidationTryout'
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCustomerTryout()
      //   - cpCustomerTryout.Validation(bool) (Set)
      //   - ifrmCustomerTryout()
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
    }
    // frmCustomerValidationTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void TextBoxChange(string strProperty, string strValue)
      //***
      // Action
      //   - Try to
      //     - Depending on the textbox (property)
      //       - Fill the corresponding property of the customer instance (linked to the form)
      //     - Fill the rich text box with the customer info (ToString())
      //   - When there is no cpCustomer instance
      //     - Do nothing
      //   - When other exception
      //     - Show exception message
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCustomerTryout.Address(string) (Set)
      //   - cpCustomerTryout.City(string) (Set)
      //   - cpCustomerTryout.CompanyName(string) (Set)
      //   - cpCustomerTryout.ContactName(string) (Set)
      //   - cpCustomerTryout.ContactTitle(string) (Set)
      //   - cpCustomerTryout.Country(string) (Set)
      //   - cpCustomerTryout.Fax(string) (Set)
      //   - cpCustomerTryout.Phone(string) (Set)
      //   - cpCustomerTryout.Region(string) (Set)
      //   - cpCustomerTryout.PostalCode(string) (Set)
      //   - string cpCustomerTryout.ToString()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // TextBoxChange(string, string)

    #endregion

    #region "Controls"

    private void cmdDelete_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Delete the instance of cpCustomer
      //     - If successful
      //       - Show message that delete was successful
      //       - Clear the textboxes
      //       - Set instance of cpCustomer to nothing
      //     - If not
      //       - Show message that delete was unsuccessful
      //   - When exception occurs
      //     - Show exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool cpCustomerTryout.Delete() Implements cpiCustomerTryout.Delete
      //   - ClearAllTextBoxes()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click

    private void cmdNew_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - If there is a value in the customer key
      //       - If there is a value in the customer name
      //         - Create a new instance of cpCustomer with key and name
      //       - If not
      //         - Show message that a customer name is obligatory
      //     - If not
      //       - Show message that a unique key is obligatory, ask to create one by the program
      //       - If yes
      //         - A default customer is created
      //       - If no
      //         - All textboxes are cleared
      //   - When exception occurs
      //     - Show exception message
      //     - All textboxes are cleared
      // Called by
      //   - User action (Clicking a button)
      //   - cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      // Calls
      //   - ClearAllTextBoxes()
      //   - cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      //   - cpCustomerTryout(string, string)
      //   - cpCustomerTryout.Address(string) (Set)
      //   - cpCustomerTryout.City(string) (Set)
      //   - cpCustomerTryout.ContactName(string) (Set)
      //   - cpCustomerTryout.ContactTitle(string) (Set)
      //   - cpCustomerTryout.Country(string) (Set)
      //   - cpCustomerTryout.Fax(string) (Set)
      //   - cpCustomerTryout.Phone(string) (Set)
      //   - cpCustomerTryout.PostalCode(string) (Set)
      //   - cpCustomerTryout.Region(string) (Set)
      //   - CustomerProperties()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click

    private void cmdRetrieve_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Create a new cpCustomer instance with a given key
      //     - Set valication to true
      //     - Fill the textboxes with customer properties
      //   - When error occurs
      //     - Show exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpCustomerTryout(string)
      //   - cpCustomerTryout.Validation(bool) (Set)
      //   - CustomerProperties()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click

    private void cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Save the cpCustomer instance
      //     - If successfull
      //       - Show message
      //     - If not
      //       - Show message
      //   - When error occurs
      //     - Show exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool cpCustomerTryout.Save() Implements cpiCustomerTryout.Save
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void CustomerProperties()
      //***
      // Action
      //   - Fill all textboxes with the corresponding property
      // Called by
      //   - cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      //   - cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click
      // Calls
      //   - string cpCustomerTryout.Address (Get)
      //   - string cpCustomerTryout.City (Get)
      //   - string cpCustomerTryout.CompanyName (Get)
      //   - string cpCustomerTryout.ContactName (Get)
      //   - string cpCustomerTryout.ContactTitle (Get)
      //   - string cpCustomerTryout.Country (Get)
      //   - string cpCustomerTryout.Fax (Get)
      //   - string cpCustomerTryout.Phone (Get)
      //   - string cpCustomerTryout.Region (Get)
      //   - string cpCustomerTryout.PostalCode (Get)
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // CustomerProperties()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmCustomerValidationTryout

}
// CopyPaste.Learning