﻿//***
// Action
//   - Implementation of Route Config
// Created
//   - CopyPaste – 20260427 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260427 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace AgileTasks
{
  public class RouteConfig
  {

    #region "Constructors / Destructors"

    public RouteConfig()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // RouteConfig()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void RegisterRoutes(RouteCollection routes)
    //***
    // Action
    //   - Register the routes
    //   - An URL is matched to an action and not to a page
    // Called by
    //   - MvcApplication.Application_Start()
    // Calls
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

      // VVDW - Default routing, there is a dashboard menu item
      routes.MapRoute(
          name: "Default",
          url: "{controller}/{action}/{id}",
          defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
      );

      // VVDW - Going directly to the dashboard page (thru MVC, so it is a different page
      //routes.MapRoute(
      //    name: "Default",
      //    url: "{controller}/{action}/{id}",
      //    defaults: new { controller = "cpTask", action = "Index", id = UrlParameter.Optional }
      //);

    }
    // RegisterRoutes(RouteCollection)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // RouteConfig

}
// AgileTasks