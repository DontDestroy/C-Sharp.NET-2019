﻿//***
// Action
//   - Example of a Checkbox List in a web page
// Created
//   - CopyPaste – 20260522 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260522 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmCheckBoxList : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cmdSelect.Click += new System.EventHandler(this.cmdSelect_Click);
      this.ID = "wfrmCheckBoxList";
      this.Load += new System.EventHandler(this.Page_Load);

    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260522 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260522 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdSelect_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a string
    //   - Define two bytes
    //   - Loop thru the checkbox items
    //     - If selected
    //       - Increment bytNumberOfLanguages
    //       - Depending on the number of languages
    //         - 1, show the selected language
    //         - 2, show the first and second language
    //         - more, show the languages in a list (between the last 2 an and)
    //     - If not
    //       - Do nothing
    //   - If number of languages is zero
    //     - Show that there is no language selected
    //   - If not
    //     - Show the list of selected languages
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260522 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260522 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      byte bytCounter;
      byte bytNumberOfLanguages = 0;
      string strLanguages = "abc";

      for (bytCounter = 0; bytCounter < Convert.ToByte(chkLanguages.Items.Count); bytCounter++)
      {

        if (chkLanguages.Items[bytCounter].Selected)
        {
          bytNumberOfLanguages = Convert.ToByte(bytNumberOfLanguages + 1);

          switch (bytNumberOfLanguages)
          {
            case 1:
              strLanguages = chkLanguages.Items[bytCounter].Text;
              break;
            case 2:
              strLanguages = chkLanguages.Items[bytCounter].Text + " and " + strLanguages;
              break;
            default:
              strLanguages = chkLanguages.Items[bytCounter].Text + ", " + strLanguages;
              break;
          }
          // bytNumberOfLanguages

        }
        else
        // Not chkLanguages.Items[bytCounter].Selected
        {
        }
        // chkLanguages.Items[bytCounter].Selected

      }
      // bytCounter = chkLanguages.Items.Count

      if (bytNumberOfLanguages == 0)
      {
        lblResult.Text = "You did not select any language";
      }
      else
      // bytNumberOfLanguages <> 0
      {
        lblResult.Text = "You have selected these languages : " + strLanguages;
      }
      // bytNumberOfLanguages = 0

    }
    // cmdSelect_Click(System.Object, System.EventArgs)

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260522 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260522 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // Page_Load(System.Object, System.EventArgs) Handles base.Load


    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmCheckBoxList 

}
// CopyPaste.Learning 