﻿//***
// Action
//   - Demo of Karel the Robot using Java and C# Code
//     - The Karel the Robot backend functionality is written in Java
//     - The demo functionality is written in C#
//   - Some routines (methods) are Java methods
//     - Not the same naming conventions are used as in C#
//       - Method names starts with a small letter
// Created
//   - CopyPaste – 20251009 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251009 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using java.lang;
using kareltherobot;
using System;

namespace cpKarelTheRobot
{

  public static class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void BlockWalker()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Robot World specifications
    //   - Make the world visible
    //   - Karel becomes a green Block Walker robot starting at position (2, 2), looking to the right with no beepers in the bag
    //   - Karel repeats 4 times
    //     - Karel (green) starts to walk (in the mean time the strategy is changed)
    //   - Karel is turned off
    // Called by
    //   - Task()
    // Calls
    //   - cpBlockWalker(int, int, Directions.Direction, int, Color)
    //   - cpBlockWalker.WalkASide()
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\01.01 The Robot World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpBlockWalker karel = new cpBlockWalker(2, 2, Directions.East, 0, Color.green);

      for (int counter = 0; counter < 4; counter++)
      {
        karel.WalkASide();
      }
      // counter = 4

      karel.turnOff();
    }
    // BlockWalker()

    public static void Calculator()
    //***
    // Action
    // - Reset the world
    // - Build the world according to the Add Numbers specifications
    // - Make the world visible
    // - Karel becomes a green Calculator robot starting at position (1, 6), looking to the top with 0 beepers in the bag
    // - In the mean time theCarrier becomes a blue Carrier robot starting at position (1, 1), looking to the East with infinity beepers in the bag
    // - In the mean time theChecker becomes a yellow Checker robot starting at position (1, 1), looking to the East with 0 beepers in the bag
    // - Karel adds all the columns
    //   - The beepers represent number
    //   - So 2 beepers next to 3 beepers, represent 23
    // - Karel is turned off
    // Called by
    //   - Task()
    // Calls
    //   - cpCalculator(int, int, Directions.Direction, int, Color)
    //   - cpCalculator.AddAll()
    //   - cpCalculator.GatherHelpers()
    //   - cpCalculator.TurnHelpersOff()
    //   - cpCopyPasteRobot.FaceNorth()
    //   - cpCopyPasteRobot.GoToStartPosition()
    // Created
    //   - CopyPaste – 20251103 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251103 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      World.reset(); // World is resetted
      // World.readWorld("Worlds\\07.06a Add Numbers.kwld"); // World is created with specifications
      World.readWorld("Worlds\\07.06b Add Numbers.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible
      cpCalculator karel = new cpCalculator(1, 6, Directions.North, 0, Color.green);
      karel.GatherHelpers();
      karel.AddAll();
      karel.TurnHelpersOff();
      karel.GoToStartPosition();
      karel.FaceNorth();
      karel.move();
      karel.turnOff();
    }
    // Calculator()

    public static void Choreographer()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Robot World specifications
    //   - Make the world visible
    //   - Karel becomes a green Choreographer starting at position (2, 2), looking to the right with infinity beepers in the bag
    //     - In the mean time 3 other helpers are created with karel (the color is blue)
    //   - Karel (green) and the helpers (blue) repeat 4 times  
    //     - Put a beeper
    //     - Move one forward
    //   - Karel (green) and the helpers (blue) are turned left
    //   - Karel (green) and the helpers (blue) move one forward
    //   - Karel (green) and the helpers (blue) are switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpChoreographer.move();
    //   - cpChoreographer.putBeeper();
    //   - cpChoreographer.turnLeft();
    //   - cpChoreographer.turnOff();
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      World.reset();
      World.readWorld("Worlds\\01.01 The Robot World.kwld");
      World.setVisible(true);
      cpChoreographer karel = new cpChoreographer(2, 2, Directions.East, Directions.infinity, Color.green);

      for (int counter = 0; counter < 3; counter++)
      {
        karel.putBeeper();
        karel.move();
      }
      // counter = 3

      karel.turnLeft();
      karel.move();
      karel.turnOff();
    }
    // Choreographer()

    public static void Contractor()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the House World specifications
    //   - Make the world visible
    //   - Karel becomes a green Contractor robot starting at position (1, 1), looking to the right with infinity beepers in the bag
    //     - In the mean time becomes Bob the Builder a red Mason robot starting at position (1, 1), looking to the right with infinity beepers in the bag
    //     - In the mean time becomes Joseph the Carpenter a yellow Carpenter robot starting at position (1, 1), looking to the right with infinity beepers in the bag
    //     - In the mean time becomes Fidler the Roofer a blue Roofer robot starting at position (1, 1), looking to the right with infinity beepers in the bag
    //   - Karel will delegate some work to subcontractors
    //   - Karel and all helpers are turned off
    // Called by
    //   - Task()
    // Calls
    //   - cpContractor(int, int, Directions.Direction, int, Color)
    //   - cpContractor.BuildHouse()
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\04.04 The House World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpContractor karel = new cpContractor(1, 1, Directions.East, 0, Color.green);

      karel.BuildHouse();
      karel.turnOff();
    }
    // Contractor()

    public static void ControllerStrategyVersion01()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Robot World specifications
    //   - Make the world visible
    //   - Karel becomes a green Controller Strategy Version01 robot starting at position (2, 2), looking to the right with infinity beepers in the bag
    //   - Karel repeats this 4 times
    //     - Karel puts a row of 5 beepers
    //     - Karel turns (with a controller), and when turned, the controller is switched to the other on
    //   - Karel is turned off
    // Called by
    //   - Task()
    // Calls
    //   - cpControllerStrategyVersion01(int, int, Directions.Direction, int, Color) 
    //   - cpControllerStrategyVersion01.LayRow() 
    //   - cpControllerStrategyVersion01.Turn() 
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\01.01 The Robot World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpControllerStrategyVersion01 karel = new cpControllerStrategyVersion01(2, 2, Directions.East, Directions.infinity, Color.green);

      for (int counter = 0; counter < 4; counter++)
      {
        karel.LayRow();
        karel.Turn();
      }
      // counter = 4

      karel.turnOff();
    }
    // ControllerStrategyVersion01()

    public static void ControllerStrategyVersion02()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Robot World specifications
    //   - Make the world visible
    //   - Karel becomes a green Controller Strategy Version02 robot starting at position (2, 2), looking to the right with infinity beepers in the bag
    //   - Karel repeats this 4 times
    //     - Karel puts a row of 5 beepers
    //     - Karel turns (with a controller), and when turned, the controller is switched to the other on
    //   - Karel is turned off
    // Called by
    //   - Task()
    // Calls
    //   - cpControllerStrategyVersion02(int, int, Directions.Direction, int, Color) 
    //   - cpControllerStrategyVersion02.LayRow() 
    //   - cpControllerStrategyVersion02.Turn() 
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\01.01 The Robot World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpControllerStrategyVersion02 karel = new cpControllerStrategyVersion02(2, 2, Directions.East, Directions.infinity, Color.green);

      for (int counter = 0; counter < 4; counter++)
      {
        karel.LayRow();
        karel.Turn();
      }
      // counter = 4

      karel.turnOff();
    }
    // ControllerStrategyVersion02()

    public static void DeadLock()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Beeper World specifications
    //   - Set the delay to 10
    //   - Make the world visible
    //   - Create the robots
    //     - PhilosopherGreen becomes a green DeadLock robot starting at position (2, 3), looking to the top with no beepers in the bag
    //     - PhilosopherYellow becomes a yellow DeadLock robot starting at position (3, 2), looking to the right with no beepers in the bag
    //     - PhilosopherRed becomes a red DeadLock robot starting at position (4, 3), looking to the bottom with no beepers in the bag
    //     - PhilosopherBlue becomes a blue DeadLock robot starting at position (3, 4), looking to the left with no beepers in the bag
    // Called by
    //   - Task()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\08.06 The DeadLock World.kwld"); // World is created with specifications
      World.setDelay(20); // Speeding things up
      World.setVisible(true); // World is made visible

      cpDeadLock philosopherGreen = new cpDeadLock(2, 3, Directions.North, 0, Color.green);
      cpDeadLock philosopherYellow = new cpDeadLock(3, 2, Directions.East, 0, Color.yellow);
      cpDeadLock philosopherRed = new cpDeadLock(4, 3, Directions.South, 0, Color.red);
      cpDeadLock philosopherBlue = new cpDeadLock(3, 4, Directions.West, 0, Color.blue);
    }
    // DeadLock()

    public static void Decorator()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Robot Spy World specifications
    //   - Make the world visible
    //   - Karel becomes a green Spy Robot starting at position (2, 2), looking to the right with 1 beeper in the bag
    //   - JohnDoe01 becomes a blue Accomplice Robot starting at position (2, 4), looking to the North with 0 beepers in the bag (but with new information for Karel (the spy))
    //   - JohnDoe02 becomes a blue Accomplice Robot starting at position (2, 7), looking to the North with 0 beepers in the bag (but with new information for Karel (the spy))
    //   - JohnDoe03 becomes a blue Accomplice Robot starting at position (4, 7), looking to the North with 0 beepers in the bag (but with new information for Karel (the spy))
    //   - JohnDoe04 becomes a blue Accomplice Robot starting at position (7, 7), looking to the North with 0 beepers in the bag (but with new information for Karel (the spy))
    //   - Karel repeats 4 times
    //     - Karel (green) starts to walk (in the mean time the strategy is changed)
    //     - Karel meets an accomplice to get some more information (another strategy)
    //   - Karel puts beeper (dumps the secret information)
    //   - Karel goes to the start position (first street, first avenue)
    //   - Karel is turned off
    // Called by
    //   - Task()
    // Calls
    //   - cpAccompliceRobot(int, int, Directions.Direction, int, Color, cpinfStrategy)
    //   - cpBlockStrategyExtraTurnRight()
    //   - cpCopyPasteRobot.GoToStartPosition()
    //   - cpExtraBlockStrategy()
    //   - cpExtraTurnLeftBlockStrategy()
    //   - cpSpyRobot(int, int, Directions.Direction, int, Color, cpinfStrategy)
    //   - cpTwoBlockStrategyDecorator()
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\04.08 The Robot Spy World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible
      cpSpyRobot karel = new cpSpyRobot(2, 2, Directions.East, 1, Color.green, new cpTwoBlockStrategyDecorator()); // Move two blocks
      cpAccompliceRobot JohnDoe01 = new cpAccompliceRobot(2, 4, Directions.North, 0, Color.blue, new cpExtraBlockStrategy(new cpTwoBlockStrategyDecorator())); // Move three blocks
      cpAccompliceRobot JohnDoe02 = new cpAccompliceRobot(2, 7, Directions.North, 0, Color.blue, new cpExtraTurnLeftBlockStrategy(new cpTwoBlockStrategyDecorator())); // Turn left and move two blocks
      cpAccompliceRobot JohnDoe03 = new cpAccompliceRobot(4, 7, Directions.North, 0, Color.blue, new cpBlockStrategyExtraTurnRight(new cpExtraBlockStrategy(new cpTwoBlockStrategyDecorator()))); // Move three blocks and turn right
      cpAccompliceRobot JohnDoe04 = new cpAccompliceRobot(7, 7, Directions.North, 0, Color.blue, new cpTwoBlockStrategyDecorator()); // Move two blocks

      for (int counter = 0; counter < 4; counter++)
      {
        karel.FollowStrategy();
        karel.GetNextClue();
      }
      // counter = 4

      karel.FollowStrategy();
      karel.putBeeper();
      karel.GoToStartPosition();
      karel.turnOff();
    }
    // Decorator()

    public static void Enumeration()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Robot Spy World specifications
    //   - Make the world visible
    //   - Karel becomes a green Spy Robot starting at position (2, 2), looking to the right with 1 beeper in the bag
    //   - JohnDoe01 becomes a blue Accomplice Robot starting at position (5, 2), looking to the North with 0 beepers in the bag (but with new information for Karel (the spy))
    //   - JohnDoe02 becomes a blue Accomplice Robot starting at position (5, 4), looking to the North with 0 beepers in the bag (but with new information for Karel (the spy))
    //   - JohnDoe03 becomes a blue Accomplice Robot starting at position (3, 4), looking to the North with 0 beepers in the bag (but with new information for Karel (the spy))
    //   - JohnDoe04 becomes a blue Accomplice Robot starting at position (3, 7), looking to the North with 0 beepers in the bag (but with new information for Karel (the spy))
    //   - Karel repeats 4 times
    //     - Karel (green) starts to walk (in the mean time the strategy is changed)
    //     - Karel meets an accomplice to get some more information (another strategy)
    //   - Karel puts beeper(dumps the secret information)
    //   - Karel goes to the start position (first street, first avenue)
    //   - Karel is turned off
    // Called by
    //   - Task()
    // Calls
    //   - cpAccompliceRobot(int, int, Directions.Direction, int, Color, cpinfStrategy) 
    //   - cpCopyPasteRobot.GoToStartPosition()
    //   - cpSpyRobot(int, int, Directions.Direction, int, Color, cpinfStrategy) 
    //   - cpSpyRobot.FollowStrategy()
    //   - cpSpyRobot.GetNextClue()
    //   - cpThreeBlockSpyStrategy()
    //   - cpTwoBlockSpyStrategy()
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\04.07 The Robot Spy World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible
      cpSpyRobot karel = new cpSpyRobot(2, 2, Directions.East, 1, Color.green, new cpThreeBlockSpyStrategy());
      cpAccompliceRobot JohnDoe01 = new cpAccompliceRobot(5, 2, Directions.North, 0, Color.blue, new cpTwoBlockSpyStrategy());
      cpAccompliceRobot JohnDoe02 = new cpAccompliceRobot(5, 4, Directions.North, 0, Color.blue, new cpTwoBlockSpyStrategy());
      cpAccompliceRobot JohnDoe03 = new cpAccompliceRobot(3, 4, Directions.North, 0, Color.blue, new cpThreeBlockSpyStrategy());
      cpAccompliceRobot JohnDoe04 = new cpAccompliceRobot(3, 7, Directions.North, 0, Color.blue, new cpThreeBlockSpyStrategy());

      for (int counter = 0; counter < 4; counter++)
      {
        karel.FollowStrategy();
        karel.GetNextClue();
      }
      // counter = 4

      karel.FollowStrategy();
      karel.putBeeper();
      karel.GoToStartPosition();
      karel.turnOff();
    }
    // Enumeration()

    public static void ExecutionErrors()
    //***
    // Action
    //   - Create a cpExecutionErrors instance
    //   - The constructor of the instance starts the action
    // Called by
    //   - Task()
    // Calls
    //   - cpExecutionErrors()
    // Created
    //   - CopyPaste – 20251011 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251011 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpExecutionErrors karel = new cpExecutionErrors();
    }
    // ExecutionErrors()

    public static void FindBeeperNextToWallInARoom()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Beeper in a Room specifications
    //   - Make the world visible
    //   - Karel becomes a green FindBeeperNextToWallInARoom starting at position (5, 2), looking to the bottom with no beepers in the bag
    //   - Karel will try to find the beeper next to a wall
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpFindBeeperNextToWallInARoom(int, int, Directions.Direction, int, Color)
    //   - cpFindBeeperNextToWallInARoom.FindBeeperNextToWall()
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      World.reset();
      World.readWorld("Worlds\\06.08 BeeperInARoom.kwld");
      // World.readWorld("Worlds\\06.10b BeeperInARoom.kwld");
      // World.readWorld("Worlds\\06.10c BeeperInARoom.kwld");
      // World.readWorld("Worlds\\06.11 BeeperInARoom.kwld");
      World.setVisible(true);
      cpFindBeeperNextToWallInARoom karel = new cpFindBeeperNextToWallInARoom(5, 2, Directions.South, 0, Color.green);

      karel.FindBeeperNextToWall();
      karel.turnOff();
    }
    // FindBeeperNextToWallInARoom()

    public static void FindBeeperNextToWallInARoomError()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Beeper in a Room specifications
    //   - Make the world visible
    //   - Karel becomes a green FindBeeperNextToWallInARoomError starting at position (5, 2), looking to the bottom with no beepers in the bag
    //   - Karel will try to find the beeper next to a wall
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpFindBeeperNextToWallInARoomError(int, int, Directions.Direction, int, Color)
    //   - cpFindBeeperNextToWallInARoomError.FindBeeperNextToWall()
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      World.reset();
      World.readWorld("Worlds\\06.08 BeeperInARoom.kwld");
      // World.readWorld("Worlds\\06.10b BeeperInARoom.kwld");
      // World.readWorld("Worlds\\06.10c BeeperInARoom.kwld");
      // World.readWorld("Worlds\\06.11 BeeperInARoom.kwld");
      World.setVisible(true);
      cpFindBeeperNextToWallInARoomError karel = new cpFindBeeperNextToWallInARoomError(5, 2, Directions.South, 0, Color.green);

      karel.FindBeeperNextToWall();
      karel.turnOff();
    }
    // FindBeeperNextToWallInARoomError()

    public static void ForLoop()
    //***
    // Action
    //   - Create a cpFor instance
    // Called by
    //   - Task()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251020 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251020 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpFor karel = new cpFor();
    }
    // ForLoop()

    public static void GetterPutter01()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Ten Beepers in Two Streets World specifications
    //   - Make the world visible
    //   - The putter becomes a green Putter robot starting at position (1, 1), looking to the right with infinity beepers in the bag
    //   - The getter becomes a blue Getter robot starting at position (2, 1), looking to the right with infinity beepers in the bag
    //   - Karel is defined as a Copy Paste Robot
    //   - Repeat 10 times
    //     - Karel becomes theGetter
    //     - Repeat 2 times
    //       - Move the getter or putter (overriden)
    //       - Karel becomes thePutter
    //   - Turn thePutter robot off
    //   - Karel becomes theGetter
    //   - Turn theGetter robot off
    // Called by
    //   - Task()
    // Calls
    //   - cpGetter(int, int, Directions.Direction, int, Color)
    //   - cpGetter.move()
    //   - cpPutter(int, int, Directions.Direction, int, Color)
    //   - cpPutter.move()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\07.07 Ten Beepers in Two Streets.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpCopyPasteRobot karel = null;
      cpGetter theGetter = new cpGetter(2, 1, Directions.East, Directions.infinity, Color.blue);
      cpPutter thePutter = new cpPutter(1, 1, Directions.East, Directions.infinity, Color.green);

      for (int outerCounter = 0; outerCounter < 10; outerCounter++)
      {
        karel = theGetter;

        for (int innerCounter = 0; innerCounter < 2; innerCounter++)
        {
          karel.move();
          karel = thePutter;
        }
        // innerCounter = 2

      }
      // outerCounter = 10

      karel.turnOff();
      karel = theGetter;
      karel.turnOff();
    }
    // GetterPutter01()

    public static void GetterPutter02()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Ten Beepers in Two Streets World specifications
    //   - Make the world visible
    //   - The putter becomes a green Putter robot starting at position (1, 1), looking to the right with infinity beepers in the bag
    //   - The getter becomes a blue Getter robot starting at position (2, 1), looking to the right with infinity beepers in the bag
    //   - Karel is defined as a Copy Paste Robot
    //   - Karel becomes theGetter
    //   - Repeat 10 times
    //     - Move the getter (overriden)
    //   - Turn theGetter robot off
    //   - Karel becomes thePutter
    //   - Repeat 10 times
    //     - Move the putter (overriden)
    //   - Turn thePutter robot off
    //   - Karel becomes theGetter
    // Called by
    //   - Task()
    // Calls
    //   - cpGetter(int, int, Directions.Direction, int, Color)
    //   - cpGetter.move()
    //   - cpPutter(int, int, Directions.Direction, int, Color)
    //   - cpPutter.move()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\07.07 Ten Beepers in Two Streets.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpCopyPasteRobot karel = null;
      cpGetter theGetter = new cpGetter(2, 1, Directions.East, Directions.infinity, Color.blue);
      cpPutter thePutter = new cpPutter(1, 1, Directions.East, Directions.infinity, Color.green);

      karel = theGetter;

      for (int counter = 0; counter < 10; counter++)
      {
        karel.move();
      }
      // counter = 10

      karel.turnOff();
      karel = thePutter;

      for (int counter = 0; counter < 10; counter++)
      {
        karel.move();
      }
      // counter = 10

      karel.turnOff();
    }
    // GetterPutter02()

    public static void GetterPutter03()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Ten Beepers in Two Streets World specifications
    //   - Make the world visible
    //   - The putter becomes a green Putter robot starting at position (1, 1), looking to the right with infinity beepers in the bag
    //   - The getter becomes a blue Getter robot starting at position (2, 1), looking to the right with infinity beepers in the bag
    //   - Repeat 10 times
    //     - Move the getter (overriden)
    //     - Move the putter (overriden)
    //   - Turn all robots off
    // Called by
    //   - Task()
    // Calls
    //   - cpGetter(int, int, Directions.Direction, int, Color)
    //   - cpGetter.move()
    //   - cpPutter(int, int, Directions.Direction, int, Color)
    //   - cpPutter.move()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\07.07 Ten Beepers in Two Streets.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpGetter theGetter = new cpGetter(2, 1, Directions.East, Directions.infinity, Color.blue);
      cpPutter thePutter = new cpPutter(1, 1, Directions.East, Directions.infinity, Color.green);

      for (int counter = 0; counter < 10; counter++)
      {
        theGetter.move();
        thePutter.move();
      }
      // counter = 10

      theGetter.turnOff();
      thePutter.turnOff();
    }
    // GetterPutter03()

    public static void GuardAField()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Field specifications
    //   - Make the world visible
    //   - TheGuard becomes a green GuardAField at position (2, 1), looking to the right with no beepers in the bag
    //     - TheGuard becomes a green GuardAField at position (1, 3), looking to the right with no beepers in the bag (for world 06.14 Field)
    //   - The guard goes to tha south east corner of the field
    //   - The guard walks around the perimeter (the field) to guard it
    //   - The guard is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpGuardAField(int, int, Directions.Direction, int, Color)
    //   - cpGuardAField.MoveToSouthEastCorner()
    //   - cpGuardAField.WalkPerimeter()
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      World.reset();
      World.readWorld("Worlds\\06.15 Field.kwld");
      // World.readWorld("Worlds\\06.14 Field.kwld");
      World.setVisible(true);
      cpGuardAField theGuard = new cpGuardAField(2, 1, Directions.East, 0, Color.green);
      // cpGuardAField theGuard = new cpGuardAField(1, 3, Directions.East, 0, Color.green);

      theGuard.MoveToSouthEastCorner();
      theGuard.WalkPerimeter();
      theGuard.turnOff();
    }
    // GuardAField()

    public static void LexicalErrors()
    //***
    // Action
    //   - Create a cpLexicalErrors instance
    //   - The constructor of the instance starts the action
    // Called by
    //   - Task()
    // Calls
    //   - cpLexicalErrors()
    // Created
    //   - CopyPaste – 20251011 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251011 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpLexicalErrors karel = new cpLexicalErrors();
    }
    // LexicalErrors()

    public static void LinkedList()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Robot World specifications
    //   - Make the world visible
    //   - Karel becomes a green Linked List robot starting at position (1, 1), looking to the right with infinity beepers in the bag
    //   - The strategy becomes a Null strategy();
    //   - The strategy becomes the (current) strategy with a Three Beeper Strategy as next
    //   - The strategy becomes the (current) strategy with a Move strategy with as next
    //   - The strategy becomes the (current) strategy with a Move strategy with as next
    //   - The strategy becomes the (current) strategy with a ShutDown strategy with as next
    //   - The (current) strategy is executed by karel
    //   - Karel is turned off (by the null strategy)
    // Called by
    //   - Task()
    // Calls
    //   - cpThiefRobotFail(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\01.01 The Robot World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpLinkedList karel = new cpLinkedList(1, 1, Directions.East, Directions.infinity, Color.green);
      cpinfStrategy theStrategy = new cpNullStrategy();
      theStrategy = new cpThreeBeeperStrategy(theStrategy);
      theStrategy = new cpMoveStrategy(theStrategy);
      theStrategy = new cpMoveStrategy(theStrategy);
      theStrategy = new cpShutDownStrategy(theStrategy);
      theStrategy.DoIt(karel);
    }
    // LinkedList()

    public static void Main()
    //***
    // Action
    //   - Used to demo some stuff in object oriented programming
    // Called by
    //   - 
    // Calls
    //   - Task()
    // Created
    //   - CopyPaste – 20251009 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251009 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Task();
      Console.WriteLine("The robots are finished");
      Console.ReadLine();
    }
    // Main()

    public static void MoveFiveForwardIn5WideWorldAndOneBack()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the World 5 by 5 specifications
    //   - Set the delay (speed) to 100
    //   - Make the world visible
    //   - Karel becomes a green robot starting at position (1, 1), looking to the right with no beepers in the bag
    //   - Karel will move five forward (and fall out of the world)
    //   - Karel will turn around
    //   - Karel will move one forward (and get back inside the world)
    //   - Karel shuts down
    // Called by
    //   - Task()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251011 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251011 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\02.01b World 5 by 5.kwld");
      World.setDelay(100);
      World.setVisible(true);

      UrRobot karel = new UrRobot(1, 1, Directions.East, 0, Color.green);

      karel.move();
      karel.move();
      karel.move();
      karel.move();
      karel.move();
      karel.turnLeft();
      karel.turnLeft();
      karel.move();
      karel.turnOff();
    }
    // MoveFiveForwardIn5WideWorldAndOneBack()

    public static void MoveOneForward()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the One Wall Segment specifications
    //   - Set the delay (speed) to 100
    //   - Make the world visible
    //   - Some demo command to explain why classes are interesting
    //   - Karel becomes a green robot starting at position (1, 1), looking to the right with no beepers in the bag
    //   - Karel will move one forward (and succeed)
    // Called by
    //   - Task()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251009 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251009 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\02.01a One Wall Segment.kwld");
      World.setDelay(100);
      World.setVisible(true);

      // Commands that can be added to demo stuff

      // World.setWorldColor(Color.yellow);
      // World.placeBeepers(3, 3, 10);
      // World.setBeeperColor(Color.red);
      // World.placeEWWall(2, 3, 2);
      // World.placeNSWall(3, 2, 1);
      // World.placeNSWall(3, 4, 1);
      // World.placeEWWall(3, 3, 2);
      // World.repaint();

      UrRobot karel = new UrRobot(1, 1, Directions.East, 0, Color.green);

      karel.move();
      karel.turnOff();
    }
    // MoveOneForward()

    public static void MoveOneForwardAndMoveBeeperOneForwardTurnBack()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the One Beeper specifications
    //   - Set the delay (speed) to 100
    //   - Make the world visible
    //   - Karel becomes a green robot starting at position (1, 1), looking to the right with no beepers in the bag
    //   - Karel will move one forward (and succeed)
    //   - Karel will pick one beeper (and succeed)
    //   - Karel will move one forward (and succeed)
    //   - Karel will put one beeper (and succeed)
    //   - Karel will turn around (and succeed)
    //   - Karel will move two forward (and succeed)
    //   - Karel shuts down
    // Called by
    //   - Task()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251011 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251011 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\02.04 One Beeper.kwld");
      World.setDelay(100);
      World.setVisible(true);

      UrRobot karel = new UrRobot(1, 1, Directions.East, 0, Color.green);

      karel.move();
      karel.pickBeeper();
      karel.move();
      karel.putBeeper();
      karel.turnLeft();
      karel.turnLeft();
      karel.move();
      karel.move();
      karel.turnOff();
    }
    // MoveOneForwardAndMoveBeeperOneForwardTurnBack()

    public static void MoveOneForwardAndPickBeeperTurnBack()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the One Beeper specifications
    //   - Set the delay (speed) to 100
    //   - Make the world visible
    //   - Karel becomes a green robot starting at position (1, 1), looking to the right with no beepers in the bag
    //   - Karel will move one forward (and succeed)
    //   - Karel will pick one beeper (and succeed)
    //   - Karel will turn around (and succeed)
    //   - Karel will move one forward (and succeed)
    //   - Karel shuts down
    // Called by
    //   - Task()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251011 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251011 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\02.04 One Beeper.kwld");
      World.setDelay(100);
      World.setVisible(true);

      UrRobot karel = new UrRobot(1, 1, Directions.East, 0, Color.green);

      karel.move();
      karel.pickBeeper();
      karel.turnLeft();
      karel.turnLeft();
      karel.move();
      karel.turnOff();
    }
    // MoveOneForwardAndPickBeeperTurnBack()

    public static void MoveOneForwardSimplest()
    //***
    // Action
    //   - Create a cpMoveForwardSimplest
    //   - Execute the task (is implemented using an interface)
    // Called by
    //   - Task()
    // Calls
    //   - cpMoveOneForwardSimplest()
    // Created
    //   - CopyPaste – 20251010 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251010 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpMoveOneForwardSimplest karel = new cpMoveOneForwardSimplest();

      karel.task();
    }
    // MoveOneForwardSimplest()

    public static void MoveOneForwardSimply()
    //***
    // Action
    //   - Create a cpMoveForwardSimple instance
    //   - The constructor of the instance starts the action
    // Called by
    //   - Task()
    // Calls
    //   - cpMoveOneForwardSimply()
    // Created
    //   - CopyPaste – 20251010 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251010 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpMoveOneForwardSimply karel = new cpMoveOneForwardSimply();
    }
    // MoveOneForwardSimply()

    public static void MoveTwoForward()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the One Wall Segment specifications
    //   - Set the delay (speed) to 100
    //   - Make the world visible
    //   - Karel becomes a green robot starting at position (1, 1), looking to the right with no beepers in the bag
    //   - Karel will move one forward (and succeed)
    //   - Karel will move one forward (and fail)
    //   - Karel tries to shut down (but will never reach this statement)
    // Called by
    //   - Task()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251011 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251011 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\02.01a One Wall Segment.kwld");
      World.setDelay(100);
      World.setVisible(true);

      UrRobot karel = new UrRobot(1, 1, Directions.East, 0, Color.green);

      karel.move();
      karel.move();
      karel.turnOff();
    }
    // MoveTwoForward()

    public static void Observer()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Robot Observe Picking World specifications
    //   - Make the world visible
    //   - Karel becomes a Move Two Blocks Listener Robot starting at position(3, 1), looking to the right with no beepers in the bag
    //     - This is the robot that will be triggered to move two corners, when another robot picks a beeper
    //   - BeeperPicker becomes a Observable Picker Robot starting at position(1, 1), looking to the right with no beepers in the bag
    //   - BeeperPicker is registered to karel(Karel is observing beeperPicker)
    //   - Repeat 8 times
    //     - BeeperPicker move forward
    //     - If a beeper present
    //       - BeeperPicker is picking beeper(this will trigger a move forward by 2 corners by the observer Karel)
    //   - BeeperPicker is turned off
    //   - Karel is turned off
    // Called by
    //   - Task()
    // Calls
    //   - cpMoveTwoBlocksListener(int, int, Directions.Direction, int, Color)
    //   - cpObservablePicker(int, int, Directions.Direction, int, Color) 
    //   - cpObservablePicker.Register(cpinfRobotListener)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\04.09 Observe Picking a Beeper.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible
      cpMoveTwoBlocksListener karel = new cpMoveTwoBlocksListener(3, 1, Directions.East, 0, Color.green); // The robot that is observing the robot that picks beepers
                                                                                                          // Karel will move 2 blocks when a beeper is picked by another robot
                                                                                                          // Karel is the listener, and will take some actions when something happens
      cpObservablePicker beeperPicker = new cpObservablePicker(1, 1, Directions.East, 0, Color.blue); // The robot that is picking beepers
      beeperPicker.Register(karel); // Karel is observing beeperPicker, beeperPicker is observed by karel

      for (int counter = 0; counter < 8; counter++)
      {
        beeperPicker.move();

        if (beeperPicker.nextToABeeper())
        {
          beeperPicker.pickBeeper();
        }
        // Not beeperPicker.nextToABeeper()
        else
        {
        }
        // beeperPicker.nextToABeeper()

      }
      // counter = 8

      beeperPicker.turnOff();
      karel.turnOff();
    }
    // Observer()

    public static void OriginSitterLookingNorth()
    //***
    // Action
    //   - Create a cpOriginSitterLookingNorth instance
    //   - Reset the world
    //   - Build the world according to the Robot World specifications
    //   - Make the world visible
    //   - Karel moves one forward
    //   - Karel is shut down
    // Called by
    //   - Task()
    // Calls
    //   - cpOriginSitterLookingNorth()
    // Created
    //   - CopyPaste – 20251011 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251011 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\01.01 The Robot World.kwld");
      World.setVisible(true);

      cpOriginSitterLookingNorth karel = new cpOriginSitterLookingNorth();
      karel.move();
      karel.turnOff();
    }
    // LexicalErrors()

    public static void Recursion()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the BeeperInFirstStreet specifications
    //   - Make the world visible
    //   - Karel becomes a green Beeper Finder robot starting at position (1, 1), looking to the right with 0 beepers in the bag
    //   - Karel tries to find the beeper and return to the origin
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpBeeperFinder(int, int, Directions.Direction, int, Color) 
    //   - cpBeeperFinder.RetrieveBeeper()
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\07.01 BeeperInFirstStreet.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpBeeperFinder karel = new cpBeeperFinder(1, 1, Directions.East, 0, Color.green);
      karel.RetrieveBeeper();
      karel.turnOff();
    }
    // Recursion()

    public static void RecursionFindBeeper()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the TreasureSomewhere specifications
    //   - Make the world visible
    //   - Karel becomes a green Recursion Beeper Finder robot starting at position (1, 1), looking to the right with 0 beepers in the bag
    //   - Karel tries to find the beeper
    //   - Take that beeper (the beeper is a position where the treasure can be found)
    //   - There is a treasure in the same avenue of where the beeper is found
    //   - The number of steps to the North is exactly the number of steps the robot took to find the first beeper
    //   - Take all the beepers from the treasure
    //   - Go back to the origin
    //   - Karel is turned off
    // Called by
    //   - Task()
    // Calls
    //   - cpBeeperFinder(int, int, Directions.Direction, int, Color) 
    //   - cpBeeperFinder.RetrieveBeeper()
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\07.02 TreasureSomewhere.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpRecursionFindBeeper karel = new cpRecursionFindBeeper(1, 1, Directions.East, 0, Color.green);
      karel.RetrieveTreasure();
      karel.turnOff();
    }
    // RecursionFindBeeper()

    public static void RelayRacer()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Relay Race World specifications
    //   - Make the world visible
    //   - Create the robots
    //     - RacerGreen becomes a green Relay Racer robot starting at position (1, 1), looking to the right with no beepers in the bag
    //     - RacerBlue becomes a blue Relay Racer robot starting at position (1, 4), looking to the right with no beepers in the bag
    //     - RacerYellow becomes a yellow Relay Racer robot starting at position (1, 10), looking to the right with no beepers in the bag
    // Called by
    //   - Task()
    // Calls
    //   - cpRelayRacer(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\08.03 The Relay Race World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpRelayRacer racerGreen = new cpRelayRacer(1, 1, Directions.East, 0, Color.green);
      cpRelayRacer racerBlue = new cpRelayRacer(1, 4, Directions.East, 0, Color.blue);
      cpRelayRacer racerYellow = new cpRelayRacer(1, 10, Directions.East, 0, Color.yellow);
    }
    // RelayRacer()

    public static void RemoveAllBeepersTillWall()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Beepers in a Row specifications
    //   - Make the world visible
    //   - Karel becomes a green RemoveAllBeepersTillWall starting at position (4, 3), looking to the bottom with no beepers in the bag
    //   - Karel will move down get all the beepers
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveAllBeepersTillWall(int, int, Directions.Direction, int, Color)
    //   - cpRemoveAllBeepersTillWall.RemoveAllBeeperTillWall()
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      World.reset();
      World.readWorld("Worlds\\06.07 BeepersInARow.kwld");
      World.setVisible(true);
      cpRemoveAllBeepersTillWall karel = new cpRemoveAllBeepersTillWall(4, 3, Directions.South, 0, Color.green);

      karel.RemoveAllBeepersTillWall();
      karel.turnOff();
    }
    // RemoveAllBeepersTillWall()

    public static void RemoveBeepersTillWall()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Beepers in a Row specifications
    //   - Make the world visible
    //   - Karel becomes a green RemoveBeepersTillWall starting at position (4, 3), looking to the bottom with no beepers in the bag
    //   - Karel will move down get all the beepers
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersTillWall(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersTillWall.RemoveBeeperTillWall()
    // Created
    //   - CopyPaste – 20251022 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251022 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      World.reset();
      World.readWorld("Worlds\\06.01 BeepersInARow.kwld");
      World.setVisible(true);
      cpRemoveBeepersTillWall karel = new cpRemoveBeepersTillWall(4, 3, Directions.South, 0, Color.green);

      karel.RemoveBeepersTillWall();
      karel.turnOff();
    }
    // RemoveBeepersTillWall()

    public static void RemoveBeepersTillWallError01()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Beepers in a Row specifications
    //   - Make the world visible
    //   - Karel becomes a green RemoveBeepersTillWallError01 starting at position (4, 3), looking to the bottom with no beepers in the bag
    //   - Karel will move down get all the beepers
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersTillWallError01(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersTillWallError01.RemoveBeeperTillWall()
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - This routine contains an error in the starting point
    //     - First beeper is not taken
    //***
    {
      World.reset();
      World.readWorld("Worlds\\06.05 BeepersInARow.kwld");
      World.setVisible(true);
      cpRemoveBeepersTillWallError01 karel = new cpRemoveBeepersTillWallError01(4, 3, Directions.South, 0, Color.green);

      karel.RemoveBeepersTillWall();
      karel.turnOff();
    }
    // RemoveBeepersTillWallError01()

    public static void RemoveBeepersTillWallError02()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Beepers in a Row specifications
    //   - Make the world visible
    //   - Karel becomes a green RemoveBeepersTillWallError02 starting at position (4, 3), looking to the bottom with no beepers in the bag
    //   - Karel will move down get all the beepers
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersTillWallError02(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersTillWallError02.RemoveBeeperTillWall()
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - This routine contains an error in the ending point
    //     - Last beeper is not taken
    //***
    {
      World.reset();
      World.readWorld("Worlds\\06.05 BeepersInARow.kwld");
      World.setVisible(true);
      cpRemoveBeepersTillWallError02 karel = new cpRemoveBeepersTillWallError02(4, 3, Directions.South, 0, Color.green);

      karel.RemoveBeepersTillWall();
      karel.turnOff();
    }
    // RemoveBeepersTillWallError02()

    public static void RemoveBeepersVersion01()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the World Full of Beepers specifications
    //   - Make the world visible
    //   - TheHarvester becomes a green remove beepers (version01) starting at position (2, 2), looking to the right with no beepers in the bag
    //     - We will name him theHarvester
    //   - The goal is to remove all the beepers in a fixed world (meaning, the program must work only for this world)
    //     - We will call the method harvestTheField
    //   - The goal of this exercise is to start with creating a battle plan
    //     - Define the problem
    //     - Plan the solution
    //     - Implement the plan
    //     - Analyse and test the solution
    //   - The goal is to have working software
    //     - Program must be easy to read and understand
    //     - Program must be easy to debug
    //     - Program must be easy to modify to solve variations of the original task
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersVersion01(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersVersion01.HarvestTheField()
    // Created
    //   - CopyPaste – 20251012 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251012 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\03.06 WorldFullOfBeepers.kwld");
      World.setVisible(true);
      cpRemoveBeepersVersion01 theHarvester = new cpRemoveBeepersVersion01(2, 2, Directions.East, 0, Color.green);

      theHarvester.HarvestTheField();
      theHarvester.turnOff();
    }
    // RemoveBeepersVersion01()

    public static void RemoveBeepersVersion01MultipleFiles()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the World Full of Beepers specifications
    //   - Make the world visible
    //   - TheHarvester becomes a green remove beepers (version01) starting at position (2, 2), looking to the right with no beepers in the bag
    //     - We will name him theHarvester
    //   - The goal is to remove all the beepers in a fixed world (meaning, the program must work only for this world)
    //     - We will call the method harvestTheField
    //   - The goal of this exercise is to start with creating a battle plan
    //     - Define the problem
    //     - Plan the solution
    //     - Implement the plan
    //     - Analyse and test the solution
    //   - The goal is to have working software
    //     - Program must be easy to read and understand
    //     - Program must be easy to debug
    //     - Program must be easy to modify to solve variations of the original task
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersVersion01MultipleFiles(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersVersion01MultipleFiles.HarvestTheField()
    // Created
    //   - CopyPaste – 20251013 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251013 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\03.06 WorldFullOfBeepers.kwld");
      World.setVisible(true);
      cpRemoveBeepersVersion01MultipleFiles theHarvester = new cpRemoveBeepersVersion01MultipleFiles(2, 2, Directions.East, 0, Color.green);

      theHarvester.HarvestTheField();
      theHarvester.turnOff();
    }
    // RemoveBeepersVersion01MultipleFiles()

    public static void RemoveBeepersVersion02()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the World Full of Beepers specifications
    //   - Make the world visible
    //   - TheHarvester becomes a green remove beepers (version01) starting at position (2, 2), looking to the right with no beepers in the bag
    //     - We will name him theHarvester
    //   - The goal is to remove all the beepers in a fixed world (meaning, the program must work only for this world)
    //     - We will call the method harvestTheField
    //   - The goal of this exercise is to start with creating a battle plan
    //     - Define the problem
    //     - Plan the solution
    //     - Implement the plan
    //     - Analyse and test the solution
    //   - The goal is to have working software
    //     - Program must be easy to read and understand
    //     - Program must be easy to debug
    //     - Program must be easy to modify to solve variations of the original task
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersVersion02(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersVersion02.HarvestTheField()
    // Created
    //   - CopyPaste – 20251013 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251013 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\03.09a WorldFullOfBeepers.kwld");
      World.setVisible(true);
      cpRemoveBeepersVersion02 theHarvester = new cpRemoveBeepersVersion02(2, 2, Directions.East, 0, Color.green);

      theHarvester.HarvestTheField();
      theHarvester.turnOff();
    }
    // RemoveBeepersVersion02()

    public static void RemoveBeepersVersion02MultipleFiles()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the World Full of Beepers specifications
    //   - Make the world visible
    //   - TheHarvester becomes a green remove beepers (version01) starting at position (2, 2), looking to the right with no beepers in the bag
    //     - We will name him theHarvester
    //   - The goal is to remove all the beepers in a fixed world (meaning, the program must work only for this world)
    //     - We will call the method harvestTheField
    //   - The goal of this exercise is to start with creating a battle plan
    //     - Define the problem
    //     - Plan the solution
    //     - Implement the plan
    //     - Analyse and test the solution
    //   - The goal is to have working software
    //     - Program must be easy to read and understand
    //     - Program must be easy to debug
    //     - Program must be easy to modify to solve variations of the original task
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersVersion02MultipleFiles(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersVersion02MultipleFiles.HarvestTheField()
    // Created
    //   - CopyPaste – 20251013 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251013 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\03.09a WorldFullOfBeepers.kwld");
      World.setVisible(true);
      cpRemoveBeepersVersion02MultipleFiles theHarvester = new cpRemoveBeepersVersion02MultipleFiles(2, 2, Directions.East, 0, Color.green);

      theHarvester.HarvestTheField();
      theHarvester.turnOff();
    }
    // RemoveBeepersVersion02MultipleFiles()

    public static void RemoveBeepersVersion03()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the World Full of Beepers specifications
    //   - Make the world visible
    //   - TheHarvester becomes a green remove beepers (version01) starting at position (2, 2), looking to the right with no beepers in the bag
    //     - We will name him theHarvester
    //   - The goal is to remove all the beepers in a fixed world (meaning, the program must work only for this world)
    //     - We will call the method harvestTheField
    //   - The goal of this exercise is to start with creating a battle plan
    //     - Define the problem
    //     - Plan the solution
    //     - Implement the plan
    //     - Analyse and test the solution
    //   - The goal is to have working software
    //     - Program must be easy to read and understand
    //     - Program must be easy to debug
    //     - Program must be easy to modify to solve variations of the original task
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersVersion03(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersVersion03.HarvestTheField()
    // Created
    //   - CopyPaste – 20251013 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251013 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\03.09b WorldFullOfBeepers.kwld");
      World.setVisible(true);
      cpRemoveBeepersVersion03 theHarvester = new cpRemoveBeepersVersion03(2, 2, Directions.East, 0, Color.green);

      theHarvester.HarvestTheField();
      theHarvester.turnOff();
    }
    // RemoveBeepersVersion03()

    public static void RemoveBeepersVersion03MultipleFiles()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the World Full of Beepers specifications
    //   - Make the world visible
    //   - TheHarvester becomes a green remove beepers (version01) starting at position (2, 2), looking to the right with no beepers in the bag
    //     - We will name him theHarvester
    //   - The goal is to remove all the beepers in a fixed world (meaning, the program must work only for this world)
    //     - We will call the method harvestTheField
    //   - The goal of this exercise is to start with creating a battle plan
    //     - Define the problem
    //     - Plan the solution
    //     - Implement the plan
    //     - Analyse and test the solution
    //   - The goal is to have working software
    //     - Program must be easy to read and understand
    //     - Program must be easy to debug
    //     - Program must be easy to modify to solve variations of the original task
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersVersion03MultipleFiles(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersVersion03MultipleFiles.HarvestTheField()
    // Created
    //   - CopyPaste – 20251013 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251013 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\03.09b WorldFullOfBeepers.kwld");
      World.setVisible(true);
      cpRemoveBeepersVersion03MultipleFiles theHarvester = new cpRemoveBeepersVersion03MultipleFiles(2, 2, Directions.East, 0, Color.green);

      theHarvester.HarvestTheField();
      theHarvester.turnOff();
    }
    // RemoveBeepersVersion03MultipleFiles()

    public static void RemoveBeepersVersion04()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the World Full of Beepers specifications
    //   - Make the world visible
    //   - TheHarvester becomes a green remove beepers (version01) starting at position (2, 2), looking to the right with no beepers in the bag
    //     - We will name him theHarvester
    //   - The goal is to remove all the beepers in a fixed world (meaning, the program must work only for this world)
    //     - We will call the method harvestTheField
    //   - The goal of this exercise is to start with creating a battle plan
    //     - Define the problem
    //     - Plan the solution
    //     - Implement the plan
    //     - Analyse and test the solution
    //   - The goal is to have working software
    //     - Program must be easy to read and understand
    //     - Program must be easy to debug
    //     - Program must be easy to modify to solve variations of the original task
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersVersion04(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersVersion04.HarvestTheField()
    // Created
    //   - CopyPaste – 20251013 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251013 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\05.03a WorldFullOfBeepers.kwld");
      World.setVisible(true);
      cpRemoveBeepersVersion04 theHarvester = new cpRemoveBeepersVersion04(2, 2, Directions.East, 0, Color.green);

      theHarvester.HarvestTheField();
      theHarvester.turnOff();
    }
    // RemoveBeepersVersion04()

    public static void RemoveBeepersVersion04MultipleFiles()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the World Full of Beepers specifications
    //   - Make the world visible
    //   - TheHarvester becomes a green remove beepers (version01) starting at position (2, 2), looking to the right with no beepers in the bag
    //     - We will name him theHarvester
    //   - The goal is to remove all the beepers in a fixed world (meaning, the program must work only for this world)
    //     - We will call the method harvestTheField
    //   - The goal of this exercise is to start with creating a battle plan
    //     - Define the problem
    //     - Plan the solution
    //     - Implement the plan
    //     - Analyse and test the solution
    //   - The goal is to have working software
    //     - Program must be easy to read and understand
    //     - Program must be easy to debug
    //     - Program must be easy to modify to solve variations of the original task
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersVersion04MultipleFiles(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersVersion04MultipleFiles.HarvestTheField()
    // Created
    //   - CopyPaste – 20251013 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251013 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\05.03a WorldFullOfBeepers.kwld");
      World.setVisible(true);
      cpRemoveBeepersVersion04MultipleFiles theHarvester = new cpRemoveBeepersVersion04MultipleFiles(2, 2, Directions.East, 0, Color.green);

      theHarvester.HarvestTheField();
      theHarvester.turnOff();
    }
    // RemoveBeepersVersion04MultipleFiles()

    public static void RemoveBeepersVersion05()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the World Full of Beepers specifications
    //   - Make the world visible
    //   - TheHarvester becomes a green remove beepers (version01) starting at position (2, 2), looking to the right with no beepers in the bag
    //     - We will name him theHarvester
    //   - The goal is to remove all the beepers in a fixed world (meaning, the program must work only for this world)
    //     - We will call the method harvestTheField
    //   - The goal of this exercise is to start with creating a battle plan
    //     - Define the problem
    //     - Plan the solution
    //     - Implement the plan
    //     - Analyse and test the solution
    //   - The goal is to have working software
    //     - Program must be easy to read and understand
    //     - Program must be easy to debug
    //     - Program must be easy to modify to solve variations of the original task
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersVersion05(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersVersion05.HarvestTheField()
    // Created
    //   - CopyPaste – 20251020 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251020 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\05.03a WorldFullOfBeepers.kwld");
      World.setVisible(true);
      cpRemoveBeepersVersion05 theHarvester = new cpRemoveBeepersVersion05(2, 2, Directions.East, 0, Color.green);

      theHarvester.HarvestTheField();
      theHarvester.turnOff();
    }
    // RemoveBeepersVersion05()

    public static void RemoveBeepersVersion05MultipleFiles()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the World Full of Beepers specifications
    //   - Make the world visible
    //   - TheHarvester becomes a green remove beepers (version05) starting at position (2, 2), looking to the right with no beepers in the bag
    //     - We will name him theHarvester
    //   - The goal is to remove all the beepers in a fixed world (meaning, the program must work only for this world)
    //     - We will call the method harvestTheField
    //   - The goal of this exercise is to start with creating a battle plan
    //     - Define the problem
    //     - Plan the solution
    //     - Implement the plan
    //     - Analyse and test the solution
    //   - The goal is to have working software
    //     - Program must be easy to read and understand
    //     - Program must be easy to debug
    //     - Program must be easy to modify to solve variations of the original task
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersVersion05MultipleFiles(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersVersion05MultipleFiles.HarvestTheField()
    // Created
    //   - CopyPaste – 20251020 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251020 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\05.03a WorldFullOfBeepers.kwld");
      World.setVisible(true);
      cpRemoveBeepersVersion05MultipleFiles theHarvester = new cpRemoveBeepersVersion05MultipleFiles(2, 2, Directions.East, 0, Color.green);

      theHarvester.HarvestTheField();
      theHarvester.turnOff();
    }
    // RemoveBeepersVersion05MultipleFiles()

    public static void RemoveBeepersVersion06MultipleRobots()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the World Full of Beepers specifications
    //   - Make the world visible
    //   - A robot becomes a green RemoveBeepersVersion06 robot starting at position (2, 2), looking to the right with no beepers in the bag
    //     - We will name him theHarvester01
    //     - We create 2 other robots at other positions
    //   - The goal is to remove all the beepers in a fixed world (meaning, the program must work only for this world)
    //     - All core functionalities are in a class called BadFieldHarvester
    //   - The goal of this exercise is to start with creating a battle plan
    //     - Define the problem
    //     - Plan the solution
    //     - Implement the plan
    //     - Analyse and test the solution
    //   - The goal is to have working software
    //     - Program must be easy to read and understand
    //     - Program must be easy to debug
    //     - Program must be easy to modify to solve variations of the original task
    // Called by
    //   - Task()
    // Calls
    //   - cpRemoveBeepersVersion06MultipleRobots(int, int, Directions.Direction, int, Color)
    //   - cpRemoveBeepersVersion06MultipleRobots.HarvestTwoRows()
    // Created
    //   - CopyPaste – 20251020 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251020 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\04.01 WorldFullOfBeepers.kwld");
      World.setVisible(true);
      cpRemoveBeepersVersion06MultipleRobots theHarvester01 = new cpRemoveBeepersVersion06MultipleRobots(2, 2, Directions.East, 0, Color.green);
      cpRemoveBeepersVersion06MultipleRobots theHarvester02 = new cpRemoveBeepersVersion06MultipleRobots(4, 2, Directions.East, 0, Color.green);
      cpRemoveBeepersVersion06MultipleRobots theHarvester03 = new cpRemoveBeepersVersion06MultipleRobots(6, 2, Directions.East, 0, Color.green);
      theHarvester01.move();
      theHarvester02.move();
      theHarvester03.move();
      theHarvester01.HarvestTwoRows();
      theHarvester02.HarvestTwoRows();
      theHarvester03.HarvestTwoRows();
      theHarvester01.turnOff();
      theHarvester02.turnOff();
      theHarvester03.turnOff();
    }
    // RemoveBeepersVersion05MultipleFiles()

    public static void ReplantFieldMultipleFiles()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the World Full of Beepers specifications
    //   - Make the world visible
    //   - Karel becomes a green robot starting at position (2, 2), looking to the right with infinity beepers in the bag
    //     - We will name him theReplanter
    //   - The goal is to put exactly one beeper on every corner in a fixed world (meaning, the program must work only for this world)
    //     - The world has in every corner, zero, one or two beepers
    //     - We will call the method replantTheField
    //     - All core functionalities are in a class called Replanter
    //   - The goal of this exercise is to start with creating a battle plan
    //     - Define the problem
    //     - Plan the solution
    //     - Implement the plan
    //     - Analyse and test the solution
    //   - The goal is to have working software
    //     - Program must be easy to read and understand
    //     - Program must be easy to debug
    //     - Program must be easy to modify to solve variations of the original task
    // Called by
    //   - Task()
    // Calls
    //   - cpReplantFieldMultipleFiles(int, int, Directions.Direction, int, Color)
    //   - cpReplantFieldMultipleFiles.ReplantTheField()
    // Created
    //   - CopyPaste – 20251016 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251016 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\05.05 WorldFullOfBeepers.kwld");
      World.setVisible(true);
      cpReplantFieldMultipleFiles theReplanter = new cpReplantFieldMultipleFiles(2, 2, Directions.East, Directions.infinity, Color.green);

      theReplanter.ReplantTheField();
      theReplanter.turnOff();
    }
    // ReplantFieldMultipleFiles()

    public static void ResultErrors()
    //***
    // Action
    //   - Create a cpResultErrors instance
    //   - The constructor of the instance starts the action
    // Called by
    //   - Task()
    // Calls
    //   - cpResultErrors()
    // Created
    //   - CopyPaste – 20251011 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251011 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpResultErrors karel = new cpResultErrors();
    }
    // ResultErrors()

    public static void SearchBeeper()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Beeper Somewhere specifications
    //   - Make the world visible
    //   - Karel becomes a green robot starting at position (1, 1), looking to the right with no beepers in the bag
    //   - Karel will search for a beeper somewhere in the world
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpTwoMeterHurdlesRace(int, int, Directions.Direction, int, Color)
    //   - cpTwoMeterHurdlesRace.RunRacePart()
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\07.05 BeeperSomewhere.kwld");
      World.setVisible(true);
      cpCopyPasteRobot karel = new cpCopyPasteRobot(1, 1, Directions.East, 0, Color.green);
      karel.SearchBeeperSomewhereInWorld();
      karel.turnOff();
    }
    // SearchBeeper()

    public static void ShortCircuit()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Robot World specifications
    //   - Make the world visible
    //   - Karel becomes a green robot starting at position (1, 1), looking to the right with no beepers in the bag
    //   - Excecute 2 times the same test programmed in different ways(with a move between)
    //   - Karel moves one forward
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   cpShortCircuit(int, int, Directions.Direction, int, Color)
    //   cpShortCircuit.NextToABeeperAndLeftIsBlocked01()
    //   cpShortCircuit.NextToABeeperAndLeftIsBlocked02()
    // Created
    //   - CopyPaste – 20251012 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251012 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\01.01 The Robot World.kwld");
      World.setVisible(true);
      cpShortCircuit karel = new cpShortCircuit(1, 1, Directions.East, 0, Color.green);

      if (karel.NextToABeeperAndLeftIsBlocked01())
      {
        karel.putBeeper();
      }
      // karel.NextToABeeperAndLeftIsBlocked01()

      karel.move();

      if (karel.NextToABeeperAndLeftIsBlocked01())
      {
        karel.putBeeper();
      }
      // karel.NextToABeeperAndLeftIsBlocked01()

      karel.move();
      karel.turnOff();
    }
    // ShortCircuit()

    public static void SimplyCompleteProgram()
    //***
    // Action
    //   - Create a cpSimplyCompleteProgram instance
    //   - The constructor of the instance starts the action
    // Called by
    //   - Task()
    // Calls
    //   - cpSimplyCompleteProgram()
    // Created
    //   - CopyPaste – 20251011 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251011 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpSimplyCompleteProgram karel = new cpSimplyCompleteProgram();
    }
    // SimplyCompleteProgram()

    public static void StairClimber()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the stairworld specifications
    //   - Make the world visible
    //   - Karel becomes a green stairclimber starting at position (1, 1), looking to the right with no beepers in the bag
    //   - Karel will move up the stairs and get the beeper
    // Called by
    //   - Task()
    // Calls
    //   - cpStairClimber(int, int, Directions.Direction, int, Color)
    //   - cpStairClimber.GetBeeper()
    // Created
    //   - CopyPaste – 20251012 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251012 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\03.04 StairWorld.kwld");
      World.setVisible(true);
      cpStairClimber karel = new cpStairClimber(1, 1, Directions.East, 0, Color.green);

      karel.GetBeeper();
    }
    // StairClimber()

    public static void StairSweeper()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the stairsweeper specifications
    //   - Make the world visible
    //   - Karel becomes a green stairsweeper starting at position (1, 1), looking to the right with no beepers in the bag
    //   - Karel will move up the stairs and get all the beepers
    // Called by
    //   - Task()
    // Calls
    //   - cpStairSweeper(int, int, Directions.Direction, int, Color)
    //   - cpStairSweeper.GetBeeper()
    // Created
    //   - CopyPaste – 20251012 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251012 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\03.05 StairSweeper.kwld");
      World.setVisible(true);
      cpStairSweeper karel = new cpStairSweeper(1, 1, Directions.East, 0, Color.green);

      karel.GetBeeper();
    }
    // StairSweeper()

    public static void StrategyDelegation()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Robot World specifications
    //   - Make the world visible
    //   - Karel becomes a green Abstract Beeper Layer robot starting at position (2, 2), looking to the right with infinity beepers in the bag with a given strategy
    //   - Karel put some beepers (depending on the given strategy)
    //   - Karel moves one forward
    //   - Karel is turned off
    //   - Karel becomes a green Abstract Beeper Layer robot starting at position (3, 2), looking to the right with infinity beepers in the bag with a given strategy
    //   - Karel put some beepers(depending on the given strategy)
    //   - Karel moves one forward
    //   - Karel is turned off
    //   - Karel becomes a green Strategy Beeper Layer Alternative robot starting at position (4, 2), looking to the right with infinity beepers in the bag with a given strategy
    //   - Karel sets its strategy to a Two Beeper Layer Strategy
    //   - Karel put some beepers (depending on the given strategy)
    //   - Karel moves one forward
    //   - Karel sets its strategy to a Three Beeper Layer Strategy
    //   - Karel put some beepers (depending on the given strategy)
    //   - Karel moves one forward
    //   - Karel is turned off
    // Called by
    //   - Task()
    // Calls
    //   - cpStrategyBeeperLayer(int, int, Directions.Direction, int, Color, cpinfStrategy)
    //   - cpStrategyBeeperLayer.PutBeepers()
    //   - cpStrategyBeeperLayerAlternative(int, int, Directions.Direction, int, Color)
    //   - cpStrategyBeeperLayerAlternative.PutBeepers()
    //   - cpStrategyBeeperLayerAlternative.Strategy(cpinfStrategy) (Set)
    //   - cpThreeBeeperLayerStrategy.PutBeepers() (thru delegation)
    //   - cpTwoBeeperLayerStrategy.PutBeepers() (thru delegation)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\01.01 The Robot World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpAbstractBeeperLayer karel = new cpStrategyBeeperLayer(2, 2, Directions.East, Directions.infinity, Color.green, new cpTwoBeeperLayerStrategy());
      karel.PutBeepers();
      karel.move();
      karel.turnOff();
      cpinfStrategy theStrategy = new cpThreeBeeperLayerStrategy();
      karel = new cpStrategyBeeperLayer(3, 2, Directions.East, Directions.infinity, Color.green, theStrategy);
      karel.PutBeepers();
      karel.move();
      karel.turnOff();

      cpStrategyBeeperLayerAlternative karelAlternative = new cpStrategyBeeperLayerAlternative(4, 2, Directions.East, Directions.infinity, Color.green);
      karelAlternative.Strategy = new cpTwoBeeperLayerStrategy();
      karelAlternative.PutBeepers();
      karelAlternative.move();
      karelAlternative.Strategy = theStrategy;
      karelAlternative.PutBeepers();
      karelAlternative.move();
      karelAlternative.turnOff();
    }
    // StrategyDelegation()

    public static void SyntaxErrors()
    //***
    // Action
    //   - Create a cpSyntaxErrors instance
    //   - The constructor of the instance starts the action
    // Called by
    //   - Task()
    // Calls
    //   - cpSyntaxErrors()
    // Created
    //   - CopyPaste – 20251011 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251011 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpSyntaxErrors karel = new cpSyntaxErrors();
    }
    // SyntaxErrors()

    public static void Task()
    //***
    // Action
    //   - Execute a task
    // Called by
    //   - Main()
    // Calls (in logical order)
    //   - MoveOneForward() (finished)
    //   - MoveOneForwardSimply() (finished)
    //   - MoveOneForwardSimplest() (finished)
    //   - MoveTwoForward() (finished)
    //   - MoveOneForwardAndPickBeeperTurnBack() (finished)
    //   - MoveOneForwardAndMoveBeeperOneForwardTurnBack() (finished)
    //   - MoveFiveForwardIn5WideWorldAndOneBack() (finished)
    //   - SimplyCompleteProgram() (finished)
    //   - TwoRobots() (finished)
    //   - LexicalErrors() (finished)
    //   - SyntaxErrors() (finished)
    //   - ExecutionErrors() (finished)
    //   - ResultErrors() (finished)
    //   - OriginSitterLookingNorth() (finished)
    //   - WalkMeter() (finished)
    //   - StairClimber() (finished)
    //   - StairSweeper() (finished)
    //   - WalkMeterOverrideMove() (finished)
    //   - RemoveBeepersVersion01() (finished)
    //   - RemoveBeepersVersion02() (finished)
    //   - RemoveBeepersVersion03() (finished)
    //   - RemoveBeepersVersion01MultipleFiles() (finished)
    //   - RemoveBeepersVersion02MultipleFiles() (finished)
    //   - RemoveBeepersVersion03MultipleFiles() (finished)
    //   - RemoveBeepersVersion04() (finished)
    //   - RemoveBeepersVersion04MultipleFiles() (finished)
    //   - TwoMeterHurdlesRace() (finished)
    //   - ReplantFieldMultipleFiles() (finished)
    //   - ShortCircuit() (finished)
    //   - ForLoop() (finished)
    //   - WhileLoop() (finished)
    //   - RemoveBeepersVersion05() (finished)
    //   - RemoveBeepersVersion05MultipleFiles() (finished)
    //   - RemoveBeepersTillWall() (finished)
    //   - RemoveBeepersTillWallError01() (finished)
    //   - RemoveBeepersTillWallError02() (finished)
    //   - RemoveAllBeepersTillWall() (finished)
    //   - FindBeeperNextToWallInARoom() (finished)
    //   - FindBeeperNextToWallInARoomError() (finished)
    //   - GuardAField() (finished)
    //   - RemoveBeepersVersion06MultipleRobots() (finished)
    //   - TwoDifferentRobots() (finished)
    //   - Choreographer() (finished)
    //   - TwoDifferentRobotsInterface() (finished)
    //   - StrategyDelegation() (finished)
    //   - BlockWalker() (finished)
    //   - Enumeration() (finished)
    //   - Decorator() (finished)
    //   - Observer() (finished)
    //   - ControllerStrategyVersion01() (finished)
    //   - ControllerStrategyVersion02() (finished)
    //   - Recursion() (finished)
    //   - RecursionFindBeeper() (finished)
    //   - SearchBeeper() (finished)
    //   - Calculator() (finished)
    //   - GetterPutter01() (finished)
    //   - GetterPutter02() (finished)
    //   - GetterPutter03() (finished)
    //   - Contractor() (finished)
    //   - ThreadContractor() (finished)
    //   - ThreadRobot() (finished)
    //   - RelayRacer() (finished)
    //   - ThreadRobotFail() (finished)
    //   - ThiefRobotFail() (finished)
    //   - DeadLock() (finished)
    //   - LinkedList() (finished)
    // Created
    //   - CopyPaste – 20251009 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251009 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      MoveOneForward();
      // MoveOneForwardSimply();
      // MoveOneForwardSimplest();
      // MoveTwoForward();
      // MoveOneForwardAndPickBeeperTurnBack();
      // MoveOneForwardAndMoveBeeperOneForwardTurnBack();
      // MoveFiveForwardIn5WideWorldAndOneBack();
      // SimplyCompleteProgram();
      // TwoRobots();
      // LexicalErrors();
      // SyntaxErrors();
      // ExecutionErrors();
      // ResultErrors();
      // OriginSitterLookingNorth();
      // WalkMeter();
      // StairClimber();
      // StairSweeper();
      // WalkMeterOverrideMove();
      // RemoveBeepersVersion01();
      // RemoveBeepersVersion02();
      // RemoveBeepersVersion03();
      // RemoveBeepersVersion01MultipleFiles();
      // RemoveBeepersVersion02MultipleFiles();
      // RemoveBeepersVersion03MultipleFiles();
      // RemoveBeepersVersion04();
      // RemoveBeepersVersion04MultipleFiles();
      // TwoMeterHurdlesRace();
      // ReplantFieldMultipleFiles();
      // ShortCircuit();
      // ForLoop();
      // WhileLoop();
      // RemoveBeepersVersion05();
      // RemoveBeepersVersion05MultipleFiles();
      // RemoveBeepersTillWall();
      // RemoveBeepersTillWallError01();
      // RemoveBeepersTillWallError02();
      // RemoveAllBeepersTillWall();
      // FindBeeperNextToWallInARoom();
      // FindBeeperNextToWallInARoomError();
      // GuardAField();
      // RemoveBeepersVersion06MultipleRobots();
      // TwoDifferentRobots();
      // Choreographer();
      // TwoDifferentRobotsInterface();
      // StrategyDelegation();
      // BlockWalker();
      // Enumeration();
      // Decorator();
      // Observer();
      // ControllerStrategyVersion01();
      // ControllerStrategyVersion02();
      // Recursion();
      // RecursionFindBeeper();
      // SearchBeeper();
      // Calculator();
      // GetterPutter01();
      // GetterPutter02();
      // GetterPutter03();
      // Contractor();
      // ThreadContractor();
      // ThreadRobot();
      // RelayRacer();
      // ThreadRobotFail();
      // ThiefRobotFail();
      // DeadLock();
      // LinkedList();
    }
    // Task()

    public static void ThiefRobotFail()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Thief Beeper World specifications
    //   - Make the world visible
    //   - Create the robots
    //     - RacerGreen becomes a green Thief robot starting at position (3, 4), looking to the bottom with no beepers in the bag
    //     - RacerBlue becomes a blue Thief robot starting at position (2, 3), looking to the right with no beepers in the bag
    // Called by
    //   - Task()
    // Calls
    //   - cpThiefRobotFail(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\08.05 The Thief Beeper World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpThiefRobotFail racerGreen = new cpThiefRobotFail(3, 4, Directions.South, 0, Color.green);
      cpThiefRobotFail racerBlue = new cpThiefRobotFail(2, 3, Directions.East, 0, Color.blue);
    }
    // ThiefRobotFail()

    public static void ThreadContractor()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the House World specifications
    //   - Make the world visible
    //   - Karel becomes a green Contractor robot starting at position (1, 1), looking to the right with infinity beepers in the bag
    //     - In the mean time becomes Bob the Builder a red Mason robot starting at position (1, 1), looking to the right with infinity beepers in the bag
    //     - In the mean time becomes Joseph the Carpenter a yellow Carpenter robot starting at position (1, 1), looking to the right with infinity beepers in the bag
    //     - In the mean time becomes Fidler the Roofer a blue Roofer robot starting at position (1, 1), looking to the right with infinity beepers in the bag
    //   - Karel will delegate some work to subcontractors
    //   - Karel and all helpers are turned off
    // Called by
    //   - Task()
    // Calls
    //   - cpThreadContractor(int, int, Directions.Direction, int, Color)
    //   - cpThreadContractor.cpCarpenterRunner()
    //   - cpThreadContractor.cpMasonRunner()
    //   - cpThreadContractor.cpRooferRunner()
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpThreadContractor.cpCarpenterRunner theCarpenterRunner = new cpThreadContractor.cpCarpenterRunner();
      cpThreadContractor.cpMasonRunner theMasonRunner = new cpThreadContractor.cpMasonRunner();
      cpThreadContractor.cpRooferRunner theRooferRunner = new cpThreadContractor.cpRooferRunner();

      World.reset(); // World is resetted
      World.readWorld("Worlds\\08.01 The House World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpThreadContractor karel = new cpThreadContractor(1, 1, Directions.East, 0, Color.green);

      Thread theCarpenterThread = new Thread(theCarpenterRunner);
      Thread theMasonThread = new Thread(theMasonRunner);
      Thread theRooferThread = new Thread(theRooferRunner);

      theCarpenterThread.start();
      theMasonThread.start();
      theRooferThread.start();
      karel.turnOff();
    }
    // ThreadContractor()

    public static void ThreadRobot()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Beeper World specifications
    //   - Make the world visible
    //   - Create the robots
    //     - RacerGreen becomes a green Thread robot starting at position (1, 1), looking to the right with no beepers in the bag
    //     - RacerBlue becomes a blue Thread robot starting at position (2, 1), looking to the right with no beepers in the bag
    // Called by
    //   - Task()
    // Calls
    //   - cpThreadRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\08.02 The Beeper World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpThreadRobot racerGreen = new cpThreadRobot(1, 1, Directions.East, 0, Color.green);
      cpThreadRobot racerBlue = new cpThreadRobot(2, 1, Directions.East, 0, Color.blue);
    }
    // ThreadRobot()

    public static void ThreadRobotFail()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Beeper World specifications
    //   - Make the world visible
    //   - Create the robots
    //     - RacerGreen becomes a green Thread robot starting at position (2, 8), looking to the left with no beepers in the bag
    //     - RacerBlue becomes a blue Thread robot starting at position (8, 2), looking to the bottom with no beepers in the bag
    // Called by
    //   - Task()
    // Calls
    //   - cpThreadRobotFail(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\08.04 The Beeper World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible

      cpThreadRobotFail racerGreen = new cpThreadRobotFail(2, 8, Directions.West, 0, Color.green);
      cpThreadRobotFail racerBlue = new cpThreadRobotFail(8, 2, Directions.South, 0, Color.blue);
    }
    // ThreadRobotFail()

    public static void TwoDifferentRobots()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Robot World specifications
    //   - Make the world visible
    //   - Karel becomes an cpAbstractBeeperLayer with value null
    //   - Karel becomes a green Two Beeper Layer robot starting at position (1, 3), looking to the right with infinity beepers in the bag
    //   - Karel lay some beepers according to the Two Beeper Layer specifications
    //   - Karel is switched off
    //   - Karel becomes a blue Three Beeper Layer robot starting at position (2, 3), looking to the right with infinity beepers in the bag
    //   - Karel lay some beepers according to the Three Beeper Layer specifications
    //   - Karel is switched off
    //   - Karel becomes a green Two Beeper Layer robot starting at position (3, 3), looking to the right with infinity beepers in the bag
    //   - Karel lay some beepers according to the Two Beeper Layer specifications
    //   - Karel is switched off
    //   - Karel becomes a blue Three Beeper Layer robot starting at position (4, 3), looking to the right with infinity beepers in the bag
    //   - Karel lay some beepers according to the Three Beeper Layer specifications
    //   - Karel is switched off
    //   - Karel becomes a green Two Beeper Layer robot starting at position (5, 3), looking to the right with infinity beepers in the bag
    //   - Karel lay some beepers according to the Two Beeper Layer specifications
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpTwoBeeperLayer(int, int, Directions.Direction, int, Color) 
    //   - cpThreeBeeperLayer(int, int, Directions.Direction, int, Color) 
    //   - cpAbstractBeeperLayer.LayBeepers()
    //   - cpThreeBeeperLayer.LayBeepers()
    //   - cpTwoBeeperLayer.LayBeepers()
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\01.01 The Robot World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible
      cpAbstractBeeperLayer karel = null;
      karel = new cpTwoBeeperLayer(1, 3, Directions.East, Directions.infinity, Color.green);
      karel.LayBeepers();
      karel.turnOff();
      karel = new cpThreeBeeperLayer(2, 3, Directions.East, Directions.infinity, Color.blue);
      karel.LayBeepers();
      karel.turnOff();
      karel = new cpTwoBeeperLayer(3, 3, Directions.East, Directions.infinity, Color.green);
      karel.LayBeepers();
      karel.turnOff();
      karel = new cpThreeBeeperLayer(4, 3, Directions.East, Directions.infinity, Color.blue);
      karel.LayBeepers();
      karel.turnOff();
      karel = new cpTwoBeeperLayer(5, 3, Directions.East, Directions.infinity, Color.green);
      karel.LayBeepers();
      karel.turnOff();
    }
    // TwoDifferentRobots()

    public static void TwoDifferentRobotsInterface()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Robot World specifications
    //   - Make the world visible
    //   - Karel becomes a green No Neighbour robot starting at position (1, 1), looking to the top with 1 beeper in the bag
    //   - A bunch of blue Neighbour Talker robots are created next to the first robot in one line, looking to the top with 1 beeper in the bag
    //   - Karel distribute the beepers
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpinfcpinfBeeperPutter.DistributeBeepers()
    //   - cpinfcpinfBeeperPutter.SwitchOff()
    //   - cpNoNeighbour(int, int, Directions.Direction, int, Color)
    //   - cpNoNeighBour.DistributeBeepers()
    //   - cpNoNeighbourTalker(int, int, Directions.Direction, int, Color, cpinfBeeperPutter)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset(); // World is resetted
      World.readWorld("Worlds\\01.01 The Robot World.kwld"); // World is created with specifications
      World.setVisible(true); // World is made visible
      cpinfBeeperPutter karel = new cpNoNeighbour(1, 1, Directions.North, 1, Color.green);

      karel = new cpNeighbourTalker(1, 2, Directions.North, 1, Color.blue, karel);
      karel = new cpNeighbourTalker(1, 3, Directions.North, 1, Color.blue, karel);
      karel = new cpNeighbourTalker(1, 4, Directions.North, 1, Color.blue, karel);
      karel = new cpNeighbourTalker(1, 5, Directions.North, 1, Color.blue, karel);
      karel = new cpNeighbourTalker(1, 6, Directions.North, 1, Color.blue, karel);
      karel = new cpNeighbourTalker(1, 7, Directions.North, 1, Color.blue, karel);
      karel.DistributeBeepers();
      karel.SwitchOff();
    }
    // TwoDifferentRobotsInterface()

    public static void TwoMeterHurdlesRace()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Two Meter Hurdles Race specifications
    //   - Make the world visible
    //   - Karel becomes a green Two Meter Hurdles Race robot starting at position (1, 1), looking to the right with no beepers in the bag
    //   - Karel has to jump over the hurdles and reach the finish
    //   - Karel must succeed, wherever the hurdles are placed
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpTwoMeterHurdlesRace(int, int, Directions.Direction, int, Color)
    //   - cpTwoMeterHurdlesRace.RunRacePart()
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\05.04 Hurdles.kwld");
      World.setVisible(true);
      cpTwoMeterHurdlesRace karel = new cpTwoMeterHurdlesRace(1, 1, Directions.East, 0, Color.green);
      karel.RunRacePart();
      karel.RunRacePart();
      karel.RunRacePart();
      karel.RunRacePart();
      karel.RunRacePart();
      karel.RunRacePart();
      karel.RunRacePart();
      karel.RunRacePart();
      karel.turnOff();
    }
    // TwoMeterHurdlesRace()

    public static void TwoRobots()
    //***
    // Action
    //   - Create a cpTwoRobots instance
    //   - The constructor of the instance starts the action
    // Called by
    //   - Task()
    // Calls
    //   - cpTwoRobots()
    // Created
    //   - CopyPaste – 20251011 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251011 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpTwoRobots karel = new cpTwoRobots();
    }
    // TwoRobots()

    public static void WalkMeter()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Big Robot World specifications
    //   - Make the world visible
    //   - Karel becomes a green WalkMeter robot starting at position (1, 1), looking to the East with no beepers in the bag
    //   - Karel moves a meter
    //   - Karel turns left
    //   - Karel moves a meter twice
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpWalkMeter()
    //   - cpWalkMeter.MoveMeter()
    // Created
    //   - CopyPaste – 20251011 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251011 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\03.03 The Big Robot World.kwld");
      World.setVisible(true);
      cpWalkMeter karel = new cpWalkMeter();

      karel.MoveMeter(); // Move a meter in the direction karel is looking
      karel.turnLeft(); // Looking up (to the North)
      karel.MoveMeter(); // Move a meter in the direction karel is looking
      karel.MoveMeter(); // Move a meter in the direction karel is looking
      karel.turnOff();
    }
    // WalkMeter()

    public static void WalkMeterOverrideMove()
    //***
    // Action
    //   - Reset the world
    //   - Build the world according to the Big Robot World specifications
    //   - Make the world visible
    //   - Karel becomes a green WalkMeterOverrideMove robot starting at position (1, 1), looking to the East with no beepers in the bag
    //   - Karel moves a meter (by overriding move)
    //   - Karel turns left
    //   - Karel moves a meter twice
    //   - Karel is switched off
    // Called by
    //   - Task()
    // Calls
    //   - cpWalkMeterOverrideMove()
    //   - cpWalkMeterOverrideMove.move()
    // Created
    //   - CopyPaste – 20251012 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251012 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\03.03 The Big Robot World.kwld");
      World.setVisible(true);
      cpWalkMeterOverrideMove karel = new cpWalkMeterOverrideMove();

      karel.move(); // Move a meter in the direction karel is looking
      karel.turnLeft(); // Looking up (to the North)
      karel.move(); // Move a meter in the direction karel is looking
      karel.move(); // Move a meter in the direction karel is looking
      karel.turnOff();
    }
    // WalkMeterOverrideMove()

    public static void WhileLoop()
    //***
    // Action
    //   - Create a cpWhile instance
    // Called by
    //   - Task()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251020 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251020 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpWhile karel = new cpWhile(1, 1, Directions.East, 0, Color.green);
    }
    // WhileLoop()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// cpKarelTheRobot