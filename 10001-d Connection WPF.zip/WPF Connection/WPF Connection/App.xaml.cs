﻿//***
// Action
//   - Class implements the Application-level events
// Created
//   - CopyPaste – 20210806 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210806 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System.Windows;

namespace WPFConnection
{
  public partial class App : Application
  {

  //#region "Constructors / Destructors"
  //#endregion

  //#region "Designer"
  //#endregion

  //#region "Structures"
  //#endregion

  //#region "Fields"
  //#endregion

  //#region "Properties"
  //#endregion

  //#region "Methods"

  //#region "Overrides"
  //#endregion

  //#region "Controls"
  //#endregion

  //#region "Functionality"

  //#region "Event"
  //#endregion

  //#region "Sub / Function"
  //#endregion

  //#endregion

  //#endregion

  //#region "Not used"
  //#endregion
  
  }
  // App 

}
// WPFConnection
