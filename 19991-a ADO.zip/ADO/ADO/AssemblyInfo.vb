Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("ADO")>
<Assembly: AssemblyDescription("Copy Paste Example Visual Basic .NET 2019")>
<Assembly: AssemblyCompany("Copy Paste")> 
<Assembly: AssemblyProduct("ADO")> 
<Assembly: AssemblyCopyright("Copy Paste Classroom")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("08B8BD45-236E-4CCA-953A-C525D09547E3")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.0.0")> 
