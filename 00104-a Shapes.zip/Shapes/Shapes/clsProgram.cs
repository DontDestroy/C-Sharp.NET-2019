//'***
//' Action
//'   - Testroutine for cpCircle, cpCylinder, cpPoint and cpShape
//'   - Showing the way polymorphisme works
//' Created
//'   - CopyPaste � 20230811 � VVDW
//' Changed
//'   - CopyPaste � yyyymmdd � VVDW � What changed
//' Tested
//'   - CopyPaste � 20230811 � VVDW
//' Proposal (To Do)
//'   -
//'***

using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThread]
    static void Main()
      //***
      // Action
      //   - Create an array of 6 cpShapes
      //   - Define a cpCircle
      //   - Define a cpCylinder
      //   - Define a cpPoint
      //   - Define a cpShape
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpCircle.Name() As String (Get)
      //   - cpCircle.New(Int32, Int32, Double)
      //   - cpCircle.ToString() As String)
      //   - cpCylinder.Name() As String (Get)
      //   - cpCylinder.New(Int32, Int32, Double, Double)
      //   - cpCylinder.ToString() As String)
      //   - cpPoint.Name() As String (Get)
      //   - cpPoint.New(Int32, Int32)
      //   - cpPoint.ToString() As String)
      //   - cpShape.Area() As Double
      //   - cpShape.Name() As String (Get)
      //   - cpShape.ToString() As String
      //   - cpShape.Volume() As Double
      // Created
      //   - CopyPaste � 20230811 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230811 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpShape[] arrShape = new cpShape[6];
      string strOutput = "";

      cpCircle thecpCircle = new cpCircle(22, 8, 3.5);
      cpCylinder thecpCylinder = new cpCylinder(10, 10, 3.3, 10);
      cpPoint thecpPoint = new cpPoint(7, 11);

      cpCircle thecpCircleWithPoint = new cpCircle(thecpPoint, 5);
      cpCylinder thecpCylinderWithPoint = new cpCylinder(thecpPoint, 5, 10);
      cpCylinder thecpCylinderWithCircle = new cpCylinder(thecpCircle, 10);

      arrShape[0] = thecpPoint;
      arrShape[1] = thecpCircle;
      arrShape[2] = thecpCylinder;
      arrShape[3] = thecpCircleWithPoint;
      arrShape[4] = thecpCylinderWithPoint;
      arrShape[5] = thecpCylinderWithCircle;

      strOutput = thecpPoint.Name + ": " + thecpPoint.ToString() + ControlChars.CrLf +
        thecpCircle.Name + ": " + thecpCircle.ToString() + ControlChars.CrLf +
        thecpCylinder.Name + ": " + thecpCylinder.ToString();

      foreach (cpShape thecpShape in arrShape)
      {
        strOutput += ControlChars.CrLf + ControlChars.CrLf +
          thecpShape.Name + ": " + thecpShape.ToString() + ControlChars.CrLf +
          "Area = " + String.Format("{0:F}", thecpShape.Area()) + ControlChars.CrLf +
          "Volume = " + String.Format("{0:F}", thecpShape.Volume());
      }
      // In arrShape

    MessageBox.Show(strOutput, "Demonstrating Polymorphism");
  }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning