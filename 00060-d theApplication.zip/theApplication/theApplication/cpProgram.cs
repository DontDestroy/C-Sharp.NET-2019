﻿using System;
using System.Windows;

namespace theApplication
{
  public class cpProgram
  {
    [STAThread()]
    static void Main()
    {
      Application theApplication = new Application();  // Create instance of Application
      cpWindow cpStartupScreen = new cpWindow(); // create instance of cpWindow

      // Option 1
      theApplication.Run(cpStartupScreen); // Start the application with the Startup screen

      // Option 2
      // theApplication.MainWindow = cpStartupScreen;
      // cpStartupScreen.Show();
      // theApplication.Run();
    }
    // Main()

  }
  // cpProgram

}
// theApplication
