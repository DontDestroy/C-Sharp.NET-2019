//***
// Action
//   - Definition interface of a cpiShape
// Created
//   - CopyPaste � 20230818 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230818 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public interface cpiShape
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    string Name {get;}
    // string Name (Get)

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    double Area();
    // double Area()
    string ToString();
    // string ToString()
    double Volume();
    // double Volume()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpiShape

}
// CopyPaste.Learning