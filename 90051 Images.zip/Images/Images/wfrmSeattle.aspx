﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmSeattle.aspx.cs" Inherits="CopyPaste.Learning.wfrmSeattle" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>myPod: Seattle Ferry</title>
  <style>
    body {
      background-color: #eaf3da;
    }
  </style>
</head>
<body>
  <form id="wfrmSeattle">
    <h1>Video iPod on the Seattle Ferry</h1>
    <p>
      <img src="./Resources/Seattle_Medium.jpg" alt="The skyline of Seattle" />
    </p>
  </form>
</body>
</html>
