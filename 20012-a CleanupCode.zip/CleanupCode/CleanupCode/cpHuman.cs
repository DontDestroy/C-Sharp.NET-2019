﻿//***
// Action
//   - Definition of a cpHuman
// Created
//   - CopyPaste – 20251223 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251223 – VVDW
// Proposal (To Do)
//   - 
//***

namespace CopyPaste.Learning
{

  public class cpHuman
  {

    #region "Constructors / Destructors"

    public cpHuman(string strFirstName, string strLastName, int intAge)
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - 
    // Calls
    //   - Age(int) (Set)
    //   - FirstName(string) (Set)
    //   - LastName(string) (Set)
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Age = intAge;
      FirstName = strFirstName;
      LastName = strLastName;
    }
    // cpHuman(string, string, int)

    #endregion

    #region "Designer"

    public enum NameOrder
    {
      FirstLast,
      LastFirst
    }
    // NameOrder

    #endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public int Age { get; set; }
    // cpHuman(string, string, int)
    // string ToString()

    public string FirstName { get; set; }
    // cpHuman(string, string, int)
    // string ToString()

    public string LastName { get; set; }
    // cpHuman(string, string, int)
    // string ToString()

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
    //***
    // Action
    //   - The default information of cpHuman
    // Called by
    //   - 
    // Calls
    //   - int Age (Get)
    //   - string FirstName (Get)
    //   - string LastName (Get)
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return $"{FirstName} {LastName} is {Age} years old";
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string FullName(NameOrder theNameOrder)
    {
      string strReturn;

      switch (theNameOrder)
      {
        case NameOrder.FirstLast:
          strReturn = $"{FirstName} {LastName}";
          break;
        case NameOrder.LastFirst:
          strReturn = $"{LastName} {FirstName}";
          break;
        default:
          strReturn = $"{FirstName} {LastName}";
          break;
      }
      // (theNameOrder)

      return strReturn;

      // VVDW - The code below is valid from version C# 8.0
      // return theNameOrder switch
      // {
      //   NameOrder.FirstLast => $"{FirstName} {LastName}",
      //   NameOrder.LastFirst => $"{LastName} {FirstName}",
      //   _ => $"{FirstName} {LastName}"
      // };

    }
    // string FullName(NameOrder)

      #endregion

      #endregion

      #endregion

      //#region "Not used"
      //#endregion

    }
  // cpHuman

}
// CopyPaste.Learning