//***
// Action
//   - Use of private variables
// Created
//   - CopyPaste � 20220128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220128 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Private
{

  public class cpPrivate
	{
    private const decimal decCmInch = 2.54M;
    static long lngNumberOfConversions;

    static void Main()
    //***
    // Action
    //   - Calculate 100 cm to inches
    //   - Calculate 3 inches to centimeter
    //   - Show results at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    //   - ToCm(decimal)
    //   - ToInch(decimal)
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      ToInch(100);
      ToCm(3);
      Console.WriteLine("Conversions : {0}", lngNumberOfConversions);
      Console.ReadLine();
    }
    // Main()

    static void ToCm(decimal decInch)
    //***
    // Action
    //   - Calculate inches to centimeter
    //   - Add 1 to 'lngNumberOfConversions'
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string, System.Object, System.Object)
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      lngNumberOfConversions += 1;
      Console.WriteLine("{0} inch = {1} cm", decInch, decInch * decCmInch);
    }
    // ToCm(decimal)

    static void ToInch(decimal decCm)
    //***
    // Action
    //   - Calculate centimeter to inches
    //   - Add 1 to 'lngNumberOfConversions'
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string, System.Object, System.Object)
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      lngNumberOfConversions += 1;
      Console.WriteLine("{0} cm = {1} inch", decCm, decCm / decCmInch);
    }
    // ToInch(decimal)

  }
  // cpPrivate

}
// Private