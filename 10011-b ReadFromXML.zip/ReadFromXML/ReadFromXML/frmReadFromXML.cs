//***
// Action
//   - Use a written XML file as data source
// Created
//   - CopyPaste � 20251125 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251125 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Xml;

namespace CopyPaste.Learning
{

  public class frmReadXML: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdPopulate;
    internal System.Windows.Forms.DataGrid dgrDataGrid;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmReadXML));
      this.cmdPopulate = new System.Windows.Forms.Button();
      this.dgrDataGrid = new System.Windows.Forms.DataGrid();
      ((System.ComponentModel.ISupportInitialize)(this.dgrDataGrid)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdPopulate
      // 
      this.cmdPopulate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdPopulate.Location = new System.Drawing.Point(78, 229);
      this.cmdPopulate.Name = "cmdPopulate";
      this.cmdPopulate.Size = new System.Drawing.Size(128, 31);
      this.cmdPopulate.TabIndex = 3;
      this.cmdPopulate.Text = "&Populate from XML";
      this.cmdPopulate.Click += new System.EventHandler(this.cmdPopulate_Click);
      // 
      // dgrDataGrid
      // 
      this.dgrDataGrid.AlternatingBackColor = System.Drawing.Color.LightGoldenrodYellow;
      this.dgrDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrDataGrid.BackColor = System.Drawing.Color.White;
      this.dgrDataGrid.BackgroundColor = System.Drawing.Color.LightGoldenrodYellow;
      this.dgrDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.dgrDataGrid.CaptionBackColor = System.Drawing.Color.LightGoldenrodYellow;
      this.dgrDataGrid.CaptionFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
      this.dgrDataGrid.CaptionForeColor = System.Drawing.Color.DarkSlateBlue;
      this.dgrDataGrid.DataMember = "";
      this.dgrDataGrid.FlatMode = true;
      this.dgrDataGrid.Font = new System.Drawing.Font("Tahoma", 8F);
      this.dgrDataGrid.ForeColor = System.Drawing.Color.DarkSlateBlue;
      this.dgrDataGrid.GridLineColor = System.Drawing.Color.Peru;
      this.dgrDataGrid.GridLineStyle = System.Windows.Forms.DataGridLineStyle.None;
      this.dgrDataGrid.HeaderBackColor = System.Drawing.Color.Maroon;
      this.dgrDataGrid.HeaderFont = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold);
      this.dgrDataGrid.HeaderForeColor = System.Drawing.Color.LightGoldenrodYellow;
      this.dgrDataGrid.LinkColor = System.Drawing.Color.Maroon;
      this.dgrDataGrid.Location = new System.Drawing.Point(14, 12);
      this.dgrDataGrid.Name = "dgrDataGrid";
      this.dgrDataGrid.ParentRowsBackColor = System.Drawing.Color.BurlyWood;
      this.dgrDataGrid.ParentRowsForeColor = System.Drawing.Color.DarkSlateBlue;
      this.dgrDataGrid.SelectionBackColor = System.Drawing.Color.DarkSlateBlue;
      this.dgrDataGrid.SelectionForeColor = System.Drawing.Color.GhostWhite;
      this.dgrDataGrid.Size = new System.Drawing.Size(264, 201);
      this.dgrDataGrid.TabIndex = 2;
      // 
      // frmReadXML
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdPopulate);
      this.Controls.Add(this.dgrDataGrid);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmReadXML";
      this.Text = "Read from XML";
      ((System.ComponentModel.ISupportInitialize)(this.dgrDataGrid)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmReadXML'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251125 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251125 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmReadXML()
      //***
      // Action
      //   - Create instance of 'frmReadXML'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251125 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251125 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdPopulate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Read an XML file and use it as base to fill a form
      //   - Create a new data set
      //   - Read the file with a file stream
      //   - Use the file stream to read it as XML (with a XMLTextReader)
      //   - Fill the data set by reading the XML
      //   - Close the XMLTextReader
      //   - Set the properties of the data grid
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251125 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251125 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DataSet dsDataSet = new DataSet();
      string strFilename = "T:\\SqlXML.xml";
      FileStream theFileStream = new FileStream(strFilename, FileMode.Open);
      XmlTextReader strReaderXML = new XmlTextReader(theFileStream);

      dsDataSet.ReadXml(strReaderXML);
      strReaderXML.Close();

      dgrDataGrid.CaptionText = "Populated from XML";
      dgrDataGrid.DataSource = dsDataSet;
      dgrDataGrid.AllowSorting = true;
      dgrDataGrid.AlternatingBackColor = System.Drawing.Color.Bisque;
      dgrDataGrid.SetDataBinding(dsDataSet, "tblCPCategory");
    }
    // cmdPopulate_Click(System.Object, System.EventArgs) Handles cmdPopulate.Click
  
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmReadXML
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmReadXML()
      // Created
      //   - CopyPaste � 20251125 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251125 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmReadXML());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmReadXML

}
// CopyPaste.Learning