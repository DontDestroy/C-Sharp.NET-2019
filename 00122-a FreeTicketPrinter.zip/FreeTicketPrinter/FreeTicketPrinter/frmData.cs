//***
// Action
//   - Demo of toolbar, menubar, statusbar, splashscreen and printing a document
// Created
//   - CopyPaste � 20240529 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240529 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmData: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    internal System.Windows.Forms.TextBox txtName;
    internal System.Drawing.Printing.PrintDocument prndocTicket;
    internal System.Windows.Forms.StatusBarPanel stpTime;
    internal System.Windows.Forms.MainMenu mnuMain;
    internal System.Windows.Forms.MenuItem MenuItem1;
    internal System.Windows.Forms.MenuItem mnuTicketPrint;
    internal System.Windows.Forms.MenuItem mnuTicketClear;
    internal System.Windows.Forms.Timer tmrTime;
    internal System.Windows.Forms.Button cmdClear;
    internal System.Windows.Forms.ToolBarButton tbbClear;
    internal System.Windows.Forms.Button cmdPrint;
    internal System.Windows.Forms.DateTimePicker dtpDate;
    internal System.Windows.Forms.ComboBox cmbDepartment;
    internal System.Windows.Forms.TextBox txtAddress;
    internal System.Windows.Forms.TextBox txtFirstName;
    internal System.Windows.Forms.Label lblDate;
    internal System.Windows.Forms.Label lblAdres;
    internal System.Windows.Forms.ImageList ilsToolBar;
    internal System.Windows.Forms.Label lblFirstName;
    internal System.Windows.Forms.StatusBarPanel stpDate;
    internal System.Windows.Forms.Label lblName;
    internal System.Windows.Forms.StatusBar stbTicket;
    internal System.Windows.Forms.ToolBarButton tbbPrint;
    internal System.Windows.Forms.Label lblDepartment;
    internal System.Windows.Forms.ToolBar tlbTicket;
    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmData));
      this.txtName = new System.Windows.Forms.TextBox();
      this.prndocTicket = new System.Drawing.Printing.PrintDocument();
      this.stpTime = new System.Windows.Forms.StatusBarPanel();
      this.mnuMain = new System.Windows.Forms.MainMenu();
      this.MenuItem1 = new System.Windows.Forms.MenuItem();
      this.mnuTicketPrint = new System.Windows.Forms.MenuItem();
      this.mnuTicketClear = new System.Windows.Forms.MenuItem();
      this.tmrTime = new System.Windows.Forms.Timer(this.components);
      this.cmdClear = new System.Windows.Forms.Button();
      this.tbbClear = new System.Windows.Forms.ToolBarButton();
      this.cmdPrint = new System.Windows.Forms.Button();
      this.dtpDate = new System.Windows.Forms.DateTimePicker();
      this.cmbDepartment = new System.Windows.Forms.ComboBox();
      this.txtAddress = new System.Windows.Forms.TextBox();
      this.txtFirstName = new System.Windows.Forms.TextBox();
      this.lblDate = new System.Windows.Forms.Label();
      this.lblAdres = new System.Windows.Forms.Label();
      this.ilsToolBar = new System.Windows.Forms.ImageList(this.components);
      this.lblFirstName = new System.Windows.Forms.Label();
      this.stpDate = new System.Windows.Forms.StatusBarPanel();
      this.lblName = new System.Windows.Forms.Label();
      this.stbTicket = new System.Windows.Forms.StatusBar();
      this.tbbPrint = new System.Windows.Forms.ToolBarButton();
      this.lblDepartment = new System.Windows.Forms.Label();
      this.tlbTicket = new System.Windows.Forms.ToolBar();
      ((System.ComponentModel.ISupportInitialize)(this.stpTime)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.stpDate)).BeginInit();
      this.SuspendLayout();
      // 
      // txtName
      // 
      this.txtName.Location = new System.Drawing.Point(64, 56);
      this.txtName.Name = "txtName";
      this.txtName.Size = new System.Drawing.Size(104, 20);
      this.txtName.TabIndex = 16;
      this.txtName.Text = "";
      // 
      // prndocTicket
      // 
      this.prndocTicket.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.prndocTicket_PrintPage);
      // 
      // stpTime
      // 
      this.stpTime.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
      this.stpTime.Width = 10;
      // 
      // mnuMain
      // 
      this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.MenuItem1});
      // 
      // MenuItem1
      // 
      this.MenuItem1.Index = 0;
      this.MenuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.mnuTicketPrint,
                                                                              this.mnuTicketClear});
      this.MenuItem1.Text = "&Ticket";
      // 
      // mnuTicketPrint
      // 
      this.mnuTicketPrint.Index = 0;
      this.mnuTicketPrint.Text = "&Print";
      this.mnuTicketPrint.Click += new System.EventHandler(this.mnuTicketPrint_Click);
      // 
      // mnuTicketClear
      // 
      this.mnuTicketClear.Index = 1;
      this.mnuTicketClear.Text = "&Clear";
      this.mnuTicketClear.Click += new System.EventHandler(this.mnuTicketClear_Click);
      // 
      // tmrTime
      // 
      this.tmrTime.Enabled = true;
      this.tmrTime.Interval = 1000;
      this.tmrTime.Tick += new System.EventHandler(this.tmrTime_Tick);
      // 
      // cmdClear
      // 
      this.cmdClear.Location = new System.Drawing.Point(16, 216);
      this.cmdClear.Name = "cmdClear";
      this.cmdClear.TabIndex = 25;
      this.cmdClear.Text = "&Clear";
      this.cmdClear.Click += new System.EventHandler(this.cmdClear_Click);
      // 
      // tbbClear
      // 
      this.tbbClear.ImageIndex = 1;
      // 
      // cmdPrint
      // 
      this.cmdPrint.Location = new System.Drawing.Point(104, 216);
      this.cmdPrint.Name = "cmdPrint";
      this.cmdPrint.TabIndex = 26;
      this.cmdPrint.Text = "&Print";
      this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
      // 
      // dtpDate
      // 
      this.dtpDate.Location = new System.Drawing.Point(64, 168);
      this.dtpDate.Name = "dtpDate";
      this.dtpDate.TabIndex = 24;
      // 
      // cmbDepartment
      // 
      this.cmbDepartment.Items.AddRange(new object[] {
                                                       "Finance",
                                                       "Office",
                                                       "Research And Development"});
      this.cmbDepartment.Location = new System.Drawing.Point(256, 56);
      this.cmbDepartment.Name = "cmbDepartment";
      this.cmbDepartment.Size = new System.Drawing.Size(104, 21);
      this.cmbDepartment.TabIndex = 18;
      // 
      // txtAddress
      // 
      this.txtAddress.Location = new System.Drawing.Point(64, 120);
      this.txtAddress.Multiline = true;
      this.txtAddress.Name = "txtAddress";
      this.txtAddress.Size = new System.Drawing.Size(200, 40);
      this.txtAddress.TabIndex = 22;
      this.txtAddress.Text = "";
      // 
      // txtFirstName
      // 
      this.txtFirstName.Location = new System.Drawing.Point(88, 88);
      this.txtFirstName.Name = "txtFirstName";
      this.txtFirstName.Size = new System.Drawing.Size(80, 20);
      this.txtFirstName.TabIndex = 20;
      this.txtFirstName.Text = "";
      // 
      // lblDate
      // 
      this.lblDate.Location = new System.Drawing.Point(8, 168);
      this.lblDate.Name = "lblDate";
      this.lblDate.Size = new System.Drawing.Size(48, 23);
      this.lblDate.TabIndex = 23;
      this.lblDate.Text = "&Date";
      // 
      // lblAdres
      // 
      this.lblAdres.Location = new System.Drawing.Point(8, 120);
      this.lblAdres.Name = "lblAdres";
      this.lblAdres.Size = new System.Drawing.Size(48, 23);
      this.lblAdres.TabIndex = 21;
      this.lblAdres.Text = "&Address";
      // 
      // ilsToolBar
      // 
      this.ilsToolBar.ImageSize = new System.Drawing.Size(16, 16);
      this.ilsToolBar.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilsToolBar.ImageStream")));
      this.ilsToolBar.TransparentColor = System.Drawing.Color.Transparent;
      // 
      // lblFirstName
      // 
      this.lblFirstName.Location = new System.Drawing.Point(8, 88);
      this.lblFirstName.Name = "lblFirstName";
      this.lblFirstName.Size = new System.Drawing.Size(80, 23);
      this.lblFirstName.TabIndex = 19;
      this.lblFirstName.Text = "&FirstName";
      // 
      // stpDate
      // 
      this.stpDate.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Contents;
      this.stpDate.Width = 10;
      // 
      // lblName
      // 
      this.lblName.Location = new System.Drawing.Point(8, 56);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(48, 23);
      this.lblName.TabIndex = 15;
      this.lblName.Text = "&Name";
      // 
      // stbTicket
      // 
      this.stbTicket.Location = new System.Drawing.Point(0, 251);
      this.stbTicket.Name = "stbTicket";
      this.stbTicket.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
                                                                                 this.stpDate,
                                                                                 this.stpTime});
      this.stbTicket.ShowPanels = true;
      this.stbTicket.Size = new System.Drawing.Size(376, 22);
      this.stbTicket.TabIndex = 27;
      // 
      // tbbPrint
      // 
      this.tbbPrint.ImageIndex = 0;
      // 
      // lblDepartment
      // 
      this.lblDepartment.Location = new System.Drawing.Point(184, 56);
      this.lblDepartment.Name = "lblDepartment";
      this.lblDepartment.Size = new System.Drawing.Size(64, 23);
      this.lblDepartment.TabIndex = 17;
      this.lblDepartment.Text = "&Department";
      // 
      // tlbTicket
      // 
      this.tlbTicket.Buttons.AddRange(new System.Windows.Forms.ToolBarButton[] {
                                                                                 this.tbbClear,
                                                                                 this.tbbPrint});
      this.tlbTicket.DropDownArrows = true;
      this.tlbTicket.ImageList = this.ilsToolBar;
      this.tlbTicket.Location = new System.Drawing.Point(0, 0);
      this.tlbTicket.Name = "tlbTicket";
      this.tlbTicket.ShowToolTips = true;
      this.tlbTicket.Size = new System.Drawing.Size(376, 28);
      this.tlbTicket.TabIndex = 14;
      this.tlbTicket.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.tlbTicket_ButtonClick);
      // 
      // frmData
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(376, 273);
      this.Controls.Add(this.cmbDepartment);
      this.Controls.Add(this.txtAddress);
      this.Controls.Add(this.txtFirstName);
      this.Controls.Add(this.lblDate);
      this.Controls.Add(this.lblAdres);
      this.Controls.Add(this.lblFirstName);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.stbTicket);
      this.Controls.Add(this.lblDepartment);
      this.Controls.Add(this.tlbTicket);
      this.Controls.Add(this.txtName);
      this.Controls.Add(this.cmdClear);
      this.Controls.Add(this.cmdPrint);
      this.Controls.Add(this.dtpDate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mnuMain;
      this.Name = "frmData";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Print Label";
      this.Load += new System.EventHandler(this.frmData_Load);
      this.Closed += new System.EventHandler(this.frmData_Closed);
      ((System.ComponentModel.ISupportInitialize)(this.stpTime)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.stpDate)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmData'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmData()
      //***
      // Action
      //   - Create instance of 'frmData'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmData()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdClear_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Clear the form (back to its original state)
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - Clear()
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - 
      //***
    {
      Clear();
    }
    // cmdClear_Click(System.Object, System.EventArgs) Handles cmdClear.Click

    private void cmdPrint_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Print the document
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - Print()
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - 
      //***
    {
      Print();
    }
    // cmdPrint_Click(System.Object, System.EventArgs) Handles cmdPrint.Click

    private void frmData_Closed(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - End the application
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Exit();
    }
    // frmData_Closed(System.Object, System.EventArgs) Handles this.Closed

    private void frmData_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the date to today
      //   - Set the statusbar correct
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - 
      //***
    {
      dtpDate.Value = DateTime.Today;

      stpDate.Text = DateTime.Today.ToShortDateString();
      stpTime.Text = DateTime.Now.ToShortTimeString();
    }
    // frmData_Load(System.Object, System.EventArgs) Handles this.Load

    private void mnuTicketClear_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Clear the screen (back to original state)
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - Clear()
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - 
      //***
    {
      Clear();
    }
    // mnuTicketClear_Click(System.Object, .EventArgs) Handles mnuTicketClear.Click

    private void mnuTicketPrint_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Print the ticket
      // Called by
      //   - User action (Clicking a menuitem)
      // Calls
      //   - Print()
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - 
      //***
    {
      Print();
    }
    // mnuTicketPrint_Click(System.Object, System.EventArgs) Handles mnuTicketPrint.Click

    private void prndocTicket_PrintPage(System.Object theSender, PrintPageEventArgs thePrintPageEventArguments)
      //***
      // Action
      //   - Set up the page to print
      //   - Replace enters of address into ", "
      //   - Define a brush (the color to print)
      //   - Define a font (take the font of the textbox of the address)
      //   - Set the date on the document on a certain calculated position
      //   - Change lngCounter (to recalculate the position)
      //   - Repeat the actions for
      //     - Name, Address, Department, a certain text, Date
      // Called by
      //   - System action (Printing a page)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngCounter;
      string strAddress = txtAddress.Text.Replace(System.Environment.NewLine, ", ");
      Brush theBrush = Brushes.Black;
      Font theFont = txtAddress.Font;

      thePrintPageEventArguments.Graphics.DrawString("Date: " + dtpDate.Text, theFont, theBrush, thePrintPageEventArguments.MarginBounds.Left, thePrintPageEventArguments.MarginBounds.Top);
      lngCounter = 1;
      thePrintPageEventArguments.Graphics.DrawString("Name: " + txtName.Text, theFont, theBrush, thePrintPageEventArguments.MarginBounds.Left, thePrintPageEventArguments.MarginBounds.Top + theFont.Height * lngCounter);
      lngCounter += 1;
      thePrintPageEventArguments.Graphics.DrawString("Address: " + strAddress, theFont, theBrush, thePrintPageEventArguments.MarginBounds.Left, thePrintPageEventArguments.MarginBounds.Top + theFont.Height * lngCounter);
      lngCounter += 1;
      thePrintPageEventArguments.Graphics.DrawString("Department: " + cmbDepartment.Text, theFont, theBrush, thePrintPageEventArguments.MarginBounds.Left, thePrintPageEventArguments.MarginBounds.Top + theFont.Height * lngCounter);
      lngCounter += 1;
      thePrintPageEventArguments.Graphics.DrawString("When you show this ticket to the parkingguard, you can park for free.", theFont, theBrush, thePrintPageEventArguments.MarginBounds.Left, thePrintPageEventArguments.MarginBounds.Top + theFont.Height * lngCounter);
      lngCounter += 1;
      thePrintPageEventArguments.Graphics.DrawString("at the mentioned date", theFont, theBrush, thePrintPageEventArguments.MarginBounds.Left, thePrintPageEventArguments.MarginBounds.Top + theFont.Height * lngCounter);
    }
    // prndocTicket_PrintPage(System.Object, Printing.PrintPageEventArgs) Handles prndocTicket.PrintPage

    private void tlbTicket_ButtonClick(System.Object theSender, ToolBarButtonClickEventArgs theToolBarButtonClickEventArguments)
      //***
      // Action
      //   - A certain button on the toolbar is clicked
      //   - Depending on the button
      //     - A certain action is started
      // Called by
      //   - User action (Clicking a button on the toolbar)
      // Calls
      //   - Clear()
      //   - Print()
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - 
      //***
    {

      if (theToolBarButtonClickEventArguments.Button == tbbClear)
      {
        Clear();
      }
      else if (theToolBarButtonClickEventArguments.Button == tbbPrint)
        // theToolBarButtonClickEventArguments.Button <> tbbClear
      {
        Print();
      }
      else
        // theToolBarButtonClickEventArguments.Button <> tbbPrint
      {
      }
      // theToolBarButtonClickEventArguments.Button = tbbClear
      // theToolBarButtonClickEventArguments.Button = tbbPrint
    
    }
    // tlbTicket_ButtonClick(System.Object, ToolBarButtonClickEventArgs) Handles tlbTicket.ButtonClick

    private void tmrTime_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The current date is compared with the date on the screen
      //   - If equal
      //     - Nothing happens
      //   - If Not
      //     - Date on screen is changed
      //     - Interval of ticks is put to 1 minute
      // Called by
      //   - System action (Timer tick)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - Date is every hour refreshed
      //   - Date is possible wrong after midnight (but before 1 o'clock it is set correct)
      //***
    {

      if (stpTime.Text == DateTime.Now.ToShortTimeString())
      {
      }
      else
        // stpTime.Text <> DateTime.Now.ToShortTimeString()
      {
        stpTime.Text = DateTime.Now.ToShortTimeString();
        tmrTime.Interval = 60000;
      }
      // stpTime.Text = DateTime.Now.ToShortTimeString()
    
    }
    // tmrTime_Tick(System.Object, System.EventArgs) Handles tmrTime.Tick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Clear()
      //***
      // Action
      //   - Form is put back in its original state
      // Called by
      //   - mnuTicketClear_Click(System.Object, .EventArgs) Handles mnuTicketClear.Click
      //   - tlbTicket_ButtonClick(System.Object, ToolBarButtonClickEventArgs) Handles tlbTicket.ButtonClick
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtAddress.Text = "";
      txtFirstName.Text = "";
      txtName.Text = "";
      dtpDate.Value = DateTime.Today;
      stpDate.Text = DateTime.Today.ToShortDateString();
      stpTime.Text = DateTime.Now.ToShortTimeString();
      cmbDepartment.Text = "";
    }
    // Clear()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmData
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmData()
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmData());
    }
    // Main() 

    public void Print()
      //***
      // Action
      //   - Document is printed
      // Called by
      //   - cmdPrint_Click(System.Object, System.EventArgs) Handles cmdPrint.Click
      //   - mnuTicketPrint_Click(System.Object, System.EventArgs) Handles mnuTicketPrint.Click
      //   - tlbTicket_ButtonClick(System.Object, ToolBarButtonClickEventArgs) Handles tlbTicket.ButtonClick
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      prndocTicket.Print();
    }
    // Print()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // frmData

}
// CopyPaste.Learning