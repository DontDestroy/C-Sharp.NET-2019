﻿//***
// Action
//   - A definition of an AbstractBeeperLayer
// Created
//   - CopyPaste – 20251027 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251027 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public abstract class cpAbstractBeeperLayer : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpAbstractBeeperLayer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpAbstractBeeperLayer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpAbstractBeeperLayer(int, int, Directions.Direction, int)
    //   - cpStrategyBeeperLayer(int, int, Directions.Direction, int, Color, cpinfStrategy) 
    //   - cpStrategyBeeperLayerAlternative(int, int, Directions.Direction, int, Color, cpinfStrategy) 
    //   - cpThreeBeeperLayer(int, int, Directions.Direction, int, Color) 
    //   - cpTwoBeeperLayer(int, int, Directions.Direction, int, Color) 
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpAbstractBeeperLayer(int, int, Directions.Direction, int, Color) 

    public cpAbstractBeeperLayer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpAbstractBeeperLayer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpAbstractBeeperLayer(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpAbstractBeeperLayer(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public abstract void PutBeepers();
    //***
    // Action
    //   - A functionality to put beepers
    // Called by
    //   - cpProgram.StrategyDelegation()
    //   - LayBeepers()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***

    public void LayBeepers()
    //***
    // Action
    //   - A functionality to lay beepers in a row
    //     - Repeat 4 times
    //       - Put beepers
    //       - Move one forward
    //   - Robot is switched off
    // Called by
    //   - cpProgram.TwoDifferentRobots()
    // Calls
    //   - PutBeepers()
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      for (int number = 0; number < 4; number++)
      {
        PutBeepers();
        move();
      }
      // number = 4

    }
    // LayBeepers()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpAbstractBeeperLayer

}
// cpKarelTheRobot