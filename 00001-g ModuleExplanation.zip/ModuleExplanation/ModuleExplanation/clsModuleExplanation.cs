//***
// Action
//   - Test public and private routines
// Created
//   - CopyPaste � 20210823 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210823 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using AnotherProject;
using System;

namespace ModuleExplanation
{

  class cpModuleExplanation
  {

		static void Main()
    //***
    // Action
    //   - Write message to console
    //   - Wait for user action
    //   - Define an instance of cpTryout
    //   - Define an instance of cpAnotherProject
    //   - Run public routine
    //   - Run internal routine
    //   - Run public routine of another project
    //   - Try running a internal routine of another project
    // Called by
    //   - User action (starting the program)
    // Calls
    //   - AnotherProject.cpAnotherProject.ThisIsFriend()
    //   - AnotherProject.cpAnotherProject.ThisIsPublic()
    //   - cpTryout.ThisIsFriend()
    //   - cpTryout.ThisIsPublic()
    //   - System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20210823 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20210823 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      cpTryout theTryout;
      cpAnotherProject theOtherProject;
      
      theTryout = new cpTryout();
      theOtherProject = new cpAnotherProject();

      Console.WriteLine("This is the startup Main routine");
      Console.ReadLine();
      theTryout.ThisIsPublic();
      theTryout.ThisIsInternal();
      theOtherProject.ThisIsPublic();
      // theOtherProject.ThisIsInternal();
    }
    // Main()

	}
  // cpModuleExplanation

}
// ModuleExplanation