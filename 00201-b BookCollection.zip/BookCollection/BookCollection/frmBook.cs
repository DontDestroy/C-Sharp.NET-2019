//***
// Action
//   - Child window in the MDI application
// Created
//   - CopyPaste � 20250707 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250707 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBook: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtDescription;
    internal System.Windows.Forms.TextBox txtTitle;
    internal System.Windows.Forms.TextBox txtAuthor;
    internal System.Windows.Forms.Label lblDescription;
    internal System.Windows.Forms.Label Label2;
    internal System.Windows.Forms.SaveFileDialog dlgFileSave;
    internal System.Windows.Forms.Label Label1;

    private void InitializeComponent()
    {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBook));
			this.txtDescription = new System.Windows.Forms.TextBox();
			this.txtTitle = new System.Windows.Forms.TextBox();
			this.txtAuthor = new System.Windows.Forms.TextBox();
			this.lblDescription = new System.Windows.Forms.Label();
			this.Label2 = new System.Windows.Forms.Label();
			this.dlgFileSave = new System.Windows.Forms.SaveFileDialog();
			this.Label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txtDescription
			// 
			this.txtDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txtDescription.Location = new System.Drawing.Point(10, 88);
			this.txtDescription.Multiline = true;
			this.txtDescription.Name = "txtDescription";
			this.txtDescription.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txtDescription.Size = new System.Drawing.Size(272, 177);
			this.txtDescription.TabIndex = 11;
			this.txtDescription.TextChanged += new System.EventHandler(this.txtDescription_TextChanged);
			// 
			// txtTitle
			// 
			this.txtTitle.Location = new System.Drawing.Point(66, 32);
			this.txtTitle.Name = "txtTitle";
			this.txtTitle.Size = new System.Drawing.Size(144, 20);
			this.txtTitle.TabIndex = 9;
			this.txtTitle.Text = "No Title";
			this.txtTitle.TextChanged += new System.EventHandler(this.txtTitle_TextChanged);
			// 
			// txtAuthor
			// 
			this.txtAuthor.Location = new System.Drawing.Point(66, 8);
			this.txtAuthor.Name = "txtAuthor";
			this.txtAuthor.Size = new System.Drawing.Size(144, 20);
			this.txtAuthor.TabIndex = 7;
			this.txtAuthor.Text = "No Author";
			this.txtAuthor.TextChanged += new System.EventHandler(this.txtAuthor_TextChanged);
			// 
			// lblDescription
			// 
			this.lblDescription.Location = new System.Drawing.Point(10, 64);
			this.lblDescription.Name = "lblDescription";
			this.lblDescription.Size = new System.Drawing.Size(100, 23);
			this.lblDescription.TabIndex = 10;
			this.lblDescription.Text = "Description";
			// 
			// Label2
			// 
			this.Label2.Location = new System.Drawing.Point(10, 32);
			this.Label2.Name = "Label2";
			this.Label2.Size = new System.Drawing.Size(56, 23);
			this.Label2.TabIndex = 8;
			this.Label2.Text = "Title";
			// 
			// dlgFileSave
			// 
			this.dlgFileSave.Filter = "Books | *.bk";
			// 
			// Label1
			// 
			this.Label1.Location = new System.Drawing.Point(10, 8);
			this.Label1.Name = "Label1";
			this.Label1.Size = new System.Drawing.Size(56, 23);
			this.Label1.TabIndex = 6;
			this.Label1.Text = "Author";
			// 
			// frmBook
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.Add(this.txtTitle);
			this.Controls.Add(this.txtAuthor);
			this.Controls.Add(this.lblDescription);
			this.Controls.Add(this.Label2);
			this.Controls.Add(this.Label1);
			this.Controls.Add(this.txtDescription);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmBook";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Book";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.frmBook_Closing);
			this.Load += new System.EventHandler(this.frmBook_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBook'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBook()
      //***
      // Action
      //   - Create instance of 'frmBook'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmBook()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    bool mblnArchive;

    #endregion

    #region "Properties"

    public bool Archive
    {

      get
        //***
        // Action Get
        //   - Returns mblnArchive
        // Called by
        //   - frmBook_Closing(System.Object, System.ComponentModel.CancelEventArgs) Handles this.Closing
        //   - frmMain.frmMain_Closing(System.Object, System.ComponentModel.CancelEventArgs) Handles this.Closing
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250707 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250707 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mblnArchive;
      }
      // bool Archive (Get)

      set
        //***
        // Action Set
        //   - mblnArchive becomes value
        // Called by
        //   - frmBook_Load(System.Object, System.EventArgs) Handles this.Load
        //   - Save(frmBook)
        //   - txtAuthor_TextChanged(System.Object, System.EventArgs) Handles txtAuthor.TextChanged
        //   - txtDescription_TextChanged(System.Object, System.EventArgs) Handles txtDescription.TextChanged
        //   - txtTitle_TextChanged(System.Object, System.EventArgs) Handles txtTitle.TextChanged
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250707 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250707 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mblnArchive = value;
      }
      // Archive(bool) (Set)

    }
    // bool Archive

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmBook_Closing(System.Object theSender, System.ComponentModel.CancelEventArgs theCancelEventArguments)
      //***
      // Action
      //   - If frmBook has changed
      //     - Save the book
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Closing a form (book))
      // Calls
      //   - bool Archive (Get)
      //   - ChangeTitle()
      //   - Save(frmBook)
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (Archive)
      {
        Save((frmBook)theSender);
      }
      else
        // Not Archive
      {
      }
      // Archive

      ChangeTitle();
    }
    // frmBook_Closing(System.Object, System.ComponentModel.CancelEventArgs) Handles this.Closing

    private void frmBook_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the title of the child and the main form
      //   - Mark the book as unchanged
      // Called by
      //   - User action (Loading a form (book))
      // Calls
      //   - Archive(bool) (Set)
      //   - ChangeTitle()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeTitle();
      Archive = false;
    }
    // frmBook_Load(System.Object, System.EventArgs) Handles this.Load

    private void txtAuthor_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the title of the child and the main form
      //   - Mark the book as changed
      // Called by
      //   - User action (Changing a textbox)
      // Calls
      //   - Archive(bool) (Set)
      //   - ChangeTitle()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeTitle();
      Archive = true;
    }
    // txtAuthor_TextChanged(System.Object, System.EventArgs) Handles txtAuthor.TextChanged

    private void txtDescription_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Mark the book as changed
      // Called by
      //   - User action (Changing a textbox)
      // Calls
      //   - Archive(bool) (Set)
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Archive = true;
    }
    // txtDescription_TextChanged(System.Object, System.EventArgs) Handles txtDescription.TextChanged

    private void txtTitle_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the title of the child and the main form
      //   - Mark the book as changed
      // Called by
      //   - User action (Changing a textbox)
      // Calls
      //   - Archive(bool) (Set)
      //   - ChangeTitle()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeTitle();
      Archive = true;
    }
    // txtTitle_TextChanged(System.Object, System.EventArgs) Handles txtTitle.TextChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ChangeTitle()
      //***
      // Action
      //   - Try to
      //     - Define the text of the form into Author and Title
      //     - Define the text of the main form into "Book Collection - " and the title of the form
      // Called by
      //   - frmBook_Closing(System.Object, System.ComponentModel.CancelEventArgs) Handles this.Closing
      //   - frmMain.frmMain_MdiChildActivate(System.Object, System.EventArgs) Handles this.MdiChildActivate
      //   - frmMain.NewBook()
      //   - frmMain.Open()
      //   - txtAuthor_TextChanged(System.Object, System.EventArgs) Handles txtAuthor.TextChanged
      //   - txtTitle_TextChanged(System.Object, System.EventArgs) Handles txtTitle.TextChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      try
      {
        this.Text = txtAuthor.Text + " - " + txtTitle.Text;
        this.MdiParent.Text = "Book Collection - " + this.Text;
      }
      catch
      {
      }
      finally
      {
      }

    }
    // ChangeTitle()

    public void Save(frmBook frmChild)
      //***
      // Action
      //   - Show file save dialog
      //   - If OK button (save) is clicked
      //     - A streamwriter is created with the chosen filename
      //     - A line is written with the author text, a dot comma, and the title text
      //     - A line is written with the description text
      //     - The streamwriter is closed
      //     - The form is marked as saved
      //   - If not
      //     - Do nothing
      // Called by
      //   - frmBook_Closing(System.Object, System.ComponentModel.CancelEventArgs) Handles this.Closing
      //   - frmMain.mnuFileSaveAs_Click(System.Object, System.EventArgs) Handles mnuFileSaveAs.Click
      // Calls
      //   - Archive(bool) (Set)
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - We assume here that the author does not contain a ; in the name
      //***
    {

      if (dlgFileSave.ShowDialog() == DialogResult.OK)
      {
        StreamWriter theWriter = new StreamWriter(dlgFileSave.OpenFile());
        theWriter.WriteLine(frmChild.txtAuthor.Text + ";" + frmChild.txtTitle.Text);
        theWriter.WriteLine(frmChild.txtDescription.Text);
        theWriter.Close();
        frmChild.Archive = false;
      }
      else
        // dlgFileSave.ShowDialog() <> DialogResult.OK
      {
      }
      // dlgFileSave.ShowDialog() = DialogResult.OK

    }
    // Save(frmBook)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBook

}
// CopyPaste.Learning