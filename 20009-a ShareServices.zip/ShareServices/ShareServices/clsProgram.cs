﻿//***
// Action
//   - Demo how to share some services
//     - First with a Task<T>
//     - Then with a ValueTask<T>
// Created
//   - CopyPaste – 20251221 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251221 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static System.Console;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251221 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251221 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Run Shared Service Task
    //   - Wait for user input
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - RunSharedServiceTask()
    //   - RunSharedServiceValueTask()
    //   - Task RunTaskWithDiscards(int, int)
    // Created
    //   - CopyPaste – 20251221 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251221 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Run the routine RunSharedServiceTask and show the diagnostics
    //     - It runned around 18 seconds
    //     - The garbage collector ran 320 times
    //     - Memory load was around 18 Mb
    //   - Run the routine RunSharedServiceValueTask and show the diagnostics
    //     - It runned around 16 seconds
    //     - The garbage collector ran 0 times
    //     - Memory load was around 9 Mb
    //***
    {
      DateTime dtmStart;
      DateTime dtmEnd;
      TimeSpan tspRunned;

      dtmStart = DateTime.Now;
      WriteLine();
      WriteLine($"Starting Shared Service Task demo: {dtmStart}");

      RunSharedServiceTask();
      // RunSharedServiceValueTask();

      dtmEnd = DateTime.Now;
      WriteLine();
      WriteLine($"Ending Shared Service Task demo: {dtmEnd}");

      tspRunned = dtmEnd - dtmStart;
      WriteLine($"Shared Service Task demo runned: {tspRunned.TotalMilliseconds} milliseconds");

      // VVDW - Example of async with a discard variable
      // WriteLine();
      // WriteLine("Async started at: " + DateTime.Now);
      // _ = RunTaskWithDiscards(10, 11);
      // WriteLine("Async completed at: " + DateTime.Now);

      WriteLine();
      WriteLine("Hit any key to continue");
      ReadLine();
    }
    // Main()    

    static void RunSharedServiceTask()
    //***
    // Action
    //   - Define a result
    //   - Define a counter
    //   - Define and create a cpSharedServiceTask
    //   - Loop something 20 million times
    //     - Get the stock details from the shared service
    //   - Show the counter
    //   - Show how many times the garbage collector ran
    // Called by
    //   - Main()
    // Calls
    //   - cpSharedServiceTask(int)
    //   - cpSharedServiceTask.GetStockDetails()
    // Created
    //   - CopyPaste – 20251221 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251221 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpStockNasDaq> result;
      int intCounter;
      int intNumberOfSeconds = 2;

      cpSharedServiceTask theSharedService = new cpSharedServiceTask(intNumberOfSeconds);

      for (intCounter = 0; intCounter < 20_000_000; intCounter++)
      {
        result = theSharedService.GetStockDetails().Result;
      }
      // intCounter = 20000000

      WriteLine($"End of loop: Counter reached {intCounter}");
      WriteLine($"Garbage collection occured {GC.CollectionCount(0)} times");
    }
    // RunSharedServiceTask()

    static void RunSharedServiceValueTask()
    //***
    // Action
    //   - Define a result
    //   - Define a counter
    //   - Define and create a cpSharedServiceValueTask
    //   - Loop something 20 million times
    //     - Get the stock details from the shared service
    //   - Show the counter
    //   - Show how many times the garbage collector ran
    // Called by
    //   - Main()
    // Calls
    //   - cpSharedServiceValueTask(int)
    //   - cpSharedServiceValueTask.GetStockDetails()
    // Created
    //   - CopyPaste – 20251221 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251221 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpStockNasDaq> result;
      int intCounter;
      int intNumberOfSeconds = 2;

      cpSharedServiceValueTask theSharedService = new cpSharedServiceValueTask(intNumberOfSeconds);

      for (intCounter = 0; intCounter < 20_000_000; intCounter++)
      {
        result = theSharedService.GetStockDetails().Result;
      }
      // intCounter = 20000000

      WriteLine($"End of loop: Counter reached {intCounter}");
      WriteLine($"Garbage collection occured {GC.CollectionCount(0)} times");
    }
    // RunSharedServiceValueTask()

    private static async Task RunTaskWithDiscards(int intFirstValue, int intSecondValue)
    //***
    // Action
    //   - Something is executed, but result is discarded
    //   - Wait 2 seconds
    // Called by
    //   - Main()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251222 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251222 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      _ = await Task.Run(
        () => intFirstValue + intSecondValue
        );

      await Task.Delay(2000);
      WriteLine("Waited 2 seconds");
    }
    // Task RunTaskWithDiscards(int, int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning