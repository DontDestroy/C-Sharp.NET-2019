//***
// Action
//   - Definition and methods on a structure
// Created
//   - CopyPaste � 20240708 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240708 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    #region "Structures"

    public struct cpBook
    {
      public string strTitle;
      public string strAuthor;
      public string strPublisher;
      public double dblPrice;
    }
    // cpBook
     
    #endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create a variable of type cpBook
      //   - Fill Title, Author, Publisher and Price
      //   - Show the information
      // Called by
      //   - Main()
      // Calls
      //   - ShowBook(cpBook)
      // Created
      //   - CopyPaste � 20270708 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20270708 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBook theBookInfo = new cpBook();

      theBookInfo.strTitle = "Visual Basic .NET Programming Tips & Techniques";
      theBookInfo.strAuthor = "Jamsa";
      theBookInfo.strPublisher = "MsGraw-Hill/Osborne";
      theBookInfo.dblPrice = 49.99;

      ShowBook(theBookInfo);
      Console.ReadLine();
    }
		// Main()

    public static void ShowBook(cpBook thecpBook)
      //***
      // Action
      //   - Show the book information
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20270708 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20270708 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine(thecpBook.strTitle);
      Console.WriteLine(thecpBook.strAuthor);
      Console.WriteLine(thecpBook.strPublisher);
      Console.WriteLine(thecpBook.dblPrice);
    }
    // ShowBook(cpBook)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning