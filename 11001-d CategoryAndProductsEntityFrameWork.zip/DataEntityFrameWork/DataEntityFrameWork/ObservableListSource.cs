﻿//***
// Action
//   - Create a binding list that is observable
// Created
//   - CopyPaste – 20210701 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210701 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Entity;

namespace DataEntityFrameWork
{

  public class ObservableListSource<T> : ObservableCollection<T>, IListSource
        where T : class
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    private IBindingList _bindingList;
    #endregion

    #region "Properties"

    bool IListSource.ContainsListCollection { get { return false; } }
    //***
    // Action Get
    //   - Return False
    // Called by
    //   -  
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    IList IListSource.GetList()
    //***
    // Action
    //   - Get the list of the source
    //   - If _bindingList is nothing
    //     - Define the binding list
    //   - If Not
    //     - Do Nothing
    //   - Return _bindingList
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      return _bindingList ?? (_bindingList = this.ToBindingList());
    }
    // IList IListSource.GetList()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // ObservableListSource<T> : ObservableCollection<T>, IListSource where T : class

}
// DataEntityFrameWork