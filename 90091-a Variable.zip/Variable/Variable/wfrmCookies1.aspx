﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCookies1.aspx.cs" Inherits="CopyPaste.Learning.wfrmCookies1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Cookies</title>
</head>
<body>
  <form id="wfrmCookies1" method="post" runat="server">
    <asp:Label Style="z-index: 101; position: absolute; top: 112px; left: 64px" ID="lblName" runat="server">Name</asp:Label>
    <asp:Button Style="z-index: 105; position: absolute; top: 184px; left: 64px" ID="cmdOK" TabIndex="4"
      runat="server" Text="OK"></asp:Button>
    <asp:TextBox Style="z-index: 104; position: absolute; top: 144px; left: 136px" ID="txtEmail"
      TabIndex="3" runat="server"></asp:TextBox>
    <asp:TextBox Style="z-index: 103; position: absolute; top: 110px; left: 136px" ID="txtName" TabIndex="1"
      runat="server"></asp:TextBox>
    <asp:Label Style="z-index: 102; position: absolute; top: 144px; left: 64px" ID="lblEmail" runat="server">E-mail</asp:Label>
  </form>
</body>
</html>
