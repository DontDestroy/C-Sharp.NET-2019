//***
// Action
//   - Demo of reading a textfile using a file open dialog
// Created
//   - CopyPaste � 20240628 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240628 � VVDW
// Proposal (To Do)
//   - 
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTextBrowser: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.MenuItem mnuFileClose;
    internal System.Windows.Forms.TextBox txtNote;
    internal System.Windows.Forms.Label lblNote;
    internal System.Windows.Forms.MenuItem mnuFile;
    internal System.Windows.Forms.MenuItem mnuFileOpen;
    internal System.Windows.Forms.MenuItem mnuFileExit;
    internal System.Windows.Forms.MainMenu mnuTextBrowser;
    internal System.Windows.Forms.OpenFileDialog dlgFileOpen;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTextBrowser));
      this.mnuFileClose = new System.Windows.Forms.MenuItem();
      this.txtNote = new System.Windows.Forms.TextBox();
      this.lblNote = new System.Windows.Forms.Label();
      this.mnuFile = new System.Windows.Forms.MenuItem();
      this.mnuFileOpen = new System.Windows.Forms.MenuItem();
      this.mnuFileExit = new System.Windows.Forms.MenuItem();
      this.mnuTextBrowser = new System.Windows.Forms.MainMenu();
      this.dlgFileOpen = new System.Windows.Forms.OpenFileDialog();
      this.SuspendLayout();
      // 
      // mnuFileClose
      // 
      this.mnuFileClose.Enabled = false;
      this.mnuFileClose.Index = 1;
      this.mnuFileClose.Text = "&Close";
      this.mnuFileClose.Click += new System.EventHandler(this.mnuFileClose_Click);
      // 
      // txtNote
      // 
      this.txtNote.Enabled = false;
      this.txtNote.Location = new System.Drawing.Point(16, 48);
      this.txtNote.Multiline = true;
      this.txtNote.Name = "txtNote";
      this.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtNote.Size = new System.Drawing.Size(360, 184);
      this.txtNote.TabIndex = 3;
      this.txtNote.Text = "";
      // 
      // lblNote
      // 
      this.lblNote.Location = new System.Drawing.Point(16, 8);
      this.lblNote.Name = "lblNote";
      this.lblNote.RightToLeft = System.Windows.Forms.RightToLeft.No;
      this.lblNote.Size = new System.Drawing.Size(360, 24);
      this.lblNote.TabIndex = 2;
      this.lblNote.Text = "Import a text by selecting the menu File / Open";
      // 
      // mnuFile
      // 
      this.mnuFile.Index = 0;
      this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFileOpen,
                                                                            this.mnuFileClose,
                                                                            this.mnuFileExit});
      this.mnuFile.Text = "&File";
      // 
      // mnuFileOpen
      // 
      this.mnuFileOpen.Index = 0;
      this.mnuFileOpen.Text = "&Open ...";
      this.mnuFileOpen.Click += new System.EventHandler(this.mnuFileOpen_Click);
      // 
      // mnuFileExit
      // 
      this.mnuFileExit.Index = 2;
      this.mnuFileExit.Text = "&Exit";
      this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
      // 
      // mnuTextBrowser
      // 
      this.mnuTextBrowser.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                   this.mnuFile});
      // 
      // frmTextBrowser
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(392, 277);
      this.Controls.Add(this.txtNote);
      this.Controls.Add(this.lblNote);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mnuTextBrowser;
      this.Name = "frmTextBrowser";
      this.Text = "Text Browser";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTextBrowser'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTextBrowser()
      //***
      // Action
      //   - Create instance of 'frmTextBrowser'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTextBrowser()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void mnuFileClose_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Empty the textbox
      //   - Set the correct message on screen
      //   - Disable File Close menu
      //   - Enable File Open menu
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtNote.Text = "";
      lblNote.Text = "Import a text by selecting the menu File / Open";
      mnuFileClose.Enabled = false;
      mnuFileOpen.Enabled = true;
    }
    // mnuFileClose_Click(System.Object, System.EventArgs) Handles mnuFileClose.Click

    private void mnuFileExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop the application
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // mnuFileExit_Click(System.Object, System.EventArgs) Handles mnuFileExit.Click

    private void mnuFileOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Initialize the file open screen
      //   - Only text files
      //   - Default current directory
      //   - Show the dialog
      //   - If there is a file name
      //     - Try
      //       - Open the file
      //       - Loop thru all the lines
      //         - Add the line in the textbox
      //       - Set the correct message on screen
      //       - Set cursor at the start of the text
      //       - Enable File Close menu
      //       - Disable File Open menu
      //     - Show error message when it fails
      //     - Close the file
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strAllText = "";
      string strLineOfText;

      dlgFileOpen.Filter = "Text Files (*.TXT)|*.TXT";
      dlgFileOpen.InitialDirectory = Environment.CurrentDirectory;
      dlgFileOpen.ShowDialog();

      if (dlgFileOpen.FileName == "")
      {
      }
      else
        // dlgFileOpen.FileName <> ""
      {

        try
        {
          FileSystem.FileOpen(1, dlgFileOpen.FileName, OpenMode.Input, OpenAccess.Read, OpenShare.Default, 100);

          while (!FileSystem.EOF(1))
          {
            strLineOfText = FileSystem.LineInput(1);
            strAllText = strAllText + strLineOfText + ControlChars.NewLine;
          }
          // FileSystem.EOF(1)

          lblNote.Text = dlgFileOpen.FileName;
          txtNote.Text = strAllText;
          txtNote.Enabled = true;
          txtNote.Select(0, 0);
          txtNote.Select();
          mnuFileClose.Enabled = true;
          mnuFileOpen.Enabled = false;
        }
        catch
        {
          MessageBox.Show("Error while opening file.");
        }
        finally
        {
          FileSystem.FileClose(1);
        }

      }
      // dlgFileOpen.FileName = ""

    }
    // mnuFileOpen_Click(System.Object, System.EventArgs) Handles mnuFileOpen.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTextBrowser
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmTextBrowser()
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTextBrowser());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTextBrowser

}
// CopyPaste.Learning