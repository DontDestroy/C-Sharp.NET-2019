﻿//***
// Action
//   - The class that sets up the context towards a SQL Server database
// Created
//   - CopyPaste – 20230405 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230405 – VVDW
// Proposal (To Do)
//   -
//***

using System.Configuration;
using System.Data.Entity;

namespace CopyPaste.Learning
{

  public class cpApplicationDatabaseContext : DbContext
  {

    #region "Constructors / Destructors"

    public cpApplicationDatabaseContext() : base("LocalConnectionString")
    //***
    // Action
    //   - We use a parameter in the app.config to determine the connectionstring
    // Called by
    //   - System action (Configuring the database context)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230405 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230405 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpApplicationDatabaseContext()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"

    //***
    // Action Get and Set
    //   - Entry point for the database context to create the model towards the database
    // Called by
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230405 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230405 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    public DbSet<cpWarning> cpWarning { get; set; }
    // DbSet<cpWarning> cpWarning (Get)
    // cpWarning(DbSet<cpWarning>) (Set)

    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"

    //public static string UsedConnectionString()
    ////***
    //// Action
    ////   - Determine the used connectionstring
    ////   - The connectionstring name is hardcode (and duplicated)
    //// Called by
    ////   - 
    //// Calls
    ////   - 
    //// Created
    ////   - CopyPaste – 20230405 – VVDW
    //// Changed
    ////   - CopyPaste – yyyymmdd – VVDW – What changed
    //// Tested
    ////   - CopyPaste – 20230405 – VVDW
    //// Keyboard key
    ////   - 
    //// Proposal (To Do)
    ////   - 
    ////***
    //{
    //  return ConfigurationManager.ConnectionStrings["LocalConnectionString"].ConnectionString;
    //}
    //// string UsedConnectionString()

    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpApplicationDatabaseContext

}
// CopyPaste.Learning