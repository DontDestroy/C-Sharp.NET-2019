//***
// Action
//   - Starting and stopping notepath with a process
// Created
//   - CopyPaste � 20240702 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240702 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmStartAndStop: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdStart;
    internal System.Diagnostics.Process theNoteProcess;
    internal System.Windows.Forms.Button cmdStop;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmStartAndStop));
      this.cmdStart = new System.Windows.Forms.Button();
      this.theNoteProcess = new System.Diagnostics.Process();
      this.cmdStop = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdStart
      // 
      this.cmdStart.Location = new System.Drawing.Point(78, 46);
      this.cmdStart.Name = "cmdStart";
      this.cmdStart.Size = new System.Drawing.Size(136, 32);
      this.cmdStart.TabIndex = 2;
      this.cmdStart.Text = "Start Notepad";
      this.cmdStart.Click += new System.EventHandler(this.cmdStart_Click);
      // 
      // theNoteProcess
      // 
      this.theNoteProcess.StartInfo.FileName = "notepad.exe";
      this.theNoteProcess.SynchronizingObject = this;
      // 
      // cmdStop
      // 
      this.cmdStop.Location = new System.Drawing.Point(78, 110);
      this.cmdStop.Name = "cmdStop";
      this.cmdStop.Size = new System.Drawing.Size(136, 32);
      this.cmdStop.TabIndex = 3;
      this.cmdStop.Text = "Stop Notepad";
      this.cmdStop.Click += new System.EventHandler(this.cmdStop_Click);
      // 
      // frmStartAndStop
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 189);
      this.Controls.Add(this.cmdStop);
      this.Controls.Add(this.cmdStart);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmStartAndStop";
      this.Text = "Start and stop Notepad";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmStartAndStop'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmStartAndStop()
      //***
      // Action
      //   - Create instance of 'frmStartAndStop'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmStartAndStop()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdStart_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Start Notepad (when not started)
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      IntPtr theHandles;

      try
      {
        theHandles = theNoteProcess.MainWindowHandle;
      }
      catch
      {
        theNoteProcess.Start();
      }
    
    }
    // cmdStart_Click(System.Object, System.EventArgs) Handles cmdStart.Click

    private void cmdStop_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop Notepad (when started)
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      IntPtr theHandles;

      try
      {
        theHandles = theNoteProcess.MainWindowHandle;
        theNoteProcess.CloseMainWindow();
        theNoteProcess.Refresh();
      }
      catch
      {
      }
    
    }
    // cmdStop_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdStop.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmStartAndStop
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmStartAndStop()
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmStartAndStop());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmStartAndStop

}
// CopyPaste.Learning