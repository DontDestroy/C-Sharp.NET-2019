﻿//***
// Action
//   - Create a class cpFor that uses the interface Directions
//   - Demo a nested for loop
// Created
//   - CopyPaste – 20251020 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251020 – VVDW
// Proposal (To Do)
//   -
//***

using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpFor : Directions
	{

    #region "Constructors / Destructors"

    public cpFor()
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Reset the world
    //   - Build the world according to the Robot World specifications
    //   - Make the world visible
    //   - Karel becomes a green robot starting at position (2, 2), looking to the right with no beepers in the bag
    //   - Do 4 times the ocde for a size
    //     - Do 7 times one move
    //     - Turn left
    //   - Karel is switched off
    // Called by
    //   - cpProgram.ForLoop()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251020 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251020 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      World.reset();
      World.readWorld("Worlds\\01.01 The Robot World.kwld");
      World.setVisible(true);
      UrRobot karel = new UrRobot(2, 2, Directions.East, 0);

      for (int countSize = 0; countSize < 4; countSize++)
      {

        for (int countMove = 0; countMove < 7; countMove++)
        {
          karel.move();
        }
        // countMove = 7       

        karel.turnLeft();
      }
      // countSize = 4

      karel.turnOff(); // Robot karel is switched off
    }
    // cpFor()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpFor

}
// cpKarelTheRobot