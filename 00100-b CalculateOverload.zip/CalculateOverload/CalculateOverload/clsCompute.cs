﻿//***
// Action
//   - Definition of cpCompute
// Created
//   - CopyPaste – 20260619 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260619 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpCompute
  {

    #region "Constructors / Destructors"

    public cpCompute(decimal decGivenWidth)
    //***
    // Action
    //   - Basic constructor with a given size
    // Called by
    //   - cpProgram.Main()
    // Calls
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      this.decWidth = decGivenWidth;
    }
    // cpCompute(decimal)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private decimal decWidth = 0;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public decimal Surface(string strPolygon)
    //***
    // Action
    //   - Define and assign a result
    //   - Change the given letter to lower case
    //   - If the wanted surface is a "circle"
    //     - Calculate the surface of a circle with a given width
    //   - If not
    //     - If the wanted surface is a "triangle"
    //       - Calculate the surface of a triangle with a given base and height
    //     - If not
    //       - If the wanted surface is a "square"
    //         - Calculate the surface of a square with a given width
    //       - If not
    //   - Show the result
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - decimal Surface(decimal)
    //   - decimal Surface(decimal, decimal, string)
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      decimal decResult = 0.0m;
      strPolygon = strPolygon.ToLower();

      if (strPolygon == "circle")
      {
        decResult = Surface(decWidth);
      }
      else if (strPolygon == "triangle" || strPolygon == "square")
      // chrLetter <> "circle"
      {
        decResult = Surface(decWidth, decWidth, strPolygon);
      }
      // chrLetter = "circle"
      // chrLetter = "triangle"
      // chrLetter = "square"

      return decResult;
    }
    // decimal Surface(string)

    private decimal Surface(decimal decWidth)
    //***
    // Action
    //   - Calculate the surface of a circle with a given width
    //   - Devide the width into 2 (radius)
    //   - Square the radius and multiply by PI
    // Called by
    //   - decimal Surface(string)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      decimal decRadius;
      decimal decResult = 0.0m;

      decRadius = decWidth / 2;
      decResult = decRadius * decRadius * (decimal)System.Math.PI;

      return decResult;
    }
    // decimal Surface(decimal)

    private decimal Surface(decimal decBase, decimal decHeight, string strPolygon)
    //***
    // Action
    //   - Calculate the surface of a triangle or a square with a given width
    //   - Multiply the width with the width
    //   - For a triagle divide by 2
    // Called by
    //   - decimal Surface(string)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      decimal decResult = 0.0m;

      decResult = decWidth * decWidth;

      if (strPolygon == "triangle")
      {
        decResult /= 2;
      }
      // strPolygon == "triangle"

      return decResult;
    }
    // decimal Surface(decimal)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCompute

}
// CopyPaste.Learning