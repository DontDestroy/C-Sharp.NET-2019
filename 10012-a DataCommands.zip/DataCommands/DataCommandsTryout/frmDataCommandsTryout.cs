﻿//***
// Action
//   - Having DataCommands and DataReaders towards a database
// Created
//   - CopyPaste – 20210701 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210701 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System.Windows.Forms;

namespace DataCommandsTryout
{

  public partial class frmDataCommandsTryout : Form
  {

    #region "Constructors / Destructors"

    public frmDataCommandsTryout()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Setting command with 2 parameters for Select Order
    //   - Set properties for mcmmSelectCustomer
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //  - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmDataCommandsTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataCommandsTryout

}
// DataCommandsTryout