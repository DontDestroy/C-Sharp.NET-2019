//***
// Action
//   -  Starting a program using the Process object
// Created
//   - CopyPaste � 20250629 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250629 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmStartup: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdEnd;
    internal System.Windows.Forms.Button cmdLaunch;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmStartup));
      this.cmdEnd = new System.Windows.Forms.Button();
      this.cmdLaunch = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdEnd
      // 
      this.cmdEnd.Location = new System.Drawing.Point(86, 144);
      this.cmdEnd.Name = "cmdEnd";
      this.cmdEnd.Size = new System.Drawing.Size(120, 34);
      this.cmdEnd.TabIndex = 3;
      this.cmdEnd.Text = "End This Program";
      this.cmdEnd.Click += new System.EventHandler(this.cmdEnd_Click);
      // 
      // cmdLaunch
      // 
      this.cmdLaunch.Location = new System.Drawing.Point(86, 48);
      this.cmdLaunch.Name = "cmdLaunch";
      this.cmdLaunch.Size = new System.Drawing.Size(120, 30);
      this.cmdLaunch.TabIndex = 2;
      this.cmdLaunch.Text = "Launch a Program";
      this.cmdLaunch.Click += new System.EventHandler(this.cmdLaunch_Click);
      // 
      // frmStartup
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdEnd);
      this.Controls.Add(this.cmdLaunch);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmStartup";
      this.Text = "LaunchProgram";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmStartup'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250629 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmStartup()
      //***
      // Action
      //   - Create instance of 'frmStartup'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250629 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmStartup()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdLaunch_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Start another process / application by opening a file
      //   - Show a file open dialog
      //   - If a file is selected to open
      //     - If the file name is nothing
      //       - Do nothing
      //     - If not
      //       - Try to start the process to open that file
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250629 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      OpenFileDialog dlgFileOpen = new OpenFileDialog();
      string strApplicationName;

      if (dlgFileOpen.ShowDialog() == DialogResult.OK)
      {
        strApplicationName = dlgFileOpen.FileName;

        if (strApplicationName == null)
        {
        }
        else
          // strApplicationName <> null
        {

          try
          {
            Process.Start(strApplicationName);
          }
          catch
          {
            MessageBox.Show("Error opening " + strApplicationName);
          }
          finally
          {
          }

        }
        // strApplicationName = null

      }
      else
        // dlgFileOpen.ShowDialog() <> DialogResult.OK
      {
      }
      // dlgFileOpen.ShowDialog() = DialogResult.OK

    }
    // cmdLaunch_Click(System.Object, System.EventArgs) Handles cmdLaunch_Click

    private void cmdEnd_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop the application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250629 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // cmdLaunch_Click(System.Object, System.EventArgs) Handles cmdLaunch.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmStartup
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmStartup()
      // Created
      //   - CopyPaste � 20250629 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250629 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmStartup());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmStartup

}
// CopyPaste.Learning