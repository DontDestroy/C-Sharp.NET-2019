//***
// Action
//   - Implementation of cpErrorTrace
// Created
//   - CopyPaste � 20240628 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240628 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Diagnostics;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpErrorTrace
  {

    #region "Constructors / Destructors"

    public cpErrorTrace(string strApplication, bool blnEventWriter)
      //***
      // Action
      //   - Constructor with a given application and a boolean to write to event log
      //   - Get the value of the environment variable "DemoSwitch"
      //     - The DemoSwitch can be set by Registry or environment variables
      //       - Off = 0, No error messages
      //       - Error = 1, Only error messages
      //       - Warning = 2, Warning messages and error messages
      //       - Info = 3, Informational messages, Warning messages and error messages
      //       - Verbose = 4, Verbose messages, Informational messages, Warning messages and error messages
      //   - Create a new instance of a TraceSwitch
      //   - Get the trace level (from the environment variable)
      //   - If TraceLevel.Off is the level
      //     - Stop the routine
      //   - If not
      //     - Define the stream writer
      //     - Define a trace listener (that writes text to the stream)
      //     - Add the trace listener to the list of trace listeners
      //     - Define the application name
      //     - Set event log on or off
      //     - If event log is on
      //       - Log to the event log
      //     - If Not
      //       - Do nothing
      //     - Add when the appliciation is started
      //     - Add the version of the application
      //     - Add the directory of the application
      //     - Add the machinename
      //     - Add the operating system
      //     - Add the user
      // Called by
      //   - 
      // Calls
      //   - WriteEventLogInformation(string)
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int intEnvironment;
      string strEnvironment = Environment.GetEnvironmentVariable("DemoSwitch");

      intEnvironment = Convert.ToInt32(strEnvironment);
      mtheTraceSwitch = new TraceSwitch("DemoSwitch", "DemoSwitch");
      mtheTraceSwitch.Level = (TraceLevel)intEnvironment;

      if (mtheTraceSwitch.Level == TraceLevel.Off)
      {
      }
      else
        // mtheTraceSwitch.Level <> TraceLevel.Off 
      {
        mErrorFileStreamWriter = File.AppendText("T:\\ErrorFile.txt");
        mtheTextWriterTraceListener = new TextWriterTraceListener(mErrorFileStreamWriter);
        
        Trace.Listeners.Add(mtheTextWriterTraceListener);
        
        mstrApplicationName = strApplication;
        mblnEventWriter = blnEventWriter;

        if (mblnEventWriter)
        {
          mtheEventLog = new EventLog("Application", ".", strApplication);
          WriteEventLogInformation(DateTime.Now + " Application: " + mstrApplicationName + " started");
        }
        else
          // Not mblnEventWriter 
        {
        }
        // mblnEventWriter 

        Trace.WriteLine(DateTime.Now + " Application: " + mstrApplicationName + " started");
        Trace.WriteLine("Application Version: " + Environment.Version.ToString());
        Trace.WriteLine("Current Directory: " + Environment.CommandLine);
        Trace.WriteLine("Machine Name: " + Environment.MachineName);
        Trace.WriteLine("Operating System: " + Environment.OSVersion.ToString());
        Trace.WriteLine("User: " + Environment.UserName.ToString());
        Trace.WriteLine("------------------------------------------");
      }
      // mtheTraceSwitch.Level = TraceLevel.Off 

    }
    // cpErrorTrace(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    private bool mblnEventWriter;
    private EventLog mtheEventLog;
    private StreamWriter mErrorFileStreamWriter;
    private string mstrApplicationName = "";
    private TextWriterTraceListener mtheTextWriterTraceListener;
    private TraceSwitch mtheTraceSwitch;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Dispose()
      //***
      // Action
      //   - Clean up the stuff when not used anymore
      //   - If TraceLevel.Off is the level
      //     - Stop the routine
      //   - If not
      //     - Add when the appliciation is ended
      //     - If event log is on
      //       - Log to the event log
      //     - If Not
      //       - Do nothing
      //     - Flush the stream writer
      //     - Close the stream writer
      // Called by
      //   - System action (Disposing the instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (mtheTraceSwitch.Level == TraceLevel.Off)
      {
      }
      else
        // mtheTraceSwitch.Level <> TraceLevel.Off 
      {
        Trace.WriteLine(DateTime.Now + "  Application: " + mstrApplicationName + " ended");

        if (mblnEventWriter)
        {
          WriteEventLogInformation(DateTime.Now + " Application: " + mstrApplicationName + " ended.");
        }
        else
          // Not mblnEventWriter 
        {
        }
        // mblnEventWriter 

        mErrorFileStreamWriter.Flush();
        mErrorFileStreamWriter.Close();
      }
      // mtheTraceSwitch.Level = TraceLevel.Off 

    }
		// Dispose()

    public void WriteError(System.Exception theException)
      //***
      // Action
      //   - Write the error information
      //   - If trace info is on
      //     - Write the error message
      //   - If trace verbose is on
      //     - Write the text "Stack Trace:"
      //     - Write the stack trace
      //   - If event log is on
      //     - Log to the event log
      //   - If Not
      //     - Do nothing
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Trace.WriteLineIf(mtheTraceSwitch.TraceInfo, "Error: " + theException.Message);
      Trace.WriteLineIf(mtheTraceSwitch.TraceVerbose, "Stack Trace: ");
      Trace.WriteLineIf(mtheTraceSwitch.TraceVerbose, theException.StackTrace);
      Trace.WriteLineIf(mtheTraceSwitch.TraceVerbose, "------------------------------------");

      if (mblnEventWriter)
      {
        mtheEventLog.WriteEntry(theException.Message, EventLogEntryType.Error);
      }
      else
        // Not mblnEventWriter
      {
      }
      // mblnEventWriter 

    }
    // WriteError(System.Exception)

    public void WriteEventLogInformation(string strMessage)
      //***
      // Action
      //   - Write an information message to the event log
      // Called by
      //   - Dispose()
      //   - cpErrorTrace(string, bool)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mtheEventLog.WriteEntry(strMessage, EventLogEntryType.Information);
    }
    // WriteEventLogInformation(string)

    public void WriteEventLogWarning(string strMessage)
      //***
      // Action
      //   - Write a warning message to the event log
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mtheEventLog.WriteEntry(strMessage, EventLogEntryType.Warning);
    }
    // WriteEventLogInformation(string)

    public void WriteText(string strMessage)
      //***
      // Action
      //   - Write an the error message
      //   - If trace info is on
      //     - Write the message
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Trace.WriteLineIf(mtheTraceSwitch.TraceInfo, strMessage);
    }
    // WriteText(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpErrorTrace

}
// CopyPaste.Learning