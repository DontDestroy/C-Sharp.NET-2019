//***
// Action
//   - Demo the functionality of an inputbox
// Created
//   - CopyPaste � 20240219 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240219 � VVDW
// Proposal (To Do)
//   - 
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmInputBox: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.Label lblOne;
    internal System.Windows.Forms.Button cmdInputBox;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmInputBox));
      this.cmdExit = new System.Windows.Forms.Button();
      this.lblOne = new System.Windows.Forms.Label();
      this.cmdInputBox = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdExit
      // 
      this.cmdExit.Location = new System.Drawing.Point(32, 78);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.Size = new System.Drawing.Size(88, 32);
      this.cmdExit.TabIndex = 4;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // lblOne
      // 
      this.lblOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblOne.Location = new System.Drawing.Point(152, 22);
      this.lblOne.Name = "lblOne";
      this.lblOne.Size = new System.Drawing.Size(160, 32);
      this.lblOne.TabIndex = 5;
      this.lblOne.Text = "Label1";
      // 
      // cmdInputBox
      // 
      this.cmdInputBox.Location = new System.Drawing.Point(32, 22);
      this.cmdInputBox.Name = "cmdInputBox";
      this.cmdInputBox.Size = new System.Drawing.Size(88, 32);
      this.cmdInputBox.TabIndex = 3;
      this.cmdInputBox.Text = "&InputBox";
      this.cmdInputBox.Click += new System.EventHandler(this.cmdInputBox_Click);
      // 
      // frmInputBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(392, 133);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.lblOne);
      this.Controls.Add(this.cmdInputBox);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmInputBox";
      this.Text = "Test InputBox";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmInputBox'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240219 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240219 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmInputBox()
      //***
      // Action
      //   - Create instance of 'frmInputBox'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240219 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240219 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmInputBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop the application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240219 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240219 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit.Click

    private void cmdInputBox_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Ask for a name using an inputbox
      //   - Fill in the typed value in the only label of the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240219 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240219 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strPrompt;
      string strFullName;
      
      strPrompt = "Type your name, please.";
      strFullName = Interaction.InputBox(strPrompt, "Copy Paste", "", 0, 0);
      lblOne.Text = strFullName;
    }
    // cmdInputBox_Click(System.Object, System.EventArgs) Handles cmdInputBox.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmInputBox
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240219 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240219 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmInputBox());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmInputBox

}
// CopyPaste.Learning