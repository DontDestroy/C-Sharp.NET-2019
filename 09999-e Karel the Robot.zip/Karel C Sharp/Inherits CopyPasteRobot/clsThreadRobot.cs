﻿//***
// Action
//   - A definition of a ThreadRobot
// Created
//   - CopyPaste – 20251105 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251105 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using java.lang;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpThreadRobot : cpCopyPasteRobot, Runnable
	{

		#region "Constructors / Destructors"

		public cpThreadRobot(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpThreadRobot starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - A new thread of the cpThreadRobot is defined
    //   - The thread is started
    // Called by
    //   - cpProgram.ThreadRobot()
    //   - cpThreadRobot(int, int, Directions.Direction, int) 
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251105 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251105 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Thread theRobotRunnerThread = new Thread(this);

      theRobotRunnerThread.start();
    }
    // cpThreadRobot(int, int, Directions.Direction, int, Color) 

    public cpThreadRobot(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpThreadRobot starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpThreadRobot(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251105 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251105 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpThreadRobot(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override void run()
    //***
    // Action
    //   - Define what must be runned
    //   - Robot moves to the next beeper
    //   - Robot switch off
    // Called by
    //   - cpThreadRobot(int, int, Directions.Direction, int, Color) 
    // Calls
    //   - cpCopyPasteRobot.MoveToBeeper()
    // Created
    //   - CopyPaste – 20251105 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251105 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      MoveToBeeper();
      turnOff();
    }
    // run()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpThreadRobot

}
// cpKarelTheRobot