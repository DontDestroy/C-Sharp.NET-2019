//***
// Action
//   - A solution of the exercise for handling an overflow
// Created
//   - CopyPaste � 20240518 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240518 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmOverflowCatch: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdCalculateResult;
    internal System.Windows.Forms.Label lblSum;
    internal System.Windows.Forms.Label lblSecond;
    internal System.Windows.Forms.Label lblFirst;
    internal System.Windows.Forms.TextBox txtSum;
    internal System.Windows.Forms.TextBox txtSecond;
    internal System.Windows.Forms.TextBox txtFirst;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmOverflowCatch));
      this.cmdCalculateResult = new System.Windows.Forms.Button();
      this.lblSum = new System.Windows.Forms.Label();
      this.lblSecond = new System.Windows.Forms.Label();
      this.lblFirst = new System.Windows.Forms.Label();
      this.txtSum = new System.Windows.Forms.TextBox();
      this.txtSecond = new System.Windows.Forms.TextBox();
      this.txtFirst = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdCalculateResult
      // 
      this.cmdCalculateResult.Location = new System.Drawing.Point(80, 200);
      this.cmdCalculateResult.Name = "cmdCalculateResult";
      this.cmdCalculateResult.Size = new System.Drawing.Size(104, 23);
      this.cmdCalculateResult.TabIndex = 13;
      this.cmdCalculateResult.Text = "Calculate Result";
      this.cmdCalculateResult.Click += new System.EventHandler(this.cmdCalculateResult_Click);
      // 
      // lblSum
      // 
      this.lblSum.Location = new System.Drawing.Point(16, 136);
      this.lblSum.Name = "lblSum";
      this.lblSum.Size = new System.Drawing.Size(96, 23);
      this.lblSum.TabIndex = 11;
      this.lblSum.Text = "Sum";
      // 
      // lblSecond
      // 
      this.lblSecond.Location = new System.Drawing.Point(16, 88);
      this.lblSecond.Name = "lblSecond";
      this.lblSecond.Size = new System.Drawing.Size(96, 23);
      this.lblSecond.TabIndex = 9;
      this.lblSecond.Text = "Second Value";
      // 
      // lblFirst
      // 
      this.lblFirst.Location = new System.Drawing.Point(16, 32);
      this.lblFirst.Name = "lblFirst";
      this.lblFirst.Size = new System.Drawing.Size(96, 23);
      this.lblFirst.TabIndex = 7;
      this.lblFirst.Text = "First Value";
      // 
      // txtSum
      // 
      this.txtSum.Location = new System.Drawing.Point(112, 136);
      this.txtSum.Name = "txtSum";
      this.txtSum.TabIndex = 12;
      this.txtSum.Text = "";
      // 
      // txtSecond
      // 
      this.txtSecond.Location = new System.Drawing.Point(112, 88);
      this.txtSecond.Name = "txtSecond";
      this.txtSecond.TabIndex = 10;
      this.txtSecond.Text = "";
      // 
      // txtFirst
      // 
      this.txtFirst.Location = new System.Drawing.Point(112, 32);
      this.txtFirst.Name = "txtFirst";
      this.txtFirst.TabIndex = 8;
      this.txtFirst.Text = "";
      // 
      // frmOverflowCatch
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdCalculateResult);
      this.Controls.Add(this.lblSum);
      this.Controls.Add(this.lblSecond);
      this.Controls.Add(this.lblFirst);
      this.Controls.Add(this.txtSum);
      this.Controls.Add(this.txtSecond);
      this.Controls.Add(this.txtFirst);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmOverflowCatch";
      this.Text = "Addition Catch";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmOverflowCatch'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 200070315 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 200070315 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmOverflowCatch()
      //***
      // Action
      //   - Create instance of 'frmOverflowCatch'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmOverflowCatch()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCalculateResult_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If the first value is not filled in
      //     - Show an error
      //   - If not
      //     - If the second value is not filled in
      //       - Show an error
      //     - If not
      //       - Try
      //         - Convert both texts into numbers
      //         - Add them together
      //         - Show the result
      //       - When there is an overflow error
      //         - Show a corresponding error message
      //         - Show "Overflow Error" as result
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      
      if (txtFirst.Text.Length == 0)
      {
        MessageBox.Show("Must specify first value");
      }
      else if (txtSecond.Text.Length == 0)
        // txtFirst.Text.Length <> 0
      {
        MessageBox.Show("Must specify second value");
      }
      else
        // txtSecond.Text.Length <> 0
      {
        int lngFirst;
        int lngResult;
        int lngSecond;

        try
        {
          lngFirst = Convert.ToInt32(txtFirst.Text);
          lngSecond = Convert.ToInt32(txtSecond.Text);
          lngResult = checked (lngFirst + lngSecond);
          txtSum.Text = lngResult.ToString();
        }
        catch (OverflowException theOverflowException)
        {
          MessageBox.Show("Error: Overflow error detected", "Copy Paste");
          txtSum.Text = "Overflow Error";
        }

      }
      // txtFirst.Text.Length = 0
      // txtSecond.Text.Length = 0
    
    }
    // cmdCalculateResult_Click(System.Object, System.EventArgs) Handles cmdCalculateResult.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmOverflowCatch
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmOverflowCatch()
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmOverflowCatch());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmOverflowCatch

}
// CopyPaste.Learning