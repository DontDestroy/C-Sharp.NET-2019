//***
// Action
//   - Scoping variables
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Scoping
{

  public class frmScoping : System.Windows.Forms.Form
  {
    #region Windows Form Designer generated code
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    System.ComponentModel.Container components;
    internal System.Windows.Forms.Label lblOutput;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmScoping));
      this.lblOutput = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // lblOutput
      // 
      this.lblOutput.Location = new System.Drawing.Point(8, 8);
      this.lblOutput.Name = "lblOutput";
      this.lblOutput.Size = new System.Drawing.Size(312, 200);
      this.lblOutput.TabIndex = 1;
      this.lblOutput.Text = "Label1";
      // 
      // frmScoping
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(328, 213);
      this.Controls.Add(this.lblOutput);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmScoping";
      this.Text = "Scoping Demonstration";
      this.Load += new System.EventHandler(this.frmScoping_Load);
      this.ResumeLayout(false);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmScoping'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
          
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmScoping()
    //***
    // Action
    //   - Create instance of 'frmScoping'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmScoping()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    static long lngValue = 1;
    // Instance variable can be used anywhere in class
    // long mlngValue = 1:

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmScoping_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Initialize a local variable (same as module variable)
    //   - Call some subroutines
    //   - Show result in form
    // Called by
    //   - System action (Loading the form)
    // Calls
    //   - Environment.NewLine
    //   - MethodA()
    //   - MethodB()
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      long lngValue = 5;
    // Variable local to frmScoping_Load hides instance variable

    lblOutput.Text = "Local variable value in frmScoping_Load is " + lngValue;
    MethodA();
    // MethodA has automatic local value
    MethodB();
    // MethodB uses instance variable value
    MethodA();
    // MethodA creates new automatic local value
    MethodB();
    // Instance variable value retains its value
    lblOutput.Text += Environment.NewLine + Environment.NewLine + "Local variable value in frmScoping_Load is " + lngValue;
    }
    // frmScoping_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion
    
    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmScoping
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmScoping());
    }
    // Main() 

    private void MethodA()
    //***
    // Action
    //   - Initialize a local variable (automatic local variable value hides instance variable)
    //   - This variable is initialized after each call
    //   - Show result in form
    // Called by
    //   - frmScoping_Load(System.Object, System.EventArgs) Handles this.Load
    // Calls
    //   - Environment.NewLine
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngValue = 25;
      
      lblOutput.Text += Environment.NewLine + Environment.NewLine + "Local variable value in MethodA is " + lngValue + " after entering MethodA";
      lngValue += 1;
      lblOutput.Text += Environment.NewLine + "Local variable value in MethodA is " + lngValue + " before exiting MethodA";
    }
    // MethodA()

    private void MethodB()
    //***
    // Action
    //  - Initialize a local variable (uses instance variable value)
    //  - This variable is initialized after each call
    //  - Show result in form
    // Called by
    //   - frmScoping_Load(System.Object, System.EventArgs) Handles this.Load
    // Calls
    //   - Environment.NewLine
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      lblOutput.Text += Environment.NewLine + Environment.NewLine + "instance variable value is " + lngValue + " after entering MethodB";
      lngValue *= 10;
      lblOutput.Text += Environment.NewLine + "instance variable value is " + lngValue + " before exiting MethodB";
    }
    // MethodB()

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmScoping

}
// Scoping