﻿//***
// Action
//   - A pet shop, the WPF form and the definitions of an animal (base class)
//   - Working with properties (Get and Set) and methods in several classes, that can be reused
//   - This is not fully documented, because it becomes very big and unclear
//   - This is not an optimal solution, but is used to explain things (everything is in the same file)
//   - The only purpose is explain that is can be used in this way
// Created
//   - CopyPaste – 20230407 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW
// Tested
//   - CopyPaste – 20230407 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CopyPaste.PetShop
{

  public partial class wpfPetShop : Window
  {

    #region "Constructors / Destructors"

    public wpfPetShop()
    {
      InitializeComponent();
    }
    // wpfPetShop()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    Animal[] arrPets = new Animal[9];
    int intCounter;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdPlay_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    {
      MessageBox.Show(arrPets[lstAnimal.SelectedIndex].Play());
    }
    // cmdPlay_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdPlay.Click

    private void cmdSpeak_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    {
      MessageBox.Show(arrPets[lstAnimal.SelectedIndex].Speak());
    }
    // cmdSpeak_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdSpeak.Click

    private void lstAnimal_SelectionChanged(System.Object theSender, System.Windows.Controls.SelectionChangedEventArgs theSelectionChangedEventArgs)
    {
      Display(arrPets[lstAnimal.SelectedIndex]);
    }
    // lstAnimal_SelectionChanged(System.Object, System.Windows.Controls.SelectionChangedEventArgs) Handles lstAnimal.SelectionChanged

    private void wndStartup_Initialized(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define some animals (Dogs, Cats and Birds)
    // Called by
    //   - User action (Loading a form)
    // Calls
    //   - Not documented
    // Created
    //   - CopyPaste – 20230407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230407 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      arrPets[0] = new Dog("Ranger");

      arrPets[0].Breed = "German Shepherd";
      arrPets[0].Coloration = "Brown/Black";
      arrPets[0].Cost = 200;
      arrPets[0].Gender = "Male";

      arrPets[1] = new MiniDoxen("Cindy", "Black");
      arrPets[1].Gender = "Female";

      arrPets[2] = new GreatDane("Sir Ralph", "Brown/White");
      arrPets[2].Gender = "Male";

      arrPets[3] = new Cat("Misty");
      arrPets[3].Breed = "Calico";
      arrPets[3].Coloration = "Orange/Black";
      arrPets[3].Cost = 50;
      arrPets[3].Gender = "Female";

      arrPets[4] = new Siamese("Buster", "Orange/White");
      arrPets[4].Gender = "Male";

      arrPets[5] = new Manx("Horatio", "Brown");
      arrPets[5].Gender = "Male";

      arrPets[6] = new Bird("Bluebill");
      arrPets[6].Breed = "Blue Macaw Parrot";
      arrPets[6].Coloration = "Blue/Green/Yellow";
      arrPets[6].Cost = 1200;
      arrPets[6].Gender = "Male";

      arrPets[7] = new Cockatiel("Sparky", "Gray/Yellow");
      arrPets[7].Gender = "Female";

      arrPets[8] = new Parakeet("Sprinkles", "White");
      arrPets[8].Gender = "Male";

      for (intCounter = 0; intCounter < arrPets.Length; intCounter++)
      {
        lstAnimal.Items.Add(arrPets[intCounter].Breed);
      }
      // intCounter = arrPets.Length

    }
    // wndStartup_Initialized(System.Object, System.EventArgs) Handles wndStartup.Initialized

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void Display(Animal thePet)
    {
      txtName.Text = thePet.Name;
      txtSpecies.Text = thePet.Species;
      txtBreed.Text = thePet.Breed;
      txtGender.Text = thePet.Gender;
      txtColor.Text = thePet.Coloration;
      txtLeg.Text = Convert.ToString(thePet.Legs);
      txtCost.Text = Convert.ToString(thePet.Cost);
    }
    // Display(°Animal)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfPetShop

  public class Animal
  {

    #region "Constructors / Destructors"

    public Animal()
    {
      strSpecies = "";
      strBreed = "";
      strColor = "";
      strName = "";
      strGender = "";
      intLegs = 0;
      intCost = 0;
      Console.WriteLine("Animal default constructor");
    }
    // Animal()

    public Animal(string strSpecies, int intLegs) : this()
    {
      Species = strSpecies;
      Legs = intLegs;
      Console.WriteLine("Animal overloaded constructor");
    }
    // Animal(string, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int intCost;
    private int intLegs;
    private string strBreed;
    private string strColor;
    private string strGender;
    private string strName;
    private string strSpecies;

    #endregion

    #region "Properties"

    public string Breed
    {

      get
      {
        return strBreed;
      }
      // string Breed (Get)

      set
      {
        strBreed = value;
      }
      // Breed(string) (Set)

    }
    // string Breed

    public string Coloration
    {

      get
      {
        return strColor;
      }
      // string Coloration (Get)

      set
      {
        strColor = value;
      }
      // Coloration(string) (Set)

    }
    // string Coloration

    public int Cost
    {

      get
      {
        return intCost;
      }
      // int Cost (Get)

      set
      {
        intCost = value;
      }
      // Cost(int) (Set)

    }
    // string Cost

    public string Gender
    {

      get
      {
        return strGender;
      }
      // string Gender (Get)

      set
      {
        strGender = value;
      }
      // Gender(string) (Set)

    }
    // string Gender

    public int Legs
    {

      get
      {
        return intLegs;
      }
      // int Legs (Get)

      set
      {
        intLegs = value;
      }
      // Legs(int) (Set)

    }
    // string Legs

    public string Name
    {

      get
      {
        return strName;
      }
      // string Name (Get)

      set
      {
        strName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    public string Species
    {

      get
      {
        return strSpecies;
      }
      // string Species (Get)

      set
      {
        strSpecies = value;
      }
      // Species(string) (Set)

    }
    // string Species

    #endregion

    //#region "Methods"

    #region "Overrides"

    public virtual string Play()
    {
      Console.WriteLine("Animal.Play");
      return "";
    }
    // string Play()

    public virtual string Speak()
    {
      Console.WriteLine("Animal.Speak");
      return "";
    }
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // Animal

  public class Bird : Animal
  {

    #region "Constructors / Destructors"

    public Bird() : base("Bird", 2)
    {
      Breed = "";
      Gender = "";
      Coloration = "";
      Cost = 0;
      Console.WriteLine("Bird default constructor");
    }
    // Bird()

    public Bird(string strName) : this()
    {
      Name = strName;
    }
    // Bird(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Play()
    {
      Console.WriteLine("Bird.Play");
      return Name + " bites your finger.";
    }
    //string Play()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Bird

  public class Cat : Animal
  {

    #region "Constructors / Destructors"

    public Cat() : base("Cat", 4)
    {
      Breed = "";
      Gender = "";
      Coloration = "";
      Cost = 0;
      Console.WriteLine("Cat default constructor");
    }
    // Cat()

    public Cat(string strName) : this()
    {
      Name = strName;
      Console.WriteLine("Cat overloaded constructor");
    }
    // Cat(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Play()
    {
      Console.WriteLine("Cat.Play");
      return Name + " attacks the yarn ball";
    }
    // string Play()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Cat()

  public class Cockatiel : Bird
  {

    #region "Constructors / Destructors"

    public Cockatiel() : base()
    {
      Breed = "Cockatiel";
      Cost = 250;
      Console.WriteLine("Cockatiel default constructor");
    }
    // Parakeet()

    public Cockatiel(string strName, string strColor) : base(strName)
    {
      Breed = "Cockatiel";
      Cost = 250;
      Coloration = strColor;
      Console.WriteLine("Cockatiel overloaded constructor");
    }
    // Cockatiel(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Speak()
    {
      Console.WriteLine("Cockatiel.Speak");
      return Name + " says 'Squawkkk, " + Name + " want a cracker!'";
    }
    //End Function
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Parakeet

  public class Dog : Animal
  {

    #region "Constructors / Destructors"

    public Dog() : base("Dog", 4)
    {
      Breed = "";
      Gender = "";
      Coloration = "";
      Cost = 0;
      Console.WriteLine("Dog default constructor");
    }
    // Dog()

    public Dog(string strName) : this()
    {
      Name = strName;
      Console.WriteLine("Dog overloaded constructor");
    }
    // Dog(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Play()
    {
      Console.WriteLine("Dog.Play");
      return Name + " fetches the frisbie";
    }
    // string Play()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Dog()

  public class GreatDane : Dog
  {

    #region "Constructors / Destructors"

    public GreatDane() : base()
    {
      Breed = "Great Dane";
      Cost = 400;
      Console.WriteLine("GreatDane default constructor");
    }
    // GreatDane()

    public GreatDane(string strName, string strColor) : base(strName)
    {
      Breed = "Great Dane";
      Cost = 400;
      Coloration = strColor;
      Console.WriteLine("GreatDane overloaded constructor");
    }
    // GreatDane(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Speak()
    {
      Console.WriteLine("GreatDane.Speak");
      return Name + " says 'oof, Woof!'";
    }
    //End Function
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // GreatDane

  public class Manx : Cat
  {

    #region "Constructors / Destructors"

    public Manx() : base()
    {
      Breed = "Manx";
      Cost = 100;
      Console.WriteLine("Manx default constructor");
    }
    // Manx()

    public Manx(string strName, string strColor) : base(strName)
    {
      Breed = "Manx";
      Cost = 100;
      Coloration = strColor;
      Console.WriteLine("Manx overloaded constructor");
    }
    // Manx(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Speak()
    {
      Console.WriteLine("Siamese.Speak");
      return Name + " says 'ffftttt!'";
    }
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Manx

  public class MiniDoxen : Dog
  {

    #region "Constructors / Destructors"

    public MiniDoxen() : base()
    {
      Breed = "Miniature Doxen";
      Cost = 600;
      Console.WriteLine("MiniDoxen default constructor");
    }
    // MiniDoxen()

    public MiniDoxen(string strName, string strColor) : base(strName)
    {
      Breed = "Miniature Doxen";
      Cost = 600;
      Coloration = strColor;
      Console.WriteLine("MiniDoxen overloaded constructor");
    }
    // MiniDoxen(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Speak()
    {
      Console.WriteLine("MiniDoxen.Speak");
      return Name + " says 'Boo boo boo boo!'";
    }
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // MiniDoxen

  public class Parakeet : Bird
  {

    #region "Constructors / Destructors"

    public Parakeet() : base()
    {
      Breed = "Parakeet";
      Cost = 75;
      Console.WriteLine("Parakeet default constructor");
    }
    // Parakeet()

    public Parakeet(string strName, string strColor) : base(strName)
    {
      Breed = "Parakeet";
      Cost = 75;
      Coloration = strColor;
      Console.WriteLine("Parakeet overloaded constructor");
    }
    // Parakeet(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Speak()
    {
      Console.WriteLine("Parakeet.Speak");
      return Name + " says 'Pee-dee-deet, peet.'";
    }
    //End Function
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Parakeet

  public class Siamese : Cat
  {

    #region "Constructors / Destructors"

    public Siamese() : base()
    {
      Breed = "Siamese";
      Cost = 250;
      Console.WriteLine("Siamese default constructor");
    }
    // Siamese()

    public Siamese(string strName, string strColor) : base(strName)
    {
      Breed = "Siamese";
      Cost = 250;
      Coloration = strColor;
      Console.WriteLine("Siamese overloaded constructor");
    }
    // Siamese(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Speak()
    {
      Console.WriteLine("Siamese.Speak");
      return Name + " says 'Rrrrowwll!'";
    }
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Siamese

}
// CopyPaste.PetShop