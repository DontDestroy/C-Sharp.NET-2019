﻿//***
// Action
//   - Implementation of cpAdd
// Created
//   - CopyPaste – 20260128 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260128 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpAdd: cpCalculation 
  {

    #region "Constructors / Destructors"

    public cpAdd() : this(1, 1)
    //***
    // Action
    //   - Basic constructor with no parameters
    // Called by
    //   - 
    // Calls
    //   - cpAdd(int, int)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpAdd()

    public cpAdd(int intFirstValue, int intSecondValue)
    //***
    // Action
    //   - Basic constructor with 2 parameters
    // Called by
    //   - cpAdd()
    //   - cpProgram.Main()
    // Calls
    //   - FirstValue(int) (Set)
    //   - SecondValue(int) (Set)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      FirstValue = intFirstValue;
      SecondValue = intSecondValue;
    }
    // cpAdd(int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public override int FirstValue
    {
      
      get
      //***
      // Action Get
      //   - Return _firstValue
      // Called by
      //   - int Calculate()
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        return _firstValue;
      }
      // int FirstValue (Get)

      set
      //***
      // Action Set
      //   - _firstValue becomes value
      // Called by
      //   - cpAdd(int, int)
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        _firstValue = value;
      }
      // FirstValue(int) (Set)

    }
    // int FirstValue

    public override int SecondValue
    {

      get
      //***
      // Action Get
      //   - Return _secondValue
      // Called by
      //   - int Calculate()
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        return _secondValue;
      }
      // int SecondValue (Get)

      set
      //***
      // Action Set
      //   - _secondValue becomes value
      // Called by
      //   - cpAdd(int, int)
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        _secondValue = value;
      }
      // FirstValue(int) (Set)

    }
    // int FirstValue

    #endregion

    #region "Methods"

    #region "Overrides"

    public override int Calculate()
    //***
    // Action
    //   - Return the addition of two values
    // Called by
    //   - cpProgram.Main() (Thru inheritance)
    // Calls
    //   - int FirstValue (Get)
    //   - int SecondValue (Get)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      int intResult;

      intResult = FirstValue + SecondValue;
      return intResult;
    }
    // int Calculate()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpAdd

}
// CopyPaste.Learning