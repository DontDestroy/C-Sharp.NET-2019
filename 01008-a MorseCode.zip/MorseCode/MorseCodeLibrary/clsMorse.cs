﻿//***
// Action
//   - Implementation of a cpMorse
//		 - The implementation of Morse ingredients
//       - Translation tables from Text to Morse
//       - Translation tables from Morse to Text
//     - All class that inherit have an implementation of "SendMessage" (with Morse code)
//       - This is done thru delegates and events
//       - Meaning, that the functionality is outside the class of cpMorse
//     - All class that inherit must convert text to morse on the Output Window
//       - This methods are shared over all inherited classes
// Created
//   - CopyPaste – 20241227 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20241227 – VVDW
// Proposal (To Do)
//   - Workout a tree to find easily the translation from Morse towards a character (look at hoffmann code)
//***

using System.Collections.Generic;
using System.Reflection;

namespace CopyPaste.MorseCode.Library
{

	public class cpMorse
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Basic constructor that accepts a speed in milliseconds
		/// </summary>
		/// <param name="intSpeed"></param>
		public cpMorse(int intSpeed)
		//***
		// Action
		//   - Set the speed of the conversion to intSpeed
		//   - The way to send a message is by default by immediate or output window
		// Called by
		//   - CopyPaste.MorseCode.frmMorseCode.frmMorseCode_Load(System.Object, EventArgs) Handles frmMorseCode.Load
		//   - CopyPaste.MorseCode.Test.cpProgram()
		// Calls
		//   - SignalItems(List<cpSignalItem>) (Set)
		//   - Speed(int) (Set)
		//   - cpMorseByOutputWindow()
		//   - HowToSendMessage(cpiMessageMorse) (Set)
		// Created
		//   - CopyPaste – 20241227 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20241227 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			SignalItems = new List<cpSignalItem>();
			Speed = intSpeed;
			HowToSendMessage = new cpMorseByOutputWindow(Speed);
		}
		// cpMorse(int)

		/// <summary>
		/// Static Constructor of cpMorse
		/// </summary>
		static cpMorse()
		//***
		// Action
		//   - Create the Text to Morse dictionary
		//   - Create the Morse to Text dictionary
		//     - All for "abcdefghijklmnopqrstuvwxyz0123456789.,?:;-/"'()=+^°_"
		// Called by
		//   - CopyPaste.MorseCode.frmMorseCode_Load(System.Object, EventArgs) Handles frmMorseCode.Load
		//   - CopyPaste.MorseCode.Test.cpProgram()
		// Calls
		//   - AddToDictionary(string, string)
		// Created
		//   - CopyPaste – 20241227 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20241227 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			AddToDictionary("a", "01");
			AddToDictionary("b", "1000");
			AddToDictionary("c", "1010");
			AddToDictionary("d", "100");
			AddToDictionary("e", "0");
			AddToDictionary("f", "0010");
			AddToDictionary("g", "110");
			AddToDictionary("h", "0000");
			AddToDictionary("i", "00");
			AddToDictionary("j", "0111");
			AddToDictionary("k", "101");
			AddToDictionary("l", "0100");
			AddToDictionary("m", "11");
			AddToDictionary("n", "10");
			AddToDictionary("o", "111");
			AddToDictionary("p", "0110");
			AddToDictionary("q", "1101");
			AddToDictionary("r", "010");
			AddToDictionary("s", "000");
			AddToDictionary("t", "1");
			AddToDictionary("u", "001");
			AddToDictionary("v", "0001");
			AddToDictionary("w", "011");
			AddToDictionary("x", "1001");
			AddToDictionary("y", "1011");
			AddToDictionary("z", "1100");
			AddToDictionary("0", "11111");
			AddToDictionary("1", "01111");
			AddToDictionary("2", "00111");
			AddToDictionary("3", "00011");
			AddToDictionary("4", "00001");
			AddToDictionary("5", "00000");
			AddToDictionary("6", "10000");
			AddToDictionary("7", "11000");
			AddToDictionary("8", "11100");
			AddToDictionary("9", "11110");
			AddToDictionary(".", "010101");
			AddToDictionary(",", "110011");
			AddToDictionary("?", "001100");
			AddToDictionary(":", "111000");
			AddToDictionary(";", "101010");
			AddToDictionary("-", "100001");
			AddToDictionary("/", "10010");
			AddToDictionary("\"", "010010");
			AddToDictionary("\'", "011110");
			AddToDictionary("(", "10110");
			AddToDictionary(")", "101101");
			AddToDictionary("=", "10001");
			AddToDictionary("+", "01010");
			AddToDictionary("$", "0001001");
			AddToDictionary("_", "001101");
		}
		// cpMorse()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		static private char _chrDash = '1';
		static private char _chrDot = '0';
		static private Dictionary<string, string> _dicTextToMorse = new Dictionary<string, string>();
		static private Dictionary<string, string> _dicMorseToText = new Dictionary<string, string>();

		public event cpDelegateSendMessage PerformSendMessage;

		private cpiMessageMorse cpHowToSendMessage;

		private int _intLengthDash;
		private int _intLengthDot;
		private int _intPauseBetweenLetters;
		private int _intPauseBetweenSymbols;
		private int _intPauseBetweenWords;
		private int _intSpeed;
		private string _strMessage;

		#endregion

		#region "Properties"

		/// <summary>
		/// List of cpSignalItem
		/// </summary>
		private List<cpSignalItem> SignalItems { get; set; }

		/// <summary>
		/// Get and Set how to send a message in Morse
		/// </summary>
		public cpiMessageMorse HowToSendMessage
		{

			get
			//***
			// Action Get
			//   - Return cpHowToSendMessage
			// Called by
			//   - CleanBehaviour()
			//   - cpMorse(int)
			//   - HowToSendMessage(cpiMessageMorse) (Set)
			//   - HowToDisplay(cpiMessageMorse) (Set)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20241227 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20241227 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return cpHowToSendMessage;
			}
			// cpiMessageMorse HowToSendMessage (Get)

			set
			//***
			// Action Set
			//   - We don't remove the previous behaviour from the event
			//     - Activate the code if you want to do this
			//   - cpHowToSendMessage becomes value
			//   - Add the new functionality to the event
			// Called by
			//   - CleanBehaviour()
			//   - CopyPaste.MorseCode.frmMorseCode.cmdSend_Click(System.Object, EventArgs) Handles cmdSend.Click
			// Calls
			//   - cpiMessageMorse HowToSendMessage (Get)
			//   - cpiMessageMorse.SendMessage()
			// Created
			//   - CopyPaste – 20241227 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20241227 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				// CleanBehaviour();
				// Do the code above, if you want to replace behaviour to the event instead of adding the behaviour

				cpHowToSendMessage = value;
				PerformSendMessage += new cpDelegateSendMessage(HowToSendMessage.SendMessage);
			}
			// HowToSendMessage(cpiMessageMorse) (Set)

		}
		// cpiMessageMorse HowToSendMessage

		/// <summary>
		/// Get or set the message for the Morse signal
		/// </summary>
		public string Message
		{

			get
			//***
			// Action Get
			//   - Return _strMessage
			// Called by
			//   - GenerateSignal()
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20241227 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20241227 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return _strMessage;
			}
			// string Message (Get)

			set
			//***
			// Action Set
			//   - _strMessage becomes value
			// Called by
			//   - CopyPaste.MorseCode.frmMorseCode.cmdSend_Click(System.Object, EventArgs) Handles cmdSend.Click
			//   - CopyPaste.MorseCode.Test.cpProgram()
			// Calls
			//   - GenerateSignal()
			// Created
			//   - CopyPaste – 20241227 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20241227 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				_strMessage = value;
				GenerateSignal();
			}
			// Message(string) (Set)

		}
		// string Message

		/// <summary>
		/// Get the dictionary MorseToText
		/// </summary>
		private static Dictionary<string, string> MorseToText
		{

			get
			//***
			// Action Get
			//   - Return _dicMorseToText
			// Called by
			//   - AddToDictionary(string, string)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20241227 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20241227 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return _dicMorseToText;
			}
			// Dictionary<string, string> MorseToText (Get)

		}
		// Dictionary<string, string> MorseToText

		/// <summary>
		/// Get the dictionary TextToMorse
		/// </summary>
		private static Dictionary<string, string> TextToMorse
		{

			get
			//***
			// Action Get
			//   - Return _dicTextToMorse
			// Called by
			//   - AddToDictionary(string, string)
			// Calls
			//   - GenerateSignal()
			// Created
			//   - CopyPaste – 20241227 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 2024122 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return _dicTextToMorse;
			}
			// Dictionary<string, string> TextToMorse (Get)

		}
		// Dictionary<string, string> TextToMorse

		/// <summary>
		/// Get or set a speed for the Morse signal
		/// </summary>
		public int Speed
		{

			get
			//***
			// Action Get
			//   - Return _intSpeed
			// Called by
			//   - CopyPaste.MorseCode.frmMorseCode.cmdSend_Click(System.Object, EventArgs) Handles cmdSend.Click
			//   - CopyPaste.MorseCode.Test.cpProgram()
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20241227 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20241227 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return _intSpeed;
			}
			// int Speed (Get)

			set
			//***
			// Action Set
			//   - _intSpeed becomes value
			//   - _intLengthDot becomes value
			//   - _intLengthDash becomes three times the value
			//   - _intPauseBetweenLetters becomes
			//   - _intPauseBetweenSymbols becomes
			//   - _intPauseBetweenWords becomes
			// Called by
			//   - CopyPaste.MorseCode.Test.cpProgram()
			//   - cpMorse(int)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20241227 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20241227 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				_intSpeed = value;
				_intLengthDot = value;
				_intLengthDash = value * 3;
				_intPauseBetweenSymbols = value;
				_intPauseBetweenLetters = value * 3;
				_intPauseBetweenWords = value * 6;
			}
			// Speed(int) (Set)

		}
		// int Speed

		#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		#region "Event"

		public delegate void cpDelegateSendMessage(List<cpSignalItem> lstMessage);

		#endregion

		#region "Sub / Function"

		/// <summary>
		/// Add a signal item to the list of signal items
		/// </summary>
		/// <param name="aSignalItem"></param>
		public void Add(cpSignalItem aSignalItem)
		//***
		// Action
		//   - Add a cpSignal item to be send
		// Called by
		//   - CopyPaste.MorseCode.Test.cpProgram()
		//   - GenerateSignal()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20241227 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20241227 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			SignalItems.Add(aSignalItem);
		}
		// Add(cpSignalItem)

		/// <summary>
		/// Add a character and corresponding code to translating dictionaries
		/// </summary>
		/// <param name="strCharacter"></param>
		/// <param name="strMorse"></param>
		private static void AddToDictionary(string strCharacter, string strMorse)
		//***
		// Action
		//   - Add strCharacter and strMorse to _dicTextToMorse
		//   - Add strMorse and strCharacter to _dicMorseToText
		// Called by
		//   - cpMorse()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20241227 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20241227 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			TextToMorse.Add(strCharacter, strMorse);
			MorseToText.Add(strMorse, strCharacter);
		}
		// AddToDictionary(string, string)

		/// <summary>
		/// Clean the existing behaviour from a cpMorse
		/// </summary>
		public void CleanBehaviour()
		//***
		// Action
		//   - If there is a behaviour for sending
		//     - Remove it
		// Called by
		//   - CopyPaste.MorseCode.frmMorseCode.cmdSend_Click(System.Object, EventArgs) Handles cmdSend.Click
		//   - CopyPaste.MorseCode.frmMorseCode.frmMorseCode_Load(System.Object, EventArgs) Handles frmMorseCode.Load
		//   - CopyPaste.MorseCode.Test.cpProgram()
		// Calls
		//   - cpiMessageMorse HowToSendMessage (Get)
		//   - cpiMessageMorse.SendMessage()
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   - PerformSendMessage = null; // This would remove them all, but here we only want to remove the last
		//***
		{

			if (PerformSendMessage == null)
			{
			}
			else
			// PerformSendMessage <> null
			{
				PerformSendMessage -= new cpDelegateSendMessage(HowToSendMessage.SendMessage);
			}
			// PerformSendMessage = null

		}
		// CleanBehaviour()

		/// <summary>
		/// 
		/// </summary>
		private void GenerateSignal()
		//***
		// Action
		//   - Clear the signal items
		//   - Get the message string
		//   - Loop thru all the characters of the message string
		//     - If the character is a space
		//       - Create a signal item No signal for having a pause between the words
		//       - Add the signal to the list of signal items 
		//     - If not
		//       - Lower the character
		//       - Find the character in the TextToMorse dictionary and put it into strMorse
		//       - Calculate the length of strMorse
		//       - Loop thru the morse symbols
		//         - If the symbol is a dot (0)
		//           - Create a signal item with signal for having a dot
		//           - Add the signal to the list of signal items 
		//         - If not
		//           - Create a signal item with signal for having a dash
		//           - Add the signal to the list of signal items 
		//				 - If you have had the last symbol
		//           - Create a signal item No signal for having a pause between letters
		//           - Add the signal to the list of signal items 
		//				 - If not
		//           - Create a signal item No signal for having a pause between symbols
		//           - Add the signal to the list of signal items 
		// Called by
		//   - Message(string) (Set)
		// Calls
		//   - Add(cpSignalItem)
		//   - cpSignalItem(bool, int)
		//   - Dictionary<string, string> TextToMorse (Get)
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   - PerformSendMessage = null; // This would remove them all, but here we only want to remove the last
		//***
		{
			string strMessage;

			SignalItems.Clear();
			strMessage = Message;

			foreach (char theCharacter in strMessage)
			{

				if (theCharacter == ' ')
				{
					cpSignalItem theNewWordSignal = new cpSignalItem(false, _intPauseBetweenWords);
					Add(theNewWordSignal);
				}
				else
				// theCharacter <> ' '
				{
					char chrMorseSymbol;
					int intLengthOfMorseMinusOne;
					string strCharacter;
					string strMorse;

					strCharacter = theCharacter.ToString();
					strCharacter = strCharacter.ToLower();
					strMorse = TextToMorse[strCharacter];
					intLengthOfMorseMinusOne = strMorse.Length - 1;

					for (int intCounter = 0; intCounter <= intLengthOfMorseMinusOne; intCounter++)
					{ 
						chrMorseSymbol = strMorse[intCounter];

						if (chrMorseSymbol == _chrDot)
						{
							cpSignalItem theDot = new cpSignalItem(true, _intLengthDot);
							SignalItems.Add(theDot);
						}
						else
						// chrMorseSymbol <> _chrDot
						{
							cpSignalItem theDash = new cpSignalItem(true, _intLengthDash);
							SignalItems.Add(theDash);
						}
						// chrMorseSymbol == _chrDot

						if (intCounter == intLengthOfMorseMinusOne)
						{
							cpSignalItem theNewLetterSignal = new cpSignalItem(false, _intPauseBetweenLetters);
							SignalItems.Add(theNewLetterSignal);
						}
						else
						// intCounter <> intLengthOfMorseMinusOne
						{
							cpSignalItem theNewSymbolSignal = new cpSignalItem(false, _intPauseBetweenSymbols);
							SignalItems.Add(theNewSymbolSignal);
						}
						// intCounter == intLengthOfMorseMinusOne

					}
					// intCounter > intLengthOfMorseMinusOne

				}
				// theCharacter == ' '

			}
			// in strMessage

		}
		// GenerateSignal()

		/// <summary>
		/// Define how the  moves in the air
		/// </summary>
		public void SendMessage()
		//***
		// Action
		//   - If PerformSendMessage is null
		//     - Do nothing
		//   - If Not
		//     - Execute PerformSendMessage
		// Called by
		//   - CopyPaste.MorseCode.frmMorseCode.cmdSend_Click(System.Object, EventArgs) Handles cmdSend.Click
		//   - CopyPaste.MorseCode.Test.cpProgram()
		// Calls
		//   - PerformSendMessage(List<cpSignalItem>)
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformSendMessage == null)
			{
			}
			else
			// PerformSendMessage <> null
			{
				PerformSendMessage(SignalItems);
			}
			// PerformSendMessage = null

		}
		// SendMessage()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpMorse

}
// CopPaste.MorseCode.Library