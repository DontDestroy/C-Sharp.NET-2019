﻿//***
// Action
//   - Implementation of a cpDisplayPicture
//		 - The way a thing can't fly in the air
// Created
//   - CopyPaste – 20240727 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240727 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Duck;

namespace CopyPaste.Game.Animal.Library
{

	public class cpDisplayPicture : cpiDisplay
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpFlyNoWay
		/// </summary>
		public cpDisplayPicture(frmDuckGame aForm)
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - frmDuckGame.cmbChooseDuck_SelectedIndexChanged(System.Object, EventArgs) Handles cmbChooseDuck.SelectedIndexChanged
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			theForm = aForm;
		}
		// cpDisplayPicture(frmDuckGame)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private frmDuckGame theForm;

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing is shown in a picture box
		/// </summary>
		public void Display()
		//***
		// Action
		//   - Define how something is shown on a form in a picture box
		//   - Find the location where the pictures are located
		//   - Make sure that there is a backslash at the end of the location
		//   - Add the folder "DuckDisplays" to the path
		//   - Construct the filename of the picture
		//     - Find the last occurrence of a '.' (to get the type name)
		//   - Add this to the path
		//   - Show the picture in the picture box
		// Called by
		//   - frmDuckGame.cmbChooseDuck_SelectedIndexChanged(System.Object, EventArgs) Handles cmbChooseDuck.SelectedIndexChanged
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			string strPath;
			string strFullName;

			try
			{

				if (theForm.cmbChooseDuck.SelectedItem == null)
				{
				}
				else
				// theForm.cmbChooseDuck.SelectedItem <> null
				{
					strPath = Environment.CurrentDirectory;

					if (strPath.EndsWith('\\'))
					{
					}
					else
					// Not strPath.EndsWith('\\')
					{
						strPath += "\\";
					}
					// strPath.EndsWith('\\')

					strFullName = theForm.cmbChooseDuck.SelectedItem.ToString();

					if (strFullName.Contains('.'))
					{
						strFullName = strFullName.Substring(strFullName.LastIndexOf(".") + 1);
					}
					else
					// Not strFullName.Contains('.')
					{
					}
					// strFullName.Contains('.')

					strPath = strPath + "DuckDisplays\\" + strFullName + ".jpg";
					theForm.picImage.Image = Image.FromFile(strPath);
				}
				// cmbChooseDuck.SelectedItem = null

			}
			catch (FileNotFoundException theException)
			{
				string strException = theException.ToString();
				// VVDW - I do nothing with this text yet
				theForm.lblErrorMessage.Text = "The picture was not found";
			}
			catch (Exception theException)
			{
				theForm.lblErrorMessage.Text = theException.ToString();
			}

		}
  	// Display()

	#endregion

	#endregion

	#endregion

	//#region "Not used"
	//#endregion

}
	// cpDisplayPicture

}
// CopyPaste.Game.Animal.Library