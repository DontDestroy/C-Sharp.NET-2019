//***
// Action
//   - Test the Custom Text Control
// Created
//   - CopyPaste � 20250716 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250716 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTestControl: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    private CopyPaste.Learning.cpControls.cpctlTextBoxColor txtTextBox;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTestControl));
      this.txtTextBox = new CopyPaste.Learning.cpControls.cpctlTextBoxColor();
      this.SuspendLayout();
      // 
      // txtTextBox
      // 
      this.txtTextBox.Location = new System.Drawing.Point(72, 48);
      this.txtTextBox.Name = "txtTextBox";
      this.txtTextBox.Size = new System.Drawing.Size(128, 24);
      this.txtTextBox.TabIndex = 0;
      this.txtTextBox.ColorChanged += new CopyPaste.Learning.cpControls.cpctlTextBoxColor.ColorDelegate(this.txtTextBox_ColorChanged);
      // 
      // frmTestControl
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 141);
      this.Controls.Add(this.txtTextBox);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTestControl";
      this.Text = "Simple Custom Control";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTestControl'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTestControl()
      //***
      // Action
      //   - Create instance of 'frmTestControl'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTestControl()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void txtTextBox_ColorChanged(Color theColor)
      //***
      // Action
      //   - Show the current color information after color is changed
      // Called by
      //   - User action (Changing Color) (Thru event)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show("The textbox color was changed to " + theColor.ToString(), "Copy Paste - Custom Control", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // txtTextBoxColor_ColorChanged(Color) Handles txtTextBoxColor.ColorChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTestControl
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmTestControl()
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTestControl());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTestControl

}
// CopyPaste.Learning