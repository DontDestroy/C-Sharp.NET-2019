//***
// Action
//   - Show the records using a subquery
//   - Locate Records with Duplicate Values
//     - Show customers where there is more than one customer in a city
// Created
//   - CopyPaste � 20260114 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260114 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSubqueries: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.IContainer components;
    internal System.Windows.Forms.DataGrid dgrResult;
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.Label lblSQLString;
    internal System.Windows.Forms.Label lblSQLStatement;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSubqueries));
      this.dgrResult = new System.Windows.Forms.DataGrid();
      this.lblResult = new System.Windows.Forms.Label();
      this.lblSQLString = new System.Windows.Forms.Label();
      this.lblSQLStatement = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.dgrResult)).BeginInit();
      this.SuspendLayout();
      // 
      // dgrResult
      // 
      this.dgrResult.AlternatingBackColor = System.Drawing.Color.Silver;
      this.dgrResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrResult.BackColor = System.Drawing.Color.White;
      this.dgrResult.CaptionBackColor = System.Drawing.Color.Maroon;
      this.dgrResult.CaptionFont = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.CaptionForeColor = System.Drawing.Color.White;
      this.dgrResult.DataMember = "";
      this.dgrResult.Font = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.ForeColor = System.Drawing.Color.Black;
      this.dgrResult.GridLineColor = System.Drawing.Color.Silver;
      this.dgrResult.HeaderBackColor = System.Drawing.Color.Silver;
      this.dgrResult.HeaderFont = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.HeaderForeColor = System.Drawing.Color.Black;
      this.dgrResult.LinkColor = System.Drawing.Color.Maroon;
      this.dgrResult.Location = new System.Drawing.Point(16, 154);
      this.dgrResult.Name = "dgrResult";
      this.dgrResult.ParentRowsBackColor = System.Drawing.Color.Silver;
      this.dgrResult.ParentRowsForeColor = System.Drawing.Color.Black;
      this.dgrResult.PreferredColumnWidth = 100;
      this.dgrResult.SelectionBackColor = System.Drawing.Color.Maroon;
      this.dgrResult.SelectionForeColor = System.Drawing.Color.White;
      this.dgrResult.Size = new System.Drawing.Size(456, 144);
      this.dgrResult.TabIndex = 7;
      // 
      // lblResult
      // 
      this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblResult.Location = new System.Drawing.Point(16, 130);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(96, 16);
      this.lblResult.TabIndex = 6;
      this.lblResult.Text = "Results";
      // 
      // lblSQLString
      // 
      this.lblSQLString.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblSQLString.Location = new System.Drawing.Point(16, 34);
      this.lblSQLString.Name = "lblSQLString";
      this.lblSQLString.Size = new System.Drawing.Size(456, 80);
      this.lblSQLString.TabIndex = 5;
      // 
      // lblSQLStatement
      // 
      this.lblSQLStatement.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblSQLStatement.Location = new System.Drawing.Point(16, 10);
      this.lblSQLStatement.Name = "lblSQLStatement";
      this.lblSQLStatement.Size = new System.Drawing.Size(168, 16);
      this.lblSQLStatement.TabIndex = 4;
      this.lblSQLStatement.Text = "SQL Statement";
      // 
      // frmSubqueries
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(480, 309);
      this.Controls.Add(this.dgrResult);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.lblSQLString);
      this.Controls.Add(this.lblSQLStatement);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSubqueries";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Locate Records with Duplicate Values";
      this.Load += new System.EventHandler(this.frmSubqueries_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrResult)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSubqueries'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSubqueries()
      //***
      // Action
      //   - Create instance of 'frmSubqueries'
      // Called by
      //   - frmMain.cmdSubQueries_Click(System.Object, System.EventArgs) Handles cmdSubQueries.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSubqueries()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    private void frmSubqueries_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a data adapter
      //   - Define and create a data table
      //   - Define and set a SQL Statement
      //   - Create the data adapter using the SQL statement and the connection
      //   - Try to
      //     - Fill the data table using the data adapter
      //     - The data table becomes the data source of the data grid
      //   - When error occurs
      //     - Show exception message
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpGeneralRoutines()
      //   - SqlClient.SqlConnection cpGeneralRoutines.GetConnection()
      //   - string cpGeneralRoutines.BuildConnectionString()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpGeneralRoutines theRoutines = new cpGeneralRoutines();
      DataTable dtResult = new DataTable();
      SqlDataAdapter dtaResult;
      string strSQLStatement;

      strSQLStatement = "SELECT tblCPCustomer.strCity, tblCPCustomer.strRegion, tblCPCustomer.strIdCustomer, " +
        "tblCPCustomer.strCompanyName FROM tblCPCustomer " +
        "WHERE ((tblCPCustomer.strCity IN " +
        "(SELECT tblHelp.strCity FROM tblCPCustomer As tblHelp " +
        "GROUP BY tblHelp.strCity,tblHelp.strRegion HAVING Count(*) > 1 " +
        "AND strRegion = tblCPCustomer.strRegion))) " +
        "ORDER BY tblCPCustomer.strCity, tblCPCustomer.strRegion";
      lblSQLString.Text = strSQLStatement;

      dtaResult = new SqlDataAdapter(strSQLStatement, theRoutines.GetConnection());
      // dtaResult = new SqlDataAdapter(strSQLStatement, theRoutines.BuildConnectionString());

      try
      {
        dtaResult.Fill(dtResult);
        dgrResult.DataSource = dtResult;
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }

    }
    // frmSubQueries_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSubqueries

}
// CopyPaste.Learning