﻿//***
// Action
//   - Having DataViews in database actions
// Created
//   - CopyPaste – 20210716 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210716 – VVDW
// Proposal (To Do)
//   -
//***

namespace DataViews
{

  partial class frmDataViews
  {

    #region Windows Form Designer generated code
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;
    internal System.Windows.Forms.Button cmdFind;
    internal System.Windows.Forms.Button cmdSort;
    internal System.Windows.Forms.Button cmdRowState;
    internal System.Windows.Forms.Button cmdCreate;
    internal System.Windows.Forms.ListBox lstClient;
    internal System.Windows.Forms.ListBox lstEmployee;
    internal System.Windows.Forms.Label lblOrder;
    internal System.Windows.Forms.Label lblClient;
    internal System.Windows.Forms.Label lblEmployee;
    internal System.Data.DataView dvOrder;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwindScript;
    internal System.Data.SqlClient.SqlDataAdapter dtaOrder;
    internal System.Data.SqlClient.SqlCommand cmmSelectOrder;
    internal System.Data.SqlClient.SqlDataAdapter dtaCustomer;
    internal System.Data.SqlClient.SqlCommand cmmSelectCustomer;
    internal System.Data.SqlClient.SqlDataAdapter dtaEmployee;
    internal System.Data.SqlClient.SqlCommand cmmSelectEmployee;
    private dsData dsData;
    internal System.Windows.Forms.DataGrid dgrOrder;


    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataViews));
      this.cmdFind = new System.Windows.Forms.Button();
      this.cmdSort = new System.Windows.Forms.Button();
      this.cmdRowState = new System.Windows.Forms.Button();
      this.cmdCreate = new System.Windows.Forms.Button();
      this.lstEmployee = new System.Windows.Forms.ListBox();
      this.dsData = new DataViews.dsData();
      this.lstClient = new System.Windows.Forms.ListBox();
      this.lblOrder = new System.Windows.Forms.Label();
      this.lblClient = new System.Windows.Forms.Label();
      this.lblEmployee = new System.Windows.Forms.Label();
      this.dvOrder = new System.Data.DataView();
      this.cnncpNorthwindScript = new System.Data.SqlClient.SqlConnection();
      this.dtaOrder = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectOrder = new System.Data.SqlClient.SqlCommand();
      this.dtaCustomer = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectCustomer = new System.Data.SqlClient.SqlCommand();
      this.dtaEmployee = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectEmployee = new System.Data.SqlClient.SqlCommand();
      this.dgrOrder = new System.Windows.Forms.DataGrid();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dvOrder)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdFind
      // 
      this.cmdFind.Location = new System.Drawing.Point(416, 114);
      this.cmdFind.Name = "cmdFind";
      this.cmdFind.Size = new System.Drawing.Size(96, 23);
      this.cmdFind.TabIndex = 19;
      this.cmdFind.Text = "Find";
      this.cmdFind.Click += new System.EventHandler(this.cmdFind_Click);
      // 
      // cmdSort
      // 
      this.cmdSort.Location = new System.Drawing.Point(416, 82);
      this.cmdSort.Name = "cmdSort";
      this.cmdSort.Size = new System.Drawing.Size(96, 23);
      this.cmdSort.TabIndex = 18;
      this.cmdSort.Text = "Sort";
      this.cmdSort.Click += new System.EventHandler(this.cmdSort_Click);
      // 
      // cmdRowState
      // 
      this.cmdRowState.Location = new System.Drawing.Point(416, 50);
      this.cmdRowState.Name = "cmdRowState";
      this.cmdRowState.Size = new System.Drawing.Size(96, 24);
      this.cmdRowState.TabIndex = 17;
      this.cmdRowState.Text = "Row State";
      this.cmdRowState.Click += new System.EventHandler(this.cmdRowState_Click);
      // 
      // cmdCreate
      // 
      this.cmdCreate.Location = new System.Drawing.Point(416, 18);
      this.cmdCreate.Name = "cmdCreate";
      this.cmdCreate.Size = new System.Drawing.Size(96, 24);
      this.cmdCreate.TabIndex = 16;
      this.cmdCreate.Text = "Create";
      this.cmdCreate.Click += new System.EventHandler(this.cmdCreate_Click);
      // 
      // lstEmployee
      // 
      this.lstEmployee.DataSource = this.dsData;
      this.lstEmployee.DisplayMember = "tblCPEmployee.strLastName";
      this.lstEmployee.Location = new System.Drawing.Point(8, 26);
      this.lstEmployee.Name = "lstEmployee";
      this.lstEmployee.Size = new System.Drawing.Size(184, 95);
      this.lstEmployee.TabIndex = 11;
      this.lstEmployee.ValueMember = "tblCPEmployee.intIdEmployee";
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // lstClient
      // 
      this.lstClient.DataSource = this.dsData;
      this.lstClient.DisplayMember = "tblCPCustomer.strCompanyName";
      this.lstClient.Location = new System.Drawing.Point(200, 26);
      this.lstClient.Name = "lstClient";
      this.lstClient.Size = new System.Drawing.Size(200, 95);
      this.lstClient.TabIndex = 13;
      this.lstClient.ValueMember = "tblCPCustomer.strIdCustomer";
      this.lstClient.SelectedIndexChanged += new System.EventHandler(this.lstClient_SelectedIndexChanged);
      // 
      // lblOrder
      // 
      this.lblOrder.AutoSize = true;
      this.lblOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOrder.Location = new System.Drawing.Point(8, 138);
      this.lblOrder.Name = "lblOrder";
      this.lblOrder.Size = new System.Drawing.Size(48, 13);
      this.lblOrder.TabIndex = 14;
      this.lblOrder.Text = "Orders:";
      // 
      // lblClient
      // 
      this.lblClient.AutoSize = true;
      this.lblClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblClient.Location = new System.Drawing.Point(200, 10);
      this.lblClient.Name = "lblClient";
      this.lblClient.Size = new System.Drawing.Size(49, 13);
      this.lblClient.TabIndex = 12;
      this.lblClient.Text = "Clients:";
      // 
      // lblEmployee
      // 
      this.lblEmployee.AutoSize = true;
      this.lblEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblEmployee.Location = new System.Drawing.Point(8, 10);
      this.lblEmployee.Name = "lblEmployee";
      this.lblEmployee.Size = new System.Drawing.Size(71, 13);
      this.lblEmployee.TabIndex = 10;
      this.lblEmployee.Text = "Employees:";
      // 
      // dvOrder
      // 
      this.dvOrder.Sort = "intIdOrder";
      this.dvOrder.Table = this.dsData.tblCPOrder;
      // 
      // cnncpNorthwindScript
      // 
      this.cnncpNorthwindScript.ConnectionString = "Data Source=COPYPASTEPOWER\\COPYPASTE;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthwindScript.FireInfoMessageEventOnUserErrors = false;
      // 
      // dtaOrder
      // 
      this.dtaOrder.SelectCommand = this.cmmSelectOrder;
      this.dtaOrder.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPOrder", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intEmployeeId", "intEmployeeId"),
                        new System.Data.Common.DataColumnMapping("strCustomerId", "strCustomerId"),
                        new System.Data.Common.DataColumnMapping("intIdOrder", "intIdOrder"),
                        new System.Data.Common.DataColumnMapping("dtmOrderDate", "dtmOrderDate"),
                        new System.Data.Common.DataColumnMapping("dblFreight", "dblFreight")})});
      // 
      // cmmSelectOrder
      // 
      this.cmmSelectOrder.CommandText = "SELECT intEmployeeId, strCustomerId, intIdOrder, dtmOrderDate, dblFreight FROM tb" +
    "lCPOrder";
      this.cmmSelectOrder.Connection = this.cnncpNorthwindScript;
      // 
      // dtaCustomer
      // 
      this.dtaCustomer.SelectCommand = this.cmmSelectCustomer;
      this.dtaCustomer.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCustomer", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("strIdCustomer", "strIdCustomer"),
                        new System.Data.Common.DataColumnMapping("strCompanyName", "strCompanyName"),
                        new System.Data.Common.DataColumnMapping("strCity", "strCity"),
                        new System.Data.Common.DataColumnMapping("strCountry", "strCountry"),
                        new System.Data.Common.DataColumnMapping("strPostalCode", "strPostalCode"),
                        new System.Data.Common.DataColumnMapping("strRegion", "strRegion")})});
      // 
      // cmmSelectCustomer
      // 
      this.cmmSelectCustomer.CommandText = "SELECT strIdCustomer, strCompanyName, strCity, strCountry, strPostalCode, strRegi" +
    "on FROM tblCPCustomer";
      this.cmmSelectCustomer.Connection = this.cnncpNorthwindScript;
      // 
      // dtaEmployee
      // 
      this.dtaEmployee.SelectCommand = this.cmmSelectEmployee;
      this.dtaEmployee.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPEmployee", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdEmployee", "intIdEmployee"),
                        new System.Data.Common.DataColumnMapping("strLastName", "strLastName"),
                        new System.Data.Common.DataColumnMapping("strFirstName", "strFirstName")})});
      // 
      // cmmSelectEmployee
      // 
      this.cmmSelectEmployee.CommandText = "SELECT intIdEmployee, strLastName, strFirstName FROM tblCPEmployee";
      this.cmmSelectEmployee.Connection = this.cnncpNorthwindScript;
      // 
      // dgrOrder
      // 
      this.dgrOrder.DataMember = "";
      this.dgrOrder.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrOrder.Location = new System.Drawing.Point(8, 154);
      this.dgrOrder.Name = "dgrOrder";
      this.dgrOrder.Size = new System.Drawing.Size(504, 208);
      this.dgrOrder.TabIndex = 20;
      // 
      // frmDataViews
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
      this.ClientSize = new System.Drawing.Size(520, 373);
      this.Controls.Add(this.dgrOrder);
      this.Controls.Add(this.cmdFind);
      this.Controls.Add(this.cmdSort);
      this.Controls.Add(this.cmdRowState);
      this.Controls.Add(this.cmdCreate);
      this.Controls.Add(this.lstClient);
      this.Controls.Add(this.lstEmployee);
      this.Controls.Add(this.lblOrder);
      this.Controls.Add(this.lblClient);
      this.Controls.Add(this.lblEmployee);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataViews";
      this.Text = "DataViews";
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dvOrder)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"


    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210707 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      if (disposing && (components != null))
      {
        components.Dispose();
      }
      // (disposing && (components != null))

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataViews

}
// DataViews