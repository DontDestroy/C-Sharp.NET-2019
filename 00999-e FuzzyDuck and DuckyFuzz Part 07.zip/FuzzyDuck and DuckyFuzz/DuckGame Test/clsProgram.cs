﻿//***
// Action
//   - Testroutine for cpDecoyDuck, cpDuck, cpiFly, cpiMakeNoise, cpiWalk, cpPlasticRubberDuck, cpRedHeadDuck and cpWoodDuck
// Created
//   - CopyPaste – 20240725 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240725 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Duck.Library;
using System.Diagnostics;

namespace CopyPaste.Game.Duck.Test
{

	internal static class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		///  The main entry point for the test application
		/// </summary>
		public static void Main()
		//***
		// Action
		//   - Start application
		//   - Create a list of cpDuck
		//   - Add a cpDecoyDuck, cpMallardDuck, cpPlasticRubberDuck, cpRedHeadDuck and a cpWoodDuck to it
		//   - Loop thru all the ducks
		//     - Let the duck Display, Fly, MakeNoise, Swim and Walk
		//   - Show some information on where to check if it was successful
		//   - Wait for the user to hit the keyboard
		// Called by
		//   - User action (Starting the application)
		// Calls
		//   - CopyPaste.Game.Duck.Library.cpDuck.Display()
		//   - CopyPaste.Game.Duck.Library.cpDuck.Fly()
		//   - CopyPaste.Game.Duck.Library.cpDuck.MakeNoise()
		//   - CopyPaste.Game.Duck.Library.cpDuck.Swim()
		//   - CopyPaste.Game.Duck.Library.cpDuck.Walk()
		//   - CopyPaste.Game.Duck.Library.cpDecoyDuck()
		//   - CopyPaste.Game.Duck.Library.cpDecoyDuck.Display()
		//   - CopyPaste.Game.Duck.Library.cpMallardDuck()
		//   - CopyPaste.Game.Duck.Library.cpMallardDuck.Display()
		//   - CopyPaste.Game.Duck.Library.cpPlasticRubberDuck()
		//   - CopyPaste.Game.Duck.Library.cpPlasticRubberDuck.Display()
		//   - CopyPaste.Game.Duck.Library.cpRedHeadDuck()
		//   - CopyPaste.Game.Duck.Library.cpRedHeadDuck.Display()
		//   - CopyPaste.Game.Duck.Library.cpWoodDuck()
		//   - CopyPaste.Game.Duck.Library.cpWoodDuck.Display()
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			List<cpDuck> lstDucks = new List<cpDuck>();

			cpDecoyDuck aDecoyDuck = new cpDecoyDuck();
			cpMallardDuck aMallardDuck = new cpMallardDuck();
			cpPlasticRubberDuck aPlasticRubberDuck = new cpPlasticRubberDuck();
			cpRedHeadDuck aRedHeadDuck = new cpRedHeadDuck();
			cpWoodDuck aWoodDuck = new cpWoodDuck();

			lstDucks.Add(aDecoyDuck);
			lstDucks.Add(aMallardDuck);
			lstDucks.Add(aPlasticRubberDuck);
			lstDucks.Add(aRedHeadDuck);
			lstDucks.Add(aWoodDuck);

			foreach (cpDuck theDuck in lstDucks)
			{
				theDuck.Display();
				theDuck.Fly();
				theDuck.MakeNoise();
				theDuck.Swim();
				theDuck.Walk();
				Debug.Print("");
			}
			// in lstDucks

			Console.WriteLine("Information about the execution of methods can be found in the immediate / output window");
			Console.WriteLine();
			Console.WriteLine("Hit any key to exit the program ...");
			Console.ReadLine();
		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#Region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.Game.Duck.Test