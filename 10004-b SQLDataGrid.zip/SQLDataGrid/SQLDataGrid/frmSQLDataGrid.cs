//***
// Action
//   - Create a form with a database connection, data adapter and data set
// Created
//   - CopyPaste � 20250725 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250725 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSQLDataGrid: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Data.SqlClient.SqlCommand cmmUpdateCustomer;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwindScript;
    internal System.Data.SqlClient.SqlCommand cmmSelectCustomer;
    internal System.Data.SqlClient.SqlCommand cmmInsertCustomer;
    internal System.Windows.Forms.Button cmdUpdate;
    internal System.Data.SqlClient.SqlCommand cmmDeleteCustomer;
    internal System.Windows.Forms.Button cmdRetrieve;
    internal System.Windows.Forms.DataGrid dgrCustomer;
    private SQLDataGrid.dsCustomer dsCustomer;
		internal System.Data.SqlClient.SqlDataAdapter dtaCustomer;

    private void InitializeComponent()
    {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSQLDataGrid));
			this.cmmUpdateCustomer = new System.Data.SqlClient.SqlCommand();
			this.cnncpNorthwindScript = new System.Data.SqlClient.SqlConnection();
			this.cmmSelectCustomer = new System.Data.SqlClient.SqlCommand();
			this.cmmInsertCustomer = new System.Data.SqlClient.SqlCommand();
			this.cmdUpdate = new System.Windows.Forms.Button();
			this.cmmDeleteCustomer = new System.Data.SqlClient.SqlCommand();
			this.cmdRetrieve = new System.Windows.Forms.Button();
			this.dgrCustomer = new System.Windows.Forms.DataGrid();
			this.dtaCustomer = new System.Data.SqlClient.SqlDataAdapter();
			this.dsCustomer = new SQLDataGrid.dsCustomer();
			((System.ComponentModel.ISupportInitialize)(this.dgrCustomer)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dsCustomer)).BeginInit();
			this.SuspendLayout();
			// 
			// cmmUpdateCustomer
			// 
			this.cmmUpdateCustomer.CommandText = resources.GetString("cmmUpdateCustomer.CommandText");
			this.cmmUpdateCustomer.Connection = this.cnncpNorthwindScript;
			this.cmmUpdateCustomer.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@strIdCustomer", System.Data.SqlDbType.VarChar, 5, "strIdCustomer"),
            new System.Data.SqlClient.SqlParameter("@strCompanyName", System.Data.SqlDbType.VarChar, 40, "strCompanyName"),
            new System.Data.SqlClient.SqlParameter("@strContactName", System.Data.SqlDbType.VarChar, 30, "strContactName"),
            new System.Data.SqlClient.SqlParameter("@strContactTitle", System.Data.SqlDbType.VarChar, 30, "strContactTitle"),
            new System.Data.SqlClient.SqlParameter("@strAddress", System.Data.SqlDbType.VarChar, 60, "strAddress"),
            new System.Data.SqlClient.SqlParameter("@strCity", System.Data.SqlDbType.VarChar, 15, "strCity"),
            new System.Data.SqlClient.SqlParameter("@strRegion", System.Data.SqlDbType.VarChar, 15, "strRegion"),
            new System.Data.SqlClient.SqlParameter("@strPostalCode", System.Data.SqlDbType.VarChar, 10, "strPostalCode"),
            new System.Data.SqlClient.SqlParameter("@strCountry", System.Data.SqlDbType.VarChar, 15, "strCountry"),
            new System.Data.SqlClient.SqlParameter("@strPhone", System.Data.SqlDbType.VarChar, 24, "strPhone"),
            new System.Data.SqlClient.SqlParameter("@strFax", System.Data.SqlDbType.VarChar, 24, "strFax"),
            new System.Data.SqlClient.SqlParameter("@Original_strIdCustomer", System.Data.SqlDbType.VarChar, 5, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strIdCustomer", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strAddress", System.Data.SqlDbType.VarChar, 60, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCity", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCity", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCompanyName", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCompanyName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strContactName", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strContactName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strContactTitle", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strContactTitle", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCountry", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCountry", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strFax", System.Data.SqlDbType.VarChar, 24, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strFax", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strPhone", System.Data.SqlDbType.VarChar, 24, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strPhone", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strPostalCode", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strPostalCode", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strRegion", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strRegion", System.Data.DataRowVersion.Original, null)});
			// 
			// cnncpNorthwindScript
			// 
			this.cnncpNorthwindScript.ConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
			this.cnncpNorthwindScript.FireInfoMessageEventOnUserErrors = false;
			// 
			// cmmSelectCustomer
			// 
			this.cmmSelectCustomer.CommandText = "SELECT strIdCustomer, strCompanyName, strContactName, strContactTitle, strAddress" +
    ", strCity, strRegion, strPostalCode, strCountry, strPhone, strFax FROM tblCPCust" +
    "omer";
			this.cmmSelectCustomer.Connection = this.cnncpNorthwindScript;
			// 
			// cmmInsertCustomer
			// 
			this.cmmInsertCustomer.CommandText = resources.GetString("cmmInsertCustomer.CommandText");
			this.cmmInsertCustomer.Connection = this.cnncpNorthwindScript;
			this.cmmInsertCustomer.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@strIdCustomer", System.Data.SqlDbType.VarChar, 5, "strIdCustomer"),
            new System.Data.SqlClient.SqlParameter("@strCompanyName", System.Data.SqlDbType.VarChar, 40, "strCompanyName"),
            new System.Data.SqlClient.SqlParameter("@strContactName", System.Data.SqlDbType.VarChar, 30, "strContactName"),
            new System.Data.SqlClient.SqlParameter("@strContactTitle", System.Data.SqlDbType.VarChar, 30, "strContactTitle"),
            new System.Data.SqlClient.SqlParameter("@strAddress", System.Data.SqlDbType.VarChar, 60, "strAddress"),
            new System.Data.SqlClient.SqlParameter("@strCity", System.Data.SqlDbType.VarChar, 15, "strCity"),
            new System.Data.SqlClient.SqlParameter("@strRegion", System.Data.SqlDbType.VarChar, 15, "strRegion"),
            new System.Data.SqlClient.SqlParameter("@strPostalCode", System.Data.SqlDbType.VarChar, 10, "strPostalCode"),
            new System.Data.SqlClient.SqlParameter("@strCountry", System.Data.SqlDbType.VarChar, 15, "strCountry"),
            new System.Data.SqlClient.SqlParameter("@strPhone", System.Data.SqlDbType.VarChar, 24, "strPhone"),
            new System.Data.SqlClient.SqlParameter("@strFax", System.Data.SqlDbType.VarChar, 24, "strFax")});
			// 
			// cmdUpdate
			// 
			this.cmdUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.cmdUpdate.Location = new System.Drawing.Point(208, 263);
			this.cmdUpdate.Name = "cmdUpdate";
			this.cmdUpdate.Size = new System.Drawing.Size(104, 23);
			this.cmdUpdate.TabIndex = 5;
			this.cmdUpdate.Text = "&Update Database";
			this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
			// 
			// cmmDeleteCustomer
			// 
			this.cmmDeleteCustomer.CommandText = resources.GetString("cmmDeleteCustomer.CommandText");
			this.cmmDeleteCustomer.Connection = this.cnncpNorthwindScript;
			this.cmmDeleteCustomer.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_strIdCustomer", System.Data.SqlDbType.VarChar, 5, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strIdCustomer", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strAddress", System.Data.SqlDbType.VarChar, 60, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strAddress", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCity", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCity", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCompanyName", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCompanyName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strContactName", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strContactName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strContactTitle", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strContactTitle", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCountry", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCountry", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strFax", System.Data.SqlDbType.VarChar, 24, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strFax", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strPhone", System.Data.SqlDbType.VarChar, 24, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strPhone", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strPostalCode", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strPostalCode", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strRegion", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strRegion", System.Data.DataRowVersion.Original, null)});
			// 
			// cmdRetrieve
			// 
			this.cmdRetrieve.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.cmdRetrieve.Location = new System.Drawing.Point(40, 263);
			this.cmdRetrieve.Name = "cmdRetrieve";
			this.cmdRetrieve.Size = new System.Drawing.Size(104, 23);
			this.cmdRetrieve.TabIndex = 4;
			this.cmdRetrieve.Text = "&Retrieve Data";
			this.cmdRetrieve.Click += new System.EventHandler(this.cmdRetrieve_Click);
			// 
			// dgrCustomer
			// 
			this.dgrCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.dgrCustomer.DataMember = "";
			this.dgrCustomer.HeaderForeColor = System.Drawing.SystemColors.ControlText;
			this.dgrCustomer.Location = new System.Drawing.Point(8, 7);
			this.dgrCustomer.Name = "dgrCustomer";
			this.dgrCustomer.Size = new System.Drawing.Size(344, 240);
			this.dgrCustomer.TabIndex = 3;
			// 
			// dtaCustomer
			// 
			this.dtaCustomer.DeleteCommand = this.cmmDeleteCustomer;
			this.dtaCustomer.InsertCommand = this.cmmInsertCustomer;
			this.dtaCustomer.SelectCommand = this.cmmSelectCustomer;
			this.dtaCustomer.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCustomer", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("strIdCustomer", "strIdCustomer"),
                        new System.Data.Common.DataColumnMapping("strCompanyName", "strCompanyName"),
                        new System.Data.Common.DataColumnMapping("strContactName", "strContactName"),
                        new System.Data.Common.DataColumnMapping("strContactTitle", "strContactTitle"),
                        new System.Data.Common.DataColumnMapping("strAddress", "strAddress"),
                        new System.Data.Common.DataColumnMapping("strCity", "strCity"),
                        new System.Data.Common.DataColumnMapping("strRegion", "strRegion"),
                        new System.Data.Common.DataColumnMapping("strPostalCode", "strPostalCode"),
                        new System.Data.Common.DataColumnMapping("strCountry", "strCountry"),
                        new System.Data.Common.DataColumnMapping("strPhone", "strPhone"),
                        new System.Data.Common.DataColumnMapping("strFax", "strFax")})});
			this.dtaCustomer.UpdateCommand = this.cmmUpdateCustomer;
			// 
			// dsCustomer1
			// 
			this.dsCustomer.DataSetName = "dsCustomer";
			this.dsCustomer.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// frmSQLDataGrid
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(360, 293);
			this.Controls.Add(this.dgrCustomer);
			this.Controls.Add(this.cmdUpdate);
			this.Controls.Add(this.cmdRetrieve);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmSQLDataGrid";
			this.Text = "SQLClient Example";
			((System.ComponentModel.ISupportInitialize)(this.dgrCustomer)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dsCustomer)).EndInit();
			this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSQLDataGrid'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250725 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250725 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSQLDataGrid()
      //***
      // Action
      //   - Create instance of 'frmSQLDataGrid'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250725 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250725 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSQLDataGrid()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdRetrieve_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Clear the data set
      //   - Fill the data adapter with the info in the data set table "tblCPCustomer"
      //   - Set up the data grid
      //     - Data source is the data set
      //     - Allow sorting
      //     - Set the back color alternating
      //     - Bind the data of the data set table "tblCPCustomer"
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250725 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250725 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsCustomer.Clear();
      dtaCustomer.Fill(dsCustomer, "tblCPCustomer");

      dgrCustomer.DataSource = dsCustomer;
      dgrCustomer.AllowSorting = true;
      dgrCustomer.AlternatingBackColor = System.Drawing.Color.Bisque;
      dgrCustomer.SetDataBinding(dsCustomer, "tblCPCustomer");   
    }
    // cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click

    private void cmdUpdate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Update the data grid
      //   - Update the data set thru the data adapter
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250725 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250725 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dgrCustomer.Update();
      dtaCustomer.Update(dsCustomer);
    }
    // cmdUpdate_Click(System.Object, System.EventArgs) Handles cmdUpdate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSQLDataGrid
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSQLDataGrid()
      // Created
      //   - CopyPaste � 20250725 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250725 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSQLDataGrid());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSQLDataGrid

}
// CopyPaste.Learning