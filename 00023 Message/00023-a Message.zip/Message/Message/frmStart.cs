//***
// Action
//   - Showing a messagebox. Starting point is an empty form.
// Created
//   - CopyPaste � 20210831 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210831 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Windows.Forms;

namespace Message
{

  public class frmStart : System.Windows.Forms.Form
	{

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmStart));
      // 
      // frmStart
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(512, 445);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmStart";
      this.Text = "Start Screen";
      this.Load += new System.EventHandler(this.frmStart_Load);

    }

    #endregion

    #region "Constructors / Destructors"
    
    protected override void Dispose( bool disposing )
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210831 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210831 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if ( disposing )
      {
        if (components == null) 
        {
        }
        else
          // (components != null) 
        {
          components.Dispose();
        }
        // (components == null) 

      }
      else
        // Not ( disposing )
      {
      }
      // ( disposing )

      base.Dispose( disposing );
    }
    // Dispose( bool )
  
    public frmStart()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210831 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210831 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmStart()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmStart_Load(System.Object theSender, System.EventArgs theEventArguments)
    {
      //***
      // Action
      //   - Show a MessageBox message
      //   - Show a MessageBox message with button OK
      //   - Show a MessageBox message with title and 3 buttons
      //   - Show a MessageBox message with title and 2 buttons
      //   - Show a MessageBox message with title and 2 buttons with icon and remember the answer
      //   - Depending on the answer, show a MessageBox message
      // Called by
      //   - User action (starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20210831 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20210831 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***

      DialogResult dlgrResponse;

      MessageBox.Show("C# .NET Programming For The Absolute Beginner");
      MessageBox.Show("Hi There!", "Copy Paste", MessageBoxButtons.OK);
      MessageBox.Show("Nuclear Meltdown In Progress!", "Copy Paste", MessageBoxButtons.AbortRetryIgnore);
      MessageBox.Show("Do you want to format your hard drive?", "Copy Paste", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
      MessageBox.Show("Error connecting to server...", "Copy Paste", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation);
      dlgrResponse = MessageBox.Show("How about a game of Global Thermonuclear War?", "Copy Paste", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

      if (dlgrResponse == DialogResult.Yes)
      {
        MessageBox.Show("On second thought, that's not such a good idea.", "Result");
      }
      else
        // dlgrResponse <> DialogResult.Yes
      {
        MessageBox.Show("Chicken!", "Result");
      }
      // dlgrResponse = DialogResult.Yes
    
    }
    // frmStart_Load(System.Object, System.EventArgs)

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    // Action
    //   - Start of the application
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmMathQuiz()
    // Created
    //   - CopyPaste � 20210831 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210831 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmStart());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmStart

}
// Message