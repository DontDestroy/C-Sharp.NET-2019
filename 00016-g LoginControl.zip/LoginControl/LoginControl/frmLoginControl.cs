//***
// Action
//   - Button that calls an inputbox that is checked on content
// Created
//   - CopyPaste � 20240227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240227 � VVDW
// Proposal (To Do)
//   - 
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmLoginControl: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.PictureBox picPhoto;
    internal System.Windows.Forms.Button cmdLogin;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmLoginControl));
      this.picPhoto = new System.Windows.Forms.PictureBox();
      this.cmdLogin = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // picPhoto
      // 
      this.picPhoto.Location = new System.Drawing.Point(18, 88);
      this.picPhoto.Name = "picPhoto";
      this.picPhoto.Size = new System.Drawing.Size(256, 168);
      this.picPhoto.TabIndex = 3;
      this.picPhoto.TabStop = false;
      // 
      // cmdLogin
      // 
      this.cmdLogin.Location = new System.Drawing.Point(18, 8);
      this.cmdLogin.Name = "cmdLogin";
      this.cmdLogin.Size = new System.Drawing.Size(72, 32);
      this.cmdLogin.TabIndex = 2;
      this.cmdLogin.Text = "&Login";
      this.cmdLogin.Click += new System.EventHandler(this.cmdLogin_Click);
      // 
      // frmLoginControl
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.picPhoto);
      this.Controls.Add(this.cmdLogin);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmLoginControl";
      this.Text = "Login control";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmLoginControl'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmLoginControl()
      //***
      // Action
      //   - Create instance of 'frmLoginControl'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmLoginControl()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdLogin_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Ask for a name using an inputbox
      //   - Take the current directory (path)
      //   - Test the name on "Jan" or "Piet"
      //     - Show a welcome message
      //     - Show a picture
      //   - All other names
      //     - Show a warning
      //     - End application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strPath;
      string strUserName;

      strUserName = Interaction.InputBox("Enter your firstname. (Jan or Piet or something else)", "", "", 0, 0);
      strPath = Directory.GetCurrentDirectory();

      if (strUserName == "Jan")
      {
        MessageBox.Show("Welcome, Jan!  How do you do?");
        picPhoto.Image = Image.FromFile(strPath + "\\jan.jpg");
      }
      else if (strUserName == "Piet")
        // strUserName <> "Jan"
      {
        MessageBox.Show("Welcome, Piet!  How are you today?");
        picPhoto.Image = Image.FromFile(strPath + "\\piet.jpg");
      }
      else
        // strUserName <> "Jan"
        // strUserName <> "Piet"
      {
        MessageBox.Show("Sorry, I don't know who you are.");
        this.Close();
      }
      // strUserName = "Jan"
      // strUserName = "Piet"

    }
    // cmdLogin_Click(System.Object, System.EventArgs) Handles cmdLogin.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmLoginControl
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmLoginControl());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmLoginControl

}
// CopyPaste.Learning