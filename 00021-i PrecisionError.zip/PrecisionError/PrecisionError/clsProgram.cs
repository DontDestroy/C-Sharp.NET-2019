//***
// Action
//   - Demo of the not precise calculations of single
// Created
//   - CopyPaste � 20240414 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240414 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Start with value 0.01 and loop till 0.1 by adding 0.01
      //     - The moment you reach 0.05
      //       - Show message
      //   - Show message that loop is ended
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240414 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240414 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      float sngNumber;

      for (sngNumber = 0.01F; sngNumber < 01; sngNumber += 0.01F)
      {

        if (sngNumber == 0.05)
        {
          Console.WriteLine("Reached 0.05");
        }
        else
          // sngNumber <> 0.05
        {
        }
        // sngNumber = 0.05

      }
      // sngNumber = 0.100999939


      Console.WriteLine("Done with loop");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning