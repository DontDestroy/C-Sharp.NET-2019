//***
// Action
//   - Implementation of a WML Page Content
// Created
//   - CopyPaste � 20240412 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240412 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Page
{

  public class cpWMLPage: cpPageContent
  {

    #region "Constructors / Destructors"

    public cpWMLPage(string strMessage) : base(strMessage)
      //***
      // Action
      //   - Constructor with Message
      // Called by
      //   - cpProgram.Main(�
      // Calls
      //   - cpPageContent(string)
      // Created
      //   - CopyPaste � 20240412 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240412 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override void ShowPage()
      //***
      // Action
      //   - Start wml node
      //   - Start card id node
      //   - Define page data
      //   - Define action node that TGIF images are accepted
      //   - Define that when you click on the image you go to a website
      //   - Stop action node
      //   - Stop card id node
      //   - Stop wml node
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240412 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240412 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("<wml>");
      Console.WriteLine("<card id=\"Demo\">");
      Console.WriteLine("<p>" + mstrPageData + "</p>");
      Console.WriteLine("<do type=\"accept\" label=\"TGIF\">");
      Console.WriteLine("<go href=\"www.CopyPaste.com\" />");
      Console.WriteLine("</do>");
      Console.WriteLine("</card>");
      Console.WriteLine("</wml>");
    }
    // ShowPage()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpWMLPage

}
// CopyPaste.Learning.Page