//***
// Action
//   - Implementation of cpSavingsAccount
//   - This is a bankAccount, but you can add an interest on it
// Created
//   - CopyPaste � 20240221 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240221 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpSavingsAccount : cpBankAccount
  {

    #region "Constructors / Destructors"

    public cpSavingsAccount(string strOwner) : base(strOwner)
      //***
      // Action
      //   - Constructor of a cpSavingsAccount that defines an owner
      // Called by
      //   - frmSavingsAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - cpBankAccount(string)
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpCheckingAccount(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private decimal mdecInterest = 0.03M;

    #endregion

    #region "Properties"

    public override string Id
    {
      
      get
        //***
        // Action Get
        //   - Returns the Id (owner) of a cpBankAccount with a "-S" added at the end
        // Called by
        //   - frmSavingsAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
        // Calls
        //   - string cpBankAccount.Id (Get)
        // Created
        //   - CopyPaste � 20240221 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240221 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return base.Id + "-S";
      }
      // string Id (Get)

    }
    // string Id

    public decimal Interest
    {

      get
        //***
        // Action Get
        //   - Returns the Interest of a cpSavingsAccount
        // Called by
        //   - AddInterest()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240221 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240221 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecInterest;
      }
      // decimal Interest (Get)

      set
        //***
        // Action Set
        //   - Set the Interest of a cpSavingsAccount to value
        // Called by
        //   - frmSavingsAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240221 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240221 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mdecInterest = value;
      }
      // Interest(decimal) (Set)

    }
    // decimal Interest

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void AddInterest()
      //***
      // Action
      //   - A certain amount (Balance * Interest) is added to the balance of the cpSavingsAccount
      // Called by
      //   - frmSavingsAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmTheBank.cmdAddInterest_Click(System.Object, System.EventArgs) Handles cmdAddInterest.Click
      // Calls
      //   - cpBankAccount.Deposit(decimal)
      //   - decimal cpBankAccount.Balance (Get)
      //   - decimal Interest (Get)
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Deposit(Interest * Balance);
    }
    // AddInterest()
    
    #endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCheckingAccount

}
// CopyPaste.Learning