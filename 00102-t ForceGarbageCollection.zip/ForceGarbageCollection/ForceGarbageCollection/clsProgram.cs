//***
// Action
//   - Testroutine for cpPet
// Created
//   - CopyPaste � 20230802 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230802 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;

namespace ForceGarbageCollection
{

  public class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Create 3 instances of cpPet
    //   - Put one to nothing
    //   - Collect the garbage
    //   - Put one to nothing
    //   - Collect the garbage
    //   - Put one to nothing
    //   - Collect the garbage
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - ~cpPet()
    //   - cpPet(string, string, double)
    // Created
    //   - CopyPaste � 20230802 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230802 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpPet theDog = new cpPet("Dog", "Buddy", 99.95);
      cpPet theBird = new cpPet("Bird", "Tweety", 199.95);
      cpPet theCat = new cpPet("Cat", "Sylvester", 39.95);

      theBird = null;
      Console.WriteLine("Started first collection");
      GC.Collect();
      
      GC.WaitForPendingFinalizers();

      theDog = null;
      Console.WriteLine("Started second collection");
      GC.Collect();
      
      theCat = null;
      Console.WriteLine("Started third collection");
      GC.Collect();
      
      Console.WriteLine("Press Enter");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// ForceGarbageCollection