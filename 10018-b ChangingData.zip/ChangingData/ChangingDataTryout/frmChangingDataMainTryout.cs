//***
// Action
//   - Starting screen with four options
// Created
//   - CopyPaste � 20251209 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251209 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmChangingDataMainTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    internal System.Windows.Forms.Button cmdStoredProcedure;
    internal System.Windows.Forms.ToolTip ttpInfo;
    internal System.Windows.Forms.Button cmdAddAndDelete;
    internal System.Windows.Forms.Button cmdEditAndUpdate;
    internal System.Windows.Forms.Button cmdChangeOnTheFly;
    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmChangingDataMainTryout));
      this.cmdStoredProcedure = new System.Windows.Forms.Button();
      this.ttpInfo = new System.Windows.Forms.ToolTip(this.components);
      this.cmdAddAndDelete = new System.Windows.Forms.Button();
      this.cmdEditAndUpdate = new System.Windows.Forms.Button();
      this.cmdChangeOnTheFly = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdStoredProcedure
      // 
      this.cmdStoredProcedure.Location = new System.Drawing.Point(44, 110);
      this.cmdStoredProcedure.Name = "cmdStoredProcedure";
      this.cmdStoredProcedure.Size = new System.Drawing.Size(112, 32);
      this.cmdStoredProcedure.TabIndex = 6;
      this.cmdStoredProcedure.Text = "Stored Procedure";
      this.cmdStoredProcedure.Click += new System.EventHandler(this.cmdStoredProcedure_Click);
      // 
      // cmdAddAndDelete
      // 
      this.cmdAddAndDelete.Location = new System.Drawing.Point(44, 62);
      this.cmdAddAndDelete.Name = "cmdAddAndDelete";
      this.cmdAddAndDelete.Size = new System.Drawing.Size(112, 32);
      this.cmdAddAndDelete.TabIndex = 5;
      this.cmdAddAndDelete.Text = "Add and Delete";
      this.cmdAddAndDelete.Click += new System.EventHandler(this.cmdAddAndDelete_Click);
      // 
      // cmdEditAndUpdate
      // 
      this.cmdEditAndUpdate.Location = new System.Drawing.Point(44, 14);
      this.cmdEditAndUpdate.Name = "cmdEditAndUpdate";
      this.cmdEditAndUpdate.Size = new System.Drawing.Size(112, 32);
      this.cmdEditAndUpdate.TabIndex = 4;
      this.cmdEditAndUpdate.Text = "Edit and Update";
      this.cmdEditAndUpdate.Click += new System.EventHandler(this.cmdEditAndUpdate_Click);
      // 
      // cmdChangeOnTheFly
      // 
      this.cmdChangeOnTheFly.Location = new System.Drawing.Point(44, 158);
      this.cmdChangeOnTheFly.Name = "cmdChangeOnTheFly";
      this.cmdChangeOnTheFly.Size = new System.Drawing.Size(112, 32);
      this.cmdChangeOnTheFly.TabIndex = 7;
      this.cmdChangeOnTheFly.Text = "Change on the fly";
      this.cmdChangeOnTheFly.Click += new System.EventHandler(this.cmdChangeOnTheFly_Click);
      // 
      // frmChangingDataMainTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(200, 205);
      this.Controls.Add(this.cmdAddAndDelete);
      this.Controls.Add(this.cmdEditAndUpdate);
      this.Controls.Add(this.cmdChangeOnTheFly);
      this.Controls.Add(this.cmdStoredProcedure);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmChangingDataMainTryout";
      this.Text = "Changing Data Main Form Tryout";
      this.Load += new System.EventHandler(this.frmChangingDataMainTryout_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmChangingDataMainTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmChangingDataMainTryout()
      //***
      // Action
      //   - Create instance of 'frmChangingDataMainTryout'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmChangingDataMainTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdAddAndDelete_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmListBoxAddDelete
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmListBoxAddDelete()
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdAddAndDelete_Click(System.Object, System.EventArgs) Handles cmdAddAndDelete.Click

    private void cmdChangeOnTheFly_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmUpdateOnTheFly
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmUpdateOnTheFly()
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdChangeOnTheFly_Click(System.Object, System.EventArgs) Handles cmdChangeOnTheFly.Click

    private void cmdEditAndUpdate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmListBoxUpdate
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmListBoxUpdate()
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdEditAndUpdate_Click(System.Object, System.EventArgs) Handles cmdEditAndUpdate.Click

    private void cmdStoredProcedure_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmStoredProcedure
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmStoredProcedure()
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdStoredProcedure_Click(System.Object, System.EventArgs) Handles cmdStoredProcedure.Click
   
    private void frmChangingDataMainTryout_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set tooltips for the buttons
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmChangingDataMainTryout_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmChangingDataMainTryout
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmChangingDataMainTryout()
      // Created
      //   - CopyPaste � 20251209 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251209 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmChangingDataMainTryout());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmChangingDataMainTryout

}
// CopyPaste.Learning