﻿//***
// Action
//   - A visualisation of a cpNetwork
// Created
//   - CopyPaste – 20230614 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230614 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CopyPaste.TelecomNetwork
{
  public partial class frmNetwork : Form
  {

    #region "Constructors / Destructors"

    public frmNetwork()
    //***
    // Action
    //   - Create instance of 'frmNetwork'
    //   - Define a cpNetwork with cpPhones
    // Called by
    //   - Main()
    // Calls
    //   - cpNetwork<cpPhone>()
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      theNetwork = new cpNetwork<cpPhone>();
    }
    // frmNetwork()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    cpNetwork<cpPhone> theNetwork;
    delegate void ClearItemsCallback();
    delegate void AddItemCallback(cpPhone aPhone);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCreate_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Use phone number and name to create a new phone
    //   - The newly created cpPhone is created and added to the cpNetwork
    //   - The combobox is refilled with the available phones
    //   - Both textboxes are emptied
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - cpNetwork.Add(T) (T : cpPhone)
    //   - cpPhone(string, string)
    //   - FillPhoneCombobox()
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - There is no check on duplicate phone numbers
    //   - The first one in the list wins
    //***
    {

      if (txtNumber.Text == "")
      {
      }
      else
      // txtNumber.Text <> ""
      {
        cpPhone newPhone = new cpPhone(txtNumber.Text, txtName.Text);
        theNetwork.Add(newPhone);
        FillPhoneCombobox();
        txtNumber.Text = "";
        txtName.Text = "";
      }
      // txtNumber.Text == ""

    }
    // cmdCreate_Click(System.Object, System.EventArgs) Handles cmdCreate.Click

    private void cmdShowPhone_Click(System.Object theSender, System.EventArgs theEventArguments)
    {

      if (cmbPhone.SelectedItem == null)
      {
      }
      else
      // cmbPhone.SelectedItem <> null
      {

        try
        {
          cpPhone theSelectedPhone = cmbPhone.SelectedItem as cpPhone;

          if (theSelectedPhone.IsOpen)
          {
            throw new Exception("The phone is already shown on the screen");
          }
          else
          // Not theSelectedPhone.IsOpen
          {
            frmPhone aPhoneWindow = new frmPhone(theNetwork, theSelectedPhone);
            aPhoneWindow.Show();
          }
          // theSelectedPhone.IsOpen

        }
        catch (Exception theException)
        {
          MessageBox.Show(theException.Message);
        }

      }
      // cmbPhone.SelectedItem = null


    }
    // cmdShowPhone_Click(System.Object, System.EventArgs) Handles cmdShowPhone.Click

    private async void frmNetwork_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - The async and await is at the moment overkill (and hard to test)
    //   - The window is loaded and the configuration is done
    //   - The different phonenumbers for the network are read from a file
    //   - The location is default the same path where the executable is placed
    //   - The file PhoneNumbers.txt has a property that newer versions must be copied toward that path
    //   - The file is read
    //   - For every information
    //     - a cpPhone is created and added to the cpNetwork
    //   - The combobox is filled with the available phones
    // Called by
    //   - System action (Form is loaded)
    // Calls
    //   - cpNetwork.Add(T) (T : cpPhone)
    //   - cpPhone(string, string)
    //   - FillPhoneCombobox()
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strFileName;
      string strPath;

      await Task.Run(() =>
      {
        strPath = Assembly.GetExecutingAssembly().Location;
        strPath = Path.GetDirectoryName(strPath);
        strFileName = strPath + "/" + "PhoneNumbers.txt";

        string[] arrPhones = File.ReadAllLines(strFileName);
        string[] arrPhoneInformation;

        foreach (string strPhone in arrPhones)
        {
          arrPhoneInformation = strPhone.Split(';');

          cpPhone aPhone = new cpPhone(arrPhoneInformation[0], arrPhoneInformation[1]);
          theNetwork.Add(aPhone);
        }
        // in arrPhones

      });

      FillPhoneCombobox();
    }
    // frmNetwork_Load(System.Object, System.EventArgs) Handles frmNetwork.Load

    private void txtFind_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Recalculate the correct phones according to the filter criteria
    // Called by
    //   - User action (Textbox is changed)
    // Calls
    //   - FillPhoneCombobox()
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FillPhoneCombobox();
    }
    // txtFind_TextChanged(System.Object, System.EventArgs) Handles txtFind.TextChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void AddToPhoneComboBox(cpPhone aPhone)
    //***
    // Action
    //   - Add a phone to the combobox
    //   - An invoke is required because of another thread
    //     - Define a callback
    //     - Invoke the addition of a cpPhone to the combobox
    //   - Otherwise
    //     - Add a cpPhone to the combobox
    //   - This is overkill, in different threads it is useful
    // Called by
    //   - FillPhoneCombobox()
    // Calls
    //   - AddToPhoneComboBox(cpPhone)
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (cmbPhone.InvokeRequired)
      {
        AddItemCallback theAddItemCallback = new AddItemCallback(AddToPhoneComboBox);
        this.Invoke(theAddItemCallback, aPhone);
      }
      else
      // cmbPhone.InvokeRequired()
      {
        cmbPhone.Items.Add(aPhone);
      }
      // cmbPhone.InvokeRequired

    }
    // AddToPhoneComboBox(cpPhone)

    private void ClearPhoneCombobox()
    //***
    // Action
    //   - An invoke is required because of another thread
    //     - Define a callback
    //     - Invoke the clear of the combobox
    //   - Otherwise
    //     - Remove all the items from the combobox
    //   - This is overkill, in different threads it is useful
    // Called by
    //   - FillPhoneCombobox()
    // Calls
    //   - ClearPhoneCombobox()
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (cmbPhone.InvokeRequired)
      {
        ClearItemsCallback theClearItemsCallBack = new ClearItemsCallback(ClearPhoneCombobox);
        this.Invoke(theClearItemsCallBack);
      }
      else
        // cmbPhone.InvokeRequired()
      {
        cmbPhone.Items.Clear();
      }
      // cmbPhone.InvokeRequired

    }
    // ClearPhoneCombobox()

    private void FillPhoneCombobox()
    //***
    // Action
    //   - Clear all the items in the combobox
    //   - Add the items (according to the filter criteria) to the combobox
    // Called by
    //   - frmNetwork_Load(System.Object, System.EventArgs) Handles frmNetwork.Load
    //   - txtFind_TextChanged(System.Object, System.EventArgs) Handles txtFind.TextChanged
    //   - cmdCreate_Click(System.Object, System.EventArgs) Handles cmdCreate.Click
    // Calls
    //   - AddToPhoneComboBox(cpPhone)
    //   - ClearPhoneCombobox()
    //   - List<T> cpNetwork.cpPhones (Get) (T : cpPhone)
    //   - string cpPhone.SearchString()
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpPhone> filteredPhoneList;
      string strSearchText = txtFind.Text;

      ClearPhoneCombobox();

      if (txtFind.Text == "")
      {
        filteredPhoneList = theNetwork.cpPhones;
      }
      // txtFind.Text <> ""
      else
      {
        filteredPhoneList = from aPhone in theNetwork.cpPhones
                            where aPhone.SearchString().Contains(txtFind.Text.ToLower())
                            select aPhone;
        // Filtering the phone list using a Linq Fluent Syntax Query Expression 

        // filteredPhoneList = theNetwork.cpPhones.Where(aPhone => aPhone.SearchString().Contains(txtFind.Text.ToLower()));
        // The same thing but in a Lambda Linq Dot Notation
      }
      // txtFind.Text == ""

      foreach (cpPhone aPhone in filteredPhoneList)
      {
        AddToPhoneComboBox(aPhone);
      }
      // in filteredPhoneList

    }
    // FillPhoneCombobox()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmNetwork

}
// CopyPaste.TelecomNetwork