﻿//***
// Action
//   - Having DataViews in database actions
// Created
//   - CopyPaste – 20210716 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210716 – VVDW
// Proposal (To Do)
//   -
//***

using System.Data;
using System.Windows.Forms;

namespace DataViews
{

  public partial class frmDataViews : Form
  {

    #region "Constructors / Destructors"

    public frmDataViews()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Fill DataSet Customer with DataAdapter
    //   - Fill DataSet Order with DataAdapter
    //   - Fill DataSet Employee with DataAdapter
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210716 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210716 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      InitializeComponent();
      dtaCustomer.Fill(dsData.tblCPCustomer);
      dtaOrder.Fill(dsData.tblCPOrder);
      dtaEmployee.Fill(dsData.tblCPEmployee);
    }
    // frmDataViews()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCreate_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define the current view of the row (drvCurrent)
    //   - Define a DataView of tblCPOrder (dvNew)
    //   - Filter the DataView (dvNew) with the key of drwCurrent
    //   - Set DataSource (dgrOrder) to DataView (dvNew).
    // Called by
    //   - User action (Clicking a button)
    //   - cmdFind_Click(System.Object, System.EventArgs) Handles cmdFind.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210716 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210716 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - You can also use drvCurrent[0].ToString() in the code.
    //     - Is this a good idea?
    //***
    {
      DataRowView drvCurrent;
      DataView dvNew;

      drvCurrent = (DataRowView)lstClient.SelectedItem;
      dvNew = new DataView();
      dvNew.Table = dsData.tblCPOrder;
      dvNew.RowFilter = "strCustomerId = '" + drvCurrent["strIdCustomer"].ToString() + "'";
      dgrOrder.DataSource = dvNew;
    }
    // cmdCreate_Click(System.Object, System.EventArgs)

    private void cmdFind_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Sort Orders based on the key
    //   - Find a specific order
    //   - Show a message
    //   - Define a DataView of tblCPOrder (dvNew)
    //   - Filter the DataView (dvNew) with the key of drwCurrent
    //   - Set DataSource (dgrOrder) to DataView (dvNew).
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - cmdCreate_Click(System.Object, System.EventArgs) Handles cmdCreate.Click
    // Created
    //   - CopyPaste – 20210716 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210716 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      int lngFound;
      string strMessage;

      dvOrder.RowFilter = "";
      dvOrder.RowStateFilter = DataViewRowState.CurrentRows;
      dvOrder.Sort = "intIdOrder ASC";
      lngFound = dvOrder.Find(10255);
      strMessage = "The Order key is " + dvOrder[lngFound]["intIdOrder"].ToString() + "\n\r";
      strMessage += "The Customer key is " + dvOrder[lngFound]["strCustomerId"].ToString() + "\n\r";
      strMessage += "The Employee key is " + dvOrder[lngFound]["intEmployeeId"].ToString();
      MessageBox.Show(strMessage);
      cmdCreate_Click(theSender, theEventArguments);
    }
    // cmdFind_Click(System.Object, System.EventArgs)

    private void cmdRowState_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    //***
    // Action
    //   - Try to
    //     - Define a new row in DatView (drvNew)
    //     - Set Customer
    //     - Set Employee
    //     - Set key of Order
    //     - Show the added record in the grid Order
    //     - Refresh the grid
    //   - Catch
    //     - Show the exception message when not succesful
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210716 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210716 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      DataRowView drvNew;

      try
      {
        drvNew = dvOrder.AddNew();
        drvNew["strCustomerId"] = "ALFKI";
        drvNew["intEmployeeId"] = 1;
        drvNew["intIdOrder"] = 0;
        dvOrder.RowStateFilter = DataViewRowState.Added;
        dgrOrder.DataSource = dvOrder;
        dgrOrder.Refresh();
      }
      catch (System.Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }

    }
    // cmdRowState_Click(System.Object, System.EventArgs)

    private void cmdSort_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define the current view of the row (drvCurrent)
    //   - Filter orders with the selected client
    //   - Sort DataView dvOrder
    //   - Set DataSource (dvOrder) to the grid of orders
    //   - Refresh the grid of the orders
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210716 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210716 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      DataRowView drvCurrent;

      drvCurrent = (DataRowView)lstClient.SelectedItem;
      dvOrder.RowFilter = "strCustomerId = '" + drvCurrent["strIdCustomer"].ToString() + "'";
      dvOrder.Sort = "intEmployeeId, strCustomerId, intIdOrder DESC";
      dgrOrder.DataSource = dvOrder;
      dvOrder.RowStateFilter = DataViewRowState.CurrentRows;
      dgrOrder.Refresh();
    }
    // cmdSort_Click(System.Object, System.EventArgs)

    private void lstClient_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - Define the current view of the row (drvCurrent)
    //     - Define a DataView of tblCPOrder (dvNew)
    //     - Filter the DataView (dvNew) with the key of drwCurrent
    //     - Set DataSource (dgrOrder) to DataView (dvNew).
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210716 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210716 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      DataRowView drvCurrent;
      DataView dvNew;

      try
      {
        drvCurrent = (DataRowView)lstClient.SelectedItem;
        dvNew = new DataView();
        dvNew.Table = dsData.tblCPOrder;
        dvNew.RowFilter = "strCustomerId = '" + drvCurrent["strIdCustomer"].ToString() + "'";
        dgrOrder.DataSource = dvNew;
      }
      catch (System.Exception theException)
      {
      }
      finally
      {
      }

    }
    // lstClient_SelectedIndexChanged(System.Object, System.EventArgs)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataViews

}
// DataViews