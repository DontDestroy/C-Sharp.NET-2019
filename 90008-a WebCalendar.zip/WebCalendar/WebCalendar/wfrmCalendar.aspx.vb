﻿'***
' Action
'   - Example of a calendar in a web page
'   - There is a calendar, a text box, a submit button and a validator
' Created
'   - CopyPaste – 20260416 – VVDW
' Changed
'   - CopyPaste – yyyymmdd – VVDW – What changed
' Tested
'   - CopyPaste – 20260416 – VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On
Option Strict On

Namespace CopyPaste.Learning

  Public Class wfrmCalendar
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Init
      InitializeComponent()
    End Sub

#End Region

    '#Region "Constructors"
    '#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

#Region "Fields"

    Protected WithEvents calDate As System.Web.UI.WebControls.Calendar
    Protected WithEvents cmdSubmit As System.Web.UI.WebControls.Button
    Protected WithEvents txtDate As System.Web.UI.WebControls.TextBox

#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

#Region "Controls"

    Private Sub calDate_SelectionChanged(ByVal theSender As Object, ByVal theEventArguments As System.EventArgs) Handles calDate.SelectionChanged
      '***
      ' Action
      '   - Selected date on the calendar is converte to a string
      '   - That string is placed into the textbox that represents the choosen date
      ' Called by
      '   - User action (Selecting a date)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20260416 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260416 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      txtDate.Text = calDate.SelectedDate.ToLongDateString
    End Sub
    ' calDate_SelectionChanged(System.Object, System.EventArgs) Handles calDate.SelectionChanged

    Private Sub Page_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Load
      '***
      ' Action
      '   - 
      ' Called by
      '   - User action (Loading the page)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20260416 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260416 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

    End Sub
    ' Page_Load(System.Object, System.EventArgs) Handles MyBase.Load

#End Region

    '#Region "Functionality"

    '#Region "Event"
    '#End Region

    '#Region "Sub / Function"
    '#End Region

    '#End Region

#End Region

    '#Region "Not used"
    '#End Region

  End Class
  ' wfrmCalendar

End Namespace
' CopyPaste.Learning