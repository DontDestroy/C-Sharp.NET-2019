﻿//***
// Action
//   - Explain the basic principles of Memory Management
//   - Measured by throughput, latency and resource utilization
//     - The Garbage Collector is resource utilization
//     - Workstation Garbage Collection for User Interface responsiveness
//     - Server Garbage Collection for throughput, using multiple threads to perform concurrent collections
// Created
//   - CopyPaste – 20260530 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260530 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void DemoStructContainer()
    //***
    // Action
    //   - Define and create a structContainer with a structPoint with coordinates 5 and 6
    //   - Define a variable of type structContainer
    //   - Copy the value of the created structContainer in the variable
    //   - Change the X coordinate (modifies only the copy)
    // Called by
    //   - Main()
    // Calls
    //   - double structContainer.Distance()
    //   - double structContainer.Distance(structPoint)
    //   - int structPoint.X (Get)
    //   - int structPoint.Y (Get)
    //   - structContainer(structPoint)
    //   - structPoint(int, int)
    //   - structPoint.X(int) (Set)
    //   - structPoint.Y(int) (Set)
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      structContainer theContainer = new structContainer(new structPoint(5, 6));
      structContainer theCopy;
      structPoint aNewPoint = new structPoint(10, 20);

      theCopy = theContainer;
      theCopy.thePoint.X = 100;

      Console.WriteLine($"The coordinates of the original are {theContainer.thePoint.X} and {theContainer.thePoint.Y}");
      Console.WriteLine($"The coordinates of the copy are {theCopy.thePoint.X} and {theCopy.thePoint.Y}");
      Console.WriteLine($"The distance of the original point ({theContainer.thePoint.X}, {theContainer.thePoint.Y}) is {theContainer.Distance()}");
      Console.WriteLine($"The distance of the new point ({theCopy.thePoint.X}, {theCopy.thePoint.Y}) is {theContainer.Distance(aNewPoint)}");
    }
    // DemoStructContainer()

    public static void Main()
    //***
    // Action
    //   - Demo the number Garbage Collections (inside a loop array definition)
    //   - Demo the number Garbage Collections (inside a loop string definition)
    //   - Working with the stack or the heap
    //   - Demo of a struct container
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - DemoStructContainer()
    //   - UnderstandingGarbageCollector()
    //   - UnderstandingProcess()
    //   - WorkingWithStackOrHeap()
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      // UnderstandingGarbageCollector();
      // UnderstandingProcess();
      // WorkingWithStackOrHeap();
      // DemoStructContainer();

      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadKey();
    }
    // Main()

    public static void UnderstandingGarbageCollector()
    //***
    // Action
    //   - You can set the latency mode of garbage collection (generation 2)
    //   - Show some Garbage Collection settings
    //   - Define and assign a number of items
    //   - Define 10 percent of it
    //   - Loop a number of times
    //     - Define and assign an array of number of items bytes
    //       (Put on purpose inside the loop)
    //     - If ten percent is passed
    //       - Show the number of Garbage Collectors occurrences
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intNumberOfItems = 25_000;
      int intTenProcent = intNumberOfItems / 10;

      // VVDW - Generation 2 collections are delayed
      // GCSettings.LatencyMode = GCLatencyMode.SustainedLowLatency;
      // GCSettings.LatencyMode = GCLatencyMode.Batch;

      Console.WriteLine($"Latency Mode: {GCSettings.LatencyMode}");
      Console.WriteLine($"Server Garbage Collecition: {GCSettings.IsServerGC}");
      Console.WriteLine();

      for (int intCounter = 0; intCounter < intNumberOfItems; intCounter++)
      {
        byte[] arrbytData = new byte[intNumberOfItems];
        // VVDW - For demo put inside the loop

        if (intCounter % intTenProcent == 0)
        {
          Console.WriteLine("Run " + (intCounter / intTenProcent + 1));
          Console.WriteLine($"Garbage Collector Generation 0 (short lived) : {GC.CollectionCount(0)}");
          Console.WriteLine($"Garbage Collector Generation 1 (medium lived): {GC.CollectionCount(1)}");
          Console.WriteLine($"Garbage Collector Generation 2 (long lived)  : {GC.CollectionCount(2)}");
          Console.WriteLine();
        }
        else
        // intCounter % 1_000 <> 0
        {
        }
        // intCounter % 1_000 == 0

      }
      // intCounter = intNumberOfItems

    }
    // UnderstandingGarbageCollector()

    public static void UnderstandingProcess()
    //***
    // Action
    //   - Define and assign a number of items
    //   - Define 10 percent of it
    //   - Loop a number of times
    //     - Define and assign an array of number of items bytes
    //       (Put on purpose inside the loop)
    //     - If ten percent is passed
    //       - Show the number of Garbage Collectors occurrences
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intNumberOfItems = 1_000_000;
      int intTenProcent = intNumberOfItems / 10;

      // string aText; 

      for (int intCounter = 0; intCounter < intNumberOfItems; intCounter++)
      {
        string aText = $"Iteration {intCounter}";
        // VVDW - For demo put inside the loop

        if (intCounter % intTenProcent == 0)
        {
          Console.WriteLine("Run " + (intCounter / intTenProcent + 1));
          Console.WriteLine($"Garbage Collector Generation 0 (short lived) : {GC.CollectionCount(0)}");
          Console.WriteLine($"Garbage Collector Generation 1 (medium lived): {GC.CollectionCount(1)}");
          Console.WriteLine($"Garbage Collector Generation 2 (long lived)  : {GC.CollectionCount(2)}");
          Console.WriteLine();
        }
        else
        // intCounter % 1_000 <> 0
        {
        }
        // intCounter % 1_000 == 0

      }
      // intCounter = intNumberOfItems

    }
    // UnderstandingProcess()

    public static void WorkingWithStackOrHeap()
    //***
    // Action
    //   - Define and initialize a point on the heap (it is a reference)
    //   - Define and initialize a point on the stack (it is a value)
    //   - Copy both to a corresponding variable
    //   - Change the X coordinate of both originals to 30
    //   - Show the X coordinate of both copied variables
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpPoint pointOnHeap = new cpPoint(10, 20);
      // memory allocated on the heap (reference)
      structPoint pointOnStack = new structPoint(10, 20);
      // memory allocated on the stack (value)

      cpPoint pointHeapCopy = pointOnHeap;
      // a reference is copied

      structPoint pointStackCopy = pointOnStack;
      // a value is copied

      pointOnHeap.X = 30;
      pointOnStack.X = 30;

      Console.WriteLine("Copied point on heap - X coordinate: " + pointHeapCopy.X);
      Console.WriteLine("Copied point on stack - X coordinate: " + pointStackCopy.X);
    }
    // WorkingWithStackOrHeap()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning