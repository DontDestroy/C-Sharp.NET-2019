﻿//***
// Action
//   - Basic routine to create unit tests on
//     - The shown unit test is not useful, because it always fails
//     - The goal here is to show the principle
//       - The method that is tested, prints something on the console
// Created
//   - CopyPaste – 20251223 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251223 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using static System.Console;
using System.Globalization;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Print some dates in a given culture
    //   - Six May of 1970 is used as example
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - PrintDate(DateTime, string)
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      DateTime dtmDate = new DateTime(1970, 5, 6, 13, 20, 30);

      PrintDate(dtmDate, "be-NL");
      PrintDate(dtmDate, "en-US");

      WriteLine();
      WriteLine("Hit any key");
      ReadLine();
    }
    // Main()

    public static void PrintDate(DateTime dtmDate, string strCulture)
    //***
    // Action
    //   - Show the given date in a given culture on the console
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      CultureInfo theCulture = new CultureInfo(strCulture);

      WriteLine($"The date in the culture {strCulture} is {dtmDate.ToString(theCulture)}");
    }
    // PrintDate(DateTime, string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning