﻿//***
// Action
//   - Demo of overloading a method from a class
// Created
//   - CopyPaste – 20260619 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260619 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpCalculateOverload
  {

    #region "Constructors / Destructors"

    public cpCalculateOverload()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpCalculateOverload()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Define and assign a base size
    //   - Define and initialize a cpCompute with width 10
    //   - 
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpCompute.Surface(string)
    // Created
    //   - CopyPaste – 20260619 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260619 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      decimal decBaseWidth = 10;
      cpCompute theSurface = new cpCompute(decBaseWidth);
      decimal decResult;

      Console.Title = "Overload";

      decResult = theSurface.Surface("Circle");
      Console.WriteLine("A circle with width {0} has a surface of {1}", decBaseWidth, decResult);
      decResult = theSurface.Surface("Triangle");
      Console.WriteLine("A triangle with width {0} and base {1} has a surface of {2}", decBaseWidth, decBaseWidth, decResult);
      decResult = theSurface.Surface("Square");
      Console.WriteLine("A square with width {0} has a surface of {1}", decBaseWidth, decResult);
      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadKey();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCalculateOverload

}
// CopyPaste.Learning