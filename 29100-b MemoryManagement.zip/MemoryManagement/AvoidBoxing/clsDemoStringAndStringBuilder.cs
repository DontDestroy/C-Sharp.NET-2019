﻿//***
// Action
//   - Demo with a normal string and StringBuilder
// Created
//   - CopyPaste – 20260614 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260614 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpDemoStringAndStringBuilder
  {

    #region "Constructors / Destructors"

    public cpDemoStringAndStringBuilder()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260614 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpDemoStringAndStringBuilder()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [BenchmarkAttribute]
    public string DemoString()
    //***
    // Action
    //   - Create a string with the first 1000 numbers (0 till 999)
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intLength = 1000;
      string strResult = "";

      for (int aCounter = 0; aCounter < intLength; aCounter++)
      {
        strResult += aCounter.ToString();
      }
      // aCounter = 1000

      return strResult;
    }
    // string DemoString()

    [BenchmarkAttribute]
    public string DemoStringBuilder()
    //***
    // Action
    //   - Create a string using StringBuilder with the first 1000 numbers (0 till 999)
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strResult;
      StringBuilder strBuildText = new StringBuilder();

      int intLength = 1000;

      for (int aCounter = 0; aCounter < intLength; aCounter++)
      {
        strBuildText.Append(aCounter);
      }
      // aCounter = 1000

      strResult = strBuildText.ToString();
      return strResult;
    }
    // string DemoStringBuilder()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDemoStringAndStringBuilder

}
// CopyPaste.Learning