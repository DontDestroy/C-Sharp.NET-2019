﻿
namespace CopyPaste.Learning.Data
{
  partial class frmDataGridWizard
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataGridWizard));
      this.dgrInstructors = new System.Windows.Forms.DataGrid();
      this.cmdUpdate = new System.Windows.Forms.Button();
      this.cmdLoad = new System.Windows.Forms.Button();
      this.dsData = new DataGridWizard.dsData();
      this.bdscrInspector = new System.Windows.Forms.BindingSource(this.components);
      this.tbaInstructor = new DataGridWizard.dsDataTableAdapters.tbaInstructor();
      ((System.ComponentModel.ISupportInitialize)(this.dgrInstructors)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdscrInspector)).BeginInit();
      this.SuspendLayout();
      // 
      // dgrInstructors
      // 
      this.dgrInstructors.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrInstructors.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.dgrInstructors.DataMember = "";
      this.dgrInstructors.DataSource = this.bdscrInspector;
      this.dgrInstructors.GridLineColor = System.Drawing.Color.Blue;
      this.dgrInstructors.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrInstructors.Location = new System.Drawing.Point(8, 15);
      this.dgrInstructors.Name = "dgrInstructors";
      this.dgrInstructors.PreferredColumnWidth = 110;
      this.dgrInstructors.Size = new System.Drawing.Size(376, 128);
      this.dgrInstructors.TabIndex = 6;
      // 
      // cmdUpdate
      // 
      this.cmdUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdUpdate.Location = new System.Drawing.Point(104, 159);
      this.cmdUpdate.Name = "cmdUpdate";
      this.cmdUpdate.Size = new System.Drawing.Size(75, 23);
      this.cmdUpdate.TabIndex = 8;
      this.cmdUpdate.Text = "&Update";
      this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
      // 
      // cmdLoad
      // 
      this.cmdLoad.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdLoad.Location = new System.Drawing.Point(16, 159);
      this.cmdLoad.Name = "cmdLoad";
      this.cmdLoad.Size = new System.Drawing.Size(75, 23);
      this.cmdLoad.TabIndex = 7;
      this.cmdLoad.Text = "&Load";
      this.cmdLoad.Click += new System.EventHandler(this.cmdLoad_Click);
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // bdscrInspector
      // 
      this.bdscrInspector.DataMember = "tblCPInstructor";
      this.bdscrInspector.DataSource = this.dsData;
      // 
      // tbaInstructor
      // 
      this.tbaInstructor.ClearBeforeFill = true;
      // 
      // frmDataGridWizard
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(392, 197);
      this.Controls.Add(this.dgrInstructors);
      this.Controls.Add(this.cmdUpdate);
      this.Controls.Add(this.cmdLoad);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataGridWizard";
      this.Text = "Data Grid Wizard";
      ((System.ComponentModel.ISupportInitialize)(this.dgrInstructors)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdscrInspector)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    internal System.Windows.Forms.DataGrid dgrInstructors;
    internal System.Windows.Forms.Button cmdUpdate;
    internal System.Windows.Forms.Button cmdLoad;
    private DataGridWizard.dsData dsData;
    private System.Windows.Forms.BindingSource bdscrInspector;
    private DataGridWizard.dsDataTableAdapters.tbaInstructor tbaInstructor;
  }
}

