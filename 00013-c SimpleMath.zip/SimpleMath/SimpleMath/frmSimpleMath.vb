'***
' Action
'   - Examples of simple math calculations
' Created
'   - CopyPaste � 20210827 � VVDW
' Changed
'   - Organisation � yyyymmdd � Initials of programmer � What changed
' Tested
'   - CopyPaste � 20210827 � VVDW
' Proposal (To Do)
'   - List of actions that can be added to the functionality
'***

Option Explicit On 
Option Strict On

Imports Microsoft.VisualBasic
Imports System.Windows.Forms

Public Class frmSimpleMath
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  Friend WithEvents Label2 As System.Windows.Forms.Label
  Friend WithEvents txtNumber01 As System.Windows.Forms.TextBox
  Friend WithEvents txtNumber02 As System.Windows.Forms.TextBox
  Friend WithEvents optMultiply As System.Windows.Forms.RadioButton
  Friend WithEvents optAdd As System.Windows.Forms.RadioButton
  Friend WithEvents optSubtract As System.Windows.Forms.RadioButton
  Friend WithEvents optDivide As System.Windows.Forms.RadioButton
  Friend WithEvents optDivideInteger As System.Windows.Forms.RadioButton
  Friend WithEvents lblResult As System.Windows.Forms.Label
  Friend WithEvents cmdCalculate As System.Windows.Forms.Button
  Friend WithEvents cmdQuit As System.Windows.Forms.Button
  Friend WithEvents lblOperator As System.Windows.Forms.Label
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmSimpleMath))
    Me.txtNumber01 = New System.Windows.Forms.TextBox
    Me.txtNumber02 = New System.Windows.Forms.TextBox
    Me.optMultiply = New System.Windows.Forms.RadioButton
    Me.optAdd = New System.Windows.Forms.RadioButton
    Me.optSubtract = New System.Windows.Forms.RadioButton
    Me.optDivide = New System.Windows.Forms.RadioButton
    Me.optDivideInteger = New System.Windows.Forms.RadioButton
    Me.lblOperator = New System.Windows.Forms.Label
    Me.Label2 = New System.Windows.Forms.Label
    Me.lblResult = New System.Windows.Forms.Label
    Me.cmdCalculate = New System.Windows.Forms.Button
    Me.cmdQuit = New System.Windows.Forms.Button
    Me.SuspendLayout()
    '
    'txtNumber01
    '
    Me.txtNumber01.Location = New System.Drawing.Point(10, 25)
    Me.txtNumber01.Name = "txtNumber01"
    Me.txtNumber01.Size = New System.Drawing.Size(75, 20)
    Me.txtNumber01.TabIndex = 0
    Me.txtNumber01.Text = ""
    '
    'txtNumber02
    '
    Me.txtNumber02.Location = New System.Drawing.Point(110, 25)
    Me.txtNumber02.Name = "txtNumber02"
    Me.txtNumber02.Size = New System.Drawing.Size(75, 20)
    Me.txtNumber02.TabIndex = 1
    Me.txtNumber02.Text = ""
    '
    'optMultiply
    '
    Me.optMultiply.Location = New System.Drawing.Point(30, 135)
    Me.optMultiply.Name = "optMultiply"
    Me.optMultiply.Size = New System.Drawing.Size(104, 20)
    Me.optMultiply.TabIndex = 2
    Me.optMultiply.Text = "Multiply (*)"
    '
    'optAdd
    '
    Me.optAdd.Checked = True
    Me.optAdd.Location = New System.Drawing.Point(30, 95)
    Me.optAdd.Name = "optAdd"
    Me.optAdd.Size = New System.Drawing.Size(104, 20)
    Me.optAdd.TabIndex = 3
    Me.optAdd.TabStop = True
    Me.optAdd.Text = "Add (+)"
    '
    'optSubtract
    '
    Me.optSubtract.Location = New System.Drawing.Point(30, 115)
    Me.optSubtract.Name = "optSubtract"
    Me.optSubtract.Size = New System.Drawing.Size(104, 20)
    Me.optSubtract.TabIndex = 4
    Me.optSubtract.Text = "Subtract (-)"
    '
    'optDivide
    '
    Me.optDivide.Location = New System.Drawing.Point(30, 155)
    Me.optDivide.Name = "optDivide"
    Me.optDivide.Size = New System.Drawing.Size(104, 20)
    Me.optDivide.TabIndex = 5
    Me.optDivide.Text = "Divide (float /)"
    '
    'optDivideInteger
    '
    Me.optDivideInteger.Location = New System.Drawing.Point(30, 175)
    Me.optDivideInteger.Name = "optDivideInteger"
    Me.optDivideInteger.Size = New System.Drawing.Size(104, 20)
    Me.optDivideInteger.TabIndex = 6
    Me.optDivideInteger.Text = "Divide (int \)"
    '
    'lblOperator
    '
    Me.lblOperator.Location = New System.Drawing.Point(90, 25)
    Me.lblOperator.Name = "lblOperator"
    Me.lblOperator.Size = New System.Drawing.Size(15, 20)
    Me.lblOperator.TabIndex = 7
    Me.lblOperator.Text = "+"
    '
    'Label2
    '
    Me.Label2.Location = New System.Drawing.Point(195, 25)
    Me.Label2.Name = "Label2"
    Me.Label2.Size = New System.Drawing.Size(15, 20)
    Me.Label2.TabIndex = 8
    Me.Label2.Text = "="
    '
    'lblResult
    '
    Me.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.lblResult.Location = New System.Drawing.Point(220, 25)
    Me.lblResult.Name = "lblResult"
    Me.lblResult.Size = New System.Drawing.Size(75, 20)
    Me.lblResult.TabIndex = 9
    '
    'cmdCalculate
    '
    Me.cmdCalculate.Location = New System.Drawing.Point(195, 125)
    Me.cmdCalculate.Name = "cmdCalculate"
    Me.cmdCalculate.TabIndex = 10
    Me.cmdCalculate.Text = "Calculate"
    '
    'cmdQuit
    '
    Me.cmdQuit.Location = New System.Drawing.Point(195, 165)
    Me.cmdQuit.Name = "cmdQuit"
    Me.cmdQuit.TabIndex = 11
    Me.cmdQuit.Text = "Quit"
    '
    'frmSimpleMath
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(302, 233)
    Me.Controls.Add(Me.cmdQuit)
    Me.Controls.Add(Me.cmdCalculate)
    Me.Controls.Add(Me.lblResult)
    Me.Controls.Add(Me.Label2)
    Me.Controls.Add(Me.lblOperator)
    Me.Controls.Add(Me.optDivideInteger)
    Me.Controls.Add(Me.optDivide)
    Me.Controls.Add(Me.optSubtract)
    Me.Controls.Add(Me.optAdd)
    Me.Controls.Add(Me.optMultiply)
    Me.Controls.Add(Me.txtNumber02)
    Me.Controls.Add(Me.txtNumber01)
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Name = "frmSimpleMath"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Simple Math"
    Me.ResumeLayout(False)

  End Sub

#End Region

#Region "Constructors / Destructors"

  Protected Overloads Overrides Sub Dispose(ByVal blnDisposing As Boolean)
    '***
    ' Action
    '   - Clean up instance of 'frmSimpleMath'
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210827 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210827 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    If blnDisposing Then

      If components Is Nothing Then
      Else
        ' Not components Is Nothing
        components.Dispose()
      End If
      ' components Is Nothing

    Else
      ' Not blnDisposing
    End If
    ' blnDisposing

    MyBase.Dispose(blnDisposing)
  End Sub
  ' Dispose(Boolean)

  Public Sub New()
    '***
    ' Action
    '   - Create new instance of 'frmSimpleMath'
    ' Called by
    '   - 
    ' Calls
    '   - InitializeComponent()
    ' Created
    '   - CopyPaste � 20210827 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210827 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    MyBase.New()
    InitializeComponent()
  End Sub
  ' New()

#End Region

  '#Region "Designer"
  '#End Region

  '#Region "Structures"
  '#End Region

  '#Region "Fields"
  '#End Region

  '#Region "Properties"
  '#End Region

#Region "Methods"

  '#Region "Overrides"
  '#End Region

#Region "Controls"

  Private Sub cmdCalculate_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdCalculate.Click
    '***
    ' Action
    '   - Do a calculation
    '   - If 'txtNumber01' is not a number, show error message
    '   - If 'txtNumber02' is not a number, show error message
    ' Called by
    '   - 
    ' Calls
    '   - Microsoft.VisualBasic.IsNumeric(String)
    '   - System.Windows.Forms.MessageBox.Show(String)
    '   - System.Convert.ToInt32(String)
    ' Created
    '   - CopyPaste � 20210827 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210827 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    If IsNumeric(txtNumber01.Text) Then
    Else
      ' Not IsNumeric(txtNumber01.Text)
      MessageBox.Show("Please type a number in the first field.")
      txtNumber01.Focus()
      Exit Sub
    End If
    ' IsNumeric(txtNumber01.Text)

    If IsNumeric(txtNumber02.Text) Then
    Else
      ' Not IsNumeric(txtNumber02.Text)
      MessageBox.Show("Please type a number in the second field.")
      txtNumber02.Focus()
      Exit Sub
    End If
    ' IsNumeric(txtNumber02.Text)

    Select Case lblOperator.Text
      Case "+"
        lblResult.Text = (Convert.ToInt32(txtNumber01.Text) + Convert.ToInt32(txtNumber02.Text)).ToString
      Case "-"
        lblResult.Text = (Convert.ToInt32(txtNumber01.Text) - Convert.ToInt32(txtNumber02.Text)).ToString
      Case "*"
        lblResult.Text = (Convert.ToInt32(txtNumber01.Text) * Convert.ToInt32(txtNumber02.Text)).ToString
      Case "/"
        lblResult.Text = (Convert.ToInt32(txtNumber01.Text) / Convert.ToInt32(txtNumber02.Text)).ToString
      Case "\"
        lblResult.Text = (Convert.ToInt32(txtNumber01.Text) \ Convert.ToInt32(txtNumber02.Text)).ToString
    End Select
    ' lblOperator.Text

  End Sub
  ' cmdCalculate_Click(System.Object, System.EventArgs)

  Private Sub cmdQuit_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdQuit.Click
    '***
    ' Action
    '   - End program
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210827 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210827 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    End
  End Sub
  ' cmdQuit_Click(System.Object, System.EventArgs)

  Private Sub optAdd_CheckedChanged(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles optAdd.CheckedChanged
    '***
    ' Action
    '   - Change 'lblOperator' to "+"
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210827 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210827 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    lblOperator.Text = "+"
  End Sub
  ' optAdd_CheckedChanged(System.Object, System.EventArgs)

  Private Sub optDivide_CheckedChanged(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles optDivide.CheckedChanged
    '***
    ' Action
    '   - Change 'lblOperator' to "/"
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210827 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210827 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    lblOperator.Text = "/"
  End Sub
  ' optDivide_CheckedChanged(System.Object, System.EventArgs)

  Private Sub optDivideInteger_CheckedChanged(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles optDivideInteger.CheckedChanged
    '***
    ' Action
    '   - Change 'lblOperator' to "\"
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210827 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210827 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    lblOperator.Text = "\"
  End Sub
  ' optDivideInteger_CheckedChanged(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs)

  Private Sub optMultiply_CheckedChanged(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles optMultiply.CheckedChanged
    '***
    ' Action
    '   - Change 'lblOperator' to "*"
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210827 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210827 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    lblOperator.Text = "*"
  End Sub
  ' optMultiply_CheckedChanged(System.Object, System.EventArgs)

  Private Sub optSubtract_CheckedChanged(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles optSubtract.CheckedChanged
    '***
    ' Action
    '   - Change 'lblOperator' to "-"
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210827 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210827 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    lblOperator.Text = "-"
  End Sub
  ' optSubtract_CheckedChanged(System.Object, System.EventArgs)

#End Region

  '#Region "Functionality"

  '#Region "Event"
  '#End Region

  '#Region "Sub / Function"
  '#End Region

  '#End Region

#End Region

  '#Region "Not used"
  '#End Region

End Class
' frmSimpleMath