//***
// Action
//   - Test use of static variable
// Created
//   - CopyPaste � 20220128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220128 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace Static
{

  class cpStatic
	{
    static long lngStaticNumber = 0;

    static void Main()
    //***
    // Action
    //   - Call 5 times the same subroutine
    // Called by
    //   - User action (Starting the application) 
    // Calls
    //   - SubRoutine()
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      SubRoutine();
      SubRoutine();
      SubRoutine();
      SubRoutine();
      SubRoutine();
    }
    // Main()

    static void SubRoutine()
    //***
    // Action
    //   - Define 2 integers (one static)
    //   - Add 1 to 'lngNumber'
    //   - Add 1 to 'lngStaticNumber'
    //   - Show messagebox with results
    // Called by
    //   - Main()
    // Calls
    //   - DialogResult System.Windows.Forms.MessageBox.Show(string)
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngNumber = 0;

      lngNumber += 1;
      lngStaticNumber += 1;
      MessageBox.Show(lngNumber + " - " + lngStaticNumber);
    }
    // SubRoutine()

	}
  // cpStatic

}
// Static