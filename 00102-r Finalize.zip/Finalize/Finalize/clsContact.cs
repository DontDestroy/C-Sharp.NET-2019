//***
// Action
//   - Implementation of cpContact
// Created
//   - CopyPaste � 20230704 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230704 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpContact
  {

    #region "Constructors / Destructors"
    
    public cpContact(string strContactName, string strContactPhone, string strContactEmail)
    //***
    // Action
    //   - Constructor of cpContact
    //   - Define the name, phone and emailaddress
    //   - Show a messagebox with the information
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230704 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230704 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      mstrName = strContactName;
      mstrPhone = strContactPhone;
      mstrEMail = strContactEmail;
      MessageBox.Show("Name: " + strContactName + " - Phone: " + strContactPhone + " - Email: " + strContactEmail);
    }
    // cpContact(string, string, string)

    ~cpContact()
    //***
    // Action
    //   - Finalize the cpContact
    //   - Show a messagebox with the information
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230704 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230704 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***

    {

      try
      {      
        MessageBox.Show("In Finalize for " + mstrName);
      }
      catch (Exception theException)
      {
      }

    }
    // ~cpContact()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public string mstrEMail;
    public string mstrName;
    public string mstrPhone;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpContact

}
// CopyPaste.Learning