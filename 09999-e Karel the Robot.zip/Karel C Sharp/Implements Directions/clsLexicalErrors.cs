﻿//***
// Action
//   - Create a class cpLexicalErrors that uses the interface Directions
// Created
//   - CopyPaste – 20251011 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251011 – VVDW
// Proposal (To Do)
//   - This is put into comments because it contains errors (on purpose)
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpLexicalErrors : Directions
	{

		#region "Constructors / Destructors"

		public cpLexicalErrors()
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Reset the world
		//   - Build the world according to the One Wall Segment specifications
		//   - Make the world visible
		//   - Karel becomes a green robot starting at position (1, 1), looking to the right with no beepers in the bag
		//   - Karel will move one forward
		//   - Karel will move one forward
		//   - Karel will move two forward
		//   - Karel will pick the beeper at that position
		//   - Karel will turn right
		//   - Karel will turn left
		//   - Karel will turn left
		//   - Karel is switched off
		// Called by
		//   - cpProgram.LexicalErrors()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251011 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251011 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - This code is full of lexical errors and will never work
		//***
		{
			// World.reset();
			// World.readWorld("Worlds\\01.01 The Robot World.kwld");
			// World.setVisible(true);
			// UrRobot karel(1, 1, East, 0); // Missing new instruction
			// karel.move();
			// karel.mvoe(); // Misspelled instruction
			// karel.move();
			// karel.pick(); // Unknown instruction
			// karel.turnright(); // Unknown instruction
			// karel.turnleft(); // Unknown instruction
			// karel.turn_left(); // Unknown instruction
			// Karel.turnOff(); // Unknown robot name
		}
		// cpLexicalErrors()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// cpLexicalErrors

}
// cpKarelTheRobot