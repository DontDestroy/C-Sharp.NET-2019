//***
// Action
//   - Implementation of a cpEmployee using an interface for the cost
// Created
//   - CopyPaste � 20240410 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240410 � VVDW
// Proposal (To Do)
//   - 
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public abstract class cpEmployee : cpiCost
  {

    #region "Constructors / Destructors"

    public cpEmployee(string strName)
      //***
      // Action
      //   - Constructor with Name
      // Called by
      //   - cpHandWorker(string)
      //   - cpOfficeWorker(string)
      //   - cpProgram.Main()
      // Calls
      //   - Name(string) (Set)
      // Created
      //   - CopyPaste � 20240410 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240410 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Name = strName;
    }
    // cpEmployee(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrName;

    #endregion

    #region "Properties"

    public abstract decimal Amount{ get;}

    public bool Human
    {

      get
        //***
        // Action Get
        //   - Returns True
        //   - The cost of an employee is human
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240410 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240410 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return true;
      }
      // bool Human (Get)

    }
    // bool Human

    public string Name
    {

      get
        //***
        // Action Get
        //   - Returns mstrName
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240410 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240410 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

      set
        //***
        // Action Set
        //   - mstrName becomes value
        // Called by
        //   - cpEmployee(string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240410 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240410 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpEmployee

}
// CopyPaste.Learning.Employee