//***
// Action
//   - Working with a basic array
// Created
//   - CopyPaste � 20220210 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220210 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace BasicArray
{

  public class frmBasicArray : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdFind;
    internal System.Windows.Forms.Button cmdToDo;
    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBasicArray));
      this.cmdFind = new System.Windows.Forms.Button();
      this.cmdToDo = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdFind
      // 
      this.cmdFind.Location = new System.Drawing.Point(16, 64);
      this.cmdFind.Name = "cmdFind";
      this.cmdFind.Size = new System.Drawing.Size(264, 32);
      this.cmdFind.TabIndex = 3;
      this.cmdFind.Text = "&Find something in Array";
      this.cmdFind.Click += new System.EventHandler(this.cmdFind_Click);
      // 
      // cmdToDo
      // 
      this.cmdToDo.Location = new System.Drawing.Point(16, 16);
      this.cmdToDo.Name = "cmdToDo";
      this.cmdToDo.Size = new System.Drawing.Size(264, 32);
      this.cmdToDo.TabIndex = 2;
      this.cmdToDo.Text = "&Things to do today";
      this.cmdToDo.Click += new System.EventHandler(this.cmdToDo_Click);
      // 
      // frmBasicArray
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdFind);
      this.Controls.Add(this.cmdToDo);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBasicArray";
      this.Text = "Basic Array";
      this.Load += new System.EventHandler(this.frmBasicArray_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmBasicArray'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBasicArray()
    //***
    // Action
    //   - Create instance of 'frmBasicArray'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
      string[] marrstrLaborsOfHercules = new string[13];
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFind_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Find a specific element in the array
    //   - Show info in MessageBox
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - int Array.BinarySearch(Array, System.Object)
    //   - int Array.IndexOf(Array, System.Object)
    //   - Array.Sort(Array)
    //   - DialogResult MessageBox.Show(string, string)
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      int intIndex;
      
      intIndex = Array.IndexOf(marrstrLaborsOfHercules, "Learn C# .NET");
      MessageBox.Show("In element: " + intIndex.ToString(), "Copy Paste Tryout");
      
      // Array.Sort(marrstrLaborsOfHercules);
      // intIndex = Array.BinarySearch(marrstrLaborsOfHercules, "Learn C# .NET");
      // MessageBox.Show("In element: " + intIndex.ToString(), "Copy Paste Tryout");
    }
    // cmdFind_Click(System.Object, System.EventArgs) Handles cmdFind.Click

    private void cmdToDo_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Loop thru elements of array
    //     - Prepare message with value of element
    //   - Show info in MessageBox
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - Array.Reverse(Array)
    //   - Array.Sort(Array)
    //   - int Array.GetLowerBound(int)
    //   - int Array.GetUpperBound(int)
    //   - System.Object Array.GetValue(int)
    //   - DialogResult MessageBox.Show(string, string)
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      int intIndex;
      string strArrayContent = "";
      
      // Array.Sort(marrstrLaborsOfHercules)
      // Array.Reverse(marrstrLaborsOfHercules)
      
      for (intIndex = marrstrLaborsOfHercules.GetLowerBound(0); intIndex <= marrstrLaborsOfHercules.GetUpperBound(0); intIndex++)
      {
        strArrayContent += intIndex.ToString() + ". " + marrstrLaborsOfHercules.GetValue(intIndex).ToString() + "\n";
      }
      // lngIndex = marrstrLaborsOfHercules.GetUpperBound(0) + 1

      MessageBox.Show(strArrayContent, "Copy Paste Tryout");
    }
    // cmdToDo_Click(System.Object, System.EventArgs) Handles cmdToDo.Click

    private void frmBasicArray_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Fill an array with 13 elemement
    //   - Show some info in MessageBox
    // Called by
    //   - User action (Loading a form)
    // Calls
    //   - Array.SetValue(System.Object, int)
    //   - DialogResult MessageBox.Show(string, string)
    //   - int Array.GetLowerBound(int)
    //   - int Array.GetUpperBound(int)
    //   - int Array.Rank()
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strArrayInfo;
      
      // marrstrLaborsOfHercules[0] = "Kill Nemean Lion";

      marrstrLaborsOfHercules.SetValue("Kill Nemean Lion", 0);
      marrstrLaborsOfHercules.SetValue("Slay nine-headed hydra of Lerna", 1);
      marrstrLaborsOfHercules.SetValue("Capture elusive Stag of Arcadia", 2);
      marrstrLaborsOfHercules.SetValue("Capture wild boar on Mt. Erymantus", 3);
      marrstrLaborsOfHercules.SetValue("Clean Stables of King Augeas of Elis", 4);
      marrstrLaborsOfHercules.SetValue("Shoot monstrous man-eating burds of the Stymphalian Marshes", 5);
      marrstrLaborsOfHercules.SetValue("Capture mad bul of Crete", 6);
      marrstrLaborsOfHercules.SetValue("Kill man-eating mares of King Diomedes", 7);
      marrstrLaborsOfHercules.SetValue("Steal Girdle of Hippolyta", 8);
      marrstrLaborsOfHercules.SetValue("Seize cattle of Geryon of Erytheia", 9);
      marrstrLaborsOfHercules.SetValue("Fetch golden apples of Hesperides", 10);
      marrstrLaborsOfHercules.SetValue("Retrieve three-headed dog Cerberus from Hell", 11);
      marrstrLaborsOfHercules.SetValue("Learn C# .NET", 12);
      // .SetValue("Learn C# .NET in a single day", 13)

      strArrayInfo = "The lower bound is: " + marrstrLaborsOfHercules.GetLowerBound(0).ToString() + "\n";
      strArrayInfo += "The upper bound is: " + marrstrLaborsOfHercules.GetUpperBound(0).ToString() + "\n";
      strArrayInfo += "Number of elements: " + marrstrLaborsOfHercules.GetLength(0).ToString() + "\n";
      strArrayInfo += "Dimension of array: " + marrstrLaborsOfHercules.Rank.ToString();

      MessageBox.Show(strArrayInfo, "Copy Paste Tryout: Array Information");
    }
    // frmBasicArray_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmBasicArray
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmBasicArray());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmBasicArray

}
// BasicArray