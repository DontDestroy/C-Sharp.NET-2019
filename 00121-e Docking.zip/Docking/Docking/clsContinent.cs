//***
// Action
//   - Implementation of cpContinent
// Created
//   - CopyPaste � 20240701 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240701 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpContinent
  {

    #region "Constructors / Destructors"

    public cpContinent(string strName, cpCountry[] arrcpCountry)
      //***
      // Action
      //   - Constructor with Name and an array of cpCountry
      // Called by
      //   - frmDocking()
      // Calls
      //   - Countries(cpCountry[]) (Set)
      //   - Name(string) (Set)
      // Created
      //   - CopyPaste � 20240701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240701 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Name = strName;
      Countries = arrcpCountry;
    }
    // cpContinent(string, cpCountry[])

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpCountry[] marrcpCountry;
    private string mstrName;

    #endregion

    #region "Properties"

    public cpCountry[] Countries
    {

      get
        //***
        // Action Get
        //   - Returns marrcpCountry
        // Called by
        //   - frmDocking.lstContinents_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstContinents.SelectedIndexChanged
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240701 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240701 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return marrcpCountry;
      }
      // cpCountry[] Countries (Get)

      set
        //***
        // Action Set
        //   - marrcpCountry becomes value
        // Called by
        //   - cpContinent(string, cpCountry[])
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240701 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240701 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        marrcpCountry = value;
      }
      // Countries(cpCountry[]) (Set)

    }
    // cpCountry[] Countries

    public string Name
    {

      get
        //***
        // Action Get
        //   - Returns mstrName
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240701 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240701 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

      set
        //***
        // Action Set
        //   - mstrName becomes value
        // Called by
        //   - cpContinent(string, cpCountry[])
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240701 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240701 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrName = value;
      }
      // string Name (Get)

    }
    // string Name

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpContinent

}
// CopyPaste.Learning