//***
// Action
//   - Loop thru elements of array
// Created
//   - CopyPaste � 20220210 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220210 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace ForEach
{

  class cpForEach
	{

    static void Main()
    //***
    // Action
    //   - Lowest equals 100
    //   - Loop thru all the elements of an array
    //     - If value is lower than the lowest
    //       - Lowest becomes value
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - Console.WriteLine(string)
    //   - string Console.ReadLine()
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int[,] arrGrade = new Int32[,]
        {{77, 68, 86, 73}, {98, 87, 89, 81}, {70, 90, 86, 81}};
      int intLowGrade = 100;

      foreach (int intGrade in arrGrade)
      {

        if (intGrade < intLowGrade)
        {
          intLowGrade = intGrade;
        }
        else
          //  intGrade >= intLowGrade 
        {
        }
        // intGrade < intLowGrade 
      }
      // in arrGrade
      
      Console.WriteLine("The minimum grade is: {0}", intLowGrade);
      Console.ReadLine();
    }
    // Main()

  }
  // cpForEach

}
// ForEach