//***
// Action
//   - Starting point of the application.
//   - Fill an array with pets (cpPet)
//   - Show a form and treat the actions of cpPet or derived classes
//   - Working with properties (Get and Set) and methods in several classes, that can be reused
// Created
//   - CopyPaste � 20220316 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20220316 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace CopyPaste.Pet
{

  public class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static cpPet[] arrcpPets = new cpPet[9];
    private static frmPetStore thefrmPetStore;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Fill the array with all the pets
      //   - Show a form frmPetStore
      // Called by
      //   - Startup of the application
      // Calls
      //   - DialogResult frmPetStore.ShowDialog()
      //   - FillArray()
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      thefrmPetStore = new frmPetStore();
      FillArray();
      thefrmPetStore.ShowDialog();
    }
    // Main()

    static void FillArray()
      //***
      // Action
      //   - Fill the array with all the pets
      //   - arrcpPets[0] is a dog with name "Ranger"
      //   - The breed, colloration, cost and gender is filled in
      //   - arrcpPets[1] is a MiniDoxen with name Cindy and color Black
      //   - The gender is filled in
      //   - arrcpPets[2] is a GreatDane with name Sir Ralph and color Brown/White
      //   - The gender is filled in
      //   - arrcpPets[3] is a cat with name "Misty"
      //   - The breed, colloration, cost and gender is filled in
      //   - arrcpPets[4] is a Siamese with name Buster and color Orange/White
      //   - The gender is filled in
      //   - arrcpPets[5] is a Manx with name Horatio and color Brown
      //   - The gender is filled in
      //   - arrcpPets[6] is a bird with name "Bluebill"
      //   - The breed, colloration, cost and gender is filled in
      //   - arrcpPets[7] is a Cockatiel with name Sparky and color Gray/Yellow
      //   - The gender is filled in
      //   - arrcpPets[8] is a Parakeet with name Sprinkles and color White
      //   - The gender is filled in
      // Called by
      //   - Main()
      // Calls
      //   - CopyPaste.Pet.Bird.cpCockatiel(string, string)
      //   - CopyPaste.Pet.Bird.cpParakeet(string, string)
      //   - CopyPaste.Pet.Cat.cpManx(string, string)
      //   - CopyPaste.Pet.Cat.cpSiamese(string, string)
      //   - CopyPaste.Pet.cpAnimal.Breed(string) (Set)
      //   - CopyPaste.Pet.cpAnimal.Coloration(string) (Set)
      //   - CopyPaste.Pet.cpAnimal.Cost(decimal) (Set)
      //   - CopyPaste.Pet.cpAnimal.Gender(string) (Set)
      //   - CopyPaste.Pet.cpBird(string)
      //   - CopyPaste.Pet.cpCat(string)
      //   - CopyPaste.Pet.cpDog(string)
      //   - CopyPaste.Pet.Dog.cpGreatDane(string, string)
      //   - CopyPaste.Pet.Dog.cpMiniDoxen(string, string)
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      arrcpPets[0] = new CopyPaste.Pet.cpDog("Ranger");
      arrcpPets[0].Breed = "German Shepherd";
      arrcpPets[0].Coloration = "Brown/Black";
      arrcpPets[0].Cost = 200;
      arrcpPets[0].Gender = "Male";

      arrcpPets[1] = new CopyPaste.Pet.Dog.cpMiniDoxen("Cindy", "Black");
      arrcpPets[1].Gender = "Female";

      arrcpPets[2] = new CopyPaste.Pet.Dog.cpGreatDane("Sir Ralph", "Brown/White");
      arrcpPets[2].Gender = "Male";
      
      arrcpPets[3] = new CopyPaste.Pet.cpCat("Misty");
      arrcpPets[3].Breed = "Calico";
      arrcpPets[3].Coloration = "Orange/Black";
      arrcpPets[3].Cost = 50;
      arrcpPets[3].Gender = "Female";

      arrcpPets[4] = new CopyPaste.Pet.Cat.cpSiamese("Buster", "Orange/White");
      arrcpPets[4].Gender = "Male";
      
      arrcpPets[5] = new CopyPaste.Pet.Cat.cpManx("Horatio", "Brown");
      arrcpPets[5].Gender = "Male";
      
      arrcpPets[6] = new CopyPaste.Pet.cpBird("Bluebill");
      arrcpPets[6].Breed = "Blue Macaw Parrot";
      arrcpPets[6].Coloration = "Blue/Green/Yellow";
      arrcpPets[6].Cost = 1200;
      arrcpPets[6].Gender = "Male";
      
      arrcpPets[7] = new CopyPaste.Pet.Bird.cpCockatiel("Sparky", "Gray/Yellow");
      arrcpPets[7].Gender = "Female";
      
      arrcpPets[8] = new CopyPaste.Pet.Bird.cpParakeet("Sprinkles", "White");
      arrcpPets[8].Gender = "Male";
    }
    // FillArray()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// CopyPaste.Pet