//***
// Action
//   - Try out some exceptions
// Created
//   - CopyPaste � 20220824 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220824 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;

namespace CopyPaste.Learning
{

  public class UsingExceptions
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    static void DoesNotThrowException()
      //***
      // Action
      //   - Try to show a message
      //   - Catch an error (never happens, because there is no error)
      //   - Run the finally block
      //   - Shows a message that you are outside the try block
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220824 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220824 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {

      try
      {
        Console.WriteLine("In DoesNotThrowException");
      }
      catch
      {
        Console.WriteLine("This Catch never executes");
      }
      finally
      {
        Console.WriteLine("Finally executed in DoesNotThrowException");
      }

      Console.WriteLine("End of DoesNotThrowException");
    }
    // DoesNotThrowException()

    static void Main()
      //***
      // Action
      //   - Show a message "Calling DoesNotThrowException"
      //   - Execute a method without an error
      //   - Show a message "Calling ThrowExceptionWithCatch"
      //   - Execute a method with an error and catch
      //   - Show a message "Calling ThrowExceptionWithoutCatch"
      //   - Try to excecute a method (a try block outside the method)
      //   - Show a message "Calling ThrowExceptionCatchRethrow"
      //   - Try to excecute a method (a try block inside the method rethrows the error)
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - DoesNotThrowException()
      //   - ThrowExceptionCatchRethrow()
      //   - ThrowExceptionWithCatch()
      //   - ThrowExceptionWithoutCatch()
      // Created
      //   - CopyPaste � 20220824 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220824 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      Console.WriteLine("Calling DoesNotThrowException");
      DoesNotThrowException();
      Console.WriteLine(ControlChars.CrLf + "Calling ThrowExceptionWithCatch");
      ThrowExceptionWithCatch();
      Console.WriteLine(ControlChars.CrLf + "Calling ThrowExceptionWithoutCatch");
      
      try
      {
        ThrowExceptionWithoutCatch();
      }
      catch
      {
        Console.WriteLine("Caught exception from ThrowExceptionWithoutCatch in Main");
      }

      Console.WriteLine(ControlChars.CrLf + "Calling ThrowExceptionCatchRethrow");
      
      try
      {
        ThrowExceptionCatchRethrow();
      }
      catch
      {
        Console.WriteLine("Caught exception from ThrowExceptionCatchRethrow in Main");
      }

      Console.ReadLine();
    }
    // Main()

    static void ThrowExceptionCatchRethrow()
      //***
      // Action
      //   - Try to show a message
      //   - Throw an error
      //   - Catch the error (It will always happen, because just thrown)
      //   - Error is rethrown
      //   - Run the finally block
      //   - Shows a message that you are outside the try block
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220824 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220824 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      try
      {
        Console.WriteLine("In ThrowExceptionCatchRethrow");
        throw new System.Exception("Exception in ThrowExceptionCatchRethrow");
      }
      catch (System.Exception theException)
      {
        Console.WriteLine("Message: " + theException.Message);
        throw theException;
      }
      finally
      {
        Console.WriteLine("Finally executed in ThrowException");
      }

      // Any code placed here is never reached
      Console.WriteLine("End of ThrowExceptionCatchRethrow");
    }
    // ThrowExceptionCatchRethrow

    static void ThrowExceptionWithCatch()
      //***
      // Action
      //   - Try to show a message
      //   - Throw an error
      //   - Catch the error (It will always happen, because just thrown)
      //   - Run the finally block
      //   - Shows a message that you are outside the try block
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220824 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220824 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {

      try
      {
        Console.WriteLine("In ThrowExceptionWithCatch");
        throw new System.Exception("Something went wrong: Exception in ThrowExceptionWithCatch");
      }
      catch (System.Exception theException) 
      {
        Console.WriteLine("Message: " + theException.Message);
      }
      finally
      {
        Console.WriteLine("Finally executed in ThrowExceptionWithCatch");
      }

      Console.WriteLine("End of ThrowExceptionWithCatch");
    }
    // ThrowExceptionWithCatch()

    static void ThrowExceptionWithoutCatch()
      //***
      // Action
      //   - Try to show a message
      //   - Throw an error
      //   - Run the finally block
      //   - Shows a message that you are outside the try block (never reached)
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220824 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220824 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {

      try
      {
        Console.WriteLine("In ThrowExceptionWithoutCatch");
        throw new System.Exception("Exception in ThrowExceptionWithoutCatch");
      }
      finally
      {
        Console.WriteLine("Finally executed in ThrowExceptionWithoutCatch");
      }

      // Any code placed here is never reached
      Console.WriteLine("End of ThrowExceptionWithoutCatch");
    }
    // ThrowExceptionWithoutCatch

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpUsingExceptions

}
// CopyPaste.Learning