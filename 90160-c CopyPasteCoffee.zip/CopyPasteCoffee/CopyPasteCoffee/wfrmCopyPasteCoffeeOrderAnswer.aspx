﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCopyPasteCoffeeOrderAnswer.aspx.cs" Inherits="CopyPaste.Learning.wfrmCopyPasteCoffeeOrderAnswer" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Copy Paste Coffee Order Summary</title>
</head>
<body>
  <form id="wfrmCopyPasteCoffeeOrderAnswer" method="POST">
    <h1>
      The Copy Paste Order Confirmation
    </h1>
    <asp:Label ID="lblAnswer" Style="z-index: 102; position: absolute; top: 80px; left: 120px" runat="server"></asp:Label>
  </form>
</body>
</html>
