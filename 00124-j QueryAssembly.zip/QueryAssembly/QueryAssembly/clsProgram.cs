//***
// Action
//   - Get information out of the assembly
// Created
//   - CopyPaste � 20240710 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240710 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Reflection;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Get the current assembly
      //   - Show the code base
      //   - Show the full name
      //   - Show the entry point
      //   - Show the Global assembly Cache
      //   - Show the location
      //   - Loop thru all the types
      //     - Show the typename
      //   - Loop thru all the referenced assemblies
      //    - Show the full names
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Assembly theAssembly = Assembly.GetExecutingAssembly();

      Console.WriteLine("Code base: " + theAssembly.CodeBase);
      Console.WriteLine("Full name: " + theAssembly.FullName);
      Console.WriteLine("Entry point: " + theAssembly.EntryPoint.ToString());
      Console.WriteLine("From Global Assembly Cache: " + theAssembly.GlobalAssemblyCache);
      Console.WriteLine("Location: " + theAssembly.Location);
      Console.Write("Types: ");

      foreach (Type theType in theAssembly.GetTypes())
      {
        Console.Write(theType.Name + " ");
      }
      // in theAssembly.GetTypes()

      Console.WriteLine();
      Console.WriteLine();
      Console.WriteLine("Referenced Assemblies: ");

      foreach (AssemblyName theReferenceAssembly in theAssembly.GetReferencedAssemblies())
      {
        Console.WriteLine(theReferenceAssembly.FullName);
      }
      // in theAssembly.GetReferencedAssemblies()

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning