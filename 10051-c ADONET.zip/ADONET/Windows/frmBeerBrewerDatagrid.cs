//***
// Action
//   - Show brewer and beer in a data grid
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBeerBrewerDatagrid: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.DataGrid dgrBrewerBeer;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBeerBrewerDatagrid));
      this.dgrBrewerBeer = new System.Windows.Forms.DataGrid();
      ((System.ComponentModel.ISupportInitialize)(this.dgrBrewerBeer)).BeginInit();
      this.SuspendLayout();
      // 
      // dgrBrewerBeer
      // 
      this.dgrBrewerBeer.AlternatingBackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(128)));
      this.dgrBrewerBeer.DataMember = "";
      this.dgrBrewerBeer.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgrBrewerBeer.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrBrewerBeer.Location = new System.Drawing.Point(0, 0);
      this.dgrBrewerBeer.Name = "dgrBrewerBeer";
      this.dgrBrewerBeer.ReadOnly = true;
      this.dgrBrewerBeer.Size = new System.Drawing.Size(568, 341);
      this.dgrBrewerBeer.TabIndex = 1;
      // 
      // frmBeerBrewerDatagrid
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(568, 341);
      this.Controls.Add(this.dgrBrewerBeer);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBeerBrewerDatagrid";
      this.Text = "Beer Brewer Datagrid";
      this.Load += new System.EventHandler(this.frmBeerBrewerDatagrid_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrBrewerBeer)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBeerBrewerDatagrid'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBeerBrewerDatagrid()
      //***
      // Action
      //   - Create new instance of 'frmBeerBrewerDatagrid'
      // Called by
      //   - frmMain.cmdBeerAndBrewerDatagrid_Click(System.Object, System.EventArgs) Handles cmdBeerAndBrewerDatagrid.Click
      //   - User action (Starting the form)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
    }
    // frmBeerBrewerDatagrid()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    private void frmBeerBrewerDatagrid_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Preparing the form to show correct information about brewers and beers
      //   - Define an instance of cpCommand
      //   - Define a data set
      //   - Find the Brewers and Beers data set and assign it to the data set
      //   - The data source of the data grid becomes the data set
      //   - The data member (to start with) is the brewer table
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCommand()
      //   - dsData cpCommand.FindBrewerBeer()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpCommand thecpCommand = new cpCommand();
      DataSet dsData = thecpCommand.FindBrewerBeer();

      dgrBrewerBeer.DataSource = dsData;
      dgrBrewerBeer.DataMember = "tblCPBrewer";
    }
    // frmBeerBrewerDatagrid_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBeerBrewerDatagrid

}
// CopyPaste.Learning