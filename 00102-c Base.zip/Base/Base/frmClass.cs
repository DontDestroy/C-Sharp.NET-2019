//***
// Action
//   - Put content of form in a class
// Created
//   - CopyPaste � 20220603 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220603 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

#region Components

namespace Base
{

  public class frmClass : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdCreate;
    internal System.Windows.Forms.TextBox txtEmail;
    internal System.Windows.Forms.TextBox txtTitle;
    internal System.Windows.Forms.TextBox txtLastName;
    internal System.Windows.Forms.TextBox txtFirstName;
    internal System.Windows.Forms.Label lblEmail;
    internal System.Windows.Forms.Label lblTitle;
    internal System.Windows.Forms.Label lblLastName;
    internal System.Windows.Forms.Label lblFirstName;
    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmClass));
      this.cmdCreate = new System.Windows.Forms.Button();
      this.txtEmail = new System.Windows.Forms.TextBox();
      this.txtTitle = new System.Windows.Forms.TextBox();
      this.txtLastName = new System.Windows.Forms.TextBox();
      this.txtFirstName = new System.Windows.Forms.TextBox();
      this.lblEmail = new System.Windows.Forms.Label();
      this.lblTitle = new System.Windows.Forms.Label();
      this.lblLastName = new System.Windows.Forms.Label();
      this.lblFirstName = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdCreate
      // 
      this.cmdCreate.Location = new System.Drawing.Point(80, 168);
      this.cmdCreate.Name = "cmdCreate";
      this.cmdCreate.Size = new System.Drawing.Size(136, 23);
      this.cmdCreate.TabIndex = 17;
      this.cmdCreate.Text = "Assign Class Members";
      this.cmdCreate.Click += new System.EventHandler(this.cmdCreate_Click);
      // 
      // txtEmail
      // 
      this.txtEmail.Location = new System.Drawing.Point(152, 120);
      this.txtEmail.Name = "txtEmail";
      this.txtEmail.Size = new System.Drawing.Size(100, 20);
      this.txtEmail.TabIndex = 16;
      // 
      // txtTitle
      // 
      this.txtTitle.Location = new System.Drawing.Point(152, 88);
      this.txtTitle.Name = "txtTitle";
      this.txtTitle.Size = new System.Drawing.Size(100, 20);
      this.txtTitle.TabIndex = 15;
      // 
      // txtLastName
      // 
      this.txtLastName.Location = new System.Drawing.Point(152, 56);
      this.txtLastName.Name = "txtLastName";
      this.txtLastName.Size = new System.Drawing.Size(100, 20);
      this.txtLastName.TabIndex = 14;
      // 
      // txtFirstName
      // 
      this.txtFirstName.Location = new System.Drawing.Point(152, 24);
      this.txtFirstName.Name = "txtFirstName";
      this.txtFirstName.Size = new System.Drawing.Size(100, 20);
      this.txtFirstName.TabIndex = 13;
      // 
      // lblEmail
      // 
      this.lblEmail.Location = new System.Drawing.Point(32, 120);
      this.lblEmail.Name = "lblEmail";
      this.lblEmail.Size = new System.Drawing.Size(100, 23);
      this.lblEmail.TabIndex = 12;
      this.lblEmail.Text = "Email:";
      // 
      // lblTitle
      // 
      this.lblTitle.Location = new System.Drawing.Point(32, 88);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(100, 23);
      this.lblTitle.TabIndex = 11;
      this.lblTitle.Text = "Title:";
      // 
      // lblLastName
      // 
      this.lblLastName.Location = new System.Drawing.Point(32, 56);
      this.lblLastName.Name = "lblLastName";
      this.lblLastName.Size = new System.Drawing.Size(100, 23);
      this.lblLastName.TabIndex = 10;
      this.lblLastName.Text = "Last Name:";
      // 
      // lblFirstName
      // 
      this.lblFirstName.Location = new System.Drawing.Point(32, 24);
      this.lblFirstName.Name = "lblFirstName";
      this.lblFirstName.Size = new System.Drawing.Size(100, 23);
      this.lblFirstName.TabIndex = 9;
      this.lblFirstName.Text = "First Name:";
      // 
      // frmClass
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 213);
      this.Controls.Add(this.cmdCreate);
      this.Controls.Add(this.txtEmail);
      this.Controls.Add(this.txtTitle);
      this.Controls.Add(this.txtLastName);
      this.Controls.Add(this.txtFirstName);
      this.Controls.Add(this.lblEmail);
      this.Controls.Add(this.lblTitle);
      this.Controls.Add(this.lblLastName);
      this.Controls.Add(this.lblFirstName);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmClass";
      this.Text = "Base";
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDefault'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220603 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220603 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmClass()
      //***
      // Action
      //   - Create instance of 'frmClass'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220603 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220603 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmClass()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdCreate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //'***
      //' Action
      //'   - Do some checks before you create a class based on the information you have typed
      //'   - Check on length 0 for first name
      //'     - Show error if it is
      //'   - Check on length 0 for last name
      //'     - Show error if it is
      //'   - Check on length 0 for book title
      //'     - Show error if it is
      //'   - Check on length 0 for email address
      //'     - Show error if it is
      //'   - If not
      //'     - Create the author
      //'     - Show a message with the author information
      //' Called by
      //'   - User action (Clicking a button)
      //' Calls
      //'   - cpAuthor(string, string, string, string)
      //' Created
      //'   - CopyPaste � 20220603 � VVDW
      //' Changed
      //'   - CopyPaste � yyyymmdd � VVDW � What changed
      //' Tested
      //'   - CopyPaste � 20220603 � VVDW
      //' Keyboard key
      //'   -
      //' Proposal (To Do)
      //'   -
      //'***
    {

      if (txtFirstName.Text.Length == 0)
      {
        MessageBox.Show("Must specify first name");
      }
      else if (txtLastName.Text.Length == 0)
      {
        MessageBox.Show("Must specify last name");
      }
      else if (txtTitle.Text.Length == 0)
      {
        MessageBox.Show("Must specify book title");
      }
      else if (txtEmail.Text.Length == 0)
      {
        MessageBox.Show("Must specify email address");
      }
      else
      // txtFirstName.Text.Length <> 0
      // txtLastName.Text.Length <> 0
      // txtTitle.Text.Length <> 0
      // txtEmail.Text.Length <> 0
      {
        cpAuthor theAuthor = new cpAuthor(txtFirstName.Text, txtLastName.Text, txtTitle.Text, txtEmail.Text);
        MessageBox.Show("Name: " + theAuthor.mstrFirstName + " " + theAuthor.mstrLastName + " - Title: " + theAuthor.mstrBookTitle + " - Email: " + theAuthor.mstrEmailAddress);
      }
      // (txtFirstName.Text.Length = 0)
    
    }
    // cmdCreate_Click(System.Object, System.EventArgs) Handles cmdCreate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmClass
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmClass()
      // Created
      //   - CopyPaste � 20220603 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220603 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmClass());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmClass

  public class cpPerson
  {

    #region "Constructors / Destructors"

    public cpPerson(string strFirstName, string strLastName)
      //***
      // Action
      //   - Creating an instance op cpPerson
      // Called by
      //   - cpAuthor(string, string, string, string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220603 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220603 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***

    {
      mstrFirstName = strFirstName;
      mstrLastName = strLastName;
    }
    // cpPerson(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public string mstrFirstName;
    public string mstrLastName;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpPerson

  public class cpAuthor : cpPerson
  {

    #region "Constructors / Destructors"

    public cpAuthor(string strFirstName, string strLastName, string strBookTitle, string strEmailAddress) : base(strFirstName, strLastName)
      //'***
      //' Action
      //'   - Creating an instance op cpAuthor
      //' Called by
      //'   - cmdCreate_Click(System.Object, System.EventArgs) Handles cmdCreate.Click
      //' Calls
      //'   - cpPerson(string, string)
      //' Created
      //'   - CopyPaste � 20220603 � VVDW
      //' Changed
      //'   - CopyPaste � yyyymmdd � VVDW � What changed
      //' Tested
      //'   - CopyPaste � 20220603 � VVDW
      //' Keyboard key
      //'   - 
      //' Proposal (To Do)
      //'   - 
      //'***
    {
      mstrBookTitle = strBookTitle;
      mstrEmailAddress = strEmailAddress;
    }
    // cpAuthor(string, string, string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public string mstrBookTitle;
    public string mstrEmailAddress;
   
    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpAuthor

}
// Base

#endregion