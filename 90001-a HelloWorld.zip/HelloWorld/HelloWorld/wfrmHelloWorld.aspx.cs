﻿//***
// Action
//   - Demo of a simple website with 3 textboxes and 2 command buttons
// Created
//   - CopyPaste – 20260325 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260325 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public partial class wfrmHelloWorld : System.Web.UI.Page
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    protected void cmdServer_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change the text of a textbox
    // Called by
    //   - User action (Clicking a button) (Server side)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260325 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260325 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      txtServer.Text = "txtServer (cmdServer_Click)";
    }
    // cmdServer_Click(System.Object, System.EventArgs) Handles cmdServer.Click

    protected void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change the text of a textbox
    // Called by
    //   - User action (Loading the page) (Server side)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260325 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260325 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      txtServer.Text = "txtServer (Page_Load)";
    }
    // Page_Load(System.Object, System.EventArgs) Handles base.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#Region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmHelloWorld 

}
// CopyPaste.Learning