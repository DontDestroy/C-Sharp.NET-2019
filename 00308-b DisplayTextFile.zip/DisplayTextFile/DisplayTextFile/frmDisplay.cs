//***
// Action
//   - Open a file and display the text
// Created
//   - CopyPaste � 20240925 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240925 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDisplayText: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtResult;
    internal System.Windows.Forms.Button cmdSelect;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDisplayText));
      this.cmdSelect = new System.Windows.Forms.Button();
      this.txtResult = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdSelect
      // 
      this.cmdSelect.Location = new System.Drawing.Point(105, 24);
      this.cmdSelect.Name = "cmdSelect";
      this.cmdSelect.TabIndex = 2;
      this.cmdSelect.Text = "Select a File";
      this.cmdSelect.Click += new System.EventHandler(this.cmdSelect_Click);
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(20, 80);
      this.txtResult.Multiline = true;
      this.txtResult.Name = "txtResult";
      this.txtResult.Size = new System.Drawing.Size(250, 150);
      this.txtResult.TabIndex = 3;
      this.txtResult.Text = "";
      // 
      // frmDisplayText
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.txtResult);
      this.Controls.Add(this.cmdSelect);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDisplayText";
      this.Text = "Display Text";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDisplayText'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240925 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240925 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDisplayText()
      //***
      // Action
      //   - Create instance of 'frmDisplayText'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240925 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240925 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDisplayText()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdSelect_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a file open dialog
      //   - Set the filter
      //   - Text files in the selected option
      //   - Directory is by default T:\
      //   - If OK is clicked
      //     - Define an array of 1025 bytes
      //     - Define a file stream
      //     - Try
      //       - Open the chosen file into the filestream
      //     - On error
      //       - Show that file could not be opened
      //     - Loop, as long there is text
      //       - Try
      //         - Take the next 1024 bytes
      //         - Set text to empty string
      //         - Loop thru all the bytes
      //           - Add the character to text
      //         - Append the text to the textbox
      //       - On error
      //         - Show error reading file
      //     - Close the file
      //   - If not
      //     - Show that cancel was selected
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240925 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240925 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      OpenFileDialog dlgFileOpen = new OpenFileDialog();

      dlgFileOpen.Filter = "All files | *.* | Word files | *.doc | Text files | *.txt";
      dlgFileOpen.FilterIndex = 3;
      dlgFileOpen.InitialDirectory = "T:\\";

      if (dlgFileOpen.ShowDialog() == DialogResult.OK)
      {
        byte[] arrbytText = new byte[1025];
        FileStream filstrOpen;
        int lngBytes = 0;
        int lngCounter;
        string strText;
        
        try
        {
          filstrOpen = (FileStream) dlgFileOpen.OpenFile();

          do
          {

            try
            {
              lngBytes = filstrOpen.Read(arrbytText, 1, 1024);
              strText = "";

              for (lngCounter = 1; lngCounter <= lngBytes; lngCounter++)
              {
                strText = strText + (char)arrbytText[lngCounter];
              }
              // lngCounter = lngBytes + 1

              txtResult.AppendText(strText);
            }
            catch
            {
              MessageBox.Show("Error reading file");
            }
            finally
            {
            }

          }
          while (lngBytes != 0);
          // lngBytes = 0

          filstrOpen.Close();
        }
        catch
        {
          MessageBox.Show("Error opening " + dlgFileOpen.FileName);
        }
        finally
        {
        }

      }
      else
        // dlgFileOpen.ShowDialog() <> DialogResult.OK 
      {
        MessageBox.Show("User selected Cancel");
      }
      // dlgFileOpen.ShowDialog() = DialogResult.OK 
    
    }
    // cmdSelect_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdSelect.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDisplayText
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDisplayText()
      // Created
      //   - CopyPaste � 20240925 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240925 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDisplayText());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDisplayText

}
// CopyPaste.Learning