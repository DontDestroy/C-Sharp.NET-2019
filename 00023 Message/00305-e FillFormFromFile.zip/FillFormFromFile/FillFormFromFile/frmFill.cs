//***
// Action
//   - Reading a file and showing it on a form
// Created
//   - CopyPaste � 20230809 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230809 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFill : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    internal System.Windows.Forms.Button cmdSelect;
    internal System.Windows.Forms.TextBox txtResult;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFill));
      this.cmdSelect = new System.Windows.Forms.Button();
      this.txtResult = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdSelect
      // 
      this.cmdSelect.Location = new System.Drawing.Point(105, 24);
      this.cmdSelect.Name = "cmdSelect";
      this.cmdSelect.TabIndex = 2;
      this.cmdSelect.Text = "Select File";
      this.cmdSelect.Click += new System.EventHandler(this.cmdSelect_Click);
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(21, 80);
      this.txtResult.Multiline = true;
      this.txtResult.Name = "txtResult";
      this.txtResult.Size = new System.Drawing.Size(250, 150);
      this.txtResult.TabIndex = 3;
      this.txtResult.Text = "";
      // 
      // frmFill
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdSelect);
      this.Controls.Add(this.txtResult);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFill";
      this.Text = "Open File to Fill Form";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFill'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFill()
      //***
      // Action
      //   - Create instance of 'frmFill'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFill()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdSelect_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - A file open dialog box is defined
      //   - Needed parameters are set
      //     - By default is "C:\Temp" chosen
      //     - This becomes the normal documents folder if it does not exist
      //   - If 'OK' button is clicked
      //     - The saved text is shown in a form using the file defined in the file open dialog box
      //     - If successful, a message is shown
      //     - If not, an error message is shown
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      OpenFileDialog dlgFileOpen = new OpenFileDialog();

      dlgFileOpen.Filter = "All files | *.* | Text files | *.txt";
      dlgFileOpen.FilterIndex = 2;
      dlgFileOpen.InitialDirectory = "C:\\Temp";
      dlgFileOpen.AddExtension = true;
      dlgFileOpen.DefaultExt = "txt";

      if (dlgFileOpen.ShowDialog() == DialogResult.OK)
      {
        StreamReader strReader = null;

        try
        {
          strReader = new StreamReader(dlgFileOpen.FileName);

          try
          {
            txtResult.Text = strReader.ReadToEnd();
          }
          catch
          {
            MessageBox.Show("Error reading file");
          }
          finally
          {
          }

        }
        catch
        {
          MessageBox.Show("Error opening " + dlgFileOpen.FileName + " for reading.");
        }
        finally
        {
        }

        strReader.Close();
      }
      else
        // dlgFileOpen.ShowDialog() <> DialogResult.OK
      {
        MessageBox.Show("User selected Cancel");
      }
      // dlgFileOpen.ShowDialog() = DialogResult.OK

    }
    // cmdSelect_Click(System.Object, System.EventArgs) Handles cmdSelect.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFill
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFill());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmFill

}
// CopyPaste.Learning