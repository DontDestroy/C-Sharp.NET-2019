//***
// Action
//   - Implementation of a cpPointEnumerator
//   - Interface IEnumerator is used
//   - The goal is this
//     - Making sure you can use a foreach statement
//     - You need a current position as property
//     - You need the method Reset
//     - You need the method Movenext
//   - It is good practice when the size of the list changes
//     - Looping is stopped
//     - Enumerator is resetted
// Created
//   - CopyPaste � 20240314 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240314 � VVDW
// Proposal (To Do)
//   - You can implement the class inside cpSortedPointList, because it is not used anywhere else
//***

using System;
using System.Collections;

namespace CopyPaste.Learning
{

  public class cpPointEnumerator :  IEnumerator
  {

    #region "Constructors / Destructors"

    public cpPointEnumerator(ArrayList arrPoint)
      //***
      // Action
      //   - Constructor of cpPointEnumerator
      //   - An ArrayList is given
      //   - The number of elements is remembered to check if the number of elements is changed
      // Called by
      //   - IEnumerator cpSortedPointList.GetEnumerator()
      //   - frmPoint.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      marrPoint = arrPoint;
      mlngInitialCount = arrPoint.Count;
    }
    // cpPointEnumerator(ArrayList)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    ArrayList marrPoint;
    int mlngInitialCount;
    int mlngPosition = -1;
    // Position is set to -1 (because MoveNext goes to the next, so the first is position 0)

    #endregion

    #region "Properties"

    public System.Object Current
    {

      get
        //***
        // Action Get
        //   - An obligatory implementation due to IEnumerator
        //   - If the number of elements in the array is still the same at the moment of the instantiation
        //     - Returns the current element
        //   - If not
        //     - If the position is bigger than the number of elements
        //       - Throw an invalid operation exception with specific message
        //     - If not
        //       - Throw an invalid operation exception with specific message
        // Called by
        //   - frmPoint.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
        //   - frmPointCoordinate.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
        //   - frmPointList.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240314 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240314 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (mlngInitialCount == marrPoint.Count)
        {
          return marrPoint[mlngPosition];
        }
        else if (mlngPosition >= marrPoint.Count)
          // mlngInitialCount <> marrPoint.Count
        {
          throw new InvalidOperationException("Enumeration value is invalid.");
        }
        else
          // mlngPosition < marrPoint.Count
        {
          throw new InvalidOperationException("Collection has changed during enumeration.");
        }
        // mlngInitialCount == marrPoint.Count
        // mlngPosition >= marrPoint.Count

      }
      // System.Object Current (Get)

    }
    // System.Object Current

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"


    public bool MoveNext()
      //***
      // Action
      //   - An obligatory implementation due to IEnumerator
      //   - Returns true when you can go to the next element
      //   - Returns false when there is no next element
      //   - If original number of elements is bigger or equal than the number of elements
      //     - Increment the position with 1
      //     - If position is bigger or equal than the number of elements
      //       - Return false
      //     - If Not
      //       - Return true
      //   - If not
      //     - Throw an invalid operation exception with specific message
      // Called by
      //   - frmPoint.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
      //   - frmPointCoordinate.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
      //   - frmPointList.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnReturn;

      if (mlngInitialCount >= marrPoint.Count) 
      {
        mlngPosition += 1;

        if (mlngPosition >= marrPoint.Count)
        {
          blnReturn = false;
        }
        else
          // mlngPosition < marrPoint.Count
        {
          blnReturn = true;
        }
        // mlngPosition >= marrPoint.Count

      }
      else
        // mlngInitialCount < marrPoint.Count
      {
        throw new InvalidOperationException("Collection has changed during enumeration.");
      }
      // mlngInitialCount >= marrPoint.Count

      return blnReturn;
    }
    // bool MoveNext()
		
    public void Reset()
      //***
      // Action
      //   - An obligatory implementation due to IEnumerator
      //   - Set position to -1
      //     - The movenext increments the position (first element has index 0)
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mlngPosition = -1;
    }
    // Reset()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpPointEnumerator

}
// CopyPaste.Learning