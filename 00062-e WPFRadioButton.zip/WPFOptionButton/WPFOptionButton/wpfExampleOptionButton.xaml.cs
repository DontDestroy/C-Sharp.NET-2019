﻿//***
// Action
//   - Demo of an OptionButton
// Created
//   - CopyPaste – 20220921 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220921 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;
using System.Windows;
using System.Windows.Media;

namespace WPFOptionButton
{

  public partial class wpfExampleOptionButton : Window
  {

    #region "Constructors / Destructors"

    public wpfExampleOptionButton()
    //***
    // Action
    //   - Create an instance of 'wpfExampleOptionButton'
    // Called by
    //   - User action (Starting application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220921 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220921 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfExampleOptionButton()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void chkVisible_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Depending on the value of chkVisible, is cmdClickMe visible or not
    // Called by
    //   - User action (Clicking a checkbox)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220921 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220921 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if ((bool)chkVisible.IsChecked)
      {
        cmdClickMe.Visibility = Visibility.Visible;
      }
      else
      // Not (bool)chkVisible.IsChecked
      {
        cmdClickMe.Visibility = Visibility.Hidden;
      }
      // (bool)chkVisible.IsChecked

    }
    // chkVisible_Click(System.Object, System.Windows.RoutedEventArgs) Handles chkVisible.Click

    private void cmdClickMe_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Prove that you have clicked on the button
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220921 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220921 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Debug.WriteLine("You have clicked the button");
    }
    // cmdClickMe_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdClickMe.Click

    private void optBlue_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Prove that you have clicked on the option by making the button blue
    // Called by
    //   - User action (Clicking an option)
    // Calls
    //   - ColourButton(string)
    // Created
    //   - CopyPaste – 20220921 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220921 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ColourButton("Blue");
    }
    // optBlue_Click(System.Object, System.Windows.RoutedEventArgs) Handles optBlue.Click

    private void optGreen_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Prove that you have clicked on the option by making the button green
    // Called by
    //   - User action (Clicking an option)
    // Calls
    //   - ColourButton(string)
    // Created
    //   - CopyPaste – 20220921 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220921 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ColourButton("Green");
    }
    // optGreen_Click(System.Object, System.Windows.RoutedEventArgs) Handles optGreen.Click

    private void optRed_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Prove that you have clicked on the option by making the button red
    // Called by
    //   - User action (Clicking an option)
    // Calls
    //   - ColourButton(string)
    // Created
    //   - CopyPaste – 20220921 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220921 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ColourButton("Red");
    }
    // optRed_Click(System.Object, System.Windows.RoutedEventArgs) Handles optRed.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void ColourButton(string strColour)
    //***
    // Action
    //   - Prove that you have clicked on the option by making the button blue
    // Called by
    //   - optBlue_Click(System.Object, System.Windows.RoutedEventArgs) Handles optBlue.Click
    //   - optGreen_Click(System.Object, System.Windows.RoutedEventArgs) Handles optGreen.Click
    //   - optRed_Click(System.Object, System.Windows.RoutedEventArgs) Handles optRed.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220921 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220921 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      switch (strColour)
      {
        case "Blue":
          cmdClickMe.Background = Brushes.Blue;
          break;
        case "Green":
          cmdClickMe.Background = Brushes.Green;
          break;
        case "Red":
          cmdClickMe.Background = Brushes.Red;
          break;
      }
      // strColour

    }
    // ColourButton(string)

    #endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfExampleOptionButton

}
// WPFOptionButton