//***
// Action
//   - Creating a guessing game. This is form as startpoint of the exercise
// Created
//   - CopyPaste � 20240129 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240129 � VVDW
// Proposal (To Do)
//   - The maximum value 10 is hardcoded
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmGuessingGame: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdGuess;
    internal System.Windows.Forms.TextBox txtNumber;
    internal System.Windows.Forms.Label lblMessage;
    internal System.Windows.Forms.Label lblTitle;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmGuessingGame));
      this.cmdGuess = new System.Windows.Forms.Button();
      this.txtNumber = new System.Windows.Forms.TextBox();
      this.lblMessage = new System.Windows.Forms.Label();
      this.lblTitle = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdGuess
      // 
      this.cmdGuess.Location = new System.Drawing.Point(78, 176);
      this.cmdGuess.Name = "cmdGuess";
      this.cmdGuess.Size = new System.Drawing.Size(128, 32);
      this.cmdGuess.TabIndex = 7;
      this.cmdGuess.Text = "&Guess";
      this.cmdGuess.Click += new System.EventHandler(this.cmdGuess_Click);
      // 
      // txtNumber
      // 
      this.txtNumber.Location = new System.Drawing.Point(70, 96);
      this.txtNumber.Name = "txtNumber";
      this.txtNumber.Size = new System.Drawing.Size(136, 20);
      this.txtNumber.TabIndex = 6;
      this.txtNumber.Text = "";
      // 
      // lblMessage
      // 
      this.lblMessage.Location = new System.Drawing.Point(14, 72);
      this.lblMessage.Name = "lblMessage";
      this.lblMessage.Size = new System.Drawing.Size(160, 16);
      this.lblMessage.TabIndex = 5;
      this.lblMessage.Text = "&Enter a number from 1 to 10:";
      this.lblMessage.TextAlign = System.Drawing.ContentAlignment.TopCenter;
      // 
      // lblTitle
      // 
      this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblTitle.Location = new System.Drawing.Point(6, 8);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(280, 32);
      this.lblTitle.TabIndex = 4;
      this.lblTitle.Text = "Guessing Game";
      this.lblTitle.TextAlign = System.Drawing.ContentAlignment.TopCenter;
      // 
      // frmGuessingGame
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdGuess);
      this.Controls.Add(this.txtNumber);
      this.Controls.Add(this.lblMessage);
      this.Controls.Add(this.lblTitle);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmGuessingGame";
      this.Text = "The Guessing Game";
      this.Load += new System.EventHandler(this.frmGuessingGame_Load);
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmGuessingGame'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240129 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240129 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmGuessingGame()
			//***
			// Action
			//   - Create instance of 'frmGuessingGame'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240129 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240129 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmGuessingGame()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

    int mlngNumber;
    Random mrndRandom = new Random(DateTime.Now.Millisecond);

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"
    
    private void cmdGuess_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Check if the number was a numeric value
      //     - If Not, show an error message and stop routine
      //   - Check if the number is between 1 (included) and 10 (included)
      //     - If Not, show an error message and stop routine
      //   - Depending on the number
      //     - Too high, show a message that the number was too high
      //     - Too low, show a message that the number was too low
      //     - Exact value, show a message that you found the number and stop application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240129 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20240129 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (Information.IsNumeric(txtNumber.Text))
      {

        if ((Conversion.Val(txtNumber.Text) < 1) || (Conversion.Val(txtNumber.Text) > 10))
        {
          MessageBox.Show("Please enter a number between 1 and 10!");
        }
        else
          // Conversion.Val(txtNumber.Text) >= 1 And Conversion.Val(txtNumber.Text) <= 10
        {

          if (Conversion.Val(txtNumber.Text) > mlngNumber)
          {
            MessageBox.Show("That number is too high");
          }
          else if (Conversion.Val(txtNumber.Text) < mlngNumber)
            // Conversion.Val(txtNumber.Text) <= mlngNumber
          {
            MessageBox.Show("That number is too low");
          }
          else
            // Conversion.Val(txtNumber.Text) = mlngNumber
          {
            MessageBox.Show("That number is CORRECT!");
            Application.Exit();
          }
          // Conversion.Val(txtNumber.Text) > mlngNumber
          // Conversion.Val(txtNumber.Text) < mlngNumber
          // Conversion.Val(txtNumber.Text) = mlngNumber

        }
        // Conversion.Val(txtNumber.Text) < 1 Or Conversion.Val(txtNumber.Text) > 10

      }
      else
        // Not Information.IsNumeric(txtNumber.Text)
      {
        MessageBox.Show("Please enter a number between 1 and 10!");
      }
      // Information.IsNumeric(txtNumber.Text)
    
    }
    // cmdGuess_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdGuess.Click

    private void frmGuessingGame_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Determine a random number as starting point between 1 (included) and 10 (included)
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240129 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20240129 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mlngNumber = mrndRandom.Next(1, 11);
    }
    // frmGuessingGame_Load(System.Object, System.EventArgs) Handles frmGuessingGame.Load

		#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmGuessingGame
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmDefault()
			// Created
			//   - CopyPaste � 20240129 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240129 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmGuessingGame());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmGuessingGame

}
// CopyPaste.Learning