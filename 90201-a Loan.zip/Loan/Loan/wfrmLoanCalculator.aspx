﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmLoanCalculator.aspx.cs" Inherits="CopyPaste.Learning.wfrmLoanCalculator" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>The Loan Calculator</title>
</head>
<body>
  <form id="wfrmLoanCalculator" method="post" runat="server">
    <asp:Label Style="z-index: 101; position: absolute; top: 12px; left: 28px" ID="lblTitle" runat="server"
      Font-Underline="True" Font-Bold="True" Font-Names="Verdana" Width="294px">The Copy Paste Loan Calculator</asp:Label>
    <asp:Label Style="z-index: 102; position: absolute; top: 49px; left: 23px; width: 417px;" ID="lblAmount" runat="server">How much do you want to borrow?</asp:Label>
    <asp:TextBox Style="z-index: 103; position: absolute; top: 72px; left: 21px" ID="txtAmount" runat="server"></asp:TextBox>
    <asp:Label Style="z-index: 104; position: absolute; top: 101px; left: 24px" ID="lblRate" runat="server"
      Width="111px">Interest Rate</asp:Label>
    <asp:TextBox Style="z-index: 105; position: absolute; top: 127px; left: 21px" ID="txtRate" runat="server"></asp:TextBox>
    <asp:Label Style="z-index: 106; position: absolute; top: 160px; left: 26px; width: 320px;" ID="lblTerm" runat="server">Term of Loan (in months)</asp:Label>
    <asp:DropDownList Style="z-index: 107; position: absolute; top: 188px; left: 24px" ID="cmbTerm" runat="server"
      Width="104px">
      <asp:ListItem Value="12">12</asp:ListItem>
      <asp:ListItem Value="24">24</asp:ListItem>
      <asp:ListItem Value="36">36</asp:ListItem>
      <asp:ListItem Value="48">48</asp:ListItem>
      <asp:ListItem Value="60">60</asp:ListItem>
      <asp:ListItem Value="72">72</asp:ListItem>
      <asp:ListItem Value="84">84</asp:ListItem>
      <asp:ListItem Value="96">96</asp:ListItem>
      <asp:ListItem Value="108">108</asp:ListItem>
      <asp:ListItem Value="120">120</asp:ListItem>
      <asp:ListItem Value="132">132</asp:ListItem>
      <asp:ListItem Value="144">144</asp:ListItem>
      <asp:ListItem Value="156">156</asp:ListItem>
      <asp:ListItem Value="168">168</asp:ListItem>
      <asp:ListItem Value="180">180</asp:ListItem>
    </asp:DropDownList>
    <asp:Button Style="z-index: 108; position: absolute; top: 227px; left: 25px" ID="cmdCalculate"
      runat="server" Width="101px" Text="Calculate"></asp:Button>
    <asp:Label Style="z-index: 109; position: absolute; top: 227px; left: 198px" ID="lblMonthly"
      runat="server" Width="312px"></asp:Label>
    <asp:RangeValidator Style="z-index: 110; position: absolute; top: 71px; left: 194px; width: 602px;" ID="rgvAmount"
      runat="server" MinimumValue="1000" MaximumValue="150000" Type="Currency" ControlToValidate="txtAmount"
      ErrorMessage="The loan must be between € 1.000 and € 150.000"></asp:RangeValidator>
    <asp:RequiredFieldValidator Style="z-index: 111; position: absolute; top: 72px; left: 194px; width: 271px;" ID="rfvAmount"
      runat="server" ControlToValidate="txtAmount" ErrorMessage="Please enter a loan amount"></asp:RequiredFieldValidator>
    <asp:RegularExpressionValidator Style="z-index: 112; position: absolute; top: 128px; left: 194px; width: 450px;" ID="revRate" runat="server" ControlToValidate="txtRate" ErrorMessage="Please enter a numeric rate in the format X,X" ValidationExpression="\d*[,]{0,1}\d*"></asp:RegularExpressionValidator>
    <asp:RequiredFieldValidator Style="z-index: 113; position: absolute; top: 128px; left: 194px; width: 289px;" ID="rfvRate" runat="server" ControlToValidate="txtRate" ErrorMessage="Please enter an interest rate"></asp:RequiredFieldValidator>
    <asp:HyperLink Style="z-index: 114; position: absolute; top: 271px; left: 205px" ID="hypSchedule"
      runat="server" Width="131px" NavigateUrl="wfrmLoanPaymentSchedule.aspx">Payment Schedule</asp:HyperLink>
  </form>
</body>
</html>
