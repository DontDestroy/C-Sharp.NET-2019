//***
// Action
//   - Loop thru funny faces
// Created
//   - CopyPaste � 20240117 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240117 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmCounter: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdShow;
    internal System.Windows.Forms.PictureBox picIcon;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCounter));
      this.cmdShow = new System.Windows.Forms.Button();
      this.picIcon = new System.Windows.Forms.PictureBox();
      this.SuspendLayout();
      // 
      // cmdShow
      // 
      this.cmdShow.Location = new System.Drawing.Point(76, 158);
      this.cmdShow.Name = "cmdShow";
      this.cmdShow.Size = new System.Drawing.Size(104, 32);
      this.cmdShow.TabIndex = 3;
      this.cmdShow.Text = "&Show";
      this.cmdShow.Click += new System.EventHandler(this.cmdShow_Click);
      // 
      // picIcon
      // 
      this.picIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.picIcon.Location = new System.Drawing.Point(76, 30);
      this.picIcon.Name = "picIcon";
      this.picIcon.Size = new System.Drawing.Size(104, 96);
      this.picIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picIcon.TabIndex = 2;
      this.picIcon.TabStop = false;
      // 
      // frmCounter
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(256, 221);
      this.Controls.Add(this.cmdShow);
      this.Controls.Add(this.picIcon);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCounter";
      this.Text = "Counter";
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmCounter'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240117 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240117 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmCounter()
			//***
			// Action
			//   - Create instance of 'frmCounter'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240117 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240117 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmCounter()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

    int mlngCounter = 1;

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"

    
    private void cmdShow_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the correct image depending on 'mlngCounter'
      //   - Add 1 to 'mlngCounter'
      //   - If 'mlngCounter' = 5
      //     - 'mlngCounter' becomes 1
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - System.Drawing.Image.FormFile(String)
      // Created
      //   - CopyPaste � 20080701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20080701 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      picIcon.Image = System.Drawing.Image.FromFile(Directory.GetCurrentDirectory() + "\\face0" + mlngCounter + ".ico");
      mlngCounter += 1;
      
      if (mlngCounter == 5)
      {
        mlngCounter = 1;
      }
      else
      // mlngCounter <> 5
      {
      }
      // mlngCounter = 5
      
    }
    // cmdShow_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdShow.Click

		#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmCounter
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmCounter()
			// Created
			//   - CopyPaste � 20240117 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240117 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmCounter());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmCounter

}
// CopyPaste.Learning