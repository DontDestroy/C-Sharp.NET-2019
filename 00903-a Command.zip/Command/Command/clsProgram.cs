﻿//***
// Action
//   - Read the given parameters attached to an executable
// Created
//   - CopyPaste – 20250723 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250723 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main(string[] strArguments)
      //***
      // Action
      //   - In the parameters given with the executable we give "-d:50 -f -g -k" as commands
      //   - The "-" and the "/" can be used as delimiters
      //   - Show the command string
      //   - Loop thru all the characters of the command string
      //     - Get the actual character
      //     - If the character is a "-" or a "/"
      //       - Get the next character (to get the command letter)
      //       - Depending on the letter
      //         - Case "d"
      //           - Show "Got Option d with the attached parameter" (in this case 50)
      //         - Case "f"
      //           - Show "Got Option f"
      //         - Case "g"
      //           - Show "Got Option f"
      //         - Case "k"
      //           - Show "Got Option f"
      //     - If not
      //       - Do nothing
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250723 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250723 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngCounter;
      string strChar;
      string strParameter;
      string strPattern = "[-/]";

      foreach(string strString in strArguments)
      {
        Console.Write(strString + " ");
      }
      // in strArguments

      Console.WriteLine();

      foreach(string strString in strArguments)
      {
        strChar = strString.Substring(0, 1);

        if ((strChar == "-") || (strChar == "/"))
        {
          strChar = strString.Substring(1, 1);
          Console.WriteLine();

          switch (strChar)
          {
            case "d":
              Console.WriteLine("Got Option d");
              strParameter = strString.Substring(3, 2);
              Console.WriteLine("Option d Parameter = " + strParameter);
              break;
            case "f":
              Console.WriteLine("Got Option f");
              break;
            case "g":
              Console.WriteLine("Got Option g");
              break;
            case "k":
              Console.WriteLine("Got Option k");
              break;
            case "l":
              Console.WriteLine("Got Option l");
              break;
          }
          // strChar

        }
        else
          // (strChar <> "-") AndAlso (strChar <> "/")
        {
        }
        // (strChar = "-") OrElse (strChar = "/")

      }
      // in strArguments

      Console.WriteLine();
      Console.ReadLine();
    }
    // Main(string[])

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning