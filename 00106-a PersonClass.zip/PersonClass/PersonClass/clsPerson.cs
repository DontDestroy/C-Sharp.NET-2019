//***
// Action
//   - Definition of a cpPerson
// Created
//   - CopyPaste � 20230819 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230819 � VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpPerson
  {

    #region "Constructors / Destructors"

    ~cpPerson()
      //***
      // Action
      //   - Destroys the instance of cpPerson
      // Called by
      //   - System action (Destroying up instance of cpPerson)
      // Calls
      //   - Dispose()
      // Created
      //   - CopyPaste � 20230819 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230819 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Dispose();
    }
    // ~cpPerson()

    public void Dispose()
      //***
      // Action
      //   - Make it possible to clean up nicely by the garbage collector
      //   - Substract 1 from the amount of persons
      // Called by
      //   - ~cpPerson()
      // Calls
      //   - Count()
      // Created
      //   - CopyPaste � 20230819 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230819 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show("Person " + Count() + " is cleaned up.", "Copy Paste");
      mlngCount -= 1;
    }
    // Dispose()

    public cpPerson()
      //***
      // Action
      //   - Constructor of cpPerson
      //   - Add 1 to the amount of persons
      // Called by
      //   - frmPerson.cmdUse_Click(System.Object, System.EventArgs) Handles cmdUse.Click
      //   - cpPerson(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230819 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230819 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mlngCount += 1;
    }
    // cpPerson()

    public cpPerson(string strNewName) : this()
      //***
      // Action
      //   - Constructor of cpPerson with a name
      // Called by
      //   - frmPerson()
      //   - frmPerson.cmdUse_Click(System.Object, System.EventArgs) Handles cmdUse.Click
      // Calls
      //   - cpPerson()
      // Created
      //   - CopyPaste � 20230819 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230819 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Name = strNewName;
    }
    // cpPerson()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public event cpDelegate cpTesting;
    private int mlngAge;
    public int mlngAgePublic;
    private static int mlngCount;
    private const int mlngMaxAge = 120;
    private string mstrName;

    #endregion

    #region "Properties"

    public int Age
    {
    
      get
        //***
        // Action Get
        //   - Return the age of a cpPerson
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230819 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230819 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngAge;
      }
      // int Age (Get)

      set
        //***
        // Action Set
        //   - If value is negative
        //     - Error is shown
        //   - If not
        //     - If value is bigger than the maximum age
        //       - Error is shown
        //     - If not
        //       - Age becomes value
        // Called by
        //   - frmPerson.cmdUse_Click(System.Object, System.EventArgs) Handles cmdUse.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230819 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230819 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value < 0)
        {
          MessageBox.Show("Age cannot be negative.", "Copy Paste");
        }
        else
          // value >= 0
        {

          if (value > mlngMaxAge)
          {
            MessageBox.Show("Age cannot be bigger than " + mlngMaxAge + ".", "Copy Paste");
          }
          else
            // value <= mlngMaxAge
          {
            mlngAge = value;
          }
          // value > mlngMaxAge
  
        }
        // value < 0

      }
      // Age(int) (Set)

    }
    // int Age

    public string Name
    {

      get
        //***
        // Action Get
        //   - Return the name of a cpPerson
        // Called by
        //   - frmPerson.mthePerson01_cpTesting() Handles mthePerson01.cpTesting
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230819 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230819 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

      set
        //***
        // Action Set
        //   - Name becomes strValue
        // Called by
        //   - cpPerson(string)
        //   - frmPerson.cmdUse_Click(System.Object, System.EventArgs) Handles cmdUse.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230819 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230819 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate void cpDelegate();

    #endregion

    #region "Sub / Function"

    public static int Count()
      //***
      // Action
      //   - Return the number of cpPersons defined in the application
      // Called by
      //   - Dispose()
      //   - frmPerson.cmdUse_Click(System.Object, System.EventArgs) Handles cmdUse.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230819 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230819 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return mlngCount;
    }
    // int Count()

    public void Test()
      //***
      // Action
      //   - Starts / invokes the event "cpTesting"
      //   - The code of this event is defined outside this class
      // Called by
      //   - frmPerson.cmdUse_Click(System.Object, System.EventArgs) Handles cmdUse.Click
      // Calls
      //   - cpTesting()
      // Created
      //   - CopyPaste � 20230819 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230819 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (cpTesting == null)
      {
      }
      else
        // cpTesting <> null
      {
        cpTesting();
      }
      // cpTesting == null

    }
    // Test()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPerson

}
// CopyPaste.Learning