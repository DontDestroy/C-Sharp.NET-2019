//***
// Action
//   - Loop thru items in an array
// Created
//   - CopyPaste � 20220119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220119 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace ForLoop
{

  class cpForLoop
	{

    static void Main()
    //***
    // Action
    //   - 'arrstrFile' is filled with filenames of current directory
    //   - Loop thru arrstrFile (strFileName)
    //     - Show 'strFileName' at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - string[] System.IO.Directory.GetFiles(string)
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220119 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220119 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string[] arrstrFile = Directory.GetFiles(".");
      
      foreach (string strFilename in arrstrFile)
      {
        Console.WriteLine(strFilename);
      }
      // in arrstrFile
      
      Console.ReadLine();
    }
    // Main()

	}
  // cpForLoop

}
// ForLoop