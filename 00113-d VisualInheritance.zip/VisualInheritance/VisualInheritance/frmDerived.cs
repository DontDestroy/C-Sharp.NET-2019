//***
// Action
//   - Child form doing the conversion from Euro to Belgian Frank, to Dutch Gulden, to French Franc
// Created
//   - CopyPaste � 20240219 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240219 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.VDAB.Learning
{

  public class frmDerived: frmConversion
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtFrf;
    internal System.Windows.Forms.TextBox txtNlg;
    internal System.Windows.Forms.Label lblFrf;
    internal System.Windows.Forms.Label lblNlg;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDerived));
      this.txtFrf = new System.Windows.Forms.TextBox();
      this.txtNlg = new System.Windows.Forms.TextBox();
      this.lblFrf = new System.Windows.Forms.Label();
      this.lblNlg = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // txtFrf
      // 
      this.txtFrf.Location = new System.Drawing.Point(107, 152);
      this.txtFrf.Name = "txtFrf";
      this.txtFrf.ReadOnly = true;
      this.txtFrf.TabIndex = 13;
      this.txtFrf.Text = "";
      // 
      // txtNlg
      // 
      this.txtNlg.Location = new System.Drawing.Point(107, 120);
      this.txtNlg.Name = "txtNlg";
      this.txtNlg.ReadOnly = true;
      this.txtNlg.TabIndex = 12;
      this.txtNlg.Text = "";
      // 
      // lblFrf
      // 
      this.lblFrf.Location = new System.Drawing.Point(11, 152);
      this.lblFrf.Name = "lblFrf";
      this.lblFrf.Size = new System.Drawing.Size(88, 23);
      this.lblFrf.TabIndex = 11;
      this.lblFrf.Text = "&French Franc:";
      // 
      // lblNlg
      // 
      this.lblNlg.Location = new System.Drawing.Point(11, 120);
      this.lblNlg.Name = "lblNlg";
      this.lblNlg.Size = new System.Drawing.Size(88, 23);
      this.lblNlg.TabIndex = 10;
      this.lblNlg.Text = "&Dutch Gulden:";
      // 
      // frmDerived
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(218, 183);
      this.Controls.Add(this.txtFrf);
      this.Controls.Add(this.txtNlg);
      this.Controls.Add(this.lblFrf);
      this.Controls.Add(this.lblNlg);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDerived";
      this.Text = "Euro to Belgian Frank, Dutch Gulden and French Franc";
      this.Controls.SetChildIndex(this.lblNlg, 0);
      this.Controls.SetChildIndex(this.lblFrf, 0);
      this.Controls.SetChildIndex(this.txtNlg, 0);
      this.Controls.SetChildIndex(this.txtFrf, 0);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDerived'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240219 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240219 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDerived()
      //***
      // Action
      //   - Create instance of 'frmDerived'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240219 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240219 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDerived()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void cmdOK_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The actions on the parent form are executed
      //   - The entered value in textbox is converted to a number (if possible)
      //   - It is multiplied by 2.20371
      //   - It is rounded to two decimals
      //   - It is converted to a string
      //   - It is show in another textbox
      //   - It is multiplied by 6.55957
      //   - It is rounded to two decimals
      //   - It is converted to a string
      //   - It is show in another textbox
      //   - If something fails
      //     - A message is shown
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmConversion.cmdOK_Click(theSender, theEventArguments) Handles cmdOK.Click
      // Created
      //   - CopyPaste � 20240219 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240219 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
          
      try
      {
        base.cmdOK_Click(theSender, theEventArguments);
        txtNlg.Text = Math.Round(Convert.ToDecimal(txtEuro.Text) * 2.20371M, 2).ToString();
        txtFrf.Text = Math.Round(Convert.ToDecimal(txtEuro.Text) * 6.55957M, 2).ToString();
      }
      catch (Exception theException)
      {
      }
      finally
      {
      }

    }
    // cmdOK_Click(System.Object, System.EventArgs) Handles cmdOK.Click

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDerived
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240219 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240219 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDerived());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // CopyPaste.VDAB.Learning

}
// CopyPaste.VDAB.Learning