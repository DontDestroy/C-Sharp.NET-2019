//***
// Action
//   - Testroutine of cpAccount, cpiSaveMethod, cpSavingAccount and cpUsingAccount
// Created
//   - CopyPaste � 20240105 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240105 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

	public class cpProgram
	{
	
		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public static void Main()
			//***
			// Action
			//   - Create an owner
			//   - Create a correct Paper value
			//   - Create a correct Belgian saving account
			//   - Create two correct Belgian using accounts
			//   - Add all accounts to an array of accounts
			//   - Show the information of all accounts
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - cpClient(string, string)
			//   - cpPaperValue(Decimal, int, Decimal, Date, cpClient)
		  //   - cpSavingAccount(long, decimal, DateTime, decimal, cpClient)
			//   - cpUsingAccount(long, decimal, DateTime, decimal, cpClient)
			//   - string cpAccount.ToString()
			//   - string cpPaperValue.ToString()
			//   - string cpSavingAccount.ToString()
			//   - string cpUsingAccount.ToString()
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - Not all properties are tested in this routine
			//***
	{

			try
			{
				cpClient thecpOwner = new cpClient("Vincent", "Van De Walle");
				cpiSaveMethod[] arrcpSaving = new cpiSaveMethod[4];

        cpPaperValue thecpPaperValue = new cpPaperValue(1000, 5, 5, new DateTime(2005, 1, 1), thecpOwner);
				cpSavingAccount thecpSavingAccount01 = new cpSavingAccount(83179377453, 0, new DateTime(2004, 12, 19), 4.5M, thecpOwner);
				cpSavingAccount thecpSavingAccount02 = new cpSavingAccount(83179377554, 0, new DateTime(2004, 12, 20), 3.8M, thecpOwner);
				cpUsingAccount thecpUsingAccount = new cpUsingAccount(63154756360, 0, new DateTime(2004, 12, 18), -1000, thecpOwner);

				arrcpSaving[0] = thecpUsingAccount;
				arrcpSaving[1] = thecpSavingAccount01;
				arrcpSaving[2] = thecpSavingAccount02;
				arrcpSaving[3] = thecpPaperValue;

				thecpUsingAccount.Add(1000);
				thecpSavingAccount01.Add(125);
				thecpSavingAccount02.Add(250);

				foreach(cpiSaveMethod theSaving in arrcpSaving)
				{
					Console.WriteLine(theSaving.ToString());
					Console.WriteLine();
				}
				// in arrcpSaving

			}			
			catch (Exception theException)
			{
				Console.WriteLine(theException.Message);
			}
			finally
			{
				Console.ReadLine();
			}

		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.Learning