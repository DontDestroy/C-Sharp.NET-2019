﻿using System.Windows;

namespace Base_WPF
{

  public partial class App : Application
  {
  }
  // App

}
// Base_WPF