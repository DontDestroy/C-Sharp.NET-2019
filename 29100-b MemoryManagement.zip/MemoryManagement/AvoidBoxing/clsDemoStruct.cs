﻿//***
// Action
//   - Demo with a normal calculation and an in calculation
// Created
//   - CopyPaste – 20260614 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260614 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections;
using System.Collections.Generic;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpDemoStruct
  {

    #region "Constructors / Destructors"

    public cpDemoStruct()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260614 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpDemoStruct()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [BenchmarkAttribute]
    public float DemoDistance()
    //***
    // Action
    //   - Define and create two cpVector3D
    //   - Calculate the distance of the two cpVector3D
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - cpVector3D(float, float, float)
    //   - float cpVector3D.DemoDistance(cpVector3D, cpVector3D)
    // Created
    //   - CopyPaste – 20260614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpVector3D cpFirst = new cpVector3D(1, 1, 1);
      cpVector3D cpSecond = new cpVector3D(2, 2, 2);

      return DemoDistance(cpFirst, cpSecond);
    }
    // float DemoDistance()

    public float DemoDistance(cpVector3D cpFirst, cpVector3D cpSecond)
    //***
    // Action
    //   - Define and create a cpVector3D
    //   - Calculate the distance
    // Called by    
    //   - cpProgram.Main()
    //   - float DemoDistance()
    // Calls
    //   - cpVector3D.Distance(cpVector3D, cpVector3D)
    // Created
    //   - CopyPaste – 20260614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      float distance;

      distance = cpVector3D.Distance(cpFirst, cpSecond);
      return distance;
    }
    // float DemoDistance(cpVector3D, cpVector3D)

    [BenchmarkAttribute]
    public float DemoDistanceIn()
    //***
    // Action
    //   - Define and create a two cpVector3D
    //   - Calculate the distance of the two cpVector3D
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - cpVector3D(float, float, float)
    //   - float cpVector3D.DemoDistanceIn(cpVector3D, cpVector3D)
    // Created
    //   - CopyPaste – 20260614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpVector3D cpFirst = new cpVector3D(1, 1, 1);
      cpVector3D cpSecond = new cpVector3D(2, 2, 2);

      return DemoDistanceIn(in cpFirst, in cpSecond);
    }
    // float DemoDistanceIn()

    [BenchmarkAttribute]
    public float DemoDistanceInMore()
    //***
    // Action
    //   - Define and create ten cpVector3D
    //   - Calculate the distance of the ten cpVector3D compared with the first
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - cpVector3D(float, float, float)
    //   - float cpVector3D.DemoDistanceIn(cpVector3D, cpVector3D)
    // Created
    //   - CopyPaste – 20260614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpVector3D cpFirst = new cpVector3D(1, 1, 1);
      cpVector3D cpSecond = new cpVector3D(2, 2, 2);
      cpVector3D cpThird = new cpVector3D(3, 3, 3);
      cpVector3D cpFourth = new cpVector3D(4, 4, 4);

      return DemoDistanceIn(cpFirst, cpSecond) + DemoDistanceIn(cpFirst, cpThird) + DemoDistanceIn(cpFirst, cpFourth);
    }
    // float DemoDistanceMore()

    [BenchmarkAttribute]
    public float DemoDistanceMore()
    //***
    // Action
    //   - Define and create ten cpVector3D
    //   - Calculate the distance of the ten cpVector3D compared with the first
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - cpVector3D(float, float, float)
    //   - float cpVector3D.DemoDistance(cpVector3D, cpVector3D)
    // Created
    //   - CopyPaste – 20260614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpVector3D cpFirst = new cpVector3D(1, 1, 1);
      cpVector3D cpSecond = new cpVector3D(2, 2, 2);
      cpVector3D cpThird = new cpVector3D(3, 3, 3);
      cpVector3D cpFourth = new cpVector3D(4, 4, 4);

      return DemoDistance(cpFirst, cpSecond) + DemoDistance(cpFirst, cpThird) + DemoDistance(cpFirst, cpFourth);
    }
    // float DemoDistanceMore()

    public float DemoDistanceIn(in cpVector3D cpFirst, in cpVector3D cpSecond)
    //***
    //   - Define and create a cpVector3D
    //   - Calculate the distance
    // Called by    
    //   - cpProgram.Main()
    //   - float DemoDistanceIn()
    // Calls
    //   - cpVector3D.DistanceIn(cpVector3D, cpVector3D)
    // Created
    //   - CopyPaste – 20260614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      float distance;

      distance = cpVector3D.DistanceIn(in cpFirst, in cpSecond);
      return distance;
    }
    // float DemoDistanceIn(cpVector3D, cpVector3D)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDemoStruct

}
// CopyPaste.Learning