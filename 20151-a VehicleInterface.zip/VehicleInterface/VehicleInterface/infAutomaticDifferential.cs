﻿//***
// Action
//   - Implementation of a compare of vehicles
// Created
//   - CopyPaste – 20260129 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260129 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public interface cpiAutomaticDifferential
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    bool AutomaticDifferential { get; set; }
    
    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpiCompareVehicle

}
// CopyPaste.Learning