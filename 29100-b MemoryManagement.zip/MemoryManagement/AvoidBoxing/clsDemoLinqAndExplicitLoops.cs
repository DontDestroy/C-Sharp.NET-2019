﻿//***
// Action
//   - Demo with a normal list and Linq
// Created
//   - CopyPaste – 20260614 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260614 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpDemoLinqAndExplicitLoops
  {

    #region "Constructors / Destructors"

    public cpDemoLinqAndExplicitLoops()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260614 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpDemoLinqAndExplicitLoops()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    int intLength = 1000;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [BenchmarkAttribute]
    public List<int> DemoLinq()
    //***
    // Action
    //   - Create a list of 1000 elements
    //   - Multiply the number by 2
    //   - Filter the number if it is divisible by 3
    //     --> 0, 6, 12, ..., 1998
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      List<int> lstData =
        Enumerable.Range(0, intLength)
        .Select(aNumber => aNumber * 2)
        .Where(aNumber => aNumber % 3 == 0)
        .ToList();

      return lstData;
    }
    // List<int> DemoLinq()

    [BenchmarkAttribute]
    public List<int> DemoList()
    //***
    // Action
    //   -
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intDouble;
      List<int> lstData = new List<int>(intLength);

      for (int aNumber = 0; aNumber < intLength; aNumber++)
      {
        intDouble = aNumber * 2;

        if (intDouble % 3 == 0)
        {
          lstData.Add(intDouble);
        }
        // intDouble % 3 == 0

      }
      // aNumber = intLength

      return lstData;
    }
    // List<int>DemoList()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDemoLinqAndExplicitLoops

}
// CopyPaste.Learning