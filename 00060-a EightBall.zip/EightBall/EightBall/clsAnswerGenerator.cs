//***
// Action
//   - Generate a random answer
// Created
//   - CopyPaste � 20220813 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220813 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace EightBall
{

  public class cpAnswerGenerator
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string[] arrAnswers = new string[]
    {
        "Ask again later",
        "Can not predict now",
        "Without a doubt", 
        "Is decidely so",
        "Concentrate and ask again",
        "My sources say no",
        "Yes, definitely",
        "Don't count on it",
        "Signs point to yes",
        "Better not tell you now",
        "Looks not so good",
        "Most likely",
        "Very doubtful",
        "As I see it, yes",
        "My reply is no",
        "It is certain",
        "Yes",
        "You may rely on it",
        "Looks good",
        "Reply hazy try again"
    };

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string GetRandomAnswer(string strQuestion)
    //***
    // Action
    //   - Get randomly an answer out of arrAnswers
    // Called by
    //   -wpfEightBallAnswer.cmdAnswer_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAnswer.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220813 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220813 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Random aRandom = new Random();

      return arrAnswers[aRandom.Next(0, arrAnswers.Length)];
    }
    // string GetRandomAnswer(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpAnswerGenerator

}
// EightBall