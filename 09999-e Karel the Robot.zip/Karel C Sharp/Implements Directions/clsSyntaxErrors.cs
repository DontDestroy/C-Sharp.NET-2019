﻿//***
// Action
//   - Create a class cpSyntaxErrors that uses the interface Directions
// Created
//   - CopyPaste – 20251011 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251011 – VVDW
// Proposal (To Do)
//   - This is put into comments because it contains errors (on purpose)
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpSyntaxErrors : Directions
	{

		#region "Constructors / Destructors"

		public cpSyntaxErrors()
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Reset the world
		//   - Build the world according to the One Wall Segment specifications
		//   - Make the world visible
		//   - Karel becomes a green robot starting at position (1, 1), looking to the right with no beepers in the bag
		//   - Karel will move one forward
		//   - Karel will move one forward
		//   - Karel will pick the beeper at that position
		//   - Karel will turn right
		//   - Karel is switched off
		// Called by
		//   - cpProgram.SyntaxErrors()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251011 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251011 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - This code is full of syntax errors and will never work
		//***
		// World.reset(); // Instruction is outside the code block
		{
			// World.readWorld("Worlds\\01.01 The Robot World.kwld");
			// World.setVisible(true);
			// UrRobot karel = new UrRobot(1, 1, East, 0);
			// move(); // Not addressed to any robot
			// karel.move();
			// karel.pickBeeper; // No () are placed after the instruction
			// karel.turnRight() // Missing a semicolon ;
			// karel.turnOff();
		}
		// ; // A wrongly places semicolon 
		// cpSyntaxErrors()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// cpSyntaxErrors

}
// cpKarelTheRobot