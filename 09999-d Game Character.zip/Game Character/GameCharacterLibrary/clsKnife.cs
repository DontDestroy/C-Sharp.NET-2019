﻿//***
// Action
//   - Implementation of a cpWeapon
//		 - The way a knife can be used
// Created
//   - CopyPaste – 20240806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240806 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Weapon.Library
{

	public class cpKnife : cpiWeapon
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpKnife
		/// </summary>
		public cpKnife()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - CopyPaste.Game.Character.Library.cpQueen()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpKnife()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a knife is used to fight
		/// </summary>
		public void UseWeapon()
		//***
		// Action
		//   - Define how a Knife is used in a fight
		// Called by
		//   - cpKing() (indirectly, thru delegate)
		//   - cpKnight() (indirectly, thru delegate)
		//   - cpQueen() (indirectly, thru delegate)
		//   - cpTroll() (indirectly, thru delegate)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Cutting with a knife");
		}
		// UseWeapon()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpKnife

}
// CopyPaste.Game.Weapon.Library