//***
// Action
//   - Testroutine for cpEmployee
// Created
//   - CopyPaste � 20220308 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220308 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Toolkit;
using System;

namespace Properties
{

  class cpProgram
	{

    static void Main()
      //***
      // Action
      //   - Create an instance of cpEmployee
      //   - Give a Name
      //   - Define the wage constants
      //   - Show the values of the properties
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpEmployee.Name(string) (Set)
      //   - cpEmployee.New()
      //   - cpEmployee.theWageConstant() (Set)
      //   - cpEmployee.Wage() (Set)
      //   - decimal cpEmployee.Wage() (Get)
      //   - string cpEmployee.Name (Get)
      //   - WageConstant cpEmployee.theWageConstant() (Get)
      // Created
      //   - CopyPaste � 20220308 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220308 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      
      cpEmployee thecpEmployee = new cpEmployee();
      
      thecpEmployee.Name = "Vincent";
      thecpEmployee.theWageConstant = WageConstant.Rate;
      thecpEmployee.Wage = Convert.ToDecimal(75.0);
      thecpEmployee.theWageConstant = WageConstant.OverTime;
      thecpEmployee.Wage = Convert.ToDecimal(75.0 * 1.5);
      thecpEmployee.theWageConstant = WageConstant.Weekend;
      thecpEmployee.Wage = Convert.ToDecimal(75.0 * 1.75);
      thecpEmployee.theWageConstant = WageConstant.WeekendOverTime;
      thecpEmployee.Wage = Convert.ToDecimal(75.0 * 2.25);

      Console.WriteLine("Name: " + thecpEmployee.Name);
      thecpEmployee.theWageConstant = WageConstant.Rate;
      Console.WriteLine("Rate: " + thecpEmployee.Wage);
      thecpEmployee.theWageConstant = WageConstant.OverTime;
      Console.WriteLine("OverTime: " + thecpEmployee.Wage);
      thecpEmployee.theWageConstant = WageConstant.Weekend;
      Console.WriteLine("Weekend: " + thecpEmployee.Wage);
      thecpEmployee.theWageConstant = WageConstant.WeekendOverTime;
      Console.WriteLine("Weekend OverTime: " + thecpEmployee.Wage);
      thecpEmployee = null;
      
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

	}
  // cpProgram

}
// Properties