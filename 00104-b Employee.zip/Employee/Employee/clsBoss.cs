//***
// Action
//   - Definition of a cpBoss
// Created
//   - CopyPaste � 20230817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230817 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Company
{

  public class cpBoss : cpEmployee
  {

    #region "Constructors / Destructors"

    public cpBoss(string strFirstName, string strLastName, decimal decSalary) : base(strFirstName, strLastName)
      //***
      // Action
      //   - Creates a boss with strFirstName and strLastName
      //   - Set the weeksalary to decSalary
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee(string, string)
      //   - WeeklySalary(decimal) (Set)
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      WeeklySalary = decSalary;
    }
    // cpBoss(string, string, decimal)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private decimal mdecSalary;

    #endregion

    #region "Properties"

    public decimal WeeklySalary
    {

      get
        //***
        // Action
        //   - Return the week salary
        // Called by
        //   - decimal Earnings()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecSalary;
      }
      // decimal WeeklySalary (Get)

      set
        //***
        // Action
        //   - Set the week salary to value
        //   - If weeksalary is negative, 0 becomes the value
        // Called by
        //   - cpBoss(string, string, decimal)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value > 0)
        {
          mdecSalary = value;
        }
        else
          // value <= 0
        {
          mdecSalary = 0;
        }
        // value > 0

      }
      // WeeklySalary(decimal) (Set)

    }
    // decimal WeeklySalary

    #endregion

    #region "Methods"

    #region "Overrides"

    public override decimal Earnings()
      //***
      // Action
      //   - Return the week salary
      // Called by
      //   - 
      // Calls
      //   - decimal WeekSalary (Get)
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return WeeklySalary;
    }
    // decimal Earnings

    public override string ToString()
      //***
      // Action
      //   - Return description of a cpBoss
      // Called by
      //   - 
      // Calls
      //   - string cpEmployee.ToString()
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "cpBoss: " + base.ToString();
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBoss

}
// CopyPaste.Learning.Company