﻿//***
// Action
//   - Implementation of a cpQueen
//     - Inherits from cpGameCharacter
//   - The way a cpQueen can fight given thru a delegate and an event
// Created
//   - CopyPaste – 20240806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240806 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Weapon.Library;

namespace CopyPaste.Game.Character.Library
{

	public class cpQueen : cpGameCharacter
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpQueen
		/// </summary>
		public cpQueen() : base()
		//***
		// Action
		//   - Basic constructor
		//   - Define how a cpQueen fights (with a weapon)
		// Called by
		//   - CopyPaste.Game.Character.Test.cpProgram.Main()
		// Calls
		//   - CopyPaste.Game.Weapon.Library.cpKnife()
		//   - cpGameCharacter()
		//   - cpGameCharacter.HowToFight(cpiWeapon) (Set)
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			HowToFight = new cpKnife();
		}
		// cpQueen()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// cpQueen

}
// CopyPaste.Game.Character.Library