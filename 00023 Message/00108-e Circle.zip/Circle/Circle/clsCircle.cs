//***
// Action
//   - Definition of a cpCircle using a cpPoint as middle
// Created
//   - CopyPaste � 20231229 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231229 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Math
{

	public class cpCircle : cpPoint
	{

		#region "Constructors / Destructors"

		public cpCircle() : base()
			//***
			// Action
			//   - Default constructor
			//   - Sets X and Y property to 0 thru the base class
			//   - Creates the Center as a point
			//   - Sets radius property to 0
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - Center(cpPoint) (Set)
			//   - Radius(double) (Set)
			// Created
			//   - CopyPaste � 20231229 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231229 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Center = new cpPoint(X, Y);
			Radius = 0;
		}
		// cpCircle()

		public cpCircle(int lngX, int lngY, double dblRadius) : base(lngX, lngY)
			//***
			// Action
			//   - Constructor with 3 arguments
			//   - Sets X and Y property to the given arguments thru the base class
			//   - Creates the Center as a point
			//   - Set Radius to the given argument
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - Center(cpPoint) (Set)
			//   - Radius(double) (Set)
			// Created
			//   - CopyPaste � 20231229 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231229 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Center = new cpPoint(X, Y);
			Radius = dblRadius;
		}
		// cpCircle(int, int, double)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private cpPoint mcpCenter;
		private double mdblRadius; 

		#endregion

		#region "Properties"

		public cpPoint Center
		{

			get
				//***
				// Action Get
				//   - Returns mcpCenter
				// Called by
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231229 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231229 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
	    {
				return mcpCenter;
			}
			// cpPoint Center (Get)

			set
				//***
				// Action Set
				//   - mcpCenter becomes value
				// Called by
				//   - cpCircle()
				//   - cpCircle(int, int, double)
				// Calls
				//   - int cpPoint.X (Get)
				//   - int cpPoint.Y (Get)
				//   - X(int) (Set)
				//   - Y(int) (Set)
				// Created
				//   - CopyPaste � 20231229 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231229 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
    	{
				mcpCenter = value;
				X = value.X;
				Y = value.Y;
			}
			// Center(cpPoint) (Set)

		}
		// cpPoint Center

		public double Radius
		{

			get
				//***
				// Action Get
				//   - Returns mdblRadius
				// Called by
				//   - cpProgram.Main()
				//   - double Area()
				//   - double Diameter()
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231229 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231229 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mdblRadius;
			}
			// double Radius (Get)

			set
				//***
				// Action Set
				//   - If value is bigger than zero
				//     - mdblRadius becomes value
				//   - If not
				//     - mdblRadius becomes zero
				// Called by
				//   - cpCircle()
				//   - cpCircle(int, int, double)
				//   - cpProgram.Main()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231229 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231229 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{

				if (value > 0)
				{
					mdblRadius = value;
				}
				else
				{
					mdblRadius = 0;
				}

			}
			// Radius(double) (Set)

		}
		// double Radius

		public override int X
		{

			get
				//***
				// Action Get
				//   - Returns base.X
				// Called by
				//   - 
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231229 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231229 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
	    {
				return base.X;
			}
			// int X (Get)

			set
				//***
				// Action Set
				//   - MyBase.X becomes lngValue
				//   - Center.X becomes lngValue when Center exists
				// Called by
				//   - 
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231229 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231229 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				base.X = value;

				if (Center == null)
				{
				}
				else
					// (Center <> null)
				{
					Center.X = value;
				}
				// (Center = null)

			}
			// X(int) (Set)

		}
		// int X


		public override int Y
		{

			get
				//***
				// Action Get
				//   - Returns base.Y
				// Called by
				//   - 
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231229 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231229 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return base.Y;
			}
			// int Y (Get)

			set
				//***
				// Action Set
				//   - MyBase.Y becomes lngValue
				//   - Center.Y becomes lngValue when Center exists
				// Called by
				//   - 
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231229 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231229 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				base.Y = value;

				if (Center == null)
				{
				}
				else
					// (Center <> null)
				{
					Center.Y = value;
				}
				// (Center = null)

			}
			// Y(int) (Set)

		}
		// int Y

		#endregion

		#region "Methods"

		#region "Overrides"

		public override string ToString()
			//***
			// Action
			//   - Genererates the items shown when asking ToString() using the ToString of the base class
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - cpPoint Center (Get)
			//   - double Radius (Get)
			// Created
			//   - CopyPaste � 20231229 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231229 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			return "Center = " + Center.ToString() + "; Radius = " + Radius;
		}

		#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public double Area()
			//***
			// Action
			//   - Calculates the area of a cpCircle
			// Called by
			//   - cpProgarm.Main()
			// Calls
			//   - double Radius (Get)
			// Created
			//   - CopyPaste � 20231229 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231229 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			return System.Math.PI * Radius * Radius;
		}
		// double Area()

		public double Circumference()
			//***
			// Action
			//   - Calculates the circumference of a cpCircle
			// Called by
			//   - cpProgarm.Main()
			// Calls
			//   - double Diameter()
			// Created
			//   - CopyPaste � 20231229 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231229 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			return System.Math.PI * Diameter();
		}
		// double Circumference()

		public double Diameter()
			//***
			// Action
			//   - Calculates the Diameter of a cpCircle
			// Called by
			//   - Circumference() As Double
			//   - cpProgram.Main()
			// Calls
			//   - double Radius (Get)
			// Created
			//   - CopyPaste � 20231229 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231229 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			return Radius * 2;
		}
		// double Diameter()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpCircle

}
// CopyPaste.Learning.Math