﻿//***
// Action
//   - Definition of a cpCube
// Created
//   - CopyPaste – 20251218 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251218 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpPyramid
  {

    #region "Constructors / Destructors"

    public cpPyramid(double dblBaseLengthSize, double dblBaseWidthSize, double dblHeightSize)
    //***
    // Action
    //   - Basic constructor of cpPyramid with three size parameters
    //     - Base length size, base width size and height size
    // Called by
    //   - cpProgram().Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251218 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251218 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      BaseLengthSize = dblBaseLengthSize;
      BaseWidthSize = dblBaseWidthSize;
      HeightSize = dblHeightSize;
    }
    // cpPyramid()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public double BaseLengthSize { get; private set; }
    // cpLocalFunction().CalculateObjectVolume(System.Object)

    public double BaseWidthSize { get; private set; }
    // cpLocalFunction().CalculateObjectVolume(System.Object)

    public double HeightSize { get; private set; }
    // cpLocalFunction().CalculateObjectVolume(System.Object)

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpPyramid

}
// CopyPaste.Learning