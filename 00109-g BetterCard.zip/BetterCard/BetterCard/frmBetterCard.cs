//***
// Action
//   - Implementation of a visualisation of a card, just to test cpctlCard
// Created
//   - CopyPaste � 20240402 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240402 � VVDW
// Proposal (To Do)
//   - The references to CopyPaste.CardGames are not documented
//   - CopyPaste.CardGames is considered as a black box
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.CardGames
{

  public class frmBetterCard: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.ListBox lstFaceValue;
    private CopyPaste.CardGames.cpctlCard thecpctlCard;
    internal System.Windows.Forms.ListBox lstSuit;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBetterCard));
      this.lstFaceValue = new System.Windows.Forms.ListBox();
      this.lstSuit = new System.Windows.Forms.ListBox();
      this.thecpctlCard = new CopyPaste.CardGames.cpctlCard();
      this.SuspendLayout();
      // 
      // lstFaceValue
      // 
      this.lstFaceValue.Location = new System.Drawing.Point(86, 87);
      this.lstFaceValue.Name = "lstFaceValue";
      this.lstFaceValue.Size = new System.Drawing.Size(120, 173);
      this.lstFaceValue.TabIndex = 4;
      this.lstFaceValue.SelectedIndexChanged += new System.EventHandler(this.lstFaceValue_SelectedIndexChanged);
      // 
      // lstSuit
      // 
      this.lstSuit.Location = new System.Drawing.Point(86, 7);
      this.lstSuit.Name = "lstSuit";
      this.lstSuit.Size = new System.Drawing.Size(120, 69);
      this.lstSuit.TabIndex = 3;
      this.lstSuit.SelectedIndexChanged += new System.EventHandler(this.lstSuit_SelectedIndexChanged);
      // 
      // thecpctlCard
      // 
      this.thecpctlCard.BackColor = System.Drawing.Color.White;
      this.thecpctlCard.FaceUp = true;
      this.thecpctlCard.FaceValue = CopyPaste.CardGames.cpctlCard.cpFaceValue.Ace;
      this.thecpctlCard.Location = new System.Drawing.Point(16, 8);
      this.thecpctlCard.Name = "thecpctlCard";
      this.thecpctlCard.Size = new System.Drawing.Size(60, 75);
      this.thecpctlCard.Suit = CopyPaste.CardGames.cpctlCard.cpSuit.Diamonds;
      this.thecpctlCard.TabIndex = 5;
      // 
      // frmBetterCard
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.Add(this.thecpctlCard);
      this.Controls.Add(this.lstFaceValue);
      this.Controls.Add(this.lstSuit);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBetterCard";
      this.Text = "Test BetterCard";
      this.Load += new System.EventHandler(this.frmBetterCard_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBetterCard'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBetterCard()
      //***
      // Action
      //   - Create instance of 'frmBetterCard'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmBetterCard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmBetterCard_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Fill the list of suit with the possible suits
      //   - Fill the list of face values with the possible face values
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      // lstSuit.DataSource = Enum.GetValues(System.Type.GetType("BetterCard.CopyPaste.CardGames.cpSuit"));
      // Above is correct when cpSuit is not defined in cpctlCard, but in the namespace

      lstSuit.DataSource = Enum.GetValues(cpctlCard.cpSuit.Clubs.GetType());
      lstFaceValue.DataSource = Enum.GetValues(cpctlCard.cpFaceValue.Ace.GetType());
    }
    // frmBetterCard_Load(System.Object, System.EventArgs) Handles this.Load
    
    private void lstFaceValue_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the selected face value on the card
      // Called by
      //   - User action (Selecting a face value)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      thecpctlCard.FaceValue = (cpctlCard.cpFaceValue)lstFaceValue.SelectedItem;
    }
    // lstFaceValue_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstFaceValue.SelectedIndexChanged

    private void lstSuit_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the selected suit on the card
      // Called by
      //   - User action (Selecting a suit)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      thecpctlCard.Suit = (cpctlCard.cpSuit)lstSuit.SelectedItem;
    }
    // lstSuit_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstSuit.SelectedIndexChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmBetterCard
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmBetterCard());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBetterCard

}
// CopyPaste.CardGames