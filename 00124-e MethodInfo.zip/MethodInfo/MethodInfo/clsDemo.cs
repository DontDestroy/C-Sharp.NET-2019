//***
// Action
//   - Implementation of cpDemo
// Created
//   - CopyPaste � 20240708 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240708 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpDemo
  {

    #region "Constructors / Destructors"

    public cpDemo()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240708 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240708 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDemo()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int AddTwoIntegers(int lngFirst, int lngSecond)
      //***
      // Action
      //   - Add Two Integers
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240708 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240708 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return lngFirst + lngSecond;
    }
    // int AddTwoIntegers(int, int)
		
    public void ShowMessage(string strMessage)
      //***
      // Action
      //   - Show a message on the console
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240708 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240708 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Message: " + strMessage);
    }
    // ShowMessage(string)

    public void ShowThreeDoubles(double dblFirst, double dblSecond, double dblThird)
      //***
      // Action
      //   - Show three doubles on the console
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240708 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240708 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine(dblFirst + " - " + dblSecond + " - " + dblThird);
    }
    // ShowThreeDoubles(double, double, double)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx