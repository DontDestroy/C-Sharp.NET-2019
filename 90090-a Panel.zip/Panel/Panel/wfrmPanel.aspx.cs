﻿//***
// Action
//   - Demo of a panel that contains the alphabet buttons
// Created
//   - CopyPaste – 20260715 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260715 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmPanel : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cmdHere.Click += new System.EventHandler(this.cmdHere_Click);
      this.ID = "wfrmPanel";
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when initializing the page
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260715 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260715 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdHere_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Get the country you are now from the application settings (Web.config)
    //   - Show the found country
    //   - Compare the selected country with the found country
    //   - If equal
    //     - Show "Welcome countrymen"
    //   - If not
    //     - Show "welcome foreigner"
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260715 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260715 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCountry;

      try
      {
        strCountry = System.Configuration.ConfigurationSettings.AppSettings["theCountry"];

        if (lstCountries.SelectedIndex == -1)
        {
          lblStatus.Text = "You have to select a country";
        }
        else
        // lstCountries.SelectedIndex <> -1
        {
          lblSelected.Text = lstCountries.SelectedItem.Text;

          if (lstCountries.SelectedItem.Text == strCountry)
          {
            lblStatus.Text = "Welcome countrymen";
          }
          else
          // lstCountries.SelectedItem.Text <> strCountry 
          {
            lblStatus.Text = "Welcome foreigner";
          }
          // lstCountries.SelectedItem.Text = strCountry 
        
        }
        // lstCountries.SelectedIndex == -1

      }
      catch
      {
        lblStatus.Text = "You have to select a country";
      }

    }
    // cmdHere_Click(System.Object, System.EventArgs) Handles cmdHere.Click

    protected void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define the first character "A"
    //   - Clear all controls from a panel
    //   - Loop till character is after "Z"
    //     - Add a new button
    //     - Set the character a text of the button
    //     - Add the button to the panel
    //     - Add a handler to the button
    //     - Get the next character
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - ClickLetter(System.Object, System.EventArgs)
    // Created
    //   - CopyPaste – 20260715 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260715 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      char theChar = 'A';

      panAlphabet.Controls.Clear();

      while (theChar <= 'Z')
      {
        Button theButton = new Button();

        theButton.Text = theChar.ToString();
        panAlphabet.Controls.Add(theButton);
        theButton.Click += new EventHandler(ClickLetter);
        theChar = Convert.ToChar(Convert.ToInt32(theChar) + 1);
      }
      // theChar <= 'Z'

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    #region "Event"

    private void ClickLetter(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define and set the character of the button that was clicked
    //   - Clear the items of the list
    //   - Show the clicked letter
    //   - Get the path of the countries from the configuration settings (Web.config)
    //   - Get the country from the configuration settings (Web.config)
    //   - Set the text of the found country
    //   - Define and initialize a stream reader (the list of countries)
    //   - Read the first (next) line into a variable
    //   - Show the path
    //   - While there was a line read
    //     - If the first character is equal the clicked letter
    //       - Add the item to the list
    //       - Increment the counter
    //     - If not
    //       - Do nothing
    //     - Read the next line
    //   - Show the number of found countries
    //   - Close the stream reader
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260715 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260715 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      char chrFind = ((Button)theSender).Text[0];
      decimal decCounter = 0M;
      string strCountryPath;
      string strCountry;

      lstCountries.Items.Clear();
      lblClickLetter.Text = chrFind.ToString();
      strCountryPath = System.Configuration.ConfigurationSettings.AppSettings["CountriesPath"];
      strCountry = System.Configuration.ConfigurationSettings.AppSettings["theCountry"];
      lblCountry.Text = strCountry;

      System.IO.StreamReader strReader = new System.IO.StreamReader(Server.MapPath(strCountryPath), System.Text.Encoding.Default);
      string strLine = strReader.ReadLine();

      lblPath.Text = strCountryPath;

      while (strLine != null)
      {

        if (strLine[0] == chrFind)
        {
          lstCountries.Items.Add(strLine);
          decCounter++;
        }
        else
        // strLine[0] <> chrFind
        {
        }
        // strLine[0] = chrFind

        strLine = strReader.ReadLine();
      }
      // strLine <> null

      lblCountCountries.Text = decCounter.ToString();
      strReader.Close();
    }
    // ClickLetter(System.Object, System.EventArgs)

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmPanel

}
// CopyPaste.Learning