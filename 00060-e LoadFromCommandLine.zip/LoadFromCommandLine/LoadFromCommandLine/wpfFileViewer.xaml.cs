//***
// Action
//   - Screen where the content of cpTextFile.txt is shown
// Created
//   - CopyPaste � 20220815 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220815 � VVDW
// Proposal (To Do)
//   -
//***

using System.IO;
using System.Windows;

namespace LoadFromCommandLine
{
  public partial class wpfFileViewer : Window
  {

    #region "Constructors / Destructors"

    public wpfFileViewer()
    //***
    // Action
    //   - Constructor of wpfFileViewer
    // Called by
    //   - cpStartup.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220815 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220815 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      InitializeComponent();
    }
    // wpfFileViewer()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void LoadFile(string strPath)
    //***
    // Action
    //   - Read all text from a certain file
    //   - Place that into the content of the Window
    //   - Place the value strPath as text of the Window
    // Called by
    //   - cpStartup.ApplicationStartup(System.Object, System.Windows.StartupEventArgs)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220815 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220815 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      this.Content = File.ReadAllText(strPath);
      this.Title = strPath;
    }
    // LoadFile(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfFileViewer

}
// LoadFromCommandLine 