//***
// Action
//   - Implementation of a cpManager
//   - Inherits from cpOfficeWorker
// Created
//   - CopyPaste � 20240410 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240410 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Company
{

  namespace Personel
  {

    public class cpManager : cpOfficeWorker
    {

      #region "Constructors / Destructors"

      public cpManager(string strName) : base(strName)
        //***
        // Action
        //   - Constructor with Name
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - cpOfficeWorker(string)
        // Created
        //   - CopyPaste � 20240410 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240410 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
      }
      // cpManager(string)
   
      #endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      #region "Fields"

      private decimal mdecBonus = 5500M;

      #endregion

      #region "Properties"
      
      public override decimal Amount
      {

        get
          //***
          // Action Get
          //   - Returns the amount of an officeworker with an extra bonus
          // Called by
          //   - cpProgram.Main()
          // Calls
          //   - decimal cpOfficeWorker.Amount (Get)
          // Created
          //   - CopyPaste � 20240410 � VVDW
          // Changed
          //   - CopyPaste � yyyymmdd � VVDW � What changed
          // Tested
          //   - CopyPaste � 20240410 � VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {
          return base.Amount + mdecBonus;
        }
        // decimal Amount (Get)

      }
      // decimal Amount

      #endregion

      //#region "Methods"

      //#region "Overrides"
      //#endregion

      //#region "Controls"
      //#endregion

      //#region "Functionality"

      //#region "Event"
      //#endregion

      //#region "Sub / Function"
      //#endregion

      //#endregion

      //#endregion

      //#region "Not used"
      //#endregion

    }
    // cpManager

  }
  // Personel

}
// Company