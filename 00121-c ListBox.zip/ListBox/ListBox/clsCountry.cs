﻿//***
// Action
//   - Implementation of cpCountry
// Created
//   - CopyPaste – 20240628 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240628 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpCountry
  {

    #region "Constructors / Destructors"

    public cpCountry(string strName, string strCapital, int lngSize)
      //***
      // Action
      //   - Constructor with Name, Capital and Size
      // Called by
      //   - frmListBox()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20240628 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20240628 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrName = strName;
      mstrCapital = strCapital;
      mlngSize = lngSize;
    }
    // cpCountry(string, string, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mlngSize;
    private string mstrCapital;
    private string mstrName;

    #endregion

    #region "Properties"

    public string Capital
    {

      get
        //***
        // Action Get
        //   - Returns mstrCapital
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20240628 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20240628 – VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrCapital;
      }
      // string Capital (Get)

    }
    // string Capital

    public string Name
    {

      get
        //***
        // Action Get
        //   - Returns mstrName
        // Called by
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20240628 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20240628 – VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

    }
    // string Name

    public int Size
    {

      get
        //***
        // Action Get
        //   - Returns mlngSize
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20240628 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20240628 – VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngSize;
      }
      // int Size (Get)

    }
    // int Size

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Returns name of cpCountry
      // Called by
      //   - 
      // Calls
      //   - Name() As String (Get)
      // Created
      //   - CopyPaste – 20240628 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20240628 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Name;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
		//#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCountry

}
// CopyPaste.Learning