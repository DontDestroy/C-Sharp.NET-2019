﻿//***
// Action
//   - A definition of a ShortCircuit
// Created
//   - CopyPaste – 20251018 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251018 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpShortCircuit : kareltherobot.Robot
	{

		#region "Constructors / Destructors"

		public cpShortCircuit(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpCopyPasteRobot starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpProgram.ShortCircuit()
    //   - cpShortCircuit(int, int, Directions.Direction, int) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpShortCircuit(int, int, Directions.Direction, int, Color) 

    public cpShortCircuit(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpCopyPasteRobot starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpShortCircuit(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpShortCircuit(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private bool LeftIsClear()
    //***
    // Action
    //   - Turn left
    //   - Remember if front is clear into blnResult
    //   - Turn right
    //   - Return blnResult
    // Called by
    //   - NextToABeeperAndLeftIsBlocked01()
    //   - NextToABeeperAndLeftIsBlocked02()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251018 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251018 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnResult;

			turnLeft();
			blnResult = frontIsClear();
      turnLeft();
      turnLeft();
      turnLeft();

			return blnResult;
		}
    // LeftIsClear()

    public bool NextToABeeperAndLeftIsBlocked01()
    //***
    // Action
    //   - Robot will test if next to  beeper and left is blocked
    //   - If so
    //     - Return true 
    //   - If not
		//     - Return false
    // Called by
    //   - 
    // Calls
    //   - LeftIsClear()
    // Created
    //   - CopyPaste – 20251018 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251018 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnReturn;

      if (nextToABeeper())
      {

        if (LeftIsClear())
        {
          blnReturn = false;
        }
        else
        // Not LeftIsClear()
        {
          blnReturn = true;
        }
        // LeftIsClear()

      }
      else
      // Not nextToABeeper()
      {
        blnReturn = false;
      }
      // nextToABeeper()

      return blnReturn;
    }
    // NextToABeeperAndLeftIsBlocked01()

    public bool NextToABeeperAndLeftIsBlocked02()
    //***
    // Action
    //   - Robot will test if next to  beeper and left is blocked
    //   - If so
    //     - Return true 
    //   - If not
    //     - Return false
    // Called by
    //   - 
    // Calls
    //   - LeftIsClear()
    // Created
    //   - CopyPaste – 20251018 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251018 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnReturn;

      if (nextToABeeper())
      {
        blnReturn = !LeftIsClear();
      }
      else
      // nextToABeeper()
      {
        blnReturn = false;
      }
      // Not nextToABeeper()

      return blnReturn;
    }
    // NextToABeeperAndLeftIsBlocked02()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpShortCircuit

}
// cpKarelTheRobot