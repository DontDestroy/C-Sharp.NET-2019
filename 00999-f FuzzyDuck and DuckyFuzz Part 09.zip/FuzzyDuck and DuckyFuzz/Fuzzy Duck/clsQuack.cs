﻿//***
// Action
//   - Implementation of a cpQuack
//		 - The way a thing makes a Quack sound
// Created
//   - CopyPaste – 20240727 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240727 – VVDW
// Proposal (To Do)
//   - I have decided to override the complete class from the DuckGameLibrary
//   - If you want it in the DuckGameLibrary, give it another name and move it
//***

using System.Diagnostics;

namespace CopyPaste.Game.Animal.Library
{

	public class cpQuack : cpiMakeNoise
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpQuack
		/// </summary>
		public cpQuack()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - frmDuckGame.cmdMakeSound_Click(System.Object, EventArgs) Handles cmdMakeSound.Click
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpQuack()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing makes a quack sound
		/// </summary>
		public void MakeNoise()
		//***
		// Action
		//   - Define how something is making a quack sound
		// Called by
		//   - frmDuckGame.cmdMakeSound_Click(System.Object, EventArgs) Handles cmdMakeSound.Click
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Console.Beep();
		}
		// MakeNoise()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpQuack

}
// CopyPaste.Game.Animal.Library