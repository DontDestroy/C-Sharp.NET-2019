//***
// Action
//   - Example subroutines
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Sub
{

  class cpSub
	{

    static void Main()
    //***
    // Action
    //   - Call a few subroutines
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - GreetInEnglish()
    //   - GreetInSpanish()
    //   - ShowBookInformation()
    //   - ShowTime()
    //   - string System.Console.ReadLine()
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      ShowTime();
      GreetInEnglish();
      GreetInSpanish();
      ShowBookInformation();
      Console.ReadLine();
    }
    // Main()
	
    static void GreetInEnglish()
    //***
    // Action
    //   - Show a greeting in English at the console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Hello, world");
    }
    // GreetInEnglish()

    static void GreetInSpanish()
    //***
    // Action
    //   - Show a greeting in Spanish at the console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Hola, mundo");
    }
    // GreetInSpanish()

    static void ShowBookInformation()
    //***
    // Action
    //   - Show some info at the console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Title: C# .Net Programming Tips & Techniques");
      Console.WriteLine("Author: Jamsa");
      Console.WriteLine("Publisher: McGraw-Hill/Osborne");
      Console.WriteLine("Price: 49.99");
    }
    // ShowBookInformation()

    static void ShowTime()
    //***
    // Action
    //   - Show current time at console screen
    // Called by
    //   - Main()
    // Calls
    //   - DateTime System.DateTime.Now()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Current time is: " + DateTime.Now);
    }
    // ShowTime()

  }
  // cpSub

}
// Sub