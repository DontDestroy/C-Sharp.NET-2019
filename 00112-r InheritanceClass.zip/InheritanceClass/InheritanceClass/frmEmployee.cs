//***
// Action
//   - Testroutine for cpPerson and cpTeacher 
// Created
//   - CopyPaste � 20240525 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240525 � VVDW
// Proposal (To Do)
//   - 
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmEmployee: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.DateTimePicker dtpBirthDay;
    internal System.Windows.Forms.Label lblText;
    internal System.Windows.Forms.TextBox txtName;
    internal System.Windows.Forms.TextBox txtFirstName;
    internal System.Windows.Forms.Button cmdDisplay;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmEmployee));
      this.dtpBirthDay = new System.Windows.Forms.DateTimePicker();
      this.lblText = new System.Windows.Forms.Label();
      this.txtName = new System.Windows.Forms.TextBox();
      this.txtFirstName = new System.Windows.Forms.TextBox();
      this.cmdDisplay = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // dtpBirthDay
      // 
      this.dtpBirthDay.Location = new System.Drawing.Point(48, 144);
      this.dtpBirthDay.Name = "dtpBirthDay";
      this.dtpBirthDay.Size = new System.Drawing.Size(184, 20);
      this.dtpBirthDay.TabIndex = 8;
      this.dtpBirthDay.Value = new System.DateTime(1970, 5, 6, 1, 35, 0, 0);
      // 
      // lblText
      // 
      this.lblText.Location = new System.Drawing.Point(8, 16);
      this.lblText.Name = "lblText";
      this.lblText.Size = new System.Drawing.Size(272, 32);
      this.lblText.TabIndex = 5;
      this.lblText.Text = "Enter name, firstname and birthday of the employee.";
      // 
      // txtName
      // 
      this.txtName.Location = new System.Drawing.Point(48, 104);
      this.txtName.Name = "txtName";
      this.txtName.Size = new System.Drawing.Size(184, 20);
      this.txtName.TabIndex = 7;
      this.txtName.Text = "LastName";
      // 
      // txtFirstName
      // 
      this.txtFirstName.Location = new System.Drawing.Point(48, 64);
      this.txtFirstName.Name = "txtFirstName";
      this.txtFirstName.Size = new System.Drawing.Size(184, 20);
      this.txtFirstName.TabIndex = 6;
      this.txtFirstName.Text = "FirstName";
      // 
      // cmdDisplay
      // 
      this.cmdDisplay.Location = new System.Drawing.Point(96, 200);
      this.cmdDisplay.Name = "cmdDisplay";
      this.cmdDisplay.Size = new System.Drawing.Size(96, 32);
      this.cmdDisplay.TabIndex = 9;
      this.cmdDisplay.Text = "&Display data";
      this.cmdDisplay.Click += new System.EventHandler(this.cmdDisplay_Click);
      // 
      // frmEmployee
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.dtpBirthDay);
      this.Controls.Add(this.lblText);
      this.Controls.Add(this.txtName);
      this.Controls.Add(this.txtFirstName);
      this.Controls.Add(this.cmdDisplay);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmEmployee";
      this.Text = "Employee";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmEmployee'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240525 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240525 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmEmployee()
      //***
      // Action
      //   - Create instance of 'frmEmployee'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240525 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240525 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmEmployee()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdDisplay_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a date
      //   - Define a teacher
      //   - Assign name, firstname and date of form to instance of cpTeacher
      //   - Show a messagebox with information (cpPerson)
      //   - Ask for the grade of the teacher
      //   - Show a messagebox with extra information (cpTeacher)
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpEmployee.FirstName(string) (Set)
      //   - cpEmployee.LastName(string) (Set)
      //   - cpTeacher()
      //   - cpTeacher.Grade(short) (Set)
      //   - int cpEmployee.Age(DateTime)
      //   - short cpTeacher.Grade (Get)
      //   - string cpEmployee.FirstName (Get)
      //   - string cpEmployee.LastName (Get)
      // Created
      //   - CopyPaste � 20240525 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240525 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DateTime dtmDateOfBirth;
      cpTeacher thecpEmployee = new cpTeacher();

      thecpEmployee.FirstName = txtFirstName.Text;
      thecpEmployee.LastName = txtName.Text;
      dtmDateOfBirth = dtpBirthDay.Value.Date;

      MessageBox.Show(thecpEmployee.FirstName + " " + thecpEmployee.LastName +
        " is " + thecpEmployee.Age(dtmDateOfBirth) + " year old.", "Copy Paste");
      thecpEmployee.Grade = Convert.ToInt16(Interaction.InputBox("In what grade do you teach? (Number)", "Copy Paste", "", 0, 0));
      MessageBox.Show(thecpEmployee.FirstName + " " + thecpEmployee.LastName +
        " teaches in grade " + thecpEmployee.Grade, "Copy Paste");
    }
    // cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmEmployee
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmEmployee()
      // Created
      //   - CopyPaste � 20240525 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240525 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmEmployee());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmEmployee

}
// CopyPaste.Learning