//***
// Action
//   - Show the logical drives of the computer system
// Created
//   - CopyPaste � 20240723 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240723 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define an array of logical drives
      //   - Loop thru the array
      //     - Show the logical drive
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240723 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240723 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string[] arrstrDrive = Directory.GetLogicalDrives();

      Console.WriteLine("Logical Drives");

      foreach (string strDrive in arrstrDrive)
      {
        Console.WriteLine(strDrive);
      }
      // in arrstrDrive

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning