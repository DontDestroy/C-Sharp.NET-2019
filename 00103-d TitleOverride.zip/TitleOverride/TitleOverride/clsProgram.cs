//***
// Action
//   - Testroutine for cpBook and cpBestseller
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Create a cpBook
      //   - Create a cpBestseller
      //   - Show information of both
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpBestseller(String, String, String, Double, String, Int32)
      //   - cpBestseller.ShowTitle()
      //   - cpBook(String, String, String, Double)
      //   - cpBook.ShowTitle()
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBook theProgrammingBook = new cpBook("C# Programming Tips & Techniques", "Wright", "McGraw-Hill", 49.99);
      cpBestseller theBigSeller = new cpBestseller("Vincent and .NET", "Big V", "V Code", 9.99, "New York Times", 3);

      theProgrammingBook.ShowTitle();
      Console.WriteLine();
      theBigSeller.ShowTitle();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// CopyPaste.Learning