﻿//***
// Action
//   - Showing information based on the language settings of the browser
// Created
//   - CopyPaste – 20260804 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260804 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmMultiLanguage : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.ID = "wfrmMultiLanguage";
    }
    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when initializing the page
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260804 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260804 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    protected void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define and initialize a culture info, based on the first user language of the request
    //   - Try to
    //     - Set the culture info of the thread to the found culture info
    //   - On possible error
    //     - Set the culture to "en-uk"
    //   - If form is loaded first time
    //     - Try to
    //       - Define and initialize a resource manager to work with the resources
    //     - On possible error
    //       - Set the culture to "en-uk"
    //     - Get a string (value from the correct resource) based on a given name
    //   - If not
    //     - Do nothing
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260804 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260804 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      CultureInfo theCulture = new CultureInfo(Request.UserLanguages[0]);
      ResourceManager theResourceManager = new ResourceManager("MultiLanguage.Language", typeof(wfrmMultiLanguage).Assembly);

      try
      {
        System.Threading.Thread.CurrentThread.CurrentCulture = theCulture;
      }
      catch
      {
        theCulture = new CultureInfo("en-gb");
        System.Threading.Thread.CurrentThread.CurrentCulture = theCulture;
      }

      if (IsPostBack)
      {
      }
      else
      // Not IsPostBack
      {

        try
        {
          theResourceManager = new ResourceManager("MultiLanguage.Language", typeof(wfrmMultiLanguage).Assembly);
          lblNumber.Text = theResourceManager.GetString("lblNumber", theCulture);
        }
        catch
        {
          theCulture = new CultureInfo("en-gb");
          theResourceManager = new ResourceManager("MultiLanguage.Language", typeof(wfrmMultiLanguage).Assembly);
          System.Threading.Thread.CurrentThread.CurrentCulture = theCulture;
        }
        finally
        {
          lblNumber.Text = theResourceManager.GetString("lblNumber", theCulture);
          lblName.Text = theResourceManager.GetString("lblName", theCulture);
          lblAddress.Text = theResourceManager.GetString("lblAddress", theCulture);
          lblZipcode.Text = theResourceManager.GetString("lblZipCode", theCulture);
          lblCity.Text = theResourceManager.GetString("lblCity", theCulture);
        }

      }
      // IsPostBack

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmMultiLanguage

}
// CopyPaste.Learning