// Action
//   - String variables
// Created
//   - CopyPaste � 20220111 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220111 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Strings
{

  class cpStrings
	{

    static void Main()
    //***
    // Action
    //   - Initialise string variables
    //   - Show values at console screen
    //   - Run subroutines
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - System.Console.ReadLine()
    //   - System.Console.WriteLine()
    //   - System.Console.WriteLine(String)
    //   - Test1()
    //   - Test2()
    //   - Test3()
    //   - Test4()
    //   - Test5()
    //   - Test6()
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strBigWarrior;
      string strName;

      strName = "Asterix";
      strBigWarrior = strName;
      Console.WriteLine(strBigWarrior);
      Console.WriteLine();
      
      // Test1();
      Console.WriteLine();
      Test2();
      Console.WriteLine();
      Test3();
      Console.WriteLine();
      Test4();
      Console.WriteLine();
      Test5();
      Console.WriteLine();
      Test6();
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

    public void Test1()
    //***
    // Action
    //   - Initialise variables
    //   - Concatenate strings
    //   - Show result at console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strTogether;
      string strWarrior1 = "Asterix";
      string strWarrior2 = "Obelix";

      strTogether = strWarrior1 + " and " + strWarrior2;
      Console.WriteLine(strTogether);
    }
    // Test1()

    static void Test2()
    //***
    // Action
    //   - Initialise variables
    //   - Concatenate byte and string
    //   - Show result at console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      byte bytSeasons = 4;
      string strEndSentence = " seasons";
      string strTogether;
      
      strTogether = bytSeasons + strEndSentence;
      Console.WriteLine(strTogether);
    }
    // Test2()

    static void Test3()
    //***
    // Action
    //   - Initialise variables
    //   - Concatenate strings
    //   - Compare strings
    //   - Show results at console screen
    // Called by
    //   - Main()
    // Calls
    //   - bool string.CompareTo(string)
    //   - bool string.Equals(string)
    //   - int string.IndexOf(string)
    //   - System.Console.WriteLine(bool)
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      bool blnIsEqual;
      bool blnIsLarger;
      string strBigWarrior = "Asterix";
      string strWarrior1 = "Asterix";
      string strWarrior2 = "Obelix";

      strBigWarrior += "x";
      blnIsEqual = (strWarrior1.Equals(strBigWarrior));
      Console.WriteLine(blnIsEqual);
      
      if (strWarrior1.CompareTo(strWarrior2) > 0)
      {
        blnIsLarger = true;
      }
      else
      {
        blnIsLarger = false;
      }

      Console.WriteLine(blnIsLarger);
      Console.WriteLine(strWarrior1.IndexOf("ster") > 0);
    }
    // Test3()

    static void Test4()
    //***
    // Action
    //   - Initialise variable
    //   - Use methods on string
    //   - Show results at console screen
    // Called by
    //   - Main()
    // Calls
    //   - string string.ToLower()
    //   - string string.ToUpper()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strWarriors = "Asterix and Obelix";

      Console.WriteLine(strWarriors.ToUpper());
      Console.WriteLine(strWarriors.ToLower());
      Console.WriteLine(strWarriors);
    }
    // Test4()
  
    static void Test5()
    //***
    // Action
    //   - Initialise byte variable
    //   - Use methods on byte
    //   - Show result at console screen
    // Called by
    //   - Main()
    // Calls
    //   - string byte.ToString()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      byte bytChildren = 7;
      string strChildrenWord = bytChildren.ToString();

      Console.WriteLine(strChildrenWord);
    }
    // Test5()
  
    static void Test6()
    //***
    // Action
    //   - Initialise string variable
    //   - Use methods on string
    //   - Show result at console screen
    // Called by
    //   - Main()
    // Calls
    //   - byt System.Convert.ToByte(string)
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strChildrenWord = "7";
      byte bytChildren = Convert.ToByte(strChildrenWord);

      Console.WriteLine(bytChildren);
    }
    // Test6()
  
  }
  // cpStrings

}
// Strings