//***
// Action
//   - Implementation of cpMath
// Created
//   - CopyPaste � 20240618 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240618 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpMath
  {

    #region "Constructors / Destructors"

    public cpMath()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpMath()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int Add(int[] arrlngValue)
      //***
      // Action
      //   - Add all numbers of a given array
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngIndex;
      int lngResult = 0;

      for (lngIndex = 0; lngIndex < arrlngValue.Length; lngIndex++)
      {
        lngResult += arrlngValue[lngIndex];
      }
      // lngIndex = arrlngValue.Length

      return lngResult;
    }
		// int Add(int[])

    public int Multiply(int[] arrlngValue)
      //***
      // Action
      //   - Multiply all numbers of a given array
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngIndex;
      int lngResult = 1;

      for (lngIndex = 0; lngIndex < arrlngValue.Length; lngIndex++)
      {
        lngResult *= arrlngValue[lngIndex];
      }
      // lngIndex = arrlngValue.Length

      return lngResult;
    }
    // int Multiply(int[])

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpMath

}
// CopyPaste.Learning