//***
// Action
//   - Working with strings
// Created
//   - CopyPaste � 20220111 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220111 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Strings
{

  class cpStrings
	{

    static void Main()
    //***
    // Action
    //   - Initialise string variables
    //   - Show info on console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strBook = "C# Net Programming Tips & Techniques";
      string strAuthor = "Vincent Van De Walle";
      string strCompany = "Copy Paste";
      
      Console.WriteLine(strBook);
      Console.WriteLine(strAuthor);
      Console.WriteLine(strCompany);
      Console.ReadLine();
		}
    // Main()

  }
  // cpStrings
}
// Strings