﻿//***
// Action
//   - Demo of getting a cooking
//   - Saving the cookie is in wfrmCookies1
// Created
//   - CopyPaste – 20260720 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260720 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmCookies2 : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cmdRemove.Click += new System.EventHandler(this.cmdRemove_Click);
      this.ID = "wfrmCookies2";
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when the page is initialized
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdRemove_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Set the expire date of the cookie to yesterday
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Response.Cookies["Info"].Expires = DateTime.Today.AddDays(-1);
    }
    // cmdRemove_Click(System.Object, System.EventArgs) Handles cmdRemove.Click

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - If cookies "Info" exists
    //     - Fill label name and email with cookie information
    //   - If not
    //     - Show that there is no cookie
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260720 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260720 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (Request.Cookies["Info"] == null)
      {
        lblName.Text = "No cookie";
        lblEmail.Text = "";
      }
      else
      // Request.Cookies["Info"] <> null
      {
        lblName.Text = Request.Cookies["Info"]["Name"];
        lblEmail.Text = Request.Cookies["Info"]["Email"];
      }
      // Request.Cookies["Info"] = null

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmCookies2

}
// CopyPaste.Learning