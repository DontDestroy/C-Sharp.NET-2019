//***
// Action
//   - Definition of cpWorker
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   - Extra exercise, work with properties in stead of variables
//***

using System;

namespace CopyPaste.Teaching
{

  public class cpWorker
  {

    #region "Constructors / Destructors"
    
    public cpWorker()
      //***
      // Action
      //   - Empty constructor of cpWorker
      // Called by
      //   - modAssignNameOverload.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

    }
    // cpWorker()
    
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public string mstrFirstName;
    public string mstrFullName;
    public string mstrLastName;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void AssignName(string strName)
      //***
      // Action
      //   - Assign the name, with one parameter
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - Extra exercise, split the name on the first space
      //   - Before the space, is the info of the firstname
      //   - After the space, is the info of the lastname
      //***
    {
      mstrFullName = strName;
    }
    // AssignName(string)

    public void AssignName(string strFirstName, string strLastName)
      //***
      // Action
      //   - Assign the name, with two parameters
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mstrFirstName = strFirstName;
      mstrLastName = strLastName;
      mstrFullName = strFirstName + " " + strLastName;
    }
    // AssignName(string, string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpWorker 

}
// CopyPaste.Teaching