//***
// Action
//   - Show the order details of a selected order in frmDataGridDrillDown
// Created
//   - CopyPaste � 20251231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251231 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmOrderDetail: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Data.SqlClient.SqlDataAdapter dtaOrderInfo;
    internal System.Data.SqlClient.SqlCommand cmmSelectOrderInfo;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwindScript2005;
    internal System.Windows.Forms.TextBox txtOrderID;
    internal System.Data.SqlClient.SqlDataAdapter dtaEmployees;
    internal System.Data.SqlClient.SqlCommand cmmSelectEmployee;
    internal System.Data.SqlClient.SqlDataAdapter dtaOrderDetails;
    internal System.Data.SqlClient.SqlCommand cmmSelectOrderDetails;
    internal System.Windows.Forms.DataGrid dgrOrderDetails;
    internal System.Windows.Forms.DateTimePicker dtpOrderDate;
    internal System.Windows.Forms.Label lblEmployee;
    internal System.Windows.Forms.ComboBox cmbEmployees;
    internal System.Windows.Forms.Label lblOrderDate;
    private BoundControls.dsOrderInfo dsOrderInfo;
    private BoundControls.dsEmployees dsEmployees;
    private BoundControls.dsOrderDetails dsOrderDetails;
    internal System.Windows.Forms.Label lblOrderId;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOrderDetail));
      this.dtaOrderInfo = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectOrderInfo = new System.Data.SqlClient.SqlCommand();
      this.cnncpNorthwindScript2005 = new System.Data.SqlClient.SqlConnection();
      this.txtOrderID = new System.Windows.Forms.TextBox();
      this.dsOrderInfo = new BoundControls.dsOrderInfo();
      this.dtaEmployees = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectEmployee = new System.Data.SqlClient.SqlCommand();
      this.dtaOrderDetails = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectOrderDetails = new System.Data.SqlClient.SqlCommand();
      this.dgrOrderDetails = new System.Windows.Forms.DataGrid();
      this.dsOrderDetails = new BoundControls.dsOrderDetails();
      this.dtpOrderDate = new System.Windows.Forms.DateTimePicker();
      this.lblEmployee = new System.Windows.Forms.Label();
      this.cmbEmployees = new System.Windows.Forms.ComboBox();
      this.dsEmployees = new BoundControls.dsEmployees();
      this.lblOrderDate = new System.Windows.Forms.Label();
      this.lblOrderId = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.dsOrderInfo)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrderDetails)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsOrderDetails)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsEmployees)).BeginInit();
      this.SuspendLayout();
      // 
      // dtaOrderInfo
      // 
      this.dtaOrderInfo.SelectCommand = this.cmmSelectOrderInfo;
      this.dtaOrderInfo.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPOrder", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdOrder", "intIdOrder"),
                        new System.Data.Common.DataColumnMapping("strCustomerId", "strCustomerId"),
                        new System.Data.Common.DataColumnMapping("dtmOrderDate", "dtmOrderDate"),
                        new System.Data.Common.DataColumnMapping("dtmRequiredDate", "dtmRequiredDate"),
                        new System.Data.Common.DataColumnMapping("dtmShippedDate", "dtmShippedDate"),
                        new System.Data.Common.DataColumnMapping("intShipVia", "intShipVia"),
                        new System.Data.Common.DataColumnMapping("dblFreight", "dblFreight"),
                        new System.Data.Common.DataColumnMapping("strShipName", "strShipName"),
                        new System.Data.Common.DataColumnMapping("strShipAddress", "strShipAddress"),
                        new System.Data.Common.DataColumnMapping("strShipCity", "strShipCity"),
                        new System.Data.Common.DataColumnMapping("strShipRegion", "strShipRegion"),
                        new System.Data.Common.DataColumnMapping("strShipPostalCode", "strShipPostalCode"),
                        new System.Data.Common.DataColumnMapping("strShipCountry", "strShipCountry")})});
      // 
      // cmmSelectOrderInfo
      // 
      this.cmmSelectOrderInfo.CommandText = resources.GetString("cmmSelectOrderInfo.CommandText");
      this.cmmSelectOrderInfo.Connection = this.cnncpNorthwindScript2005;
      this.cmmSelectOrderInfo.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@KeyOrder", System.Data.SqlDbType.Int, 4, "intIdOrder")});
      // 
      // cnncpNorthwindScript2005
      // 
      this.cnncpNorthwindScript2005.ConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthwindScript2005.FireInfoMessageEventOnUserErrors = false;
      // 
      // txtOrderID
      // 
      this.txtOrderID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtOrderID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsOrderInfo, "tblCPOrder.intIdOrder", true));
      this.txtOrderID.Location = new System.Drawing.Point(96, 6);
      this.txtOrderID.Name = "txtOrderID";
      this.txtOrderID.Size = new System.Drawing.Size(72, 20);
      this.txtOrderID.TabIndex = 8;
      // 
      // dsOrderInfo
      // 
      this.dsOrderInfo.DataSetName = "dsOrderInfo";
      this.dsOrderInfo.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsOrderInfo.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // dtaEmployees
      // 
      this.dtaEmployees.SelectCommand = this.cmmSelectEmployee;
      this.dtaEmployees.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPEmployee", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdEmployee", "intIdEmployee"),
                        new System.Data.Common.DataColumnMapping("FullName", "FullName")})});
      // 
      // cmmSelectEmployee
      // 
      this.cmmSelectEmployee.CommandText = "SELECT intIdEmployee, strLastName + \', \' + strFirstName AS FullName FROM tblCPEmp" +
    "loyee";
      this.cmmSelectEmployee.Connection = this.cnncpNorthwindScript2005;
      // 
      // dtaOrderDetails
      // 
      this.dtaOrderDetails.SelectCommand = this.cmmSelectOrderDetails;
      this.dtaOrderDetails.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPOrderDetail", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intOrderId", "intIdOrder"),
                        new System.Data.Common.DataColumnMapping("intProductId", "intIdProduct"),
                        new System.Data.Common.DataColumnMapping("dblUnitPrice", "dblUnitPrice"),
                        new System.Data.Common.DataColumnMapping("intQuantity", "intQuantity"),
                        new System.Data.Common.DataColumnMapping("dblDiscount", "dblDiscount")})});
      // 
      // cmmSelectOrderDetails
      // 
      this.cmmSelectOrderDetails.CommandText = "SELECT intOrderId, intProductId, dblUnitPrice, intQuantity, dblDiscount FROM tblC" +
    "POrderDetail WHERE (intOrderId = @KeyOrder)";
      this.cmmSelectOrderDetails.Connection = this.cnncpNorthwindScript2005;
      this.cmmSelectOrderDetails.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@KeyOrder", System.Data.SqlDbType.Int, 4, "intOrderId")});
      // 
      // dgrOrderDetails
      // 
      this.dgrOrderDetails.AllowSorting = false;
      this.dgrOrderDetails.DataMember = "";
      this.dgrOrderDetails.DataSource = this.dsOrderDetails.tblCPOrderDetail;
      this.dgrOrderDetails.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrOrderDetails.Location = new System.Drawing.Point(16, 86);
      this.dgrOrderDetails.Name = "dgrOrderDetails";
      this.dgrOrderDetails.ReadOnly = true;
      this.dgrOrderDetails.Size = new System.Drawing.Size(432, 120);
      this.dgrOrderDetails.TabIndex = 13;
      // 
      // dsOrderDetails
      // 
      this.dsOrderDetails.DataSetName = "dsOrderDetails";
      this.dsOrderDetails.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsOrderDetails.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // dtpOrderDate
      // 
      this.dtpOrderDate.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.dsOrderInfo, "tblCPOrder.dtmOrderDate", true));
      this.dtpOrderDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtpOrderDate.Location = new System.Drawing.Point(96, 30);
      this.dtpOrderDate.Name = "dtpOrderDate";
      this.dtpOrderDate.Size = new System.Drawing.Size(200, 20);
      this.dtpOrderDate.TabIndex = 10;
      // 
      // lblEmployee
      // 
      this.lblEmployee.Location = new System.Drawing.Point(24, 54);
      this.lblEmployee.Name = "lblEmployee";
      this.lblEmployee.Size = new System.Drawing.Size(56, 16);
      this.lblEmployee.TabIndex = 11;
      this.lblEmployee.Text = "Employee";
      // 
      // cmbEmployees
      // 
      this.cmbEmployees.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.dsOrderInfo, "tblCPOrder.intEmployeeId", true));
      this.cmbEmployees.DataSource = this.dsEmployees;
      this.cmbEmployees.DisplayMember = "tblCPEmployee.FullName";
      this.cmbEmployees.Location = new System.Drawing.Point(96, 54);
      this.cmbEmployees.Name = "cmbEmployees";
      this.cmbEmployees.Size = new System.Drawing.Size(200, 21);
      this.cmbEmployees.TabIndex = 12;
      this.cmbEmployees.ValueMember = "intIdEmployee";
      // 
      // dsEmployees
      // 
      this.dsEmployees.DataSetName = "dsEmployees";
      this.dsEmployees.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsEmployees.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // lblOrderDate
      // 
      this.lblOrderDate.Location = new System.Drawing.Point(24, 30);
      this.lblOrderDate.Name = "lblOrderDate";
      this.lblOrderDate.Size = new System.Drawing.Size(64, 16);
      this.lblOrderDate.TabIndex = 9;
      this.lblOrderDate.Text = "Order Date";
      // 
      // lblOrderId
      // 
      this.lblOrderId.Location = new System.Drawing.Point(24, 6);
      this.lblOrderId.Name = "lblOrderId";
      this.lblOrderId.Size = new System.Drawing.Size(48, 16);
      this.lblOrderId.TabIndex = 7;
      this.lblOrderId.Text = "Order ID";
      // 
      // frmOrderDetail
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(456, 213);
      this.Controls.Add(this.cmbEmployees);
      this.Controls.Add(this.lblOrderDate);
      this.Controls.Add(this.lblOrderId);
      this.Controls.Add(this.txtOrderID);
      this.Controls.Add(this.dgrOrderDetails);
      this.Controls.Add(this.dtpOrderDate);
      this.Controls.Add(this.lblEmployee);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmOrderDetail";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Detail Order";
      this.Load += new System.EventHandler(this.frmOrderDetail_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dsOrderInfo)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrderDetails)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsOrderDetails)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsEmployees)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmOrderDetail'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmOrderDetail()
      //***
      // Action
      //   - Create instance of 'frmOrderDetail'
      // Called by
      //   - frmDataGridDrillDown.cmdOrderDetail_Click(System.Object, System.EventArgs) Handles cmdOrderDetail.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmOrderDetail()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmOrderDetail_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a variable to store the order key
      //   - Get the selected order key of the global variable (the current frmDataGridDrillDown)
      //   - Fill the data set of employees with the data adapter
      //   - Get the order key
      //   - Set the title of the screen with order key and customer
      //   - Set the parameter for select command of order info
      //   - Fill the data set of order info using the data adapter
      //   - Set the parameter for select command of order details
      //   - Fill the data set of order details using the data adapter
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      long lngOrderKey;

      dtaEmployees.Fill(dsEmployees);
      lngOrderKey = Convert.ToInt32(cpProgram.thefrmDataGridDrillDown.dsOrder.tblCPOrder.Rows[cpProgram.thefrmDataGridDrillDown.dgrOrder.CurrentCell.RowNumber]["intIdOrder"]);
      Text = "Order #" + lngOrderKey.ToString() + " For " + cpProgram.thefrmDataGridDrillDown.cmbCustomer.Text;
      dtaOrderInfo.SelectCommand.Parameters["@KeyOrder"].Value = lngOrderKey;
      dtaOrderInfo.Fill(dsOrderInfo);
      dtaOrderDetails.SelectCommand.Parameters["@KeyOrder"].Value = lngOrderKey;
      dtaOrderDetails.Fill(dsOrderDetails);
    }
    // frmOrderDetail_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmOrderDetail

}
// CopyPaste.Learning