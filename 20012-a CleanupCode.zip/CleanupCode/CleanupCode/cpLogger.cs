﻿//***
// Action
//   - Definition of a cpLogger
// Created
//   - CopyPaste – 20251223 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251223 – VVDW
// Proposal (To Do)
//   - This is automatically generated code
//***

using System.Collections.Generic;
using static System.Console;

namespace CopyPaste.Learning
{

  internal class cpLogger
  {
    public string Flag { get; }
    public int Priority { get; }
    public string LogLevel { get; }

    public cpLogger(string flag, int priority, string logLevel)
    {
      Flag = flag;
      Priority = priority;
      LogLevel = logLevel;
    }

    public override bool Equals(object obj)
    {
      return obj is cpLogger other &&
             Flag == other.Flag &&
             Priority == other.Priority &&
             LogLevel == other.LogLevel;
    }

    public override int GetHashCode()
    {
      int hashCode = -1332235279;
      hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(Flag);
      hashCode = hashCode * -1521134295 + Priority.GetHashCode();
      hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(LogLevel);
      return hashCode;
    }

    public void AddLogEntry()
    //***
    // Action
    //   - There is a local function that determine the priority
    //   - Determine the priority using the log level
    //   - Add the log item as entry
    // Called by
    //   - 
    // Calls
    //   - int DetermineLogLevelValue()
    //   - int Priority (Get)
    //   - Log(int, int, string)
    //   - string Flag (Get)
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Copy this code in your automatically created class
    //***
    {
      int intLogLevel = DetermineLogLevelValue();
      Log(intLogLevel, Priority, Flag);

      int DetermineLogLevelValue()
      //***
      // Action
      //   - Define a return value
      //   - Depending on the lower case value of LogLevel
      //     - 'mail' -> 10
      //     - 'message box' --> 5
      //     - 'log file' --> 1
      //     - default (anything else) --> 0
      // Called by
      //   - AddLogEntry()
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20251223 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251223 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - Copy this code in your automatically created class
      //   - The local function can be converted into a method
      //***
      {
        int intReturnValue = 0;

        switch (LogLevel.ToLower())
        {
          case "mail":
            intReturnValue = 8;
            break;
          case "message box":
            intReturnValue = 5;
            break;
          case "log file":
            intReturnValue = 1;
            break;
          default:
            intReturnValue = 0;
            break;
        }
        // LogLevel.ToLower()

        return intReturnValue;
      }
      // DetermineLogLevelValue()

    }
    // AddLogEntry()

    private void Log(int intLogLevel, int intPriority, string strFlag)
    //***
    // Action
    //   - Create and assign a log message
    //   - Show on console the log message
    // Called by
    //   - AddLogEntry()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Copy this code in your automatically created class
    //***
    {
      string strLogMessage = $"LogLevel = {intLogLevel} \nPriority = {intPriority} \nFlag = {strFlag}";

      WriteLine(strLogMessage);
    }
    // Log(int, int, string)

  }
  // cpLoggger

}
// CopyPaste.Learning