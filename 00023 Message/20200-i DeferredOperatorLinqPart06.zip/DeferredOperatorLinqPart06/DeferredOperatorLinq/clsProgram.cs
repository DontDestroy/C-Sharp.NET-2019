﻿//***
// Action
//   - Demo of Set with Linq
//   - Keyword Distinct
//   - Keyword Union
//   - Keyword Intersect
//   - Keyword Except
// Created
//   - CopyPaste – 20230515 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230515 – VVDW
// Proposal (To Do)
//   -
//***

using AmericanHistory;
using CopyPaste.HumanResources;
using System;
using System.Diagnostics;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeferredOperatorLinq
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void DistinctSequence()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Distinct operators return an output sequence of elements where duplicates are removed
    //     - The input sequence is of the form IEnumerable<T>
    //     - The output sequence is of the form IEnumerable<T>
    //   - Distinct has 2 overloads (only 1 is used in this example)
    //     - Return the elements of a collection using a GetHashCode and Equals methods to determine the unique elements
    //     - See class cpFounderComparer for more information about GetHashCode and Equals if you want to give a comparer with the distinct method
    //   - Fill the array with presidents
    //   - Show result by displaying how many presidents there are
    //   - Concatenate the list of presidents with itself (all presidents are now twice in the list)
    //   - Show result by displaying how many presidents there are
    //   - Select all the unique presidents names (Lambda Linq Dot Notation)
    //   - Show result by displaying how many presidents there are
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - ShowNumberOfPresidents(IEnumerable<cpPresident>, string)
    // Created
    //   - CopyPaste – 20230515 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230515 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpPresident> colResultConcatLambda;
      IEnumerable<cpPresident> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();
      colResultLambda = cpPresident.AllPresidents.Select(aPresident => aPresident);
      // The lambda expression is not needed here, but when you want only the name of the president, it makes sense
      ShowNumberOfPresidents(colResultLambda, "The number of American Presidents (Lambda Linq Dot Notation): ");


      colResultConcatLambda = colResultLambda.Concat(colResultLambda);
      ShowNumberOfPresidents(colResultConcatLambda, "The number of American Presidents after concatenation (Lambda Linq Dot Notation): ");

      colResultLambda = colResultConcatLambda.Distinct();
      // Distinct takes an input sequence and returns an object that, when enumerated,
      // enumerates the input sequence, and yields any element that is not equal to a previously yielded element
      // Values are compared using the GetHashCode and Equals methods
      // Distinct is an extension method, so we use it on an instance of a sequence that is enumerable (AllPresidents)

      ShowNumberOfPresidents(colResultLambda, "The number of American Presidents after distinct (Lambda Linq Dot Notation): ");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // DistinctSequence()

    public static void ExceptSequence()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Except operators return an output sequence of elements where the elements are only in the first collection
    //     - The input sequences are of the form IEnumerable<T>
    //     - The output sequence is of the form IEnumerable<T>
    //   - Except has 2 overloads (only 1 is used in this example)
    //     - Return the elements of a first collection, that are not in the second collection, using a GetHashCode and Equals methods to determine the unique elements 
    //     - First the second collection is looped, then the first collection is looped
    //     - See class cpFounderComparer for more information about GetHashCode and Equals if you want to give a comparer with the distinct method
    //   - Fill the array with presidents
    //   - Create two arrays that are a part of the array of the presidents
    //     - First is the list of all the presidents
    //     - Second is the first 20 presidents
    //   - Using Except, the first list is filtered with what is not in the second list
    //   - Show result by displaying how many presidents there are
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - ShowNumberOfPresidents(IEnumerable<cpPresident>, string)
    // Created
    //   - CopyPaste – 20230516 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230516 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpPresident> colExceptions;
      IEnumerable<cpPresident> colProcessed;
      IEnumerable<cpPresident> colResultLambda;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();
      colResultLambda = cpPresident.AllPresidents.Select(aPresident => aPresident);
      // The lambda expression is not needed here, but when you want only the name of the president, it makes sense
      ShowNumberOfPresidents(colResultLambda, "The number of American Presidents (Lambda Linq Dot Notation): ");

      colProcessed = colResultLambda.Take(20); // Take the first 20 presidents
      colExceptions = colResultLambda.Except(colProcessed); // Take all presidents, except the first 20
      // Except takes a second input sequence and returns an object that, when enumerated,
      // enumerates the input sequence, and collects any element that is not equal to a previously collected element
      // Then it takes a first input sequence and returns an object that, when enumerated,
      // enumerates the input sequence, and yields any element that is not equal to a previously collected element
      // and that is not equal to a previously yielded element
      // Values are compared using the GetHashCode and Equals methods
      // Except is an extension method, so we use it on an instance of a sequence that is enumerable (AllPresidents)

      ShowNumberOfPresidents(colExceptions, "The number of American Presidents after except (Lambda Linq Dot Notation): ");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // ExceptSequence()

    public static void IntersectSequence()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Intersect operators return an output sequence of elements where duplicates are removed
    //     - The input sequences are of the form IEnumerable<T>
    //     - The output sequence is of the form IEnumerable<T>
    //   - Intersect has 2 overloads (only 1 is used in this example)
    //     - Return the elements of two collections using a GetHashCode and Equals methods to determine the unique elements
    //     - First the second collection is looped, then the first collection is looped
    //     - See class cpFounderComparer for more information about GetHashCode and Equals if you want to give a comparer with the distinct method
    //   - Fill the array with presidents
    //   - Create two arrays that are a part of the array of the presidents
    //     - First is the first 5
    //     - Second is all except the first 4
    //   - So you have 1 duplicate (the fifth element) if you intersect this
    //   - Using Intersect, the duplicate should not be the only one
    //   - Show result by displaying how many presidents there are
    //   - Intersect the two lists of presidents (1 president is in both collections)
    //   - Show result by displaying how many presidents there are
    //   - Show result by displaying the name of that president
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)
    //   - ShowNumberOfPresidents(IEnumerable<cpPresident>, string)
    // Created
    //   - CopyPaste – 20230516 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230516 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpPresident> colFirst;
      IEnumerable<cpPresident> colResultIntersectLambda;
      IEnumerable<cpPresident> colResultLambda;
      IEnumerable<cpPresident> colSecond;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();
      colResultLambda = cpPresident.AllPresidents.Select(aPresident => aPresident);
      // The lambda expression is not needed here, but when you want only the name of the president, it makes sense
      ShowNumberOfPresidents(colResultLambda, "The number of American Presidents (Lambda Linq Dot Notation): ");

      colFirst = colResultLambda.Take(5); // Take the first 5 presidents
      colSecond = colResultLambda.Skip(4); // Take all presidents, except the first 4

      colResultIntersectLambda = colFirst.Intersect(colSecond);
      // Intersect takes a second input sequence and returns an object that, when enumerated,
      // enumerates the input sequence, and collects any element that is not equal to a previously collected element
      // Then it takes a first input sequence and returns an object that, when enumerated,
      // enumerates the input sequence, and yields any element that is equal to a previously collected element
      // and that is not equal to a previously yielded element
      // Values are compared using the GetHashCode and Equals methods
      // Intersect is an extension method, so we use it on an instance of a sequence that is enumerable (AllPresidents)

      ShowNumberOfPresidents(colResultIntersectLambda, "The number of American Presidents after intersect (Lambda Linq Dot Notation): ");
      ShowContentOfPresidentSequence(colResultIntersectLambda, "The American Presidents after intersect: (Lambda Linq Dot Notation) ");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // IntersectSequence()

    public static void Main()
    //***
    // Action
    //   - Study the methods in order
    //   - Try to experiment, your own location to try things out
    //   - Remove duplicates of a sequence on a specific value
    //   - Union two sequences and remove duplicates of the result sequence on a specific value
    //   - Intersect two sequences and remove duplicates of the result sequence on a specific value
    //   - Except two sequences and only keep the elements in the result sequence on a specific value that are not in the second sequence
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - DistinctSequence()
    //   - ExceptSequence()
    //   - IntersectSequence()
    //   - TryToExperiment()
    //   - UnionSequence()
    // Created
    //   - CopyPaste – 20230515 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230515 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      TryToExperiment();
      // DistinctSequence();
      // UnionSequence();
      // IntersectSequence();
      // ExceptSequence();
      Console.ReadLine();
    }
    // Main()

    public static void UnionSequence()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Union operators return an output sequence of elements where duplicates are removed
    //     - The input sequences are of the form IEnumerable<T>
    //     - The output sequence is of the form IEnumerable<T>
    //   - Union has 2 overloads (only 1 is used in this example)
    //     - Return the elements of two collections using a GetHashCode and Equals methods to determine the unique elements
    //     - First the first collection is looped, then the second collection is looped
    //     - See class cpFounderComparer for more information about GetHashCode and Equals if you want to give a comparer with the distinct method
    //   - Fill the array with presidents
    //   - Create two arrays that are a part of the array of the presidents
    //     - First is the first 5
    //     - Second is all except the first 4
    //   - So you have 1 duplicate (the fifth element) if you concatenate this
    //   - Using Union, the duplicate should not be there
    //   - Show result by displaying how many presidents there are
    //   - Concatenate the two lists of presidents (all presidents are in the list, 1 is duplicated)
    //   - Show result by displaying how many presidents there are
    //   - Union the two lists of presidents (Lambda Linq Dot Notation)
    //   - Show result by displaying how many presidents there are
    // Called by
    //   - Main()
    // Calls
    //   - cpPresident.FillPresidents()
    //   - cpPresident[] cpPresident.AllPresidents (Get)
    //   - ShowNumberOfPresidents(IEnumerable<cpPresident>, string)
    // Created
    //   - CopyPaste – 20230516 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230516 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IEnumerable<cpPresident> colFirst;
      IEnumerable<cpPresident> colResultConcatLambda;
      IEnumerable<cpPresident> colResultLambda;
      IEnumerable<cpPresident> colResultUnionLambda;
      IEnumerable<cpPresident> colSecond;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      cpPresident.FillPresidents();
      colResultLambda = cpPresident.AllPresidents.Select(aPresident => aPresident);
      // The lambda expression is not needed here, but when you want only the name of the president, it makes sense
      ShowNumberOfPresidents(colResultLambda, "The number of American Presidents (Lambda Linq Dot Notation): ");

      colFirst = colResultLambda.Take(5); // Take the first 5 presidents
      colSecond = colResultLambda.Skip(4); // Take all presidents, except the first 4

      colResultConcatLambda = colFirst.Concat(colSecond);
      ShowNumberOfPresidents(colResultConcatLambda, "The number of American Presidents after concatenation (Lambda Linq Dot Notation): ");

      colResultUnionLambda = colFirst.Union(colSecond);
      // Union takes a first input sequence and returns an object that, when enumerated,
      // enumerates the input sequence, and yields any element that is not equal to a previously yielded element
      // Then it takes a second input sequence and returns an object that, when enumerated,
      // enumerates the input sequence, and yields any element that is not equal to a previously yielded element
      // Values are compared using the GetHashCode and Equals methods
      // Union is an extension method, so we use it on an instance of a sequence that is enumerable (AllPresidents)

      ShowNumberOfPresidents(colResultUnionLambda, "The number of American Presidents after union (Lambda Linq Dot Notation): ");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // UnionSequence()

    private static void ShowContentOfPresidentSequence(IEnumerable<cpPresident> colSequence, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type cpPresident in a sequence
    // Called by
    //   - DistinctSequence()
    //   - IntersectSequence()
    // Calls
    //   - string cpPresident.Name() (Get)
    // Created
    //   - CopyPaste – 20230515 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230515 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine(strTitle);

      foreach (cpPresident aPresident in colSequence)
      {
        Console.WriteLine(aPresident.Name);
      }
      // in colSequence

    }
    // ShowContentOfPresidentSequence(IEnumerable<cpPresident>, string)

    private static void ShowNumberOfPresidents(IEnumerable<cpPresident> colSequence, string strTitle)
    //***
    // Action
    //   - Show the Number of presidents in a sequence
    // Called by
    //   - DistinctSequence()
    //   - ExceptSequence()
    //   - IntersectSequence()
    //   - UnionSequence()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20230515 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230515 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.Write(strTitle);
      Console.WriteLine(colSequence.Count());
    }
    // ShowNumberOfPresidents(IEnumerable<cpPresident>, string)

    public static void TryToExperiment()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Method used for experimenting
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230515 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230515 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      //  Do your stuff here

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // TryToExperiment()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion  

  }
  // cpProgram

}
// DeferredOperatorLinq