﻿//***
// Action
//   - Implementation of a cpCamera
//     - All cameras take and save a photo in the same way
//       - All class that inherit must show information on the Output Window
//     - All cameras can have an implementation of sharing
//       - This is done thru delegates and events
//       - Meaning, that the functionality is outside the class of cpCamera
//     - All cameras implement editing photos with a shared method
// Created
//   - CopyPaste – 20240810 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240810 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Camera.Library
{

	public abstract class cpCamera
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpCamera
		/// </summary>
		public cpCamera()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - cpBasicCamera()
		//   - cpSpecialCamera()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240810 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240810 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpCamera()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		internal event cpDelegateShare PerformShare;
		// Edit()

		private cpiShare cpHowToShare;

		#endregion

		#region "Properties"

		public cpiShare HowToShare
		{

			get
			//***
			// Action Get
			//   - Return cpHowToShare
			// Called by
			//   - CleanBehaviour()
			//   - HowToShare(cpiShare) (Set)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20240810 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240810 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return cpHowToShare;
			}
			// cpiShare HowToShare (Get)

			set
			//***
			// Action Set
			//   - Try to remove the previous behaviour from the event
			//   - cpHowToShare becomes value
			//   - Add the new functionality to the event
			// Called by
			//   - CopyPaste.Camera.Test.cpProgram.Main()
			//   - cpBasicCamera()
			//   - cpSpecialCamera()
			// Calls
  		//   - cpiShare HowToShare (Get)
			//   - cpiShare.Share()
			// Created
			//   - CopyPaste – 20240810 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240810 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{

				if (PerformShare == null)
				{
				}
				else
				// PerformShare <> null
				{
					PerformShare -= new cpDelegateShare(HowToShare.Share);
					// Don't do the code above, if you want to add behaviour to the event instead of replacing the behaviour
				}
				// PerformShare = null

				cpHowToShare = value;
				PerformShare += new cpDelegateShare(HowToShare.Share);
			}
			// HowToShare(cpiShare) (Set)

		}
		// cpiShare HowToShare

		#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		#region "Event"

		public delegate void cpDelegateShare();

		#endregion

		#region "Sub / Function"

		/// <summary>
		/// Clean the existing behaviour from a cpCamera
		/// </summary>
		public void CleanBehaviour()
		//***
		// Action
		//   - If there is a behaviour for sharing
		//     - Remove it
		// Called by
		//   - CopyPaste.Camera.Test.cpProgram.Main()
		// Calls
		//   - cpiShare HowToShare (Get)
		//   - cpiShare.Share()
		// Created
		//   - CopyPaste – 20240810 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240810 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformShare == null)
			{
			}
			else
			// PerformShare <> null
			{
				PerformShare -= new cpDelegateShare(HowToShare.Share);
			}
			// PerformShare = null

		}
		// CleanBehaviour()

		/// <summary>
		/// How is a cpCamera editing a photo
		/// </summary>
		public abstract void Edit();

		/// <summary>
		/// Define how the cpCamera shares a photo
		/// </summary>
		public void Share()
		//***
		// Action
		//   - If PerformShare is null
		//     - Do nothing
		//   - If Not
		//     - Execute PerformShare
		// Called by
		//   - CopyPaste.Camera.Test.cpProgram.Main()
		// Calls
		//   - PerformShare()
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformShare == null)
			{
			}
			else
			// PerformShare <> null
			{
				PerformShare();
			}
			// PerformShare = null

		}
		// Share()

		/// <summary>
		/// How is a cpCamera saving a photo
		/// </summary>
		public virtual void Save()
		//***
		// Action
		//   - Define how the cpCamera saves a photo
		// Called by
		//   - CopyPaste.Camera.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240810 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240810 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("cpCamera is saving a photo");
		}
		// Save()

		/// <summary>
		/// How is a cpCamera taking a photo
		/// </summary>
		public virtual void Take()
		//***
		// Action
		//   - Define how the cpCamera takes a photo
		// Called by
		//   - CopyPaste.Camera.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240810 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240810 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("cpCamera is taking a photo");
		}
		// Take()

		public override string ToString()
		//***
		// Action
		//   - Define how the cpCamera class name is shown
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240810 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240810 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			return this.GetType().Name;
		}
		// string ToString()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpCamera

}
// CopyPaste.Camera.Library