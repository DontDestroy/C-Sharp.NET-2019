//***
// Action
//   - Starting screen with four options
// Created
//   - CopyPaste � 20251205 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251205 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmViewingDataMain: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    internal System.Windows.Forms.Button cmdFilterRecord;
    internal System.Windows.Forms.ToolTip ttpInfo;
    internal System.Windows.Forms.Button cmdLocateRecord;
    internal System.Windows.Forms.Button cmdDataTable;
    internal System.Windows.Forms.Button cmdDataReader;
    private System.ComponentModel.IContainer components;


    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmViewingDataMain));
      this.cmdFilterRecord = new System.Windows.Forms.Button();
      this.ttpInfo = new System.Windows.Forms.ToolTip(this.components);
      this.cmdLocateRecord = new System.Windows.Forms.Button();
      this.cmdDataTable = new System.Windows.Forms.Button();
      this.cmdDataReader = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdFilterRecord
      // 
      this.cmdFilterRecord.Location = new System.Drawing.Point(44, 170);
      this.cmdFilterRecord.Name = "cmdFilterRecord";
      this.cmdFilterRecord.Size = new System.Drawing.Size(112, 32);
      this.cmdFilterRecord.TabIndex = 7;
      this.cmdFilterRecord.Text = "Filter Record";
      this.cmdFilterRecord.Click += new System.EventHandler(this.cmdFilterRecord_Click);
      // 
      // cmdLocateRecord
      // 
      this.cmdLocateRecord.Location = new System.Drawing.Point(44, 122);
      this.cmdLocateRecord.Name = "cmdLocateRecord";
      this.cmdLocateRecord.Size = new System.Drawing.Size(112, 32);
      this.cmdLocateRecord.TabIndex = 6;
      this.cmdLocateRecord.Text = "Locate Record";
      this.cmdLocateRecord.Click += new System.EventHandler(this.cmdLocateRecord_Click);
      // 
      // cmdDataTable
      // 
      this.cmdDataTable.Location = new System.Drawing.Point(44, 74);
      this.cmdDataTable.Name = "cmdDataTable";
      this.cmdDataTable.Size = new System.Drawing.Size(112, 32);
      this.cmdDataTable.TabIndex = 5;
      this.cmdDataTable.Text = "Data Table";
      this.cmdDataTable.Click += new System.EventHandler(this.cmdDataTable_Click);
      // 
      // cmdDataReader
      // 
      this.cmdDataReader.Location = new System.Drawing.Point(44, 26);
      this.cmdDataReader.Name = "cmdDataReader";
      this.cmdDataReader.Size = new System.Drawing.Size(112, 32);
      this.cmdDataReader.TabIndex = 4;
      this.cmdDataReader.Text = "Data Reader";
      this.cmdDataReader.Click += new System.EventHandler(this.cmdDataReader_Click);
      // 
      // frmViewingDataMain
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(200, 229);
      this.Controls.Add(this.cmdLocateRecord);
      this.Controls.Add(this.cmdDataTable);
      this.Controls.Add(this.cmdDataReader);
      this.Controls.Add(this.cmdFilterRecord);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmViewingDataMain";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Viewing Data Main Form";
      this.Load += new System.EventHandler(this.frmViewingDataMain_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmViewingDataMain'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmViewingDataMain()
      //***
      // Action
      //   - Create instance of 'frmViewingDataMain'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmViewingDataMain()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdDataReader_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmDataReader
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmDataReader()
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmDataReader thefrmDataReader = new frmDataReader();
      
      thefrmDataReader.Show();    
    }
    // cmdDataReader_Click(System.Object, System.EventArgs) Handles cmdDataReader.Click

    private void cmdDataTable_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmDataTable
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmDataTable()
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmDataTable thefrmDataTable = new frmDataTable();
      
      thefrmDataTable.Show();
    }
    // cmdDataTable_Click(System.Object, System.EventArgs) Handles cmdDataTable.Click

    private void cmdFilterRecord_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmFilterRecord
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmFilterRecord()
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmFilterRecord thefrmFilterRecord = new frmFilterRecord();
      
      thefrmFilterRecord.Show();
    }
    // cmdFilterRecord_Click(System.Object, System.EventArgs) Handles cmdFilterRecord.Click

    private void cmdLocateRecord_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmLocateRecord
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmLocateRecord()
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmLocateRecord thefrmLocateRecord = new frmLocateRecord();

      thefrmLocateRecord.Show();
    }
    // cmdLocateRecord_Click(System.Object, System.EventArgs) Handles cmdLocateRecord.Click

    private void frmViewingDataMain_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set tooltips for the buttons
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ttpInfo.SetToolTip(cmdDataReader, "Retrieve data using DataReader object, fully unbound");
      ttpInfo.SetToolTip(cmdDataTable, "Retrieve results from SQL Server using the DataTable object, databind at runtime");
      ttpInfo.SetToolTip(cmdLocateRecord, "Locate records with the DataTable object");
      ttpInfo.SetToolTip(cmdFilterRecord, "Filter and sort records using the DataView object");
    }
    // frmViewingDataMain_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmViewingDataMain
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmViewingDataMain()
      // Created
      //   - CopyPaste � 20251205 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251205 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmViewingDataMain());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmViewingDataMain

}
// CopyPaste.Learning