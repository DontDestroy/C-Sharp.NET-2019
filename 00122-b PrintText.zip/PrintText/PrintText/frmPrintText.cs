//***
// Action
//   - Printing a text
// Created
//   - CopyPaste � 20240526 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240526 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPrintText: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdPrint;
    internal System.Windows.Forms.TextBox txtText;
    internal System.Windows.Forms.Label lblText;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPrintText));
      this.cmdPrint = new System.Windows.Forms.Button();
      this.txtText = new System.Windows.Forms.TextBox();
      this.lblText = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdPrint
      // 
      this.cmdPrint.Location = new System.Drawing.Point(104, 233);
      this.cmdPrint.Name = "cmdPrint";
      this.cmdPrint.TabIndex = 5;
      this.cmdPrint.Text = "&Print";
      this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(16, 65);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtText.Size = new System.Drawing.Size(256, 152);
      this.txtText.TabIndex = 4;
      this.txtText.Text = "";
      // 
      // lblText
      // 
      this.lblText.Location = new System.Drawing.Point(16, 17);
      this.lblText.Name = "lblText";
      this.lblText.Size = new System.Drawing.Size(248, 40);
      this.lblText.TabIndex = 3;
      this.lblText.Text = "Type text in this textbox and print.";
      // 
      // frmPrintText
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdPrint);
      this.Controls.Add(this.txtText);
      this.Controls.Add(this.lblText);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPrintText";
      this.Text = "Print Text";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPrintText'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240526 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240526 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPrintText()
      //***
      // Action
      //   - Create instance of 'frmPrintText'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240526 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240526 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPrintText()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"


    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdPrint_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a print document
      //   - Try
      //     - Add a print action to the print document
      //     - Execute the print
      //   - When something goes wrong
      //     - Show the error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - PrintText(System.Object, PrintPageEventArgs)
      // Created
      //   - CopyPaste � 20240526 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240526 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      PrintDocument prtDocument = new PrintDocument();

      try
      {
        prtDocument.PrintPage += new PrintPageEventHandler(PrintText);
        prtDocument.Print();
      }
      catch (Exception theException)
      {
        MessageBox.Show("Sorry, there is a printing problem", theException.ToString());
      }
      finally
      {
      }
    
    }
    // cmdPrint_Click(System.Object, System.EventArgs) Handles cmdPrint.Click

    #endregion

    #region "Functionality"

    #region "Event"

    private void PrintText(System.Object theSender, PrintPageEventArgs thePrintPageEventArguments)
      //***
      // Action
      //   - Action to print the text of the form
      // Called by
      //   - cmdPrint_Click(System.Object, System.EventArgs) Handles cmdPrint.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240526 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240526 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      thePrintPageEventArguments.Graphics.DrawString(txtText.Text, new Font("Arial", 11, FontStyle.Regular), Brushes.Black, 120, 120);
      thePrintPageEventArguments.HasMorePages = false;
    }
    // PrintText(System.Object, PrintPageEventArgs)

    #endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPrintText
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmPrintText()
      // Created
      //   - CopyPaste � 20240526 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240526 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPrintText());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPrintText

}
// CopyPaste.Learning