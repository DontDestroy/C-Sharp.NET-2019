//***
// Action
//   - Create and Call SQL Server 2005 User Defined Functions
//     - Show the products and categories with a price higher than a parameter
// Created
//   - CopyPaste � 20260114 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260114 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmUserDefinedFunctionTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.IContainer components;
    internal System.Windows.Forms.Button cmdUseUDF;
    internal System.Windows.Forms.Label lblUseUDF;
    internal System.Windows.Forms.Label lblSQLStatementUsingUDF;
    internal System.Windows.Forms.TextBox txtUnitPrice;
    internal System.Windows.Forms.Label lblCriteria;
    internal System.Windows.Forms.Button cmdCreateUDF;
    internal System.Windows.Forms.DataGrid dgrResult;
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.Label lblCreateUDF;
    internal System.Windows.Forms.Label lblSQLStatement;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmUserDefinedFunctionTryout));
      this.cmdUseUDF = new System.Windows.Forms.Button();
      this.lblUseUDF = new System.Windows.Forms.Label();
      this.lblSQLStatementUsingUDF = new System.Windows.Forms.Label();
      this.txtUnitPrice = new System.Windows.Forms.TextBox();
      this.lblCriteria = new System.Windows.Forms.Label();
      this.cmdCreateUDF = new System.Windows.Forms.Button();
      this.dgrResult = new System.Windows.Forms.DataGrid();
      this.lblResult = new System.Windows.Forms.Label();
      this.lblCreateUDF = new System.Windows.Forms.Label();
      this.lblSQLStatement = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.dgrResult)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdUseUDF
      // 
      this.cmdUseUDF.Location = new System.Drawing.Point(416, 320);
      this.cmdUseUDF.Name = "cmdUseUDF";
      this.cmdUseUDF.Size = new System.Drawing.Size(72, 32);
      this.cmdUseUDF.TabIndex = 17;
      this.cmdUseUDF.Text = "Use UDF";
      this.cmdUseUDF.Click += new System.EventHandler(this.cmdUseUDF_Click);
      // 
      // lblUseUDF
      // 
      this.lblUseUDF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblUseUDF.Location = new System.Drawing.Point(8, 320);
      this.lblUseUDF.Name = "lblUseUDF";
      this.lblUseUDF.Size = new System.Drawing.Size(392, 32);
      this.lblUseUDF.TabIndex = 16;
      // 
      // lblSQLStatementUsingUDF
      // 
      this.lblSQLStatementUsingUDF.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblSQLStatementUsingUDF.Location = new System.Drawing.Point(8, 304);
      this.lblSQLStatementUsingUDF.Name = "lblSQLStatementUsingUDF";
      this.lblSQLStatementUsingUDF.Size = new System.Drawing.Size(168, 16);
      this.lblSQLStatementUsingUDF.TabIndex = 15;
      this.lblSQLStatementUsingUDF.Text = "SQL Statement Using UDF";
      // 
      // txtUnitPrice
      // 
      this.txtUnitPrice.Location = new System.Drawing.Point(184, 8);
      this.txtUnitPrice.Name = "txtUnitPrice";
      this.txtUnitPrice.TabIndex = 11;
      this.txtUnitPrice.Text = "12.00";
      this.txtUnitPrice.TextChanged += new System.EventHandler(this.txtUnitPrice_TextChanged);
      // 
      // lblCriteria
      // 
      this.lblCriteria.Location = new System.Drawing.Point(16, 8);
      this.lblCriteria.Name = "lblCriteria";
      this.lblCriteria.Size = new System.Drawing.Size(168, 16);
      this.lblCriteria.TabIndex = 10;
      this.lblCriteria.Text = "Report Products Greater Than:";
      // 
      // cmdCreateUDF
      // 
      this.cmdCreateUDF.Location = new System.Drawing.Point(416, 152);
      this.cmdCreateUDF.Name = "cmdCreateUDF";
      this.cmdCreateUDF.Size = new System.Drawing.Size(72, 32);
      this.cmdCreateUDF.TabIndex = 14;
      this.cmdCreateUDF.Text = "Create UDF";
      this.cmdCreateUDF.Click += new System.EventHandler(this.cmdCreateUDF_Click);
      // 
      // dgrResult
      // 
      this.dgrResult.AlternatingBackColor = System.Drawing.Color.Silver;
      this.dgrResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrResult.BackColor = System.Drawing.Color.White;
      this.dgrResult.CaptionBackColor = System.Drawing.Color.Maroon;
      this.dgrResult.CaptionFont = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.CaptionForeColor = System.Drawing.Color.White;
      this.dgrResult.DataMember = "";
      this.dgrResult.Font = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.ForeColor = System.Drawing.Color.Black;
      this.dgrResult.GridLineColor = System.Drawing.Color.Silver;
      this.dgrResult.HeaderBackColor = System.Drawing.Color.Silver;
      this.dgrResult.HeaderFont = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.HeaderForeColor = System.Drawing.Color.Black;
      this.dgrResult.LinkColor = System.Drawing.Color.Maroon;
      this.dgrResult.Location = new System.Drawing.Point(8, 376);
      this.dgrResult.Name = "dgrResult";
      this.dgrResult.ParentRowsBackColor = System.Drawing.Color.Silver;
      this.dgrResult.ParentRowsForeColor = System.Drawing.Color.Black;
      this.dgrResult.PreferredColumnWidth = 100;
      this.dgrResult.SelectionBackColor = System.Drawing.Color.Maroon;
      this.dgrResult.SelectionForeColor = System.Drawing.Color.White;
      this.dgrResult.Size = new System.Drawing.Size(488, 144);
      this.dgrResult.TabIndex = 19;
      // 
      // lblResult
      // 
      this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblResult.Location = new System.Drawing.Point(8, 360);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(96, 16);
      this.lblResult.TabIndex = 18;
      this.lblResult.Text = "Results";
      // 
      // lblCreateUDF
      // 
      this.lblCreateUDF.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblCreateUDF.Location = new System.Drawing.Point(8, 48);
      this.lblCreateUDF.Name = "lblCreateUDF";
      this.lblCreateUDF.Size = new System.Drawing.Size(392, 248);
      this.lblCreateUDF.TabIndex = 13;
      // 
      // lblSQLStatement
      // 
      this.lblSQLStatement.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblSQLStatement.Location = new System.Drawing.Point(8, 32);
      this.lblSQLStatement.Name = "lblSQLStatement";
      this.lblSQLStatement.Size = new System.Drawing.Size(248, 16);
      this.lblSQLStatement.TabIndex = 12;
      this.lblSQLStatement.Text = "SQL Statement Creating Temporary Table";
      // 
      // frmUserDefinedFunctionTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(504, 525);
      this.Controls.Add(this.cmdUseUDF);
      this.Controls.Add(this.lblUseUDF);
      this.Controls.Add(this.lblSQLStatementUsingUDF);
      this.Controls.Add(this.txtUnitPrice);
      this.Controls.Add(this.lblCriteria);
      this.Controls.Add(this.cmdCreateUDF);
      this.Controls.Add(this.dgrResult);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.lblCreateUDF);
      this.Controls.Add(this.lblSQLStatement);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmUserDefinedFunctionTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Create and Call SQL Server 2000 User Defined Functions Tryout";
      this.Load += new System.EventHandler(this.frmUserDefinedFunctionTryout_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrResult)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmUserDefinedFunctionTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmUserDefinedFunctionTryout()
      //***
      // Action
      //   - Create instance of 'frmUserDefinedFunctionTryout'
      // Called by
      //   - frmMainTryout.cmdUserDefinedFunction_Click(System.Object, System.EventArgs) Handles cmdUserDefinedFunction.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmUserDefinedFunctionTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdCreateUDF_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Create a command with the SQL statement
      //     - Get the connection
      //     - Open the connection
      //     - Execute the command
      //     - Close the connection
      //     - Show a result message
      //   - When error occurs
      //     - Show the exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpGeneralRoutines()
      //   - cpGeneralRoutines.GetConnection() As SqlClient.SqlConnection
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdCreateUDF_Click(System.Object, System.EventArgs) Handles cmdCreateUDF.Click

    private void cmdUseUDF_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Use the user defined function
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - GenerateData()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdUseUDF_Click(System.Object, System.EventArgs) Handles cmdUseUDF.Click

    private void frmUserDefinedFunctionTryout_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and assign a SQL statement with a user defined function
      //   - Set the SQL statement as text on the form (the user defined function)
      //   - Set the use SQL statement as text on the form (the use of the user defined function)
      // Called by
      //   - User action (Starting a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmUserDefinedFunctionTryout_Load(System.Object, System.EventArgs) Handles this.Load

    private void txtUnitPrice_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the SQL statement to use (filter) the SQL User Defined Function
      // Called by
      //   - User action (Changing a textbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // txtUnitPrice_TextChanged(System.Object, System.EventArgs) Handles txtUnitPrice.TextChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void GenerateData()
      //***
      // Action
      //   - Define and create a data table
      //   - Try to
      //     - Create and assign a data adapter using the SQL statement and the connection
      //     - Fill the data table using the data adapter
      //     - The data table becomes the data source of the data grid
      //   - When error occurs
      //     - Show the exception message
      // Called by
      //   - cmdUseUDF_Click(System.Object, System.EventArgs) Handles cmdUseUDF.Click
      // Calls
      //   - cpGeneralRoutines()
      //   - SqlClient.SqlConnection cpGeneralRoutines.GetConnection()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // GenerateData() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmUserDefinedFunctionTryout

}
// CopyPaste.Learning