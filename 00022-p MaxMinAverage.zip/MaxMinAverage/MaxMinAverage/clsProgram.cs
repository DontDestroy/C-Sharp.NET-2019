//***
// Action
//   - Ask a list of numbers
//   - Stop with -1
//   - In the mean time, calculate the minimum, maximum and average
// Created
//   - CopyPaste � 20240502 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240502 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Determine the lowest integer
      //   - Determine the biggest integer
      //   - Loop asking positive numbers (program crashes when you type text)
      //     - If negative (except -1), show error message
      //     - If not negative
      //       - If -1
      //         - exit the loop
      //       - If Not
      //         - Add typed number to total
      //         - Add one to counter of numbers
      //         - If number is bigger than maximum, save into maximum
      //         - If number is smaller than minimum, save into minimum
      //   - If there are numbers typed
      //     - Show minimum, maximum and average
      //   - If not
      //     - Show message that there were no numbers typed
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240502 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240502 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngCounter = 0;
      int lngMaximum = int.MinValue;
      int lngMinimum = int.MaxValue;
      int lngNumber;
      int lngTotal = 0;

      do
      {
        Console.WriteLine("Enter a positive number (to finish enter -1): ");
        lngNumber = Convert.ToInt32(Console.ReadLine());

        if (lngNumber < -1)
        {
          Console.WriteLine("Only positive numbers are allowed");
        }
        else if (lngNumber == -1)
          // lngNumber >= -1
        {
        }
        else
        {
          lngTotal += lngNumber;
          lngCounter += 1;
          
          if (lngNumber > lngMaximum)
          {
            lngMaximum = lngNumber;
          }
          else
            // lngNumber <= lngMaximum
          {
          }
          // lngNumber > lngMaximum

          if (lngNumber < lngMinimum)
          {
            lngMinimum = lngNumber;
          }
          else
            // lngNumber >= lngMinimum 
          {
          }
          // lngNumber < lngMinimum 

        }
        // lngNumber < -1

      }
      while (lngNumber != -1);
      // lngNumber = -1

      if (lngCounter == 0)
      {
        Console.WriteLine("There was no input.");
      }
      else
        // lngCounter = 0
      {
        Console.WriteLine("The minimum: {0}", lngMinimum);
        Console.WriteLine("The maximum: {0}", lngMaximum);
        Console.WriteLine("The average: {0}", lngTotal / lngCounter);
      }
      // lngCounter = 0

      Console.WriteLine();
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning