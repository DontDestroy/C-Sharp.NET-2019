//***
// Action
//   - Routine that keeps a secret by changing a character into another character
// Created
//   - CopyPaste � 20240502 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240502 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Text;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define an array of characters, used to substitute a text
      //   - Ask a text
      //   - Put the text into capitals
      //   - Loop thru every character of the text
      //     - If character is A till Z
      //       - Change that character by the substitute character
      //     - If not
      //       - Character is not changed
      //     - Add the result to the coded text
      //   - Show the coded text
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240502 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240502 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      char[] arrchrCode = new char[]
         {'Q', 'S', 'P', 'A', 'T', 'V', 
          'X', 'B', 'C', 'R', 'J', 'Y', 
          'E', 'D', 'U', 'O', 'H', 'Z', 
          'G', 'I', 'F', 'L', 'N', 'W', 
          'K', 'M'};

      byte[] arrbytTextInAscii;
      byte aInAscii;
      int lngCounter;
      string strCodedText;
      string strText;
      
      Console.Write("Enter text: ");
      strText = Console.ReadLine().ToUpper();
      strCodedText = "";
      arrbytTextInAscii = Encoding.ASCII.GetBytes(strText);
      aInAscii = Encoding.ASCII.GetBytes("A")[0];

      for (lngCounter = 0; lngCounter < strText.Length; lngCounter++)
      {

        if (strText[lngCounter] >= 'A' && strText[lngCounter] <= 'Z')
        {
          strCodedText += arrchrCode[arrbytTextInAscii[lngCounter] - aInAscii];
        }
        else
          // strText[lngCounter] < 'A' OrElse strText[lngCounter] > 'Z'
        {
          strCodedText += strText[lngCounter];
        }
        // strText[lngCounter] >= 'A' AndAlso strText[lngCounter] <= 'Z'

      }
      // lngCounter = strText.Length

      Console.WriteLine("In code: {0}", strCodedText);
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning