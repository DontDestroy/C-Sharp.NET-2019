//***
// Action
//   - Implementation of cpCheckingAccount
//   - This is a bankAccount, but for every withdraw there is a cost of 25 cent
// Created
//   - CopyPaste � 20240221 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240221 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpCheckingAccount : cpBankAccount
  {

    #region "Constructors / Destructors"

    public cpCheckingAccount(string strOwner) : base(strOwner)
      //***
      // Action
      //   - Constructor of a cpCheckingAccount that defines an owner
      // Called by
      //   - frmCheckingAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - cpBankAccount(string)
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpCheckingAccount(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public override string Id
    {
      
      get
        //***
        // Action Get
        //   - Returns the Id (owner) of a cpBankAccount with a "-C" added at the end
        // Called by
        //   - frmCheckingAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
        // Calls
        //   - string cpBankAccount.Id (Get)
        // Created
        //   - CopyPaste � 20240221 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240221 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return base.Id + "-C";
      }
      // string Id (Get)

    }
    // string Id

    #endregion

    #region "Methods"

    #region "Overrides"

    public override void Withdraw(decimal decAmount)
      //***
      // Action
      //   - A certain amount (decAmount) with a cost of 25 cent is removed from the balance of the cpCheckingAccount
      // Called by
      //   - frmCheckingAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - cpBankAccount.Withdraw(Decimal)
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      decimal decAmountWithCost;
      
      decAmountWithCost = decAmount + 0.25M;
      base.Withdraw(decAmountWithCost);
    }
    // Withdraw(decimal)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCheckingAccount

}
// CopyPaste.Learning