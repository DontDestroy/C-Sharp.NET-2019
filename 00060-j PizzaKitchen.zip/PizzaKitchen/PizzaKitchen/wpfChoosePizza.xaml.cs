﻿//***
// Action
//   - A page to choose the pizza you want to order
// Created
//   - CopyPaste – 20220819 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220819 – VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace PizzaKitchen
{

  public partial class wpfChoosePizza : Page
  {

    //region "Constructors / Destructors"

    public wpfChoosePizza()
    //***
    // Action
    //   - Create an instance of wpfChoosePizza
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220819 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      InitializeComponent();
    }
    // wpfChoosePizza()

    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdSelectTopping_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Show the page to select a topping
    //   - There is a possibility that you will return afterwards back to this page
    //   - The state of the page will be remembered
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - theToppingPage_Return(System.Object, System.Windows.Navigation.ReturnEventArgs<System.Object>) Handles theToppingPage.OnReturn
    //   - wpfPageFunctionToppings()
    // Created
    //   - CopyPaste – 20220819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220819 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      wpfPageFunctionToppings theToppingPage = new wpfPageFunctionToppings();

      theToppingPage.Return += new ReturnEventHandler<object>(theToppingPage_Return);
      NavigationService.Navigate(theToppingPage);
    }
    // cmdSelectTopping_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdSelectTopping.Click

    #endregion

    #region "Functionality"

    #region "Event"

    private void theToppingPage_Return(System.Object theSender, System.Windows.Navigation.ReturnEventArgs<System.Object> theReturnArguments)
    //***
    // Action
    //   - The chosen toppings are shown
    // Called by
    //   - User action (Returning from wpfPageFunctionToppings)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220819 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      List<string> lstChosenToppings = (List<string>)theReturnArguments.Result;

      foreach (string strItem in lstChosenToppings)
      {
        lstToppings.Items.Add(strItem);
      }
      // in lstChosenToppings

    }
    // theToppingPage_Return(System.Object, System.Windows.Navigation.ReturnEventArgs<System.Object>) Handles theToppingPage.OnReturn

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#Region "Not used"
    //#endregion

  }
  // wpfChoosePizza

}
// PizzaKitchen