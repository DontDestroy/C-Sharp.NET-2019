﻿//***
// Action
//   - Definition of a local function
// Created
//   - CopyPaste – 20251218 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251218 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpLocalFunction
  {

    #region "Constructors / Destructors"

    public cpLocalFunction(System.Object thePassedInShape)
    //***
    // Action
    //   - Basic constructor
    //   - This contains the local function CalculateObjectVolume
    //   - Calculate the volume of different shapes
    //     - Shapes supported: cpCube, cpSphere, cpPyramid
    //   - Return the type of shape passed in
    // Called by
    //   - cpProgram.DisplayResult(System.Object)
    // Calls
    //   - CalculateObjectVolume(System.Object)
    //   - double ShapeVolume (Get)   
    //   - ShapeType(string) (Set)
    //   - ShapeVolume(double) (Set)   
    // Created
    //   - CopyPaste – 20251218 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251218 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      ShapeVolume = CalculateObjectVolume(thePassedInShape);

      if (ShapeVolume == 0.0)
      {
        ShapeType = "Invalid Shape";
      }
      else
      // ShapeVolume <> 0.0
      {
        ShapeType = thePassedInShape.GetType().Name;
      }
      // ShapeVolume = 0.0

      double CalculateObjectVolume(System.Object theShape)
      //***
      // Action
      //   - Calculate the volume of different shapes
      //     - Shapes supported: cpCube, cpSphere, cpPyramid
      // Called by
      //   - cpLocalFunction()
      // Calls
      //   - cpCube.Size (Get)
      //   - cpSphere.Radius (Get)
      //   - cpPyramid.BaseLengthSize (Get)
      //   - cpPyramid.BaseWidthSize (Get)
      //   - cpPyramid.HeightSize (Get)
      // Created
      //   - CopyPaste – 20251218 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251218 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        double dblReturn = 0.0;

        switch (theShape)
        {
          case cpCube theCube:
            dblReturn = Math.Pow(theCube.Size, 3);
            break;
          case cpSphere theSphere:
            dblReturn = (4.0 / 3.0) * Math.PI * Math.Pow(theSphere.Radius, 3);
            break;
          case cpPyramid thePiramid:
            dblReturn = (thePiramid.BaseLengthSize * thePiramid.BaseWidthSize * thePiramid.HeightSize) / 3.0;
            break;
          case null:
            dblReturn = 0.0;
            break;
          default:
            throw new ArgumentException("Unknown shape type");
        }

        return dblReturn;
      }
      // CalculateObjectVolume(System.Object)

    }
    // cpLocalFunction(System.Object)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public double ShapeVolume { get; private set; }
    // cpLocalFunction(System.Object)
    // cpProgram.DisplayResult(System.Object)

    public string ShapeType { get; private set; }
    // cpLocalFunction(System.Object)
    // cpProgram.DisplayResult(System.Object)

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpLocalFunction

}
// CopyPaste.Learning