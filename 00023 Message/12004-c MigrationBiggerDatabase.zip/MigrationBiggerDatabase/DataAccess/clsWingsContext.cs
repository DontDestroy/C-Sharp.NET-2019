﻿//***
// Action
//   - Definition of the Database Context
// Created
//   - CopyPaste – 20230713 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230713 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.BusinessObjects;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Common;
using System.Diagnostics;
using System.Linq;
using System.Reflection;

namespace CopyPaste.DataAccess
{

  public class cpWingsContext : DbContext
  {

    //#region "Constructors / Destructors"

    public cpWingsContext()
    //***
    // Action
    //   - Constructor of cpWingsContext
    // Called by
    //   - 
    // Calls
    //   - ConnectionString(string) (Set)
    // Created
    //   - CopyPaste – 20230711 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230711 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ConnectionString = @"Data Source=COPYPASTEPOWER\COPYPASTE;Initial Catalog = cpWings; Integrated Security = True; MultipleActiveResultSets=True";
    }
    // cpWingsContext()

    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public static string ConnectionString { get; set; }

    //***
    // Action Get and Set
    //   - Entry point for the database context to create the model towards the database
    //   - It will give possible errors, uncomment the correct lines in OnModelCreating
    // Called by
    //   - 
    // Calls
    //   - cpEmployee()
    //   - cpPerson()
    // Created
    //   - CopyPaste – 20230711 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230711 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***

    public DbSet<Pilot> Pilot { get; set; }
    // DbSet<Pilot> Pilot (Get)
    // Pilot(DbSet<Pilot>) (Set)

    // Next is created by relation thru Pilot
    // public DbSet<Employee> Employee { get; set; }
    // DbSet<Employee> Employee (Get)
    // Employee(DbSet<Employee>) (Set)

    public DbSet<Flight> Flight { get; set; }
    // DbSet<Flight> Flight (Get)
    // Flight(DbSet<Flight>) (Set)

    // Next is created by relation thru Flight (but must be accessible in cpDataGeneration)
    public DbSet<AircraftType> AircraftType { get; set; }
    // DbSet<AircraftType> AircraftType (Get)
    // AirCraftType(DbSet<AirCraftType>) (Set)

    // Next is created by relation thru AircraftType (but must be accessible in cpDataGeneration)
    public DbSet<AircraftTypeDetail> AircraftTypeDetail { get; set; }
    // DbSet<AircraftTypeDetail> AircraftTypeDetail (Get)
    // AircraftTypeDetail(DbSet<AircraftTypeDetail>) (Set)

    // Next is created by relation thru Flight (but must be accessible in cpDataGeneration)
    public DbSet<Airline> Airline { get; set; }
    // DbSet<Airline> Airline (Get)
    // Airline(DbSet<Airline>) (Set)

    // Next is created by relation thru Flight (but must be accessible in cpDataGeneration)
    public DbSet<Booking> Booking { get; set; }
    // DbSet<Booking> Booking (Get)
    // Booking(DbSet<Booking>) (Set)

    // Next is created by relation thru Flight (but must be accessible in cpDataGeneration)
    public DbSet<Passenger> Passenger { get; set; }
    // DbSet<Passenger> Passenger (Get)
    // Passenger(DbSet<Passenger>) (Set)

    // Next is created by inheritence and is already in Passenger
    // public DbSet<Person> Person { get; set; }
    // DbSet<Person> Person (Get)
    // Person(DbSet<Person>) (Set)

    // Next is created by relation thru Person
    // public DbSet<PersonDetail> PersonDetail { get; set; }
    // DbSet<PersonDetail> PersonDetail (Get)
    // PersonDetail(DbSet<PersonDetail>) (Set)

    #endregion

    //#endregion

    //#region "Methods"

    #region "Overrides"

    protected override void OnConfiguring(DbContextOptionsBuilder theOptionsBuilder)
    //***
    // Action
    //   - While configuring the database context, we say it is a SQL Server database
    //   - Configure the DbContext by giving the correct ConnectionString
    // Called by
    //   - User action (Creating instance of cpWingsContext)
    // Calls
    //   - string ConnectionString (Get)
    // Created
    //   - CopyPaste – 20230711 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230711 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theOptionsBuilder.UseSqlServer(ConnectionString);
    }
    // OnConfiguring(DbContextOptionsBuilder)

    protected override void OnModelCreating(ModelBuilder theModelBuilder)
    //***
    // Action
    //   - Creating the table of Booking gives an error that there is no primary key defined
    //     - Force the key to a combination of FlightNo and PassengerId (both of Booking)
    //   - Creating the table of Flight gives an error that there is no fields that is candidate for the primary key
    //     - Force the key to FlightNo
    //   - Creating the table of Employee gives an error that there is no primary key defined
    //     - Force the key to PersonId
    //   - Creating the table of Passenger gives an error that there is no primary key defined
    //     - Force the key to PersonId
    //   - There are two relations between a Flight and a Pilot
    //     - One for the Pilot and one for the CoPilot
    //     - Force the key to a combination of FlightAsPilot and PilotId
    //     - Force the key to a combination of FlightAsCoPilot and CoPilotId
    //   - Set the maximum lenght for a field (Flight.Memo)
    //   - Set a field (Flight.Seats) required
    //   - Set a default value for Flight.Destination
    //   - Set a default value for Flight.Date
    //   - Create an index for Flight.FreeSeats
    //   - Create an index for Flight.Departure and Flight.Destination
    //   - Several methods to influence the creating 
    // Called by
    //   - User action (Creating instance of cpWingsContext)
    // Calls
    //   - cpEntityTypeConfiguration.Configure(EntityTypeBuilder<Flight>)
    //   - cpFlightEntityTypeConfiguration()
    //   - DateTime Flight.Date (Get)
    //   - ICollection<Flight> Pilot.FlightAsPilot (Get)
    //   - ICollection<Flight> Pilot.FlightAsCoPilot (Get)
    //   - int Booking.FlightNo (Get)
    //   - int Booking.PassengerId (Get)
    //   - int Flight.CoPilotId (Get)
    //   - int Flight.FlightNo (Get)
    //   - int Flight.PilotId (Get)
    //   - int Employee.PersonId (Get)
    //   - int Passenger.PersonId (Get)
    //   - OnModelCreatingConfiguration(EntityTypeBuilder<Flight>)
    //   - Pilot Pilot.CoPilot (Get)
    //   - Pilot Pilot.Pilot (Get)
    //   - short Flight.FreeSeats (Get)
    //   - short Flight.Seats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    //   - string Flight.Memo (Get)
    // Created
    //   - CopyPaste – 20230714 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      // The order is important, putting Booking after Passenger, has a different result
      theModelBuilder.Entity<Booking>().HasKey(theBooking => new { theBooking.FlightNo, theBooking.PassengerId });
      theModelBuilder.Entity<Employee>().HasKey(theEmployee => theEmployee.PersonId);
      theModelBuilder.Entity<Passenger>().HasKey(thePassenger => thePassenger.PersonId);
      theModelBuilder.Entity<Pilot>().HasMany(thePilot => thePilot.FlightAsPilot).WithOne(thePilot => thePilot.Pilot).HasForeignKey(theFlight => theFlight.PilotId).OnDelete(DeleteBehavior.Restrict);
      theModelBuilder.Entity<Pilot>().HasMany(theCoPilot => theCoPilot.FlightAsCoPilot).WithOne(theCoPilot => theCoPilot.CoPilot).HasForeignKey(theFlight => theFlight.CoPilotId).OnDelete(DeleteBehavior.Restrict);

      #region "Syntax 01 Sequential code"

      theModelBuilder.Entity<Flight>().HasKey(theFlight => theFlight.FlightNo);

      // If the Primary Key has an Identy Seeded value, you can say it must not have that by using the following method
      // theModelBuilder.Entity<Flight>().Property(theFlight => theFlight.FlightNo).ValueGeneratedNever();

      // Set the maximum length, not using a data annotation
      theModelBuilder.Entity<Flight>().Property(theFlight => theFlight.Memo).HasMaxLength(4000);

      // Set the field to required, not using a data annotation
      theModelBuilder.Entity<Flight>().Property(theFlight => theFlight.Seats).IsRequired();

      // Set the field to a default value (also done in the entity class)
      theModelBuilder.Entity<Flight>().Property(theFlight => theFlight.Destination).HasDefaultValue("(not set)");
      theModelBuilder.Entity<Flight>().Property(theFlight => theFlight.Date).HasDefaultValueSql("getdate()");

      // Create an index on the field Flight.FreeSeats
      // Create an index on two fields Flight.Departure and Flight.Destination

      theModelBuilder.Entity<Flight>().HasIndex(theFlight => theFlight.FreeSeats).HasDatabaseName("IndexFreeSeats");
      theModelBuilder.Entity<Flight>().HasIndex(theFlight => new { theFlight.Departure, theFlight.Destination }).HasDatabaseName("IndexFromTo");

      #endregion

      #region "Syntax 02 Lambda Statements, comments are the same as Syntax 01"

      theModelBuilder.Entity<Flight>(theFligth =>
      {
        // theFligth.HasKey(theFlight => theFlight.FlightNo);
        // theFligth.Property(theFlight => theFlight.Memo).HasMaxLength(4000);
        // theFligth.Property(theFlight => theFlight.Seats).IsRequired();
        // theFligth.Property(theFlight => theFlight.Destination).HasDefaultValue("(not set)");
        // theFligth.Property(theFlight => theFlight.Date).HasDefaultValueSql("getdate()");
        // theFligth.HasIndex(theFlight => theFlight.FreeSeats).HasDatabaseName("IndexFreeSeats");
        // theFligth.HasIndex(theFlight => new { theFlight.Departure, theFlight.Destination }).HasDatabaseName("IndexFromTo");
      });

      #endregion

      #region "Syntax 03 Subroutines, comments are the same as Syntax 01"

      // theModelBuilder.Entity<Flight>(OnModelCreatingConfiguration);

      #endregion

      #region "Syntax 04 Configuration Classes, comments are the same as Syntax 01"

      // theModelBuilder.ApplyConfiguration<Flight>(new cpFlightEntityTypeConfiguration());

      #endregion

      #region "Syntax 05 Bulk generation, comments are the same as Syntax 01"

      // It prevents the convention that all tables get the names as set in DbSet<T> context class
      // So all the tables get the same name as the class names
      // Except the ones that have the table attribute
      // Columns ending in "No" become primary keys without auto increment

      foreach (IMutableEntityType theEntity in theModelBuilder.Model.GetEntityTypes())
      {
        Debug.Print(theEntity.Name);
        TableAttribute dataAnnotation = theEntity.ClrType?.GetCustomAttribute<TableAttribute>();

        if (dataAnnotation == null)
        {
          // theEntity.Relational().TableName = theEntity.DisplayName(); // Only for versions before 3.0
          // theEntity.SetTableName(theEntity.DisplayName()); // For version 3.0 and after
        }
        else
        // dataAnnotation <> null
        {
        }
        // dataAnnotation = null

        IMutableProperty theProperty = theEntity.GetProperties().FirstOrDefault(anEntity => anEntity.Name.EndsWith("No"));

        if (theProperty == null)
        {
        }
        else
        // theProperty <> null
        {
          // theEntity.SetPrimaryKey(theProperty);
          // theProperty.ValueGenerated = ValueGenerated.Never;
        }
        // theProperty = null

      }
      // in theModelBuilder.Model.GetEntityTypes()

      #endregion

      base.OnModelCreating(theModelBuilder);
    }
    // OnModelCreating(ModelBuilder)

    private void OnModelCreatingConfiguration(EntityTypeBuilder<Flight> theFligth)
    //***
    // Action
    //   - Configuration that is used in OnModelCreating
    //   - There are no other comments, the comments are the same as in syntax 01
    // Called by
    //   - OnModelCreating(ModelBuilder)
    // Calls
    //   - DateTime Flight.Date (Get)
    //   - int Flight.FlightNo (Get)
    //   - short Flight.FreeSeats (Get)
    //   - short Flight.Seats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    //   - string Flight.Memo (Get)
    // Created
    //   - CopyPaste – 20230714 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theFligth.HasKey(theFlight => theFlight.FlightNo);
      theFligth.Property(theFlight => theFlight.Memo).HasMaxLength(4000);
      theFligth.Property(theFlight => theFlight.Seats).IsRequired();
      theFligth.Property(theFlight => theFlight.Destination).HasDefaultValue("(not set)");
      theFligth.Property(theFlight => theFlight.Date).HasDefaultValueSql("getdate()");
      theFligth.HasIndex(theFlight => theFlight.FreeSeats).HasDatabaseName("IndexFreeSeats");
      theFligth.HasIndex(theFlight => new { theFlight.Departure, theFlight.Destination }).HasDatabaseName("IndexFromTo");
    }
    // OnModelCreatingConfiguration(EntityTypeBuilder<Flight>)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpWingsContext

}
// CopyPaste.DataAccess