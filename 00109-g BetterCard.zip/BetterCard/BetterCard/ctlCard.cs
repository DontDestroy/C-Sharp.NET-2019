//***
// Action
//   - Implementation of a playing card in a normal card game, with visualisation as a control
//   - Some comments are in Dutch for clarification
//   - Some comments are in West-Flemish for clarification
// Created
//   - CopyPaste � 20240402 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240402 � VVDW
// Proposal (To Do)
//   - The references towards the actual game are not documented
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Reflection;

namespace CopyPaste.CardGames
{
	public class cpctlCard : System.Windows.Forms.UserControl
	{

    #region Component Designer generated code

    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      // 
      // cpctlCard
      // 
      this.Name = "cpctlCard";
      this.Size = new System.Drawing.Size(60, 75);
      this.SizeChanged += new System.EventHandler(this.cpctlCard_SizeChanged);
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.cpctlCard_Paint);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpctlCard'
      // Called by
      //   - User action (Closing the control)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpctlCard()
      //***
      // Action
      //   - Create new instance of 'cpctlCard'
      //   - Four icons are added to a list of images
      // Called by
      //   - cpctlCard(cpSuit, cpFaceValue)
      //   - User action (Starting the control)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // cpctlCard()

    static cpctlCard()
      //***
      // Action
      //   - This is a static / shared constructor
      //   - Create an array of all possible suits
      //   - Determine the assembly (the location where the icons are stored)
      //   - Get the name of the assembly
      //   - Loop thru the array of suits
      //     - Determine the name of the icon that corresponds with the suitname
      //     - Get the icon (as a stream)
      //     - Create an icon
      //     - Determine the suit
      //     - Add the icon with the suit (as key) to a sorted list
      // Called by
      //   - User action (Starting the control)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      // string[] arrstrSuitName = Enum.GetNames(System.Type.GetType("BetterCard.CopyPaste.CardGames.cpSuit"));
      // Above is correct when cpSuit is not defined in cpctlCard, but in the namespace

      Assembly theAssembly;
      Icon theIcon;
      int lngSuit;
      object theSuit;
      Stream theIconStream;
      string strAssemblyName;
      string strResourceName;
      string[] arrstrSuitName = Enum.GetNames(cpctlCard.cpSuit.Clubs.GetType());

      theAssembly = Assembly.GetExecutingAssembly();
      strAssemblyName = theAssembly.GetName().Name;

      for (lngSuit = 0; lngSuit < arrstrSuitName.Length; lngSuit++)
      {
        strResourceName = strAssemblyName + "." + arrstrSuitName[lngSuit] + ".ico";
        theIconStream = theAssembly.GetManifestResourceStream(strResourceName);
        theIcon = new Icon(theIconStream);
        theSuit = Enum.Parse(System.Type.GetType(cpctlCard.cpSuit.Clubs.GetType().ToString()), arrstrSuitName[lngSuit]);
        msrlImages.Add(theSuit, theIcon);
      }
      // lngSuit = arrstrSuitName.Length

    }
    // cpctlCard()

    public cpctlCard(cpSuit theNewSuit, cpFaceValue theNewFaceValue) : this()
      //***
      // Action
      //   - Create new instance of 'cpctlCard' using a cpSuit and a cpFaceValue
      // Called by
      //   - User action (Starting the control)
      // Calls
      //   - cpcmpDeck.MakeDeck()
      //   - FaceValue(cpFaceValue) (Set)
      //   - cpctlCard()
      //   - Suit(cpSuit) (Set)
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Suit = theNewSuit;
      FaceValue = theNewFaceValue;
    }
    // cpctlCard(cpSuit, cpFaceValue)

    #endregion

    #region "Designer"

    public enum cpFaceValue
    {
      Ace,        // Aas
      Two,        // Twee
      Three,      // Drie
      Four,       // Vier
      Five,       // Vijf
      Six,        // Zes
      Seven,      // Zeven
      Eight,      // Acht
      Nine,       // Negen
      Ten,        // Tien
      Jack,       // Boer
      Queen,      // Vrouw
      King        //Heer
    }
    // cpFaceValue

    public enum cpSuit
    {
      Hearts,      // Harten (hertns)
      Diamonds,    // Ruiten (koekns)
      Clubs,       // Klaver (klavers)
      Spades       // Schoppen (Piekns)
    }
    // cpSuit

    #endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private bool mblnFaceUp = true;
    private cpFaceValue mcpFaceValue = cpFaceValue.Ace;
    private cpSuit mcpSuit = cpSuit.Diamonds;
    public const int mlngFixedHeight = 75;
    public const int mlngFixedWidth = 60;
    private static SortedList msrlImages = new SortedList();

    #endregion

    #region "Properties"

    // This property will be shown in the category "Game" with a specific attribute
    [CategoryAttribute("Game"), DescriptionAttribute("Is the card face up?")]
    public bool FaceUp
    {

      get
        //***
        // Action Get
        //   - Returns mblnFaceUp
        // Called by
        //   - ctlCard_Paint(System.Object, PaintEventArgs) Handles this.Paint
        //   - User action (as property of a control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240402 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240402 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mblnFaceUp;
      }
      // bool FaceUp (Get)

      set
        //***
        // Action Set
        //   - mblnFaceUp becomes value
        //   - Visualisation is refreshed
        // Called by
        //   - User action (as property of a control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240402 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240402 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mblnFaceUp = value;
        this.Refresh();
      }
      // FaceUp(bool) (Set)

    }
    // bool FaceUp

    // This property will be shown in the category "Game" with a specific attribute
    [CategoryAttribute("Game"), DescriptionAttribute("Face value of the card.")]
    public cpFaceValue FaceValue
    {

      get
        //***
        // Action Get
        //   - Returns mcpFaceValue
        // Called by
        //   - ctlCard_Paint(System.Object, PaintEventArgs) Handles this.Paint
        //   - User action (as property of a control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240402 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240402 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mcpFaceValue;
      }
      // cpFaceValue FaceValue (Get)

      set
        //***
        // Action Set
        //   - mblnFaceValue becomes value
        //   - Visualisation is refreshed
        // Called by
        //   - cpctlCard(cpSuit, cpFaceValue)
        //   - User action (as property of a control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240402 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240402 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mcpFaceValue = value;
        this.Refresh();
      }
      // FaceValue(cpFaceValue) (Set)

    }
    // cpFaceValue FaceValue

    // This property will be shown in the category "Game" with a specific attribute
    [CategoryAttribute("Game"), DescriptionAttribute("Suit (Hearts, Spades, Diamonds, Clubs)")]
    public cpSuit Suit
    {

      get
        //***
        // Action Get
        //   - Returns mcpSuit
        // Called by
        //   - ctlCard_Paint(System.Object, PaintEventArgs) Handles this.Paint
        //   - User action (as property of a control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240402 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240402 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mcpSuit;
      }
      // cpSuit Suit (Get)

      set
        //***
        // Action Set
        //   - mcpSuit becomes value
        //   - Visualisation is refreshed
        // Called by
        //   - cpctlCard(cpSuit, cpFaceValue)
        //   - User action (as property of a control)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240402 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240402 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mcpSuit = value;
        this.Refresh();
      }
      // Suit(cpSuit) (Set)

    }
    // cpSuit Suit

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cpctlCard_Paint(System.Object theSender, PaintEventArgs thePaintEventArguments)
      //***
      // Action
      //   - Visualisation of the control
      //   - A graphics is created
      //   - A rectangle is drawn
      //   - If FaceUp
      //     - Show a white color
      //     - Show the face value as a text
      //     - Show the suit using the icon
      //   - If Not
      //     - Show a blue color
      // Called by
      //   - System action (Drawing the card)
      // Calls
      //   - bool FaceUp (Get)
      //   - cpFaceValue FaceValue (Get)
      //   - cpSuit Suit (Get)
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Graphics theGraphics = CreateGraphics();

      theGraphics.DrawRectangle(Pens.Black, 0, 0, ClientRectangle.Width - 1, ClientRectangle.Height - 1);

      if (FaceUp)
      {
        BackColor = Color.White;
        theGraphics.DrawString(FaceValue.ToString(), new Font("Arial", 10, FontStyle.Bold), Brushes.Black, 3, 3);
        theGraphics.DrawIcon((Icon)msrlImages[Suit], 14, 40);
      }
      else
        // Not FaceUp 
      {
        BackColor = Color.Blue;
      }
      // FaceUp 
    
    }
    // cpctlCard_Paint(System.Object theSender, PaintEventArgs thePaintEventArguments) Handles base.Paint()

    private void cpctlCard_SizeChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The control has a specific size
      //   - When the size is changed, it goes back to the default values
      // Called by
      //   - User action (Resizing the card)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Size = new Size(mlngFixedWidth, mlngFixedHeight);
    }
    // cpctlCard_SizeChanged(System.Object, System.EventArgs) Handles base.SizeChanged

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpctlCard

}
// CopyPaste.CardGames