﻿//***
// Action
//   - Implementation of a cpQuack
//		 - The way a thing makes a Quack sound
// Created
//   - CopyPaste – 20240725 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240725 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Animal.Library
{

	public class cpQuack : cpiMakeNoise
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpQuack
		/// </summary>
		public cpQuack()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - cpMallardDuck()
		//   - cpRedHeadDuck()
		//   - cpWoodDuck()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpQuack()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing makes a quack sound
		/// </summary>
		public void MakeNoise()
		//***
		// Action
		//   - Define how something is making a quack sound
		// Called by
		//   - cpMallardDuck()
		//   - cpRedHeadDuck()
		//   - cpWoodDuck()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240725 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240725 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Something is making a quack sound");
		}
		// MakeNoise()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpQuack

}
// CopyPaste.Game.Animal.Library