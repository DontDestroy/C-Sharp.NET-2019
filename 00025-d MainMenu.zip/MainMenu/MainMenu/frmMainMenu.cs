﻿//***
// Action
//   - Working with a menu on a form. This is form as startpoint of the exercise. 
// Created
//   - CopyPaste – 20220708 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220708 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace MainMenu
{

  public class frmMainMenu : System.Windows.Forms.Form
	{
    internal System.Windows.Forms.MainMenu mnuMain;
    internal System.Windows.Forms.MenuItem mnuApple;
    internal System.Windows.Forms.MenuItem mnuAppleRed;
    internal System.Windows.Forms.MenuItem mnuAppleGreen;
    internal System.Windows.Forms.MenuItem mnuAppleGreenRegular;
    internal System.Windows.Forms.MenuItem mnuAppleGreenCaramel;
    internal System.Windows.Forms.MenuItem mnuGrape;
    internal System.Windows.Forms.MenuItem mnuGrapeRed;
    internal System.Windows.Forms.MenuItem mnuGrapeGreen;
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMainMenu));
      this.mnuMain = new System.Windows.Forms.MainMenu();
      this.mnuApple = new System.Windows.Forms.MenuItem();
      this.mnuAppleRed = new System.Windows.Forms.MenuItem();
      this.mnuAppleGreen = new System.Windows.Forms.MenuItem();
      this.mnuAppleGreenRegular = new System.Windows.Forms.MenuItem();
      this.mnuAppleGreenCaramel = new System.Windows.Forms.MenuItem();
      this.mnuGrape = new System.Windows.Forms.MenuItem();
      this.mnuGrapeRed = new System.Windows.Forms.MenuItem();
      this.mnuGrapeGreen = new System.Windows.Forms.MenuItem();
      // 
      // mnuMain
      // 
      this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuApple,
                                                                            this.mnuGrape});
      // 
      // mnuApple
      // 
      this.mnuApple.Index = 0;
      this.mnuApple.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                             this.mnuAppleRed,
                                                                             this.mnuAppleGreen});
      this.mnuApple.Text = "Apples";
      // 
      // mnuAppleRed
      // 
      this.mnuAppleRed.Index = 0;
      this.mnuAppleRed.Text = "Red Apple";
      this.mnuAppleRed.Click += new System.EventHandler(this.mnuAppleRed_Click);
      // 
      // mnuAppleGreen
      // 
      this.mnuAppleGreen.Index = 1;
      this.mnuAppleGreen.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                  this.mnuAppleGreenRegular,
                                                                                  this.mnuAppleGreenCaramel});
      this.mnuAppleGreen.Text = "Green Apple";
      // 
      // mnuAppleGreenRegular
      // 
      this.mnuAppleGreenRegular.Index = 0;
      this.mnuAppleGreenRegular.Text = "Regular";
      // 
      // mnuAppleGreenCaramel
      // 
      this.mnuAppleGreenCaramel.Index = 1;
      this.mnuAppleGreenCaramel.Text = "Caramel";
      // 
      // mnuGrape
      // 
      this.mnuGrape.Index = 1;
      this.mnuGrape.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                             this.mnuGrapeRed,
                                                                             this.mnuGrapeGreen});
      this.mnuGrape.Text = "Grapes";
      // 
      // mnuGrapeRed
      // 
      this.mnuGrapeRed.Checked = true;
      this.mnuGrapeRed.Index = 0;
      this.mnuGrapeRed.Text = "Red Grapes";
      // 
      // mnuGrapeGreen
      // 
      this.mnuGrapeGreen.Enabled = false;
      this.mnuGrapeGreen.Index = 1;
      this.mnuGrapeGreen.Text = "Green Grapes";
      // 
      // frmMainMenu
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(520, 421);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mnuMain;
      this.Name = "frmMainMenu";
      this.Text = "Main Menu";
      this.Load += new System.EventHandler(this.frmMainMenu_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMainMenu'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220708 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220708 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMainMenu()
      //***
      // Action
      //   - Create instance of 'frmMainMenu'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220708 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220708 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmMainMenu_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The form gets the menu linked to it
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220708 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220708 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Menu = mnuMain;
    }
    // frmMainMenu_Load(System.Object, System.EventArgs) Handles this.Load
 
    private void mnuAppleRed_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a message box
      // Called by
      //   - User action (clicking the menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220708 – VVDW
      // Changed
      //   - Organisation – yyyymmdd – Initials of programmer – What changed
      // Tested
      //   - CopyPaste – 20220708 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      MessageBox.Show("You clicked " + mnuAppleRed.Text, "Copy Paste");
    }
    // mnuAppleRed_Click(System.Object, System.EventArgs) Handles mnuAppleRed.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMainMenu
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220708 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220708 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMainMenu());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmMainMenu

}
// MainMenu
