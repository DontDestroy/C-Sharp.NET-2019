﻿//***
// Action
//   - Implementation of a cpMallardDuck
//     - Inherits from cpDuck, where Display (how do I look like) is an abstract method
//       - All class that inherit from cpDuck must implement the Display method
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
//   - The way a cpMallardDuck moves on water is inherited
//     - All cpDuck and child classes moves on water the same way
//   - The sound that a cpMallardDuck makes is given thru a delegate and an event
//   - The way a cpMallardDuck moves on land is given thru a delegate and an event
//   - The way a cpMallardDuck moves in the air is given thru a delegate and an event
// Created
//   - CopyPaste – 20240726 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240726 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Animal.Library;
using System.Diagnostics;

namespace CopyPaste.Game.Duck.Library
{
	
	public class cpMallardDuck : cpDuck
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpMallardDuck
		/// </summary>
		public cpMallardDuck() : base()
		//***
		// Action
		//   - Basic constructor
		//   - Define how a cpWallardDuck flies (with wings)
		//   - Define how a cpWallardDuck makes some noise (quacking)
		//   - Define how a cpWallardDuck walks (with feet)
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - cpDuck()
		//   - cpDuck.HowToFly(cpiFly) (Set)
		//   - cpDuck.HowToMakeNoise(cpiMakeNoise) (Set)
		//   - cpDuck.HowToWalk(cpiWalk) (Set)
		//   - cpFlyWithWings()
		//   - cpQuack()
		//   - cpWalkWithFeet()
  	// Created
		//   - CopyPaste – 20240726 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240726 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			HowToFly = new cpFlyWithWings();
			HowToMakeNoise = new cpQuack();
			HowToWalk = new cpWalkWithFeet();
		}
		// cpMallardDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		#region "Overrides"

		/// <summary>
		/// The visualization (displaying) of a cpMallardDuck
		/// </summary>
		public override void Display()
		//***
		// Action
		//   - Define how a cpMallardDuck looks like
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240726 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240726 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Representation of a cpMallardDuck");
		}
		// Display()

		#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpMallardDuck

}
// CopyPaste.Game.Duck.Library