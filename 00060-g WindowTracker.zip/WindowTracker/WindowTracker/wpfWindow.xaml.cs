//***
// Action
//   - A window that will be created several times from the startup screen
// Created
//   - CopyPaste � 20220817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220817 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace WindowTracker
{

  public partial class wpfWindow : Window
  {

    #region "Constructors / Destructors"

    public wpfWindow()
    //***
    // Action
    //   - Create instance of 'wpfWindow'
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfWindow()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void SetContent(string strContent)
    //***
    // Action
    //   - Change the content of the Window
    // Called by
    //   - cmdUpdate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdUpdate.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      this.Content = strContent;
    }
    // SetContent(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfWindow

}
// WindowTracker