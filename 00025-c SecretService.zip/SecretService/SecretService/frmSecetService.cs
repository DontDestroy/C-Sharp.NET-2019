//***
// Action
//   - Encrypt and decrypt secret texts
// Created
//   - CopyPaste � 20240506 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240506 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSecretText: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.SaveFileDialog dlgFileSave;
    internal System.Windows.Forms.TextBox txtNote;
    internal System.Windows.Forms.MenuItem mnuFileClose;
    internal System.Windows.Forms.MenuItem mnuFileExit;
    internal System.Windows.Forms.OpenFileDialog dlgFileOpen;
    internal System.Windows.Forms.MenuItem mnuFileSaveAs;
    internal System.Windows.Forms.MenuItem mnuFileOpen;
    internal System.Windows.Forms.MenuItem mnuFileInsertDate;
    internal System.Windows.Forms.MenuItem mnuFile;
    internal System.Windows.Forms.Label lblNote;
    internal System.Windows.Forms.MainMenu mnuSecretService;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSecretText));
      this.dlgFileSave = new System.Windows.Forms.SaveFileDialog();
      this.txtNote = new System.Windows.Forms.TextBox();
      this.mnuFileClose = new System.Windows.Forms.MenuItem();
      this.mnuFileExit = new System.Windows.Forms.MenuItem();
      this.dlgFileOpen = new System.Windows.Forms.OpenFileDialog();
      this.mnuFileSaveAs = new System.Windows.Forms.MenuItem();
      this.mnuFileOpen = new System.Windows.Forms.MenuItem();
      this.mnuFileInsertDate = new System.Windows.Forms.MenuItem();
      this.mnuFile = new System.Windows.Forms.MenuItem();
      this.lblNote = new System.Windows.Forms.Label();
      this.mnuSecretService = new System.Windows.Forms.MainMenu();
      this.SuspendLayout();
      // 
      // dlgFileSave
      // 
      this.dlgFileSave.FileName = "doc1";
      // 
      // txtNote
      // 
      this.txtNote.Location = new System.Drawing.Point(16, 48);
      this.txtNote.Multiline = true;
      this.txtNote.Name = "txtNote";
      this.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtNote.Size = new System.Drawing.Size(360, 184);
      this.txtNote.TabIndex = 3;
      this.txtNote.Text = "";
      // 
      // mnuFileClose
      // 
      this.mnuFileClose.Enabled = false;
      this.mnuFileClose.Index = 1;
      this.mnuFileClose.Text = "&Close";
      this.mnuFileClose.Click += new System.EventHandler(this.mnuFileClose_Click);
      // 
      // mnuFileExit
      // 
      this.mnuFileExit.Index = 4;
      this.mnuFileExit.Text = "&Exit";
      this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
      // 
      // mnuFileSaveAs
      // 
      this.mnuFileSaveAs.Index = 2;
      this.mnuFileSaveAs.Text = "&Save secret text as...";
      this.mnuFileSaveAs.Click += new System.EventHandler(this.mnuFileSaveAs_Click);
      // 
      // mnuFileOpen
      // 
      this.mnuFileOpen.Index = 0;
      this.mnuFileOpen.Text = "&Open secret text...";
      this.mnuFileOpen.Click += new System.EventHandler(this.mnuFileOpen_Click);
      // 
      // mnuFileInsertDate
      // 
      this.mnuFileInsertDate.Index = 3;
      this.mnuFileInsertDate.Text = "&Insert date";
      this.mnuFileInsertDate.Click += new System.EventHandler(this.mnuFileInsertDate_Click);
      // 
      // mnuFile
      // 
      this.mnuFile.Index = 0;
      this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFileOpen,
                                                                            this.mnuFileClose,
                                                                            this.mnuFileSaveAs,
                                                                            this.mnuFileInsertDate,
                                                                            this.mnuFileExit});
      this.mnuFile.Text = "&File";
      // 
      // lblNote
      // 
      this.lblNote.Location = new System.Drawing.Point(16, 8);
      this.lblNote.Name = "lblNote";
      this.lblNote.Size = new System.Drawing.Size(344, 24);
      this.lblNote.TabIndex = 2;
      this.lblNote.Text = "Insert a bit of text and turn it into something unreadable.";
      // 
      // mnuSecretService
      // 
      this.mnuSecretService.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                     this.mnuFile});
      // 
      // frmSecretText
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(392, 277);
      this.Controls.Add(this.txtNote);
      this.Controls.Add(this.lblNote);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mnuSecretService;
      this.Name = "frmSecretText";
      this.Text = "Secret text";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSecretText'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSecretText()
      //***
      // Action
      //   - Create instance of 'frmSecretText'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void mnuFileClose_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the state of the program back to the starting point
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtNote.Text = "";
      lblNote.Text = "Insert a bit of text and turn it into something unreadable.";
      mnuFileClose.Enabled = false;
      mnuFileOpen.Enabled = true;    
    }
    // mnuFileClose_Click(System.Object, System.EventArgs) Handles mnuFileClose.Click

    private void mnuFileExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Close the application
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // mnuFileExit_Click(System.Object, System.EventArgs) Handles mnuFileExit.Click

    private void mnuFileInsertDate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the date at beginning of the text
      //   - Set cursor at starting point
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtNote.Text = DateTime.Now.ToString("dd/MM/yyyy") + Environment.NewLine + txtNote.Text;
      txtNote.Select(0, 0);
    }
    // mnuFileInsertDate_Click(System.Object, System.EventArgs) Handles mnuFileInsertDate.Click

    private void mnuFileOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Initialize the file open screen
      //     - Filter by text files
      //     - Folder is current directory
      //   - Show the dialog
      //   - If clicked on OK Button
      //     - If there is a filename
      //       - Try to open the file
      //         - Read every character till end
      //           - Generate a string that contains the text
      //         - Count the number of characters
      //         - Loop thru all characters
      //           - Determine the ASCII code
      //             - When part of enter, character stays unchanged in decryption
      //             - When not, character gets 1 ascii code less in decryption
      //         - Decryption is shown on screen
      //         - Filename is shown on screen
      //         - Cursor is placed at the start of the text
      //         - Text is enabled
      //         - File close is enabled
      //         - File open is disabled
      //       - On error an error is shown
      //       - File is closed
      //     - If not
      //       - Do nothing
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      byte[] arrBytes;
      int lngCharactersInFile;
      int lngCounter;
      StreamReader strReader = null;
      string strAllText = "";
      string strDecrypt = "";
      string strEnter1 = ((char)(10)).ToString();
      string strEnter2 = ((char)(13)).ToString();
      string strLetter;
      string strLineOfText;

      dlgFileOpen.Filter = "Text files (*.TXT)|*.TXT";
      dlgFileOpen.InitialDirectory = Environment.CurrentDirectory;

      if (dlgFileOpen.ShowDialog() == DialogResult.OK)
      {

        if (dlgFileOpen.FileName == "")
        {
        }
        else
          // dlgFileOpen.FileName <> ""
        {
          
          try
          {
            strReader = new StreamReader(dlgFileOpen.FileName);

            while (strReader.Peek() > 0)
            {
              strLineOfText = strReader.ReadLine();
              strAllText = strAllText + strLineOfText + Environment.NewLine;
            }
            // strReader.Peek() = 0
            
            lngCharactersInFile = strAllText.Length;
            
            for (lngCounter = 0; lngCounter < lngCharactersInFile; lngCounter++)
            {
            
              strLetter = strAllText.Substring(lngCounter, 1);
              
              if ((strLetter == strEnter1) || (strLetter == strEnter2))
              {
                strDecrypt = strDecrypt + strLetter;
              }
              else
                // ((strLetter <> strEnter1) AndAlso (strLetter <> strEnter2))
              {
                arrBytes = Encoding.ASCII.GetBytes(strLetter);
                strDecrypt = strDecrypt + (char)(arrBytes[0] - 1);
              }
              // ((strLetter = strEnter1) OrElse (strLetter = strEnter2))

            }
            // lngCounter = lngCharactersInFile

            txtNote.Text = strDecrypt;
            lblNote.Text = dlgFileOpen.FileName;
            txtNote.Select(0, 0);
            txtNote.Enabled = true;
            mnuFileClose.Enabled = true;
            mnuFileOpen.Enabled = false;
          }
          catch
          {
            MessageBox.Show("Problems with opening the file.");
          }
          finally
          {
            strReader.Close();
          }

        }
        // dlgFileOpen.FileName = ""

      }
      else
        // dlgFileOpen.ShowDialog() <> DialogResult.OK
      {
      }
      // dlgFileOpen.ShowDialog() = DialogResult.OK 
    
    }
    // mnuFileOpen_Click(System.Object, System.EventArgs) Handles mnuFileOpen.Click

    private void mnuFileSaveAs_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Initialize the file save screen
      //     - Filter by text files
      //     - Folder is current directory
      //   - Show the dialog
      //   - If clicked on OK Button
      //     - If there is a filename
      //       - Try to open the file
      //         - Read every character till end
      //           - Generate a string that contains the text
      //         - Count the number of characters
      //         - Loop thru all characters
      //           - Determine the ASCII code
      //             - When part of enter, character stays unchanged in encryption
      //             - When not, character gets 1 ascii code more in encryption
      //         - File is opened for output
      //         - Encryption is written to file
      //         - File is closed
      //         - Encryption is shown to the screen
      //         - Cursor is put at the start
      //         - File close is enabled
      //     - If not
      //       - Do nothing
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      byte[] arrBytes;
      int lngCharactersInFile;
      int lngCounter;
      StreamWriter strWriter = null;
      string strEncrypt = "";
      string strEnter1 = ((char)(10)).ToString();
      string strEnter2 = ((char)(13)).ToString();
      string strLetter;

      dlgFileSave.Filter = "Text files (*.txt)|*.txt";
      dlgFileSave.InitialDirectory = Environment.CurrentDirectory;

      if (dlgFileSave.ShowDialog() == DialogResult.OK)
      {
        
        if (dlgFileSave.FileName == "")
        {
        }
        else
          // dlgFileSave.FileName <> ""
        {
          lngCharactersInFile = txtNote.Text.Length;
        
          for (lngCounter = 0; lngCounter < lngCharactersInFile; lngCounter++)
          {
            strLetter = txtNote.Text.Substring(lngCounter, 1);
            
            if ((strLetter == strEnter1) || (strLetter == strEnter2))
            {
              strEncrypt = strEncrypt + strLetter;
            }
            else
              // ((strLetter <> strEnter1) AndAlso (strLetter <> strEnter2))
            {
              arrBytes = Encoding.ASCII.GetBytes(strLetter);
              strEncrypt = strEncrypt + (char)(arrBytes[0] + 1);
            }
            // ((strLetter = strEnter1) OrElse (strLetter = strEnter2))

          }
          // lngCounter = lngCharactersInFile 
        
          strWriter = new StreamWriter(dlgFileSave.FileName);
          strWriter.Write(strEncrypt);
          strWriter.Flush();
          strWriter.Close();
          txtNote.Text = strEncrypt;
          txtNote.Select(0, 0);
          mnuFileClose.Enabled = true;
          mnuFileOpen.Enabled = false;
        }
        // dlgFileSave.FileName = ""

      }
      else
        // dlgFileSave.ShowDialog() <> DialogResult.OK
      {
      }
      // dlgFileSave.ShowDialog() = DialogResult.OK
    
    }
    // mnuFileSaveAs_Click(System.Object, System.EventArgs) Handles mnuFileSaveAs.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSecretText
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSecretText()
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSecretText());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSecretText

}
// CopyPaste.Learning