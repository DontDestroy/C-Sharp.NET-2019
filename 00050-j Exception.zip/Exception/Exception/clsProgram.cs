//***
// Action
//   - Demo of different kind of exceptions
// Created
//   - CopyPaste � 20230808 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230808 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Start 2 the same methods, but with a different exception 
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Test01()
      //   - Test02()
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Test01();
      Test02();
    }
    // Main()

    public static void Test01()
      //***
      // Action
      //   - Try to do something that will fail
      //   - Show the exception
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        string strFileNameFrom;
        string strFileNameTo = null;

        strFileNameFrom = "C:\\Test.xml";
        
        FileSystem.FileCopy(strFileNameFrom, strFileNameTo);
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }

    }
    // Test01()

    public static void Test02()
      //***
      // Action
      //   - Try to do something that will fail
      //   - Show the argument exception
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        string strFileNameFrom;
        string strFileNameTo = null;

        strFileNameFrom = "C:\\Test.xml";
        
        FileSystem.FileCopy(strFileNameFrom, strFileNameTo);
      }
      catch (ArgumentException theException)
      {
        MessageBox.Show(theException.Message + " Parameter: " + theException.ParamName);
      }

    }
    // Test02()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning