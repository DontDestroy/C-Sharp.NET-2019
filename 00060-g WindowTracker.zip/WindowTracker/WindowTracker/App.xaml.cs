//***
// Action
//   - Code for the application that contains the wpfStartupScreen
// Created
//   - CopyPaste � 20220817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220817 � VVDW
// Proposal (To Do)
//   -
//***

using System.Collections.Generic;
using System.Windows;

namespace WindowTracker
{

  public partial class App : Application
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private List<wpfWindow> lstWindows = new List<wpfWindow>();

    #endregion

    #region "Properties"

    public List<wpfWindow> StartedWindows
    {
     
      get
      //***
      // Action Get
      //   - Returns the list of started Windows
      // Called by
      //   - cmdCreate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCreate.Click
      //   - cmdUpdate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdUpdate.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return lstWindows; 
      }
      // List<wpfWindow> StartedWindows (Get)

      set
      //***
      // Action Set
      //   - The list of started windows is defined
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        lstWindows = value; 
      }
      // StartedWindows(List<wpfWindow>) (Set)

    }
    // List<wpfWindow> startedWindows

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // App

}
// WindowTracker