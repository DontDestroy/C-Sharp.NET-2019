//***
// Action
//   - Testroutine for cpClasses and cpOneClass
// Created
//   - CopyPaste � 20240124 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240124 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning{

  /// <summary>
  /// Form where class cpClasses and cpOneClass are tested
  /// </summary>
	public class frmCodeAnalysis: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.OpenFileDialog dlgOpenSourceFile;
    internal System.Windows.Forms.Label lblLinesOfCode;
    internal System.Windows.Forms.Button cmdBrowse;
    internal System.Windows.Forms.DataGrid dgrFiles;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCodeAnalysis));
      this.dlgOpenSourceFile = new System.Windows.Forms.OpenFileDialog();
      this.lblLinesOfCode = new System.Windows.Forms.Label();
      this.cmdBrowse = new System.Windows.Forms.Button();
      this.dgrFiles = new System.Windows.Forms.DataGrid();
      ((System.ComponentModel.ISupportInitialize)(this.dgrFiles)).BeginInit();
      this.SuspendLayout();
      // 
      // lblLinesOfCode
      // 
      this.lblLinesOfCode.Location = new System.Drawing.Point(94, 234);
      this.lblLinesOfCode.Name = "lblLinesOfCode";
      this.lblLinesOfCode.Size = new System.Drawing.Size(192, 23);
      this.lblLinesOfCode.TabIndex = 5;
      this.lblLinesOfCode.Text = "Lines of code";
      // 
      // cmdBrowse
      // 
      this.cmdBrowse.Location = new System.Drawing.Point(6, 234);
      this.cmdBrowse.Name = "cmdBrowse";
      this.cmdBrowse.TabIndex = 4;
      this.cmdBrowse.Text = "Browse";
      this.cmdBrowse.Click += new System.EventHandler(this.cmdBrowse_Click);
      // 
      // dgrFiles
      // 
      this.dgrFiles.DataMember = "";
      this.dgrFiles.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrFiles.Location = new System.Drawing.Point(6, 10);
      this.dgrFiles.Name = "dgrFiles";
      this.dgrFiles.Size = new System.Drawing.Size(280, 216);
      this.dgrFiles.TabIndex = 3;
      // 
      // frmCodeAnalysis
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.Add(this.cmdBrowse);
      this.Controls.Add(this.dgrFiles);
      this.Controls.Add(this.lblLinesOfCode);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCodeAnalysis";
      this.Text = "Code Analysis";
      ((System.ComponentModel.ISupportInitialize)(this.dgrFiles)).EndInit();
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

    /// <summary>
    /// Code executed when form is not used anymore
    /// </summary>
    /// <param name="disposing">To dispose all components in the form, set true</param>
    protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmCodeAnalysis'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240124 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240124 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

    /// <summary>
    /// Constructor of frmCodeAnalysis
    /// </summary>
    public frmCodeAnalysis()
			//***
			// Action
			//   - Create instance of 'frmCodeAnalysis'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240124 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240124 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmCodeAnalysis()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

    private cpClasses mcpClass = new cpClasses();

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"
    
    private void cmdBrowse_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to do something
      //     - Show a file open dialog
      //     - If you click OK (or corresponding button)
      //       - Read from a file using the method from the class cpClasses
      //     - Display the class
      //   - When it fails
      //     - Show an error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpClasses.ReadFromFile(string)
      //   - DisplayClass()
      // Created
      //   - CopyPaste � 20240124 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240124 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        DialogResult dlgResult;
        
        dlgOpenSourceFile.Filter = "C# files (*.cs)|*.cs";
        dlgResult = dlgOpenSourceFile.ShowDialog();

        if (dlgResult == DialogResult.OK)
        {
          mcpClass.ReadFromFile(dlgOpenSourceFile.FileName);
        }
        else
          // dlgResult <> DialogResult.OK
        {
        }
        // dlgResult = DialogResult.OK

        DisplayClass();
      }
      catch (System.Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
    
    }
    // cmdBrowse_Click(System.Object, System.EventArgs) Handles cmdBrowse.Click

    #endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

    private void DisplayClass()
      //***
      // Action
      //   - Make an array of cpOneClass
      //   - Loop thru all the classes with a counter 'lngCounter'
      //     - The 'lngCounter' element of mcpClass becomes the element in the array
      //   - Refresh the datagrid
      //   - Show the lines of code
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpClass.ReadFromFile(string)
      //   - cpOneClass cpClasses.this(int) (Get)
      //   - DisplayClass()
      //   - int cpClasses.Count() (Get)
      //   - int cpClass.LinesOfCode (Get)
      // Created
      //   - CopyPaste � 20240124 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240124 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngCounter;
      cpOneClass[] arrcpOneClass = new cpOneClass[mcpClass.Count];

      for(lngCounter = 0; lngCounter <= mcpClass.Count - 1; lngCounter++)
      {
        arrcpOneClass[lngCounter] = mcpClass[lngCounter];
      }
      // lngCounter = mcpClass.Count
      
      dgrFiles.DataSource = arrcpOneClass;
      lblLinesOfCode.Text = "Lines of code:" + mcpClass.LinesOfCode.ToString();
  }
    // DisplayClass()

    [STAThreadAttribute]
		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmCodeAnalysis
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmCodeAnalysis()
			// Created
			//   - CopyPaste � 20240124 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240124 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmCodeAnalysis());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmCodeAnalysis

}
// CopyPaste.Learning