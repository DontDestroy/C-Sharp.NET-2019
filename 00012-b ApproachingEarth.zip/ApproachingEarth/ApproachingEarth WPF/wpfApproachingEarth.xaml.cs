﻿//***
// Action
//   - 
// Created
//   - CopyPaste – yyyymmdd – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – yyyymmdd – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ApproachingEarth_WPF
{

  public partial class wpfApproachingEarth : Window
  {

    #region "Constructors / Destructors"

    public wpfApproachingEarth()
    //***
    // Action
    //   - Create instance of 'wpfApproachingEarth'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – yyyymmdd – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – yyyymmdd – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfApproachingEarth()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void picEarth_MouseDown(System.Object theSender, System.Windows.Input.MouseButtonEventArgs theMouseButtonEventArguments)
    //***
    // Action
    //   - Change size of picture with 5 points
    // Called by
    //   - User action (Clicking a picture)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      picEarth.Height = picEarth.Height + 5;
      picEarth.Width = picEarth.Width + 5;
    }
    // picEarth_MouseDown(System.Object, System.Windows.Input.MouseButtonEventArgs) Handles picEarth.MouseDown

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfApproachingEarth

}
// ApproachingEarth_WPF