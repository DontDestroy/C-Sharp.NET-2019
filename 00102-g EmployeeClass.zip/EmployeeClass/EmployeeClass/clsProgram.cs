//***
// Action
//   - Testroutine of the clsEmployee
// Created
//   - CopyPaste � 20230419 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230419 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    {
      //***
      // Action
      //   - Define a new cpEmployee
      //   - Fill in the name
      //   - Fill in the sex
      //   - Fill in the startdate
      //   - Show the information on the screen
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - aSex cpEmployee.Sex (Get)
      //   - cpEmployee.Name(string)(Set)
      //   - cpEmployee()
      //   - cpEmployee.StartDate(Date) (Set)
      //   - cpEmployee.Sex(aSex) (Set)
      //   - DateTime cpEmployee.StartDate() (Get)
      //   - string cpEmployee.Name (Get)
      //   - TestIsNothing()
      // Created
      //   - CopyPaste � 20230419 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230419 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***

      cpEmployee thecpEmployee;

      thecpEmployee = new cpEmployee();
      // cpEmployee anEmployee = new cpEmployee();

      thecpEmployee.Name = "Vincent";
      thecpEmployee.Sex = cpEmployee.aSex.Male;
      thecpEmployee.StartDate = new DateTime(2001, 1, 1);

      Console.WriteLine(thecpEmployee.Name);
      Console.WriteLine(thecpEmployee.Sex.ToString());
      Console.WriteLine(thecpEmployee.StartDate);
      TestIsNothing();
      Console.ReadLine();
    }
    // Main()

    public static void TestIsNothing()
    //***
    // Action
    //   - Define a new cpEmployee when null
    //   - Fill in the name
    //   - Fill in the sex
    //   - Fill in the startdate
    //   - Change thecpEmployee to null
    //   - If thecpEmployee is null
    //     - Show "Employee is Nothing" when null
    //   - If Not
    //     - Show the information on the screen
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - aSex cpEmployee.Sex (Get)
    //   - cpEmployee.Name(string)(Set)
    //   - cpEmployee()
    //   - cpEmployee.StartDate(Date) (Set)
    //   - cpEmployee.Sex(aSex) (Set)
    //   - DateTime cpEmployee.StartDate() (Get)
    //   - string cpEmployee.Name (Get)
    // Created
    //   - CopyPaste � 20230419 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230419 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpEmployee thecpEmployee = null;

      if (thecpEmployee == null)
      {
        thecpEmployee = new cpEmployee();
      }
      else
        // thecpEmployee <> null
      {
      }
      // thecpEmployee = null

      thecpEmployee.Name = "Vincent";
      thecpEmployee.Sex = cpEmployee.aSex.Male;
      thecpEmployee.StartDate = new DateTime(2001, 1, 1);

      thecpEmployee = null;

      if (thecpEmployee == null)
      {
        Console.WriteLine("Employee is nothing");
      }
      else
        // thecpEmployee <> null
      {
        Console.WriteLine(thecpEmployee.Name);
        Console.WriteLine(thecpEmployee.Sex.ToString());
        Console.WriteLine(thecpEmployee.StartDate);
      }
      // thecpEmployee = null

    }
    // TestIsNothing()

    #endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// CopyPaste.Learning