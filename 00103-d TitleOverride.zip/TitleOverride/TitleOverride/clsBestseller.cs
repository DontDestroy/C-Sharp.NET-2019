//***
// Action
//   - Definition of a cpBestseller (inherits from cpBook)
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpBestseller : cpBook
  {

    #region "Constructors / Destructors"

    public cpBestseller(string strTitle,
                        string strAuthor,
                        string strPublisher,
                        double dblPrice,
                        string strList,
                        int lngPosition) : base(strTitle, strAuthor, strPublisher, dblPrice)
      // ***
      //  Action
      //    - Constructor that sets six variables
      //  Called by
      //    - cpProgram.Main()
      //  Calls
      //    - cpBook(string, string, string, double)
      //  Created
      //    - CopyPaste � 20230804 � VVDW
      //  Changed
      //    - CopyPaste � yyyymmdd � VVDW � What changed
      //  Tested
      //    - CopyPaste � 20230804 � VVDW
      //  Keyboard key
      //    - 
      //  Proposal (To Do)
      //    - 
      // ***
    {
      mstrList = strList;
      mlngPosition = lngPosition;
    }
    // cpBeststeller(string, string, string, double, string, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    public int mlngPosition;
    public string mstrList;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"
    
    public override void ShowTitle()
      //***
      // Action
      //   - Shows the information of a cpBestseller
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpBook.ShowTitle()
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      base.ShowTitle();
      Console.WriteLine("Best seller list: " + mstrList + " at # " + mlngPosition);
    }
    // ShowTitle()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBestseller

}
// CopyPaste.Learning