﻿//***
// Action
//   - Check the validations on a Belgian bank account
//   - The code was created when the Belgian bank account had this format
//     - 012-3456789-01 format
//   - In the mean time it is changed, but this proves the advantage of working this way
//     - I only need to change the code at one place (this class)
// Created
//   - CopyPaste – 20260121 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260121 – VVDW
// Proposal (To Do)
//   - Not used in program, just for explanation
//***

namespace CopyPaste.Learning
{

  public class cpCheckBelgianBankAccount: cpCheckString
  {

    #region "Constructors / Destructors"

    public cpCheckBelgianBankAccount(cpCheckBelgianBankAccount theBelgianBankAccount) : this(theBelgianBankAccount.StringValue)
      //***
      // Action
      //   - Define a new instance with a given check Belgian bank account
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - cpCheckBelgianBankAccount(string)
      //   - string cpCheckBelgianBankAccount.StringValue() (Get)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpCheckPhoneNumber()

    public cpCheckBelgianBankAccount(string strBelgianBankAccount) : base()
      //***
      // Action
      //   - Define a new instance with a given string
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - cpCheckBelgianBankAccount(cpCheckPhoneNumber)
      //   - cpCheckPhoneNumber.StringValue(string) (Set)
      //   - cpCheckString.(string)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      StringValue = strBelgianBankAccount;
    }
    // cpCheckBelgianBankAccount(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void DefineValidCharacters()
      //***
      // Action
      //   - Define the valid characters for a belgian bank account
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      marrchrValid = new string[] {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "-"};
    }
    // DefineValidCharacters()

    public override bool IsValid(string strBelgianBankAccount)
      //***
      // Action
      //   - Check on the valid rules of the parent (cpCheckString)
      //   - If valid
      //     - Check the current rules (cpBelgianBankAccount)
      //     - If there is a hyphen on the third position
      //       - If there is a hyphen on the eleventh position
      //         - It is a valid Belgian bank account
      //       - If not
      //         - It is not a valid Belgian bank account
      //     - If not
      //       - It is not a valid Belgian bank account
      //   - If not
      //     - It is not a valid Belgian bank account
      // Called by
      //   - 
      // Calls
      //   - bool cpCheckString.IsValid(string)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult = false;

      if (base.IsValid(strBelgianBankAccount))
      {
        System.Int32 intFirstHyphenPosition = strBelgianBankAccount.IndexOf("-");

        if (intFirstHyphenPosition == 3)
        {

          if (strBelgianBankAccount.IndexOf("-", 0, 2) == 11)
          {
            blnResult = true;
          }
          else
            // strBelgianBankAccount.IndexOf("-", 0, 2) <> 11
          {
            blnResult = false;
          }
          // strBelgianBankAccount.IndexOf("-", 0, 2) = 11
        
        }
        else
          // intFirstHyphenPosition <> 3
        {
          blnResult = false;
        }
        // intFirstHyphenPosition = 3

      }
      else
        // Not this.IsValid(strBelgianBankAccount)
      {
      }
      // this.IsValid(strBelgianBankAccount)

      return blnResult;
    }
    // bool IsValid(string)

    protected override cpInvalidStringException ThrowException(string strInvalidBelgianBankAccount)
      //***
      // Action
      //   - Throw an exception with information
      // Called by
      //   - 
      // Calls
      //   - cpInvalidBelgianBankAccountException(string)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      throw new cpInvalidBelgianBankAccountException(strInvalidBelgianBankAccount);
    }
    // cpInvalidStringException ThrowException(string)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
   	//#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCheckBelgianBankAccount

}
// CopyPaste.Learning