﻿//***
// Action
//   - Check the validations on a business phone number
// Created
//   - CopyPaste – 20260121 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260121 – VVDW
// Proposal (To Do)
//   - Not used in program, just for explanation
//***

namespace CopyPaste.Learning
{

  public class cpCheckBusinessPhoneNumber: cpCheckPhoneNumber
  {

    #region "Constructors / Destructors"

    public cpCheckBusinessPhoneNumber(cpCheckBusinessPhoneNumber theBusinessPhone) : this(theBusinessPhone.StringValue, new cpCheckExtension(theBusinessPhone.Extension.StringValue))
      //***
      // Action
      //   - Define a new instance with a given check business phone number
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - cpCheckExtension cpCheckBusinessPhoneNumber.Extension (Get)
      //   - cpCheckExtension(cpCheckPhoneNumber)
      //   - string cpCheckString.StringValue (Get)
      //   - cpCheckBusinessPhoneNumber(string, cpCheckExtension)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpCheckBusinessPhoneNumber(cpCheckBusinessPhoneNumber)

    public cpCheckBusinessPhoneNumber(string strPhoneNumber, cpCheckExtension thecpExtension): base(strPhoneNumber)
      //***
      // Action
      //   - Define a new instance with a given phone number and a given cpCheckExtension
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - cpCheckPhoneNumber(string)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpCheckBusinessPhoneNumber(string, cpCheckExtension)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public cpCheckExtension Extension
    {
      
      get
        //***
        // Action Get
        //   - Return 'mcpExtension'
        // Called by
        //   - cpCheckBusinessPhoneNumber(cpCheckPhoneNumber)
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return null;
      }
      // cpCheckExtension Extension (Get)

      set
        //***
        // Action Set
        //   - mcpExtension becomes theValue
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // Extension(cpCheckExtension) (Set)

    }
    // cpCheckExtension Extension

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Define the string to return by default
      //   - If the length of string value of the extension is larger than zero
      //     - Return the string value (of the phone) with the string value of the extension between ()
      //   - If not
      //     - Return the string value (of the phone) with no extension
      // Called by
      //   - 
      // Calls
      //   - cpCheckExtension Extension (Get)
      //   - string cpCheckString.StringValue (Get)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "";
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
		//#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCheckBusinessPhoneNumber

}
// CopyPaste.Learning