﻿//***
// Action
//   - A definition of a RemoveBeepersTillWallError02
// Created
//   - CopyPaste – 20251025 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251025 – VVDW
// Proposal (To Do)
//   - The example is not correct, a beeper is forgotten to be taken
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpRemoveBeepersTillWallError02 : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpRemoveBeepersTillWallError02(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpRemoveBeepersTillWallError02 starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpProgram.RemoveBeepersTillWallError02()
    //   - cpRemoveBeepersTillWallError02(int, int, Directions.Direction, int)
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRemoveBeepersTillWallError02(int, int, Directions.Direction, int, Color) 

    public cpRemoveBeepersTillWallError02(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpRemoveBeepersTillWallError02 starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpRemoveBeepersTillWallError02(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRemoveBeepersTillWallError02(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void RemoveBeepersTillWall()
    //***
    // Action
    //   - A row of beepers will be removes
    //   - As long the front is clear
    //     - Move
    //     - Pick beeper
    // Called by
    //   - cpProgram.RemoveBeepersTillWallError02()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (frontIsClear())
      {
        pickBeeper();
        move();
      }
      // frontIsClear()

    }
    // RemoveBeepersTillWall()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpRemoveBeepersTillWallError02

}
// cpKarelTheRobot