//***
// Action
//   - Demo of 3 buttons on a form
// Created
//   - CopyPaste � 20240221 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240221 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmColor: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdGreen;
    internal System.Windows.Forms.Button cmdBlue;
    internal System.Windows.Forms.Button cmdRed;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmColor));
      this.cmdGreen = new System.Windows.Forms.Button();
      this.cmdBlue = new System.Windows.Forms.Button();
      this.cmdRed = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdGreen
      // 
      this.cmdGreen.BackColor = System.Drawing.Color.Green;
      this.cmdGreen.Location = new System.Drawing.Point(104, 16);
      this.cmdGreen.Name = "cmdGreen";
      this.cmdGreen.TabIndex = 4;
      this.cmdGreen.Text = "&Green";
      this.cmdGreen.Click += new System.EventHandler(this.cmdGreen_Click);
      // 
      // cmdBlue
      // 
      this.cmdBlue.BackColor = System.Drawing.Color.Blue;
      this.cmdBlue.Location = new System.Drawing.Point(192, 16);
      this.cmdBlue.Name = "cmdBlue";
      this.cmdBlue.TabIndex = 5;
      this.cmdBlue.Text = "&Blue";
      this.cmdBlue.Click += new System.EventHandler(this.cmdBlue_Click);
      // 
      // cmdRed
      // 
      this.cmdRed.BackColor = System.Drawing.Color.Red;
      this.cmdRed.ForeColor = System.Drawing.SystemColors.ControlText;
      this.cmdRed.Location = new System.Drawing.Point(16, 16);
      this.cmdRed.Name = "cmdRed";
      this.cmdRed.TabIndex = 3;
      this.cmdRed.Text = "&Red";
      this.cmdRed.Click += new System.EventHandler(this.cmdRed_Click);
      // 
      // frmColor
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(282, 273);
      this.Controls.Add(this.cmdGreen);
      this.Controls.Add(this.cmdBlue);
      this.Controls.Add(this.cmdRed);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmColor";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Color Example";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmColor'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmColor()
      //***
      // Action
      //   - Create instance of 'frmColor'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmColor()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdBlue_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the backcolor of the screen to blue
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.BackColor = Color.Blue;
    }
    // cmdBlue_Click(System.Object theSender, System.EventArgs theEventArguments) Handling cmdBlue.Click

    private void cmdGreen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the backcolor of the screen to green
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.BackColor = Color.Green;
    }
    // cmdGreen_Click(System.Object theSender, System.EventArgs theEventArguments) Handling cmdGreen.Click

    private void cmdRed_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the backcolor of the screen to red
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.BackColor = Color.Red;
    }
    // cmdRed_Click(System.Object theSender, System.EventArgs theEventArguments) Handling cmdRed.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmColor
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmColor());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmColor

}
// CopyPaste.Learning