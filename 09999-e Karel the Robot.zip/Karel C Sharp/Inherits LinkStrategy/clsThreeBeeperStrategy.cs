﻿//***
// Action
//   - Implementation of a ThreeBeeperStrategy
// Created
//   - CopyPaste – 20251106 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251106 – VVDW
// Proposal (To Do)
//   -
//***

using kareltherobot;

namespace cpKarelTheRobot
{

  public class cpThreeBeeperStrategy : cpLinkStrategy
  {

    #region "Constructors / Destructors"

    public cpThreeBeeperStrategy(cpinfStrategy theStrategy) : base(theStrategy)
    //***
    // Action
    //   - Constructor of the start situation
    //   - Constructor of parent is used
    // Called by
    //   -
    // Calls
    //   - cpLinkStrategy(cpinfStrategy)
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpThreeBeeperStrategy (cpinfStrategy)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override void DoIt(cpCopyPasteRobot aRobot)
    //***
    // Action
    //   - Implementation of DoIt
    //     - Parent functionality is executed
    //     - Put three beepers at the current location
    //   - First do the already given, then do the three put beepers
    // Called by
    //   - cpinfStrategy.DoIt(cpCopyPasteRobot)
    // Calls
    //   - cpinfStrategy.DoIt(cpCopyPasteRobot)
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      base.DoIt(aRobot);
      aRobot.putBeeper();
      aRobot.putBeeper();
      aRobot.putBeeper();
    }
    // DoIt(cpCopyPasteRobot)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpThreeBeeperStrategy 

}
// cpKarelTheRobot