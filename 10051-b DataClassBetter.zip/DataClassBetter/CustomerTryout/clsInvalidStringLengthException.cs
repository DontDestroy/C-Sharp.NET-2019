﻿//***
// Action
//   - Check the validations on the length of a string
// Created
//   - CopyPaste – 20260121 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260121 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpInvalidStringLengthException: System.ApplicationException
  {

    #region "Constructors / Destructors"

    public cpInvalidStringLengthException(System.Int32 lngMaximumLength, string strPropertyName, string strValue):
      base("The value specified, " + strValue + ", exceeds the maximum length of " +
            lngMaximumLength + " allowable by the " + strPropertyName + " property.")
      //***
      // Action
      //   - Define the error message
      // Called by
      //   - cpCustomer.Address(string) (Set)
      //   - cpCustomer.City(string) (Set)
      //   - cpCustomer.CompanyName(string) (Set)
      //   - cpCustomer.ContactName(string) (Set)
      //   - cpCustomer.ContactTitle(string) (Set)
      //   - cpCustomer.Country(string) (Set)
      //   - cpCustomer.PostalCode(string) (Set)
      //   - cpCustomer.Region(string) (Set)
      //   - mtheFax_StringValueBeforeUpdate(string, °bool) Handles mtheFax.StringValueBeforeUpdate
      //   - mthePhone_StringValueBeforeUpdate(String, °bool) Handles mthePhone.StringValueBeforeUpdate
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpInvalidStringLengthException(System.Int32, string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public System.Int32 MaximumLength
    {

      get
        //***
        // Action Get
        //   - Return 'mlngMaximumLength'
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return 0;
      }
      // System.Int32 MaximumLength (Get)

    }
    // System.Int32 MaximumLength

    public System.Int32 MinimumLength
    {

      get
        //***
        // Action Get
        //   - Return 'mlngMinimumLength'
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return 0;
      }
      // System.Int32 MinimumLength (Get)

    }
    // System.Int32 MaximumLength

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
		//#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpInvalidStringLengthException

}
// CopyPaste.Learning