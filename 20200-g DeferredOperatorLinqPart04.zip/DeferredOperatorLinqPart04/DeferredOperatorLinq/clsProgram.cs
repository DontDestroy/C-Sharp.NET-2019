﻿//***
// Action
//   - Demo of Joining with Linq
//   - Keyword Join
//   - Keyword GroupJoin
// Created
//   - CopyPaste – 20230502 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230502 – VVDW
// Proposal (To Do)
//   -
//***

using AmericanHistory;
using CopyPaste.HumanResources;
using System;
using System.Diagnostics;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeferredOperatorLinq
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void GroupJoinTwoSequences()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Joining operators return an output sequence of elements that are two input sequences combined
    //     - The input sequences are of the form IEnumerable<T>
    //       - There is an outer sequence and an inner sequence
    //     - The output sequence is of the form IEnumerable<T>
    //   - GroupJoin has 2 overloads (only one is in the example)
    //     - Return the elements of an outer collection using a keySelector delegate and an inner collection grouped using a keySelector delegate into a sequence
    //   - Fill an array with employees (original an old school arraylist) (the outer collection)
    //   - Fill an array with investments (original an array) (the inner collection)
    //   - GroupJoin the employees with the corresponding investments grouped (Lambda Linq Dot Notation)
    //   - Show result 
    //   - GroupJoin the employees wiht the corresponding investments grouped (Linq Fluent Syntax Query Expression)
    //   - Show result 
    // Called by
    //   - Main()
    // Calls
    //   - ArrayList cpCompany.AllEmployees (Get)
    //   - cpCompany(string)
    //   - cpInvestment[] cpCompany.AllInvestments (Get)
    //   - int cpEmployee.EmployeeNumber (Get)
    //   - int cpInvestment.EmployeeNumber (Get)
    //   - long cpInvestment.Amount (Get)
    //   - ShowContentOfSequence<T>(IEnumerable<T>, string)
    //   - string cpEmployee.Name (Get)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpCompany theCopyPasteCompany;
      cpEmployee[] arrCopyPasteEmployees;
      cpInvestment[] arrCopyPasteInvestments;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      theCopyPasteCompany = new cpCompany("Copy Paste");

      arrCopyPasteEmployees = (cpEmployee[])theCopyPasteCompany.AllEmployees.ToArray(typeof(cpEmployee));
      // This is done because AllEmployees is an ArrayList (does not inherit from IEnumarable<T>)
      // ArrayList is an old school Data Type in C# (before Linq existed)
      arrCopyPasteInvestments = theCopyPasteCompany.AllInvestments;

      var colResultLambda = arrCopyPasteEmployees    // Outer sequence
        .GroupJoin(arrCopyPasteInvestments,          // Inner sequence
        anEmployee => anEmployee.EmployeeNumber,     // Outer KeySelector
        anInvestment => anInvestment.EmployeeNumber, // Inner KeySelector
        (anEmployee, theInvestments) => new          // Joining both in an anonymous Data type
        {
          EmployeeNumber = anEmployee.EmployeeNumber,
          Name = anEmployee.Name,
          Amount = theInvestments.Sum(anInvestment => anInvestment.Amount)
        });

      // GroupJoin takes two input sequences with corresponding selector delegates, and returns an object that, when enumerated,
      // enumerates the inner sequence, using the inner key selector for every element in the sequence and stores this in a hash table,
      // referenced by its key
      // Next the returned object enumerates the outer sequence, using the inner key selector for every element in the sequence
      // and retrieve the matching inner sequence elements from the hash table using that key
      // A resultSelector creates a new, possible anonymous, object, using every outer element and a list of corresponding inner elements,
      // and will build up the result sequence (with an aggregate methods for making group (not a deferred query operator)
      // GroupJoin is an extension method, so we use it on an instance of a sequence that is enumerable (arrCopyPasteEmployees)
      // GroupJoin is changing or creating a whole new element (can be anonymous) back into the result sequence

      ShowContentOfSequence(colResultLambda, "The list of all employees with the sum of their investments: (Lambda Linq Dot Notation)");

      var colResultExpression = from anEmployee in arrCopyPasteEmployees
                                join anInvestment in arrCopyPasteInvestments
                                on anEmployee.EmployeeNumber equals anInvestment.EmployeeNumber into theInvestments
                                select new { EmployeeNumber = anEmployee.EmployeeNumber, Name = anEmployee.Name, Amount = theInvestments.Sum(anInvestment => anInvestment.Amount)};

      Console.WriteLine();
      ShowContentOfSequence(colResultExpression, "The list of all employees with their investments: (Linq Fluent Syntax Query Expression)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // GroupJoinTwoSequences()

    public static void JoinTwoSequences()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Joining operators return an output sequence of elements that are two input sequences combined
    //     - The input sequences are of the form IEnumerable<T>
    //       - There is an outer sequence and an inner sequence
    //     - The output sequence is of the form IEnumerable<T>
    //   - Join has 2 overloads (only one is in the example)
    //     - Return the elements of an outer collection using a keySelector delegate and an inner collection using a keySelector delegate into a sequence
    //   - Fill an array with employees (original an old school arraylist) (the outer collection)
    //   - Fill an array with investments (original an array) (the inner collection)
    //   - Join the employees with the corresponding investments (Lambda Linq Dot Notation)
    //   - Show result 
    //   - Join the employees wiht the corresponding investments (Linq Fluent Syntax Query Expression)
    //   - Show result 
    // Called by
    //   - Main()
    // Calls
    //   - ArrayList cpCompany.AllEmployees (Get)
    //   - cpCompany(string)
    //   - cpInvestment[] cpCompany.AllInvestments (Get)
    //   - int cpEmployee.EmployeeNumber (Get)
    //   - int cpInvestment.EmployeeNumber (Get)
    //   - long cpInvestment.Amount (Get)
    //   - ShowContentOfSequence<T>(IEnumerable<T>, string)
    //   - string cpEmployee.Name (Get)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpCompany theCopyPasteCompany;
      cpEmployee[] arrCopyPasteEmployees;
      cpInvestment[] arrCopyPasteInvestments;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      theCopyPasteCompany = new cpCompany("Copy Paste");

      arrCopyPasteEmployees = (cpEmployee[])theCopyPasteCompany.AllEmployees.ToArray(typeof(cpEmployee));
      // This is done because AllEmployees is an ArrayList (does not inherit from IEnumarable<T>)
      // ArrayList is an old school Data Type in C# (before Linq existed)
      arrCopyPasteInvestments = theCopyPasteCompany.AllInvestments;

      var colResultLambda = arrCopyPasteEmployees    // Outer sequence
        .Join(arrCopyPasteInvestments,               // Inner sequence
        anEmployee => anEmployee.EmployeeNumber,     // Outer KeySelector
        anInvestment => anInvestment.EmployeeNumber, // Inner KeySelector
        (anEmployee, anInvestment) => new            // Joining both in an anonymous Data type
        {
          EmployeeNumber = anEmployee.EmployeeNumber,
          Name = anEmployee.Name,
          DatePayment = anInvestment.DatePayment,
          Amount = anInvestment.Amount
        });

      // Join takes two input sequences with corresponding selector delegates, and returns an object that, when enumerated,
      // enumerates the inner sequence, using the inner key selector for every element in the sequence and stores this in a hash table,
      // referenced by its key
      // Next the returned object enumerates the outer sequence, using the inner key selector for every element in the sequence
      // and retrieve the matching inner sequence elements from the hash table using that key
      // A resultSelector creates a new, possible anonymous, object, using every pair of found elements, and will build up the result sequence
      // Join is an extension method, so we use it on an instance of a sequence that is enumerable (arrCopyPasteEmployees)
      // Join is changing or creating a whole new element (can be anonymous) back into the result sequence

      ShowContentOfSequence(colResultLambda, "The list of all employees with their investments: (Lambda Linq Dot Notation)");

      var colResultExpression = from anEmployee in arrCopyPasteEmployees 
                                join anInvestment in arrCopyPasteInvestments
                                on anEmployee.EmployeeNumber equals anInvestment.EmployeeNumber
                                select new { EmployeeNumber = anEmployee.EmployeeNumber, Name = anEmployee.Name, DatePayment = anInvestment.DatePayment, Amount = anInvestment.Amount };

      Console.WriteLine();
      ShowContentOfSequence(colResultExpression, "The list of all employees with their investments: (Linq Fluent Syntax Query Expression)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // JoinTwoSequences()

    public static void Main()
    //***
    // Action
    //   - Study the methods in order
    //   - Try to experiment, your own location to try things out
    //   - Join two sequences with a key that is in both sequences
    //   - Join two sequences with a key that is in both sequences but with a mathematical operator
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - GroupJoinTwoSequences()
    //   - JoinTwoSequences()
    //   - TryToExperiment()
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      TryToExperiment();
      // JoinTwoSequences();
      // GroupJoinTwoSequences();
      Console.ReadLine();
    }
    // Main()

    private static void ShowContentOfSequence<T>(IEnumerable<T> colSequence, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type T in a sequence
    // Called by
    //   - JoinTwoSequences()
    //   - GroupJoinTwoSequences()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine(strTitle);

      foreach (T anElement in colSequence)
      {
        Console.WriteLine(anElement);
      }
      // in colSequence

    }
    // ShowContentOfSequence<T>(IEnumerable<T>, string)

    public static void TryToExperiment()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Method used for experimenting
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      //  Do your stuff here

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // TryToExperiment()

    #endregion

    #endregion

    #endregion

    #region "Not used"

    private static void ShowContentOfPresidentSequence(IOrderedEnumerable<cpPresident> colSequence, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type cpPresident in a sequence
    // Called by
    //   -
    // Calls
    //   - string cpPresident.Name() (Get)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine(strTitle);

      foreach (cpPresident aPresident in colSequence)
      {
        Console.WriteLine(aPresident.Name);
      }
      // in colSequence

    }
    // ShowContentOfPresidentSequence(IOrderedEnumerable<cpPresident>, string)

    #endregion

  }
  // cpProgram

}
// DeferredOperatorLinq