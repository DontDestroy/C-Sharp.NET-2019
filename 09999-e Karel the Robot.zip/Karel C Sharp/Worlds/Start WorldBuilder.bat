t:
cd Programming Tryout\Karel the Robot
java -cp .;..\KarelJRobot.jar kareltherobot.WorldBuilder
 