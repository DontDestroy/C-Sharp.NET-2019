//***
// Action
//   - Example of calling procedures
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Payment
{

  class cpPayment
	{

    static void Main()
    //***
    // Action
    //   - Call 4 time same subroutine with other parameters
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - PrintPay(double, decimal)
    //   - string System.Console.ReadLine()
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      PrintPay(40, 10.5D);
      PrintPay(38, 21.75D);
      PrintPay(20, 13);
      PrintPay(50, 14);
      Console.ReadLine();
    }
    // Main()

    static void PrintPay(double dblHours, double dblWage)
    //***
    // Action
    //   - Calculate earnings (hours' time wage)
    //   - Show result at console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string, double)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("The payment is {0:#,##0.00} Euro", dblHours * dblWage);
    }
    // PrintPay(double, double)

  }
  // cpPayment

}
// Payment