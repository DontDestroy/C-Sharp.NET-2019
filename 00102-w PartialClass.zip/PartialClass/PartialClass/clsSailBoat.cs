﻿//***
// Action
//   - Defintion of a cpSailboat
// Created
//   - CopyPaste – 20260628 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260628 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public partial class cpSailBoat
  {

    #region "Constructors / Destructors"

    public cpSailBoat(string strType, string strModel)
    //***
    // Action
    //   - Basic constructor with 2 parameters
    //     - Type and Model
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260628 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260628 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      _strModel = strModel;
      _strType = strType;
    }
    // cpSailBoat(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string _strModel;
    private string _strType;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpSailBoat

}
// CopyPaste.Learning