﻿//***
// Action
//   - A definition of a GuardAField
// Created
//   - CopyPaste – 20251027 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251027 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpGuardAField: cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpGuardAField(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpGuardAField starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpGuardAField(int, int, Directions.Direction, int)
    //   - cpProgram.GuardAField()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpGuardAField(int, int, Directions.Direction, int, Color) 

    public cpGuardAField(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpGuardAField starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpGuardAField(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpGuardAField(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void BackUp()
    //***
    // Action
    //   - Turn 180 degrees
    //   - Move forward
    //   - Turn 180 degrees
    // Called by
    //   - FollowEdge()
    // Calls
    //   - cpCopyPasteRobot.TurnAround()
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      TurnAround();
      move();
      TurnAround();
    }
    // BackUp()

    private void FollowEdge()
    //***
    // Action
    //   - While you are next to a beeper and the front is clear
    //     - Move forward
    //   - If next to a beeper (the wall blocked the robot)
    //     - Do nothing
    //   - If not
    //     - Backup (because you moved one too far)
    // Called by
    //   - WalkPerimeter()
    // Calls
    //   - BackUp()
    //   - NextToABeeperAndFrontIsClear()
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (NextToABeeperAndFrontIsClear())
      {
        move();
      }
      // NextToABeeperAndFrontIsClear()

      if (nextToABeeper())
      {
      }
      else
      // Not nextToABeeper()
      {
        BackUp();
      }
      // nextToABeeper()

    }
    // FollowEdge()

    public void MoveToSouthEastCorner()
    //***
    // Action
    //   - Look to the South
    //   - Follow the edge (beepers of field)
    //   - Look to the East
    //   - Follow the edge (beepers of field)
    // Called by
    //   - cpProgram.GuardAField()
    // Calls
    //   - cpCopyPasteRobot.FaceEast()
    //   - cpCopyPasteRobot.FaceNorth()
    //   - cpCopyPasteRobot.FaceSouth()
    //   - FollowEdge()
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FaceSouth();
      FollowEdge();
      FaceEast();
      FollowEdge();
      FaceNorth();
    }
    // MoveToSouthEastCorner()

    public bool NextToABeeperAndFrontIsClear()
    //***
    // Action
    //   - Define a variable to store the state
    //   - If next to a beeper
    //     - Variable becomes answer of front is clear
    //   - If not
    //     - Variable becomes false
    //   - Return value of variable
    // Called by
    //   - FollowEdge()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnReturn;

      if (nextToABeeper())
      {
        blnReturn = frontIsClear();
      }
      else
      // Not nextToABeeper()
      {
        blnReturn = false;
      }
      // nextToABeeper()

      return blnReturn;
    }
    // NextToABeeperAndFrontIsClear()

    public void WalkPerimeter()
    //***
    // Action
    //   - Loop 4 times
    //     - Follow the edge
    //     - Turn left
    // Called by
    //   - cpProgram.GuardAField()
    // Calls
    //   - FollowEdge()
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      for (int countSides = 0; countSides < 4; countSides++) 
      {
        FollowEdge();
        turnLeft();
      }
      // countSides = 4

    }
    // WalkPerimeter()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpGuardAField

}
// cpKarelTheRobot