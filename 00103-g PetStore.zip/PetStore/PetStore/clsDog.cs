//***
// Action
//   - A pet store, the definition of a dog (base class, but inherits from cpPet)
//   - Working with properties (Get and Set) and methods in several classes, that can be reused
// Created
//   - CopyPaste � 20220316 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW
// Tested
//   - CopyPaste � 20220316 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace CopyPaste.Pet
{

  public class cpDog : cpPet
  {

    #region "Constructors / Destructors"

    public cpDog() : base ("Dog", 4)
    //***
    // Action
    //   - Creating an instance of cpDow with default parameters
    //   - Creating an instance of cpPet with parameters "Dog" and 4
    //   - Food becomes "Doggie chow"
    //   - Write a line "cpDog default constructor"
    // Called by
    //   - CopyPaste.Pet.Dog.cpGreatDane()
    //   - CopyPaste.Pet.Dog.cpMiniDoxen()
    // Calls
    //   - base(string, int)
    //   - CopyPaste.Pet.cpPet.Food(string) (Set)
    //   - CopyPaste.Pet.cpPet(string, int)
    // Created
    //   - CopyPaste � 20220316 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20220316 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Food = "Doggie chow";
      Console.WriteLine("cpDog default constructor");
    }
    // cpDog()

    public cpDog(string strName) : this()
    //***
    // Action
    //   - Creating an instance of cpDog with default parameters and set the name
    //   - Creating an instance of cpDog with default parameters
    //   - Name becomes strName
    //   - Write a line "cpDog overloaded constructor"
    // Called by
    //   - CopyPaste.Pet.Dog.cpGreatDane(string, string)
    //   - CopyPaste.Pet.Dog.cpMiniDoxen(string, string)
    //   - cpProgram.FillArray()
    // Calls
    //   - this()
    //   - CopyPaste.Pet.cpAnimal.Name(string) (Set)
    // Created
    //   - CopyPaste � 20220316 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20220316 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Name = strName;
      Console.WriteLine("cpDog overloaded constructor");
    }
    // cpDog(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"
    
    public override string Play()
      //***
      // Action
      //   - Write a line to the console with "CopyPaste.Pet.cpAnimal.cpDog.Play"
      //   - Return "(Name) fetches the frisbie"
      // Called by
      //   - frmPetStore.cmdPlay_Click(System.Object, System.EventArgs) Handles cmdPlay.Click
      // Calls
      //   - string CopyPaste.Pet.cpPet.Name (Get)
      //   - Overrides string CopyPaste.Pet.cpAnimal.Play()
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //  - List of actions that can be added to the functionality
      //***
    {
      Console.WriteLine("CopyPaste.Pet.cpAnimal.cpDog.Play");
      return Name + " fetches the frisbie";
    }
    // string Play()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDog

}
// CopyPaste.Pet