//***
// Action
//   - Use and loop thru an array of numbers
// Created
//   - CopyPaste � 20220119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220119 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace UseNumbers
{

  class cpUseNumbers
	{

    static void Main()
    //***
    // Action
    //   - Fill 50 items of an array with numbers
    //   - Loop thru the array
    //     - Show number at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(long)
    // Created
    //   - CopyPaste � 20220119 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220119 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long[] arrlngStudent = new long[50];
      long lngCounter;

      for (lngCounter = 0; lngCounter < 50; lngCounter++)
      {
        arrlngStudent[lngCounter] = lngCounter;
      }
      // lngCounter = 51

      for (lngCounter = 0; lngCounter < 50; lngCounter++)
      {
        Console.WriteLine(arrlngStudent[lngCounter]);
      }
      // lngCounter = 51

      Console.ReadLine();
		}
    // Main()

  }
  // cpUseNumbers

}
// UseNumbers