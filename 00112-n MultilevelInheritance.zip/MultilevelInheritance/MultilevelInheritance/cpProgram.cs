//***
// Action
//   - Testing routines for cpPerson, cpAthlete and cpAllStar
// Created
//   - CopyPaste � 20240529 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240529 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create a cpPerson
      //   - Show information about that person
      //   - Create a cpAtlete
      //   - Show information about that athlete
      //   - Create a cpAllStar
      //   - Show information about that all start
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpAllStar(string, int, string, string, double, double)
      //   - cpAthlete(string, int, string, string)
      //   - cpPerson(string, int)
      //   - string cpAllStar.ToString()
      //   - string cpAthlete.ToString()
      //   - string cpPerson.ToString()
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpAllStar thecpAllStarKobie;
      cpAthlete thecpAthlete;
      cpPerson thecpPerson;

      thecpPerson = new cpPerson("Vincent Van De Walle", 31);
      thecpAthlete = new cpAthlete("Jean-Marie Pfaff", 39, "Voetbal", "Bayern Munchen");
      thecpAllStarKobie = new cpAllStar("Kobie Bryant", 23, "Basketball", "Lakers", 25.5, 6.3);

      Console.WriteLine(thecpPerson.ToString());
      Console.WriteLine(thecpAthlete.ToString());
      Console.WriteLine(thecpAllStarKobie.ToString());
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning