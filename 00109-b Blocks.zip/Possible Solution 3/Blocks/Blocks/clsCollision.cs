//***
// Action
//   - A block game, the collision
//   - Working with properties (Get and Set) and methods in several classes, that can be used in another game
//   - Possible Solution 3
// Created
//   - CopyPaste � 20240214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240214 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.Games
{

  public class cpCollision
  {

    #region "Constructors / Destructors"

    public cpCollision(cpBlockGame thecpBlockGame)
      //***
      // Action
      //   - BlockGame becomes thecpBlockGame
      // Called by
      //  - frmBlock.frmBlock_Load(System.Object, System.EventArgs) Handles this.Load
      //  - frmMoveTest.frmMoveTest_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - BlockGame(cpBlockGame) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      BlockGame = thecpBlockGame;
    }
    // cpCollision(cpBlockGame)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpBlockGame mcpBlockGame;
    private Rectangle mrecFirstPosition;
    private Rectangle mrecSecondPosition;

    #endregion

    #region "Properties"

    public cpBlockGame BlockGame
    {

      get
        //***
        // Action Get
        //   - Return the block game (mcpBlockGame)
        // Called by
        //   - 
        // Calls
        //   - CheckHit(cpMove, cpMove, bool)
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mcpBlockGame;
      }
      // cpBlockGame BlockGame (Get)

      set
        //***
        // Action Set
        //   - Return the block game (mcpBlockGame becomes value)
        // Called by
        //   - cpCollision(cpBlockGame)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mcpBlockGame = value;
      }
      // BlockGame(cpBlockGame) (Set)

    }
    // cpBlockGame BlockGame

    public Rectangle FirstPosition
    {
      
      get
        //***
        // Action Get
        //   - Return the first rectangle (mrecFirstPosition)
        // Called by
        //   - CheckHit(cpMove, cpMove, bool)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mrecFirstPosition;
      }
      // Rectangle FirstPosition (Get)

      set
        //***
        // Action Set
        //   - Set the first rectangle (mrecFirstPosition becomes value)
        // Called by
        //   - CheckHit(cpMove, cpMove, bool)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mrecFirstPosition = value;
      }
      // FirstPosition(Rectangle) (Set)

    }
    // Rectangle FirstPosition

    public Rectangle SecondPosition
    {
      
      get
        //***
        // Action Get
        //   - Return the second rectangle (mrecSecondPosition)
        // Called by
        //   - CheckHit(cpMove, cpMove, bool)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mrecSecondPosition;
      }
      // Rectangle SecondPosition (Get)

      set
        //***
        // Action Set
        //   - Set the second rectangle (mrecSecondPosition becomes value)
        // Called by
        //   - CheckHit(cpMove, cpMove, bool)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mrecSecondPosition = value;
      }
      // SecondPosition(Rectangle) (Set)

    }
    // Rectangle SecondPosition

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void CheckHit(cpMove thecpMove01, cpMove thecpMove02, bool blnDelete)
      //***
      // Action Get
      //   - Hit thecpMove01 and thecpMove2 each other (True or False) and do you want to delete (blnDelete)
      //   - If the first moving object (the ball) is Nothing 
      //     - Return False
      //   - If Not
      //     - If the second moving object (a block) is visible
      //       - Determine the position of the ball (FirstPosition)
      //       - Determine the position of the block (SecondPosition)
      //       - If positions intersects (FirstPosition and SecondPosition overlaps)
      //         - Determine the intersection (recIntersection)
      //         - Depending on the with of recIntersection
      //           - Case larger or equal then the height of recIntersection
      //             - The ball bounces with parameter of 0 degrees (bounce will be calculated)
      //           - Case smaller then the height of recIntersection
      //             - The ball bounces with parameter of 90 degrees (bounce will be calculated)
      //           - Case else
      //             - Do Nothing
      //         - If blnDelete
      //           - Subtract 1 from NumberOfBlocks
      //         - If Not
      //           - Do Nothing
      //         - If Not
      //           - Do Nothing
      //         - Update score
      //         - Visibility of the block that was hit is set by negation blnDelete
      //       - If Not
      //         - Do Nothing
      //     - If Not
      //       - Do Nothing
      // Called by
      //   - frmBlock.CheckCollision()
      //   - frmMoveTest.CheckCollision()
      // Calls
      //   - Control cpMove.MovingObject (Get)
      //   - cpBlockGame BlockGame (Get)
      //   - cpBlockGame.UpdateScore()
      //   - cpBlockGame.NumberOfBlocks(int) (Set)
      //   - int cpBlockGame.NumberOfBlocks (Get)
      //   - cpMove.Bounce()
      //   - FirstPosition(Rectangle) (Set)
      //   - Rectangle cpMove.Boundaries (Get)
      //   - Rectangle FirstPosition (Get)
      //   - Rectangle SecondPosition (Get)
      //   - SecondPosition(Rectangle) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - When the hit is just on the corner, the behaviour of the bounce is incorrect (not implemented)
      //***
    {
      if (thecpMove01 == null)
      {
      }
      else
        // thecpMove01 <> null
      {

        if (thecpMove02.MovingObject.Visible)
        {
          FirstPosition = thecpMove01.Boundaries;
          SecondPosition = thecpMove02.Boundaries;
          
          if (FirstPosition.IntersectsWith(SecondPosition))
          {
            Rectangle recIntersection = Rectangle.Intersect(FirstPosition, SecondPosition);

            if (recIntersection.Width >= recIntersection.Height)
            {
              thecpMove01.Bounce(0);
              // thecpMove02.Bounce(0);
            }
            else if (recIntersection.Width < recIntersection.Height)
              // recIntersection.Width < recIntersection.Height
            {
              thecpMove01.Bounce(90);
              // thecpMove02.Bounce(90);
            }
            else
              // recIntersection.Width < recIntersection.Height
              // recIntersection.Width >= recIntersection.Height
            {
            }
            // recIntersection.Width >= recIntersection.Height
            // recIntersection.Width < recIntersection.Height

            if (blnDelete)
            {
              BlockGame.NumberOfBlocks -= 1;
            }
            else
              // Not blnDelete
            {
            }
            // blnDelete

            BlockGame.UpdateScore();
            thecpMove02.MovingObject.Visible = !blnDelete;
          }
          else
            // Not FirstPosition.IntersectsWith(SecondPosition)
          {
          }
          // FirstPosition.IntersectsWith(SecondPosition)

        }
        else
          // Not thecpMove02.MovingObject.Visible
        {
        }
        // thecpMove02.MovingObject.Visible 

      }
      // thecpMove01 Is Nothing 

    }
    // CheckHit(cpMove, cpMove, bool)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCollision

}
// CopyPaste.Learning.Games