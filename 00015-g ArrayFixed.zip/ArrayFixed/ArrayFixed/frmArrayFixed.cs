//***
// Action
//   - Working with an array of fixed length
// Created
//   - CopyPaste � 20220212 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220212 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ArrayFixed
{

  public class frmArrayFixed : System.Windows.Forms.Form
  {
    internal System.Windows.Forms.Button cmdOutput;
    internal System.Windows.Forms.Button cmdInput;
    internal System.Windows.Forms.TextBox txtResult;
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmArrayFixed));
      this.cmdOutput = new System.Windows.Forms.Button();
      this.cmdInput = new System.Windows.Forms.Button();
      this.txtResult = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdOutput
      // 
      this.cmdOutput.Location = new System.Drawing.Point(160, 208);
      this.cmdOutput.Name = "cmdOutput";
      this.cmdOutput.Size = new System.Drawing.Size(88, 32);
      this.cmdOutput.TabIndex = 5;
      this.cmdOutput.Text = "&Show result";
      this.cmdOutput.Click += new System.EventHandler(this.cmdOutput_Click);
      // 
      // cmdInput
      // 
      this.cmdInput.Location = new System.Drawing.Point(40, 208);
      this.cmdInput.Name = "cmdInput";
      this.cmdInput.Size = new System.Drawing.Size(88, 32);
      this.cmdInput.TabIndex = 4;
      this.cmdInput.Text = "&Input";
      this.cmdInput.Click += new System.EventHandler(this.cmdInput_Click);
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(24, 8);
      this.txtResult.Multiline = true;
      this.txtResult.Name = "txtResult";
      this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtResult.Size = new System.Drawing.Size(240, 184);
      this.txtResult.TabIndex = 3;
      this.txtResult.Text = "";
      // 
      // frmArrayFixed
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(288, 261);
      this.Controls.Add(this.cmdOutput);
      this.Controls.Add(this.cmdInput);
      this.Controls.Add(this.txtResult);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmArrayFixed";
      this.Text = "Temperatures of this week";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmArrayFixed'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220212 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220212 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null)
        {
        }
        else
        // (components != null)
        {
          components.Dispose();
        }
        // (components == null)

      }
      else
      // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmArrayFixed()
    //***
    // Action
    //   - Create instance of 'frmArrayFixed'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220212 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220212 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    decimal[] marrdecTemperatures = new decimal[7];

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdInput_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Ask the average temperature for 7 days
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - decimal Convert.ToDecimal(String)
    //   - int Array.GetUpperBound(int)
    //   - string Microsoft.VisualBasic.InputBox(string, string, string, int, int)
    // Created
    //   - CopyPaste � 20220212 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220212 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter;
      string strCaption;
      string strMessage;

      strMessage = "What was the average temperature?";

      for (lngCounter = 0; lngCounter <= marrdecTemperatures.GetUpperBound(0); lngCounter++)
      {
        strCaption = "Day " + (lngCounter + 1);
        marrdecTemperatures[lngCounter] = Convert.ToDecimal(Interaction.InputBox(strMessage, strCaption, "", -1, -1));
      }
      // lngCounter = marrdecTemperatures.GetUpperBound(0) + 1

    }
    // cmdInput_Click(System.Object, System.EventArgs) Handles cmdInput.Click

    private void cmdOutput_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Show the average temperatures of 7 days
    //   - Calculate the average
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - int Array.GetUpperBound(int)
    //   - System.Environment.NewLine()
    //' Created
    //'   - CopyPaste � 20220212 � VVDW
    //' Changed
    //'   - CopyPaste � yyyymmdd � VVDW � What changed
    //' Tested
    //'   - CopyPaste � 20220212 � VVDW
    //' Keyboard key
    //'   -
    //' Proposal (To Do)
    //'   -
    //'***
    {
      decimal decTotal = 0;
      long lngCounter;
      string strResult;

      strResult = "Average temperatures of this week:" + Environment.NewLine + Environment.NewLine;

      for (lngCounter = 0; lngCounter <= marrdecTemperatures.GetUpperBound(0); lngCounter++)
      {
        strResult = strResult + "Day " + (lngCounter + 1) + "\t" +
          marrdecTemperatures[lngCounter] + Environment.NewLine;
        decTotal += marrdecTemperatures[lngCounter];
      }
      // lngCounter = marrdecTemperatures.GetUpperBound(0) + 1

      strResult += Environment.NewLine + "Average temperature:  " + (decTotal / 7).ToString("0.00");
      txtResult.Text = strResult;
    }
    // cmdOutput_Click(System.Object, System.EventArgs) Handles cmdOutput.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmDefault
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220212 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220212 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmArrayFixed());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmArrayFixed

}
// ArrayFixed