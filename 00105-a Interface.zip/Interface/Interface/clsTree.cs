//***
// Action
//   - Definition of cpTree
//   - An implementation of cpiAgeAndName
// Created
//   - CopyPaste � 20230818 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230818 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpTree : cpiAgeAndName
  {

    #region "Constructors / Destructors"

    public cpTree(int lngYearPlanted)
      //***
      // Action
      //   - Constructor of cpTree
      //   - Sets the number of rings depending on the year planted
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - Rings(int) (Set)
      // Created
      //   - CopyPaste � 20230818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Rings = DateTime.Now.Year - lngYearPlanted;
    }
    // cpTree(int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mlngRings;

    #endregion

    #region "Properties"

    public int Age
    {

      get
        //***
        // Action Get
        //   - Return the age of a cpTree using the number of rings
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - int Rings (Get)
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return Rings;
      }
      // int Age (Get)

    }
    // int Age

    public string Name
    {

      get
        //***
        // Action Get
        //   - Return the fixed text "cpTree"
        // Called by
        //   - cpPerson.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return "cpTree";
      }
      // string Name (Get)

    }
    // string Name

    public int Rings
    {
      
      get
        //***
        // Action Get
        //   - Return the number of rings
        // Called by
        //   - AddRing()
        //   - Age() As Integer (Get)  
        // Calls
        //   - Rings() As Int32 (Get)
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngRings;
      }
      // int Rings (Get)

      set
        //***
        // Action Set
        //   - The number of rings becomes value
        // Called by
        //   - AddRing()
        //   - cpTree(int) 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230818 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230818 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngRings = value;
      }
      // Rings(int) (Set)

    }
    // int Rings

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void AddRing()
      //***
      // Action
      //   - Make the cpTree one year older
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - int Rings (Get)
      //   - Rings(int) (Set)
      // Created
      //   - CopyPaste � 20230818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Rings += 1;
    }
    // AddRing()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  //  cpTree

}
// CopyPaste.Learning