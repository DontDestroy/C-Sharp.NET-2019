﻿//***
// Action
//   - Executing simple queries in Linq
// Created
//   - CopyPaste – 20230719 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230719 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.BusinessLayer;
using CopyPaste.BusinessObjects;
using CopyPaste.DataAccess;
using CopyPaste.Toolkit;
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CopyPaste.BusinessLayer
{

  public class cpFlightDTO
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public DateTime Date { get; set; } // Same fieldname than in the object Flight, but in database it is FlightDate
    public string Departure { get; set; } // Same fieldname than in the object Flight
    public string Destination { get; set; } // Same fieldname than in the object Flight
    public int FlightId { get; set; } // Other fieldname than in the object Flight
    public short FreeSeats { get; set; } // Same fieldname than in the object Flight

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpFlightDTO

  public class cpQuery
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [cpAnnotationAttribute("Distinct; Select; Union; Where", "Flight", "Linq Fluent Notation; Linq Lambda; Query Composition; Repository Pattern")]
    public static void FlightRepositoryPatternAirportsBookableFlightsNextMonth(cpWingsContext theContext)
    //***
    // Action
    //   - Loop thru a list of airports
    //     - The list is given by a Repository Pattern and using query composition
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintWithTime(string);
    //   - IQueryable<Flight> cpFlightManager.AirportsBookableFlightsNextMonth()
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IQueryable<string> colResultExpression;
      string strCurrentMethodName;

      using (cpFlightManager theFlightManager = new cpFlightManager())
      // using (cpFlightManager theFlightManager = new cpFlightManager(theContext))
      {
        strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
        cpConsole.PrintMainHeadLine($"Begin Expression: {strCurrentMethodName}");
        cpConsole.PrintWithTime("Start AirportsBookableFlightsNextMonth");

        colResultExpression = theFlightManager.AirportsBookableFlightsNextMonth();

        foreach (string strAirport in colResultExpression)
        {
          cpConsole.Print(strAirport);
        }
        // in colResultExpression

        cpConsole.PrintSuccess($"Number of possible airports: {colResultExpression.Count()}");

        cpConsole.PrintWithTime("Stop AirportsBookableFlightsNextMonth");
        cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");
      }
      // cpFlightManager theFlightManager = new cpFlightManager()
      // cpFlightManager theFlightManager = new cpFlightManager(theContext)

    }
    // FlightRepositoryPatternAirportsBookableFlightsNextMonth(cpWingsContext)

    [cpAnnotationAttribute("Select; Where", "Flight", "Linq Fluent Notation; Linq Lambda; Repository Pattern")]
    public static void FlightRepositoryPatternBookableFlights(cpWingsContext theContext)
    //***
    // Action
    //   - Loop thru a list and count
    //     - The list is given by a Repository Pattern
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintWithTime(string);
    //   - DateTime Flight.Date (Get)
    //   - int Flight.FlightNo (Get)
    //   - IQueryable<Flight> cpFlightManager.BookableFlights()
    //   - short Flight.FreeSeats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IQueryable<Flight> colResultExpression;
      IQueryable<Flight> colResultLambda;
      string strCurrentMethodName;

      using (cpFlightManager theFlightManager = new cpFlightManager())
      // using (cpFlightManager theFlightManager = new cpFlightManager(theContext))
      {
        strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
        cpConsole.PrintMainHeadLine($"Begin Expression: {strCurrentMethodName}");
        cpConsole.PrintWithTime("Start BookableFlights");

        colResultExpression = from aFlight in theFlightManager.BookableFlights()
                              select aFlight;

        foreach (Flight theFlight in colResultExpression)
        {
          cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
        }
        // in colResultExpression

        cpConsole.PrintSuccess($"Number of possible Flights: {colResultExpression.Count()}");
        // A better alternative is put the colResultExpression into a list and count the items in the list
        // Entity FrameWork Core uses the cached data, so there is no second round towards the database

        cpConsole.PrintWithTime("Stop BookableFlights");
        cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");
        cpConsole.PrintMainHeadLine($"Begin Lambda: {strCurrentMethodName}");
        cpConsole.PrintWithTime("Start BookableFlights");

        colResultLambda = theFlightManager.BookableFlights().Select(aFlight => aFlight);

        foreach (Flight theFlight in colResultLambda)
        {
          cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
        }
        // in colResultLambda

        cpConsole.PrintSuccess($"Number of possible Flights: {colResultLambda.Count()}");
        // A better alternative is put the colResultLambda into a list and count the items in the list
        // Entity FrameWork Core uses the cached data, so there is no second round towards the database

        cpConsole.PrintWithTime("Stop BookableFlights");
        cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");
      }
      // cpFlightManager theFlightManager = new cpFlightManager()
      // cpFlightManager theFlightManager = new cpFlightManager(theContext)

    }
    // FlightRepositoryPatternBookableFlights(cpWingsContext)

    [cpAnnotationAttribute("Select; Where", "Flight", "Linq Fluent Notation; Linq Lambda; Query Composition; Repository Pattern")]
    public static void FlightRepositoryPatternBookableFlightsNextMonth(cpWingsContext theContext)
    //***
    // Action
    //   - Loop thru a list and count
    //     - The list is given by a Repository Pattern and using query composition
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintWithTime(string);
    //   - DateTime Flight.Date (Get)
    //   - int Flight.FlightNo (Get)
    //   - IQueryable<Flight> cpFlightManager.BookableFlightsNextMonth()
    //   - short Flight.FreeSeats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IQueryable<Flight> colResultExpression;
      IQueryable<Flight> colResultLambda;
      string strCurrentMethodName;

      using (cpFlightManager theFlightManager = new cpFlightManager())
      // using (cpFlightManager theFlightManager = new cpFlightManager(theContext))
      {
        strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
        cpConsole.PrintMainHeadLine($"Begin Expression: {strCurrentMethodName}");
        cpConsole.PrintWithTime("Start BookableFlightsNextMonth");

        colResultExpression = from aFlight in theFlightManager.BookableFlightsNextMonth()
                              select aFlight;

        foreach (Flight theFlight in colResultExpression)
        {
          cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
        }
        // in colResultExpression

        cpConsole.PrintSuccess($"Number of possible Flights: {colResultExpression.Count()}");
        // A better alternative is put the colResultExpression into a list and count the items in the list
        // Entity FrameWork Core uses the cached data, so there is no second round towards the database

        cpConsole.PrintWithTime("Stop BookableFlightsNextMonth");
        cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");
        cpConsole.PrintMainHeadLine($"Begin Lambda: {strCurrentMethodName}");
        cpConsole.PrintWithTime("Start BookableFlightsNextMonth");

        colResultLambda = theFlightManager.BookableFlightsNextMonth().Select(aFlight => aFlight);

        foreach (Flight theFlight in colResultLambda)
        {
          cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
        }
        // in colResultLambda

        cpConsole.PrintSuccess($"Number of possible Flights: {colResultLambda.Count()}");
        // A better alternative is put the colResultLambda into a list and count the items in the list
        // Entity FrameWork Core uses the cached data, so there is no second round towards the database

        cpConsole.PrintWithTime("Stop BookableFlightsNextMonth");
        cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");
      }
      // cpFlightManager theFlightManager = new cpFlightManager()
      // cpFlightManager theFlightManager = new cpFlightManager(theContext)

    }
    // FlightRepositoryPatternBookableFlightsNextMonth(cpWingsContext)

    [cpAnnotationAttribute("OrderBy; Select; Where", "Flight", "Linq Fluent Notation; Linq Lambda; Query Composition; Repository Pattern")]
    public static void FlightRepositoryPatternBookableFlightsNextMonthDepartureSortedOnDate(cpWingsContext theContext, string strDeparture)
    //***
    // Action
    //   - Loop thru a list and count
    //     - The list is given by a Repository Pattern and using query composition
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintWithTime(string);
    //   - DateTime Flight.Date (Get)
    //   - int Flight.FlightNo (Get)
    //   - IQueryable<Flight> cpFlightManager.BookableFlightsNextMonthDepartureSortedOnDate(string)
    //   - short Flight.FreeSeats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IQueryable<Flight> colResultExpression;
      IQueryable<Flight> colResultLambda;
      string strCurrentMethodName;

      using (cpFlightManager theFlightManager = new cpFlightManager())
      // using (cpFlightManager theFlightManager = new cpFlightManager(theContext))
      {
        strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
        cpConsole.PrintMainHeadLine($"Begin Expression: {strCurrentMethodName}");
        cpConsole.PrintWithTime("Start BookableFlightsNextMonthDepartureSortedOnDate");

        colResultExpression = from aFlight in theFlightManager.BookableFlightsNextMonthDepartureSortedOnDate(strDeparture)
                              select aFlight;

        foreach (Flight theFlight in colResultExpression)
        {
          cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
        }
        // in colResultExpression

        cpConsole.PrintSuccess($"Number of possible Flights: {colResultExpression.Count()}");
        // A better alternative is put the colResultExpression into a list and count the items in the list
        // Entity FrameWork Core uses the cached data, so there is no second round towards the database

        cpConsole.PrintWithTime("Stop BookableFlightsNextMonthDepartureSortedOnDate");
        cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");
        cpConsole.PrintMainHeadLine($"Begin Lambda: {strCurrentMethodName}");
        cpConsole.PrintWithTime("Start BookableFlightsNextMonthDepartureSortedOnDate");

        colResultLambda = theFlightManager.BookableFlightsNextMonthDepartureSortedOnDate(strDeparture).Select(aFlight => aFlight);

        foreach (Flight theFlight in colResultLambda)
        {
          cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
        }
        // in colResultLambda

        cpConsole.PrintSuccess($"Number of possible Flights: {colResultLambda.Count()}");
        // A better alternative is put the colResultLambda into a list and count the items in the list
        // Entity FrameWork Core uses the cached data, so there is no second round towards the database

        cpConsole.PrintWithTime("Stop BookableFlightsNextMonthDepartureSortedOnDate");
        cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");
      }
      // cpFlightManager theFlightManager = new cpFlightManager()
      // cpFlightManager theFlightManager = new cpFlightManager(theContext)

    }
    // FlightRepositoryPatternBookableFlightsNextMonthDepartureSortedOnDate(cpWingsContext, string)

    [cpAnnotationAttribute("Select; Where", "Flight", "Linq Fluent Notation; Linq Lambda; Paging; Query Composition; Repository Pattern")]
    public static void FlightRepositoryPatternBookableFlightsNextMonthPaging(cpWingsContext theContext, int intStartingPoint, int intNumberOfRecords)
    //***
    // Action
    //   - Loop thru a list and count, but with a starting point and a number of records
    //     - The list is given by a Repository Pattern and using query composition
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintWithTime(string);
    //   - DateTime Flight.Date (Get)
    //   - int Flight.FlightNo (Get)
    //   - IQueryable<Flight> cpFlightManager.BookableFlightsNextMonthPaging(int, int)
    //   - short Flight.FreeSeats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IQueryable<Flight> colResultExpression;
      IQueryable<Flight> colResultLambda;
      string strCurrentMethodName;

      using (cpFlightManager theFlightManager = new cpFlightManager())
      // using (cpFlightManager theFlightManager = new cpFlightManager(theContext))
      {
        strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
        cpConsole.PrintMainHeadLine($"Begin Expression: {strCurrentMethodName}");
        cpConsole.PrintWithTime("Start BookableFlightsNextMonthPaging");

        colResultExpression = from aFlight in theFlightManager.BookableFlightsNextMonthPaging(intStartingPoint, intNumberOfRecords)
                              select aFlight;

        foreach (Flight theFlight in colResultExpression)
        {
          cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
        }
        // in colResultExpression

        cpConsole.PrintSuccess($"Number of possible Flights: {colResultExpression.Count()}");
        // A better alternative is put the colResultExpression into a list and count the items in the list
        // Entity FrameWork Core uses the cached data, so there is no second round towards the database

        cpConsole.PrintWithTime("Stop BookableFlightsNextMonthPaging");
        cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");
        cpConsole.PrintMainHeadLine($"Begin Lambda: {strCurrentMethodName}");
        cpConsole.PrintWithTime("Start BookableFlightsNextMonthPaging");

        colResultLambda = theFlightManager.BookableFlightsNextMonthPaging(intStartingPoint, intNumberOfRecords).Select(aFlight => aFlight);

        foreach (Flight theFlight in colResultLambda)
        {
          cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
        }
        // in colResultLambda

        cpConsole.PrintSuccess($"Number of possible Flights: {colResultLambda.Count()}");
        // A better alternative is put the colResultLambda into a list and count the items in the list
        // Entity FrameWork Core uses the cached data, so there is no second round towards the database

        cpConsole.PrintWithTime("Stop BookableFlightsNextMonthPaging");
        cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");
      }
      // cpFlightManager theFlightManager = new cpFlightManager()
      // cpFlightManager theFlightManager = new cpFlightManager(theContext)

    }
    // FlightRepositoryPatternBookableFlightsNextMonthPaging(cpWingsContext, int, int)

    [cpAnnotationAttribute("Find; Select; Where", "Flight", "Linq Fluent Notation; Linq Lambda; Repository Pattern")]
    public static void FlightRepositoryPatternFlight(cpWingsContext theContext, int intFlightId)
    //***
    // Action
    //   - Find one specific Flight
    //     - The list is given by a Repository Pattern
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintWithTime(string);
    //   - DateTime Flight.Date (Get)
    //   - Flight cpFlightManager.GetFlight(int)
    //   - int Flight.FlightNo (Get)
    //   - short Flight.FreeSeats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Flight theFlightExpression;
      string strCurrentMethodName;

      using (cpFlightManager theFlightManager = new cpFlightManager())
      // using (cpFlightManager theFlightManager = new cpFlightManager(theContext))
      {
        strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
        cpConsole.PrintMainHeadLine($"Begin Expression: {strCurrentMethodName}");
        cpConsole.PrintWithTime("Start GetFlight");

        theFlightExpression = theFlightManager.GetFlight(intFlightId);
        cpConsole.Print($"Flight {theFlightExpression.FlightNo} at {theFlightExpression.Date} from {theFlightExpression.Departure} to {theFlightExpression.Destination} has {theFlightExpression.FreeSeats} free seats.");

        cpConsole.PrintWithTime("Stop BookableFlights");
        cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");
      }
      // cpFlightManager theFlightManager = new cpFlightManager()
      // cpFlightManager theFlightManager = new cpFlightManager(theContext)

    }
    // FlightRepositoryPatternFlight(cpWingsContext, int)

    [cpAnnotationAttribute("OrderBy; Select; Where", "Flight", "Linq Fluent Notation; Linq Lambda")]
    public static void LoopThruUnbookedFlightsFromDepartureSortedByDate(cpWingsContext theContext)
    //***
    // Action
    //   - Loop thru a list and count
    //   - All unbooked Flights from the departure location 'Berlin', sorted by date
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DateTime Flight.Date (Get)
    //   - DbSet<Flight> cpWingsContext.Flight (Get)
    //   - int Flight.FlightNo (Get)
    //   - short Flight.FreeSeats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IQueryable<Flight> colResultExpression;
      IOrderedQueryable<Flight> colResultLambda;
      string strCity = "Berlin";
      string strCurrentMethodName;
      
      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      cpConsole.PrintMainHeadLine($"Begin Expression: {strCurrentMethodName}");
      cpConsole.PrintWithTime("Start");

      colResultExpression = from aFlight in theContext.Flight
                            where aFlight.Departure == strCity && aFlight.FreeSeats > 0
                            orderby aFlight.Date
                            select aFlight;

      foreach (Flight theFlight in colResultExpression)
      {
        cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
      }
      // in colResultExpression

      cpConsole.PrintSuccess($"Number of possible Flights: {colResultExpression.Count()}");
      // A better alternative is put the colResultExpression into a list and count the items in the list
      // Entity FrameWork Core uses the cached data, so there is no second round towards the database
      cpConsole.PrintWithTime("Stop");
      cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");

      cpConsole.PrintMainHeadLine($"Begin Lambda: {strCurrentMethodName}");
      cpConsole.PrintWithTime("Start");

      colResultLambda = theContext.Flight
        .Where(aFlight => aFlight.Departure == strCity && aFlight.FreeSeats > 0)
        .OrderBy(aFlight => aFlight.Date);

      foreach (Flight theFlight in colResultLambda)
      {
        cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
      }
      // in colResultLambda

      cpConsole.PrintSuccess($"Number of possible Flights: {colResultLambda.Count()}");
      // A better alternative is put the colResultLambda into a list and count the items in the list
      // Entity FrameWork Core uses the cached data, so there is no second round towards the database
      cpConsole.PrintWithTime("Stop");
      cpConsole.PrintMainHeadLine($"End Lambda: {strCurrentMethodName}");
    }
    // LoopThruUnbookedFlightsFromDepartureSortedByDate(cpWingsContext)

    [cpAnnotationAttribute("OrderBy; Select; Where", "Flight", "Linq Fluent Notation; Linq Lambda; Query Composition")]
    public static void LoopThruUnbookedFlightsFromDepartureAndDestinationSortedByDate(cpWingsContext theContext)
    //***
    // Action
    //   - Loop thru a list and count
    //   - All unbooked Flights from the departure location (can be empty) and a destination location (can be empty), sorted by date
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    //   - Pay attention how the sort is executed in the Lambda Linq Dot Notation
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintWithTime(string);
    //   - DateTime Flight.Date (Get)
    //   - DbSet<Flight> cpWingsContext.Flight (Get)
    //   - int Flight.FlightNo (Get)
    //   - short Flight.FreeSeats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IQueryable<Flight> colResultExpression;
      IQueryable<Flight> colTempResultLambda;
      IOrderedQueryable<Flight> colResultLambda;
      string? strCityDeparture = "Berlin";
      string? strCityDestination = "Kaapstad";
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      cpConsole.PrintMainHeadLine($"Begin Expression: {strCurrentMethodName}");
      cpConsole.PrintWithTime("Start");

      colResultExpression = from aFlight in theContext.Flight
                            where aFlight.FreeSeats > 0
                            orderby aFlight.Date
                            select aFlight;

      if (String.IsNullOrEmpty(strCityDeparture))
      {
      }
      else
      // Not String.IsNullOrEmpty(strCityDeparture)
      {
        colResultExpression = from aFlight in colResultExpression
                              where aFlight.Departure == strCityDeparture
                              select aFlight;
      }
      // String.IsNullOrEmpty(strCityDeparture)

      if (String.IsNullOrEmpty(strCityDestination))
      {
      }
      else
      // Not String.IsNullOrEmpty(strCityDestination)
      {
        colResultExpression = from aFlight in colResultExpression
                              where aFlight.Destination == strCityDestination
                              select aFlight;
      }
      // String.IsNullOrEmpty(strCityDestination)

      foreach (Flight theFlight in colResultExpression)
      {
        cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
      }
      // in colResultExpression

      cpConsole.PrintSuccess($"Number of possible Flights: {colResultExpression.Count()}");
      // A better alternative is put the colResultExpression into a list and count the items in the list
      // Entity FrameWork Core uses the cached data, so there is no second round towards the database
      cpConsole.PrintWithTime("Stop");
      cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");

      cpConsole.PrintMainHeadLine($"Begin Lambda: {strCurrentMethodName}");
      cpConsole.PrintWithTime("Start");

      colTempResultLambda = theContext.Flight
        .Where(aFlight => aFlight.FreeSeats > 0);

      if (String.IsNullOrEmpty(strCityDeparture))
      {
      }
      else
      // Not String.IsNullOrEmpty(strCityDeparture)
      {
        colTempResultLambda = colTempResultLambda.Where(aFlight => aFlight.Departure == strCityDeparture);
      }
      // String.IsNullOrEmpty(strCityDeparture)

      if (String.IsNullOrEmpty(strCityDestination))
      {
      }
      else
      // Not String.IsNullOrEmpty(strCityDestination)
      {
        colTempResultLambda = colTempResultLambda.Where(aFlight => aFlight.Destination == strCityDestination);
      }
      // String.IsNullOrEmpty(strCityDestination)

      colResultLambda = colTempResultLambda.OrderBy(aFlight => aFlight.Date);

      foreach (Flight theFlight in colResultLambda)
      {
        cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
      }
      // in colResultLambda

      cpConsole.PrintSuccess($"Number of possible Flights: {colResultLambda.Count()}");
      // A better alternative is put the colResultLambda into a list and count the items in the list
      // Entity FrameWork Core uses the cached data, so there is no second round towards the database
      cpConsole.PrintWithTime("Stop");
      cpConsole.PrintMainHeadLine($"End Lambda: {strCurrentMethodName}");
    }
    // LoopThruUnbookedFlightsFromDepartureAndDestinationSortedByDate(cpWingsContext)

    [cpAnnotationAttribute("Select; Where", "Flight", "Linq Fluent Notation; Linq Lambda; Repository Pattern")]
    public static void LoopThruUnbookedFlightsFromDepartureAndDestinationRepositoryPattern(cpWingsContext theContext)
    //***
    // Action
    //   - Loop thru a list and count
    //     - The list is given by a Repository Pattern
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintWithTime(string)
    //   - cpFlightManagerSimple()
    //   - DateTime Flight.Date (Get)
    //   - int Flight.FlightNo (Get)
    //   - IQueryable<Flight> cpFlightManagerSimple.BookableFlights()
    //   - short Flight.FreeSeats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IQueryable<Flight> colResultExpression;
      IQueryable<Flight> colResultLambda;
      string strCity = "Berlin";
      string strCurrentMethodName;

      using (cpFlightManagerSimple theFlightManager = new cpFlightManagerSimple())
      // using (cpFlightManagerSimple theFlightManager = new cpFlightManagerSimple(theContext))
      {
        strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
        cpConsole.PrintMainHeadLine($"Begin Expression: {strCurrentMethodName}");
        cpConsole.PrintWithTime("Start");

        colResultExpression = from aFlight in theFlightManager.BookableFlights()
                              where aFlight.Departure == strCity
                              select aFlight;

        foreach (Flight theFlight in colResultExpression)
        {
          cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
        }
        // in colResultExpression

        cpConsole.PrintSuccess($"Number of possible Flights: {colResultExpression.Count()}");
        // A better alternative is put the colResultExpression into a list and count the items in the list
        // Entity FrameWork Core uses the cached data, so there is no second round towards the database
        cpConsole.PrintWithTime("Stop");
        cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");

        cpConsole.PrintMainHeadLine($"Begin Lambda: {strCurrentMethodName}");
        cpConsole.PrintWithTime("Start");

        colResultLambda = theFlightManager.BookableFlights().Where(aFlight => aFlight.Departure == strCity);
                              
        foreach (Flight theFlight in colResultLambda)
        {
          cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
        }
        // in colResultLambda

        cpConsole.PrintSuccess($"Number of possible Flights: {colResultLambda.Count()}");
        // A better alternative is put the colResultLambda into a list and count the items in the list
        // Entity FrameWork Core uses the cached data, so there is no second round towards the database
        cpConsole.PrintWithTime("Stop");
        cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");
      }
      // cpFlightManagerSimple theFlightManager = new cpFlightManagerSimple()
      // cpFlightManagerSimple theFlightManager = new cpFlightManagerSimple(theContext)

    }
    // LoopThruUnbookedFlightsFromDepartureAndDestinationRepositoryPattern(cpWingsContext)

    [cpAnnotationAttribute("OrderBy; Select; Where", "Flight", "Linq Fluent Notation; Linq Lambda; Projection")]
    public static void LoopThruUnbookedFlightsProjection(cpWingsContext theContext)
    //***
    // Action
    //   - Loop thru a list and count
    //     - A new instance of Flight is created, only with the needed fields 
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DateTime Flight.Date (Get)
    //   - DbSet<Flight> cpWingsContext.Flight (Get)
    //   - Flight()
    //   - Flight.Date(DateTime) (Set)
    //   - Flight.FlightNo(int) (Set)
    //   - Flight.FreeSeats(short) (Set)
    //   - Flight.Departure(string) (Set)
    //   - Flight.Destination(string) (Set)
    //   - int Flight.FlightNo (Get)
    //   - short Flight.FreeSeats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IQueryable<Flight> colResultExpression;
      IQueryable<Flight> colResultLambda;
      string strCity = "Berlin";
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      cpConsole.PrintMainHeadLine($"Begin Expression: {strCurrentMethodName}");
      cpConsole.PrintWithTime("Start");

      colResultExpression = from aFlight in theContext.Flight
                            where aFlight.FreeSeats > 0 && aFlight.Departure == strCity
                            orderby aFlight.Date
                            select new Flight()
                            {
                              FlightNo = aFlight.FlightNo,
                              Date = aFlight.Date,
                              Departure = aFlight.Departure,
                              Destination = aFlight.Destination,
                              FreeSeats = aFlight.FreeSeats
                            };

      foreach (Flight theFlight in colResultExpression)
      {
        cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
      }
      // in colResultExpression

      cpConsole.PrintSuccess($"Number of possible Flights: {colResultExpression.Count()}");
      // A better alternative is put the colResultExpression into a list and count the items in the list
      // Entity FrameWork Core uses the cached data, so there is no second round towards the database
      cpConsole.PrintWithTime("Stop");
      cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");

      cpConsole.PrintMainHeadLine($"Begin Lambda: {strCurrentMethodName}");
      cpConsole.PrintWithTime("Start");

      colResultLambda = theContext.Flight
        .Where(aFlight => aFlight.FreeSeats > 0 && aFlight.Departure == strCity)
        .OrderBy(aFlight => aFlight.Date)
        .Select(aFlight => new Flight
        {
          FlightNo = aFlight.FlightNo,
          Date = aFlight.Date,
          Departure = aFlight.Departure,
          Destination = aFlight.Destination,
          FreeSeats = aFlight.FreeSeats
        });

      foreach (Flight theFlight in colResultLambda)
      {
        cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
      }
      // in colResultLambda

      cpConsole.PrintSuccess($"Number of possible Flights: {colResultLambda.Count()}");
      // A better alternative is put the colResultLambda into a list and count the items in the list
      // Entity FrameWork Core uses the cached data, so there is no second round towards the database
      cpConsole.PrintWithTime("Stop");
      cpConsole.PrintMainHeadLine($"End Lambda: {strCurrentMethodName}");
    }
    // LoopThruUnbookedFlightsProjection(cpWingsContext)

    [cpAnnotationAttribute("OrderBy; Select; Where", "Flight", "Anonymous Type; Linq Fluent Notation; Linq Lambda; Projection")]
    public static void LoopThruUnbookedFlightsProjectionAnonymousType(cpWingsContext theContext)
    //***
    // Action
    //   - Loop thru a list and count
    //     - A new instance of an anonymous type is created, only with the needed fields 
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    //   - Attention
    //     - Saving changes towards the database is not possible, because it does not exist in the database
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DateTime Flight.Date (Get)
    //   - DbSet<Flight> cpWingsContext.Flight (Get)
    //   - int Flight.FlightNo (Get)
    //   - short Flight.FreeSeats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    // Created
    //   - CopyPaste – 20230802 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230802 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCity = "Berlin";
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      cpConsole.PrintMainHeadLine($"Begin Expression: {strCurrentMethodName}");
      cpConsole.PrintWithTime("Start");

      // Here you must use a var data type, because the type is anonymous, you don't know the type here
      var colResultExpression = from aFlight in theContext.Flight
                                where aFlight.FreeSeats > 0 && aFlight.Departure == strCity
                                orderby aFlight.Date
                                select new
                                {
                                  aFlight.FlightNo,
                                  aFlight.Date,
                                  aFlight.Departure,
                                  aFlight.Destination,
                                  aFlight.FreeSeats
                                };

      // Here you must use a var data type, because the type is anonymous, you don't know the type here
      foreach (var theFlight in colResultExpression)
      {
        cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
      }
      // in colResultExpression

      cpConsole.PrintSuccess($"Number of possible Flights: {colResultExpression.Count()}");
      // A better alternative is put the colResultExpression into a list and count the items in the list
      // Entity FrameWork Core uses the cached data, so there is no second round towards the database
      cpConsole.PrintWithTime("Stop");
      cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");

      cpConsole.PrintMainHeadLine($"Begin Lambda: {strCurrentMethodName}");
      cpConsole.PrintWithTime("Start");

      // Here you must use a var data type, because the type is anonymous, you don't know the type here
      var colResultLambda = theContext.Flight
        .Where(aFlight => aFlight.FreeSeats > 0 && aFlight.Departure == strCity)
        .OrderBy(aFlight => aFlight.Date)
        .Select(aFlight => new
        {
          aFlight.FlightNo,
          aFlight.Date,
          aFlight.Departure,
          aFlight.Destination,
          aFlight.FreeSeats
        });

      // Here you must use a var data type, because the type is anonymous, you don't know the type here
      foreach (var theFlight in colResultLambda)
      {
        cpConsole.Print($"Flight {theFlight.FlightNo} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
      }
      // in colResultLambda

      cpConsole.PrintSuccess($"Number of possible Flights: {colResultLambda.Count()}");
      // A better alternative is put the colResultLambda into a list and count the items in the list
      // Entity FrameWork Core uses the cached data, so there is no second round towards the database
      cpConsole.PrintWithTime("Stop");
      cpConsole.PrintMainHeadLine($"End Lambda: {strCurrentMethodName}");
    }
    // LoopThruUnbookedFlightsProjectionAnonymousType(cpWingsContext)


    [cpAnnotationAttribute("OrderBy; Select; Where", "Flight", "DTO; Linq Fluent Notation; Linq Lambda; Projection")]
    public static void LoopThruUnbookedFlightsProjectionDataTransferObject(cpWingsContext theContext)
    //***
    // Action
    //   - Loop thru a list and count
    //     - A new instance of an anonymous type is created, only with the needed fields 
    //   - Solution is given with the Linq Fluent Syntax Query Expression
    //   - Solution is given with the Lambda Linq Dot Notation
    //   - Attention
    //     - Saving changes towards the database is not possible, because it does not exist in the database
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DateTime Flight.Date (Get)
    //   - DbSet<Flight> cpWingsContext.Flight (Get)
    //   - int Flight.FlightNo (Get)
    //   - short Flight.FreeSeats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    // Created
    //   - CopyPaste – 20230802 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230802 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      IQueryable<cpFlightDTO> colResultExpression;
      IQueryable<cpFlightDTO> colResultLambda;
      string strCity = "Berlin";
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      cpConsole.PrintMainHeadLine($"Begin Expression: {strCurrentMethodName}");
      cpConsole.PrintWithTime("Start");

      // Here you must use a var data type, because the type is anonymous, you don't know the type here
      colResultExpression = from aFlight in theContext.Flight
                            where aFlight.FreeSeats > 0 && aFlight.Departure == strCity
                            orderby aFlight.Date
                            select new cpFlightDTO
                            {
                               FlightId = aFlight.FlightNo,
                               Date = aFlight.Date,
                               Departure = aFlight.Departure,
                               Destination = aFlight.Destination,
                               FreeSeats = aFlight.FreeSeats
                            };

      foreach (var theFlight in colResultExpression)
      {
        cpConsole.Print($"Flight {theFlight.FlightId} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
      }
      // in colResultExpression

      cpConsole.PrintSuccess($"Number of possible Flights: {colResultExpression.Count()}");
      // A better alternative is put the colResultExpression into a list and count the items in the list
      // Entity FrameWork Core uses the cached data, so there is no second round towards the database
      cpConsole.PrintWithTime("Stop");
      cpConsole.PrintMainHeadLine($"End Expression: {strCurrentMethodName}");

      cpConsole.PrintMainHeadLine($"Begin Lambda: {strCurrentMethodName}");
      cpConsole.PrintWithTime("Start");

      // Here you must use a var data type, because the type is anonymous, you don't know the type here
      colResultLambda = theContext.Flight
        .Where(aFlight => aFlight.FreeSeats > 0 && aFlight.Departure == strCity)
        .OrderBy(aFlight => aFlight.Date)
        .Select(aFlight => new cpFlightDTO
        {
          FlightId = aFlight.FlightNo,
          Date = aFlight.Date,
          Departure = aFlight.Departure,
          Destination = aFlight.Destination,
          FreeSeats = aFlight.FreeSeats
        });

      // Here you must use a var data type, because the type is anonymous, you don't know the type here
      foreach (var theFlight in colResultLambda)
      {
        cpConsole.Print($"Flight {theFlight.FlightId} at {theFlight.Date} from {theFlight.Departure} to {theFlight.Destination} has {theFlight.FreeSeats} free seats.");
      }
      // in colResultLambda

      cpConsole.PrintSuccess($"Number of possible Flights: {colResultLambda.Count()}");
      // A better alternative is put the colResultLambda into a list and count the items in the list
      // Entity FrameWork Core uses the cached data, so there is no second round towards the database
      cpConsole.PrintWithTime("Stop");
      cpConsole.PrintMainHeadLine($"End Lambda: {strCurrentMethodName}");
    }
    // LoopThruUnbookedFlightsProjectionDataTransferObject(cpWingsContext)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpQuery

}
// CopyPaste.BusinessLayer