//***
// Action
//   - A screen with 2 timers
//     - One visible on the screen and one programmed
//   - Clicking the button activates the visible timer for 5 seconds and starts
//   - After 5 seconds a messagebox is shown
//   - A timer is defined
//     - The newly defined timer becomes the visible timer
//     - It is set for 10 seconds and started
// Created
//   - CopyPaste � 20250716 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250716 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTimer: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    internal System.Windows.Forms.Button cmdStart;
    internal System.Windows.Forms.Timer tmrRoutine;
    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTimer));
      this.cmdStart = new System.Windows.Forms.Button();
      this.tmrRoutine = new System.Windows.Forms.Timer(this.components);
      this.SuspendLayout();
      // 
      // cmdStart
      // 
      this.cmdStart.Location = new System.Drawing.Point(88, 104);
      this.cmdStart.Name = "cmdStart";
      this.cmdStart.Size = new System.Drawing.Size(120, 32);
      this.cmdStart.TabIndex = 1;
      this.cmdStart.Text = "Start Timer";
      this.cmdStart.Click += new System.EventHandler(this.cmdStart_Click);
      // 
      // tmrRoutine
      // 
      this.tmrRoutine.Tick += new System.EventHandler(this.tmrRoutine_Tick);
      // 
      // frmTimer
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdStart);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTimer";
      this.Text = "Timer";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTimer'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTimer()
      //***
      // Action
      //   - Create instance of 'frmTimer'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTimer()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdStart_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a message box that will start a timer for 5 seconds
      //   - Interval is set to 5 seconds
      //   - Timer is started
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show("Timer will occur 5 seconds after you close this box");
      tmrRoutine.Interval = 5000;
      tmrRoutine.Start();
    }
    // cmdStart_Click(System.Object, System.EventArgs) Handles cmdStart.Click

    private void tmrRoutine_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - A timer is defined
      //   - The original timer is stopped
      //   - Show a message  box to reset it at 10 seconds
      //   - The newly defined timer becomes the timer that triggered the routine (theSender)
      //   - Interval is set to 10 seconds
      //   - Timer is started
      // Called by
      //   - System action (Tick of a timer)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - Set the stop command of tmrRoutine into comments and look at the behaviour
      //***
    {
      Timer theTimer;

      tmrRoutine.Stop();
      MessageBox.Show("Timer occurred - Resetting for 10 seconds");
      theTimer = (Timer)theSender;
      theTimer.Interval = 10000;
      theTimer.Start();
    }
    // tmrRoutine_Tick(System.Object, System.EventArgs)

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTimer
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmTimer()
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTimer());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTimer

}
// CopyPaste.Learning