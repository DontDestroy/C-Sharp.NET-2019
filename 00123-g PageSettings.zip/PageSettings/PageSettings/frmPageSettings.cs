//***
// Action
//   - Show the page settings
// Created
//   - CopyPaste � 20240719 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240719 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPageSettings: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtText;
    internal System.Windows.Forms.Button cmdPageInfo;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPageSettings));
      this.txtText = new System.Windows.Forms.TextBox();
      this.cmdPageInfo = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(21, 80);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(250, 150);
      this.txtText.TabIndex = 3;
      this.txtText.Text = "";
      // 
      // cmdPageInfo
      // 
      this.cmdPageInfo.Location = new System.Drawing.Point(105, 32);
      this.cmdPageInfo.Name = "cmdPageInfo";
      this.cmdPageInfo.TabIndex = 2;
      this.cmdPageInfo.Text = "Page Info";
      this.cmdPageInfo.Click += new System.EventHandler(this.cmdPageInfo_Click);
      // 
      // frmPageSettings
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.txtText);
      this.Controls.Add(this.cmdPageInfo);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPageSettings";
      this.Text = "Page Settings";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPageSettings'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPageSettings()
      //***
      // Action
      //   - Create instance of 'frmPageSettings'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPageSettings()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
   
    private void cmdPageInfo_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a new page setup dialog
      //   - Define a new print document
      //   - Show the dialog
      //   - If OK is clicked
      //     - Define a new line
      //     - Append to a textbox the AllowMargins
      //     - Append to a textbox the AllowOrientation
      //     - Append to a textbox the AllowPaper
      //     - Append to a textbox the AllowPrinter
      //     - Append to a textbox the MinMargins
      //     - Append to a textbox the Network
      //     - Append to a textbox the PrinterSettings
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      PageSetupDialog dlgPageSetup = new PageSetupDialog();

      dlgPageSetup.Document = new PrintDocument();

      if (dlgPageSetup.ShowDialog() == DialogResult.OK)
      {
        string strCrLf = Environment.NewLine;
        
        txtText.Text = "";
        txtText.AppendText("Allow Margins: " + dlgPageSetup.AllowMargins);
        txtText.AppendText(strCrLf);
        txtText.AppendText("Allow Orientation: " + dlgPageSetup.AllowOrientation);
        txtText.AppendText(strCrLf);
        txtText.AppendText("Allow Paper: " + dlgPageSetup.AllowPaper);
        txtText.AppendText(strCrLf);
        txtText.AppendText("Allow Printer: " + dlgPageSetup.AllowPrinter);
        txtText.AppendText(strCrLf);
        txtText.AppendText("Minimum Margins: " + dlgPageSetup.MinMargins.ToString());
        txtText.AppendText(strCrLf);
        txtText.AppendText("Show Network: " + dlgPageSetup.ShowNetwork);
        txtText.AppendText(strCrLf);
        txtText.AppendText("Printer Settings: " + dlgPageSetup.PrinterSettings.ToString());
        txtText.AppendText(strCrLf);
      }
      else
        // dlgPageSetup.ShowDialog() <> DialogResult.OK
      {
      }
      // dlgPageSetup.ShowDialog() = DialogResult.OK

    
    }
    // cmdPageInfo_Click(System.Object, System.EventArgs) Handles cmdPageInfo.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPageSettings
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmPageSettings()
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPageSettings());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPageSettings

}
// CopyPaste.Learning