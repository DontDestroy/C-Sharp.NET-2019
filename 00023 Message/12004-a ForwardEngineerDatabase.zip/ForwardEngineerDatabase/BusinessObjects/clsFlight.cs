﻿//***
// Action
//   - Definition of a Flight
// Created
//   - CopyPaste – 20230711 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230711 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace CopyPaste.BusinessObjects
{

  [SerializableAttribute]
  public class Flight
  {

    #region "Constructors / Destructors"

    public Flight()
    //***
    // Action
    //   - Constructor of Flight
    //   - Creates an empty list of Booking
    // Called by
    //   - 
    // Calls
    //   - Booking(ICollection<Booking>) (Set)
    // Created
    //   - CopyPaste – 20230712 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230712 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      this.Booking = new List<Booking>();
    }
    // Flight()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public ICollection<Booking> Booking { get; set; }
    public Pilot CoPilot { get; set; }
    public int? CoPilotId { get; set; }

    public DateTime Date { get; set; }

    [StringLengthAttribute(50), MinLengthAttribute(3)]
    public string Departure { get; set; }

    [StringLengthAttribute(50), MinLengthAttribute(3)]
    public string Destination { get; set; }

    // Primary Key is not with the rules and conventions, see OnModelCreating for solution
    // This property must be the primary key, but it has no ID or <<class>>ID in the property
    // Entity Framework Core will think there is no Primary key
    // It must be forced in the OnModelCreating() method
    // The data annotations can be removed in newer versions of Entity Framework Core
    [KeyAttribute]
    [DatabaseGeneratedAttribute(DatabaseGeneratedOption.None)]
    public int FlightNo { get; set; }

    public short FreeSeats { get; set; }
    public string Memo { get; set; }
    public bool? NonSmokingFlight { get; set; }
    public Pilot Pilot { get; set; }
    public int PilotId { get; set; }
    public decimal? Price { get; set; }
    public short Seats { get; set; }

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
    //***
    // Action
    //   - Returns some information about the flight
    // Called by
    //   - 
    // Calls
    //   - DateTime Date (Get)
    //   - int FlightNo (Get)
    //   - short? FreeSeats (Get)
    //   - string Departure (Get)
    //   - string Destination (Get)
    // Created
    //   - CopyPaste – 20230711 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230711 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return String.Format($"Flight #{FlightNo}: from {Departure} to {Destination} on {Date:dd.MM.yy HH:mm}: {FreeSeats} free Seats.");
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string ToShortString()
    //***
    // Action
    //   - Returns some information about the flight
    // Called by
    //   - 
    // Calls
    //   - DateTime Date (Get)
    //   - int FlightNo (Get)
    //   - short? FreeSeats (Get)
    //   - string Departure (Get)
    //   - string Destination (Get)
    // Created
    //   - CopyPaste – 20230711 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230711 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return String.Format($"Flight #{FlightNo}: {Departure}->{Destination} {Date:dd.MM.yy HH:mm}: {FreeSeats} free Seats.");
    }
    // ToShortString()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Flight

}
// CopyPaste.BusinessObjects 