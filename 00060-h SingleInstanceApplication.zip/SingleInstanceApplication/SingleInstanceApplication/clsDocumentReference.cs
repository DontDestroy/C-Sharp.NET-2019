﻿//***
// Action
//   - Define what a cpDocumentReference is
//   - It contains a reference to a document window and its name
//   - The purpose of this class is to make it easier to display the list
//     of window names in DocumentList
//   - The technique of data binding is used
// Created
//   - CopyPaste – 20220817 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220817 – VVDW
// Proposal (To Do)
//   -
//***

namespace SingleInstanceApplication
{

  public class cpDocumentReference
  {

    #region "Constructors / Destructors"

    public cpDocumentReference(wpfcpDocument acpDocument, string strName)
    //***
    // Action
    //   - Creates an instance of a cpDocumentReference
    // Called by
    //   - cpwpfApplication.ShowDocument(string)
    // Calls
    //   - Document(wpfcpDocument) (Set)
    //   - Name(string) (Set)
    // Created
    //   - CopyPaste – 20220817 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220817 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Document = acpDocument;
      Name = strName;
    }
    // cpDocumentReference(wpfcpDocument, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string strName;
    private wpfcpDocument thecpDocument;

    #endregion

    #region "Properties"

    public wpfcpDocument Document
    {

      get
      //***
      // Action Get
      //   - Returns the cpDocument
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220817 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220817 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return thecpDocument;
      }
      // wpfcpDocument Document (Get)

      set
      //***
      // Action Set
      //   - Defines the cpDocument
      // Called by
      //   - cpDocumentReference(wpfcpDocument, string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220817 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220817 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        thecpDocument = value; 
      }
      // Document(wpfcpDocument) (Set)

    }
    // wpfcpDocument Document

    public string Name
    {

      get
      //***
      // Action Get
      //   - Returns the name of the document
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220817 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220817 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return strName; 
      }
      // string Name (Get)

      set
      //***
      // Action Set
      //   - Defines the name of the document
      // Called by
      //   - cpDocumentReference(wpfcpDocument, string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220817 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220817 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        strName = value; 
      }
      // Name(string) (Set)

    }
    // string Name

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpDocumentReference

}
// SingleInstanceApplication