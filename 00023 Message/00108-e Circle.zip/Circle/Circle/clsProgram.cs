//***
// Action
//   - Testroutine of an instance of cpCircle
// Created
//   - CopyPaste � 20231229 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231229 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Math;
using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace Circle
{

	public class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main()
			//***
			// Action
			//   - Create a new instance of a cpCircle
			//   - Get some properties
			//   - Set some properties
			//   - Use of ToString()
			//   - Show the diameter
			//   - Show the circumference
			//   - Show the area
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - cpCircle(int, int, double)
			//   - cpCircle.Radius(double) (Set)
			//   - cpCircle.X(int) (Set)
			//   - cpCircle.Y(int) (Set)
			//   - double cpCircle.Area()
			//   - double cpCircle.Circumference()
			//   - double cpCircle.Diameter()
			//   - double cpCircle.Radius() (Get)
			//   - int cpCircle.X() (Get)
			//   - int cpCircle.Y() (Get)
			//   - string cpCircle.ToString()
			// Created
			//   - CopyPaste � 20231229 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231229 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			string strOutput;
			cpCircle thecpCircle;

			thecpCircle = new cpCircle(37, 43, 2.5);

			strOutput = "X coordinate is " + thecpCircle.X + ControlChars.CrLf + 
				"Y coordinate is " + thecpCircle.Y + Environment.NewLine + 
				"Radius is " + thecpCircle.Radius;
			MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

			thecpCircle.X = 2;
			thecpCircle.Y = 2;
			thecpCircle.Radius = 4.25;

			strOutput = "The new location and radius of circle are " + Environment.NewLine + thecpCircle.ToString();
			MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

			strOutput = "Diameter is " + String.Format("{0:F}", thecpCircle.Diameter());
			MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

			strOutput = "Circumference is " + String.Format("{0:F}", thecpCircle.Circumference());
			MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

			strOutput = "Area is " + String.Format("{0:F}", thecpCircle.Area());
			MessageBox.Show(strOutput, "Demonstrating Class cpCircle");
		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpProgram

}
// Circle