//***
// Action
//   - Show all the changes that happens on the T:\ directory and subdirectories
// Created
//   - CopyPaste � 20240902 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240902 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFileWatcher: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
		internal TextBox txtChangedFiles;
		private System.ComponentModel.BackgroundWorker backgroundWorker1;
		internal System.Windows.Forms.Label lblChangedFiles;

    private void InitializeComponent()
    {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFileWatcher));
			this.lblChangedFiles = new System.Windows.Forms.Label();
			this.txtChangedFiles = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// lblChangedFiles
			// 
			this.lblChangedFiles.Location = new System.Drawing.Point(22, 18);
			this.lblChangedFiles.Name = "lblChangedFiles";
			this.lblChangedFiles.Size = new System.Drawing.Size(100, 23);
			this.lblChangedFiles.TabIndex = 3;
			this.lblChangedFiles.Text = "Changed files";
			// 
			// txtChangedFiles
			// 
			this.txtChangedFiles.Location = new System.Drawing.Point(22, 48);
			this.txtChangedFiles.Multiline = true;
			this.txtChangedFiles.Name = "txtChangedFiles";
			this.txtChangedFiles.Size = new System.Drawing.Size(388, 206);
			this.txtChangedFiles.TabIndex = 2;
			this.txtChangedFiles.Text = "Information can be also be found in the Output window (due to threading confilct)" +
    "";
			// 
			// frmFileWatcher
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(432, 273);
			this.Controls.Add(this.lblChangedFiles);
			this.Controls.Add(this.txtChangedFiles);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmFileWatcher";
			this.Text = "File Watcher";
			this.ResumeLayout(false);
			this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFileWatcher'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFileWatcher()
      //***
      // Action
      //   - Create instance of 'frmFileWatcher'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFileWatcher()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrText;
    private FileSystemWatcher theFileWatcher = new FileSystemWatcher("T:\\");

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void OnLoad(EventArgs theEventArguments)
    //***
    // Action
    //   - Set the filter to all files
    //   - Include subdirectories
    //   - Enable raising events
    //   - Syncronizing the object must be done, otherwise you have a thread error
    // Called by
    //   - System action (Loading the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20240902 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20240902 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      theFileWatcher.Filter = "*.*";
      theFileWatcher.IncludeSubdirectories = true;
      theFileWatcher.EnableRaisingEvents = true;
      theFileWatcher.Changed += new FileSystemEventHandler(theFileWatcher_Changed);
      theFileWatcher.SynchronizingObject = this;
      base.OnLoad(theEventArguments);
    }
    // OnLoad(EventArgs theEventArguments)

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private void theFileWatcher_Changed(System.Object theSender, FileSystemEventArgs theFileSystemEventArguments)
    //***
    // Action
    //   - Define the current date and time
    //   - Define a new line
    //   - Append text to form with the changed file
    //     - What changed and when
    //     - Pay attention to thread errors
    // Called by
    //   - System action (Changed event is triggered)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20240902 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20240902 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      DateTime dtmDateTime = DateTime.Now;
      string strCrLF = Environment.NewLine;

      mstrText = theFileSystemEventArguments.FullPath + " " + theFileSystemEventArguments.ChangeType + " " + dtmDateTime + strCrLF + strCrLF;

      txtChangedFiles.AppendText(mstrText);
      // VVDW - Without the code "theFileWatcher.SynchronizingObject = this;", you will have a thread error
      // VVDW - Thread error can be solved with code below

      // if (txtChangedFiles.InvokeRequired)
      // {
      //   txtChangedFiles.Invoke(
      //     new MethodInvoker(
      //       delegate { txtChangedFiles.AppendText(mstrText); }
      //       ));
      // }

      Debug.Print(mstrText);
    }
    // theFileWatcher_Changed(System.Object, FileSystemEventArgs) Handles theFileWatcher.Changed

    #endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFileWatcher
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmFileWatcher()
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFileWatcher());
    }
		// Main() 

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
  // frmFileWatcher

}
// CopyPaste.Learning