﻿//***
// Action
//   - Implementation of a cpDecoyDuck
//     - Inherits from cpDuck, where Display (how do I look like) is an abstract method
//       - All class that inherit from cpDuck must implement the Display method
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
//   - The way a cpPlasticRubberDuck moves on water is inherited
//     - All cpDuck and child classes moves on water the same way
// Created
//   - CopyPaste – 20240718 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240718 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Game.Duck.Library
{

	public class cpDecoyDuck : cpDuck
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpDecoyDuck
		/// </summary>
		public cpDecoyDuck() : base()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - User action (Creating an instance)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpDecoyDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		#region "Overrides"

		/// <summary>
		/// The visualization (displaying) of a cpDecoyDuck
		/// </summary>
		public override void Display()
		//***
		// Action
		//   - Define how a cpDecoyDuck looks like
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Representation of a cpDecoyDuck");
		}
		// Display()

		#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpDecoyDuck

}
// CopyPaste.Game.Duck.Library