﻿//***
// Action
//   - Definition of a Key Customer 
// Created
//   - CopyPaste – 20050508 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20050508 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpKeyCustomer: cpCustomer
  {

    #region "Constructors / Destructors"

    public cpKeyCustomer(string strKeyCustomer)
      //***
      // Action
      //   - Create new instance of 'cpKeyCustomer' with a given string
      //   - If the given string is validated
      //     - 'mstrKeyCustomer' becomes 'strKeyCustomer'
      //   - If not
      //     - Throw a new cpInvalidKeyCustomerException
      // Called by
      //   - cpCustomer(cpKeyCustomer, string)
      //   - cpCustomer.ReadValuesFromDataRow()
      //   - frmCustomerValidationBetter.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      // Calls
      //   - cpInvalidKeyCustomerException(string)
      //   - Validate(string)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (Validate(strKeyCustomer))
      {
        mstrKeyCustomer = strKeyCustomer;
      }
      else
        // Not Validate(strKeyCustomer)
      {
        throw new cpInvalidKeyCustomerException(strKeyCustomer);
      }
      // Validate(strKeyCustomer)

    }
    // cpKeyCustomer(string)

    public cpKeyCustomer(cpKeyCustomer thecpKeyCustomer)
      //***
      // Action
      //   - Create new instance of 'cpKeyCustomer' with a cpKeyCustomer
      //   - 'mstrKeyCustomer' becomes 'cpKeyCustomer'.KeyCustomer
      // Called by
      //   - cpCustomer(cpKeyCustomer, string)
      // Calls
      //   - string cpKeyCustomer.KeyCustomer (Get)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrKeyCustomer = thecpKeyCustomer.KeyCustomer;
    }
    // cpKeyCustomer(cpKeyCustomer)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrKeyCustomer;
    public delegate void CheckBeforeUpdate(string strValue, out bool blnCancel);
    // cpCustomer(cpKeyCustomer, string)

    #endregion

    #region "Properties"

    public string KeyCustomer
    {

      get
        //***
        // Action Get
        //   - Return 'mstrKeyCustomer'
        // Called by
        //   - bool cpCustomer.Save() Implements cpiCustomer.Save
        //   - cpKeyCustomer(cpKeyCustomer)
        //   - cpCustomer(cpKeyCustomer, string)
        //   - string ToString() Implements cpiCustomer.ToString
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrKeyCustomer;
      }
      // string KeyCustomer (Get)

      set
        //***
        // Action Set
        //   - Raise the event BeforeUpdate
        //   - If Cancelled
        //     - Do nothing
        //   - If not
        //     - If Validation of strValue is true
        //       - mstrKeyCustomer becomes strValue
        //     - If not
        //       - Throw new cpInvalidKeyCustomerException with correct info
        // Called by
        //   - cpCustomer.ReadValuesFromDataRow()
        // Calls
        //   - bool Validate(string)
        //   - cpInvalidKeyCustomerException(string)
        //   - StringValueBeforeUpdate(string, °bool)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        bool blnCancel = false;
        
        if (StringValueBeforeUpdate == null)
        {
        }
        else
          // StringValueBeforeUpdate <> null
        {
          StringValueBeforeUpdate(value, out blnCancel);
        }
        // StringValueBeforeUpdate <> null

        if (blnCancel)
        {
        }
        else
          // Not blnCancel 
        {

          if (Validate(value))
          {
            mstrKeyCustomer = value;
          }
          else
            // Not Validate(value)
          {
            throw new cpInvalidKeyCustomerException(value);
          }
          // Validate(value)

        }
        // blnCancel 

      }
      // KeyCustomer(string) (Set)

    }
    // string KeyCustomer

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public event CheckBeforeUpdate StringValueBeforeUpdate;
    // KeyCustomer(string) (Set)
    // cpCustomer.mtheIdCustomer_StringValueBeforeUpdate(string, °bool) Handles mtheIdCustomer.StringValueBeforeUpdate

    #endregion

    #region "Sub / Function"

    public bool Exists(string strKeyCustomer)
      //***
      // Action
      //   - Define a boolean
      //   - Define a SQL command
      //   - Define and set a SQL Statement
      //     - Count the customers with a specific key (strKeyCustomer)
      //   - Set the SQL command with the SQL statement and the connection
      //   - Open the connection
      //   - Execute the SQL command (what returns a number (0 or 1)
      //   - Convert the result to a boolean
      //   - Close the connection
      //   - Return the boolean
      // Called by
      //   - cpCustomer(cpKeyCustomer, string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnExists;
      SqlCommand cmmSelect;
      string strSQLStatement;

      strSQLStatement = "SELECT Count(*) FROM tblCPCustomer WHERE strIdCustomer = '" + strKeyCustomer + "'";
      cmmSelect = new SqlCommand(strSQLStatement, cnncpNorthwindScript);
      cnncpNorthwindScript.Open();
      blnExists = Convert.ToBoolean(cmmSelect.ExecuteScalar());
      cnncpNorthwindScript.Close();
      return blnExists;
    }
		// bool Exists(string)

    private bool Validate(string strKeyCustomer)
      //***
      // Action
      //   - Check if the customer key is 5 long
      // Called by
      //   - KeyCustomer(String) (Set)
      //   - New(String)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return (strKeyCustomer.Trim().Length == 5);
    }
    // bool Validate(string)

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpKeyCustomer

}
// CopyPaste.Learning