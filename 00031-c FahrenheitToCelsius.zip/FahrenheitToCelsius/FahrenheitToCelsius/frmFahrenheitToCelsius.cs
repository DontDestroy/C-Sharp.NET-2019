//***
// Action
//   - Ask a certain degrees and calculate the temperature in Celsius
//    - The absolute minimum temperature is not taken into account
// Created
//   - CopyPaste � 20230807 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230807 � VVDW
// Proposal (To Do)
//   - When no number is typed, the application fails
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace CopyPaste.Learning
{

  public class frmFahrenheitToCelsius : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFahrenheitToCelsius));
      // 
      // frmFahrenheitToCelsius
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFahrenheitToCelsius";
      this.Text = "Fahrenheit To Celsius";
      this.Load += new System.EventHandler(this.frmFahrenheitToCelsius_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFahrenheitToCelsius'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFahrenheitToCelsius()
      //***
      // Action
      //   - Create instance of 'frmFahrenheitToCelsius'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFahrenheitToCelsius()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmFahrenheitToCelsius_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Loop till somebody entered an input
      //     - If there is an input
      //       - A conversion to degrees Celsius is calculated
      //       - Result is shown
      //     - If not
      //       - Do nothing
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - Application fails if input is not a number
      //***
    {

      string strFahrenheit;
      string strPrompt = "Give a Fahrenheit number.";
      System.Single sngCelsius;
      System.Single sngFahrenheit;

      do
      {
        strFahrenheit = Interaction.InputBox(strPrompt, "Fahrenheit to Celsius", "", 0, 0);

        if (strFahrenheit == "")
        {
        }
        else
          // strFahrenheit <> ""
        {
          sngFahrenheit = Convert.ToSingle(strFahrenheit);
          sngCelsius = (int)((sngFahrenheit + 40) * 5 / 9 - 40);
          MessageBox.Show(sngCelsius.ToString(), "Temperature in Celsius");
        }
        // strFarenheit = ""

      }
      while (strFahrenheit != "");
      // strFahrenheit = ""

      Application.Exit();
      // VVDW - Is this useful?
    }
    // frmFahrenheitToCelsius_Load(System.Object, System.EventArgs) Handles frmFahrenheitToCelsius.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFahrenheitToCelsius
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFahrenheitToCelsius());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmFahrenheitToCelsius

}
// CopyPaste.Learning