//***
// Action
//   - Shows a message on a console screen
// Created
//   - CopyPaste � 20210823 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210823 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Welcome
{

  class cpWelcome
	{

    static void Main()
    //***
    // Action
    //   - Place text on console screen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - System.Console.Writeline(string)
    // Created
    //   - CopyPaste � 20210823 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210823 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Welcome to C# .NET 2019");
    }
    // Main()

  }
  // cpWelcome

}
// Welcome