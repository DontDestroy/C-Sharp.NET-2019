﻿//***
// Action
//   - Implementation of a cpMessageMorseByOutputWindow
//		 - The way a Morse code is send by Output window (Text on immediate or output window)
// Created
//   - CopyPaste – 20241227 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20241227 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.MorseCode.Library
{

	public class cpMorseByOutputWindow : cpiMessageMorse
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpMorseByOutputWindow
		/// </summary>
		public cpMorseByOutputWindow(int intSpeed)
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - CopyPaste.MorseCode.Test.cpProgram()
		//   - CopyPaste.MorseCode.frmMorseCode.cmdSend_Click(System.Object, EventArgs) Handles cmdSend.Click
		//   - cpMorse(int)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20241227 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20241227 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			_intSpeed = intSpeed;
		}
		// cpMorseByOutputWindow(int)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private int _intSpeed;
		private string _strOutputWindow = "";

		#endregion

		#region "Properties"

		public string OutputWindow
		{

			get
			//***
			// Action Get
			//   - Return _strOutputWindow
			// Called by
			//   - CopyPaste.MorseCode.frmMorseCode.cmdSend_Click(System.Object, EventArgs) Handles cmdSend.Click
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20241227 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20241227 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return _strOutputWindow;
			}
			// string OutputWindow (Get)

		}
		// string OutputWindow 

		#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		///  Define how a message is send by sound
		/// </summary>
		/// <param name="lstMessage"></param>
		/// <returns>A list of cpSignalItem</returns>
		public void SendMessage(List<cpSignalItem> lstMessage)
		//***
		// Action
		//   - Define how a list of signal items is send in Morse (by immediate or output window)
		//   - A debug window message is shown
		//   - Loop thru all the signal items
		//     - If there is a signal
		//       - If signal length is equal to the speed
		//         - A dot is add to the output window
		//       - If not
		//         - A dash is add to the output window
		//     - If not
		//       - Depending on the length, some spaces are added to the output window
		// Called by
		//   - cpMorse() (indirectly, thru delegates)
		// Calls
		//   - int cpSignalItem.Length (Get)
		//   - string cpSignalItem.Signal (Get)
		// Created
		//   - CopyPaste – 20241227 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20241227 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Message of {0} items is send by immediate / output window", lstMessage.Count);
			_strOutputWindow = "";

			foreach (cpSignalItem theSignalItem in lstMessage)
			{
				Debug.Print("Send {0} for {1} milliseconds by immediate / output window", theSignalItem.Signal, theSignalItem.Length);

				if (theSignalItem.Signal)
				{

					if (theSignalItem.Length == _intSpeed)
					{
						_strOutputWindow += ".";
					}
					else
					{
						_strOutputWindow += "_";
					}

				}
				// Not theSignalItem.Signal
				else
				{
					int intLength = theSignalItem.Length;

					while (intLength >= _intSpeed)
					{
						_strOutputWindow += " ";
						intLength -= _intSpeed;
					}
					// intLength < _intSpeed

				}
				// theSignalItem.Signal

			}
			// in lstMessage

		}
		// List<cpSignalItem> SendMessage(string)

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpMorseByOutputWindow

}
// CopyPaste.MorseCode.Library