﻿//***
// Action
//   - Testroutine for cpiWeapon, cpKing, cpKnight, cpQueen, cpTroll
// Created
//   - CopyPaste – 20240806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240806 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Character.Library;
using CopyPaste.Game.Weapon.Library;
using System.Diagnostics;

namespace CopyPaste.Game.Character.Test
{

	internal static class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		///  The main entry point for the test application
		/// </summary>
		public static void Main()
		//***
		// Action
		//   - Start application
		//   - Create a list of cpGameCharacter
		//   - Add a cpKing, cpKnight, cpQueen and a cpTroll to it
		//   - Loop thru all the game characters
		//     - Let the game character fight
		//   - Change the weapon behaviour of the Queen
		//   - Remove the weapon behaviour of the Troll
		//   - Loop thru all the game characters
		//     - Let the game character fight
		//   - Show some information on where to check if it was successful
		//   - Wait for the user to hit the keyboard
		// Called by
		//   - User action (Starting the application)
		// Calls
		//   - CopyPaste.Game.Character.Library.cpGameCharacter.CleanBehaviour()
		//   - CopyPaste.Game.Character.Library.cpGameCharacter.Fight()
		//   - CopyPaste.Game.Character.Library.cpKing()
		//   - CopyPaste.Game.Character.Library.cpKnight()
		//   - CopyPaste.Game.Character.Library.cpQueen()
		//   - CopyPaste.Game.Character.Library.cpTroll()
		//   - CopyPaste.Game.Weapon.Library.cpBowAndArrow()
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			List<cpGameCharacter> lstGameCharacters = new List<cpGameCharacter>();

			cpKing aKing = new cpKing();
			cpKnight aKnight = new cpKnight();
			cpQueen aQueen = new cpQueen();
			cpTroll aTroll = new cpTroll();

			lstGameCharacters.Add(aKing);
			lstGameCharacters.Add(aKnight);
			lstGameCharacters.Add(aQueen);
			lstGameCharacters.Add(aTroll);

			Debug.Print("Executing the fighting behaviour of all the game characters in the list");
			Debug.Print("");

			foreach (cpGameCharacter theGameCharacter in lstGameCharacters)
			{
				string strType = theGameCharacter.GetType().Name;

				Debug.Print(strType);
				theGameCharacter.Fight();
				Debug.Print("");
			}
			// in lstGameCharacters

			// Decided that a queen can fight with a bow and arrow (this changes the behaviour that was defined in the constructor)
			aQueen.HowToFight = new cpBowAndArrow();
			// Decided that a troll has no weapon anymore (this changes the behaviour that was defined in the constructor)
			aTroll.CleanBehaviour();

			Debug.Print("The behaviour of some game characters is changed at runtime.");
			Debug.Print("Executing again the fighting behaviour of all the game characters in the list");
			Debug.Print("");

			foreach (cpGameCharacter theGameCharacter in lstGameCharacters)
			{
				string strType = theGameCharacter.GetType().Name;

				Debug.Print(strType);
				theGameCharacter.Fight();
				Debug.Print("");
			}
			// in lstGameCharacters

			Console.WriteLine("Information about the execution of methods can be found in the output window");
			Console.WriteLine();
			Console.WriteLine("Hit any key to exit the program ...");
			Console.ReadLine();
		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#Region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.Game.Character.Test