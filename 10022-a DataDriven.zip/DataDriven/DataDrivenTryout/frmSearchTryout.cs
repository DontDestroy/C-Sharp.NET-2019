//***
// Action
//   - Search customer information using a letter (or all letters)
//   - The goal is to select one customer, accept it, and show the detailed information in another screen
//   - The other screen is the caller of the instance of this form
// Created
//   - CopyPaste � 20251211 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251211 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSearchTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdAccept;
    internal System.Windows.Forms.Button cmdCancel;
    internal System.Windows.Forms.GroupBox grpSearch;
    internal System.Windows.Forms.Button cmdAll;
    internal System.Windows.Forms.Button cmdZ;
    internal System.Windows.Forms.Button cmdY;
    internal System.Windows.Forms.Button cmdX;
    internal System.Windows.Forms.Button cmdW;
    internal System.Windows.Forms.Button cmdV;
    internal System.Windows.Forms.Button cmdU;
    internal System.Windows.Forms.Button cmdT;
    internal System.Windows.Forms.Button cmdS;
    internal System.Windows.Forms.Button cmdR;
    internal System.Windows.Forms.Button cmdQ;
    internal System.Windows.Forms.Button cmdP;
    internal System.Windows.Forms.Button cmdO;
    internal System.Windows.Forms.Button cmdN;
    internal System.Windows.Forms.Button cmdM;
    internal System.Windows.Forms.Button cmdL;
    internal System.Windows.Forms.Button cmdK;
    internal System.Windows.Forms.Button cmdJ;
    internal System.Windows.Forms.Button cmdI;
    internal System.Windows.Forms.Button cmdH;
    internal System.Windows.Forms.Button cmdG;
    internal System.Windows.Forms.Button cmdF;
    internal System.Windows.Forms.Button cmdE;
    internal System.Windows.Forms.Button cmdD;
    internal System.Windows.Forms.Button cmdC;
    internal System.Windows.Forms.Button cmdB;
    internal System.Windows.Forms.Button cmdA;
    internal System.Windows.Forms.DataGrid dgrSearch;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSearchTryout));
      this.cmdAccept = new System.Windows.Forms.Button();
      this.cmdCancel = new System.Windows.Forms.Button();
      this.grpSearch = new System.Windows.Forms.GroupBox();
      this.cmdAll = new System.Windows.Forms.Button();
      this.cmdZ = new System.Windows.Forms.Button();
      this.cmdY = new System.Windows.Forms.Button();
      this.cmdX = new System.Windows.Forms.Button();
      this.cmdW = new System.Windows.Forms.Button();
      this.cmdV = new System.Windows.Forms.Button();
      this.cmdU = new System.Windows.Forms.Button();
      this.cmdT = new System.Windows.Forms.Button();
      this.cmdS = new System.Windows.Forms.Button();
      this.cmdR = new System.Windows.Forms.Button();
      this.cmdQ = new System.Windows.Forms.Button();
      this.cmdP = new System.Windows.Forms.Button();
      this.cmdO = new System.Windows.Forms.Button();
      this.cmdN = new System.Windows.Forms.Button();
      this.cmdM = new System.Windows.Forms.Button();
      this.cmdL = new System.Windows.Forms.Button();
      this.cmdK = new System.Windows.Forms.Button();
      this.cmdJ = new System.Windows.Forms.Button();
      this.cmdI = new System.Windows.Forms.Button();
      this.cmdH = new System.Windows.Forms.Button();
      this.cmdG = new System.Windows.Forms.Button();
      this.cmdF = new System.Windows.Forms.Button();
      this.cmdE = new System.Windows.Forms.Button();
      this.cmdD = new System.Windows.Forms.Button();
      this.cmdC = new System.Windows.Forms.Button();
      this.cmdB = new System.Windows.Forms.Button();
      this.cmdA = new System.Windows.Forms.Button();
      this.dgrSearch = new System.Windows.Forms.DataGrid();
      this.grpSearch.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgrSearch)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdAccept
      // 
      this.cmdAccept.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdAccept.Location = new System.Drawing.Point(300, 342);
      this.cmdAccept.Name = "cmdAccept";
      this.cmdAccept.Size = new System.Drawing.Size(80, 24);
      this.cmdAccept.TabIndex = 6;
      this.cmdAccept.Text = "&Accept";
      this.cmdAccept.Click += new System.EventHandler(this.cmdAccept_Click);
      // 
      // cmdCancel
      // 
      this.cmdCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdCancel.Location = new System.Drawing.Point(396, 342);
      this.cmdCancel.Name = "cmdCancel";
      this.cmdCancel.Size = new System.Drawing.Size(80, 24);
      this.cmdCancel.TabIndex = 7;
      this.cmdCancel.Text = "&Cancel";
      this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
      // 
      // grpSearch
      // 
      this.grpSearch.Controls.Add(this.cmdAll);
      this.grpSearch.Controls.Add(this.cmdZ);
      this.grpSearch.Controls.Add(this.cmdY);
      this.grpSearch.Controls.Add(this.cmdX);
      this.grpSearch.Controls.Add(this.cmdW);
      this.grpSearch.Controls.Add(this.cmdV);
      this.grpSearch.Controls.Add(this.cmdU);
      this.grpSearch.Controls.Add(this.cmdT);
      this.grpSearch.Controls.Add(this.cmdS);
      this.grpSearch.Controls.Add(this.cmdR);
      this.grpSearch.Controls.Add(this.cmdQ);
      this.grpSearch.Controls.Add(this.cmdP);
      this.grpSearch.Controls.Add(this.cmdO);
      this.grpSearch.Controls.Add(this.cmdN);
      this.grpSearch.Controls.Add(this.cmdM);
      this.grpSearch.Controls.Add(this.cmdL);
      this.grpSearch.Controls.Add(this.cmdK);
      this.grpSearch.Controls.Add(this.cmdJ);
      this.grpSearch.Controls.Add(this.cmdI);
      this.grpSearch.Controls.Add(this.cmdH);
      this.grpSearch.Controls.Add(this.cmdG);
      this.grpSearch.Controls.Add(this.cmdF);
      this.grpSearch.Controls.Add(this.cmdE);
      this.grpSearch.Controls.Add(this.cmdD);
      this.grpSearch.Controls.Add(this.cmdC);
      this.grpSearch.Controls.Add(this.cmdB);
      this.grpSearch.Controls.Add(this.cmdA);
      this.grpSearch.Location = new System.Drawing.Point(12, 6);
      this.grpSearch.Name = "grpSearch";
      this.grpSearch.Size = new System.Drawing.Size(464, 88);
      this.grpSearch.TabIndex = 4;
      this.grpSearch.TabStop = false;
      this.grpSearch.Text = "Click on a Letter";
      // 
      // cmdAll
      // 
      this.cmdAll.Location = new System.Drawing.Point(392, 48);
      this.cmdAll.Name = "cmdAll";
      this.cmdAll.Size = new System.Drawing.Size(64, 24);
      this.cmdAll.TabIndex = 26;
      this.cmdAll.Text = "All";
      this.cmdAll.Click += new System.EventHandler(this.cmdAll_Click);
      // 
      // cmdZ
      // 
      this.cmdZ.Location = new System.Drawing.Point(360, 48);
      this.cmdZ.Name = "cmdZ";
      this.cmdZ.Size = new System.Drawing.Size(32, 24);
      this.cmdZ.TabIndex = 25;
      this.cmdZ.Text = "Z";
      this.cmdZ.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdY
      // 
      this.cmdY.Location = new System.Drawing.Point(328, 48);
      this.cmdY.Name = "cmdY";
      this.cmdY.Size = new System.Drawing.Size(32, 24);
      this.cmdY.TabIndex = 24;
      this.cmdY.Text = "Y";
      this.cmdY.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdX
      // 
      this.cmdX.Location = new System.Drawing.Point(296, 48);
      this.cmdX.Name = "cmdX";
      this.cmdX.Size = new System.Drawing.Size(32, 24);
      this.cmdX.TabIndex = 23;
      this.cmdX.Text = "X";
      this.cmdX.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdW
      // 
      this.cmdW.Location = new System.Drawing.Point(264, 48);
      this.cmdW.Name = "cmdW";
      this.cmdW.Size = new System.Drawing.Size(32, 24);
      this.cmdW.TabIndex = 22;
      this.cmdW.Text = "W";
      this.cmdW.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdV
      // 
      this.cmdV.Location = new System.Drawing.Point(232, 48);
      this.cmdV.Name = "cmdV";
      this.cmdV.Size = new System.Drawing.Size(32, 24);
      this.cmdV.TabIndex = 21;
      this.cmdV.Text = "V";
      this.cmdV.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdU
      // 
      this.cmdU.Location = new System.Drawing.Point(200, 48);
      this.cmdU.Name = "cmdU";
      this.cmdU.Size = new System.Drawing.Size(32, 24);
      this.cmdU.TabIndex = 20;
      this.cmdU.Text = "U";
      this.cmdU.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdT
      // 
      this.cmdT.Location = new System.Drawing.Point(168, 48);
      this.cmdT.Name = "cmdT";
      this.cmdT.Size = new System.Drawing.Size(32, 24);
      this.cmdT.TabIndex = 19;
      this.cmdT.Text = "T";
      this.cmdT.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdS
      // 
      this.cmdS.Location = new System.Drawing.Point(136, 48);
      this.cmdS.Name = "cmdS";
      this.cmdS.Size = new System.Drawing.Size(32, 24);
      this.cmdS.TabIndex = 18;
      this.cmdS.Text = "S";
      this.cmdS.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdR
      // 
      this.cmdR.Location = new System.Drawing.Point(104, 48);
      this.cmdR.Name = "cmdR";
      this.cmdR.Size = new System.Drawing.Size(32, 24);
      this.cmdR.TabIndex = 17;
      this.cmdR.Text = "R";
      this.cmdR.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdQ
      // 
      this.cmdQ.Location = new System.Drawing.Point(72, 48);
      this.cmdQ.Name = "cmdQ";
      this.cmdQ.Size = new System.Drawing.Size(32, 24);
      this.cmdQ.TabIndex = 16;
      this.cmdQ.Text = "Q";
      this.cmdQ.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdP
      // 
      this.cmdP.Location = new System.Drawing.Point(40, 48);
      this.cmdP.Name = "cmdP";
      this.cmdP.Size = new System.Drawing.Size(32, 24);
      this.cmdP.TabIndex = 15;
      this.cmdP.Text = "P";
      this.cmdP.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdO
      // 
      this.cmdO.Location = new System.Drawing.Point(8, 48);
      this.cmdO.Name = "cmdO";
      this.cmdO.Size = new System.Drawing.Size(32, 24);
      this.cmdO.TabIndex = 14;
      this.cmdO.Text = "O";
      this.cmdO.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdN
      // 
      this.cmdN.Location = new System.Drawing.Point(424, 24);
      this.cmdN.Name = "cmdN";
      this.cmdN.Size = new System.Drawing.Size(32, 24);
      this.cmdN.TabIndex = 13;
      this.cmdN.Text = "N";
      this.cmdN.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdM
      // 
      this.cmdM.Location = new System.Drawing.Point(392, 24);
      this.cmdM.Name = "cmdM";
      this.cmdM.Size = new System.Drawing.Size(32, 24);
      this.cmdM.TabIndex = 12;
      this.cmdM.Text = "M";
      this.cmdM.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdL
      // 
      this.cmdL.Location = new System.Drawing.Point(360, 24);
      this.cmdL.Name = "cmdL";
      this.cmdL.Size = new System.Drawing.Size(32, 24);
      this.cmdL.TabIndex = 11;
      this.cmdL.Text = "L";
      this.cmdL.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdK
      // 
      this.cmdK.Location = new System.Drawing.Point(328, 24);
      this.cmdK.Name = "cmdK";
      this.cmdK.Size = new System.Drawing.Size(32, 24);
      this.cmdK.TabIndex = 10;
      this.cmdK.Text = "K";
      this.cmdK.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdJ
      // 
      this.cmdJ.Location = new System.Drawing.Point(296, 24);
      this.cmdJ.Name = "cmdJ";
      this.cmdJ.Size = new System.Drawing.Size(32, 24);
      this.cmdJ.TabIndex = 9;
      this.cmdJ.Text = "J";
      this.cmdJ.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdI
      // 
      this.cmdI.Location = new System.Drawing.Point(264, 24);
      this.cmdI.Name = "cmdI";
      this.cmdI.Size = new System.Drawing.Size(32, 24);
      this.cmdI.TabIndex = 8;
      this.cmdI.Text = "I";
      this.cmdI.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdH
      // 
      this.cmdH.Location = new System.Drawing.Point(232, 24);
      this.cmdH.Name = "cmdH";
      this.cmdH.Size = new System.Drawing.Size(32, 24);
      this.cmdH.TabIndex = 7;
      this.cmdH.Text = "H";
      this.cmdH.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdG
      // 
      this.cmdG.Location = new System.Drawing.Point(200, 24);
      this.cmdG.Name = "cmdG";
      this.cmdG.Size = new System.Drawing.Size(32, 24);
      this.cmdG.TabIndex = 6;
      this.cmdG.Text = "G";
      this.cmdG.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdF
      // 
      this.cmdF.Location = new System.Drawing.Point(168, 24);
      this.cmdF.Name = "cmdF";
      this.cmdF.Size = new System.Drawing.Size(32, 24);
      this.cmdF.TabIndex = 5;
      this.cmdF.Text = "F";
      this.cmdF.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdE
      // 
      this.cmdE.Location = new System.Drawing.Point(136, 24);
      this.cmdE.Name = "cmdE";
      this.cmdE.Size = new System.Drawing.Size(32, 24);
      this.cmdE.TabIndex = 4;
      this.cmdE.Text = "E";
      this.cmdE.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdD
      // 
      this.cmdD.Location = new System.Drawing.Point(104, 24);
      this.cmdD.Name = "cmdD";
      this.cmdD.Size = new System.Drawing.Size(32, 24);
      this.cmdD.TabIndex = 3;
      this.cmdD.Text = "D";
      this.cmdD.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdC
      // 
      this.cmdC.Location = new System.Drawing.Point(72, 24);
      this.cmdC.Name = "cmdC";
      this.cmdC.Size = new System.Drawing.Size(32, 24);
      this.cmdC.TabIndex = 2;
      this.cmdC.Text = "C";
      this.cmdC.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdB
      // 
      this.cmdB.Location = new System.Drawing.Point(40, 24);
      this.cmdB.Name = "cmdB";
      this.cmdB.Size = new System.Drawing.Size(32, 24);
      this.cmdB.TabIndex = 1;
      this.cmdB.Text = "B";
      this.cmdB.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // cmdA
      // 
      this.cmdA.Location = new System.Drawing.Point(8, 24);
      this.cmdA.Name = "cmdA";
      this.cmdA.Size = new System.Drawing.Size(32, 24);
      this.cmdA.TabIndex = 0;
      this.cmdA.Text = "A";
      this.cmdA.Click += new System.EventHandler(this.cmdLetter_Click);
      // 
      // dgrSearch
      // 
      this.dgrSearch.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrSearch.DataMember = "";
      this.dgrSearch.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrSearch.Location = new System.Drawing.Point(12, 102);
      this.dgrSearch.Name = "dgrSearch";
      this.dgrSearch.ReadOnly = true;
      this.dgrSearch.Size = new System.Drawing.Size(464, 232);
      this.dgrSearch.TabIndex = 5;
      // 
      // frmSearchTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(488, 373);
      this.Controls.Add(this.cmdAccept);
      this.Controls.Add(this.cmdCancel);
      this.Controls.Add(this.grpSearch);
      this.Controls.Add(this.dgrSearch);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSearchTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "SearchingTryout";
      this.Load += new System.EventHandler(this.frmSearchTryout_Load);
      this.grpSearch.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgrSearch)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSearchTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSearchTryout()
      //***
      // Action
      //   - Create instance of 'frmSearchTryout'
      // Called by
      //   - frmTrySearchTryout.cmdSearch_Click(System.Object, System.EventArgs) Handles cmdSearch.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSearchTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public string DisplayName
    {

      get
        //***
        // Action Get
        //   - Value of 'mstrDisplayName' is returned 
        // Called by
        //   - frmSearchTryout_Load(System.Object, System.EventArgs) Handles this.Load
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20251211 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20251211 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string DisplayName (Get)

      set
        //***
        // Action Set
        //   - 'mstrDisplayName' becomes value
        // Called by
        //   - frmTrySearchTryout.cmdSearch_Click(System.Object, System.EventArgs) Handles cmdSearch.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20251211 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20251211 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // DisplayName(string) (Set)

    }
    // string DisplayName

    public string KeyField
    {

      get
        //***
        // Action Get
        //   - Value of 'mstrKeyField' is returned 
        // Called by
        //   - cmdAccept_Click(System.Object, System.EventArgs) Handles cmdAccept.Click
        //   - SetData(string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20251211 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20251211 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string KeyField (Get)

      set
        //***
        // Action Set
        //   - 'mstrKeyField' becomes value
        // Called by
        //   - frmTrySearchTryout.cmdSearch_Click(System.Object, System.EventArgs) Handles cmdSearch.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20251211 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20251211 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // KeyField(string) (Set)

    }
    // string KeyField

    public string ResultValue
    {

      get
        //***
        // Action Get
        //   - Value of 'mstrResultValue' is returned 
        // Called by
        //   - frmTrySearchTryout.cmdSearch_Click(System.Object, System.EventArgs) Handles cmdSearch.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20251211 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20251211 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string ResultValue (Get)

      set
        //***
        // Action Set
        //   - 'mstrResultValue' becomes value
        // Called by
        //   - cmdAccept_Click(System.Object, System.EventArgs) Handles cmdAccept.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20251211 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20251211 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // ResultValue(string) (Set)

    }
    // string ResultValue

    public string SearchField
    {

      get
        //***
        // Action Get
        //   - Value of 'mstrSearchField' is returned 
        // Called by
        //   - frmTrySearchTryout.cmdSearch_Click(System.Object, System.EventArgs) Handles cmdSearch.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20251211 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20251211 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string SearchField (Get)

      set
        //***
        // Action Set
        //   - 'mstrSearchField' becomes value
        // Called by
        //   - frmTrySearchTryout.cmdSearch_Click(System.Object, System.EventArgs) Handles cmdSearch.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20251211 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20251211 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // SearchField(string) (Set)

    }
    // string SearchField

    public string SearchRecordSource
    {

      get
        //***
        // Action Get
        //   - Value of 'mstrSearchRecordSource' is returned 
        // Called by
        //   - SetData(string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20251211 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20251211 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string SearchRecordSource (Get)

      set
        //***
        // Action Set
        //   - 'mstrRecordSource' becomes value
        // Called by
        //   - frmTrySearchTryout.cmdSearch_Click(System.Object, System.EventArgs) Handles cmdSearch.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20251211 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20251211 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // SearchRecordSource(string) (Set)

    }
    // string SearchRecordSource

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAll_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Remove the Filter from the list of information (show them all)
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - SetData(string)
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***    
    {
    }
    // cmdAll_Click(System.Object, System.EventArgs) Handles cmdAll.Click

    private void cmdAccept_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a data row
      //   - Define a data table
      //   - Try to
      //     - The data tabel becomes the data source table 
      //     - The data row becomes the currently selected row in the grid
      //     - The result value becomes the key of that selected row
      //     - The dialog result becomes ok
      //     - The form is hidden
      //   - On error
      //     - Dialog result becomes no
      //   - Close the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ResultValue(string) (Set)
      //   - string KeyField (Get)
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdAccept_Click(System.Object, System.EventArgs) Handles cmdAccept.Click

    private void cmdCancel_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Dialog result is set to Cancel
      //   - Form is closed
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdCancel_Click(System.Object, System.EventArgs) Handles cmdCancel.Click

    private void cmdLetter_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Filter the list of information using the clicked letter button
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - SetData(string)
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // Letter_Click(System.Object, System.EventArgs) Handles ALetterButton.Click
    
    private void frmSearchTryout_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there is a display name
      //     - The text is added with the display name
      //   - If not
      //     - An error message is shwon
      //     - Current form is closed
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - string DisplayName (Get)
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmSearchTryout_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void SetData(string strFilterLetter)
      //***
      // Action
      //   - Define a data adapter
      //   - Define and create a new data table
      //   - Define and assign a SQL statement
      //     - Select the key field with the search field in a record source
      //     - Where the search field starts with the selected letter
      //   - Create a new data adapter using the SQL statement and the connection
      //   - Fill the data table using the data adapter
      //   - The data source of the data grid becomes the data table
      // Called by
      //   - cmdAll_Click(System.Object, System.EventArgs) Handles cmdAll.Click
      //   - Letter_Click(System.Object, System.EventArgs) Handles ALetterButton.Click
      // Calls
      //   - cpGeneralRoutines()
      //   - SqlConnection cpGeneralRoutines.GetConnection()
      //   - string KeyField (Get)
      //   - string SearchField (Get)
      //   - string SearchRecordSource (Get)
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // SetData(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSearchTryout

}
// CopyPaste.Learning