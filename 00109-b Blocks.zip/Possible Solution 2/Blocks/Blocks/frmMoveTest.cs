//***
// Action
//   - A block game
//   - Working with properties (Get and Set) and methods in a class
//   - Possible Solution 2
// Created
//   - CopyPaste � 20240214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240214 � VVDW
// Proposal (To Do)
//   - When this is runned, you will see that there are errors in it
//***

using CopyPaste.Learning.Games;
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMoveTest: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.Panel panMovingArea;
    internal System.Windows.Forms.PictureBox picBlock;
    internal System.Windows.Forms.PictureBox picBall;
    internal System.Windows.Forms.Timer tmrTimer;
    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMoveTest));
      this.panMovingArea = new System.Windows.Forms.Panel();
      this.picBlock = new System.Windows.Forms.PictureBox();
      this.picBall = new System.Windows.Forms.PictureBox();
      this.tmrTimer = new System.Windows.Forms.Timer(this.components);
      this.panMovingArea.SuspendLayout();
      this.SuspendLayout();
      // 
      // panMovingArea
      // 
      this.panMovingArea.BackColor = System.Drawing.Color.Transparent;
      this.panMovingArea.Controls.Add(this.picBlock);
      this.panMovingArea.Controls.Add(this.picBall);
      this.panMovingArea.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panMovingArea.Location = new System.Drawing.Point(0, 0);
      this.panMovingArea.Name = "panMovingArea";
      this.panMovingArea.Size = new System.Drawing.Size(342, 219);
      this.panMovingArea.TabIndex = 23;
      // 
      // picBlock
      // 
      this.picBlock.BackColor = System.Drawing.Color.Red;
      this.picBlock.Location = new System.Drawing.Point(120, 80);
      this.picBlock.Name = "picBlock";
      this.picBlock.Size = new System.Drawing.Size(112, 48);
      this.picBlock.TabIndex = 23;
      this.picBlock.TabStop = false;
      // 
      // picBall
      // 
      this.picBall.BackColor = System.Drawing.Color.Brown;
      this.picBall.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBall.Location = new System.Drawing.Point(56, 96);
      this.picBall.Name = "picBall";
      this.picBall.Size = new System.Drawing.Size(10, 10);
      this.picBall.TabIndex = 22;
      this.picBall.TabStop = false;
      // 
      // tmrTimer
      // 
      this.tmrTimer.Interval = 20;
      this.tmrTimer.Tick += new System.EventHandler(this.tmrTimer_Tick);
      // 
      // frmMoveTest
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(342, 219);
      this.Controls.Add(this.panMovingArea);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMoveTest";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Move Test";
      this.Load += new System.EventHandler(this.frmMoveTest_Load);
      this.panMovingArea.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMoveTest'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMoveTest()
      //***
      // Action
      //   - Create instance of 'frmMoveTest'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMoveTest()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpMove mcpBall;
    private cpMove mcpBlock01;
    private Rectangle mrecMovingArea;
    private cpCollision mcpCollision = new cpCollision();
    private int mlngCounter;
    
    #endregion

    #region "Properties"

    private Rectangle MovingArea
    {

      get
        //***
        // Action Get
        //   - Return the MovingArea for the moving object (mrecMovingArea)
        // Called by
        //   - frmMoveTest_Load(System.Object, System.EventArgs) Handles this.Load
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mrecMovingArea;
      }
      // Rectangle MovingArea (Get)

      set
        //***
        // Action Set
        //   - Set the MovingArea for the moving object (mrecMovingArea becomes value)
        // Called by
        //   - frmMoveTest_Load(System.Object, System.EventArgs) Handles this.Load
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mrecMovingArea = value;
      }
      // MovingArea(Rectangle) (Set)

    }
    // Rectangle MovingArea

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmMoveTest_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Preparing the startup of the game
      //   - Determine a moving area (movements can't go outside this)
      //   - Determine the movement of the ball
      //   - Enable the timer
      // Called by
      //   - Starting the application (when this form is marked as startup object)
      // Calls
      //   - cpMove.New(Control, Rectangle, double, int)
      //   - MovingArea(Rectangle) (Set)
      //   - Rectangle MovingArea (Get)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MovingArea = new Rectangle(panMovingArea.Left, panMovingArea.Top, panMovingArea.Width, panMovingArea.Height);
      mcpBall = new cpMove(picBall, MovingArea, 60, 3);
      mcpBlock01 = new cpMove(picBlock, MovingArea, 0, 0);
      tmrTimer.Enabled = true;
    }
    // frmMoveTest_Load(System.Object, System.EventArgs) Handles this.Load
    
    private void tmrTimer_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Actions to be taken every time the games progresses
      //   - Move the ball
      //   - Move the block
      //   - Checked on collision
      // Called by
      //   - Program action (The beating heart of the game)
      // Called by
      //   - 
      // Calls
      //   - CheckCollision()
      //   - cpMove.Move()
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mcpBall.Move();
      mcpBlock01.Move();
      CheckCollision();
    }
    // tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void CheckCollision()
      //***
      // Action
      //   - Check if the ball is hitting something
      //   - If the ball hits another object (Block01)
      //     - Do Nothing
      // Called by
      //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - bool cpCollision.Hit(cpMove, cpMove)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (mcpCollision.Hit(mcpBall, mcpBlock01))
      {
        // mcpBlock01.MovingObject.Visible = false;
      }
      else
        // Not mcpCollision.Hit(mcpBall, mcpBlock01)
      {
      }
      // mcpCollision.Hit(mcpBall, mcpBlock01)

    }
    // CheckCollision()

//    static void Main() 
//      //***
//      // Action
//      //   - Start application
//      //   - Showing frmMoveTest
//      // Called by
//      //   - User action (Starting the application)
//      // Calls
//      //   - 
//      // Created
//      //   - CopyPaste � 20240214 � VVDW
//      // Changed
//      //   - CopyPaste � yyyymmdd � VVDW � What changed
//      // Tested
//      //   - CopyPaste � 20240214 � VVDW
//      // Keyboard key
//      //   - 
//      // Proposal (To Do)
//      //   - 
//      //***
//    {
//      Application.Run(new frmMoveTest());
//    }
//    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMoveTest

}
// CopyPaste.Learning