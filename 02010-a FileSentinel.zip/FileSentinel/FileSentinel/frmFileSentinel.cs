//***
// Action
//   - Testroutine for cpSentinel
// Created
//   - CopyPaste � 20240716 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240716 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Learning.Toolkit.Tool;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFileSentinel: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.Label lblControlErrors;
    internal Microsoft.VisualBasic.Compatibility.VB6.DirListBox lstDirectory;
    internal Microsoft.VisualBasic.Compatibility.VB6.FileListBox lstFile;
    internal Microsoft.VisualBasic.Compatibility.VB6.DriveListBox cmbDrive;
    internal System.Windows.Forms.Label lblWatching;
    internal System.Windows.Forms.Button cmdDisable;
    internal System.Windows.Forms.Button cmdEnable;
    internal System.Windows.Forms.ToolTip ttpToolTip;
    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFileSentinel));
      this.lblControlErrors = new System.Windows.Forms.Label();
      this.lstDirectory = new Microsoft.VisualBasic.Compatibility.VB6.DirListBox();
      this.lstFile = new Microsoft.VisualBasic.Compatibility.VB6.FileListBox();
      this.cmbDrive = new Microsoft.VisualBasic.Compatibility.VB6.DriveListBox();
      this.lblWatching = new System.Windows.Forms.Label();
      this.cmdDisable = new System.Windows.Forms.Button();
      this.cmdEnable = new System.Windows.Forms.Button();
      this.ttpToolTip = new System.Windows.Forms.ToolTip(this.components);
      this.SuspendLayout();
      // 
      // lblControlErrors
      // 
      this.lblControlErrors.BackColor = System.Drawing.Color.Salmon;
      this.lblControlErrors.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblControlErrors.Location = new System.Drawing.Point(5, 9);
      this.lblControlErrors.Name = "lblControlErrors";
      this.lblControlErrors.Size = new System.Drawing.Size(384, 32);
      this.lblControlErrors.TabIndex = 13;
      this.lblControlErrors.Text = "Attention. Some controls are wrong in .NET, because they are copies of Visual Bas" +
        "ic 6.0. Click again till you have the correct path and file selected.";
      // 
      // lstDirectory
      // 
      this.lstDirectory.IntegralHeight = false;
      this.lstDirectory.Location = new System.Drawing.Point(133, 89);
      this.lstDirectory.Name = "lstDirectory";
      this.lstDirectory.Size = new System.Drawing.Size(120, 144);
      this.lstDirectory.TabIndex = 12;
      this.lstDirectory.SelectedIndexChanged += new System.EventHandler(this.lstDirectory_SelectedIndexChanged);
      // 
      // lstFile
      // 
      this.lstFile.Location = new System.Drawing.Point(269, 49);
      this.lstFile.Name = "lstFile";
      this.lstFile.Pattern = "*.*";
      this.lstFile.Size = new System.Drawing.Size(120, 186);
      this.lstFile.TabIndex = 11;
      this.lstFile.SelectedIndexChanged += new System.EventHandler(this.lstFile_SelectedIndexChanged);
      // 
      // cmbDrive
      // 
      this.cmbDrive.DropDownWidth = 121;
      this.cmbDrive.Location = new System.Drawing.Point(133, 49);
      this.cmbDrive.Name = "cmbDrive";
      this.cmbDrive.Size = new System.Drawing.Size(121, 21);
      this.cmbDrive.TabIndex = 10;
      this.cmbDrive.SelectedIndexChanged += new System.EventHandler(this.cmbDrive_SelectedIndexChanged);
      // 
      // lblWatching
      // 
      this.lblWatching.BackColor = System.Drawing.Color.Lime;
      this.lblWatching.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblWatching.Location = new System.Drawing.Point(5, 249);
      this.lblWatching.Name = "lblWatching";
      this.lblWatching.Size = new System.Drawing.Size(384, 16);
      this.lblWatching.TabIndex = 9;
      this.lblWatching.Text = "Label1";
      this.lblWatching.TextChanged += new System.EventHandler(this.lblWatching_TextChanged);
      // 
      // cmdDisable
      // 
      this.cmdDisable.Location = new System.Drawing.Point(5, 97);
      this.cmdDisable.Name = "cmdDisable";
      this.cmdDisable.Size = new System.Drawing.Size(112, 32);
      this.cmdDisable.TabIndex = 8;
      this.cmdDisable.Text = "&Disable Sentinel";
      this.cmdDisable.Click += new System.EventHandler(this.cmdDisable_Click);
      // 
      // cmdEnable
      // 
      this.cmdEnable.Location = new System.Drawing.Point(5, 49);
      this.cmdEnable.Name = "cmdEnable";
      this.cmdEnable.Size = new System.Drawing.Size(112, 32);
      this.cmdEnable.TabIndex = 7;
      this.cmdEnable.Text = "&Enable Sentinel";
      this.cmdEnable.Click += new System.EventHandler(this.cmdEnable_Click);
      // 
      // frmFileSentinel
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(394, 275);
      this.Controls.Add(this.lstDirectory);
      this.Controls.Add(this.lstFile);
      this.Controls.Add(this.cmbDrive);
      this.Controls.Add(this.lblWatching);
      this.Controls.Add(this.cmdDisable);
      this.Controls.Add(this.cmdEnable);
      this.Controls.Add(this.lblControlErrors);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFileSentinel";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "File Sentinel";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFileSentinel'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240716 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFileSentinel()
      //***
      // Action
      //   - Create new instance of 'frmFileSentinel'
      //   - Set the path that is defined to be watched
      //   - Initialize the graphical user interface
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      //   - InitializeGUI()
      // Created
      //   - CopyPaste � 20240716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240716 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      lblWatching.Text = cmbDrive.Drive.ToUpper() + "\\";
      InitializeGUI();
    }
    // frmFileSentinel()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrFilesToScan;
    private cpSentinel mcpSentinel;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmbDrive_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Set the path of the directory listbox to the choosen drive
      //     - Set the choosen directory to the path of the listbox of files
      //     - Set the label to the drive that was choosen
      // Called by
      //   - User action (Selection an option in a ComboBox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        lstDirectory.Path = cmbDrive.Drive;
        lstFile.Path = lstDirectory.Path;
        lblWatching.Text = cmbDrive.Drive;
      }
      catch
      {
        cmbDrive.Drive = lstDirectory.Path;
      }

    }
    // cmbDriveListBox_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbDrive.SelectedIndexChanged

    private void cmdDisable_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Dispose the instance of cpsentinel
      //   - Enable the enable button
      //   - Disable the disable button
      //   - Enable the Drive ComboBox, Directory ListBox and the file ListBox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpSentinel.Dispose()
      // Created
      //   - CopyPaste � 20240716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpSentinel.Dispose();
      cmdEnable.Enabled = true;
      cmdDisable.Enabled = false;
      cmbDrive.Enabled = true;
      lstDirectory.Enabled = true;
      lstFile.Enabled = true;
    }
    // cmdDisable_Click(System.Object, System.EventArgs) Handles cmdDisable.Click
    
    private void cmdEnable_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Start watching a file
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - StartWatching()
      // Created
      //   - CopyPaste � 20240716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      StartWatching();
    }
    // cmdEnable_Click(System.Object, System.EventArgs) Handles cmdEnable.Click

    private void lblWatching_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - mstrFilesToScan becomes label text
      // Called by
      //   - System action (Changing the text of a label)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrFilesToScan = lblWatching.Text;    
    }
    // lblWatching_TextChanged(System.Object, System.EventArgs) Handles lblWatching.TextChanged
    
    private void lstDirectory_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Path of listbox becomes listbox directory path
      //     - Text of label becomes listbox directory path
      // Called by
      //   - User action (Selecting an item in listbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        lstFile.Path = lstDirectory.Path;
        lblWatching.Text = lstDirectory.Path;
      }
      catch
      {
      }
    
    }
    // lstDirectory_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstDirectory.SelectedIndexChanged

    private void lstFile_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Add a backslash when needed between the path and filename
      //   - Show the correct path in the label
      // Called by
      //   - User action (Selecting an item in listbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (lstFile.Path.EndsWith("\\"))
      {
        lblWatching.Text = lstFile.Path + lstFile.FileName;
      }
      else
        // Not lstFile.Path.EndsWith("\")
      {
        lblWatching.Text = lstFile.Path + "\\" + lstFile.FileName;
      }
      // lstFile.Path.EndsWith("\")
    
    }
    // lstFile_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstFile.SelectedIndexChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void InitializeGUI()
      //***
      // Action
      //   - cmdEnable is enabled
      //   - cmdDisable is disabled
      //   - Set 3 tooltips
      // Called by
      //   - frmFileSentinel()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cmdEnable.Enabled = true;
      cmdDisable.Enabled = false;

      ttpToolTip.SetToolTip(cmdEnable, "Enable the File Sentinel to monitor a folder or directory.");
      ttpToolTip.SetToolTip(cmdDisable, "Stop monitoring a folder or directory.");
      ttpToolTip.SetToolTip(cmbDrive, "Select the drive to monitor a folder or directory.");
    }
    // InitializeGUI()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFileSentinel
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmFileSentinel()
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFileSentinel());
    }
    // Main() 

    protected void StartWatching()
      //***
      // Action
      //   - Create a new instance of cpSentinel with the selected file to watch
      //   - Diaable the enable button
      //   - Enable the disable button
      //   - Disable the Drive ComboBox, Directory ListBox and the file ListBox
      // Called by
      //   - cmdEnable_Click(System.Object, System.EventArgs) Handles cmdEnable.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpSentinel = new cpSentinel(mstrFilesToScan);
      cmdEnable.Enabled = false;
      cmdDisable.Enabled = true;
      cmbDrive.Enabled = false;
      lstDirectory.Enabled = false;
      lstFile.Enabled = false;
    }
    // StartWatching()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmFileSentinel

}
// CopyPaste.Learning