﻿'***
' Action
'   - Demo of a simple website with 3 textboxes and 2 command buttons
' Created
'   - CopyPaste – 20051122 – VVDW
' Changed
'   - CopyPaste – yyyymmdd – VVDW – What changed
' Tested
'   - CopyPaste – 20051122 – VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On
Option Strict On

Namespace CopyPaste.Learning

  Public Class wfrmHelloWorld
    Inherits System.Web.UI.Page

    '#Region "Constructors"
    '#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

#Region "Fields"
#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

#Region "Controls"

    Private Sub cmdServer_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdServer.Click
      '***
      ' Action
      '   - Change the text of a textbox
      ' Called by
      '   - User action (Clicking a button) (Server side)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20051122 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20051122 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      txtServer.Text = "txtServer (cmdServer_Click)"
    End Sub
    ' cmdServer_Click(System.Object, System.EventArgs) Handles cmdServer.Click

    Private Sub Page_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Load
      '***
      ' Action
      '   - Change the text of a textbox
      ' Called by
      '   - User action (Loading the page) (Server side)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20051122 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20051122 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      txtServer.Text = "txtServer (Page_Load)"
    End Sub
    ' Page_Load(System.Object, System.EventArgs) Handles MyBase.Load

#End Region

    '#Region "Functionality"

    '#Region "Event"
    '#End Region

    '#Region "Sub / Function"
    '#End Region

    '#End Region

#End Region

    '#Region "Properties"
    '#End Region

  End Class
  ' wfrmHelloWorld

End Namespace
' CopyPaste.Learning