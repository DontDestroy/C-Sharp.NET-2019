//***
// Action
//   - A textbox where you can change the backcolor
//   - The previous backcolor is remembered
// Created
//   - CopyPaste � 20250716 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250716 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.cpControls
{

  public class cpctlTextBoxColor : System.Windows.Forms.UserControl
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.ColorDialog dlgColor;
    internal System.Windows.Forms.TextBox txtTextBox;

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.dlgColor = new System.Windows.Forms.ColorDialog();
      this.txtTextBox = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // txtTextBox
      // 
      this.txtTextBox.Location = new System.Drawing.Point(0, 0);
      this.txtTextBox.Name = "txtTextBox";
      this.txtTextBox.Size = new System.Drawing.Size(128, 20);
      this.txtTextBox.TabIndex = 1;
      this.txtTextBox.Text = "";
      // 
      // cpctlTextBoxColor
      // 
      this.Controls.Add(this.txtTextBox);
      this.Name = "cpctlTextBoxColor";
      this.Size = new System.Drawing.Size(128, 24);
      this.ResumeLayout(false);

    }

  #endregion

    #region "Constructors / Destructors"

    public cpctlTextBoxColor()
      //***
      // Action
      //   - Create instance of 'cpctlTextBoxColor'
      // Called by
      //   - User action (Starting the control)
      // Calls
      //   - InitializeComponent()
      //   - SetUpContextMenu()
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      SetUpContextMenu();    
    }
    // cpctlTextBoxColor()

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpctlTextBoxColor'
      // Called by
      //   - User action (Closing the control)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
        
        
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private Color mthePreviousColor;
    public event ColorDelegate ColorChanged;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate void ColorDelegate(Color theColor);

    #endregion

    #region "Sub / Function"

    private void mnuItem1Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The current backcolor of the textbox is selected in the Color dialog
      //   - The current backcolor is saved in mthePreviousColor
      //   - Show the color dialog
      //   - When closed, the selected color becomes the backcolor
      //   - The ColorChanged event is triggered
      // Called by
      //   - User action (Clicking a menu) (Thru click event handler)
      //   - SetUpContextMenu()
      // Calls
      //   - ColorChanged(Color)
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dlgColor.AllowFullOpen = true;
      dlgColor.AnyColor = true;
      dlgColor.SolidColorOnly = false;
      dlgColor.ShowHelp = true;
      dlgColor.Color = txtTextBox.BackColor;
      mthePreviousColor = dlgColor.Color;
      dlgColor.ShowDialog();
      txtTextBox.BackColor = dlgColor.Color;
      ColorChanged(dlgColor.Color);
    }
    // mnuItem1Click(System.Object, System.EventArgs)

    public void mnuItem2Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The mthePreviousColor becomes the backcolor
      // Called by
      //   - User action (Clicking a menu) (Thru click event handler)
      //   - SetUpContextMenu()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtTextBox.BackColor = mthePreviousColor;
    }
    // mnuItem2Click(System.Object, System.EventArgs)

    private void SetUpContextMenu()
      //***
      // Action
      //   - A context menu is created
      //   - Context menu item "Change Color" is added
      //   - Context menu item "Restore Previous" is added
      //   - Context menu is linked to textbox
      //   - Context menu item "Change Color" click event is handled by mnuItem1Click
      //   - Context menu item "Restore Previous" click event is handled by mnuItem2Click
      // Called by
      //   - cpctlTextBoxColor()
      // Calls
      //   - mnuItem1Click(System.Object, System.EventArgs)
      //   - mnuItem2Click(System.Object, System.EventArgs)
      // Created
      //   - CopyPaste � 20250716 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250716 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ContextMenu ctmContextMenu = new ContextMenu();
      MenuItem mnuItem1 = new MenuItem("Change Color");
      MenuItem mnuItem2 = new MenuItem("Restore Previous");
      
      ctmContextMenu.MenuItems.Add(mnuItem1);
      ctmContextMenu.MenuItems.Add(mnuItem2);
      
      txtTextBox.ContextMenu = ctmContextMenu;
      mnuItem1.Click += new EventHandler(mnuItem1Click);
      mnuItem2.Click += new EventHandler(mnuItem2Click);
    }
    // SetUpContextMenu()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpctlTextBoxColor

}
// CopyPaste.Learning.cpControls