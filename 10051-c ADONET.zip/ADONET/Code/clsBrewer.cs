//***
// Action
//   - Definition of a cpBrewer
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpBrewer
  {

    #region "Constructors / Destructors"

    public cpBrewer(System.Int32 intKeyBrewer, string strBrewerName)
      //***
      // Action
      //   - Creating an instance of cpBrewer with a given key and name
      // Called by
      //   - frmBeerBrewer.frmBeerBrewer_Load(System.Object, System.EventArgs) Handles this.Load
      //   - User action (Creating instance)
      // Calls
      //   - BrewerName(string) (Set)
      //   - KeyBrewer(System.Int32) (Set)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      KeyBrewer = intKeyBrewer;
      BrewerName = strBrewerName;
    }
    // cpBrewer(System.Int32, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private System.Int32 mlngKeyBrewer;
    private string mstrBrewerName;

    #endregion

    #region "Properties"

    public string BrewerName
    {

      get
        //***
        // Action Get
        //   - Return 'mstrBrewerName'
        // Called by
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260204 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260204 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrBrewerName;
      }
      // string BrewerName (Get)

      set
        //***
        // Action Set
        //   - 'mstrBrewerName' becomes 'value'
        // Called by
        //   - cpBrewer(System.Int32, string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260204 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260204 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrBrewerName = value;
      }
      // BrewerName(string) (Set)

    }
    // string BrewerName

    public System.Int32 KeyBrewer
    {

      get
        //***
        // Action Set
        //   - Return 'mlngKeyBrewer'
        // Called by
        //   - frmBeerBrewer.lstBrewer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBrewer.SelectedIndexChanged
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260204 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260204 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngKeyBrewer;
      }
      // System.Int32 KeyBrewer (Get)

      set
        //***
        // Action Set
        //   - 'mlngKeyBrewer' becomes 'value'
        // Called by
        //   - cpBrewer(System.Int32, string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260204 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260204 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
      {
        mlngKeyBrewer = value;
      }
      // KeyBrewer(System.Int32) (Set)

    }
    // System.Int32 KeyBrewer

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Default return value of cpBrewer
      // Called by
      //   - frmBeerBrewer.frmBeerBrewer_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - BrewerName() As String (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return BrewerName;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBrewer

}
// CopyPaste.Learning