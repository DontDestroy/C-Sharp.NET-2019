//***
// Action
//   - Calculation of a square root
// Created
//   - CopyPaste � 20240417 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240417 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Ask for a number using an inputbox
      //   - If the input is numeric
      //     - Convert it to a double
      //     - Take the squareroot
      //     - Result is shown in a messagebox
      //   - If not
      //     - Error is shown in a messagebox
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240417 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240417 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      string strResult;
      double dblResult;

      strResult = Interaction.InputBox("Give a number", "Copy Paste", "-100", 0, 0);

      if (Information.IsNumeric(strResult))
      {
        dblResult = Convert.ToDouble(strResult);
        dblResult = Math.Sqrt(Math.Abs(dblResult));
        MessageBox.Show("The squareroot is: " + dblResult, "Copy Paste", MessageBoxButtons.OK);
      }
      else
        // Not IsNumeric(strResult)
      {
        MessageBox.Show("Input was not numeric", "Copy Paste", MessageBoxButtons.OK);
      }
      // IsNumeric(strResult)

    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning