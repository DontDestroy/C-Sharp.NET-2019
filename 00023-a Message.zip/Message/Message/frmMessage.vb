'***
' Action
'   - Showing a messagebox. Starting point is an empty form.
' Created
'   - CopyPaste � 20070219 � VVDW
' Changed
'   - Organisation � yyyymmdd � Initials of programmer � What changed
' Tested
'   - CopyPaste � 20070219 � VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On 
Option Strict On

Imports System.Windows.Forms

Public Class frmMessage
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "
  'Required by the Windows Form Designer
  Private components As System.ComponentModel.Container

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMessage))
    '
    'frmMessage
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(512, 445)
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Name = "frmMessage"
    Me.Text = "Start screen"

  End Sub

#End Region

#Region "Constructors / Destructors"

  Protected Overloads Overrides Sub Dispose(ByVal blnDisposing As Boolean)
    '***
    ' Action
    '   - Cleanup after closing the form
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20070219 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20070219 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    If blnDisposing Then

      If components Is Nothing Then
      Else
        ' Not components Is Nothing
        components.Dispose()
      End If
      ' components Is Nothing

    Else
      ' Not blnDisposing
    End If
    ' blnDisposing

    MyBase.Dispose(blnDisposing)
  End Sub
  ' Dispose(Boolean)

  Public Sub New()
    '***
    ' Action
    '   - Creating an instance of the form
    '   - Initialize the components of that form
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20070219 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20070219 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    MyBase.New()
    InitializeComponent()
  End Sub
  ' New()

#End Region

  '#Region "Designer"
  '#End Region

  '#Region "Structures"
  '#End Region

  '#Region "Fields"
  '#End Region

  '#Region "Properties"
  '#End Region

#Region "Methods"

  '#Region "Overrides"
  '#End Region

#Region "Controls"

  Private Sub frmMessage_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Load
    '***
    ' Action
    '   - Show a MessageBox message
    '   - Show a MessageBox message with button OK
    '   - Show a MessageBox message with title and 3 buttons
    '   - Show a MessageBox message with title and 2 buttons
    '   - Show a MessageBox message with title and 2 buttons with icon and remember the answer
    '   - Depending on the answer, show a MessageBox message
    ' Called by
    '   - User action (starting the form)
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20070219 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20070219 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    Dim dlgrResponse As DialogResult

    MessageBox.Show("Visual Basic .NET Programming For The Absolute Beginner")
    MessageBox.Show("Hi There!", "Copy Paste", MessageBoxButtons.OK)
    MessageBox.Show("Nuclear Meltdown In Progress!", "Copy Paste", MessageBoxButtons.AbortRetryIgnore)
    MessageBox.Show("Do you want to format your hard drive?", "Copy Paste", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
    MessageBox.Show("Error connecting to server...", "Copy Paste", MessageBoxButtons.RetryCancel, MessageBoxIcon.Exclamation)
    dlgrResponse = MessageBox.Show("How about a game of Global Thermonuclear War?", "Copy Paste", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

    If dlgrResponse = DialogResult.Yes Then
      MessageBox.Show("On second thought, that's not such a good idea.", "Result")
    Else
      ' dlgrResponse <> DialogResult.Yes
      MessageBox.Show("Chicken!", "Result")
    End If
    ' dlgrResponse = DialogResult.Yes

  End Sub
  ' frmMessage_Load(System.Object, System.EventArgs) Handles MyBase.Load

#End Region

  '#Region "Functionality"

  '#Region "Event"
  '#End Region

  '#Region "Sub / Function"
  '#End Region

  '#End Region

#End Region

  '#Region "Not used"
  '#End Region

End Class
' frmMessage