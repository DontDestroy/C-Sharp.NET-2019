//***
// Action
//   - Create at runtime buttons to filter the countries
// Created
//   - CopyPaste � 20250706 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250706 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmRunTime: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.ListBox lstCountry;

    private void InitializeComponent()
    {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmRunTime));
			this.lstCountry = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// lstCountry
			// 
			this.lstCountry.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.lstCountry.Location = new System.Drawing.Point(0, 0);
			this.lstCountry.Name = "lstCountry";
			this.lstCountry.Size = new System.Drawing.Size(680, 160);
			this.lstCountry.TabIndex = 1;
			// 
			// frmRunTime
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(680, 273);
			this.Controls.Add(this.lstCountry);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmRunTime";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Controls at runtime";
			this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmRunTime'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmRunTime()
      //***
      // Action
      //   - Create new instance of 'frmRuntime'
      //   - Create a letter A (chrLetter)
      //   - Create a counter to calculate the position of the button
      //   - As long the chrLetter is not Z
      //     - Create a new button
      //     - Set the text to the button to the chrLetter
      //     - Set the width of the button to the height of the button
      //     - Set the left side of the button
      //     - Set the top to the button
      //     - Anchor the button
      //     - Add the button to the list of the controls in the form
      //     - Add a click event to the button
      //     - Increment the counter
      //     - Take the next letter
      // Called by
      //   - Main()
      // Calls
      //   - ButtonAction(System.Object, System.EventArgs)
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      
      char chrLetter = 'A';
      int intCounter = 0;

      while (chrLetter <= 'Z')
      {
        Button theButton = new Button();

        theButton.Text = chrLetter.ToString();
        theButton.Width = theButton.Height;
        theButton.Left = lstCountry.Left + (theButton.Width + 3) * intCounter;
        theButton.Top = lstCountry.Top + lstCountry.Height + 3;
        theButton.Anchor = AnchorStyles.Bottom;

        this.Controls.Add(theButton);
        theButton.Click += new EventHandler(ButtonAction);
        intCounter += 1;
        chrLetter = Convert.ToChar(Convert.ToInt16(chrLetter) + 1);
      }
      // chrLetter > 'Z'

    }
    // frmRunTime()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private void ButtonAction(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Determine the text on the button
      //   - Define a stream reader with the file "Countries.txt"
      //   - Try to
      //     - Read the first line of the file
      //     - Clear the list (previous filter)
      //     - As long there is info in the line
      //       - If first character is the same as the button text
      //         - Add the line (country) to the list (lstCountry)
      //       - If not
      //         - Do nothing
      //       - Read the next line
      //   - Show an error message when there is a problem
      //   - Close the stream reader
      // Called by
      //   - New()
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250706 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Button theButton;
      char chrFind;
 
      theButton = (Button)theSender;
      chrFind = theButton.Text[0];

      StreamReader theStreamReader = new StreamReader("Countries.txt");

      try
      {
        string strLine = theStreamReader.ReadLine();

        lstCountry.Items.Clear();

        while (strLine != null)
        {

          if (strLine[0] == chrFind)
          {
            lstCountry.Items.Add(strLine);
          }
          else
            // strLine[0] <> chrFind 
          {
          }
          // strLine[0] = chrFind 

          strLine = theStreamReader.ReadLine();
        }
        // strLine = null

      }
      catch (IOException theIOException)
      {
        MessageBox.Show("Problem with country file\n" + theIOException.Message, this.Text);
      }
      finally
      {
        theStreamReader.Close();
      }

    }
    // ButtonAction(System.Object, System.EventArgs)

    #endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmRunTime
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmRunTime()
      // Created
      //   - CopyPaste � 20250706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmRunTime());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmRunTime

}
// CopyPaste.Learning