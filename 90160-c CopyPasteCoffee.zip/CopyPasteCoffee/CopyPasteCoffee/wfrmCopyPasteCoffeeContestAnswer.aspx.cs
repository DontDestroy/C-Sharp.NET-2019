﻿//***
// Action
//   - Demo of how to communicate with a server
//   - This is the answer form
// Created
//   - CopyPaste – 20260806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260806 – VVDW
// Proposal (To Do)
//   - The server is not live at the moment
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmCopyPasteCoffeeContestAnswer : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when initializing the page
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260806 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260806 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - If form is started the first time
    //       - Get the 2 values out of the request form and put them in the corresponding answer
    //     - If not
    //       - Show corresponding error message
    //   - On possible error
    //     - Show corresponding error message
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260806 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260806 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      try
      {

        if (IsPostBack || Request.Form["firstname"] == null)
        {
          lblAnswer.Text = "Page not correctly loaded";
        }
        else
        // Not IsPostBack And Request.Form["firstname"] <> null
        {
          lblAnswer.Text = "Thanks, " + Request.Form["firstName"] + " " + Request.Form["lastName"] +
            " for entering the Copy Paste Coffee Contest form <br> <br> If you win something, you'll be the first to know";
        }
        // IsPostBack Or Request.Form["firstname"] = null

      }
      catch
      {
        lblAnswer.Text = "Page not correctly loaded";
      }

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmCopyPasteCoffeeContestAnswer

}
// CopyPaste.Learning