﻿//***
// Action
//   - Having a command towards a database
//   - Interaction logic for ctrlProductDetail.xaml (part of MainWindow.xaml)
// Created
//   - CopyPaste – 20210809 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210809 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System.Windows.Controls;

namespace WPFCommand.cpUserControl
{

  public partial class ctrlProductDetail : UserControl
  {

    #region "Constructors / Destructors"

    public ctrlProductDetail()
    //***
    // Action
    //   - Creating an instance of the WPF control
    // Called by
    //   - User Action Or System action (Showing the control)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // ctrlProductDetail()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"

    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // ctrlProductDetail 

}
// WPFCommand.cpUserControl