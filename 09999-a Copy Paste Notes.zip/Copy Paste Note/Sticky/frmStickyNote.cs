//***
// Action
//   - The form of a sticky note (postit)
//   - There is a title, a text and some menu items
// Created
//   - CopyPaste � 20250806 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250806 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.PostIt
{

  public class frmStickyNote: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.MainMenu mnuMain;
    internal System.Windows.Forms.MenuItem mnuNote;
    internal System.Windows.Forms.MenuItem mnuNoteOnTop;
    internal System.Windows.Forms.MenuItem mnuNoteDelete;
    internal System.Windows.Forms.MenuItem mnuNoteHide;
    internal System.Windows.Forms.TextBox txtNote;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmStickyNote));
      this.mnuMain = new System.Windows.Forms.MainMenu();
      this.mnuNote = new System.Windows.Forms.MenuItem();
      this.mnuNoteOnTop = new System.Windows.Forms.MenuItem();
      this.mnuNoteDelete = new System.Windows.Forms.MenuItem();
      this.mnuNoteHide = new System.Windows.Forms.MenuItem();
      this.txtNote = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // mnuMain
      // 
      this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuNote});
      // 
      // mnuNote
      // 
      this.mnuNote.Index = 0;
      this.mnuNote.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuNoteOnTop,
                                                                            this.mnuNoteDelete,
                                                                            this.mnuNoteHide});
      this.mnuNote.Text = "&Note";
      // 
      // mnuNoteOnTop
      // 
      this.mnuNoteOnTop.Index = 0;
      this.mnuNoteOnTop.Text = "&Keep on Top";
      this.mnuNoteOnTop.Click += new System.EventHandler(this.mnuNoteOnTop_Click);
      // 
      // mnuNoteDelete
      // 
      this.mnuNoteDelete.Index = 1;
      this.mnuNoteDelete.Text = "&Delete this note";
      this.mnuNoteDelete.Click += new System.EventHandler(this.mnuNoteDelete_Click);
      // 
      // mnuNoteHide
      // 
      this.mnuNoteHide.Index = 2;
      this.mnuNoteHide.Text = "&Hide this note";
      this.mnuNoteHide.Click += new System.EventHandler(this.mnuNoteHide_Click);
      // 
      // txtNote
      // 
      this.txtNote.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(192)));
      this.txtNote.Dock = System.Windows.Forms.DockStyle.Fill;
      this.txtNote.Location = new System.Drawing.Point(0, 0);
      this.txtNote.Multiline = true;
      this.txtNote.Name = "txtNote";
      this.txtNote.Size = new System.Drawing.Size(292, 213);
      this.txtNote.TabIndex = 1;
      this.txtNote.Text = "";
      // 
      // frmStickyNote
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 213);
      this.ControlBox = false;
      this.Controls.Add(this.txtNote);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.Menu = this.mnuMain;
      this.MinimizeBox = false;
      this.Name = "frmStickyNote";
      this.ShowInTaskbar = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
      this.Text = "A Sticky Note";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmStickyNote'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmStickyNote()
      //***
      // Action
      //   - Create instance of 'frmStickyNote'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmStickyNote()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void mnuNoteDelete_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Ask confirmation to delete this note
      //   - If answer is yes
      //     - Delete the note
      //     - Close and dispose the note
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - cpStickyOrganiser.DeleteNote(frmStickyNote)
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DialogResult dlgrResult = MessageBox.Show("Delete this note?", "Copy Paste Sticky", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

      if (dlgrResult == DialogResult.Yes)
      {
        cpStickyOrganiser.DeleteNote(this);
        this.Close();
        this.Dispose();
      }
      else
        // dlgrResult <> DialogResult.Yes
      {
      }
      // dlgrResult = DialogResult.Yes

    }
    // mnuNoteDelete_Click(System.Object, System.EventArgs) Handles mnuNoteDelete.Click
    
    private void mnuNoteHide_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Hide the current note
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mnuNoteHide.Checked = false;
      this.Hide();
    }
    // mnuNoteHide_Click(System.Object, System.EventArgs) Handles mnuNoteHide.Click

    private void mnuNoteOnTop_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Switch the checked menu option on or off
      //   - That value becomes also the property TopMost
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mnuNoteOnTop.Checked = !mnuNoteOnTop.Checked;
      this.TopMost = mnuNoteOnTop.Checked;
    }
    // mnuNoteOnTop_Click(System.Object, System.EventArgs) Handles mnuNoteOnTop.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmStickyNote

}
// CopyPaste.Learning.PostIt