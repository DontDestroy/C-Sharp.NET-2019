//***
// Action
//   - Demo of executing an event
// Created
//   - CopyPaste � 20240520 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240520 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Learning.Event;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmWithEvents: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdAddHandler;
    internal System.Windows.Forms.Button cmdRaiseEvent;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmWithEvents));
      this.cmdAddHandler = new System.Windows.Forms.Button();
      this.cmdRaiseEvent = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdAddHandler
      // 
      this.cmdAddHandler.Location = new System.Drawing.Point(16, 72);
      this.cmdAddHandler.Name = "cmdAddHandler";
      this.cmdAddHandler.Size = new System.Drawing.Size(120, 32);
      this.cmdAddHandler.TabIndex = 3;
      this.cmdAddHandler.Text = "Add Handler";
      this.cmdAddHandler.Click += new System.EventHandler(this.cmdAddHandler_Click);
      this.cmdAddHandler.Click += new System.EventHandler(this.cmdCustomHandler_Click);
      // 
      // cmdRaiseEvent
      // 
      this.cmdRaiseEvent.Location = new System.Drawing.Point(16, 24);
      this.cmdRaiseEvent.Name = "cmdRaiseEvent";
      this.cmdRaiseEvent.Size = new System.Drawing.Size(120, 32);
      this.cmdRaiseEvent.TabIndex = 2;
      this.cmdRaiseEvent.Text = "Raise Event";
      this.cmdRaiseEvent.Click += new System.EventHandler(this.cmdRaiseEvent_Click);
      // 
      // frmWithEvents
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdAddHandler);
      this.Controls.Add(this.cmdRaiseEvent);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmWithEvents";
      this.Text = "WithEvents";
      this.ResumeLayout(false);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmWithEvents'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmWithEvents()
      //***
      // Action
      //   - Create instance of 'frmWithEvents'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      cmdAddHandler.Click += new EventHandler(cmdSecondCustomHandler_Click);
      mcpEvent = new cpEvent();
      mcpEvent.theEvent += new cpEvent.cpDelegate(mcpEvent_theEvent);
    }
    // frmWithEvents()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpEvent mcpEvent;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAddHandler_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show that a normal event is triggered
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show("The normal event handler", "Copy Paste");
    }
    // cmdAddHandler_Click(System.Object, System.EventArgs) Handles cmdAddHandler.Click

    private void cmdCustomHandler_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show that a custom event is triggered
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show("The custom event handler", "Copy Paste");
    }
    // cmdCustomHandler_Click(System.Object, System.EventArgs) Handles cmdAddHandler.Click

    private void cmdRaiseEvent_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Raise the event of cpEvent
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpEvent.RaiseTheEvent(int)
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpEvent.RaiseTheEvent(7);
    }
    // cmdRaiseEvent_Click(System.Object, System.EventArgs)

    #endregion

    #region "Functionality"

    #region "Event"

    public void mcpEvent_theEvent(int lngEventParameter)
      //***
      // Action
      //   - Show that an event is triggered and that the parameter is given thru
      // Called by
      //   - User action (Triggering an event)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (mcpEvent == null)
      {
      }
      else
        // mcpEvent <> null
      {
        MessageBox.Show("Event raised: " + lngEventParameter);
      }
      // mcpEvent = null

    }
    // mcpEvent_theEvent(int)

    #endregion

    #region "Sub / Function"

    private void cmdSecondCustomHandler_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show that a second custom event is triggered
      // Called by
      //   - frmWithEvents()
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show("The second custom event handler", "Copy Paste");
    }
    // cmdSecondCustomHandler_Click(System.Object, System.EventArgs)
  
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmWithEvents
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmWithEvents()
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmWithEvents());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmWithEvents

}
// CopyPaste.Learning