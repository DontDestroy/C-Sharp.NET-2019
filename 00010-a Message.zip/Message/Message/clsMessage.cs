//***
// Action
//   - Example of procedure calls
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace Message
{

  class cpMessage
	{

    static void Main()
    //***
    // Action
    //   - Call procedures
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - SubRoutineFromOtherClass()
    //   - string System.Console.ReadLine()
    //   - SubRoutine()
    //   - SubRoutineWithParameter(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      SubRoutine();
      SubRoutineWithParameter("This is an example of a subroutine.");
      SubRoutineWithParameter("This is another example of a subroutine.");
      SubRoutine();
      SubRoutineFromOtherClass();
      SubRoutineWithParameter("Done. Hit enter to stop.");
      Console.ReadLine();
    }
    // Main()

    public static void SubRoutine()
    //***
    // Action
    //   - Show fixed message in messagebox and at console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string)
    //   - System.Windows.Forms.MessageBox.Show(string) As DialogResult
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      MessageBox.Show("This is an example of a subroutine.");
      Console.WriteLine("This is an example of a subroutine.");
    }
    // SubRoutine()

    static void SubRoutineFromOtherClass()
    //***
    // Action
    //   - Show fixed message in messagebox and at console screen (strShowText)
    //   - But code is in another class
    // Called by
    //   - Main()
    // Calls
    //   - cpOtherMessage.ShowOtherMessage()
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      cpOtherMessage anOtherMessage;

      anOtherMessage = new cpOtherMessage();
      anOtherMessage.ShowOtherMessage();
    }
    // SubRoutineFromOtherClass()

    static void SubRoutineWithParameter(string strShowText)
    //***
    // Action
    //   - Show variable message in messagebox and at console screen (strShowText)
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string)
    //   - System.Windows.Forms.MessageBox.Show(string) As DialogResult
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      MessageBox.Show(strShowText);
      Console.WriteLine(strShowText);
    }
    // SubRoutineWithParameter(string)

  }
  // cpMessage

}
// Message