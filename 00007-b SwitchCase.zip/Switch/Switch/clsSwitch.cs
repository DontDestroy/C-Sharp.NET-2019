//***
// Action
//   - Switch Case
// Created
//   - CopyPaste � 20220117 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220117 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Switch
{

  class cpSwitch
	{

    static void Main()
    //***
    // Action
    //   - Ask for country code
    //   - Depending on given code
    //     - Case "B" or "b", show "Belgium" and "Brussels"
    //     - Case "N" or "n", show "Netherlands" and "Amsterdam"
    //     - Case "F" or "f", show "France" and "Paris"
    //     - Case else, show "Unknown" and "Unknown"
    //   - Call NestedIf
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - NestedIf()
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine()
    //   - System.Console.WriteLine(string)
    //   - System.Console.WriteLine(string, System.Object, System.Object)
    // Created
    //   - CopyPaste � 20220117 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220117 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strCapital;
      string strCountry;
      string strCountryCode;

      Console.WriteLine("Type Countrycode:");
      strCountryCode = Console.ReadLine();

      switch (strCountryCode)
      {
        case "B": case "b":
          strCountry = "Belgium";
          strCapital = "Brussels";
          break;
        case "N": case "n":
          strCountry = "Netherlands";
          strCapital = "Amsterdam";
          break;
        case "F": case "f":
          strCountry = "France";
          strCapital = "Paris";
          break;
        default:
          strCountry = "Unknown";
          strCapital = "Unknown";
          break;
      }
      // strCountryCode

      Console.WriteLine("{0} with capital {1}", strCountry, strCapital);
      Console.WriteLine();
      NestedIf();
      Console.ReadLine();
    }
    // Main()

    static void NestedIf()
    //***
    // Action
    //   - Ask for age
    //   - Depending on given age we define a status (bytCase)
    //     - Case < 18, bytCase becomes 0
    //     - Case > 80, bytCase becomes 1
    //     - Case else, bytCase becomes 2
    //   - Depending on the status
    //     - Case 0, show "You are too young"
    //     - Case 1, show "You are too old"
    //     - Case else, show "Welcome"
    // Called by
    //   - Main()
    // Calls
    //   - byte System.Convert.ToByte(string)
    //   - string System.Console.ReadLine()
    //   - System.Console.Write(string)
    //   - System.Console.WriteLine(string)
    //   - SwitchCase(byte)
    // Created
    //   - CopyPaste � 20220117 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220117 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      byte bytAge;
      byte bytCase;

      Console.Write("Type your age: ");
      bytAge = Convert.ToByte(Console.ReadLine());

      if (bytAge < 18)
      {
        bytCase = 0;
      }
      else if (bytAge > 80)
        // (bytAge >= 18)
      {
        bytCase = 1;
      }
      else
        // (bytAge >= 18) AND (bytAge > 80)
      {
        bytCase = 2;
      }
      // (bytAge >= 18)

      SwitchCase(bytCase);
    }
    // NestedIf()

    static void SwitchCase(byte bytStatus)
    //***
    // Action
    //   - Depending on the status
    //     - Case 0, show "You are too young"
    //     - Case 1, show "You are too old"
    //     - Case else, show "Welcome"
    // Called by
    //   - NestedIf()
    // Calls
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220117 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220117 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      switch (bytStatus)
      {
        case 0:
          Console.WriteLine("You are too young");
          break;
        case 1:
          Console.WriteLine("You are too old");
          break;
        default:
          Console.WriteLine("Welcome");
          break;
      }
      // bytStatus

    }
    // SwitchCase(byte)

  }
  // cpSwitch

}
// Switch