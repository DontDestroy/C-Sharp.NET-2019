//***
// Action
//   - User interface of dices
// Created
//   - CopyPaste � 20230620 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230620 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Game
{

  public class frmDice : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    internal System.Windows.Forms.Label lblSum;
    internal System.Windows.Forms.Button cmdRollTen;
    internal System.Windows.Forms.GroupBox grpDice;
    internal System.Windows.Forms.PictureBox picDice2;
    internal System.Windows.Forms.Button cmdRollRedDice;
    internal System.Windows.Forms.Button cmdRollBlueDice;
    internal System.Windows.Forms.PictureBox picDice1;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDice));
      this.lblSum = new System.Windows.Forms.Label();
      this.cmdRollTen = new System.Windows.Forms.Button();
      this.grpDice = new System.Windows.Forms.GroupBox();
      this.picDice2 = new System.Windows.Forms.PictureBox();
      this.cmdRollRedDice = new System.Windows.Forms.Button();
      this.cmdRollBlueDice = new System.Windows.Forms.Button();
      this.picDice1 = new System.Windows.Forms.PictureBox();
      this.grpDice.SuspendLayout();
      this.SuspendLayout();
      // 
      // lblSum
      // 
      this.lblSum.Location = new System.Drawing.Point(96, 170);
      this.lblSum.Name = "lblSum";
      this.lblSum.Size = new System.Drawing.Size(96, 16);
      this.lblSum.TabIndex = 4;
      this.lblSum.TextAlign = System.Drawing.ContentAlignment.TopCenter;
      // 
      // cmdRollTen
      // 
      this.cmdRollTen.Location = new System.Drawing.Point(88, 194);
      this.cmdRollTen.Name = "cmdRollTen";
      this.cmdRollTen.Size = new System.Drawing.Size(112, 40);
      this.cmdRollTen.TabIndex = 5;
      this.cmdRollTen.Text = "Get 10 Roll Sum";
      this.cmdRollTen.Click += new System.EventHandler(this.cmdRollTen_Click);
      // 
      // grpDice
      // 
      this.grpDice.Controls.Add(this.picDice2);
      this.grpDice.Controls.Add(this.cmdRollRedDice);
      this.grpDice.Controls.Add(this.cmdRollBlueDice);
      this.grpDice.Controls.Add(this.picDice1);
      this.grpDice.Location = new System.Drawing.Point(8, 2);
      this.grpDice.Name = "grpDice";
      this.grpDice.Size = new System.Drawing.Size(272, 152);
      this.grpDice.TabIndex = 3;
      this.grpDice.TabStop = false;
      // 
      // picDice2
      // 
      this.picDice2.Location = new System.Drawing.Point(176, 24);
      this.picDice2.Name = "picDice2";
      this.picDice2.Size = new System.Drawing.Size(56, 64);
      this.picDice2.TabIndex = 3;
      this.picDice2.TabStop = false;
      // 
      // cmdRollRedDice
      // 
      this.cmdRollRedDice.Location = new System.Drawing.Point(152, 96);
      this.cmdRollRedDice.Name = "cmdRollRedDice";
      this.cmdRollRedDice.Size = new System.Drawing.Size(104, 40);
      this.cmdRollRedDice.TabIndex = 1;
      this.cmdRollRedDice.Text = "Roll The Red Die";
      this.cmdRollRedDice.Click += new System.EventHandler(this.cmdRollRedDice_Click);
      // 
      // cmdRollBlueDice
      // 
      this.cmdRollBlueDice.Location = new System.Drawing.Point(16, 96);
      this.cmdRollBlueDice.Name = "cmdRollBlueDice";
      this.cmdRollBlueDice.Size = new System.Drawing.Size(104, 40);
      this.cmdRollBlueDice.TabIndex = 0;
      this.cmdRollBlueDice.Text = "Roll The Blue Die";
      this.cmdRollBlueDice.Click += new System.EventHandler(this.cmdRollBlueDice_Click);
      // 
      // picDice1
      // 
      this.picDice1.Location = new System.Drawing.Point(40, 24);
      this.picDice1.Name = "picDice1";
      this.picDice1.Size = new System.Drawing.Size(56, 64);
      this.picDice1.TabIndex = 0;
      this.picDice1.TabStop = false;
      // 
      // frmDice
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(288, 237);
      this.Controls.Add(this.lblSum);
      this.Controls.Add(this.cmdRollTen);
      this.Controls.Add(this.grpDice);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDice";
      this.Text = "Dice Test";
      this.grpDice.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmDice'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDice()
    //***
    // Action
    //   - Create instance of 'frmDice'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmDice()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdRollBlueDice_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Roll a dice
    //   - Show blue picture
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - Image modDice.GetImage(int, string)
    //   - int modDice.Roll()
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      picDice1.Image = cpDice.GetImage(cpDice.Roll(), "Dice");
    }
    // cmdRollBlueDice_Click(System.Object, System.EventArgs) Handles cmdRollBlueDice.Click
    
    private void cmdRollRedDice_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Roll a dice
    //   - Show red picture
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - Image modDice.GetImage(int, string)
    //   - int modDice.Roll()
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      picDice2.Image = cpDice.GetImage(cpDice.Roll(), "RedDice");
    }
    // cmdRollRedDice_Click(System.Object, System.EventArgs) Handles cmdRollRedDice.Click

    private void cmdRollTen_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Roll dice ten times
    //   - Calculate all values
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - int modDice.RollAndSum(int)
    //   - string System.Convert.ToString(int)
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      lblSum.Text = Convert.ToString(cpDice.RollAndSum(10));
    }
    // cmdRollTen_Click(System.Object, System.EventArgs) Handles cmdRollTen.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmDice
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmDice());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmDice

}
// CopyPaste.Game