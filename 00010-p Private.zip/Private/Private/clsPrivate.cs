//***
// Action
//   - Private variables
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Private
{

  public class cpPrivate
	{
    const float fltCmInch = 2.54f;
    static long lngCounter;
    static long lngNumberOfConversions; 

    static void Main()
    //***
    // Action
    //   - Run private procedures
    //   - Show values of private variables at the console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string, System.Object)
    //   - ToCm(float)
    //   - ToInch(float)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      ToInch(100);
      ToCm(3);
      Console.WriteLine("Number of Conversions : {0}", lngNumberOfConversions);
      Console.WriteLine("Counter : {0}", lngCounter);
      Console.ReadLine();
    }
    // Main()

    private static void ToCm(float fltInch)
    //***
    // Action
    //   - Add one to 'lngCounter' (local)
    //   - Add one to "lngNumberOfConversions'
    //   - Show conversion values at console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string, System.Object, System.Object)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter = 0;
      
      lngNumberOfConversions += 1;
      lngCounter += 1;
      Console.WriteLine("{0} inch = {1} cm", fltInch, fltInch * fltCmInch);
    }
    // ToCm(float)

    private static void ToInch(float fltCm)
    //***
    // Action
    //   - Add one to "lngNumberOfConversions'
    //   - Show conversion values at console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string, System.Object, System.Object)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      lngNumberOfConversions += 1;
      Console.WriteLine("{0} cm = {1} inch", fltCm, fltCm / fltCmInch);
    }
    // ToInch(float)

  }
  // cpPrivate

}
// Private