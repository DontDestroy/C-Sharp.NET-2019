//***
// Action
//   - The definition of cpOverflow
// Created
//   - CopyPaste � 20230808 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230808 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using Microsoft.VisualBasic;

namespace CopyPaste.Learning
{

  public class cpOverflow
  {

    #region "Constructors / Destructors"

    public cpOverflow()
      //***
      // Action
      //   - Empty constructor of cpOverflow
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpOverflow()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Add the maximum of a byte with 2
      //   - Add the maximum of an integer with 2
      //   - Add the maximum of a double with 2
      //   - Sum the integer result with the double result into a byte
      //   - Show the overflow exceptions if any
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      byte bytSum = 0;
      double dblSum = 0;
      int intSum = 0;

      try
      {
        byte bytNumber1 = byte.MaxValue;
        byte bytNumber2 = 2;

        Console.WriteLine("number1: {0}" + ControlChars.CrLf + "number2: {1}", bytNumber1, bytNumber2);
        Console.WriteLine(ControlChars.CrLf + "Sum bytes in checked context:");
        bytSum = (byte)(bytNumber1 + bytNumber2);
        Console.WriteLine(ControlChars.CrLf + "Sum after operation: {0}" + ControlChars.CrLf , bytSum);
      }
      catch (OverflowException theOverflowException) 
      {
        Console.WriteLine(theOverflowException.ToString());
      }

      try
      {
        int intNumber1 = int.MaxValue;
        int intNumber2 = 2;

        Console.WriteLine("number1: {0}" + ControlChars.CrLf + "number2: {1}", intNumber1, intNumber2);
        Console.WriteLine(ControlChars.CrLf + "Sum bytes in checked context:");
        intSum = intNumber1 + intNumber2;
        Console.WriteLine(ControlChars.CrLf + "Sum after operation: {0}" + ControlChars.CrLf , intSum);
      }
      catch (OverflowException theOverflowException) 
      {
        Console.WriteLine(theOverflowException.ToString());
      }

      try
      {
        double dblNumber1 = double.MaxValue;
        double dblNumber2 = 2;

        Console.WriteLine("number1: {0}" + ControlChars.CrLf + "number2: {1}", dblNumber1, dblNumber2);
        Console.WriteLine(ControlChars.CrLf + "Sum bytes in checked context:");
        dblSum = dblNumber1 + dblNumber2;
        Console.WriteLine(ControlChars.CrLf + "Sum after operation: {0}" + ControlChars.CrLf , dblSum);
      }
      catch (OverflowException theOverflowException) 
      {
        Console.WriteLine(theOverflowException.ToString());
      }

      try
      {
        Console.WriteLine("number1: {0}" + ControlChars.CrLf + "number2: {1}", intSum, dblSum);
        Console.WriteLine(ControlChars.CrLf + "Sum integer with double into byte in checked context:");
        bytSum = Convert.ToByte(intSum + dblSum);
        Console.WriteLine(ControlChars.CrLf + "Sum after operation: {0}" + ControlChars.CrLf, bytSum);
      }
      catch (OverflowException theOverflowException)
      {
        Console.WriteLine(theOverflowException.ToString());
      }

      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpOverflow

}
// CopyPaste.Learning