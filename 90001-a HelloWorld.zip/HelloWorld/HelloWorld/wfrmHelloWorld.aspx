﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmHelloWorld.aspx.cs" Inherits="CopyPaste.Learning.wfrmHelloWorld" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Hello World</title>
  <script>
    function ClientAction()
    // Executed when button is clicked (Client side)
    {
      document.getElementById("txtClient").value = "txtClient (cmdClient_onclick)";
    }
    // cmdClient_onclick()
  </script>
</head>
<body>
  <form id="wfrmHelloWorld" runat="server" method="post">
    <div>
      <asp:Label ID="lblText" Style="z-index: 101; position: absolute; top: 48px; left: 24px" runat="server"
        Width="145px" Height="29px">Hello World !</asp:Label>
      <input id="cmdClient" style="z-index: 106; position: absolute; width: 56px; height: 24px; top: 120px; left: 216px; bottom: 230px;"
        type="button" value="Client" onclick="ClientAction()" />
      <asp:Button ID="cmdServer" Style="z-index: 105; position: absolute; top: 152px; left: 216px"
        runat="server" Width="56px" Text="Server" OnClick="cmdServer_Click"></asp:Button>
      <input id="txtClassic" style="z-index: 102; position: absolute; top: 88px; left: 48px; width: 128px;"
        value="Klassieke HTML tag" name="txtClassic" />
      <input id="txtClient" style="z-index: 103; position: absolute; top: 120px; left: 48px; width: 128px;"
        value="HTML Text Field" name="txtHTML" />
      <asp:TextBox ID="txtServer" Style="z-index: 104; position: absolute; top: 152px; left: 48px"
        runat="server" Width="128px">WebForm Text Field</asp:TextBox>
    </div>
  </form>
</body>
</html>
