//***
// Action
//   - Demo of the most common data types in .NET
// Created
//   - CopyPaste � 20240415 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240415 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDataTypes: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.ListBox lstDataType;
    internal System.Windows.Forms.Label lblExampleData;
    internal System.Windows.Forms.Label lblExample;
    internal System.Windows.Forms.Label lblChooseDataType;
    internal System.Windows.Forms.Label lblTitle;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDataTypes));
      this.cmdExit = new System.Windows.Forms.Button();
      this.lstDataType = new System.Windows.Forms.ListBox();
      this.lblExampleData = new System.Windows.Forms.Label();
      this.lblExample = new System.Windows.Forms.Label();
      this.lblChooseDataType = new System.Windows.Forms.Label();
      this.lblTitle = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdExit
      // 
      this.cmdExit.Location = new System.Drawing.Point(352, 208);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.Size = new System.Drawing.Size(80, 24);
      this.cmdExit.TabIndex = 11;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // lstDataType
      // 
      this.lstDataType.Location = new System.Drawing.Point(32, 80);
      this.lstDataType.Name = "lstDataType";
      this.lstDataType.Size = new System.Drawing.Size(176, 147);
      this.lstDataType.TabIndex = 8;
      this.lstDataType.SelectedIndexChanged += new System.EventHandler(this.lstDataType_SelectedIndexChanged);
      // 
      // lblExampleData
      // 
      this.lblExampleData.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblExampleData.Location = new System.Drawing.Point(256, 80);
      this.lblExampleData.Name = "lblExampleData";
      this.lblExampleData.Size = new System.Drawing.Size(176, 24);
      this.lblExampleData.TabIndex = 10;
      this.lblExampleData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblExample
      // 
      this.lblExample.Location = new System.Drawing.Point(256, 64);
      this.lblExample.Name = "lblExample";
      this.lblExample.Size = new System.Drawing.Size(144, 16);
      this.lblExample.TabIndex = 9;
      this.lblExample.Text = "Example";
      // 
      // lblChooseDataType
      // 
      this.lblChooseDataType.Location = new System.Drawing.Point(32, 64);
      this.lblChooseDataType.Name = "lblChooseDataType";
      this.lblChooseDataType.Size = new System.Drawing.Size(168, 16);
      this.lblChooseDataType.TabIndex = 7;
      this.lblChooseDataType.Text = "Choose a data type";
      // 
      // lblTitle
      // 
      this.lblTitle.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblTitle.Location = new System.Drawing.Point(72, 16);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(336, 32);
      this.lblTitle.TabIndex = 6;
      this.lblTitle.Text = "Different kind of data types";
      this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // frmDataTypes
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(472, 261);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.lstDataType);
      this.Controls.Add(this.lblExampleData);
      this.Controls.Add(this.lblExample);
      this.Controls.Add(this.lblChooseDataType);
      this.Controls.Add(this.lblTitle);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataTypes";
      this.Text = "Data Type Tester";
      this.Load += new System.EventHandler(this.frmDataTypes_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDataTypes'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240415 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240415 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDataTypes()
      //***
      // Action
      //   - Create instance of 'frmDataTypes'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240415 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240415 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDataTypes()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    bool mblnBoolean;
    byte mbytByte;
    char mchrUnicodeChar;
    double mdblDouble;
    decimal mdecDecimal;
    DateTime mdtmDate;
    int mintInteger;
    long mlngLong;
    short mshthort;
    float mfltFloat;
    string mstrString;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - End the application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240415 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240415 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();  
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit.Click
    
    private void frmDataTypes_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Add some texts (data types namings) to a listbox
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240415 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240415 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lstDataType.Items.Add("Short");
      lstDataType.Items.Add("Integer");
      lstDataType.Items.Add("Long");
      lstDataType.Items.Add("Float");
      lstDataType.Items.Add("Double");
      lstDataType.Items.Add("Decimal");
      lstDataType.Items.Add("Byte");
      lstDataType.Items.Add("Char");
      lstDataType.Items.Add("String");
      lstDataType.Items.Add("Bool");
      lstDataType.Items.Add("DateTime");
    }
    // frmDataTypes_Load(System.Object, System.EventArgs) Handles this.Load

    private void lstDataType_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Selecting an item in the listbox
      //   - Depending on the order
      //     - Define a Short, Integer, Long, Float, Double, Decimal, Byte, Char, String, Bool, DateTime
      //     - Show a value (converted to string) in label
      //   - When an option is not one of those numbers
      //     - An error message is shown in label
      // Called by
      //   - User action (Select item from listbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240415 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240415 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      switch (lstDataType.SelectedIndex)
      {
        case 0:
          mshthort = 12500;
          lblExampleData.Text = mshthort.ToString();
          break;
        case 1:
          mintInteger = 3750000;
          lblExampleData.Text = mintInteger.ToString();
          break;
        case 2:
          mlngLong = 4800000004;
          lblExampleData.Text = mlngLong.ToString();
          break;
        case 3:
          mfltFloat = 899.99F;
          lblExampleData.Text = mfltFloat.ToString();
          break;
        case 4:
          mdblDouble = 3.1415926535D;
          lblExampleData.Text = mdblDouble.ToString();
          break;
        case 5:
          mdecDecimal = 7600300.5M;
          lblExampleData.Text = mdecDecimal.ToString();
          break;
        case 6:
          mbytByte = 13;
          lblExampleData.Text = mbytByte.ToString();
          break;
        case 7:
          mchrUnicodeChar = '�';
          lblExampleData.Text = mchrUnicodeChar.ToString();
          break;
        case 8:
          mstrString = "Pointer";
          lblExampleData.Text = mstrString;
          break;
        case 9:
          mblnBoolean = true;
          lblExampleData.Text = mblnBoolean.ToString();
          break;
        case 10:
          mdtmDate = new DateTime(1963, 3, 1);
          lblExampleData.Text = mdtmDate.ToString();
          break;
        default:
          lblExampleData.Text = "Not defined!";
          break;
      }
      // lstDataType.SelectedIndex
    
    }
    // lstDataType_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstDataType.SelectedIndexChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDataTypes
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDataTypes()
      // Created
      //   - CopyPaste � 20240415 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240415 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDataTypes());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataTypes

}
// CopyPaste.Learning