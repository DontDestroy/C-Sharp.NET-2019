﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmUploading.aspx.cs" Inherits="CopyPaste.Learning.wfrmUploading" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/html">
<head runat="server">
  <title>Uploading</title>
</head>
<body>
  <form id="wfrmUploading" method="post" runat="server">
    <input id="ffdUploadFile" style="z-index: 101; position: absolute; top: 16px; left: 16px"
      type="file" runat="server" name="ffdUploadFile">
      <asp:Label ID="lblInfo" Style="z-index: 104; position: absolute; top: 128px; left: 56px" runat="server"
        Width="168px"></asp:Label>
      <asp:TextBox ID="txtName" Style="z-index: 103; position: absolute; top: 48px; left: 16px" runat="server"
        Enabled="False"></asp:TextBox>
      <asp:Button ID="cmdUpload" Style="z-index: 102; position: absolute; top: 80px; left: 16px" runat="server"
        Text="Upload"></asp:Button>
  </form>
</body>
</html>
