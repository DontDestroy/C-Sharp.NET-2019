//***
// Action
//   - Implementation of cpAlarmGroup
// Created
//   - CopyPaste � 20240524 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240524 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning.Alarm
{

  public class cpAlarmGroup
  {

    #region "Constructors / Destructors"

    public cpAlarmGroup()
      //***
      // Action
      //   - Default constructor
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

    }
    // cpAlarmGroup()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public delegate void cpBurglarAlarm();
    public delegate void cpFireAlarm(int lngTemperature);
    public delegate void cpMotionAlarm(string strRoom, int lngDuration);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public event cpBurglarAlarm BurglarAlarm;
    // GenerateEvents()
    public event cpFireAlarm FireAlarm;
    // GenerateEvents()
    public event cpMotionAlarm MotionAlarm;
    // GenerateEvents()

    #endregion

    #region "Sub / Function"

    public void GenerateEvents()
      //***
      // Action
      //   - Raise 3 events
      // Called by
      //   - modEventHandler.Main()
      // Calls
      //   - BurglarAlarm() Handles cpAlarmGroup.BurglarAlarm
      //   - FireAlarm(int) Handles cpAlarmGroup.FireAlarm
      //   - MotionAlarm(string, int) Handles cpAlarmGroup.MotionAlarm
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (BurglarAlarm == null)
      {
      }
      else
        // BurglarAlarm <> null
      {
        BurglarAlarm();
      }
      // BurglarAlarm = null

      if (FireAlarm == null)
      {
      }
      else
        // FireAlarm <> null
      {
        FireAlarm(212);
      }
      // FireAlarm = null

      if (MotionAlarm == null)
      {
      }
      else
        // MotionAlarm <> null
      {
        MotionAlarm("Living Room", 25);
      }
      // MotionAlarm = null

    }
    // GenerateEvents()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpAlarmGroup

}
// CopyPaste.Learning.Alarm