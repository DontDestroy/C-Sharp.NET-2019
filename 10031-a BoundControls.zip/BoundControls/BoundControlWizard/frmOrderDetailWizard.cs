//***
// Action
//   - Show the order details of a selected order in frmDataGridDrillDownWizard
// Created
//   - CopyPaste � 20251231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251231 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmOrderDetailWizard: System.Windows.Forms.Form
  {
    private IContainer components;

    #region Windows Form Designer generated code
    internal System.Windows.Forms.TextBox txtOrderID;
    internal System.Windows.Forms.DataGrid dgrOrderDetails;
    internal System.Windows.Forms.DateTimePicker dtpOrderDate;
    internal System.Windows.Forms.Label lblEmployee;
    internal System.Windows.Forms.ComboBox cmbEmployees;
    internal System.Windows.Forms.Label lblOrderDate;
    private BoundControlWizard.dsEmployees dsEmployees;
    private BindingSource bdscrEmployees;
    private BoundControlWizard.dsEmployeesTableAdapters.tbaEmployee tbaEmployee;
    private BindingSource bdsrcOrderInfo;
    private BoundControlWizard.dsOrderInfo dsOrderInfo;
    private BoundControlWizard.dsOrderInfoTableAdapters.tbaOrder tbaOrderInfo;
    private BindingSource bdsrcOrderDetail;
    private BoundControlWizard.dsOrderDetail dsOrderDetail;
    private BoundControlWizard.dsOrderDetailTableAdapters.tbaOrderDetail tbaOrderDetail;
    internal System.Windows.Forms.Label lblOrderId;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOrderDetailWizard));
      this.txtOrderID = new System.Windows.Forms.TextBox();
      this.bdsrcOrderInfo = new System.Windows.Forms.BindingSource(this.components);
      this.dsOrderInfo = new BoundControlWizard.dsOrderInfo();
      this.dgrOrderDetails = new System.Windows.Forms.DataGrid();
      this.bdsrcOrderDetail = new System.Windows.Forms.BindingSource(this.components);
      this.dsOrderDetail = new BoundControlWizard.dsOrderDetail();
      this.dtpOrderDate = new System.Windows.Forms.DateTimePicker();
      this.lblEmployee = new System.Windows.Forms.Label();
      this.cmbEmployees = new System.Windows.Forms.ComboBox();
      this.bdscrEmployees = new System.Windows.Forms.BindingSource(this.components);
      this.dsEmployees = new BoundControlWizard.dsEmployees();
      this.lblOrderDate = new System.Windows.Forms.Label();
      this.lblOrderId = new System.Windows.Forms.Label();
      this.tbaEmployee = new BoundControlWizard.dsEmployeesTableAdapters.tbaEmployee();
      this.tbaOrderInfo = new BoundControlWizard.dsOrderInfoTableAdapters.tbaOrder();
      this.tbaOrderDetail = new BoundControlWizard.dsOrderDetailTableAdapters.tbaOrderDetail();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcOrderInfo)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsOrderInfo)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrderDetails)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcOrderDetail)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsOrderDetail)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdscrEmployees)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsEmployees)).BeginInit();
      this.SuspendLayout();
      // 
      // txtOrderID
      // 
      this.txtOrderID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtOrderID.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcOrderInfo, "intIdOrder", true));
      this.txtOrderID.Location = new System.Drawing.Point(96, 6);
      this.txtOrderID.Name = "txtOrderID";
      this.txtOrderID.Size = new System.Drawing.Size(72, 20);
      this.txtOrderID.TabIndex = 8;
      // 
      // bdsrcOrderInfo
      // 
      this.bdsrcOrderInfo.DataMember = "tblCPOrder";
      this.bdsrcOrderInfo.DataSource = this.dsOrderInfo;
      // 
      // dsOrderInfo
      // 
      this.dsOrderInfo.DataSetName = "dsOrderInfo";
      this.dsOrderInfo.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // dgrOrderDetails
      // 
      this.dgrOrderDetails.AllowSorting = false;
      this.dgrOrderDetails.DataMember = "";
      this.dgrOrderDetails.DataSource = this.bdsrcOrderDetail;
      this.dgrOrderDetails.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrOrderDetails.Location = new System.Drawing.Point(16, 86);
      this.dgrOrderDetails.Name = "dgrOrderDetails";
      this.dgrOrderDetails.ReadOnly = true;
      this.dgrOrderDetails.Size = new System.Drawing.Size(432, 120);
      this.dgrOrderDetails.TabIndex = 13;
      // 
      // bdsrcOrderDetail
      // 
      this.bdsrcOrderDetail.DataMember = "tblCPOrderDetail";
      this.bdsrcOrderDetail.DataSource = this.dsOrderDetail;
      // 
      // dsOrderDetail
      // 
      this.dsOrderDetail.DataSetName = "dsOrderDetail";
      this.dsOrderDetail.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // dtpOrderDate
      // 
      this.dtpOrderDate.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcOrderInfo, "dtmOrderDate", true));
      this.dtpOrderDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtpOrderDate.Location = new System.Drawing.Point(96, 30);
      this.dtpOrderDate.Name = "dtpOrderDate";
      this.dtpOrderDate.Size = new System.Drawing.Size(200, 20);
      this.dtpOrderDate.TabIndex = 10;
      // 
      // lblEmployee
      // 
      this.lblEmployee.Location = new System.Drawing.Point(24, 54);
      this.lblEmployee.Name = "lblEmployee";
      this.lblEmployee.Size = new System.Drawing.Size(56, 16);
      this.lblEmployee.TabIndex = 11;
      this.lblEmployee.Text = "Employee";
      // 
      // cmbEmployees
      // 
      this.cmbEmployees.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.bdsrcOrderInfo, "intEmployeeId", true));
      this.cmbEmployees.DataSource = this.bdscrEmployees;
      this.cmbEmployees.DisplayMember = "FullName";
      this.cmbEmployees.Location = new System.Drawing.Point(96, 54);
      this.cmbEmployees.Name = "cmbEmployees";
      this.cmbEmployees.Size = new System.Drawing.Size(200, 21);
      this.cmbEmployees.TabIndex = 12;
      this.cmbEmployees.ValueMember = "intIdEmployee";
      // 
      // bdscrEmployees
      // 
      this.bdscrEmployees.DataMember = "tblCPEmployee";
      this.bdscrEmployees.DataSource = this.dsEmployees;
      // 
      // dsEmployees
      // 
      this.dsEmployees.DataSetName = "dsEmployees";
      this.dsEmployees.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // lblOrderDate
      // 
      this.lblOrderDate.Location = new System.Drawing.Point(24, 30);
      this.lblOrderDate.Name = "lblOrderDate";
      this.lblOrderDate.Size = new System.Drawing.Size(64, 16);
      this.lblOrderDate.TabIndex = 9;
      this.lblOrderDate.Text = "Order Date";
      // 
      // lblOrderId
      // 
      this.lblOrderId.Location = new System.Drawing.Point(24, 6);
      this.lblOrderId.Name = "lblOrderId";
      this.lblOrderId.Size = new System.Drawing.Size(48, 16);
      this.lblOrderId.TabIndex = 7;
      this.lblOrderId.Text = "Order ID";
      // 
      // tbaEmployee
      // 
      this.tbaEmployee.ClearBeforeFill = true;
      // 
      // tbaOrderInfo
      // 
      this.tbaOrderInfo.ClearBeforeFill = true;
      // 
      // tbaOrderDetail
      // 
      this.tbaOrderDetail.ClearBeforeFill = true;
      // 
      // frmOrderDetailWizard
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(456, 213);
      this.Controls.Add(this.cmbEmployees);
      this.Controls.Add(this.lblOrderDate);
      this.Controls.Add(this.lblOrderId);
      this.Controls.Add(this.txtOrderID);
      this.Controls.Add(this.dgrOrderDetails);
      this.Controls.Add(this.dtpOrderDate);
      this.Controls.Add(this.lblEmployee);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmOrderDetailWizard";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Detail Order Wizard";
      this.Load += new System.EventHandler(this.frmOrderDetailWizard_Load);
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcOrderInfo)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsOrderInfo)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrderDetails)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcOrderDetail)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsOrderDetail)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdscrEmployees)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsEmployees)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmOrderDetailWizard'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmOrderDetailWizard()
      //***
      // Action
      //   - Create instance of 'frmOrderDetailWizard'
      // Called by
      //   - frmDataGridDrillDownWizard.cmdOrderDetail_Click(System.Object, System.EventArgs) Handles cmdOrderDetail.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmOrderDetailWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmOrderDetailWizard_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a variable to store the order key
      //   - Get the selected order key of the global variable (the current frmDataGridDrillDownWizard)
      //   - Fill the data set of employees with the data adapter
      //   - Get the order key
      //   - Set the title of the screen with order key and customer
      //   - Set the parameter for select command of order info
      //   - Fill the data set of order info using the data adapter
      //   - Set the parameter for select command of order details
      //   - Fill the data set of order details using the data adapter
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int intOrderKey;

      tbaEmployee.Fill(dsEmployees.tblCPEmployee);
      intOrderKey = Convert.ToInt32(cpProgram.thefrmDataGridDrillDown.dsOrder.tblCPOrder.Rows[cpProgram.thefrmDataGridDrillDown.dgrOrder.CurrentCell.RowNumber]["intIdOrder"]);
      Text = "Order #" + intOrderKey.ToString() + " For " + cpProgram.thefrmDataGridDrillDown.cmbCustomer.Text;
      tbaOrderInfo.Fill(dsOrderInfo.tblCPOrder, intOrderKey);
      tbaOrderDetail.Fill(dsOrderDetail.tblCPOrderDetail, intOrderKey);
    }
    // frmOrderDetailWizard_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmOrderDetailWizard

}
// CopyPaste.Learning