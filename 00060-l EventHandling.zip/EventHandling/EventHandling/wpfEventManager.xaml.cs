﻿//***
// Action
//   - Show a screen with 2 buttons
//   - An Event handlers is added with code "ConditionalClickEvent"
// Created
//   - CopyPaste – 20220901 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220901 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace EventHandles
{

  public partial class wpfEventManager: Window
  {

    #region "Constructors / Destructors"

    public wpfEventManager()
    //***
    // Action
    //   - Create an instance of 'wpfEventManager'
    //   - Add 1 event
    //     - Name of the event
    //     - Routing strategy (direct, tunneling, bubbling)
    //     - Type of delegate that handles the event
    //     - Type of the class that owns the event
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220901 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220901 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfEventManager

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static readonly System.Windows.RoutedEvent ConditionalClickEvent = System.Windows.EventManager.RegisterRoutedEvent("ConditionalClick", System.Windows.RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(wpfEventManager));

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void OnMouseDoubleClick(System.Windows.Input.MouseButtonEventArgs theMouseButtonEventArguments)
    //***
    // Action
    //   - The double click triggers the newly created event (conditional, but for this demo always true)
    // Called by
    //   - User action (Double clicking the window)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220901 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220901 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (true) // a condition that is always true
      {
        RaiseCustomRoutedEvent();
      }

      base.OnMouseDoubleClick(theMouseButtonEventArguments);
    }
    // OnMouseDoubleClick(System.Windows.Input.MouseButtonEventArgs)

    #endregion

    #region "Controls"

    private void cmdFirstWithEventManager_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Trigger an event
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - RaiseCustomRoutedEvent()
    // Created
    //   - CopyPaste – 20220901 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220901 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      RaiseCustomRoutedEvent();
    }
    // cmdFirstWithEventManager_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdFirstWithEventManager.Click

    private void cmdSecondWithEventManager_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Trigger an event
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - RaiseCustomRoutedEvent()
    // Created
    //   - CopyPaste – 20220901 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220901 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      RaiseCustomRoutedEvent();
    }
    // cmdSecondWithEventManager_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdSecondWithEventManager.Click

    #endregion

    #region "Functionality"

    #region "Event"

    public event System.Windows.RoutedEventHandler ConditionalClick
    //***
    // Action
    //   - Define a ConditionalClick event
    // Called by
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220901 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220901 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      add
      {
        this.AddHandler(ConditionalClickEvent, value);
      }

      remove
      {
        this.RemoveHandler(ConditionalClickEvent, value);
      }

    }
    // System.Windows.RoutedEventHandler ConditionalClick

    private void ConditionalClickHandler(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Show a messagebox that the conditional click is executed (Handled)
    // Called by
    //   - User action (Double clicking on the window)
    //   - User action (Clicking on a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220901 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220901 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      MessageBox.Show("The conditional Click is executed");
    }
    // ConditionalClickHandler(System.Object, System.Windows.RoutedEventArgs) Handles ConditionalClick

    public void RaiseCustomRoutedEvent()
    //***
    // Action
    //   - Raise a ConditionalClickEvent event
    //     - Create an instance of RoutedEventArgs
    //     - Raise the event, which will bubble up (bottom up)
    // Called by
    //   - cmdFirstWithEventManager_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdFirstWithEventManager.Click
    //   - cmdSecondWithEventManager_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdSecondWithEventManager.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220901 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220901 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      RoutedEventArgs theRoutedEventArguments = new RoutedEventArgs(wpfEventManager.ConditionalClickEvent);

      RaiseEvent(theRoutedEventArguments);
    }
    // RaiseCustomRoutedEvent()

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfEventManager 

}
// EventHandles