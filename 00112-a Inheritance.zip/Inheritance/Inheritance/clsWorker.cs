//***
// Action
//   - Implementation of a cpWorker
//   - Inherits from cpEmployee
// Created
//   - CopyPaste � 20240405 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240405 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpWorker : cpEmployee
  {

    #region "Constructors / Destructors"

    public cpWorker() : base()
      //***
      // Action
      //   - Default constructor
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee()
      //   - HourPrice(Decimal) (Set)
      //   - Shift(Byte) (Set)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      HourPrice = 0;
      Shift = 1;
    }
    // cpWorker()

    public cpWorker(string strName, cpSex thecpSex, DateTime dtmStartDate, Decimal decHourPrice, byte bytShift) : base(strName, thecpSex, dtmStartDate)
      //***
      // Action
      //   - Constructor with Name, Sex, StartDate, HourPrice and Shift
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee(string, cpSex, DateTime)
      //   - HourPrice(decimal) (Set)
      //   - Shift(byte) (Set)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      HourPrice = decHourPrice;
      Shift = bytShift;
    }
    // cpWorker(string, cpSex, DateTime, Decimal, byte)
 
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private byte mbytShift;
    private decimal mdecHourPrice;

    #endregion

    #region "Properties"

    public decimal HourPrice
    {

      get
        //***
        // Action Get
        //   - Returns mdecHourPrice
        // Called by
        //   - ShowInfo() 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecHourPrice;
      }
      // decimal HourPrice (Get)

      set
        //***
        // Action Set
        //   - mdecHourPrice becomes value
        //   - Only positive values or zero are allowed
        // Called by
        //   - cpWorker()
        //   - cpWorker(string, cpSex, DateTime, decimal, byte)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value >= 0)
        {
          mdecHourPrice = value;
        }
        else
          // value < 0
        {
        }
        // value >= 0

      }
      // HourPrice(decimal) (Set)

    }
    // decimal HourPrice

    public byte Shift
    {

      get
        //***
        // Action Get
        //   - Returns mbytShift
        // Called by
        //   - ShowInfo()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mbytShift;
      }
      // byte Shift (Get)

      set
        //***
        // Action Set
        //   - mbytShift becomes bytValue
        //   - Only values 1 till 3 are allowed
        // Called by
        //   - cpWorker()
        //   - cpWorker(string, cpSex, DateTime, decimal, byte)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if ((value >= 1) && (value <= 3))
        {
          mbytShift = value;
        }
        else
          // (value < 1) OrElse (value > 3)
        {
        }
        // (value >= 1) AndAlso (value <= 3)

      }
      // Shift(byte) (Set)

    }
    // byte Shift

    #endregion

    #region "Methods"

    #region "Overrides"

    public override void ShowInfo()
      //***
      // Action
      //   - Shows information to the console
      //     - Name, Sex, StartDate, Is it a Workanniversary, Is it CompanyParty
      //     - HourPrice and Shift
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - byte Shift (Get)
      //   - cpEmployee.ShowInfo()
      //   - decimal HourPrice (Get)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      base.ShowInfo();
      Console.WriteLine("HourPrice: {0}", HourPrice);
      Console.WriteLine("Shift: {0}", Shift);
    }
    // ShowInfo()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpWorker

}
// CopyPaste.Learning.Employee