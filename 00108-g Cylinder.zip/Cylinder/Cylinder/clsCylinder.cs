//***
// Action
//   - Definition of cpCylinder using a cpCircle as base
// Created
//   - CopyPaste � 20231230 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231230 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Math
{

	public class cpCylinder : cpCircle
	{

		#region "Constructors / Destructors"

		public cpCylinder() : base()
			//***
			// Action
			//   - Default constructor
			//   - Creates the Base as a circle (being itself)
			//   - Set height property to 0
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - Base(cpCircle) (Set)
			//   - cpCircle()
			//   - Height(double) (Set)
			// Created
			//   - CopyPaste � 20231230 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231230 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
  	{
			Base = this;
			Height = 0;
		}
		// cpCylinder()

		public cpCylinder(int lngX, int lngY, double dblRadius, double dblHeight) : base(lngX, lngY, dblRadius)
				//***
				// Action
				//   - Constructor with 4 arguments
				//   - Sets X, Y and Radius property to the given arguments thru the base class
				//   - Creates the Base as a circle (being itself)
				//   - Set Height to the given argument
				// Called by
				//   - cpProgram.Main()
				// Calls
				//   - Base(cpCircle) (Set)
				//   - cpCircle(int, int, double)
				//   - Height(double) (Set)
				// Created
				//   - CopyPaste � 20231230 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231230 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
		{
			Base = this;
			Height = dblHeight;
		}
		// cpCylinder(int, int, double, double)

		public cpCylinder(cpPoint thecpPoint, double dblRadius, double dblHeight) : base(thecpPoint, dblRadius)
			//***
			// Action
			//   - Constructor with 3 arguments
			//   - Sets thecpPoint and Radius property to the given arguments thru the base class
			//   - Creates the Base as a circle (being itself)
			//   - Set Height to the given argument
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - Base(cpCircle) (Set)
			//   - cpCircle(cpPoint, double)
			//   - Height(double) (Set)
			// Created
			//   - CopyPaste � 20231230 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231230 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Base = this;
			Height = dblHeight;
		}
		// cpCylinder(int, int, double, double)

		public cpCylinder(cpCircle thecpCircle, double dblHeight)
			//***
			// Action
			//   - Constructor with 2 arguments
			//   - Sets Base property to the given argument
			//   - Set Height to the given argument
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - Base(cpCircle) (Set)
			//   - Height(double) (Set)
			// Created
			//   - CopyPaste � 20231230 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231230 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Base = thecpCircle;
			Height = dblHeight;
		}
		// cpCylinder(cpCircle, double)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private cpCircle mcpBase;
		private double mdblHeight;

		#endregion

		#region "Properties"

		public cpCircle Base
		{

			get
				//***
				// Action Get
				//   - Returns mcpBase
				// Called by
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231230 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231230 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mcpBase;
			}
			// cpCircle Base (Get)

			set
				//***
				// Action Set
				//   - mcpBase becomes value
				// Called by
				//   - cpCylinder()
				//   - cpCylinder(cpCircle, double)
				//   - cpCylinder(cpPoint, double, double)
				//   - cpCylinder(int, int, double, double)
				// Calls
				//   - double cpCircle.Radius (Get)
				//   - int cpPoint.X (Get)
				//   - int cpPoint.Y (Get)
				//   - Radius(double) (Set)
				//   - X(int) (Set)
				//   - Y(int) (Set)
				// Created
				//   - CopyPaste � 20231230 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231230 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				mcpBase = value;
				X = value.X;
				Y = value.Y;
				Radius = value.Radius;
			}
			// Base(cpCircle) (Set)

		}
		// cpCircle Base

		public double Height
		{

			get
				//***
				// Action Get
				//   - Returns mdblHeight
				// Called by
				//   - 
				//   - cpProgram.Main()
				//   - double Area()
				//   - double Volume()
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231230 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231230 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mdblHeight;
			}
			// double Height (Get)

			set
				//***
				// Action Set
				//   - If value is bigger than zero
				//     - mdblRadius becomes value
				//   - If not
				//     - mdblRadius becomes zero
				// Called by
				//   - cpCylinder()
				//   - cpCylinder(cpCircle, double)
				//   - cpCylinder(cpPoint, double, double)
				//   - cpCylinder(int, int, double, double)
				//   - cpProgram.Main()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231230 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231230 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{

				if (value >= 0)
				{
					mdblHeight = value;
				}
				else
					// value < 0
				{
					mdblHeight = 0;
				}
				// value > 0

			}
			// Height(double) (Set)

		}
		// double Height

		#endregion

		#region "Methods"

		#region "Overrides"

		public override double Area()
			//***
			// Action
			//   - Calculates the area of a cpCylinder
			// Called by
			//   - cpProgarm.Main()
			// Calls
			//   - double cpCircle.Area()
			//   - double cpCircle.Circumference()
			//   - double Height (Get)
			// Created
			//   - CopyPaste � 20231230 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231230 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			return 2 * base.Area() + base.Circumference() * Height;
		}
		// double Area()

		public override string ToString()
			//***
			// Action
			//   - Genererates the items shown when asking ToString() using the ToString of the base class
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - double Height (Get)
			//   - string cpCircle.ToString()
			// Created
			//   - CopyPaste � 20231230 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231230 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			return base.ToString() + "; Height = " + Height;
		}
		// string ToString()

		#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public double Volume()
			//***
			// Action
			//   - Calculates the volume of a cpCylinder
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - double cpCircle.Area()
			//   - double Height (Get)
			// Created
			//   - CopyPaste � 20231230 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231230 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			return base.Area() * Height;
		}
		// double Volume()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpCylinder

}
// CopyPaste.Learning.Math