//***
// Action
//   - Using a cpBook class
// Created
//   - CopyPaste � 20220301 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220301 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Book
{

  class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    static void Main()
    //***
    // Action
    //   - Creating a cpBook
    //   - Putting information in it
    //   - Showing the information
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string Console.ReadLine()
    //   - Console.WriteLine(string)
    //   - cpBook.cpBook()
    //   - cpBook.DisplayBookInfo()
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      cpBook theBook = new cpBook();

      theBook.mstrTitle = "C#.Net Programming Tips & Techniques";
      theBook.mstrAuthor = "Jamsa";
      theBook.mstrPublisher = "McGraw-Hill/Osborne";
      theBook.mdblPrice = 49.99;
      
      theBook.DisplayBookInfo();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion
   
	}
  // cpProgram

}
// Book