//***
// Action
//   - A class inside another class
// Created
//   - CopyPaste � 20240312 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240312 � VVDW
// Proposal (To Do)
//   - Move the class to a better location, so the class is reuseable
//***

using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpProgram()

    #endregion

    #region "Designer"

    public class cpTVShow
    {

      #region "Constructors / Destructors"

      public cpTVShow(string strShowName, string strDayOfWeek, string strShowTime)
        //***
        // Action
        //   - Constructor with 3 strings
        //     - Showname, day of the week and hour is shown after creation
        // Called by
        //   - Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � yyyymmdd � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � yyyymmdd � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mstrName = strShowName;
        mstrDay = strDayOfWeek;
        mstrTime = strShowTime;
        MessageBox.Show("Name: " + mstrName + " - Day: " + mstrDay + " - Time: " + mstrTime);
      }
      // cpTVShow(string, string, string)

      #endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      #region "Fields"

      public string mstrDay;
      public string mstrName;
      public string mstrTime;

      #endregion

      //#region "Properties"
      //#endregion

      #region "Methods"

      //#region "Overrides"
      //#endregion

      //#region "Controls"
      //#endregion

      #region "Functionality"

      //#region "Event"
      //#endregion

      #region "Sub / Function"

      //***
      // Action
      //   - Explanation of the code in this method
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
		
      #endregion

      #endregion

      #endregion

      //#region "Not used"
      //#endregion

    }
    // cpTVShow

    #endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Testroutine for the class cpTVShow
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpTVShow(string, string, string)
      // Created
      //   - CopyPaste � cpProgram � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � cpProgram � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpTVShow theComedy = new cpTVShow("Friends", "Thursday", "19:00");
      cpTVShow theDrama = new cpTVShow("West Wing", "Wednesday", "20:00");
      cpTVShow theMedical = new cpTVShow("ER", "Thursday", "21:00");
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning