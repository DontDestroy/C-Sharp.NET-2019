//***
// Action
//   - Demo of a font dialog
// Created
//   - CopyPaste � 20240715 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240715 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFont: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtResult;
    internal System.Windows.Forms.Button cmdFont;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFont));
      this.txtResult = new System.Windows.Forms.TextBox();
      this.cmdFont = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(21, 80);
      this.txtResult.Multiline = true;
      this.txtResult.Name = "txtResult";
      this.txtResult.Size = new System.Drawing.Size(250, 150);
      this.txtResult.TabIndex = 3;
      this.txtResult.Text = "";
      // 
      // cmdFont
      // 
      this.cmdFont.Location = new System.Drawing.Point(105, 32);
      this.cmdFont.Name = "cmdFont";
      this.cmdFont.TabIndex = 2;
      this.cmdFont.Text = "Font Info";
      this.cmdFont.Click += new System.EventHandler(this.cmdFont_Click);
      // 
      // frmFont
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.txtResult);
      this.Controls.Add(this.cmdFont);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFont";
      this.Text = "Font";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFont'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240715 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFont()
      //***
      // Action
      //   - Create instance of 'frmFont'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240715 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFont()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    FontDialog mdlgFont = new FontDialog();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFont_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a font dialog
      //   - If OK is clicked
      //     - Generate a text in the textbox
      //       - Add the font name
      //       - Add the bold value
      //       - Add the italic value
      //       - Add the font size
      //       - Add the font strikeout
      //       - Add the font underline
      //   - If not
      //     - Nothing happens
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240715 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (mdlgFont.ShowDialog() == DialogResult.OK)
      {
        string strCrLf = Environment.NewLine;
        
        txtResult.Text = "";
        txtResult.AppendText("Font Name: " + mdlgFont.Font.Name);
        txtResult.AppendText(strCrLf);
        txtResult.AppendText("Bold: " + mdlgFont.Font.Bold);
        txtResult.AppendText(strCrLf);
        txtResult.AppendText("Italic: " + mdlgFont.Font.Italic);
        txtResult.AppendText(strCrLf);
        txtResult.AppendText("Size: " + mdlgFont.Font.Size);
        txtResult.AppendText(strCrLf);
        txtResult.AppendText("Strikeout: " + mdlgFont.Font.Strikeout);
        txtResult.AppendText(strCrLf);
        txtResult.AppendText("Underline: " + mdlgFont.Font.Underline);
        txtResult.AppendText(strCrLf);
      }
      else
        // mdlgFont.ShowDialog() <> DialogResult.OK
      {
      }
      // mdlgFont.ShowDialog() = DialogResult.OK
    
    }
    // cmdFont_Click(System.Object, System.EventArgs) Handles cmdFont.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFont
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmFont()
      // Created
      //   - CopyPaste � 20240715 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyy20240715ymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFont());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmFont

}
// CopyPaste.Learning