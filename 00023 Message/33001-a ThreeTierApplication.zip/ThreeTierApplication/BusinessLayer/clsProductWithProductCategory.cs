﻿//***
// Action
//   - Business Layer Product with Product Category
// Created
//   - CopyPaste – 20220826 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220826 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.BackEndApplication;
using System;
using System.Collections.Generic;
using System.Text;

namespace CopyPaste.MiddleTierApplication
{

  public class dtsProductWithProductCategory : IdtsProductWithProductCategory
  {

    #region "Constructors / Destructors"

    public dtsProductWithProductCategory()
    //***
    // Action
    //   - Create instance of dtsProductWithProductCategory
    //   - Create an instance of the list of Products
    //   - Create an instance of the list of Product Categories
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220825 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220825 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      _AllProductsWithProductCategory = new Dictionary<string, string>();
      _AllProducts = new dtsProduct();
      _AllProductCategories = new dtsProductCategory();
    }
    // dtsProductWithProductCategory()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private IDictionary<string, string> _AllProductsWithProductCategory;
    private IdtsProduct _AllProducts;
    private IdtsProductCategory _AllProductCategories;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public IDictionary<string, string> AllProductsWithProductCategory()
    //***
    // Action
    //   - Fill the list of Products
    //   - Fill the list of Product Categories
    //   - Loop thru the list of Products
    //     - Find the Product Category Key
    //     - 
    //     - Add the Product with the Product Category
    //   - Return the build Dictionary
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220825 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220825 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int intProductCategoryKey;
      string strProduct;
      string strProductCategory;
      string strProductCategoryKey;

      IDictionary<int, string> dicProductCategories = _AllProductCategories.AllProductCategories();
      IDictionary<int, string> dicProducts = _AllProducts.AllProducts();

      foreach (int intKey in dicProducts.Keys)
      {
        strProduct = dicProducts[intKey];
        strProductCategoryKey = strProduct.Substring(strProduct.LastIndexOf("#") + 1);
        strProduct = strProduct.Substring(0, strProduct.LastIndexOf("#"));

        if (strProductCategoryKey == "")
        {
          strProductCategory = "";
        }
        // strProductCategoryKey <> ""
        else
        {
          intProductCategoryKey = Convert.ToInt32(strProductCategoryKey);
          strProductCategory = dicProductCategories[intProductCategoryKey];
        }
        // strProductCategoryKey = ""

        _AllProductsWithProductCategory.Add(strProduct, strProductCategory);
      }
      // in dicProducts.Keys

      return _AllProductsWithProductCategory;
    }
    // IDictionary<string, string> AllProductsWithProductCategory()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // dtsProductWithProductCategory

}
// CopyPaste.MiddleTierApplication