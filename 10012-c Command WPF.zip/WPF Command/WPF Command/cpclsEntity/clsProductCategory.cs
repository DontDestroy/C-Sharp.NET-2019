﻿//***
// Action
//   - Class implements the Product Category object
//   - Decided not to document this class in the normal way
// Created
//   - CopyPaste – 20210809 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210809 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace WPFCommand
{

  public class cpProductCategory : cpCommon
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public string CategoryName { get; set; }
    public int ProductCategoryKey { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpProductCategory 

}
// WPFCommand