//***
// Action
//   - String handling using Microsoft.VisualBasic namespace
// Created
//   - CopyPaste � 20240216 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240216 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
		
    public static void Main()
      //***
      // Action
      //   - Define some variables
      //   - Show some info on the screen
      //     - Using InStr, InStrRev, Left, LTrim, Mid, Right, Substring, ToLower, ToUpper, Trim, UCase
      // Called by
      //   - User action (Starting the program)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240216 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngPosition1;
      int lngPosition2;
      string strFirst;
      string strSecond;
      string strText = "A long time ago, in a galaxy far, far away ...";
      string strThird;

      Console.WriteLine("THE STRING HANDLING PROGRAM");
      Console.WriteLine("---------------------------");
      Console.WriteLine();
      Console.WriteLine("strText = " + strText);

      Console.WriteLine();
      Console.WriteLine("Strings.Left(strText, 15)                  = " + Strings.Left(strText, 15));
      Console.WriteLine("strText.Substring(0, 15)                   = " + strText.Substring(0, 15));
      Console.WriteLine("Strings.Mid(strText, 18, 15)               = " + Strings.Mid(strText, 18, 15));
      Console.WriteLine("strText.Substring(17, 15)                  = " + strText.Substring(17, 15));
      Console.WriteLine("Strings.Right(strText, 17)                 = " + Strings.Right(strText, 17));
      Console.WriteLine("strText.Substring(strText.Length - 17, 17) = " + strText.Substring(strText.Length - 17, 17));
      Console.WriteLine();

      lngPosition1 = Strings.InStr(strText, ",", Microsoft.VisualBasic.CompareMethod.Text);
      lngPosition2 = Strings.InStrRev(strText, ",", -1, Microsoft.VisualBasic.CompareMethod.Text);
      strFirst = Strings.Mid(strText, 1, lngPosition1 - 1);
      strSecond = Strings.Mid(strText, lngPosition1 + 1, lngPosition2 - lngPosition1 - 1);
      strThird = Strings.Mid(strText, lngPosition2 + 1);

      Console.WriteLine("strFirst  = " + strFirst);
      Console.WriteLine("strSecond = " + strSecond);
      Console.WriteLine("strThird  = " + strThird);
      Console.WriteLine();
      
      Console.WriteLine("Strings.Trim(strFirst)  = " + Strings.Trim(strFirst));
      Console.WriteLine("strSecond.Trim()        = " + strSecond.Trim());
      Console.WriteLine("Strings.LTrim(strThird) = " + Strings.LTrim(strThird));
      Console.WriteLine();

      Console.WriteLine("Strings.UCase(strFirst)   = " + Strings.UCase(strFirst));
      Console.WriteLine("strSecond.ToUpper()       = " + strSecond.ToUpper());
      Console.WriteLine("strThird.ToLower()        = " + strThird.ToLower());
      Console.WriteLine();

      Console.WriteLine("Press Enter...");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning