﻿//***
// Action
//   - Definition of NasDaq Ticker Listing
// Created
//   - CopyPaste – 20251221 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251221 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpStockNasDaq
  {

    #region "Constructors / Destructors"

    public cpStockNasDaq(string strNasDaqTickerCode, decimal decOpeningValue, decimal decHighestValue, decimal decLowestValue, long lngMarketCapacityInBillions)
    //***
    // Action
    //   - Basic constructor with 5 parameters
    //     - NasDaqTickerCode (of stock item)
    //     - OpeningValue
    //     - HighestValue
    //     - LowestValue
    //     - MarketCapacityInBillions
    // Called by
    //   - Task<IEnumerable<cpStockNasDaq>> cpSharedServiceTask.GetShareDetails()
    //   - ValueTask<IEnumerable<cpStockNasDaq>> cpSharedServiceValueTask.GetShareDetails()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251221 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251221 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      NasDaqSymbol = strNasDaqTickerCode;
      OpeningValue = decOpeningValue;
      HighestValue = decHighestValue;
      LowestValue = decLowestValue;
      MarketCapacityInBillions = lngMarketCapacityInBillions;
    }
    // cpStockNasDaq()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public string NasDaqSymbol { get; private set; }
    // cpStockNasDaq()

    public decimal OpeningValue { get; private set; }
    // cpStockNasDaq()
    
    public decimal HighestValue { get; private set; }
    // cpStockNasDaq()

    public decimal LowestValue { get; private set; }
    // cpStockNasDaq()

    public long MarketCapacityInBillions { get; private set; }
    // cpStockNasDaq()

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpStockNasDaq

}
// CopyPaste.Learning