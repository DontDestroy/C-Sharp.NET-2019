﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace WPFProgressBar
{

  public partial class App : Application
  {
  }
  // App

}
// WPFProgressBar
