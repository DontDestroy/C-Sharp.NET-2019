﻿//***
// Action
//   - Definition of a Customer (linked with customer interface)
//   - This contains (thru the customer component interface)
//     - Customer connection (Connection string)
//     - Customer data adapter
//   - This contains (thru the customer class interface)
//     - Properties
//     - Methods
// Created
//   - CopyPaste – 20050508 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20050508 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpCustomerTryout: cmpCustomerTryout, cpiCustomerTryout
  {

    #region "Constructors / Destructors"

    public cpCustomerTryout()
      //***
      // Action
      //   - Create new instance of 'cpCustomerTryout'
      // Called by
      //   - cpCustomerTryout(cpKeyCustomerTryout, string)
      //   - cpCustomerTryout(string)
      //   - frmCustomerValidationBetterTryout()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpCustomer()

    public cpCustomerTryout(string strKeyCustomer) : this()
      //***
      // Action
      //   - Create new instance of 'cpCustomerTryout' with a unique key
      //   - Set an instance of dsCustomer
      //   - Try to
      //     - Set the parameter for the data adapter command (strKeyCustomer)
      //     - Fill the data set using the data adapter
      //     - If there is one record found
      //       - Fill the data row with the found record
      //       - Read the values from the dat row
      //     - If not (there are none)
      //       - Throw the application exception that the customer was not found
      //       - Attention: Thru database constraints it is impossible
      //   - When error occurs
      //     - Throw new application exception that customer row could not be retrieved
      // Called by
      //   - frmCustomerValidationBetterTryout.cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click
      // Calls
      //   - bool ValidateKeyCustomer(string)
      //   - cpCustomerTryout()
      //   - cpInvalidKeyCustomer(string)
      //   - ReadValuesFromDataRow()
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpCustomerTryout(string)

    public cpCustomerTryout(cpKeyCustomerTryout theKeyCustomer, string strCompanyName) : this()
      //***
      // Action
      //   - Create new instance of 'cpCustomerTryout' with a unique key and a company name
      //   - If strKeyCustomer already exists
      //     - Set an instance of dsCustomer
      //     - Set boolean new to true
      //     - Set customer Id
      //     - Set Company name to given company name
      //     - All other properties are set to empty string
      //   - Try to
      //     - Set the parameter for the data adapter command (strKeyCustomer)
      //     - Fill the data set using the data adapter
      //     - If there is one record found
      //       - Fill the data row with the found record
      //       - Read the values from the dat row
      //     - If not (there are none)
      //       - Throw the application exception that the customer was not found
      //       - Attention: Thru database constraints it is impossible
      //   - When error occurs
      //     - Throw new application exception that customer row could not be retrieved
      // Called by
      //   - frmCustomerValidationBetter.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      // Calls
      //   - Address(string) (Set)
      //   - bool cpKeyCustomerTryout.Exists(string)
      //   - City(string) (Set)
      //   - CompanyName(string) (Set)
      //   - ContactName(string) (Set)
      //   - ContactTitle(string) (Set)
      //   - Country(string) (Set)
      //   - cpCheckPhoneNumber(string)
      //   - cpCheckString.CheckBeforeUpdate(string, °bool)
      //   - cpCustomer()
      //   - cpInvalidKeyCustomerException(string)
      //   - cpKeyCustomerTryout(cpKeyCustomerTryout)
      //   - cpKeyCustomerTryout cpKeyCustomerTryout.IdCustomer (Get)
      //   - Fax(cpCheckPhoneNumber) (Set)
      //   - Phone(cpCheckPhoneNumber) (Set)
      //   - PostalCode(string) (Set)
      //   - ReadValuesFromDataRow()
      //   - Region(string) (Set)
      //   - string cpKeyCustomerTryout.KeyCustomer (Get)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpCustomerTryout(cpKeyCustomerTryout, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public string Address
    {

      get
        //***
        // Action Get
        //   - Return 'mstrAddress'
        // Called by
        //   - bool Save() Implements cpiCustomerTryout.Save 
        //   - frmCustomerValidationBetterTryout.CustomerProperties()
        //   - string ToString() Implements cpiCustomerTryout.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string Address (Get)

      set
        //***
        // Action Set
        //   - If Validation is true
        //     - If length of strValue > 60
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrAddress becomes value
        //   - If not
        //     - mstrAddress becomes value
        // Called by
        //   - Clear()
        //   - cpCustomerTryout(cpCustomerTryout, string)
        //   - frmCustomerValidationBetterTryout.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetterTryout.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // Address(string) (Set)

    }
    // string Address Implements cpiCustomerTryout.Address

    public string City
    {

      get
        //***
        // Action Get
        //   - Return 'mstrCity'
        // Called by
        //   - bool Save() Implements cpiCustomerTryout.Save 
        //   - frmCustomerValidationBetterTryout.CustomerProperties()
        //   - string ToString() Implements cpiCustomerTryout.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string City (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 15
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrCity becomes strValue
        //   - If not
        //     - mstrCity becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomerTryout(cpKeyCustomerTryout, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        //   - frmCustomerValidationValidationTryout.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationValidationTryout.TextBoxChange(String, String)
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // City(string) (Set)

    }
    // string City Implements cpiCustomerTryout.City

    public string CompanyName
    {

      get
        //***
        // Action Get
        //   - Return 'mstrCompanyName'
        // Called by
        //   - bool Save() Implements cpiCustomerTryout.Save 
        //   - frmCustomerValidationBetterTryout.CustomerProperties()
        //   - string ToString() Implements cpiCustomerTryout.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string CompanyName (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 40
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrCompanyName becomes strValue
        //   - If not
        //     - mstrCompanyName becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomerTryout(cpKeyCustomerTryout, String)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        //   - frmCustomerValidationBetterTryout.TextBoxChange(string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // CompanyName(string) (Set)

    }
    // string CompanyName Implements cpiCustomerTryout.CompanyName

    public string ContactName
    {

      get
        //***
        // Action Get
        //   - Return 'mstrContactName'
        // Called by
        //   - bool Save() Implements cpiCustomerTryout.Save 
        //   - frmCustomerValidationBetterTryout.CustomerProperties()
        //   - string ToString() Implements cpiCustomerTryout.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string ContactName (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 30
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrContactName becomes strValue
        //   - If not
        //     - mstrContactName becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomerTryout(cpKeyCustomerTryout, string)
        //   - frmCustomerValidationBetterTryout.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetterTryout.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // ContactName(string) (Set)

    }
    // string ContactName Implements cpiCustomerTryout.ContactName

    public string ContactTitle
    {

      get
        //***
        // Action Get
        //   - Return 'mstrContactTitle'
        // Called by
        //   - bool Save() Implements cpiCustomerTryout.Save 
        //   - frmCustomerValidationBetterTryout.CustomerProperties()
        //   - string ToString() Implements cpiCustomerTryout.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string ContactTitle (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 30
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrContactTitle becomes strValue
        //   - If not
        //     - mstrContactTitle becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomerTryout(cpKeyCustomerTryout, string)
        //   - frmCustomerValidationBetterTryout.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetterTryout.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // ContactTitle(string) (Set)

    }
    // string ContactTitle Implements cpiCustomerTryout.ContactTitle

    public string Country
    {

      get
        //***
        // Action Get
        //   - Return 'mstrContry'
        // Called by
        //   - bool Save() Implements cpiCustomerTryout.Save 
        //   - frmCustomerValidationBetterTryout.CustomerProperties()
        //   - string ToString() Implements cpiCustomerTryout.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string Country (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 15
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrCountry becomes strValue
        //   - If not
        //     - mstrCountry becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomerTryout(cpKeyCustomerTryout, string)
        //   - frmCustomerValidationBetterTryout.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetterTryout.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // Country(string) (Set)

    }
    // string Country Implements cpiCustomerTryout.Country

    public cpCheckPhoneNumber Fax
    {

      get
        //***
        // Action Get
        //   - Return 'mtheFax'
        // Called by
        //   - bool Save() Implements cpiCustomerTryout.Save 
        //   - frmCustomerValidationBetterTryout.CustomerProperties()
        //   - string ToString() Implements cpiCustomerTryout.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return null;
      }
      // cpCheckPhoneNumber Fax (Get)

      set
        //***
        // Action
        //   - mtheFax becomes value
        // Called by
        //   - Clear()
        //   - cpCustomerTryout(cpKeyCustomerTryout, string)
        //   - frmCustomerValidationBetterTryout.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetterTryout.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // Fax(cpCheckPhoneNumber) (Set)

    }
    // cpCheckPhoneNumber Fax Implements cpiCustomerTryout.Fax

    public cpKeyCustomerTryout IdCustomer
    {

      get
        //***
        // Action Get
        //   - Return 'mtheIdCustomer'
        // Called by
        //   - bool Save() Implements cpiCustomerTryout.Save 
        //   - cpCustomerTryout(cpKeyCustomerTryout, String)
        //   - string ToString() Implements cpiCustomerTryout.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return null;
      }
      // cpKeyCustomerTryout IdCustomer (Get)

      set
        //***
        // Action Set
        //   - 'mtheIdCustomer' becomes value
        // Called by
        //   - Clear()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // IdCustomerTryout(cpKeyCustomer) (Set)

    }
    // cpKeyCustomerTryout IdCustomer Implements cpiCustomerTryout.IdCustomer

    public cpCheckPhoneNumber Phone
    {

      get
        //***
        // Action Get
        //   - Return 'mthePhone'
        // Called by
        //   - bool Save() As Boolean Implements cpiCustomerTryout.Save 
        //   - frmCustomerValidationBetterTryout.CustomerProperties()
        //   - string ToString() Implements cpiCustomerTryout.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
      {
        return null;
      }
      // cpCheckPhoneNumber Phone (Get)

      set
        //***
        // Action
        //   - mthePhone becomes value
        // Called by
        //   - Clear()
        //   - cpCustomerTryout(cpKeyCustomerTryout, string)
        //   - frmCustomerValidationBetterTryout.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetterTryout.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // Phone(cpCheckPhoneNumber) (Set)

    }
    // cpCheckPhoneNumber Phone Implements cpiCustomerTryout.Phone

    public string PostalCode
      //***
      // Action Get
      //   - Return 'mstrPostalCode'
      // Called by
      //   - bool Save() Implements cpiCustomerTryout.Save 
      //   - frmCustomerValidationBetterTryout.CustomerProperties()
      //   - string ToString() Implements cpiCustomerTryout.ToString
      //   - WriteValuesToDataRow()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      get
      {
        return "";
      }
      // string PostalCode (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 10
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrPostalCode becomes strValue
        //   - If not
        //     - mstrPostalCode becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomerTryout(cpKeyCustomerTryout, string)
        //   - frmCustomerValidationBetterTryout.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetterTryout.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // PostalCode(string) (Set)

    }
    // string PostalCode Implements cpiCustomerTryout.PostalCode

    public string Region
    {

      get
        //***
        // Action Get
        //   - Return 'mstrRegion'
        // Called by
        //   - bool Save() Implements cpiCustomerTryout.Save 
        //   - frmCustomerValidationBetterTryout.CustomerProperties()
        //   - string ToString() Implements cpiCustomerTryout.ToString
        //   - WriteValuesToDataRow()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string Region (Get)

      set
        //***
        // Action
        //   - If Validation is true
        //     - If length of strValue > 10
        //       - Throw new cpInvalidStringLengthException with correct info
        //     - If not
        //       - mstrRegion becomes strValue
        //   - If not
        //     - mstrRegion becomes strValue
        // Called by
        //   - Clear()
        //   - cpCustomerTryout(cpKeyCustomerTryout, string)
        //   - frmCustomerValidationBetterTryout.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
        //   - frmCustomerValidationBetterTryout.TextBoxChange(string, string)
        //   - ReadValuesFromDataRow()
        //   - WriteValuesToDataRow()
        // Calls
        //   - bool Validation (Get)
        //   - cpInvalidStringLengthException(System.Int32, string, string)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // Region(string) (Set)

    }
    // string Region Implements cpiCustomerTryout.Region

    public bool Validation
    {

      get
        //***
        // Action Get
        //   - Return 'mblnValidation'
        // Called by
        //   - Address(string) (Set)
        //   - City(string) (Set) 
        //   - CompanyName(string) (Set)
        //   - ContactName(string) (Set)
        //   - ContactTitle(string) (Set)
        //   - Country(string) (Set)
        //   - mtheFax_StringValueBeforeUpdate(string, °bool) Handles mtheFax.StringValueBeforeUpdate
        //   - mthePhone_StringValueBeforeUpdate(string, °bool) Handles mthePhone.StringValueBeforeUpdate
        //   - PostalCode(string) (Set)
        //   - Region(string) (Set)
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return false;
      }
      // bool Validation (Get)

      set
        //***
        // Action
        //   - mblnValidation becomes blnValue
        // Called by
        //   - frmCustomerValidationBetterTryout()
        //   - frmCustomerValidationBetterTryout.cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // Validation(bool) (Set)

    }
    // bool Validation

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Create the default return value of a cpCustomer
      // Called by
      //   - frmCustomerValidationBetterTryout.TextBoxChange(string, string)
      // Calls
      //   - cpCheckPhoneNumber Fax (Get)
      //   - cpCheckPhoneNumber Phone (Get)
      //   - cpKeyCustomer IdCustomer (Get)
      //   - string Address (Get)
      //   - string City (Get)
      //   - string CompanyName (Get)
      //   - string ContactName (Get)
      //   - string ContactTitle (Get)
      //   - string Country (Get)
      //   - string cpCheckPhoneNumber.StringValue (Get)
      //   - string cpKeyCustomer.KeyCustomer (Get)
      //   - string PostalCode (Get)
      //   - string Region (Get)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return "";
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private void mtheFax_StringValueBeforeUpdate(string strFaxNumber, out bool blnCancel)
      //***
      // Action
      //   - If Validation is true
      //     - If length of fax number is larger than 24
      //       - Set cancel to true
      //       - Throw an invalid string length exception with information
      //     - If not
      //       - Set cancel to false
      //   - If not
      //     - Set cancel to false
      // Called by
      //   - 
      // Calls
      //   - bool Validation (Get)
      //   - cpInvalidStringLenghtException(System.Int32, string, string)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      blnCancel = false;
    }
    // mtheFax_StringValueBeforeUpdate(string, °bool)

    private void mtheIdCustomer_StringValueBeforeUpdate(string strKeyCustomer, out bool blnCancel)
      //***
      // Action
      //   - Set cancel to true
      // Called by
      //   - cpKeyCustomerTryout.StringValueBeforeUpdate(string, °bool)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      blnCancel = false;
    }
    // mtheIdCustomer_BeforeUpdate(string, °bool) Handles mtheIdCustomer.BeforeUpdate

    private void mthePhone_StringValueBeforeUpdate(string strPhoneNumber, out bool blnCancel)
      //***
      // Action
      //   - If Validation is true
      //     - If length of fax number is larger than 24
      //       - Set cancel to true
      //       - Throw an invalid string length exception with information
      //     - If not
      //       - Set cancel to false
      //   - If not
      //     - Set cancel to false
      // Called by
      //   - 
      // Calls
      //   - bool Validation (Get)
      //   - cpInvalidStringLenghtException(System.Int32, string, string)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      blnCancel = false;
    }
    // mthePhone_StringValueBeforeUpdate(string, °bool)

    #endregion

    #region "Sub / Function"

    private void Clear()
      //***
      // Action
      //   - Set the data row of the customer to nothing
      //   - Clear the data set of the customer to nothing
      //   - Set the unique key of the customer to nothing
      //   - Clear all properties
      //     - Address
      //     - City
      //     - CompanyName
      //     - ContactName
      //     - ContactTitle
      //     - Country
      //     - Fax
      //     - Phone
      //     - PostalCode
      //     - Region
      // Called by
      //   - bool Delete() Implements cpiCustomerTryout.Delete
      // Calls
      //   - Address(string) (Set)
      //   - City(string) (Set)
      //   - CompanyName(string) (Set)
      //   - ContactName(string) (Set)
      //   - ContactTitle(string) (Set)
      //   - Country(string) (Set)
      //   - Fax(cpCheckPhoneNumber) (Set)
      //   - IdCustomer(cpCheckString) (Set)
      //   - Phone(cpCheckPhoneNumber) (Set)
      //   - PostalCode(string) (Set)
      //   - Region(string) (Set)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // Clear()

    public bool Delete()
      //***
      // Action
      //   - Define a result value
      //   - If you are busy adding a new customer
      //     - Clear the information
      //     - Set return value to true
      //   - If not
      //     - Delete the data row of the customer
      //     - Write the changes to the database
      //     - If successful
      //       - Clear the information
      //       - Set return value to true
      //     - If not
      //       - Reject the changes of the customer data row
      //       - Set return value to false
      //   - Return result
      // Called by
      //   - frmCustomerValidationBetterTryout.cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click
      // Calls
      //   - bool WriteChangesToDatabase(DataRowState)
      //   - Clear()
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return false;
    }
    // bool Delete() Implements cpiCustomer.Delete

    private void ReadValuesFromDataRow()
      //***
      // Action
      //   - Set values from Customer Data Row into cpCustomer
      //   - mstrIdCustomer becomse strIdCustomer
      //   - CompanyName becomes strCompanyName
      //   - Do routine for strAddress, strCity, strContactName, strContactTitle,
      //     - strCountry, strFax, strPhone, strPostalCode, strRegion)
      //   - Routine:
      //     - If strXxx Is null Then
      //       - Property becomes empty string
      //     - If not
      //       - Property becomes strXxx
      // Called by
      //   - cpCustomerTryout(string)
      // Calls
      //   - Address(string) (Set)
      //   - City(string) (Set)
      //   - CompanyName(string) (Set)
      //   - ContactName(string) (Set)
      //   - ContactTitle(string) (Set)
      //   - Country(string) (Set)
      //   - cpCheckPhoneNumber(string)
      //   - cpCheckString.StringValue(string) (Set)
      //   - cpKeyCustomer(string)
      //   - cpKeyCustomer.KeyCustomer(string) (Set)
      //   - Fax(cpCheckPhoneNumber) (Set)
      //   - Phone(cpCheckPhoneNumber) (Set)
      //   - PostalCode(string) (Set)
      //   - Region(string) (Set)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // ReadValuesFromDataRow()

    public bool Save()
      //***
      // Action
      //   - Define a row state
      //   - If blnNew
      //     - Set the data row of customer an added row to the data set
      //     - Put the state to added
      //     - Set blnNew to false
      //   - If not
      //     - Set the state to modified
      //   - Try to
      //     - Start editing the data row
      //     - Write the values to the data row
      //     - Stop editing the data row
      //     - Write the changes to the data base
      //     - If successful
      //       - Set return value to true
      //     - If not
      //       - Reject the changes of the data row
      //       - Set return value to false
      //   - When error occurs
      //     - Cancel editing the data row
      //     - Reject the changes of the data row
      //     - Set return value to false
      //   - Return result
      // Called by
      //   - frmCustomerValidationBetterTryout.cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      //   - WriteChangesToDatabase(DataRowState)
      //   - WriteValuesToDataRow()
      // Calls
      //   - cpCheckPhoneNumber Fax (Get)
      //   - cpCheckPhoneNumber Phone (Get)
      //   - cpKeyCustomer IdCustomer (Get)
      //   - string Address (Get)
      //   - string City (Get)
      //   - string CompanyName (Get)
      //   - string ContactName (Get)
      //   - string ContactTitle (Get)
      //   - string Country (Get)
      //   - string cpCheckString.StringValue (Get)
      //   - string PostalCode (Get)
      //   - string Region (Get)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return false;
    }
    // bool Save() Implements cpiCustomerTryout.Save

    private bool WriteChangesToDatabase(DataRowState theDataRowState)
      //'***
      //' Action
      //'   - Define a return value
      //'   - Try to
      //'     - Define and set a dataset with the changes of the customer data set
      //'     - Update the changes using the data adapter
      //'     - Accept the changes of the customer data set
      //'     - Return value becomes true
      //'   - When error occurs
      //'     - Reject the changes of the customer data set
      //'     - Return value becomes false
      //' Called by
      //'   - bool Delete() Implements cpiCustomerTryout.Delete
      //'   - bool Save() Implements cpiCustomerTryout.Save
      //' Calls
      //'   - 
      //' Created
      //'   - CopyPaste – 20050508 – VVDW
      //' Changed
      //'   - CopyPaste – yyyymmdd – VVDW – What changed
      //' Tested
      //'   - CopyPaste – 20050508 – VVDW
      //' Keyboard key
      //'   -
      //' Proposal (To Do)
      //'   -
      //'***
    {
      return false;
    }
    // WriteChangesToDatabase(DataRowState)

    private void WriteValuesToDataRow()
      //***
      // Action
      //   - Write property values from instance to data row
      //     - strCompanyName becomes CompanyName 
      //   - Do routine for Address, City, ContactName, ContactTitle,
      //     - Country, Fax, Phone, PostalCode, Region)
      //   - Routine:
      //   - If Xxx.Length = 0 Then
      //     - Property becomes null
      //   - If not
      //     - Property becomes Xxx
      // Called by
      //   - bool Save() Implements cpiCustomerTryout.Save
      // Calls
      //   - cpCheckPhoneNumber Fax (Get)
      //   - cpCheckPhoneNumber Phone (Get)
      //   - string Address (Get)
      //   - string City (Get)
      //   - string CompanyName (Get)
      //   - string ContactName (Get)
      //   - string ContactTitle (Get)
      //   - string Country (Get)
      //   - string cpCheckPhoneNumber.StringValue (Get)
      //   - string PostalCode (Get)
      //   - string Region (Get)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // WriteValuesToDataRow()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCustomerTryout

}
// CopyPaste.Learning