//***
// Action
//   - Do the conversion from Celcius to Fahrenheit
// Created
//   - CopyPaste � 20240426 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240426 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Set an average temperature to 36.6 degrees Celcius
      //   - Calculate the templerature in Fahrenheit
      //   - Show the results
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      const float fltAverageTemperatureCelcius = 36.6F;
      float fltAverageTemperatureFahrenheit;

      fltAverageTemperatureFahrenheit = fltAverageTemperatureCelcius * 9 / 5 + 32;

      Console.WriteLine("Average temperature in Celcius: {0}", fltAverageTemperatureCelcius);
      Console.WriteLine("Average temperature in Fahrenheit: {0}", fltAverageTemperatureFahrenheit);
      Console.WriteLine();
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning