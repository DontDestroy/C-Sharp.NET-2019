﻿//***
// Action
//   - Reading and writing a text in several ways
// Created
//   - CopyPaste – 20230408 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20230408 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ReadWrite_WPF
{

  public partial class wpfReadWrite : Window
  {

    #region "Constructors / Destructors"

    public wpfReadWrite()
    //***
    // Action
    //   - Create instance of 'wpfReadWrite'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230408 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230408 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfReadWrite

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void wndStartup_Initialized(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Show the WPF form
    //   - Set the font of txtText
    //   - Write and read textfile with IO
    //   - Write and read textfile with streams (put in comment)
    // Called by
    //   - User action (starting the form)
    // Calls
    //   - TestFileIO()
    //   - TestStreams()
    // Created
    //   - CopyPaste – 20230408 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20230408 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      txtText.FontFamily = new FontFamily("Times New Roman");
      txtText.FontSize = 12;
      TestFileIO();
      // TestStreams();
    }
    // wndStartup_Initialized(System.Object, System.EventArgs) Handles wndStartup.Initialized

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void TestFileIO()
    //***
    // Action
    //   - Set a filename (strFileName)
    //   - Determine the first free file number (lngFileNumber)
    //   - Open the file for Output and Write
    //   - Write several lines
    //   - Close the file
    //   - Determine the first free file number (lngFileNumber)
    //   - Open the file for Input and Read
    //   - Loop until end of file
    //     - strInputLine become the next line
    //     - strInputText is concatenated with strInputLine
    //   - Close the file
    //   - Show the text on the screen
    //   - Set cursor before first position
    // Called by
    //   - wpfReadWrite_Initialize(System.Object, System.EventArgs) Handles wpfReadWrite.Initialize
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230408 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20230408 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int lngFileNumber;
      string strFileName;
      string strInputLine;
      string strInputText = "";

      strFileName = Directory.GetCurrentDirectory() + "\\ReadWrite.txt";
      lngFileNumber = FileSystem.FreeFile();
      FileSystem.FileOpen(lngFileNumber, strFileName, OpenMode.Output, OpenAccess.Write, OpenShare.Shared, 100);

      FileSystem.WriteLine(lngFileNumber, "Once upon a time, a girl by the name of Danielle");
      FileSystem.WriteLine(lngFileNumber, "loved to read Utopia. Her evil stepmother treated");
      FileSystem.WriteLine(lngFileNumber, "her badly. But then the crowned prince of France");
      FileSystem.WriteLine(lngFileNumber, "fell in love with Danielle, and they were married.");
      FileSystem.WriteLine(lngFileNumber, "Her evil stepmother, meanwhile, was put to work.");

      FileSystem.FileClose(lngFileNumber);

      lngFileNumber = FileSystem.FreeFile();
      FileSystem.FileOpen(lngFileNumber, strFileName, OpenMode.Input, OpenAccess.Read, OpenShare.Shared, 100);

      while (!FileSystem.EOF(lngFileNumber))
      {
        strInputLine = FileSystem.LineInput(lngFileNumber);
        strInputText += strInputLine.Substring(1, strInputLine.Length - 2) + ControlChars.NewLine;
      }

      // FileSystem.EOF(lngFileNumber)

      FileSystem.FileClose(lngFileNumber);

      txtText.Text = "Testing File I/O..." + ControlChars.NewLine;
      txtText.Text += "-------------------" + ControlChars.NewLine;
      txtText.Text += strInputText;
    }
    // TestFileIO()

    private void TestStreams()
    // Action
    //   - Set a filename (strFileName)
    //   - strWriter becomes a StreamWriter
    //   - Write several lines
    //   - Close the StreamWriter
    //   - strReader becomes a StreamReader
    //   - Read the complete text
    //   - Show the text on the screen
    //   - Close the file
    //   - Set cursor before first position
    // Called by
    //   - wpfReadWrite_Initialize(System.Object, System.EventArgs) Handles wpfReadWrite.Initialize
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230408 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20230408 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      string strFileName;
      string strInputText;
      StreamReader strReader;
      StreamWriter strWriter;

      strFileName = Directory.GetCurrentDirectory() + "\\ReadWrite.txt";

      strWriter = new StreamWriter(strFileName);
      strWriter.WriteLine("Once upon a time, a girl by the name of Danielle");
      strWriter.WriteLine("loved to read Utopia. Her evil stepmother treated");
      strWriter.WriteLine("her badly. But then the crowned prince of France");
      strWriter.WriteLine("fell in love with Danielle, and they were married.");
      strWriter.WriteLine("Her evil stepmother, meanwhile, was put to work.");

      strWriter.Close();

      strReader = new StreamReader(strFileName);
      strInputText = strReader.ReadToEnd();
      txtText.Text += "Testing Streams..." + ControlChars.NewLine;
      txtText.Text += "------------------" + ControlChars.NewLine;
      txtText.Text += strInputText;
    }
    // TestStreams()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfReadWrite

}
// ReadWrite_WPF