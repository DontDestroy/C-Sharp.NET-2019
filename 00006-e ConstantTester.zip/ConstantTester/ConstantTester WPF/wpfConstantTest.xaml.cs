﻿//***
// Action
//   - Show Pi into control on WPF form
// Created
//   - CopyPaste – 20220812 – VVDW
// Changed
//   - - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220812 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ConstantTester_WPF
{

  public partial class wpfConstantTest : Window
  {

    #region "Constructors / Destructors"

    public wpfConstantTest()
    //***
    // Action
    //   - Create instance of 'wpfConstantTest'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220812 – VVDW
    // Changed
    //   - - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220812 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfConstantTest()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdExit_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Exit the program
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220812 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220812 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      this.Close();
    }
    // cmdExit_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdExit.Click


    private void cmdShow_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Assign Pi to a Double variable
    //   - Label.Content becomes the the value of the Double variable
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - string System.Convert.ToString(Double)
    // Created
    //   - CopyPaste – 20220111 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220111 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      const double dblPi = 3.14159265;

      lblResult.Content = Convert.ToString(dblPi);
    }
    // cmdShow_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdShow.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfConstantTest 

}
// ConstantTester_WPF