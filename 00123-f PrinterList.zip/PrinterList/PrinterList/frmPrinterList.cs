//***
// Action
//   - Showing the list of printers
// Created
//   - CopyPaste � 20240719 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240719 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPrinter: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtResult;
    internal System.Windows.Forms.Button cmdPrinter;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPrinter));
      this.txtResult = new System.Windows.Forms.TextBox();
      this.cmdPrinter = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(21, 80);
      this.txtResult.Multiline = true;
      this.txtResult.Name = "txtResult";
      this.txtResult.Size = new System.Drawing.Size(250, 150);
      this.txtResult.TabIndex = 3;
      this.txtResult.Text = "";
      // 
      // cmdPrinter
      // 
      this.cmdPrinter.Location = new System.Drawing.Point(105, 32);
      this.cmdPrinter.Name = "cmdPrinter";
      this.cmdPrinter.TabIndex = 2;
      this.cmdPrinter.Text = "List Printers";
      this.cmdPrinter.Click += new System.EventHandler(this.cmdPrinter_Click);
      // 
      // frmPrinter
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.txtResult);
      this.Controls.Add(this.cmdPrinter);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPrinter";
      this.Text = "PrinterList";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPrinter'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPrinter()
      //***
      // Action
      //   - Create instance of 'frmPrinter'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdPrinter_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a new line
      //   - Loop thru the installed printers
      //     - Append the printername to a textbox
      //     - Append a new line to a textbox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   -
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      string strCrLf = Environment.NewLine;

      txtResult.Text = "";

      foreach (string strPrinterName in PrinterSettings.InstalledPrinters)
      {
        txtResult.AppendText(strPrinterName);
        txtResult.AppendText(strCrLf);
      }
      // In PrinterSettings.InstalledPrinters
    
    }
    // cmdPrinter_Click(System.Object, System.EventArgs) Handles cmdPrinter.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPrinter
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmPrinter()
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPrinter());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPrinter

}
// CopyPaste.Learning