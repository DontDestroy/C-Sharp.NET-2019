﻿//***
// Action
//   - A definition of a SpyRobot
// Created
//   - CopyPaste – 20251028 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251028 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using java.util;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpSpyRobot : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpSpyRobot(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor, cpinfStrategy theInitialStrategy) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpSpyRobot starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Assignment of the strategy by theInitialStrategy
    // Called by
    //   - cpProgram.Decorator()
    //   - cpProgram.Enumeration()
    //   - cpSpyRobot(int, int, Directions.Direction, int, cpinfStrategy) 
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      myStrategy = theInitialStrategy;
    }
    // cpSpyRobot(int, int, Directions.Direction, int, Color, cpinfStrategy) 

    public cpSpyRobot(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, cpinfStrategy theInitialStrategy) : this(intStreet, intAvenue, theDirection, intBeepers, null, theInitialStrategy)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpAccompliceRobot starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpSpyRobot(int, int, Directions.Direction, int, Color, cpinfStrategy) 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpSpyRobot(int, int, Directions.Direction, int, cpinfStrategy) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpinfStrategy myStrategy = new cpNullStrategy();

    #endregion

    #region "Properties"

    public cpinfStrategy Strategy
    {

      get
      //***
      // Action get
      //   - return myStrategy
      // Called by
      //   -
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251028 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251028 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return myStrategy;
      }
      // cpinfStrategy Strategy (Get)

    }
    // cpinfStrategy Strategy


    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void FollowStrategy()
    //***
    // Action
    //   - Execute the strategy
    // Called by
    //   - cpProgram.Decorator()
    //   - cpProgram.Enumeration()
    // Calls
    //   - cpinfStrategy.DoIt(cpCopyPasteRobot)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      myStrategy.DoIt(this); // Leaves you at the next accomplice
    }
    // FollowStrategy()

    public void GetNextClue()
    //***
    // Action
    //   - Precondition: Robot must be on a corner with another robot
    //   - Get a list of the neightbours (robots at same loation)
    //   - Take the next element and this become the accomplice (a casting is executed)
    //   - The strategy of the spy becomes the strategy of the accomplice
    //   - The accomplice is turned off
    // Called by
    //   - cpProgram.Decorator()
    //   - cpProgram.Enumeration()
    // Calls
    //   - cpinfStrategy cpAccompliceRobot.Strategy (Get)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Enumeration neighbours = neighbors();
      cpAccompliceRobot accomplice = (cpAccompliceRobot)neighbours.nextElement();
      myStrategy = accomplice.Strategy;
      accomplice.turnOff();
    }
    // GetNextClue()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpSpyRobot

}
// cpKarelTheRobot