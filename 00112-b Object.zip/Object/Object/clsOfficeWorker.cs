//***
// Action
//   - Implementation of a cpOfficeWorker
//   - Inherits from cpEmployee
// Created
//   - CopyPaste � 20240405 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240405 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpOfficeWorker : cpEmployee
  {

    #region "Constructors / Destructors"

    public cpOfficeWorker(string strName) : base(strName)
      //***
      // Action
      //   - Constructor with Name
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee(string)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpOfficeWorker(string)
 
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override void ShowInfo()
      //***
      // Action
      //   - Shows information to the console
      //     - OfficeWorker + Name
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - string cpEmployee.Name (Get)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Officeworker - Name: {0}", Name);
    }
    // ShowInfo()

    public override string ToString()
      //***
      // Action
      //   - Returns the Name and that the person is an officeworker
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - string cpEmployee.Name (Get)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Name + " is an officeworker.";
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpOfficeWorker

}
// CopyPaste.Learning.Employee