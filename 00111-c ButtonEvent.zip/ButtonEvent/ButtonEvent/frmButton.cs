//***
// Action
//   - Demo of a form, creating a button not on design but with code
// Created
//   - CopyPaste � 20240305 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240305 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmButton: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdButton;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmButton));
      this.cmdButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdButton
      // 
      this.cmdButton.Location = new System.Drawing.Point(64, 56);
      this.cmdButton.Name = "cmdButton";
      this.cmdButton.TabIndex = 1;
      this.cmdButton.Text = "Button1";
      this.cmdButton.Click += new System.EventHandler(this.cmdButton_Click);
      // 
      // frmButton
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdButton);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmButton";
      this.Text = "Button Form";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmButton'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240305 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240305 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmButton()
      //***
      // Action
      //   - Create instance of 'frmButton'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240305 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240305 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmButton()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdButton_Click(System.Object theSender, System.EventArgs theEventArguments)
      //'***
      //' Action
      //'   - Create a new button from scratch (not by the design of the form)
      //'   - Add the created button to the list of controls
      //'   - Add a handler to the created button
      //'   - Remove a handler from the button (in comments)
      //' Called by
      //'   - User action (Clicking the button)
      //' Calls
      //'   - theNewButton_Click(System.Object, System.EventArgs)
      //' Created
      //'   - CopyPaste � 20240305 � VVDW
      //' Changed
      //'   - CopyPaste � yyyymmdd � VVDW � What changed
      //' Tested
      //'   - CopyPaste � 20240305 � VVDW
      //' Keyboard key
      //'   - 
      //' Proposal (To Do)
      //'   - 
      //'***
    {
      Button theNewButton = new Button();

      this.Controls.Add(theNewButton);

      theNewButton.Click += new EventHandler(theNewButton_Click);
      // theNewButton.Click -= new EventHandler(theNewButton_Click);
    }
    // cmdButton_Click(System.Object, System.EventArgs) Handles cmdButton.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void theNewButton_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show how many controls (in this case buttons) there are on the form
      // Called by
      //   - cmdButton_Click(System.Object, System.EventArgs) Handles cmdButton.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240305 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240305 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show(string.Format("There are {0} buttons on the screen", Controls.Count), "You clicked the new button!");
    }
    // theNewButton_Click(System.Object, System.EventArgs)

    static public void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmButton
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240305 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240305 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmButton());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmButton

}
// CopyPaste.Learning