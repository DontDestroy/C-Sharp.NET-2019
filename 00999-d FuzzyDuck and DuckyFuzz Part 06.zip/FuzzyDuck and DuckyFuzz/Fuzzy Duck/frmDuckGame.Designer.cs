﻿//***
// Action
//   - Design of the Startup screen of the duck game
// Created
//   - CopyPaste – 20240717 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240717 – VVDW
// Proposal (To Do)
//   - 
//***

namespace CopyPaste.Game.Duck
{
	partial class frmDuckGame
	{
		/// <summary>
		///  Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		#region Windows Form Designer generated code

		/// <summary>
		///  Required method for Designer support - do not modify
		///  the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDuckGame));
			picImage = new PictureBox();
			cmbChooseDuck = new ComboBox();
			lblErrorMessage = new Label();
			((System.ComponentModel.ISupportInitialize)picImage).BeginInit();
			SuspendLayout();
			// 
			// picImage
			// 
			picImage.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
			picImage.Location = new Point(214, 12);
			picImage.Name = "picImage";
			picImage.Size = new Size(574, 426);
			picImage.SizeMode = PictureBoxSizeMode.Zoom;
			picImage.TabIndex = 0;
			picImage.TabStop = false;
			// 
			// cmbChooseDuck
			// 
			cmbChooseDuck.FormattingEnabled = true;
			cmbChooseDuck.Location = new Point(12, 12);
			cmbChooseDuck.Name = "cmbChooseDuck";
			cmbChooseDuck.Size = new Size(187, 23);
			cmbChooseDuck.TabIndex = 1;
			cmbChooseDuck.SelectedIndexChanged += cmbChooseDuck_SelectedIndexChanged;
			// 
			// lblErrorMessage
			// 
			lblErrorMessage.AutoSize = true;
			lblErrorMessage.Location = new Point(12, 47);
			lblErrorMessage.Name = "lblErrorMessage";
			lblErrorMessage.Size = new Size(0, 15);
			lblErrorMessage.TabIndex = 2;
			// 
			// frmDuckGame
			// 
			AutoScaleDimensions = new SizeF(7F, 15F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(800, 450);
			Controls.Add(lblErrorMessage);
			Controls.Add(cmbChooseDuck);
			Controls.Add(picImage);
			Icon = (Icon)resources.GetObject("$this.Icon");
			Name = "frmDuckGame";
			Text = "Copy Paste Fuzzy Duck Game";
			((System.ComponentModel.ISupportInitialize)picImage).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private PictureBox picImage;
		private ComboBox cmbChooseDuck;
		private Label lblErrorMessage;
	}
	// frmDuckGame

}
// CopyPaste.Game.Duck
