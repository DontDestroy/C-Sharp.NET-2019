﻿//***
// Action
//   - Definition of a cpOfficeWorker (inherits from cpEmployee)
//     - Has a name (inherited)
//     - An office worker can log some maintenance of a cpCopyMachine
// Created
//   - CopyPaste – 20250716 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250716 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Material;
using System;

namespace CopyPaste.Learning
{

  namespace Personnel
  {

    public class cpOfficeWorker : cpEmployee
    {

      #region "Constructors / Destructors"

      public cpOfficeWorker(string strName): base(strName)
        //***
        // Action
        //   - Constructor with a given name
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - cpOfficeWorker(string)
        // Created
        //   - CopyPaste – 20250716 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250716 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // cpOfficeWorker(string)

      #endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      //#region "Fields"
      //#endregion

      //#region "Properties"
      //#endregion

      #region "Methods"

      //#region "Overrides"
      //#endregion

      //#region "Controls"
      //#endregion

      #region "Functionality"

      //#region "Event"
      //#endregion

      #region "Sub / Function"

      public override void DoMaintenance(cpCopyMachine cpErrorMachine)
        //***
        // Action
        //   - On a given machine there is a maintenance
        //   - Show who is logging something in the log of the machine
        // Called by
        //   - cpProgram.Main() (thru delegate)
        // Calls
        //   - string Name() (Get)
        // Created
        //   - CopyPaste – 20250716 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250716 – VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        Console.WriteLine("{0} writes down in log of machine", Name);
      }
      // DoMaintenance(cpCopyMachine)

      #endregion

      #endregion

      #endregion

      //#region "Not used"
      //#endregion

    }
    // cpOfficeWorker

  }
  // Personnel

}
// CopyPaste.Learning