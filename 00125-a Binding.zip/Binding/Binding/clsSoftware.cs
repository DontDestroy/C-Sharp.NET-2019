//***
// Action
//   - Implementation of cpSoftware
// Created
//   - CopyPaste � 20240710 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240710 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpSoftware
  {

    #region "Constructors / Destructors"

    public cpSoftware()
      //***
      // Action
      //   - Default constructor
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpSoftware()

    public cpSoftware(string strName, string strProgrammer, string strCompany, double dblPrice)
      //***
      // Action
      //   - Basic constructor with a given Name, Programmer, Company and Price
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrName = strName;
      mstrProgrammer = strProgrammer;
      mstrCompany = strCompany;
      mdblPrice = dblPrice;
    }
    // cpSoftware(string, string, string, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public double mdblPrice;
    public string mstrCompany;
    public string mstrName;
    public string mstrProgrammer;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ShowProgrammer()
      //***
      // Action
      //   - Show Programmer of the cpSoftware
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Programmer: " + mstrProgrammer);
    }
    // ShowAuthor()

    public void ShowValues()
      //***
      // Action
      //   - Show values of the cpSoftware
      // Called by
      //   - cpProgram.LateBinding(System.Object)
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Name: " + mstrName);
      Console.WriteLine("Programmer: " + mstrProgrammer);
      Console.WriteLine("Company: " + mstrCompany);
      Console.WriteLine("Price: " + mdblPrice);
    }
    // ShowValues()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpSoftware

}
// CopyPaste.Learning