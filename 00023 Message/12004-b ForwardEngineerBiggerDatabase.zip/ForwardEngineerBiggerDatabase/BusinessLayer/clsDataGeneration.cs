﻿//***
// Action
//   - Routines for generating random data in the forward engineered database
//   - Fill the database with random generated data
//   - All queries and screens depends on the content of the database
//   - Results will be different every time you regenerate the database
//   - Results will be different every time you refill the data the database
// Created
//   - CopyPaste – 20230717 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230717 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.BusinessObjects;
using CopyPaste.DataAccess;
using CopyPaste.Toolkit;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CopyPaste.BusinessLayer
{

  public class cpDataGeneration
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    static string[] arrstrAirports =
      {"Berlin", "Brussels", "Chicago", "Dallas", "Frankfurt", "Hamburg", "Kaapstad", "London", "Madrid", "Milan", "Moscow", "Munich", "New York", "Paris", "Prague", "Rome", "Seattle", "Vienna" };
    static string[] arrstrFirstNames =
      {"Albert", "Alois", "Ann", "Anna", "Astrid", "August", "Bernadette", "Bjorn", "Carl", "Diederik", "Dries", "Ellen", "Elvire", "Ernest", "Goedele", "Gertrude", "Hannah", "Hilde", "Isabelle", "Jan", "Jowan", "Jules", "Karel", "Koen", "Leon", "Liesbeth", "Lieven", "Lukas", "Marie", "Martijn", "Pedro", "Peter", "Prosper", "Roberto", "Roger", "Vincent", "Walter", "Wim", "Xavier"};
    static string[] arrstrFirstNameForPilots =
      {"Alex", "Angela", "Axel", "Bianca", "Christian", "Christine", "Frank", "Gregor", "Julia", "Martin", "Pierre", "Roland", "Stella", "Valerie", "Victor", "Virginie",};
    static string[] arrstrLastNames =
      {"Aerts", "Bertrand", "Callewaert", "Campenaerts", "Claes", "Claeys", "De Clercq", "De Smet", "De Vos", "Demispelaere", "Deprez", "Desmet", "Devos", "Dubois", "Dupont", "Goossens", "Hendrickx", "Hermans", "Jacobs", "Janssen", "Janssens", "Lambert", "Maes", "Martens", "Mertens", "Michiels", "Pauwels", "Peeters", "Smets", "Stevens", "Van Aert", "Van Damme", "Vermeulen", "Willems", "Wouters", "Wuyts", "Wijns" };
    static string[] arrstrLastNameForPilots =
      {"Bogaerts", "Carlier", "Fontaine", "Jansen", "Michel", "Noël", "Van De Walle", "Van Dommelen", "Van Dyck", "Willaert"};
    static Random theRandom = new Random(DateTime.Now.Millisecond);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void CreateAircraftTypeDetails(cpWingsContext theDatabaseContext)
    //***
    // Action
    //   - Try to add 2 CreateAircraftTypeDetails (if there are none)
    //     - Create a new CreateAircraftTypeDetail
    //     - Add AircraftTypeDetails to the list of CreateAircraftTypeDetails in the context
    //   - Save all changes
    // Called by
    //   - SeedData(cpWingsContext, bool = false, bool = false, int = 0, int = 0, int = 0)
    // Calls
    //   - AircraftTypeDetail()
    //   - AircraftTypeDetail.AircraftTypeId(byte) (Set)
    //   - AircraftTypeDetail.Length(string) (Set)
    //   - AircraftTypeDetail.Tare(string) (Set)
    //   - AircraftTypeDetail.TurbineCount(string) (Set)
    //   - cpConsole.PrintWarning(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DbSet<AircraftTypeDetail> cpWingsContext.AircraftTypeDetail (Get)
    // Created
    //   - CopyPaste – 20230717 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230717 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (theDatabaseContext.AircraftTypeDetail.Any())
      {
        cpConsole.PrintWarning("There are already aircrafttypedetails in the database, none are added ...");
      }
      else
      // Not theDatabaseContext.AircraftTypeDetail.Any()
      {
        cpConsole.PrintWithTime("Start AircraftTypeDetail Generation ...");

        AircraftTypeDetail theFirstAircraftTypeDetail = new AircraftTypeDetail() { AircraftTypeId = 1, Length = 72.3f, Tare = 277, TurbineCount = 4 }; // Airbus 380-800
        AircraftTypeDetail theSecondAircraftTypeDetail = new AircraftTypeDetail() { AircraftTypeId = 2,Length = 31.06f, Tare = 61, TurbineCount = 2 }; // Boeing 737-500

        theDatabaseContext.AircraftTypeDetail.Add(theFirstAircraftTypeDetail);
        theDatabaseContext.AircraftTypeDetail.Add(theSecondAircraftTypeDetail);

        theDatabaseContext.SaveChanges();
        cpConsole.PrintWithTime("... AircraftTypeDetail Generation Finished");
      }
      // theDatabaseContext.AircraftTypeDetail.Any()

    }
    // CreateAircraftTypeDetails(cpWingsContext)

    public static void CreateAircraftTypes(cpWingsContext theDatabaseContext)
    //***
    // Action
    //   - Try to add 2 AircraftTypes (if there are none)
    //     - Create a new AircraftType
    //     - Add AircraftType to the list of AircraftTypes in the context
    //   - Save all changes
    // Called by
    //   - SeedData(cpWingsContext, bool = false, bool = false, int = 0, int = 0, int = 0)
    // Calls
    //   - AircraftType()
    //   - AircraftType.TypeId(byte) (Set)
    //   - AircraftType.Name(string) (Set)
    //   - AircraftType.Manufacturer(string) (Set)
    //   - cpConsole.PrintWarning(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DbSet<AircraftType> cpWingsContext.AircraftType (Get)
    // Created
    //   - CopyPaste – 20230717 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230717 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (theDatabaseContext.AircraftType.Any())
      {
        cpConsole.PrintWarning("There are already aircrafttypes in the database, none are added ...");
      }
      else
      // Not theDatabaseContext.AircraftType.Any()
      {
        cpConsole.PrintWithTime("Start AircraftType Generation ...");

        AircraftType theFirstAircraftType = new AircraftType() { TypeId = 1, Manufacturer = "Airbus", Name = "A380-800" }; // maximum 853 passengers
        AircraftType theSecondAircraftType = new AircraftType() { TypeId = 2, Manufacturer = "Boeing", Name = "737-500" }; // maximum 140 passengers

        theDatabaseContext.AircraftType.Add(theFirstAircraftType);
        theDatabaseContext.AircraftType.Add(theSecondAircraftType);

        theDatabaseContext.SaveChanges();
        cpConsole.PrintWithTime("... AircraftType Generation Finished");
      }
      // theDatabaseContext.AircraftType.Any()

    }
    // CreateAircraftTypes(cpWingsContext)

    public static void CreateAirlines(cpWingsContext theDatabaseContext)
    //***
    // Action
    //   - Try to add 2 Airlines (if there are none)
    //     - Create a new Airline
    //     - Add Airline to the list of airlines in the context
    //   - Save all changes
    // Called by
    //   - SeedData(cpWingsContext, bool = false, bool = false, int = 0, int = 0, int = 0)
    // Calls
    //   - Airline()
    //   - Airline.Code(string) (Set)
    //   - Airline.Name(string) (Set)
    //   - cpConsole.PrintWarning(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DbSet<Airline> cpWingsContext.Airline (Get)
    // Created
    //   - CopyPaste – 20230717 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230717 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (theDatabaseContext.Airline.Any())
      {
        cpConsole.PrintWarning("There are already airlines in the database, none are added ...");
      }
      else
      // Not theDatabaseContext.Airline.Any()
      {
        cpConsole.PrintWithTime("Start Airline Generation ...");

        Airline theFirstAirline = new Airline() { Code = "CPW", Name = "Copy Paste Wings" };
        Airline theSecondAirline = new Airline() { Code = "NBC", Name = "Never Come Back Airline" };

        theDatabaseContext.Airline.Add(theFirstAirline);
        theDatabaseContext.Airline.Add(theSecondAirline);

        theDatabaseContext.SaveChanges();
        cpConsole.PrintWithTime("... Airline Generation Finished");
      }
      // theDatabaseContext.Airline.Any()

    }
    // CreateAirlines(cpWingsContext)

    public static void CreateBookings(cpWingsContext theDatabaseContext)
    //***
    // Action
    //   - Create a list of random Bookings
    //   - Create a list of all existing flights
    //   - Create a list of all existing passengers
    //   - Loop thru all the flights
    //     - Calculate how many seats that are occupied (theAmount)
    //     - Calculate how many bookings there are (theNumberOfBookings)
    //     - If not enough bookings
    //       - Delete all the bookings for that flight
    //       - Assign the next 'theAmount' passengers to that flight by creating a booking for that flight
    //     - Show every 997 an added booking
    //   - Save all changes
    // Called by
    //   - CreateTestData(cpWingsContext)
    // Calls
    //   - Booking()
    //   - Booking.Flight(Flight) (Set)
    //   - Booking.Passenger(Passenger) (Set)
    //   - cpConsole.PrintSuccess(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DbSet<Booking> cpWingsContext.Booking (Get)
    //   - DbSet<Flight> cpWingsContext.Flight (Get)
    //   - DbSet<Passenger> cpWingsContext.Passenger (Get)
    //   - int Booking.FlightNo (Get)
    //   - int Flight.FlightNo (Get)
    //   - short Flight.FreeSeats (Get)
    //   - short Flight.Seats (Get)
    //   - string Flight.ToString()
    //   - string Passenger.FullName (Get)
    // Created
    //   - CopyPaste – 20230718 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230718 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intCountBookings = 0;
      int intCountPassengers;
      int intLoopPassengers;
      int intNeededBookings;
      int intNumberOfBookings;
      int intOccupiedSeats;

      IQueryable<Flight> lstFlights =
        from Flight in theDatabaseContext.Flight
        select Flight;
      IQueryable<Passenger> lstPassengers =
        from Passenger in theDatabaseContext.Passenger
        select Passenger;
      Passenger[] arrPassengers = lstPassengers.ToArray();

      cpConsole.PrintWithTime("Start Booking Generation ...");
      intCountPassengers = arrPassengers.Count();

      foreach (Flight theFligth in lstFlights)
      {
        intOccupiedSeats = theFligth.Seats - theFligth.FreeSeats;
        intNumberOfBookings = theDatabaseContext.Booking.Count(theBooking => theBooking.FlightNo == theFligth.FlightNo);
        intNeededBookings = intOccupiedSeats - intNumberOfBookings;
        // cpConsole.Print($"{intOccupiedSeats} - {intNumberOfBookings} - {intNeededBookings}");

        if (intNeededBookings > 0)
        {
          theDatabaseContext.Database.ExecuteSqlRaw("Delete from Booking where Booking.FlightNo = " + theFligth.FlightNo);
          intNeededBookings = intOccupiedSeats;
        }
        else
        // (intNeededBookings <= 0)
        { 
        }
        // (intNeededBookings > 0)

        for (int intCounter = 0; intCounter < intNeededBookings; intCounter++)
        {
          Booking newBooking = new Booking();

          intLoopPassengers = intCountBookings % intCountPassengers;
          intCountBookings++;

          newBooking.Flight = theFligth;
          newBooking.Passenger = arrPassengers[intLoopPassengers];
          theDatabaseContext.Booking.Add(newBooking);

          if (intCountBookings % 997 == 0)
          {
            cpConsole.PrintSuccess("Added booking (one of 997): for " + newBooking.Passenger.FullName + " " + newBooking.Flight.ToString());
          }
          else
          // (intCounter % 997 <> 0)
          {
          }
          // (intCounter % 997 = 0)

        }
        // intCounter = intNeededBookings

      }
      // in lstFlights

      theDatabaseContext.SaveChanges();
      cpConsole.PrintWithTime("... Booking Generation Finished");
    }
    // CreateBookings(cpWingsContext)

    public static void CreateFlights(cpWingsContext theDatabaseContext, int intNumberOfFlights)
    //***
    // Action
    //   - Create a list of random Flights
    //   - Create a list of all existing pilots
    //   - Loop intNumberOfFlights times
    //     - Create a new flight
    //     - Give some information to the fligth
    //       - An unique number
    //       - A different departure and destination
    //       - Number of seats, free seats, date and pilot
    //     - Add pilot to the list of pilots in the context
    //     - Show every 10 an added flight
    //   - Save all changes
    // Called by
    //   - SeedData(cpWingsContext, bool = false, bool = false, int = 0, int = 0, int = 0)
    // Calls
    //   - cpConsole.PrintSuccess(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DbSet<Flight> cpWingsContext.Flight (Get)
    //   - Flight()
    //   - Flight.Date(DateTime) (Set)
    //   - Flight.Departure(string) (Set)
    //   - Flight.Destination(string) (Set)
    //   - Flight.FlightNo(int) (Set)
    //   - Flight.FreeSeats(short) (Set)
    //   - Flight.Pilot(Pilot) (Set)
    //   - Flight.Seats(short) (Set)
    //   - string Flight.ToString()
    // Created
    //   - CopyPaste – 20230718 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230718 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intLengthOfAirports = arrstrAirports.Length - 1;
      int intNumberOfFlightsAlreadyExisting;
      Pilot[] arrPilots = theDatabaseContext.Pilot.ToArray();
      int intLengthOfPilots = arrPilots.Length - 1;
      string strDeparture;
      string strDestination;

      cpConsole.PrintWithTime("Start Flight Generation ...");

      intNumberOfFlightsAlreadyExisting = theDatabaseContext.Flight.Count();
      intNumberOfFlightsAlreadyExisting += 1;

      for (int intCounter = 0; intCounter < intNumberOfFlights; intCounter++)
      {
        Flight newFlight = new Flight();

        newFlight.FlightNo = intCounter + intNumberOfFlightsAlreadyExisting;
        strDeparture = arrstrAirports[theRandom.Next(0, intLengthOfAirports)];
        strDestination = strDeparture;

        while (strDestination == strDeparture)
        {
          strDestination = arrstrAirports[theRandom.Next(0, intLengthOfAirports)];
        }
        // strDestination <> strDeparture

        newFlight.Departure = strDeparture;
        newFlight.Destination = strDestination;
        newFlight.AircraftTypeId = (byte)((DateTime.Now.Millisecond % 2) + 1);

        if (newFlight.AircraftTypeId == 1)
        {
          newFlight.Seats = 853; // Number of seats in an Airbus 380-800
        }
        // (newFlight.AircraftTypeId <> 1)
        else
        {
          newFlight.Seats = 140; // Number of seats in a Boeing 737-500
        }
        // (newFlight.AircraftTypeId = 1)

        newFlight.FreeSeats = Convert.ToInt16(theRandom.Next(0, 50));
        newFlight.Date = DateTime.Now.AddDays(theRandom.Next(300)).AddMinutes(theRandom.Next(10000));

        newFlight.Pilot = arrPilots[theRandom.Next(0, intLengthOfPilots)];
        newFlight.CoPilot = newFlight.Pilot;

        while (newFlight.PilotId == newFlight.CoPilotId)
        {
          newFlight.CoPilot = arrPilots[theRandom.Next(0, intLengthOfPilots)];
        }
        // newFlight.PilotId <> newFlight.CoPilotId

        theDatabaseContext.Flight.Add(newFlight);

        if (intCounter % 10 == 0)
        {
          cpConsole.PrintSuccess("Added flight (one of 10): " + newFlight.ToString());
        }
        else
        // (intCounter % 10 <> 0)
        {
        }
        // (intCounter % 10 = 0)

      }
      // intCounter = intNumberOfFlights

      theDatabaseContext.SaveChanges();
      cpConsole.PrintWithTime("... Flight Generation Finished");
    }
    // CreateFlights(cpWingsContext)

    public static void CreatePassengers(cpWingsContext theDatabaseContext, int intNumberOfPassengers)
    //***
    // Action
    //   - Create a list of random names
    //   - Loop intNumberOfPassengers times
    //     - Create a new Passenger
    //     - Give some information to the Passenger (name, birthday, status, ...)
    //     - Add Passenger to the list of passengers in the context
    //     - Show every 200 an added passenger
    //   - Save all changes
    // Called by
    //   - SeedData(cpWingsContext, bool = false, bool = false, int = 0, int = 0, int = 0)
    // Calls
    //   - cpConsole.PrintSuccess(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DbSet<Passenger> cpWingsContext.Passenger (Get)
    //   - Passenger()
    //   - Passenger.BirthDay(DateTime) (Set)
    //   - Passenger.Detail.City(string) (Set)
    //   - Passenger.GivenName(string) (Set)
    //   - Passenger.Status(string) (Set)
    //   - Passenger.Surname(string) (Set)
    //   - string Passenger.FullName (Get)
    // Created
    //   - CopyPaste – 20230718 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230718 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strFirstName;
      string strLastName;
      int intLengthOfAirports = arrstrAirports.Length - 1;
      int intLengthOfPassengerFirstNames = arrstrFirstNames.Length - 1;
      int intLengthOfPassengerLastNames = arrstrLastNames.Length - 1;

      cpConsole.PrintWithTime("Start Passenger Generation ...");

      for (int intCounter = 0; intCounter < intNumberOfPassengers; intCounter++)
      {
        Passenger newPassenger = new Passenger();

        strFirstName = arrstrFirstNames[theRandom.Next(0, intLengthOfPassengerFirstNames)];
        strLastName = arrstrLastNames[theRandom.Next(0, intLengthOfPassengerLastNames)];

        newPassenger.GivenName = strFirstName;
        newPassenger.Surname = strLastName;
        newPassenger.BirthDay = new DateTime(1960, 1, 1).AddDays(theRandom.Next(20000));
        newPassenger.Status = PassengerStatus.arrstrPassengerStatusses[theRandom.Next(3)];
        newPassenger.Detail.City = arrstrAirports[theRandom.Next(0, intLengthOfAirports)];
        theDatabaseContext.Passenger.Add(newPassenger);

        if (intCounter % 200 == 0)
        {
          cpConsole.PrintSuccess("Added passenger (one of 200): " + newPassenger.FullName);
        }
        else
        // (intCounter % 200 <> 0)
        {
        }
        // (intCounter % 200 = 0)

      }
      // intCounter = intNumberOfPassengerss

      theDatabaseContext.SaveChanges();
      cpConsole.PrintWithTime("... Passenger Generation Finished");
    }
    // CreatePassenger(cpWingsContext)

    public static void CreatePilots(cpWingsContext theDatabaseContext, int intNumberOfPilots)
    //***
    // Action
    //   - Create a list of random names
    //   - Loop intNumberOfPilots times
    //     - Create a new Pilot
    //     - Give some information to the Pilot (name, salary, birthday, ...)
    //     - Add Pilot to the list of pilots in the context
    //     - Show every 10 an added pilot
    //   - Save all changes
    // Called by
    //   - SeedData(cpWingsContext, bool = false, bool = false, int = 0, int = 0, int = 0)
    // Calls
    //   - cpConsole.PrintSuccess(string)
    //   - cpConsole.PrintWithTime(string)
    //   - DbSet<Pilot> cpWingsContext.Pilot (Get)
    //   - Pilot()
    //   - Pilot.BirthDay(DateTime) (Set)
    //   - Pilot.Detail.City(string) (Set)
    //   - Pilot.GivenName(string) (Set)
    //   - Pilot.Salary(float) (Set)
    //   - Pilot.Surname(string) (Set)
    //   - string Pilot.FullName (Get)
    // Created
    //   - CopyPaste – 20230718 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230718 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strFirstName;
      string strLastName;
      int intLengthOfAirports = arrstrAirports.Length - 1;
      int intLengthOfPilotFirstNames = arrstrFirstNameForPilots.Length - 1;
      int intLengthOfPilotLastNames = arrstrLastNameForPilots.Length - 1;

      cpConsole.PrintWithTime("Start Pilot Generation ...");

      for (int intCounter = 0; intCounter < intNumberOfPilots; intCounter++)
      {
        Pilot newPilot = new Pilot();

        strFirstName = arrstrFirstNameForPilots[theRandom.Next(0, intLengthOfPilotFirstNames)];
        strLastName = arrstrLastNameForPilots[theRandom.Next(0, intLengthOfPilotLastNames)];

        newPilot.GivenName = strFirstName;
        newPilot.Surname = strLastName;
        newPilot.Salary = 5000;
        newPilot.Detail.City = arrstrAirports[theRandom.Next(0, intLengthOfAirports)];
        newPilot.BirthDay = new DateTime(1955, 1, 1).AddDays(theRandom.Next(15000));
        theDatabaseContext.Pilot.Add(newPilot);

        if (intCounter % 10 == 0)
        {
          cpConsole.PrintSuccess("Added pilot (one of 10): " + newPilot.FullName);
        }
        else
        // (intCounter % 10 <> 0)
        {
        }
        // (intCounter % 10 = 0)

      }
      // intCounter = intNumberOfPilots

      theDatabaseContext.SaveChanges();
      cpConsole.PrintWithTime("... Pilot Generation Finished");
    }
    // CreatePilots(cpWingsContext, int)

    public static void SeedData(cpWingsContext theContext, bool blnRecreate = false, bool blnDelete = false, int intNumberOfPilotsToCreate = 0, int intNumberOfFlightsToCreate = 0, int intNumberOfPassengersToCreate = 0)
    //***
    // Action
    //   - Recreate database when asked thru the parameters
    //     - Delete the database if it already exists
    //     - Create the database
    //   - Delete data from tables when neede
    //     - Delete Booking data
    //     - Delete Flight data
    //     - Delete Airline data
    //     - Delete AircraftTypeDetail data
    //     - Delete AircraftType data
    //     - Delete Passenger data
    //     - Delete Employee data (only the pilots)
    //     - Delete Persondetail data
    //   - Fill tables with data when needed
    //     - Add Airline data
    //     - Add AircraftType data
    //     - Add AircraftTypeDetail data
    //     - Add Pilot data
    //     - Add Passenger data
    //     - Add Flight data
    //     - Add Booking data
    // Called by
    //   - cpCreateTestDataVerb.CreateTestData(cpWingsContext)
    // Calls
    //   - cpConsole.Print(string)
    //   - cpConsole.PrintMainHeadLine(string)
    //   - cpConsole.PrintSuccess(string)
    //   - DbSet<AircraftType> cpWingsContext.AircraftType (Get)
    //   - DbSet<AircraftTypeDetail> cpWingsContext.AircraftTypeDetail (Get)
    //   - DbSet<Airline> cpWingsContext.Airline(Get)
    //   - DbSet<Flight> cpWingsContext.Flight(Get)
    //   - DbSet<Passenger> cpWingsContext.Passenger(Get)
    //   - DbSet<Pilot> cpWingsContext.Pilot(Get)
    //   - CreateAircraftTypeDetails(cpWingsContext)
    //   - CreateAircraftTypes(cpWingsContext)
    //   - CreateAirlines(cpWingsContext)
    //   - CreateFlights(cpWingsContext, int)
    //   - CreatePassengers(cpWingsContext, int)
    //   - CreatePilots(cpWingsContext, int)
    // Created
    //   - CopyPaste – 20230717 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230717 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      bool blnIsCreated = false;

      int intNumberOfAirlines;
      int intNumberOfAircraftTypeDetails;
      int intNumberOfAircraftTypes;
      int intNumberOfFlights;
      int intNumberOfPassengers;
      int intNumberOfPilots;
      int intNumberOfBookings;

      if (blnRecreate)
      {
        // Delete the database thru the context if it already exists
        cpConsole.PrintMainHeadLine("Delete Database");
        theContext.Database.EnsureDeleted();
        // Create a new database thru the context
        cpConsole.PrintMainHeadLine("Create Database");
        blnIsCreated = theContext.Database.EnsureCreated();
      }
      else
      // Not blnDelete
      { 
      }
      // blnDelete

      if (blnIsCreated)
      {
        cpConsole.PrintSuccess("Database is created");
      }
      else
      // Not blnIsCreated
      {
      }
      // blnIsCreated

      if (blnDelete)
      {
        cpConsole.PrintMainHeadLine("Remove Data");
        theContext.Database.ExecuteSqlRaw("Delete from Booking");
        theContext.Database.ExecuteSqlRaw("Delete from Flight");
        theContext.Database.ExecuteSqlRaw("Delete from Airline");
        theContext.Database.ExecuteSqlRaw("Delete from AircraftTypeDetail");
        theContext.Database.ExecuteSqlRaw("Delete from AircraftType");
        theContext.Database.ExecuteSqlRaw("Delete from Passenger");
        theContext.Database.ExecuteSqlRaw("Delete from Employee where Discriminator = 'Pilot'");
        theContext.Database.ExecuteSqlRaw("Delete from Persondetail");
        cpConsole.PrintSuccess("Data is removed");
      }
      else
      // Not blnDelete
      {
      }
      // blnDelete

      // Create a lot of data randomly (to fill the database)
      cpConsole.Print("Start Data Generation ...");

      CreateAirlines(theContext);
      CreateAircraftTypes(theContext);
      CreateAircraftTypeDetails(theContext);
      CreatePilots(theContext, intNumberOfPilotsToCreate);
      CreatePassengers(theContext, intNumberOfPassengersToCreate);
      CreateFlights(theContext, intNumberOfFlightsToCreate);
      CreateBookings(theContext);

      cpConsole.Print("... Data Generation Finished");

      cpConsole.PrintMainHeadLine("Count all Airlines");
      intNumberOfAirlines = theContext.Airline.Count();
      cpConsole.Print($"Number of Airlines: {intNumberOfAirlines}");

      cpConsole.PrintMainHeadLine("Count all AircraftTypes");
      intNumberOfAircraftTypes = theContext.AircraftType.Count();
      cpConsole.Print($"Number of AircraftTypes: {intNumberOfAircraftTypes}");

      cpConsole.PrintMainHeadLine("Count all AircraftTypeDetails");
      intNumberOfAircraftTypeDetails = theContext.AircraftTypeDetail.Count();
      cpConsole.Print($"Number of AircraftTypeDetails: {intNumberOfAircraftTypeDetails}");

      cpConsole.PrintMainHeadLine("Count all Pilots");
      intNumberOfPilots = theContext.Pilot.Count();
      cpConsole.Print($"Number of Pilots: {intNumberOfPilots}");

      cpConsole.PrintMainHeadLine("Count all Passengers");
      intNumberOfPassengers = theContext.Passenger.Count();
      cpConsole.Print($"Number of Passengers: {intNumberOfPassengers}");

      cpConsole.PrintMainHeadLine("Count all Flights");
      intNumberOfFlights = theContext.Flight.Count();
      cpConsole.Print($"Number of Flights: {intNumberOfFlights}");

      cpConsole.PrintMainHeadLine("Count all Bookings");
      intNumberOfBookings = theContext.Booking.Count();
      cpConsole.Print($"Number of Bookings: {intNumberOfBookings}");
    }
    // SeedData(cpWingsContext, bool = false, bool = false, int = 0, int = 0, int = 0)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDataGeneration

}
// CopyPaste.BusinessLayer