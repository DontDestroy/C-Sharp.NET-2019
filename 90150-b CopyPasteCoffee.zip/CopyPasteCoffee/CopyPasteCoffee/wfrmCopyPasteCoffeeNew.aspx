﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCopyPasteCoffeeNew.aspx.cs" Inherits="CopyPaste.Learning.wfrmCopyPasteCoffeeNew" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Copy Paste Coffee New</title>
  <link rel="stylesheet" type="text/css" href="cssCopyPasteCoffee.css">
</head>
<body>
  <form id="wfrmCopyPasteCoffeeNew">
    <div id="Header">
      <img id="HeaderLogo" src="./Resources/HeaderLogo.gif" alt="Copy Paste Coffee Header Logo">
      <img id="HeaderSlogan" src="./Resources/HeaderSlogan.gif" alt="Copy Paste Coffee Header Slogan">
      <img id="Coupon" src="./Resources/Ticket.gif" alt="Copy Paste Free Coffee Ticket">
    </div>
    <div id="Award">
      <img id="AwardLogo" src="./Resources/Award.gif" alt="Copy Paste Coffee Award Logo">
    </div>
    <div id="TableContainer">
      <div id="TableRow">
        <div id="Drinks">
          <h1>BEVERAGES</h1>
          <p>Cappuccino, € 1.89</p>
          <p>Chai Tea, € 2.85</p>
          <p>House Blend, € 2.49</p>
          <p>Mocha Cafe Latte, € 2.35</p>
          <h1>ELIXIRS</h1>
          <p>
            We proudly serve elixirs brewed by our friends
				at the Head First Lounge.
          </p>
          <p>Black Brain Brew, € 2.99</p>
          <p>Blueberry Bliss Elixir, € 2.99</p>
          <p>Chai Chiller, € 2.99</p>
          <p>Cranberry Antioxidant Blast, € 2.99</p>
          <p>Green Tea Cooler, € 2.99</p>
          <p>Raspberry Ice Concentration, € 2.99</p>
        </div>
        <div id="CopyPasteMain">
          <h1>QUALITY COFFEE, QUALITY CAFFEINE</h1>
          <p>
            At Copy Paste Coffee, we are dedicated to filling all your caffeine needs through our quality coffees and teas.
        Sure, we want you to have a great cup of coffee and a great coffee experience as well,
        but we're the only company that actively monitors and optimizes caffeine levels.
        So stop by and fill your cup, or order online with our new Bean Machine online order form,
        and get that quality Copy Paste coffee that you know will meet your caffeine standards.
          </p>
          <p>
            And, did we mention <em>caffeine</em>? We've just started funding the guys doing all 
        the wonderful research at the <a href="CaffeineBuzz.html#hdrCoffee"
          target="_blank"
          title="Read all about caffeine on the Buzz">Caffeine Buzz</a>.
        If you want the latest on coffee and other caffeine products, stop by and pay them a visit.
          </p>
          <h1>OUR STORY</h1>
          <p>
            "A man, a plan, a coffee bean". Okay, that doesn't make a palindrome, but it resulted in a damn good cup of coffee.
        Copy Paste Coffee's CEO is that man, and you already know his plan: a Copy Paste Coffee on every corner.
          </p>
          <p>
            In only a few years he's executed that plan and today you can enjoy Copy Paste Coffee just about anywhere.
        And, of course, the big news this year is that Copy Paste Coffee teamed up with Copy Paste readers to create Copy Paste Coffee's
        Web presence, which is growing rapidly and helping to meet the caffeine needs of a whole new set of customers.
          </p>
          <h1>COPY PASTE COFFEE BEVERAGES</h1>
          <p>
            We've got a variety of caffeinated beverages to choose from at Copy Paste Coffie, including our 
        <a href="wfrmCopyPasteCoffee.aspx#hdrHouseBlend" title="House Blend">House Blend</a>,
        <a href="wfrmCopyPasteCoffee.aspx#hdrMochaCaffeLatte" title="Mocha Cafe Latte">Mocha Cafe Latte</a>, 
        <a href="wfrmCopyPasteCoffee.aspx#hdrCappuccino" title="Cappuccino">Cappuccino</a>,
        and a favorite of our customers, 
        <a href="wfrmCopyPasteCoffee.aspx#hdrChaiTea" title="Chai Tea">Chai Tea</a>.
          </p>
          <p>
            We also offer a variety of coffee beans, whole or ground, for you to take home with you.
        Order your coffee today using our online <a href="DoesNotExistYet.html">Bean Machine</a>, and take
        the Copy Paste Coffee experience home.
          </p>
        </div>
        <!-- CopyPasteMain -->
        <div id="SideBar">
          <p class="BeanHeading">
            <img src="./Resources/Bag.gif" alt="Bean Machine Bag">
              <br>
                ORDER ONLINE
        with the 
        <a href="DoesNotExistYet.html">BEAN MACHINE</a>
                <br>
                  <span class="Slogan">FAST
                <br>
                  FRESH
                  <br>
                    TO YOUR DOOR
                    <br>
                  </span>
          </p>
          <p>
            Why wait? You can order all our fine coffees right from the Internet with our new, automated Bean Machine.
        How does it work? Just click on the Bean Machine link, enter your order, and behind the scenes, your coffee is roasted,
        ground (if you want), packaged, and shipped to your door.
          </p>
        </div>
        <!-- SideBar -->
      </div>
      <!-- TableRow -->
    </div>
    <!-- TableContainer -->
    <div id="Footer">
      <p>
        <img src="./Resources/CopyPaste.jpg" alt="Copy Paste Logo"><br>
        &copy; 2026 - Copy Paste - All trademarks and registered trademarks appearing on this site are the property of their respective owners.
      </p>
    </div>
  </form>
</body>
</html>
