﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="wfrmListBox.aspx.vb" Inherits="ListBox.CopyPaste.Learning.wfrmListBox" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Default</title>
</head>
<body ms_positioning="GridLayout">
  <form id="wfrmListBox" method="post" runat="server">
    <asp:ListBox ID="lstName" Style="z-index: 101; position: absolute; top: 16px; left: 24px" runat="server"
      Width="176px" Height="104px">
      <asp:ListItem Value="First">John</asp:ListItem>
      <asp:ListItem Value="Second">James</asp:ListItem>
      <asp:ListItem Value="Third">Francis</asp:ListItem>
      <asp:ListItem Value="Fourth">Roland</asp:ListItem>
    </asp:ListBox>
    <asp:Label ID="lblResult" Style="z-index: 103; position: absolute; top: 168px; left: 24px"
      runat="server" Width="416px"></asp:Label>
    <asp:Button ID="cmdOK" Style="z-index: 102; position: absolute; top: 128px; left: 24px" runat="server"
      Text="Choose a name and click" Width="176px"></asp:Button>
  </form>
</body>
</html>
