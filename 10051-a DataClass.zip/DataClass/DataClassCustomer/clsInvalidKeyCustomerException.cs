﻿//***
// Action
//   - Definition of a cpInvalidKeyCustomerException
// Created
//   - CopyPaste – 20260117 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260117 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpInvalidKeyCustomerException : System.ApplicationException
  {

    #region "Constructors / Destructors"

    public cpInvalidKeyCustomerException(string strKeyCustomer) : base("The customer key specified, " + strKeyCustomer + ", is not valid (must be 5 long and unique).")
      //***
      // Action
      //   - Create new instance of 'cpInvalidKeyCustomerException'
      //   - Create a message that the key is invalid
      //     - There are 2 possible reasons
      //       - Key is not 5 long
      //       - Key already in use
      // Called by
      //   - cpCustomer(string)
      //   - cpCustomer(string, string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260117 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260117 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpInvalidKeyCustomerException(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
		//#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpInvalidKeyCustomerException

}
// CopyPaste.Learning