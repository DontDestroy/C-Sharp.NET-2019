﻿//***
// Action
//   - Explanation of the code in this module or class
// Created
//   - CopyPaste – 20240615 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240615 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning.Data
{

  public partial class frmDataGridWizard : Form
  {

    #region "Constructors / Destructors"

    public frmDataGridWizard()
    //***
    // Action
    //   - Create instance of 'frmDataGridWizard'
    // Called by
    //   - Main()
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20240615 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20240615 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmDataGridWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdLoad_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Clear the data set
    //   - Fill the data set thru the data adapter
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20240615 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20240615 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      dsData.Clear();
      tbaInstructor.Fill(dsData.tblCPInstructor);
    }
    // cmdLoad_Click(theSender, theEventArguments) Handles cmdLoad.Click

    private void cmdUpdate_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try
    //     - Update the data set thru the data adapter
    //   - When something fails
    //     - Show error message
    // Called by
    //   - User action (Starting the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20240615 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20240615 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      try
      {
        tbaInstructor.Update(dsData.tblCPInstructor);
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.ToString());
      }
      finally
      {
      }

    }
    // cmdUpdate_Click(System.Object, System.EventArgs) Handles cmdUpdate.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDataGridWizard

}
// CopyPaste.Learning.Data