<%@ Page Language="C#" %>

<html>
<head>
  <title>Catch Divide by Zero</title>
</head>
<body>
  <center>
    <h1>Catch Divide by Zero Exception</h1>
  </center>
  <hr>

  <% 

    int intNumber = 10;
    int intDivider = 0;
    int intRemainder;

    try
    {
      intRemainder = intNumber % intDivider;

      Response.Write("Remainder: " + intRemainder + "<br>");
    }
    catch (DivideByZeroException theException)
    {
      Response.Write("<h3>Error in processing -- Divide by 0</h3>");
    }

  %>

</body>
</html>
