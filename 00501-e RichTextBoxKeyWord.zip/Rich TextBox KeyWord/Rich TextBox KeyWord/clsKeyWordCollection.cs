﻿//***
// Action
//   - Define a collection of keywords
// Created
//   - CopyPaste – 20250721 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250721 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;

namespace CopyPaste.Learning.UserInterface
{

  public class cpKeyWordCollection : DictionaryBase
  {

    #region "Constructors / Destructors"

    public cpKeyWordCollection()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpctlRichTextBoxKeyWord()
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250721 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250721 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpKeyWordCollection()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public cpKeyWordFormat this[string strKey] 
    {

      get
        //***
        // Action Get
        //   - Return the cpKeyWordFormat with a specific key
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20250721 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250721 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return (cpKeyWordFormat)base.Dictionary[strKey];
      }
      // cpKeyWordFormat this[string] (Get)

      set
        //***
        // Action Set
        //   - If value is null
        //     - Throw a new null argument exception
        //   - If not
        //     - Set the cpKeyWordFormat with a specific key to cpValue
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20250721 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250721 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (value == null)
        {
          throw new ArgumentNullException();
        }
        else
        {
          base.Dictionary[strKey] = value;
        }

      }
      // this[string, cpKeyWorkFormat] (Set)

    }

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Add(string strKey, cpKeyWordFormat thecpKeyWordFormat)
      //***
      // Action
      //   - If strKey is nothing or thecpKeyWordFormat is nothing
      //     - Throw a new null argument exception
      //   - If not
      //     - If strKey has no length
      //       - Throw a new Missing key argument exception
      //     - If not
      //       - Add a cpKeyWordFormat with a certain key
      // Called by
      //   - User action (Adding a keyword to collection)
      // Calls
      //   - bool Contains(string)
      // Created
      //   - CopyPaste – 20250721 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250721 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if ((strKey == null) || (thecpKeyWordFormat == null))
      {
        throw new ArgumentNullException();
      }
      else if (strKey.Length == 0)
        // strKey <> null And thecpKeyWordFormat <> null
      {
        throw new ArgumentException("Missing key.");
      }
      else if (Contains(strKey))
        // strKey.Length <> 0
      {
        throw new ArgumentException("Duplicate key.");
      }      
      else
        // Not Contains(strKey)
      {
        base.Dictionary.Add(strKey, thecpKeyWordFormat);
      }
      // strKey = null Or thecpKeyWordFormat = null
      // strKey.Length = 0
      // Contains(strKey)

    }
    // Add(String, cpKeyWordFormat)

    public bool Contains(string strKey)
      //***
      // Action
      //   - Check if a key already exists in the dictionary
      // Called by
      //   - Add(String, cpKeyWordFormat)
      //   - Remove(String)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250721 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250721 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return base.Dictionary.Contains(strKey);
    }
    // bool Contains(string)

    public void Remove(string strKey)
      //***
      // Action
      //   - Remove a certain key
      // Called by
      //   - 
      // Calls
      //   - bool Contains(string)
      // Created
      //   - CopyPaste – 20250721 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250721 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (Contains(strKey))
      {
        base.Dictionary.Remove(strKey);
      }
      else
        // Not Contains(strKey)
      {
      }
      // Contains(strKey)

    }
    // Remove(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpKeyWordCollection

}
// CopyPaste.Learning.UserInterface