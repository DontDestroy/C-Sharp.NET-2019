//***
// Action
//   - Testroutine of cpMath
// Created
//   - CopyPaste � 20240618 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240618 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using Microsoft.VisualBasic;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create an array of numbers
      //   - Make a new instance of cpMath
      //   - Give a variable the value "Add" (or "Multiply")
      //   - Do the calculation
      //   - Show a messagebox of the result
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpMath()
      //   - int cpMath.Add()
      //   - int cpMath.Multiply()
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - I use here the Visual Basic Method Interaction.CallByName
      //   - You can use also reflection (See other project)
      //***
    {
      cpMath thecpMath; 
      int[] arrlngNumber = new int[] {1, 2, 3, 4};
      System.Object objResult;
      string strMethod;

      thecpMath = new cpMath();
      strMethod = "Add";
      // strMethod = "Multiply";

      objResult = Interaction.CallByName(thecpMath, strMethod, CallType.Method, arrlngNumber);
      MessageBox.Show(objResult.ToString());
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning