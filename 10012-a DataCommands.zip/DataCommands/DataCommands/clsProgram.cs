﻿//***
// Action
//   - Having DataCommands and DataReaders towards a database
//   - Alternative way to start application
// Created
//   - CopyPaste – 20210706 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210706 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System.Windows.Forms;

namespace DataCommands
{

  static class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Starting the application frmDataCommands
    // Called by
    //   - User action (Starting the application-
    // Calls
    //   - frmDataCommands()
    // Created
    //   - CopyPaste – 20210706 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210706 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run(new frmDataCommands());
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// DataCommands