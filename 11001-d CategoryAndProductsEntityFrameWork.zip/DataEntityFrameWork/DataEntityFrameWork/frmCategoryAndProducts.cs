﻿//***
// Action
//   - An example of using Entity Framework
// Created
//   - CopyPaste – 20210701 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210701 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//   - https://docs.microsoft.com/en-us/ef/ef6/fundamentals/databinding/winforms
//***

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace DataEntityFrameWork
{
  public partial class frmCategoryAndProducts : Form
  {
    #region "Constructors / Destructors"
    public frmCategoryAndProducts()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmCategoryAndProducts()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    cpNorthWindScript2019EntitiesContext _context;
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void OnClosed(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Execute OnClosed of the base class
    //   - Dispose cpNorthWindScript2019EntitiesContext object
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      base.OnClosed(theEventArguments);
      this._context.Dispose();
    }
    // OnClosed(System.EventArgs)

    protected override void OnLoad(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Execute OnLoad of the base class
    //   - Define cpNorthWindScript2019EntitiesContext object
    //   - Load tblCPCategory
    //   - Define DataSource for tblCPCategoryBindingSource
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      base.OnLoad(theEventArguments);
      _context = new cpNorthWindScript2019EntitiesContext();
      _context.tblCPCategory.Load();
      this.tblCPCategoryBindingSource.DataSource = _context.tblCPCategory.Local.ToBindingList();
    }
    // OnLoad(System.EventArgs)

    #endregion

    #region "Controls"

    private void tblCPCategoryBindingNavigatorSaveItem_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Validate the form
    //   - Loop thru the list of items in tblCPProduct
    //     - If there is no key
    //       - Remove the product
    //     - If Not
    //       - Do nothing
    //   - Save the changes
    //   - Refresh Datagrid of Category
    //   - Refresh Datagrid of Product
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210701 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210701 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.Validate();

      foreach (var product in _context.tblCPProduct.Local.ToList())
      {
        if (product.intCategoryId == null)
        {
          _context.tblCPProduct.Remove(product);
        }
        // (product.intCategoryId == null)
      }
      // in _context.tblCPProduct.Local.ToList()

      this._context.SaveChanges();
      this.tblCPCategoryDataGridView.Refresh();
      this.tblCPProductDataGridView.Refresh();
    }
    // tblCPCategoryBindingNavigatorSaveItem_Click(System.Object, System.EventArgs)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmCategoryAndProducts
}
// DataEntityFrameWork