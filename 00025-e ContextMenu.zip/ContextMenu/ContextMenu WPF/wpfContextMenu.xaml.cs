﻿//***
// Action
//   - Working with a context menu on a label
//   - This WPF form as startpoint of the exercise
// Created
//   - CopyPaste – 20230416 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230416 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ContextMenu_WPF
{

  public partial class wpfContextMenu : Window
  {

    #region "Constructors / Destructors"

    public wpfContextMenu()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230416 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230416 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfContextMenu()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void mnuColorBlack_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - The label forecolor becomes black
    // Called by
    //   - User action (Clicking on menu mnuColorBlack)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230416 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230416 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblText.Foreground = Brushes.Black;
    }
    // mnuColorBlack_Click(System.Object, System.Windows.RoutedEventArgs) Handles mnuColorBlack.Click

    private void mnuColorBlue_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - The label forecolor becomes blue
    // Called by
    //   - User action (Clicking on menu mnuColorBlue)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230416 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230416 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblText.Foreground = Brushes.Blue;
    }
    // mnuColorBlue_Click(System.Object, System.Windows.RoutedEventArgs) Handles mnuColorBlue.Click

    private void mnuColorGreen_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - The label forecolor becomes green
    // Called by
    //   - User action (Clicking on menu mnuColorGreen)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230416 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230416 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblText.Foreground = Brushes.Green;
    }
    // mnuColorGreen_Click(System.Object, System.Windows.RoutedEventArgs) Handles mnuColorGreen.Click

    private void mnuColorRed_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - The label forecolor becomes red
    // Called by
    //   - User action (Clicking on menu mnuColorRed)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230416 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230416 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblText.Foreground = Brushes.Red;
    }
    // mnuColorRed_Click(System.Object, System.Windows.RoutedEventArgs) Handles mnuColorRed.Click

    private void mnuInsertDate_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - The label becomes the date of today
    // Called by
    //   - User action (Clicking on menu mnuInsertDate)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230416 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230416 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblText.Content = System.DateTime.Now.ToShortDateString();
    }
    // mnuInsertDate_Click(System.Object, System.Windows.RoutedEventArgs) Handles mnuInsertDate.Click

    private void mnuInsertTime_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - The label becomes the time of now
    // Called by
    //   - User action (Clicking on menu mnuInsertTime)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230416 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230416 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lblText.Content = System.DateTime.Now.ToShortTimeString();
    }
    // mnuInsertTime_Click(System.Object, System.Windows.RoutedEventArgs) Handles mnuInsertTime.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfContextMenu

}
// ContextMenu_WPF
