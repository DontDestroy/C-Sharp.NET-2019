//***
// Action
//   - A way to check if a given number is a prime number
// Created
//   - CopyPaste � 20240502 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240502 � VVDW
// Proposal (To Do)
//   - It is not optimal, but it explain good a basic routine in programming
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - A number is asked, without error check
      //   - If the number is positive
      //     - Loop from 2 till asked number minus 1 (loopnumber)
      //       - Divide asked number with loopnumber
      //         - If reminder
      //           - Can't be divided
      //         - If not
      //           - Can be divided, and so it is not a prime number
      //           - Show result of calculation (in 2 directions if it is different)
      //             x / a = b <-> x / b = a
      //           - Add one to the number of possible dividers
      //     - If counter of dividers is larger than 0
      //       - Show message that asked number is not prime
      //     - If not
      //       - Show message that asked number is prime (when not 1)
      //   - If not
      //     - Error message is shown
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240502 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240502 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - Routine is very slow and can be optimized
      //***
    {
      int lngCountDivider = 0;
      int lngCounter;
      int lngNumber;

      Console.Write("Enter a number larger than 0: ");
      lngNumber = Convert.ToInt32(Console.ReadLine());

      if (lngNumber > 0)
      {
        
        for (lngCounter = 2; lngCounter < lngNumber; lngCounter++)
          // for (lngCounter = 2; lngCounter <= Convert.ToInt32(System.Math.Round(System.Math.Sqrt(lngNumber), 0)); lngCounter++)
          // test for 1234567891 and 123456789011
        {

          if (lngNumber % lngCounter == 0)
          {
            Console.WriteLine("Number {0} can be divided by {1} - Result {2}", lngNumber, lngCounter, lngNumber / lngCounter);

            if (lngNumber / lngCounter == lngCounter)
            {
            }
            else
              // lngNumber / lngCounter <> lngCounter
            {
              Console.WriteLine("Number {0} can be divided by {1} - Result {2}", lngNumber, lngNumber / lngCounter, lngCounter);
            }
            // lngNumber / lngCounter = lngCounter
          
            lngCountDivider += 1;
          }
          else
            // lngNumber % lngCounter <> 0
          {
          }
          // lngNumber % lngCounter = 0
        
        }
        // lngCounter = lngNumber

        Console.WriteLine();
        
        if (lngCountDivider > 0)
        {
          Console.WriteLine("Number {0} is not a prime number.", lngNumber);
        }
        else if (lngNumber == 1)  
          // lngCountDivider <= 0
        {
          Console.WriteLine("Number {0} is not a prime number.", lngNumber);
        }
        else
          // lngNumber <> 1
        {
          Console.WriteLine("Number {0} is a prime number.", lngNumber);
        }
        // lngCountDivider > 0
        // lngNumber = 1

      }
      else
      // lngNumber <= 0
      {
        Console.WriteLine("Wrong input");
      }
      // lngNumber > 0

      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning