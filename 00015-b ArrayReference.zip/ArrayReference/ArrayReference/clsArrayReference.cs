//***
// Action
//   - Define arrays
//   - Copy arrays
//   - Use arrays as parameter (By value and by reference)
// Created
//   - CopyPaste � 20220210 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220210 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace ArrayReference
{

  class cpArrayReference
	{

    static void Main()
    //***
    // Action
    //   - Define 3 arrays
    //   - Fill the first array
    //   - Define the copy array as the same as the first array
    //   - Show the content of the original array
    //   - Double all items of first array in method (by value)
    //   - Define a new array in the received argument
    //   - Show the content of the original array
    //   - Test if references of first array and copy array are the same
    //   - Show the content of the copied array
    //   - Fill the second array
    //   - Define the copy array as the same as the second array
    //   - Show the content of the original array
    //   - Double all items of second array in method (by reference)
    //   - Define a new array in the received argument
    //   - Show the content of the original array
    //   - Test if references of second array and copy array are the same
    //   - Show the content of the copied array
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - Console.Write(string)
    //   - Console.WriteLine()
    //   - Console.WriteLine(string)
    //   - FirstDouble(Int32())
    //   - int Array.GetUpperBound(int)
    //   - SecondDouble(�int[])
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int intCounter;
      int[] arrCopy;
      int[] arrFirst;
      int[] arrSecond;

      arrFirst = new int[] {1, 2, 3};
      arrCopy = arrFirst;
      
      Console.WriteLine("Test passing array reference using ByVal.");
      Console.WriteLine();
      Console.Write("Contents of original array before calling FirstDouble: ");

      for (intCounter = 0; intCounter <= arrFirst.GetUpperBound(0); intCounter++)
      {
        Console.Write(arrFirst[intCounter] + " ");
      }
      // intCounter = arrFirst.GetUpperBound(0) + 1

      FirstDouble(arrFirst);
      Console.Write("\nContents of original array after calling FirstDouble: ");

      for (intCounter = 0; intCounter <= arrFirst.GetUpperBound(0); intCounter++)
      {
        Console.Write(arrFirst[intCounter] + " ");
      }
      // intCounter = arrFirst.GetUpperBound(0) + 1
      
      if (arrFirst == arrCopy)
      {
        Console.WriteLine("\nThe references are equal.");
      }
      else
        // (arrFirst != arrCopy)
      {
        Console.WriteLine("\nThe references are not equal.");
      }
      // (arrFirst == arrCopy) 

      Console.Write("\nContents of copied array after calling FirstDouble: ");

      for (intCounter = 0; intCounter <= arrCopy.GetUpperBound(0); intCounter++)
      {
        Console.Write(arrCopy[intCounter] + " ");
      }
      // intCounter = arrCopy.GetUpperBound(0) + 1

      arrSecond = new int[] {1, 2, 3};
      arrCopy = arrSecond;
      
      Console.WriteLine();
      Console.WriteLine("\nTest passing array reference using ByRef.");
      Console.WriteLine();
      Console.Write("Contents of original array before calling SecondDouble: ");

      for (intCounter = 0; intCounter <= arrSecond.GetUpperBound(0); intCounter++)
      {
        Console.Write(arrSecond[intCounter] + " ");
      }
      // intCounter = arrSecond.GetUpperBound(0) + 1

      SecondDouble(ref arrSecond);
      Console.Write("\nContents of original array after calling SecondDouble: ");

      for (intCounter = 0; intCounter <= arrSecond.GetUpperBound(0); intCounter++)
      {
        Console.Write(arrSecond[intCounter] + " ");
      }
      // intCounter = arrSecond.GetUpperBound(0) + 1

      if (arrSecond == arrCopy)
      {
        Console.WriteLine("\nThe references are equal.");
      }
      else
        // (arrSecond != arrCopy)
      {
        Console.WriteLine("\nThe references are not equal.");
      }
      // (arrSecond == arrCopy) 

      Console.Write("\nContents of copied array after calling SecondDouble: ");

      for (intCounter = 0; intCounter <= arrCopy.GetUpperBound(0); intCounter++)
      {
        Console.Write(arrCopy[intCounter] + " ");
      }
      // intCounter = arrCopy.GetUpperBound(0) + 1

      Console.ReadLine();
    }
    // Main()

    static void FirstDouble(int[] arrNumber)
    //***
    // Action
    //   - Loop thru all items of arrNumber
    //     - Multiply value by 2
    //   - Define a new array in arrNumber
    // Called by
    //   - Main()
    // Calls
    //   - int Array.GetUpperBound(int)
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int intCounter;

      for (intCounter = 0; intCounter <= arrNumber.GetUpperBound(0); intCounter++)
      {
        arrNumber[intCounter] *= 2;
      }
      // intCounter = arrNumber.GetUpperBound(0) + 1

      arrNumber = new int[] {11, 12, 13};
    }
    // FirstDouble(int[])

    static void SecondDouble(ref int[] arrNumber)
    //***
    // Action
    //   - Loop thru all items of arrNumber
    //     - Multiply value by 2
    //   - Define a new array in arrNumber
    // Called by
    //   - Main()
    // Calls
    //   - int Array.GetUpperBound(int)
    // Created
    //   - CopyPaste � 20220210 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220210 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      int intCounter;

      for (intCounter = 0; intCounter <= arrNumber.GetUpperBound(0); intCounter++)
      {
        arrNumber[intCounter] *= 2;
      }
      // intCounter = arrNumber.GetUpperBound(0) + 1
      
      arrNumber = new int[] {11, 12, 13};
    }
    // SecondDouble(�int[])
 
  }
  // cpArrayReference

}
// ArrayReference