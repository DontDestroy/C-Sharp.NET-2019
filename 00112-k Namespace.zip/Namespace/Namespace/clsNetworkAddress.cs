//***
// Action
//   - Implementation of cpAddress (Namespace Network)
// Created
//   - CopyPaste � 20240410 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240410 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Network
{

  public class cpAddress
  {

    #region "Constructors / Destructors"

    public cpAddress(string strIPAddress, string strDomain)
      //***
      // Action
      //   - Constructor of cpAddress with IP and Domain
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240410 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240410 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrDomainName = strDomain;
      mstrDottedName = strIPAddress;
    }
    // cpAddress(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrDomainName;
    private string mstrDottedName;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Constructs the information of an Address
      //   - The IP address, new line, Domainname
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240410 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240410 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strResult = "";

      strResult += "IP: " + mstrDottedName + Environment.NewLine;
      strResult += "Domain: " + mstrDomainName;

      return strResult;
    }
    // string ToString()


    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpAddress

}
// Network