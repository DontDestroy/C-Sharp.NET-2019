﻿//***
// Action
//   - Working with an array of fixed length
// Created
//   - CopyPaste – 20220823 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220823 – VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Windows;

namespace ArrayFixed_WPF
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class wpfArrayFixed : Window
  {

    #region "Constructors / Destructors"

    public wpfArrayFixed()
    //***
    // Action
    //   - Create instance of 'wpfArrayFixed'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfArrayFixed()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    decimal[] marrdecTemperatures = new decimal[7];

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdInput_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Ask the average temperature for 7 days
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - decimal Convert.ToDecimal(String)
    //   - int Array.GetUpperBound(int)
    //   - string Microsoft.VisualBasic.InputBox(string, string, string, int, int)
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter;
      string strCaption;
      string strMessage;

      strMessage = "What was the average temperature?";

      for (lngCounter = 0; lngCounter <= marrdecTemperatures.GetUpperBound(0); lngCounter++)
      {
        strCaption = "Day " + (lngCounter + 1);
        marrdecTemperatures[lngCounter] = Convert.ToDecimal(Interaction.InputBox(strMessage, strCaption, "", -1, -1));
      }
      // lngCounter = marrdecTemperatures.GetUpperBound(0) + 1

    }
    // cmdInput_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdInput.Click

    private void cmdOutput_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Show the average temperatures of 7 days
    //   - Calculate the average
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - int Array.GetUpperBound(int)
    //   - System.Environment.NewLine()
    //' Created
    //'   - CopyPaste – 20220823 – VVDW
    //' Changed
    //'   - CopyPaste – yyyymmdd – VVDW – What changed
    //' Tested
    //'   - CopyPaste – 20220823 – VVDW
    //' Keyboard key
    //'   -
    //' Proposal (To Do)
    //'   -
    //'***
    {
      decimal decTotal = 0;
      long lngCounter;
      string strResult;

      strResult = "Average temperatures of this week:" + Environment.NewLine + Environment.NewLine;

      for (lngCounter = 0; lngCounter <= marrdecTemperatures.GetUpperBound(0); lngCounter++)
      {
        strResult = strResult + "Day " + (lngCounter + 1) + "\t" +
          marrdecTemperatures[lngCounter] + Environment.NewLine;
        decTotal += marrdecTemperatures[lngCounter];
      }
      // lngCounter = marrdecTemperatures.GetUpperBound(0) + 1

      strResult += Environment.NewLine + "Average temperature:  " + (decTotal / 7).ToString("0.00");
      txtResult.Text = strResult;
    }
    // cmdOutput_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdOutput.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // 

}
// 

//***
// Action
//   - Explanation of the code in this module or class
// Called by
//   - List of code that uses this procedure
// Calls
//   - List of procedures that are called by this piece of code
// Created
//   - CopyPaste – yyyymmdd – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – yyyymmdd – VVDW
// Keyboard key
//   - 
// Proposal (To Do)
//   - 
//***