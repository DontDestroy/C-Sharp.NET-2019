﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCarLoan.aspx.cs" Inherits="CopyPaste.Learning.wfrmCarLoan" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Car Loan</title>
</head>
<body style="height: 78px">
  <form id="wfrmCarLoan" runat="server" method="post">
    <p>
      <font size="6">Car loan calculation</font>
      <asp:TextBox ID="txtAmount" runat="server" Style="z-index: 101; left: 16px; position: absolute; top: 112px; width: 124px;" TabIndex="1"></asp:TextBox>
      <asp:TextBox ID="txtInterest" runat="server" Style="z-index: 102; left: 16px; position: absolute; top: 152px; width: 124px;" TabIndex="2"></asp:TextBox>
      <asp:TextBox ID="txtPayment" runat="server" Style="z-index: 103; left: 16px; position: absolute; top: 192px; width: 124px;" TabIndex="3"></asp:TextBox>
      <asp:Label ID="lblAmount" runat="server" Font-Size="X-Small" Style="z-index: 104; left: 184px; position: absolute; top: 112px" Width="136px">Borrowed amount</asp:Label>
      <asp:Label ID="lblInterest" runat="server" Font-Size="X-Small" Style="z-index: 105; left: 184px; position: absolute; top: 152px" Width="192px">Interest (for example: 0,09)</asp:Label>
      <asp:Label ID="lblPayment" runat="server" Font-Size="X-Small" Style="z-index: 106; left: 184px; position: absolute; top: 200px" Width="240px">Monthly payment for a period of 48 months</asp:Label>
      <asp:Button ID="cmdCalculate" runat="server" Style="z-index: 107; left: 16px; position: absolute; top: 240px" TabIndex="4" Text="Calculate!" Width="96px" OnClick="cmdCalculate_Click"></asp:Button>
      <asp:HyperLink ID="hypHelpDutch" runat="server" Font-Size="X-Small" NavigateUrl="WebCarLoanHelpDutch.htm" Style="z-index: 108; left: 184px; position: absolute; top: 240px">Show help (in Dutch)</asp:HyperLink>
      <asp:HyperLink ID="hypHelpEnglish" runat="server" Font-Size="X-Small" NavigateUrl="WebCarLoanHelpEnglish.htm" Style="z-index: 109; left: 184px; position: absolute; top: 264px">Show help (in English)</asp:HyperLink>
    </p>
    <p>
      Enter information and click &quot;Calculate!&quot;
    </p>
  </form>
</body>
</html>
