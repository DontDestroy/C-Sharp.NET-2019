//***
// Action
//   - A pet store, the definition of a minidoxen (base class, but inherits from cpDog)
//   - Working with properties (Get and Set) and methods in several classes, that can be reused
// Created
//   - CopyPaste � 20220316 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW
// Tested
//   - CopyPaste � 20220316 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace CopyPaste.Pet.Dog
{

  public class cpMiniDoxen : cpDog
  {

    #region "Constructors / Destructors"

    public cpMiniDoxen() : base ()
    //***
    // Action
    //   - Creating an instance of cpMiniDoxen with default parameters
    //   - Breed becomes "Miniature Doxen"
    //   - Cost becomes 600
    //   - Write a line "cpMiniDoxen default constructor"
    // Called by
    //   - 
    // Calls
    //   - base()
    //   - CopyPaste.Pet.cpAnimal.Breed(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Cost(decimal) (Set)
    // Created
    //   - CopyPaste � 20220316 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20220316 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Breed = "Miniature Doxen";
      Cost = 600;
      Console.WriteLine("cpMiniDoxen default constructor");
    }
    // cpMiniDoxen()

    public cpMiniDoxen(string strName, string strColor) : base (strName)
    //***
    // Action
    //   - Creating an instance of cpMiniDoxen with default parameters and strName
    //   - Breed becomes "Miniature Doxen"
    //   - Cost becomes 600
    //   - Coloration becomes strColor
    //   - Write a line "cpMiniDoxen overloaded constructor"
    // Called by
    //   - cpProgram.FillArray()
    // Calls
    //   - base(string)
    //   - CopyPaste.Pet.cpAnimal.Breed(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Coloration(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Cost(decimal) (Set)
    // Created
    //   - CopyPaste � 20220316 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20220316 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Breed = "Miniature Doxen";
      Cost = 600;
      Coloration = strColor;
      Console.WriteLine("cpMiniDoxen overloaded constructor");
    }
    // cpMiniDoxen(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override string Speak()
    //***
    // Action
    //   - Write a line to the console with "CopyPaste.Pet.Dog.cpMiniDoxen.Speak"
    //   - Return "(Name) says 'Boo boo boo boo!'"
    // Called by
    //   - frmPetStore.cmdSpeak_Click(System.Object, System.EventArgs) Handles cmdSpeak.Click
    // Calls
    //   - Overrides CopyPaste.Pet.cpAnimal.Speak() As String
    //   - string CopyPaste.Pet.cpAnimal.Name (Get)
    // Created
    //   - CopyPaste � 20220316 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20220316 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Console.WriteLine("CopyPaste.Pet.Dog.cpMiniDoxen.Speak");
      return Name + " says 'Boo boo boo boo!'";
    }
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpMiniDoxen

}
// CopyPaste.Pet.Dog