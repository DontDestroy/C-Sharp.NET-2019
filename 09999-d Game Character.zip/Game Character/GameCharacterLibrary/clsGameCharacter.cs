﻿//***
// Action
//   - Implementation of a cpGameCharacter
//     - All game characters fight with a weapon
//       - All class that inherit must show information on the Output Window how they can fight
//     - All ducks can have an implementation of fighting
//       - This is done thru delegates and events
//       - Meaning, that the functionality is outside the class of cpGameCharacter
// Created
//   - CopyPaste – 20240806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240806 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Weapon.Library;
using System.Diagnostics;

namespace CopyPaste.Game.Character.Library
{

	public abstract class cpGameCharacter
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpGameCharacter
		/// </summary>
		public cpGameCharacter()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - cpKing()
		//   - cpKnight()
		//   - cpQueen()
		//   - cpTroll()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpGameCharacter()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		public event cpDelegateFight PerformFightWithWeapon;
		// Fight()

		private cpiWeapon cpHowToFight;

		#endregion

		#region "Properties"

		public cpiWeapon HowToFight
		{

			get
			//***
			// Action Get
			//   - Return cpHowToFight
			// Called by
			//   - cpGameCharacter.HowToFight(cpiWeapon) (Set)
			// Calls
			//   - 
			// Created
			//   - CopyPaste – 20240806 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240806 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				return cpHowToFight;
			}
			// cpiWeapon HowToFight (Get)

			set
			//***
			// Action Set
			//   - cpHowToFight becomes value
			//   - Add the new functionality to the event
			// Called by
			//   - cpKing()
			//   - cpKnight()
			//   - cpQueen()
			//   - cpTroll()
			// Calls
			//   - CleanBehaviour()
			//   - cpiWeapon HowToFight (Get)
			//   - cpiWeapon.UseWeapon()
			// Created
			//   - CopyPaste – 20240806 – VVDW
			// Changed
			//   - CopyPaste – yyyymmdd – VVDW – What changed
			// Tested
			//   - CopyPaste – 20240806 – VVDW
			// Keyboard key
			//   -
			// Proposal (To Do)
			//   -
			//***
			{
				CleanBehaviour();
				cpHowToFight = value;
				PerformFightWithWeapon += new cpDelegateFight(HowToFight.UseWeapon);
			}
			// HowToFight(cpiWeapon) (Set)

		}
		// cpiWeapon HowToFight

		#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		#region "Event"

		public delegate void cpDelegateFight();

		#endregion

		#region "Sub / Function"

		/// <summary>
		/// Clean the existing behaviour from a cpGameCharacter
		/// </summary>
		public void CleanBehaviour()
		//***
		// Action
		//   - If there is a behaviour for fighting
		//     - Remove it
		// Called by
		//   - CopyPaste.Game.Character.Test.cpProgram.Main()
		//   - cpiWeapon.UseWeapon()
		//   - HowToFight(cpiWeapon) (Set)
		// Calls
		//   -
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformFightWithWeapon == null)
			{
			}
			else
			// PerformFightWithWeapon <> null
			{
				PerformFightWithWeapon -= new cpDelegateFight(HowToFight.UseWeapon);
			}
			// PerformFightWithWeapon = null

		}
		// CleanBehaviour()

		public void Fight()
		//***
		// Action
		//   - If PerformFight is null
		//     - Do nothing
		//   - If Not
		//     - Execute PerformFight
		// Called by
		//   - CopyPaste.Game.Character.Test.cpProgram.Main()
		// Calls
		//   - PerformFightWithWeapon()
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{

			if (PerformFightWithWeapon == null)
			{
			}
			else
			// PerformFightWithWeapon <> null
			{
				PerformFightWithWeapon();
			}
			// PerformFightWithWeapon = null

		}
		// PerformFightWithWeapon()

		public override string ToString()
		//***
		// Action
		//   - Define how the cpGameCharacter class name is shown
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			return this.GetType().Name;
		}
		// string ToString()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpGameCharacter

}
// CopyPaste.Game.Character.Library