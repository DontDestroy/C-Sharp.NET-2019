//***
// Action
//   - Sending a mail
// Created
//   - CopyPaste � 20240412 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240412 � VVDW
// Proposal (To Do)
//   - This will only work when the correct information is given for the SmtpClient (the wrong password is given)
//   - This is legacy code
//   - Make sure that there is no 2-way security set up for the emailaddress
//***

using System;
using System.Net;
using System.Net.Mail;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create a new mail message
      //   - Set the server where you will send the mail with
      //   - Define a body, from, to and subject
      //   - Send the mail
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240412 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240412 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MailAddress theFrom;
      MailAddress theTo;
      MailMessage theMailMessage;
      SmtpClient theSmtpMail = new SmtpClient();

      theSmtpMail.Host = "smtp.gmail.com";
      theSmtpMail.Port = 587;
      theSmtpMail.UseDefaultCredentials = true;
      theSmtpMail.Credentials = new NetworkCredential("vincent.copypaste.vandewalle@gmail.com", "123abc");
      theSmtpMail.EnableSsl = true;

      theFrom = new MailAddress("vincent.copypaste.vandewalle@gmail.com");
      theTo = new MailAddress("Info@CopyPaste.Be");

      theMailMessage = new MailMessage(theFrom, theTo);

      theMailMessage.Body = "Demo message from a program";
      theMailMessage.Subject = "Demo Message";
      theSmtpMail.Send(theMailMessage);
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning