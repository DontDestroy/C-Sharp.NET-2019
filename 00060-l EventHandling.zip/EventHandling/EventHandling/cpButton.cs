﻿//***
// Action
//   - A specific button with a specific runned code on Click
// Created
//   - CopyPaste – 20220902 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220902 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;
using System.Windows.Controls;

namespace EventHandles
{

  public class cpButton : Button
  {

    #region "Constructors / Destructors"

    static cpButton()
    //***
    // Action
    //   - Create a new instance of cpButton
    // Called by
    //   - Used in wpfClassLevelEvent.xaml
    // Calls
    //   - cpButtonClickMethod(System.Object, System.Windows.RoutedEventArgs) Handles cpButton.Click
    // Created
    //   - CopyPaste – 20220902 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220902 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      RoutedEventHandler cpButtonClick = new RoutedEventHandler(cpButtonClickMethod);
    
      EventManager.RegisterClassHandler(typeof(cpButton), ClickEvent, cpButtonClick);
    }
    // cpButton()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private static void cpButtonClickMethod(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Show a message that proves that this event is triggered (before the specific button event)
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - cpButtonClickMethod()
    // Created
    //   - CopyPaste – 20220902 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220902 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      MessageBox.Show("You have clicked the cpButton");
    }
    // cpButtonClickMethod(System.Object, System.Windows.RoutedEventArgs) Handles cpButton.Click

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpButton

}
// EventHandles