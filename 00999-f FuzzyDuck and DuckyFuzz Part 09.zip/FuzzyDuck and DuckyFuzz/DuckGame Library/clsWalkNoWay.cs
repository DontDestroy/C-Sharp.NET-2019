﻿//***
// Action
//   - Implementation of a cpWalkNoWay
//		 - The way a thing can't walk on the ground
// Created
//   - CopyPaste – 20240727 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240727 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Animal.Library
{

	public class cpWalkNoWay : cpiWalk
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpWalkNoWay
		/// </summary>
		public cpWalkNoWay()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - cpDecoyDuck() (indirectly, thru delegate)
		//   - cpPlasticRubberDuck() (indirectly, thru delegate)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpWalkNoWay()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing does not moving on the ground
		/// </summary>
		public void Walk()
		//***
		// Action
		//   - Define how something is not able to walk
		// Called by
		//   - cpDecoyDuck()
		//   - cpPlasticRubberDuck()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Something can't move around on the ground");
		}
		// Walk()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpWalkNoWay

}
// CopyPaste.Game.Animal.Library