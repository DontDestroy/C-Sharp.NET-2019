//***
// Action
//   - Demo of the use of docking and anchoring
// Created
//   - CopyPaste � 20240520 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240520 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmAnchorDock: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdAlign;
    internal System.Windows.Forms.TextBox txtText;
    internal System.Windows.Forms.PictureBox picBox;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmAnchorDock));
      this.cmdAlign = new System.Windows.Forms.Button();
      this.txtText = new System.Windows.Forms.TextBox();
      this.picBox = new System.Windows.Forms.PictureBox();
      this.SuspendLayout();
      // 
      // cmdAlign
      // 
      this.cmdAlign.Location = new System.Drawing.Point(200, 241);
      this.cmdAlign.Name = "cmdAlign";
      this.cmdAlign.TabIndex = 5;
      this.cmdAlign.Text = "&Align now";
      this.cmdAlign.Click += new System.EventHandler(this.cmdAlign_Click);
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(8, 97);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(272, 128);
      this.txtText.TabIndex = 4;
      this.txtText.Text = "TextBox1";
      // 
      // picBox
      // 
      this.picBox.Image = ((System.Drawing.Image)(resources.GetObject("picBox.Image")));
      this.picBox.Location = new System.Drawing.Point(104, 9);
      this.picBox.Name = "picBox";
      this.picBox.Size = new System.Drawing.Size(80, 80);
      this.picBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picBox.TabIndex = 3;
      this.picBox.TabStop = false;
      // 
      // frmAnchorDock
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdAlign);
      this.Controls.Add(this.txtText);
      this.Controls.Add(this.picBox);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmAnchorDock";
      this.Text = "Anchor + Dock examples";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmAnchorDock'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmAnchorDock()
      //***
      // Action
      //   - Create instance of 'frmAnchorDock'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmAnchorDock()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAlign_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The picture is docked on top of the form
      //   - The command button is anchored on the right and bottom of the form
      //   - The text is anchored on all the sides of the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      picBox.Dock = DockStyle.Top;
      cmdAlign.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
      txtText.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right;
    }
    // cmdAlign_Click(System.Object, System.EventArgs) Handles cmdAlign.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmAnchorDock
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmAnchorDock()
      // Created
      //   - CopyPaste � 20240520 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240520 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmAnchorDock());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmAnchorDock

}
// CopyPaste.Learning