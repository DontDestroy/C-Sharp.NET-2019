﻿//***
// Action
//   - Implementation of Interface cpiValidationRestriction to validate a textbox on decimal number
//   - A decimal number can contain somewhere maximum 1 decimal sign
// Created
//   - CopyPaste – 20250718 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250718 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Globalization;

namespace CopyPaste.Learning
{

  public class cpValidationRestrictionDecimal: cpiValidationRestriction
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public bool Validate(cpctlValidationTextbox theSender, System.Windows.Forms.KeyPressEventArgs theKeyPressEventArgs )
      //***
      // Action
      //   - Test of a character typed can be part of a decimal number
      //   - Find the decimal separator on the settings of the operating system
      //   - If the typed character is the separator and it is the first time that it was typed or it is a number
      //     - Return True
      //   - If not
      //     - Return False
      // Called by
      //   - cpctlValidationTextbox.OnKeyPress(KeyPressEventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250718 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250718 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strSeparator = NumberFormatInfo.CurrentInfo.NumberDecimalSeparator;

      return ((theKeyPressEventArgs.KeyChar.ToString() == strSeparator) &&
        theSender.Text.IndexOfAny(strSeparator.ToCharArray()) == -1) ||
        Char.IsNumber(theKeyPressEventArgs.KeyChar);
    }
    // Validate(cpctlValidationTextbox, System.Windows.Forms.KeyPressEventArgs) As Boolean Implements cpiValidationRestriction.Validate

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpValidationRestrictionDecimal

}
// CopyPaste.Learning