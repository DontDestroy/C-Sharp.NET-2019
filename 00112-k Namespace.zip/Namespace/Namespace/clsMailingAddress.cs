//***
// Action
//   - Implementation of cpAddress (Namespace Mailing)
// Created
//   - CopyPaste � 20240410 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240410 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Mailing
{

  public class cpAddress
  {

    #region "Constructors / Destructors"

    public cpAddress(string strStreet, string strCity, string strState, string strZip)
      //***
      // Action
      //   - Constructor of cpAddress with City, State, Street and Zipcode
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240410 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240410 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrCity = strCity;
      mstrState = strState;
      mstrStreet = strStreet;
      mstrZip = strZip;
    }
    // cpAddress(string, string, string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    private string mstrCity;
    private string mstrState;
    private string mstrStreet;
    private string mstrZip;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Constructs the information of an Address
      //   - The street, city, state and zipcode
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240410 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240410 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strResult = "";

      strResult += "Street: " + mstrStreet + Environment.NewLine;
      strResult += "City: " + mstrCity + Environment.NewLine;
      strResult += "State: " + mstrState + Environment.NewLine;
      strResult += "Zip: " + mstrZip + Environment.NewLine;

      return strResult;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpAddress

}
// Mailing