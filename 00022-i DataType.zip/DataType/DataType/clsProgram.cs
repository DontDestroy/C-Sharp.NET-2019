//***
// Action
//   - The basic methods of an object
// Created
//   - CopyPaste � 20240423 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240423 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Explanation of the code in this method
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Test1()
      //   - Test2()
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Test1();
      Test2();
    }
		// Main()

    private static void Test1()
      //***
      // Action
      //   - Create 2 new collections
      //   - Create 2 variables with value 12
      //   - Add 12 to the collections
      //   - Show the information of the content of the variables and collections
      //   - First collection becomes second collection
      //   - Show the information of the content of the collections
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      ArrayList colFirst = new ArrayList();
      ArrayList colSecond = new ArrayList();
      int lngFirst = 12;
      int lngSecond = 12;

      colFirst.Add(12);
      colSecond.Add(12);

      MessageBox.Show("lngFirst (" + lngFirst + ") = lngSecond (" + lngSecond + ") : " + lngFirst.Equals(lngSecond).ToString(), "Copy Paste");
      MessageBox.Show("colFirst (" + colFirst[0].ToString() + ") = colSecond (" + colSecond[0].ToString() + ") : " + colFirst.Equals(colSecond).ToString(), "Copy Paste");
      colFirst = colSecond;
      MessageBox.Show("colFirst (" + colFirst[0].ToString() + ") = colSecond (" + colSecond[0].ToString() + ") : " + colFirst.Equals(colSecond).ToString(), "Copy Paste");
    }
    // Test1()

    private static void Test2()
      //***
      // Action
      //   - Create two variables with data type object
      //   - First object becomes a text
      //   - Second object is a number
      //   - Show the information (get type) of the 2 variables
      //   - Show the information (hash code) of the 2 variables
      //   - Show if both objects are equal
      //   - First object becomes second object
      //   - Show the information (get type) of the 2 variables
      //   - Show the information (hash code) of the 2 variables
      //   - Show if both objects are equal
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240423 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240423 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      System.Object theObjectFirst = new System.Object();
      System.Object theObjectSecond = new System.Object();

      theObjectFirst = "Hello C# .NET";
      theObjectSecond = 42;

      MessageBox.Show("Type First Object : " + theObjectFirst.GetType().ToString() + Environment.NewLine + "Type Second Object : " + theObjectSecond.GetType().ToString());
      MessageBox.Show("HashCode First Object : " + theObjectFirst.GetHashCode().ToString() + Environment.NewLine + "HashCode Second Object : " + theObjectSecond.GetHashCode().ToString());
      MessageBox.Show("Object are equal : " + theObjectFirst.Equals(theObjectSecond).ToString());
      theObjectFirst = theObjectSecond;
      MessageBox.Show("Type First Object : " + theObjectFirst.GetType().ToString() + Environment.NewLine + "Type Second Object : " + theObjectSecond.GetType().ToString());
      MessageBox.Show("HashCode First Object : " + theObjectFirst.GetHashCode().ToString() + Environment.NewLine + "HashCode Second Object : " + theObjectSecond.GetHashCode().ToString());
      MessageBox.Show("Object are equal : " + theObjectFirst.Equals(theObjectSecond).ToString());
    }
    // Test2()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning