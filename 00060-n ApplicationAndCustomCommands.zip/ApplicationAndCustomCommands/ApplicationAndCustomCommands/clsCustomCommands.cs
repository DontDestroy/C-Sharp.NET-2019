﻿//***
// Action
//   - Define a Custom Command
//     - Used in menu, button and with Ctrl+L
// Created
//   - CopyPaste – 20220906 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220906 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Input;

namespace ApplicationAndCustomCommands
{

  public class cpCustomCommands
  {

    #region "Constructors / Destructors"

    static cpCustomCommands()
    //***
    // Action
    //   - Create instance of 'cpCustomCommands' (static)
    //   - Create an Input Gesture
    //     - Add key combination Ctrl+L to the Input Gesture
    //   - Link the Input Gesture and the Handler to the Command
    // Called by
    //   - 
    // Calls
    //   - System.Windows.Input.RoutedUICommand Launch (Get)
    // Created
    //   - CopyPaste – 20220906 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220906 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      System.Windows.Input.InputGestureCollection myInputGestures = new System.Windows.Input.InputGestureCollection();
      myInputGestures.Add(new KeyGesture(Key.L, ModifierKeys.Control));
      theLaunchCommand = new System.Windows.Input.RoutedUICommand("Launch", "Launch", typeof(cpCustomCommands), myInputGestures);
    }
    // cpCustomCommands()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static System.Windows.Input.RoutedUICommand theLaunchCommand;

    #endregion

    #region "Properties"

    public static System.Windows.Input.RoutedUICommand Launch
    {

      get
      //***
      // Action Get
      //   - Returns the command to launch
      // Called by
      //   - cpCustomCommands()
      //   - wpfApplicationAndCustomCommands()
      //   - wpfApplicationAndCustomCommands.cmdCustom.Command()
      //   - wpfApplicationAndCustomCommands.mnuItemLaunchCustomCommand.Command()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return theLaunchCommand;
      }
      // System.Windows.Input.RoutedUICommand Launch (Get)

    }
    // System.Windows.Input.RoutedUICommand Launch

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpCustomCommands

}
// ApplicationAndCustomCommands