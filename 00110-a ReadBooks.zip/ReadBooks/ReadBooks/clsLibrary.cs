//***
// Action
//   - Implementation of a cpLibrary
//   - This is a collection of cpBooks (SortedList)
// Created
//   - CopyPaste � 20240106 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240106 � VVDW
// Proposal (To Do)
//   -
//***

using System.Collections;

namespace CopyPaste.Learning
{

  public class cpLibrary
	{

		#region "Constructors / Destructors"

    public cpLibrary()
      //***
      // Action
      //   - Empty Constructor
      // Called by
      //   - frmReadBooks.frmReadBooks_Load(System.Object, System.EventArgs) Handles MyBase.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpLibrary()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

    private SortedList msrlShelf = new SortedList();

    #endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

    public void CheckIn(cpBook thecpBook)
      //***
      // Action
      //   - A book is added to the library
      //   - You need a key, that will be the title of the cpBook
      //   - The item is the cpBook itself
      // Called by
      //   - frmReadBooks.frmReadBooks_Load(System.Object, System.EventArgs) Handles MyBase.Load
      //   - frmReadBooks.lstBooks_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBooks.SelectedIndexChanged
      // Calls
      //   - string cpBook.Title (Get)
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      msrlShelf.Add(thecpBook.Title, thecpBook);
    }
    // CheckIn(cpBook thecpBook)
		
    public cpBook CheckOut(string strTitle)
      //***
      // Action
      //   - A book is removed from the library
      //   - You need a key, to find what book must be removed
      //   - Find the object in the SortedList
      //   - Cast this object to a cpBook
      //   - Remove it from the list
      //   - The removed book is returned
      // Called by
      //   - frmReadBooks.lstBooks_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBooks.SelectedIndexChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBook thecpBook;

      thecpBook = (cpBook)msrlShelf[strTitle];
      // thecpBook = msrlShelf[strTitle] as cpBook;
      // Both statements are the same, except when the object to cast is null
      // Specific casting generates an error
      // Casting as a type generates a null object

      msrlShelf.Remove(strTitle);

      return thecpBook;
    }
    // CheckOut(string strTitle)

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpLibrary

}
// CopyPaste.Learning