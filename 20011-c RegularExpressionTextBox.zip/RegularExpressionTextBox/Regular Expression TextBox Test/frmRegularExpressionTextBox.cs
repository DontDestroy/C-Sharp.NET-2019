//***
// Action
//   - Demo of a textbox with regular expression to validate the typed content
// Created
//   - CopyPaste � 20260509 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260509 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmRegularExpressionTextboxTester: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblDateExample;
    internal System.Windows.Forms.Label lblZipCodeExample;
    internal System.Windows.Forms.Button cmdOK;
    internal System.Windows.Forms.Label lblBirthDate;
    internal System.Windows.Forms.Label lblZipCode;
    internal System.Windows.Forms.Label lblName;
    internal CopyPaste.Learning.cpctlRegularExpressionTextBox txtBirthdate;
    internal CopyPaste.Learning.cpctlRegularExpressionTextBox txtName;
    internal CopyPaste.Learning.cpctlRegularExpressionTextBox txtZipCode;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmRegularExpressionTextboxTester));
      this.lblDateExample = new System.Windows.Forms.Label();
      this.lblZipCodeExample = new System.Windows.Forms.Label();
      this.cmdOK = new System.Windows.Forms.Button();
      this.lblBirthDate = new System.Windows.Forms.Label();
      this.lblZipCode = new System.Windows.Forms.Label();
      this.lblName = new System.Windows.Forms.Label();
      this.txtBirthdate = new CopyPaste.Learning.cpctlRegularExpressionTextBox();
      this.txtName = new CopyPaste.Learning.cpctlRegularExpressionTextBox();
      this.txtZipCode = new CopyPaste.Learning.cpctlRegularExpressionTextBox();
      this.SuspendLayout();
      // 
      // lblDateExample
      // 
      this.lblDateExample.Location = new System.Drawing.Point(256, 112);
      this.lblDateExample.Name = "lblDateExample";
      this.lblDateExample.Size = new System.Drawing.Size(96, 16);
      this.lblDateExample.TabIndex = 16;
      this.lblDateExample.Text = "e.g. dd/mm/yyyy";
      this.lblDateExample.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
      // 
      // lblZipCodeExample
      // 
      this.lblZipCodeExample.Location = new System.Drawing.Point(72, 112);
      this.lblZipCodeExample.Name = "lblZipCodeExample";
      this.lblZipCodeExample.Size = new System.Drawing.Size(104, 16);
      this.lblZipCodeExample.TabIndex = 13;
      this.lblZipCodeExample.Text = "e.g. B-1234";
      this.lblZipCodeExample.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
      // 
      // cmdOK
      // 
      this.cmdOK.Location = new System.Drawing.Point(288, 136);
      this.cmdOK.Name = "cmdOK";
      this.cmdOK.Size = new System.Drawing.Size(64, 23);
      this.cmdOK.TabIndex = 17;
      this.cmdOK.Text = "OK";
      this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
      // 
      // lblBirthDate
      // 
      this.lblBirthDate.Location = new System.Drawing.Point(192, 88);
      this.lblBirthDate.Name = "lblBirthDate";
      this.lblBirthDate.Size = new System.Drawing.Size(56, 16);
      this.lblBirthDate.TabIndex = 14;
      this.lblBirthDate.Text = "Birth Date";
      this.lblBirthDate.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
      // 
      // lblZipCode
      // 
      this.lblZipCode.Location = new System.Drawing.Point(8, 88);
      this.lblZipCode.Name = "lblZipCode";
      this.lblZipCode.Size = new System.Drawing.Size(56, 16);
      this.lblZipCode.TabIndex = 11;
      this.lblZipCode.Text = "Zip Code";
      this.lblZipCode.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
      // 
      // lblName
      // 
      this.lblName.Location = new System.Drawing.Point(8, 32);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(48, 16);
      this.lblName.TabIndex = 9;
      this.lblName.Text = "Name";
      this.lblName.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
      // 
      // txtBirthdate
      // 
      this.txtBirthdate.Location = new System.Drawing.Point(256, 88);
      this.txtBirthdate.Name = "txtBirthdate";
      this.txtBirthdate.RegularExpression = null;
      this.txtBirthdate.TabIndex = 15;
      this.txtBirthdate.Text = "";
      // 
      // txtName
      // 
      this.txtName.Location = new System.Drawing.Point(64, 32);
      this.txtName.Name = "txtName";
      this.txtName.RegularExpression = null;
      this.txtName.Size = new System.Drawing.Size(288, 20);
      this.txtName.TabIndex = 10;
      this.txtName.Text = "";
      // 
      // txtZipCode
      // 
      this.txtZipCode.Location = new System.Drawing.Point(72, 88);
      this.txtZipCode.Name = "txtZipCode";
      this.txtZipCode.RegularExpression = null;
      this.txtZipCode.TabIndex = 12;
      this.txtZipCode.Text = "";
      // 
      // frmRegularExpressionTextboxTester
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(376, 174);
      this.Controls.Add(this.lblDateExample);
      this.Controls.Add(this.lblZipCodeExample);
      this.Controls.Add(this.cmdOK);
      this.Controls.Add(this.lblBirthDate);
      this.Controls.Add(this.lblZipCode);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.txtBirthdate);
      this.Controls.Add(this.txtName);
      this.Controls.Add(this.txtZipCode);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmRegularExpressionTextboxTester";
      this.Text = "Generic Entry Form";
      this.Load += new System.EventHandler(this.frmRegularExpressionTextboxTester_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmRegularExpressionTextboxTester'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260509 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260509 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmRegularExpressionTextboxTester()
      //***
      // Action
      //   - Create instance of 'frmRegularExpressionTextboxTester'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260509 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260509 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmRegularExpressionTextboxTester()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdOK_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Close the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260509 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260509 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // cmdOK_Click(System.Object, System.EventArgs)

    private void frmRegularExpressionTextboxTester_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the regular expression for a Belgian zipcode
      //   - Set the regular expression for a Belgian date (day/month/year)
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - cpctlRegularExpressionTextBox.RegularExpression(String) (Set)
      // Created
      //   - CopyPaste � 20260509 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260509 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtZipCode.RegularExpression = @"[B][-]\d{4}";
      txtBirthdate.RegularExpression = @"^(?<day>\d{1,2})/(?<month>\d{1,2})/(?<year>\d{2,4})$";
    }
    // frmRegularExpressionTextboxTester_Load(System.Object, System.EventArgs)

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmRegularExpressionTextboxTester
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmRegularExpressionTextboxTester()
      // Created
      //   - CopyPaste � 20260509 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260509 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmRegularExpressionTextboxTester());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmRegularExpressionTextboxTester

}
// CopyPaste.Learning