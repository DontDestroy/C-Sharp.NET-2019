'***
' Action
'   - Variables and assignment in one line
' Created
'   - CopyPaste � 20210824 � VVDW
' Changed
'   - Organisation � yyyymmdd � Initials of programmer � What changed
' Tested
'   - CopyPaste � 20210824 � VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On 
Option Strict On

Public Module modVariableObjects

  Public Sub Main()
    '***
    ' Action
    '   - Initialise some variables
    '   - Show the type minimum value and maximum value on the console screen
    '     - Two exceptions: Boolean and String does not have a minimum and maximum value
    '   - Wait for user action
    ' Called by
    '   - 
    ' Calls
    '   - System.Console.ReadLine()
    '   - System.Console.WriteLine(String)
    '   - System.Console.WriteLine(String, System.Object)
    '   - System.Console.WriteLine(String, System.Object, System.Object, System.Object)
    ' Created
    '   - CopyPaste � 20210824 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210824 � VVDW
    ' Keyboard key
    '   -
    ' Proposal (To Do)
    '   -
    '***

    Dim blnMarried As Boolean = True
    Dim bytAsciiCode As Byte = 17
    Dim chrMiddleInitial As Char = "V"c
    Dim dblCarLoan As Double = 23752.65
    Dim decHomeLoan As Decimal = 137240.25D
    Dim dtmBirthDate As Date = #5/6/1970#
    Dim intShoeSize As Integer = 42
    Dim lngWeight As Long = 179
    Dim objSomething As Object = "a nice message"
    Dim shtAge As Short = 50
    Dim sngAnnualIncome As Single = 12345.67
    Dim strAddress As String = "C. Ameyestraat"

    Console.WriteLine("THE VARIABLE OBJECTS PROGRAM")
    Console.WriteLine("----------------------------")
    Console.WriteLine("Married = {0}, ({1} to {2}).", _
        blnMarried.GetType, Boolean.TrueString, Boolean.FalseString)
    Console.WriteLine("AsciiCode = {0}, ({1} to {2}).", _
        bytAsciiCode.GetType, Byte.MinValue, Byte.MaxValue)
    Console.WriteLine("MiddleInitial = {0}.", chrMiddleInitial.GetType)
    Console.WriteLine("CarLoan = {0}, ({1} to {2}).", _
        dblCarLoan.GetType, Double.MinValue, Double.MaxValue)
    Console.WriteLine("HomeLoan = {0}, ({1} to {2}).", _
        decHomeLoan.GetType, Decimal.MinValue, Decimal.MaxValue)
    Console.WriteLine("BirthDate = {0}, ({1} to {2}).", _
        dtmBirthDate.GetType, DateTime.MinValue, DateTime.MaxValue)
    Console.WriteLine("ShoeSize = {0}, ({1} to {2}).", _
        intShoeSize.GetType, Integer.MinValue, Integer.MaxValue)
    Console.WriteLine("Weight = {0}, ({1} to {2}).", _
        lngWeight.GetType, Long.MinValue, Long.MaxValue)
    Console.WriteLine("Something = {0}.", objSomething.GetType)
    Console.WriteLine("Age = {0}, ({1} to {2}).", _
        shtAge.GetType, Short.MinValue, Short.MaxValue)
    Console.WriteLine("AnnualIncome = {0}, ({1} to {2}).", _
        sngAnnualIncome.GetType, Single.MinValue, Single.MaxValue)
    Console.WriteLine("Address = {0}.", strAddress.GetType)
    Console.WriteLine("")
    Console.WriteLine("Press Enter...")
    Console.ReadLine()
  End Sub
  ' Main()

End Module
' modVariableObjects