﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCopyPasteCoffeeContest.aspx.cs" Inherits="CopyPaste.Learning.wfrmCopyPasteCoffeeContest" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Copy Paste Coffee Contest</title>
</head>
<body>
  <!-- form id="wfrmCopyPasteCoffeeContest" action="https://yourWebsite/yourPath/Contest.php" method="post"-->
  <form id="wfrmCopyPasteCoffeeContest" action="wfrmCopyPasteCoffeeContestAnswer.aspx" method="post">
    <p>
      Just type in your name (and click Submit) to enter the contest:<br>
      First name:
        <input type="text" name="firstname" value=""><br>
      Last name: 
        <input type="text" name="lastname" value=""><br>
      <input type="submit">
    </p>
  </form>
</body>
</html>
