﻿//***
// Action
//   - ProductCategory class (in Models)
// Created
//   - CopyPaste – 20220824 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220824 – VVDW
// Proposal (To Do)
//   -
//***

using ProductCategory_WPF_MVVM.Utilities;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProductCategory_WPF_MVVM.Models
{

  public class ProductCategory : ObservableObject
  {

    #region "Constructors / Destructors"

    public ProductCategory()
    //***
    // Action
    //   - Create an instance of 'ProductCategory'
    // Called by
    //   - 
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
    }
    // ProductCategory()

    public ProductCategory(int intIdProductCategory, string strCategoryName)
    //***
    // Action
    //   - Create an instance of 'ProductCategory'
    //     - Fill the property Key
    //     - Fill the property Name
    // Called by
    //   - MockDataService.FillProductCategory()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Key = intIdProductCategory;
      Name = strCategoryName;
    }
    // ProductCategory(int, string)


    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int _intIdProductCategory;
    private string _strCategoryName;

    #endregion

    #region "Properties"

    public int Key
    {

      get
      //***
      // Action Get
      //   - Return _intIdProductCategory
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _intIdProductCategory;
      }
      // int Key (Get)

      set
      //***
      // Action Set
      //   - Sets _intIdProductCategory with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - 
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        OnPropertyChanged(ref _intIdProductCategory, value);
      }
      // Key(int) (Set)

    }
    // int Key

    public string Name
    {

      get
      //***
      // Action Get
      //   - Return _strCategoryName
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _strCategoryName;
      }
      // string Name (Get)

      set
      //***
      // Action Set
      //   - Sets _strCategoryName with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - 
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        OnPropertyChanged(ref _strCategoryName, value);
      }
      // Name(string) (Set)

    }
    // string Name

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // ProductCategory

}
// ProductCategory_WPF_MVVM.Models