//***
// Action
//   - Form created with a wizard
//   - Changed to be in line with Copy Paste Requirements
// Created
//   - CopyPaste � 20251122 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251122 � VVDW
// Proposal (To Do)
//   - 
//***

using DataFormWizard;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDataWizardChanged: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdUpdate;
    internal System.Data.OleDb.OleDbCommand cmmUpdateCategory;
    internal System.Data.OleDb.OleDbConnection cnncpNorthwindScript;
    internal System.Windows.Forms.Button cmdCancelAll;
    internal System.Windows.Forms.DataGrid dgrCategory;
    internal System.Windows.Forms.DataGridTableStyle objTableStylegrdtblCPCategorytblCPCategory;
    internal System.Windows.Forms.DataGridTextBoxColumn objColumnStylegrdtblCPCategoryintIdCategory;
    internal System.Windows.Forms.DataGridTextBoxColumn objColumnStylegrdtblCPCategorystrCategoryName;
    internal System.Windows.Forms.DataGridTextBoxColumn objColumnStylegrdtblCPCategorymemDescription;
    internal System.Data.OleDb.OleDbCommand cmmSelectProduct;
    internal System.Data.OleDb.OleDbCommand cmmDeleteCategory;
    internal System.Data.OleDb.OleDbDataAdapter dtaCategory;
    internal System.Data.OleDb.OleDbCommand cmmInsertCategory;
    internal System.Data.OleDb.OleDbCommand cmmSelectCategory;
    internal System.Data.OleDb.OleDbCommand cmmInsertProduct;
    internal System.Data.OleDb.OleDbCommand cmmDeleteProduct;
    internal System.Windows.Forms.Button cmdLoad;
    internal System.Data.OleDb.OleDbCommand cmmUpdateProduct;
    internal System.Data.OleDb.OleDbDataAdapter dtaProduct;
    private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn1;
    private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn2;
    private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn3;
    private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn4;
    private System.Windows.Forms.DataGridTextBoxColumn dataGridTextBoxColumn5;
    internal System.Windows.Forms.DataGrid dgrProduct;
    internal System.Windows.Forms.DataGridTableStyle objTableStylegrdtblCPProducttblCPProduct;
    internal System.Windows.Forms.DataGridTextBoxColumn objColumnStylegrdtblCPProductintIdProduct;
    private DataFormWizard.dsData dsData;
    internal System.Windows.Forms.DataGridTextBoxColumn objColumnStylegrdtblCPProductdblUnitPrice;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataWizardChanged));
      this.cmdUpdate = new System.Windows.Forms.Button();
      this.cmmUpdateCategory = new System.Data.OleDb.OleDbCommand();
      this.cnncpNorthwindScript = new System.Data.OleDb.OleDbConnection();
      this.cmdCancelAll = new System.Windows.Forms.Button();
      this.dgrCategory = new System.Windows.Forms.DataGrid();
      this.objTableStylegrdtblCPCategorytblCPCategory = new System.Windows.Forms.DataGridTableStyle();
      this.objColumnStylegrdtblCPCategoryintIdCategory = new System.Windows.Forms.DataGridTextBoxColumn();
      this.objColumnStylegrdtblCPCategorystrCategoryName = new System.Windows.Forms.DataGridTextBoxColumn();
      this.objColumnStylegrdtblCPCategorymemDescription = new System.Windows.Forms.DataGridTextBoxColumn();
      this.cmmSelectProduct = new System.Data.OleDb.OleDbCommand();
      this.cmmDeleteCategory = new System.Data.OleDb.OleDbCommand();
      this.dtaCategory = new System.Data.OleDb.OleDbDataAdapter();
      this.cmmInsertCategory = new System.Data.OleDb.OleDbCommand();
      this.cmmSelectCategory = new System.Data.OleDb.OleDbCommand();
      this.cmmInsertProduct = new System.Data.OleDb.OleDbCommand();
      this.cmmDeleteProduct = new System.Data.OleDb.OleDbCommand();
      this.cmdLoad = new System.Windows.Forms.Button();
      this.cmmUpdateProduct = new System.Data.OleDb.OleDbCommand();
      this.dtaProduct = new System.Data.OleDb.OleDbDataAdapter();
      this.dataGridTextBoxColumn1 = new System.Windows.Forms.DataGridTextBoxColumn();
      this.dataGridTextBoxColumn2 = new System.Windows.Forms.DataGridTextBoxColumn();
      this.dataGridTextBoxColumn3 = new System.Windows.Forms.DataGridTextBoxColumn();
      this.dataGridTextBoxColumn4 = new System.Windows.Forms.DataGridTextBoxColumn();
      this.dataGridTextBoxColumn5 = new System.Windows.Forms.DataGridTextBoxColumn();
      this.dgrProduct = new System.Windows.Forms.DataGrid();
      this.objTableStylegrdtblCPProducttblCPProduct = new System.Windows.Forms.DataGridTableStyle();
      this.objColumnStylegrdtblCPProductintIdProduct = new System.Windows.Forms.DataGridTextBoxColumn();
      this.objColumnStylegrdtblCPProductdblUnitPrice = new System.Windows.Forms.DataGridTextBoxColumn();
      this.dsData = new DataFormWizard.dsData();
      ((System.ComponentModel.ISupportInitialize)(this.dgrCategory)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrProduct)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdUpdate
      // 
      this.cmdUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdUpdate.Location = new System.Drawing.Point(315, 9);
      this.cmdUpdate.Name = "cmdUpdate";
      this.cmdUpdate.Size = new System.Drawing.Size(75, 23);
      this.cmdUpdate.TabIndex = 6;
      this.cmdUpdate.Text = "&Update";
      this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
      // 
      // cmmUpdateCategory
      // 
      this.cmmUpdateCategory.CommandText = resources.GetString("cmmUpdateCategory.CommandText");
      this.cmmUpdateCategory.Connection = this.cnncpNorthwindScript;
      this.cmmUpdateCategory.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("strCategoryName", System.Data.OleDb.OleDbType.VarChar, 15, "strCategoryName"),
            new System.Data.OleDb.OleDbParameter("memDescription", System.Data.OleDb.OleDbType.VarChar, 2147483647, "memDescription"),
            new System.Data.OleDb.OleDbParameter("imgPicture", System.Data.OleDb.OleDbType.VarBinary, 2147483647, "imgPicture"),
            new System.Data.OleDb.OleDbParameter("Original_intIdCategory", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdCategory", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strCategoryName", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCategoryName", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Select_intIdCategory", System.Data.OleDb.OleDbType.Integer, 4, "intIdCategory")});
      // 
      // cnncpNorthwindScript
      // 
      this.cnncpNorthwindScript.ConnectionString = "Provider=SQLNCLI11;Data Source=COPYPASTEPOWER\\COPYPASTE;Integrated Security=SSPI;" +
    "Initial Catalog=cpNorthWindScript2019";
      // 
      // cmdCancelAll
      // 
      this.cmdCancelAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdCancelAll.Location = new System.Drawing.Point(315, 42);
      this.cmdCancelAll.Name = "cmdCancelAll";
      this.cmdCancelAll.Size = new System.Drawing.Size(75, 23);
      this.cmdCancelAll.TabIndex = 7;
      this.cmdCancelAll.Text = "Ca&ncel All";
      this.cmdCancelAll.Click += new System.EventHandler(this.cmdCancelAll_Click);
      // 
      // dgrCategory
      // 
      this.dgrCategory.AllowNavigation = false;
      this.dgrCategory.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrCategory.DataMember = "tblCPCategory";
      this.dgrCategory.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrCategory.Location = new System.Drawing.Point(10, 75);
      this.dgrCategory.Name = "dgrCategory";
      this.dgrCategory.Size = new System.Drawing.Size(380, 250);
      this.dgrCategory.TabIndex = 8;
      this.dgrCategory.TableStyles.AddRange(new System.Windows.Forms.DataGridTableStyle[] {
            this.objTableStylegrdtblCPCategorytblCPCategory});
      // 
      // objTableStylegrdtblCPCategorytblCPCategory
      // 
      this.objTableStylegrdtblCPCategorytblCPCategory.DataGrid = this.dgrCategory;
      this.objTableStylegrdtblCPCategorytblCPCategory.GridColumnStyles.AddRange(new System.Windows.Forms.DataGridColumnStyle[] {
            this.objColumnStylegrdtblCPCategoryintIdCategory,
            this.objColumnStylegrdtblCPCategorystrCategoryName,
            this.objColumnStylegrdtblCPCategorymemDescription});
      this.objTableStylegrdtblCPCategorytblCPCategory.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.objTableStylegrdtblCPCategorytblCPCategory.MappingName = "tblCPCategory";
      // 
      // objColumnStylegrdtblCPCategoryintIdCategory
      // 
      this.objColumnStylegrdtblCPCategoryintIdCategory.Format = "";
      this.objColumnStylegrdtblCPCategoryintIdCategory.FormatInfo = null;
      this.objColumnStylegrdtblCPCategoryintIdCategory.HeaderText = "intIdCategory";
      this.objColumnStylegrdtblCPCategoryintIdCategory.MappingName = "intIdCategory";
      this.objColumnStylegrdtblCPCategoryintIdCategory.Width = 75;
      // 
      // objColumnStylegrdtblCPCategorystrCategoryName
      // 
      this.objColumnStylegrdtblCPCategorystrCategoryName.Format = "";
      this.objColumnStylegrdtblCPCategorystrCategoryName.FormatInfo = null;
      this.objColumnStylegrdtblCPCategorystrCategoryName.HeaderText = "strCategoryName";
      this.objColumnStylegrdtblCPCategorystrCategoryName.MappingName = "strCategoryName";
      this.objColumnStylegrdtblCPCategorystrCategoryName.Width = 75;
      // 
      // objColumnStylegrdtblCPCategorymemDescription
      // 
      this.objColumnStylegrdtblCPCategorymemDescription.Format = "";
      this.objColumnStylegrdtblCPCategorymemDescription.FormatInfo = null;
      this.objColumnStylegrdtblCPCategorymemDescription.HeaderText = "memDescription";
      this.objColumnStylegrdtblCPCategorymemDescription.MappingName = "memDescription";
      this.objColumnStylegrdtblCPCategorymemDescription.Width = 75;
      // 
      // cmmSelectProduct
      // 
      this.cmmSelectProduct.CommandText = "SELECT intIdProduct, strProductName, intSupplierId, intCategoryId, strQuantityPer" +
    "Unit, dblUnitPrice, intUnitsInStock, intUnitsOnOrder, intReorderLevel, blnDiscon" +
    "tinued FROM tblCPProduct";
      this.cmmSelectProduct.Connection = this.cnncpNorthwindScript;
      // 
      // cmmDeleteCategory
      // 
      this.cmmDeleteCategory.CommandText = "DELETE FROM tblCPCategory WHERE (intIdCategory = ?) AND (strCategoryName = ?)";
      this.cmmDeleteCategory.Connection = this.cnncpNorthwindScript;
      this.cmmDeleteCategory.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("Original_intIdCategory", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdCategory", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strCategoryName", System.Data.OleDb.OleDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCategoryName", System.Data.DataRowVersion.Original, null)});
      // 
      // dtaCategory
      // 
      this.dtaCategory.DeleteCommand = this.cmmDeleteCategory;
      this.dtaCategory.InsertCommand = this.cmmInsertCategory;
      this.dtaCategory.SelectCommand = this.cmmSelectCategory;
      this.dtaCategory.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCategory", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdCategory", "intIdCategory"),
                        new System.Data.Common.DataColumnMapping("strCategoryName", "strCategoryName"),
                        new System.Data.Common.DataColumnMapping("memDescription", "memDescription"),
                        new System.Data.Common.DataColumnMapping("imgPicture", "imgPicture")})});
      this.dtaCategory.UpdateCommand = this.cmmUpdateCategory;
      // 
      // cmmInsertCategory
      // 
      this.cmmInsertCategory.CommandText = resources.GetString("cmmInsertCategory.CommandText");
      this.cmmInsertCategory.Connection = this.cnncpNorthwindScript;
      this.cmmInsertCategory.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("strCategoryName", System.Data.OleDb.OleDbType.VarChar, 15, "strCategoryName"),
            new System.Data.OleDb.OleDbParameter("memDescription", System.Data.OleDb.OleDbType.VarChar, 2147483647, "memDescription"),
            new System.Data.OleDb.OleDbParameter("imgPicture", System.Data.OleDb.OleDbType.VarBinary, 2147483647, "imgPicture")});
      // 
      // cmmSelectCategory
      // 
      this.cmmSelectCategory.CommandText = "SELECT intIdCategory, strCategoryName, memDescription, imgPicture FROM tblCPCateg" +
    "ory";
      this.cmmSelectCategory.Connection = this.cnncpNorthwindScript;
      // 
      // cmmInsertProduct
      // 
      this.cmmInsertProduct.CommandText = resources.GetString("cmmInsertProduct.CommandText");
      this.cmmInsertProduct.Connection = this.cnncpNorthwindScript;
      this.cmmInsertProduct.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("strProductName", System.Data.OleDb.OleDbType.VarChar, 40, "strProductName"),
            new System.Data.OleDb.OleDbParameter("intSupplierId", System.Data.OleDb.OleDbType.Integer, 4, "intSupplierId"),
            new System.Data.OleDb.OleDbParameter("intCategoryId", System.Data.OleDb.OleDbType.Integer, 4, "intCategoryId"),
            new System.Data.OleDb.OleDbParameter("strQuantityPerUnit", System.Data.OleDb.OleDbType.VarChar, 20, "strQuantityPerUnit"),
            new System.Data.OleDb.OleDbParameter("dblUnitPrice", System.Data.OleDb.OleDbType.Currency, 8, "dblUnitPrice"),
            new System.Data.OleDb.OleDbParameter("intUnitsInStock", System.Data.OleDb.OleDbType.SmallInt, 2, "intUnitsInStock"),
            new System.Data.OleDb.OleDbParameter("intUnitsOnOrder", System.Data.OleDb.OleDbType.SmallInt, 2, "intUnitsOnOrder"),
            new System.Data.OleDb.OleDbParameter("intReorderLevel", System.Data.OleDb.OleDbType.SmallInt, 2, "intReorderLevel"),
            new System.Data.OleDb.OleDbParameter("blnDiscontinued", System.Data.OleDb.OleDbType.Boolean, 1, "blnDiscontinued")});
      // 
      // cmmDeleteProduct
      // 
      this.cmmDeleteProduct.CommandText = resources.GetString("cmmDeleteProduct.CommandText");
      this.cmmDeleteProduct.Connection = this.cnncpNorthwindScript;
      this.cmmDeleteProduct.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("Original_intIdProduct", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdProduct", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_blnDiscontinued", System.Data.OleDb.OleDbType.Boolean, 1, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "blnDiscontinued", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_dblUnitPrice", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblUnitPrice", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_dblUnitPrice1", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblUnitPrice", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intCategoryId", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intCategoryId1", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intReorderLevel", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReorderLevel", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intReorderLevel1", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReorderLevel", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intSupplierId", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intSupplierId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intSupplierId1", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intSupplierId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsInStock", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsInStock", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsInStock1", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsInStock", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsOnOrder", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsOnOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsOnOrder1", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsOnOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strProductName", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strProductName", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strQuantityPerUnit", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strQuantityPerUnit", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strQuantityPerUnit1", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strQuantityPerUnit", System.Data.DataRowVersion.Original, null)});
      // 
      // cmdLoad
      // 
      this.cmdLoad.Location = new System.Drawing.Point(10, 9);
      this.cmdLoad.Name = "cmdLoad";
      this.cmdLoad.Size = new System.Drawing.Size(75, 23);
      this.cmdLoad.TabIndex = 5;
      this.cmdLoad.Text = "&Load";
      this.cmdLoad.Click += new System.EventHandler(this.cmdLoad_Click);
      // 
      // cmmUpdateProduct
      // 
      this.cmmUpdateProduct.CommandText = resources.GetString("cmmUpdateProduct.CommandText");
      this.cmmUpdateProduct.Connection = this.cnncpNorthwindScript;
      this.cmmUpdateProduct.Parameters.AddRange(new System.Data.OleDb.OleDbParameter[] {
            new System.Data.OleDb.OleDbParameter("strProductName", System.Data.OleDb.OleDbType.VarChar, 40, "strProductName"),
            new System.Data.OleDb.OleDbParameter("intSupplierId", System.Data.OleDb.OleDbType.Integer, 4, "intSupplierId"),
            new System.Data.OleDb.OleDbParameter("intCategoryId", System.Data.OleDb.OleDbType.Integer, 4, "intCategoryId"),
            new System.Data.OleDb.OleDbParameter("strQuantityPerUnit", System.Data.OleDb.OleDbType.VarChar, 20, "strQuantityPerUnit"),
            new System.Data.OleDb.OleDbParameter("dblUnitPrice", System.Data.OleDb.OleDbType.Currency, 8, "dblUnitPrice"),
            new System.Data.OleDb.OleDbParameter("intUnitsInStock", System.Data.OleDb.OleDbType.SmallInt, 2, "intUnitsInStock"),
            new System.Data.OleDb.OleDbParameter("intUnitsOnOrder", System.Data.OleDb.OleDbType.SmallInt, 2, "intUnitsOnOrder"),
            new System.Data.OleDb.OleDbParameter("intReorderLevel", System.Data.OleDb.OleDbType.SmallInt, 2, "intReorderLevel"),
            new System.Data.OleDb.OleDbParameter("blnDiscontinued", System.Data.OleDb.OleDbType.Boolean, 1, "blnDiscontinued"),
            new System.Data.OleDb.OleDbParameter("Original_intIdProduct", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdProduct", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_blnDiscontinued", System.Data.OleDb.OleDbType.Boolean, 1, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "blnDiscontinued", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_dblUnitPrice", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblUnitPrice", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_dblUnitPrice1", System.Data.OleDb.OleDbType.Currency, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblUnitPrice", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intCategoryId", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intCategoryId1", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intReorderLevel", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReorderLevel", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intReorderLevel1", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReorderLevel", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intSupplierId", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intSupplierId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intSupplierId1", System.Data.OleDb.OleDbType.Integer, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intSupplierId", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsInStock", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsInStock", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsInStock1", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsInStock", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsOnOrder", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsOnOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_intUnitsOnOrder1", System.Data.OleDb.OleDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsOnOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strProductName", System.Data.OleDb.OleDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strProductName", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strQuantityPerUnit", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strQuantityPerUnit", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Original_strQuantityPerUnit1", System.Data.OleDb.OleDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strQuantityPerUnit", System.Data.DataRowVersion.Original, null),
            new System.Data.OleDb.OleDbParameter("Select_intIdProduct", System.Data.OleDb.OleDbType.Integer, 4, "intIdProduct")});
      // 
      // dtaProduct
      // 
      this.dtaProduct.DeleteCommand = this.cmmDeleteProduct;
      this.dtaProduct.InsertCommand = this.cmmInsertProduct;
      this.dtaProduct.SelectCommand = this.cmmSelectProduct;
      this.dtaProduct.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPProduct", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdProduct", "intIdProduct"),
                        new System.Data.Common.DataColumnMapping("strProductName", "strProductName"),
                        new System.Data.Common.DataColumnMapping("intSupplierId", "intSupplierId"),
                        new System.Data.Common.DataColumnMapping("intCategoryId", "intCategoryId"),
                        new System.Data.Common.DataColumnMapping("strQuantityPerUnit", "strQuantityPerUnit"),
                        new System.Data.Common.DataColumnMapping("dblUnitPrice", "dblUnitPrice"),
                        new System.Data.Common.DataColumnMapping("intUnitsInStock", "intUnitsInStock"),
                        new System.Data.Common.DataColumnMapping("intUnitsOnOrder", "intUnitsOnOrder"),
                        new System.Data.Common.DataColumnMapping("intReorderLevel", "intReorderLevel"),
                        new System.Data.Common.DataColumnMapping("blnDiscontinued", "blnDiscontinued")})});
      this.dtaProduct.UpdateCommand = this.cmmUpdateProduct;
      // 
      // dataGridTextBoxColumn1
      // 
      this.dataGridTextBoxColumn1.Format = "";
      this.dataGridTextBoxColumn1.FormatInfo = null;
      this.dataGridTextBoxColumn1.HeaderText = "strProductName";
      this.dataGridTextBoxColumn1.MappingName = "strProductName";
      this.dataGridTextBoxColumn1.Width = 75;
      // 
      // dataGridTextBoxColumn2
      // 
      this.dataGridTextBoxColumn2.Format = "";
      this.dataGridTextBoxColumn2.FormatInfo = null;
      this.dataGridTextBoxColumn2.HeaderText = "intSupplierId";
      this.dataGridTextBoxColumn2.MappingName = "intSupplierId";
      this.dataGridTextBoxColumn2.Width = 75;
      // 
      // dataGridTextBoxColumn3
      // 
      this.dataGridTextBoxColumn3.Format = "";
      this.dataGridTextBoxColumn3.FormatInfo = null;
      this.dataGridTextBoxColumn3.HeaderText = "intCategoryId";
      this.dataGridTextBoxColumn3.MappingName = "intCategoryId";
      this.dataGridTextBoxColumn3.Width = 75;
      // 
      // dataGridTextBoxColumn4
      // 
      this.dataGridTextBoxColumn4.Format = "";
      this.dataGridTextBoxColumn4.FormatInfo = null;
      this.dataGridTextBoxColumn4.HeaderText = "strQuantityPerUnit";
      this.dataGridTextBoxColumn4.MappingName = "strQuantityPerUnit";
      this.dataGridTextBoxColumn4.Width = 75;
      // 
      // dataGridTextBoxColumn5
      // 
      this.dataGridTextBoxColumn5.Format = "";
      this.dataGridTextBoxColumn5.FormatInfo = null;
      this.dataGridTextBoxColumn5.HeaderText = "blnDiscontinued";
      this.dataGridTextBoxColumn5.MappingName = "blnDiscontinued";
      this.dataGridTextBoxColumn5.Width = 75;
      // 
      // dgrProduct
      // 
      this.dgrProduct.AllowNavigation = false;
      this.dgrProduct.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrProduct.DataMember = "tblCPCategory.ProductCategory";
      this.dgrProduct.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrProduct.Location = new System.Drawing.Point(10, 335);
      this.dgrProduct.Name = "dgrProduct";
      this.dgrProduct.Size = new System.Drawing.Size(380, 370);
      this.dgrProduct.TabIndex = 9;
      this.dgrProduct.TableStyles.AddRange(new System.Windows.Forms.DataGridTableStyle[] {
            this.objTableStylegrdtblCPProducttblCPProduct});
      // 
      // objTableStylegrdtblCPProducttblCPProduct
      // 
      this.objTableStylegrdtblCPProducttblCPProduct.DataGrid = this.dgrProduct;
      this.objTableStylegrdtblCPProducttblCPProduct.GridColumnStyles.AddRange(new System.Windows.Forms.DataGridColumnStyle[] {
            this.objColumnStylegrdtblCPProductintIdProduct,
            this.dataGridTextBoxColumn1,
            this.dataGridTextBoxColumn2,
            this.dataGridTextBoxColumn3,
            this.dataGridTextBoxColumn4,
            this.objColumnStylegrdtblCPProductdblUnitPrice,
            this.dataGridTextBoxColumn5});
      this.objTableStylegrdtblCPProducttblCPProduct.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.objTableStylegrdtblCPProducttblCPProduct.MappingName = "tblCPProduct";
      // 
      // objColumnStylegrdtblCPProductintIdProduct
      // 
      this.objColumnStylegrdtblCPProductintIdProduct.Format = "";
      this.objColumnStylegrdtblCPProductintIdProduct.FormatInfo = null;
      this.objColumnStylegrdtblCPProductintIdProduct.HeaderText = "intIdProduct";
      this.objColumnStylegrdtblCPProductintIdProduct.MappingName = "intIdProduct";
      this.objColumnStylegrdtblCPProductintIdProduct.Width = 75;
      // 
      // objColumnStylegrdtblCPProductdblUnitPrice
      // 
      this.objColumnStylegrdtblCPProductdblUnitPrice.Format = "";
      this.objColumnStylegrdtblCPProductdblUnitPrice.FormatInfo = null;
      this.objColumnStylegrdtblCPProductdblUnitPrice.HeaderText = "dblUnitPrice";
      this.objColumnStylegrdtblCPProductdblUnitPrice.MappingName = "dblUnitPrice";
      this.objColumnStylegrdtblCPProductdblUnitPrice.Width = 75;
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // frmDataWizardChanged
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(400, 637);
      this.Controls.Add(this.cmdLoad);
      this.Controls.Add(this.dgrProduct);
      this.Controls.Add(this.cmdUpdate);
      this.Controls.Add(this.cmdCancelAll);
      this.Controls.Add(this.dgrCategory);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataWizardChanged";
      this.Text = "frmDataWizardChanged";
      ((System.ComponentModel.ISupportInitialize)(this.dgrCategory)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrProduct)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDataWizardChanged'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251122 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251122 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDataWizardChanged()
      //***
      // Action
      //   - Create instance of 'frmDataWizardChanged'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251122 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251122 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDataWizardChanged()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdCancelAll_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Reject all the changed in the data set
      //     - Nothing will be saved
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251122 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251122 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsData.RejectChanges();
    }
    // cmdCancelAll_Click(System.Object, System.EventArgs) Handles cmdCancelAll.Click

    private void cmdLoad_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to load the data set
      //   - Show error message when it fails
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - LoadDataSet()
      // Created
      //   - CopyPaste � 20251122 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251122 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        LoadDataSet();
      }
      catch (System.Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // cmdLoad_Click(System.Object, System.EventArgs) Handles cmdLoad.Click

    private void cmdUpdate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to update the data set
      //   - Show error message when it fails
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDataSet()
      // Created
      //   - CopyPaste � 20251122 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251122 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        UpdateDataSet();
      }
      catch (System.Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }

    }
    // cmdUpdate_Click(System.Object, System.EventArgs) Handles cmdUpdate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void FillDataSet(dsData theDataSet)
      //***
      // Action
      //   - Do not show constraints errors
      //   - Try to
      //     - Open the connection
      //     - Fill data set with Category info
      //     - Fill data set with Product info
      //   - When if fails throw an exception
      //   - Do show constraints errors
      //   - Close the connection
      // Called by
      //   - LoadDataSet()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251122 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251122 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      theDataSet.EnforceConstraints = false;

      try
      {
        cnncpNorthwindScript.Open();
        dtaCategory.Fill(theDataSet);
        dtaProduct.Fill(theDataSet);
      }
      catch (System.Exception theException)
      {
        throw theException;
      }
      finally
      {
        theDataSet.EnforceConstraints = true;
        cnncpNorthwindScript.Close();
      }

    }
    // FillDataSet(dsData)

    private void LoadDataSet()
      //***
      // Action
      //   - Define a data set
      //   - Initialise the data set
      //   - Try to
      //     - Fill the data set
      //     - Try to
      //       - Set data source of drgProduct to nothing
      //       - Set data source of drgCategory to nothing
      //       - Clear the data set (from the form)
      //       - Merge the defined data set to the data set of the form
      //       - Set data binding for drgCategory
      //       - Set data binding for drgProduct
      //     - When it fails an exception is thrown
      //   - When it fails an exception is thrown
      // Called by
      //   - cmdLoad_Click(System.Object, System.EventArgs) Handles cmdLoad.Click
      // Calls
      //   - FillDataSet(dsData)
      // Created
      //   - CopyPaste � 20251122 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251122 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsData dsTemp;

      dsTemp = new dsData();

      try
      {
        FillDataSet(dsTemp);

        try
        {
          dgrProduct.DataSource = null;
          dgrCategory.DataSource = null;
          dsData.Clear();
          dsData.Merge(dsTemp);
          dgrCategory.SetDataBinding(dsData, "tblCPCategory");
          dgrProduct.SetDataBinding(dsData, "tblCPCategory.ProductCategory");
        }
        catch (System.Exception theException)
        {
          throw theException;
        }
        finally
        {
        }

      }
      catch (System.Exception theException)
      {
        throw theException;
      }
      finally
      {
      }

    }
    // LoadDataSet()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDataWizardChanged
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDataWizardChanged()
      // Created
      //   - CopyPaste � 20251122 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251122 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDataWizardChanged());
    }
    // Main() 

    private void UpdateDataSet()
      //***
      // Action
      //   - Define a data set for the changes
      //   - Initialise the data set of the changes
      //   - Finalize the editing in Category info
      //   - Finalize the editing in Product info
      //   - Get the changes from the data set and put them in the changes data set
      //   - If there are no changes
      //     - Do nothing
      //   - If not
      //     - Try to
      //       - Update the source
      //       - Merge the changes with the dataset
      //       - Accept the changes
      //     - When it fails throw an exception
      // Called by
      //   - cmdUpdate_Click(System.Object, System.EventArgs) Handles cmdUpdate.Click
      // Calls
      //   - UpdateDataSource(dsData)
      // Created
      //   - CopyPaste � 20251122 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251122 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsData dsChanges = new dsData();
      
      this.BindingContext[dsData, "tblCPCategory"].EndCurrentEdit();
      this.BindingContext[dsData, "tblCPProduct"].EndCurrentEdit();

      dsChanges = (dsData)dsData.GetChanges();

      if (dsChanges == null)
      {
      }
      else
        // dsChanges <> null
      {

        try
        {
          UpdateDataSource(dsChanges);
          dsData.Merge(dsChanges);
          dsData.AcceptChanges();
        }
        catch (System.Exception theException)
        {
          throw theException;
        }
        finally
        {
        }

      }
      // dsChanges = null

    }
    // UpdateDataSet()
    
    private void UpdateDataSource(dsData dsChanges)
      //***
      // Action
      //   - Try to
      //     - If there are no changes
      //       - Do nothing
      //     - If not
      //   - When it fails throw an exception
      //     - Open the connection
      //     - Update data set with Category info
      //     - Update data set with Product info
      //   - Close the connection
      // Called by
      //   - UpdateDataSet()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251122 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251122 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        
        if (dsChanges == null)
        {
        }
        else
          // dsChanges <> null
        {
          cnncpNorthwindScript.Open();
          dtaCategory.Update(dsChanges);
          dtaProduct.Update(dsChanges);
        }
        // dsChanges = null
      
      }
      catch (System.Exception theException)
      {
        throw theException;
      }
      finally
      {
        cnncpNorthwindScript.Close();
      }

    }
    // UpdateDataSource(dsData)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataWizardChanged

}
// CopyPaste.Learning