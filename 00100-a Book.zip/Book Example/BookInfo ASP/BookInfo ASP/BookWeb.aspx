﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="BookWeb.aspx.vb" Inherits="BookInfo_ASP.BookWeb" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Book Demo</title>
</head>
<body>
  <center>
    <h1>Show Book Information</h1>
  </center>
  <hr />
  <%
         Dim thecpBook As New CopyPaste.Learning.cpBook("Visual Basic .Net Programming Tips & Techniques", _
            "Jamsa", "McGraw-Hill/Osborne",49.99)

         Response.Write(thecpBook.mstrTitle & "<br/>")
         Response.Write(thecpBook.mstrAuthor & "<br/>")
         Response.Write(thecpBook.mstrPublisher & "<br/>")
         Response.Write(thecpBook.mdblPrice)
  %>
</body>
</html>
