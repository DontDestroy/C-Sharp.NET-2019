﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmDirections.aspx.cs" Inherits="CopyPaste.Learning.wfrmDirections" %>

<!DOCTYPE html>

<html lang="uk" xmlns="http://www.w3.org/1999/html">
<head>
  <title>Copy Paste Directions</title>
  <link type="text/css" rel="stylesheet" href="cssLounge.css">
  <link rel="shortcut icon" href="./CopyPaste.ico">
</head>
<body>
  <form id="wfrmDirections">
    <h1>Directions</h1>
    <h2>From Bruges or Kortrijk E403</h2>
    <p>Take the exit Izegem</p>
    <p>Go direction Izegem for 1 km</p>
    <p>First round point, take exit left</p>
    <p>After 10 meter, directly right</p>
    <p>Straight till red lights after 750 meter</p>
    <p>Second to the left after 450 meter</p>
    <p>Number 54 can be found at your right side - 150 meter</p>
    <p>
      Go back to <a href="wfrmHomePage.aspx">Home</a>
    </p>
  </form>
</body>
</html>
