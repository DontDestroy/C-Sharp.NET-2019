//***
// Action
//   - Create a form with a database connection, data adapter and data set
// Created
//   - CopyPaste � 20250725 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250725 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSQLDataGridTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdUpdate;
    internal System.Windows.Forms.Button cmdRetrieve;
    internal System.Windows.Forms.DataGrid dgrCustomer;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSQLDataGridTryout));
      this.cmdUpdate = new System.Windows.Forms.Button();
      this.cmdRetrieve = new System.Windows.Forms.Button();
      this.dgrCustomer = new System.Windows.Forms.DataGrid();
      ((System.ComponentModel.ISupportInitialize)(this.dgrCustomer)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdUpdate
      // 
      this.cmdUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdUpdate.Location = new System.Drawing.Point(208, 263);
      this.cmdUpdate.Name = "cmdUpdate";
      this.cmdUpdate.Size = new System.Drawing.Size(104, 23);
      this.cmdUpdate.TabIndex = 5;
      this.cmdUpdate.Text = "&Update Database";
      this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
      // 
      // cmdRetrieve
      // 
      this.cmdRetrieve.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdRetrieve.Location = new System.Drawing.Point(40, 263);
      this.cmdRetrieve.Name = "cmdRetrieve";
      this.cmdRetrieve.Size = new System.Drawing.Size(104, 23);
      this.cmdRetrieve.TabIndex = 4;
      this.cmdRetrieve.Text = "&Retrieve Data";
      this.cmdRetrieve.Click += new System.EventHandler(this.cmdRetrieve_Click);
      // 
      // dgrCustomer
      // 
      this.dgrCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrCustomer.DataMember = "";
      this.dgrCustomer.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrCustomer.Location = new System.Drawing.Point(8, 7);
      this.dgrCustomer.Name = "dgrCustomer";
      this.dgrCustomer.Size = new System.Drawing.Size(344, 240);
      this.dgrCustomer.TabIndex = 3;
      // 
      // frmSQLDataGridTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(360, 293);
      this.Controls.Add(this.dgrCustomer);
      this.Controls.Add(this.cmdUpdate);
      this.Controls.Add(this.cmdRetrieve);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSQLDataGridTryout";
      this.Text = "SQLClient Example Tryout";
      ((System.ComponentModel.ISupportInitialize)(this.dgrCustomer)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSQLDataGridTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250725 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250725 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSQLDataGridTryout()
      //***
      // Action
      //   - Create instance of 'frmSQLDataGridTryout'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250725 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250725 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSQLDataGridTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdRetrieve_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Clear the data set
      //   - Fill the data adapter with the info in the data set table "tblCPCustomer"
      //   - Set up the data grid
      //     - Data source is the data set
      //     - Allow sorting
      //     - Set the back color alternating
      //     - Bind the data of the data set table "tblCPCustomer"
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250725 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250725 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click

    private void cmdUpdate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Update the data grid
      //   - Update the data set thru the data adapter
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250725 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250725 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdUpdate_Click(System.Object, System.EventArgs) Handles cmdUpdate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSQLDataGridTryout
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSQLDataGridTryout()
      // Created
      //   - CopyPaste � 20250725 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250725 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSQLDataGridTryout());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSQLDataGridTryout

}
// CopyPaste.Learning