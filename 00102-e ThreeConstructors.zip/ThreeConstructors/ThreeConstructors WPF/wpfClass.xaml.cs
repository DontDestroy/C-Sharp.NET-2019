﻿// Action
//   - A WPF form with 3 other classes and its constructors
// Created
//   - CopyPaste – 20230327 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230327 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace ThreeConstructors_WPF
{

  public partial class wpfClass : Window
  {

    #region "Constructors / Destructors"

    public wpfClass()
    //***
    // Action
    //   - Create instance of 'wpfClass'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230327 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230327 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfClass()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCreate_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    // Action
    //   - Making a new instance of cpC
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - cpC()
    // Created
    //   - CopyPaste – 20230327 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230327 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpC theSample = new cpC();
    }
    // cmdCreate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCreate.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfClass

  public class cpA
  {

    public cpA()
    //***
    // Action
    //   - Create new instance of 'cpA'
    // Called by
    //   - cpB()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230327 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230327 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      MessageBox.Show("In class cpA constructor");
    }
    // cpA()

  }
  // cpA

  public class cpB : cpA
  {

    public cpB()
    //***
    // Action
    //   - Create new instance of 'cpB'
    // Called by
    //   - cpC()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230327 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230327 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      MessageBox.Show("In class cpB constructor");
    }
    // cpB()

  }
  // cpB

  public class cpC : cpB
  {

    public cpC()
    //***
    // Action
    //   - Create new instance of 'cpC'
    // Called by
    //   - wpfClass.cmdCreate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCreate.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230327 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230327 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      MessageBox.Show("In class cpC constructor");
    }
    // cpC()

  }
  // cpC

}
// ThreeConstructors_WPF