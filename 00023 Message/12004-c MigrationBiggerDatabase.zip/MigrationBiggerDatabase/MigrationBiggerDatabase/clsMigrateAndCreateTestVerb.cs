﻿//***
// Action
//   - Prepare the option "Migrate and create testdata" for CommandLine Parser
// Created
//   - CopyPaste – 20230719 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230719 – VVDW
// Proposal (To Do)
//   -
//***

using CommandLine;
using CopyPaste.BusinessLayer;
using CopyPaste.DataAccess;
using CopyPaste.Toolkit;
using System;
using System.Collections.Generic;
using System.Text;


namespace MigrationBiggerDatabase
{

  [VerbAttribute("Both", HelpText = "Migrate the database and create testdata for forward engineered database")]
  public class cpMigrateAndCreateTestVerb
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    [OptionAttribute('f', "FlightCount", Default = 0, HelpText = "Number of Flights to create")]
    public int FlightCount { get; set; } = 0;

    [OptionAttribute('p', "PassengerCount", Default = 0, HelpText = "Number of Passengers to create")]
    public int PassengerCount { get; set; } = 0;

    [OptionAttribute('i', "PilotCount", Default = 0, HelpText = "Number of Pilots to create")]
    public int PilotCount { get; set; } = 0;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int Both(cpWingsContext theContext)
    //***
    // Action
    //   - Migrate the database
    //   - Create the test data
    // Called by
    //   - int cpProgram.Main(string[])
    // Calls
    //   - cpCreateTestDataVerb()
    //   - cpCreateTestDataVerb.CreateTestData(cpWingsContext)
    //   - cpMigrateDatabaseVerb()
    //   - cpMigrateDatabaseVerb.Migrate(cpWingsContext)
    // Created
    //   - CopyPaste – 20230719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      new cpMigrateDatabaseVerb().Migrate(theContext);
      new cpCreateTestDataVerb().CreateTestData(theContext, PilotCount, FlightCount, PassengerCount);
      return 0;
    }
    // Both(cpWingsContext)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpMigrateAndCreateTestVerb

}
// MigrationBiggerDatabase