﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCopyPasteCoffeeOrder.aspx.cs" Inherits="CopyPaste.Learning.wfrmCopyPasteCoffeeOrder" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Copy Paste Order Form</title>
  <link rel="stylesheet" type="text/css" href="cssCopyPasteCoffee.css">
  <link rel="stylesheet" type="text/css" href="cssCopyPasteCoffeeOrder.css">
</head>
<body>
  <h1>The Copy Paste Coffee Machine</h1>
  <h2>Fill out the form below and click "Order Now" to order</h2>
  <!--form id="wfrmCopyPasteCoffeeOrder" action="http://www.copypastecoffee.com/processorder.php" method="post" -->
  <form id="wfrmCopyPasteCoffeeOrder" action="wfrmCopyPasteCoffeeOrderAnswer.aspx" method="post">
    <fieldset>
      <legend>Order Details</legend>
      <div class="TableRow">
        <p>
          Choose your beans:
        </p>
        <p>
          <select id="cmbBeans" name="beans">
            <option value="House Blend">House Blend</option>
            <option value="Bolivia">Shade Grown Bolivia Supremo</option>
            <option value="Guatemala">Organic Guatemala</option>
            <option value="Kenya">Kenya</option>
          </select>
        </p>
      </div>
      <div class="TableRow">
        <p>
          Type:
        </p>
        <p>
          <input type="radio" id="optWhole" name="beantype" value="whole">
          <label for="optWhole">Whole</label>
          <br>
          <input type="radio" id="optGround" name="beantype" value="ground" checked>
          <label for="optGround">Ground</label>
        </p>
        </p>
      </div>
      <div class="TableRow">
        <p>
          Number of bags:
        </p>
        <p>
          <input type="number" id="intBags" name="bags" min="1" max="25">
        </p>
      </div>
      <div class="TableRow">
        <p>
          Must arrive by date:
        </p>
        <p>
          <input type="date" id="dtmDate" name="date">
        </p>
      </div>
      <div class="TableRow">
        <p>
          Extras:<br>
        </p>
        <p>
          <input type="checkbox" id="chkGiftWrap" name="giftwrap">Gift wrap<br>
          <input type="checkbox" id="chkCatalog" name="catalog" checked>Catalog
        </p>
      </div>
    </fieldset>
    <fieldset>
      <legend>Ship To</legend>
      <div class="TableRow">
        <p>
          Name:
        </p>
        <p>
          <input type="text" id="txtName" name="name" value="" placeholder="FirstName LastName" required>
        </p>
      </div>
      <div class="TableRow">
        <p>
          Address:
        </p>
        <p>
          <input type="text" id="txtAddress" name="address" value="">
        </p>
      </div>
      <div class="TableRow">
        <p>
          City:
        </p>
        <p>
          <input type="text" id="txtCity" name="city" value="">
        </p>
      </div>
      <div class="TableRow">
        <p>
          State:
        </p>
        <p>
          <input type="text" id="txtState" name="state" value="">
        </p>
      </div>
      <div class="TableRow">
        <p>
          Zip:
        </p>
        <p>
          <input type="text" id="txtZip" name="zip" value="">
        </p>
      </div>
      <div class="TableRow">
        <p>
          Phone:
        </p>
        <p>
          <input type="tel" id="txtPhone" name="phone" value="" placeholder="+32 (0)475 97 63 80">
        </p>
      </div>
      <div class="TableRow">
        <p>
          Customer Comments:<br>
        </p>
        <p>
          <textarea id="txtareaName" name="comments" placeholder="Type here your comments. Use <Enter> to go to a new line."></textarea>
        </p>
      </div>
    </fieldset>
    <div class="TableRow">
      <p>
      </p>
      <p>
        <input type="submit" id="cmdOrderNow" value="Order Now" />
      </p>
    </div>
  </form>
</body>
</html>
