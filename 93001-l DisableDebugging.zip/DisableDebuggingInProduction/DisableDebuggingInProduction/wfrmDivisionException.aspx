<%@ Page Language="C#" Debug="False" ErrorPage="https://localhost:44379/ErrorPage.html" %>

<!-- VVDW - Alternative way can be found in Web.config and in Global.asax -->
<html>
<head>
  <script language="C#" runat="server">

    protected void Page_Error(System.Object theSender, EventArgs theEventArguments)
    {
      Response.Redirect("https://localhost:44379/ErrorPage.html");
      // VVDW - This seems to work
    }

  </script>
  <title>Divide by Zero</title>
</head>
<body>
  <center>
    <h1>Divide by Zero triggers Error Page</h1>
  </center>
  <hr>

  <% 

    int intNumber = 10;
    int intDivider = 0;
    int intRemainder;

    intRemainder = intNumber % intDivider;
    Response.Write("Remainder: " + intRemainder + "<br>");

  %>
</body>
</html>
