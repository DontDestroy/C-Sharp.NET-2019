           ========================================

                 Lucky Seven Slot Machine 1.5

              (c) Copyright Copy Paste 2001-2024

           ========================================


============================================
Welcome to the Lucky Seven Slot Machine Game
============================================

The following information is available in this README file:


  o  USAGE TIPS
  o  UNINSTALLATION
  o  CONTACT INFORMATION


==========
Usage Tips
==========

You "win" the game by getting a 7 in one of the spinner windows when you click the Spin button.
By my calculations, you will win the game about 28% of the time. Have fun!

==============
UNINSTALLATION
==============

To Uninstall in Microsoft Windows 98, ME, 2000 or later:

Click the Start button, click Settings, and then click Control Panel.
Use the Add/Remove Programs tool to remove "Lucky" from the list of installed programs.

===================
Contact Information
===================

Copy Paste
Hazebos 13
8980 Zonnebeke
Vincent@CopyPaste.be
