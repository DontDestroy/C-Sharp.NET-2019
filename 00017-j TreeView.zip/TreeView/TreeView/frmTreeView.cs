//***
// Action
//   - Demo of a treeview (only with topnode)
// Created
//   - CopyPaste � 20240312 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240312 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTreeView: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdView;
    internal System.Windows.Forms.TreeView trvDirectory;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTreeView));
      this.cmdView = new System.Windows.Forms.Button();
      this.trvDirectory = new System.Windows.Forms.TreeView();
      this.SuspendLayout();
      // 
      // cmdView
      // 
      this.cmdView.Location = new System.Drawing.Point(98, 224);
      this.cmdView.Name = "cmdView";
      this.cmdView.Size = new System.Drawing.Size(96, 23);
      this.cmdView.TabIndex = 3;
      this.cmdView.Text = "View Directories";
      this.cmdView.Click += new System.EventHandler(this.cmdView_Click);
      // 
      // trvDirectory
      // 
      this.trvDirectory.ImageIndex = -1;
      this.trvDirectory.Location = new System.Drawing.Point(18, 16);
      this.trvDirectory.Name = "trvDirectory";
      this.trvDirectory.SelectedImageIndex = -1;
      this.trvDirectory.Size = new System.Drawing.Size(256, 184);
      this.trvDirectory.TabIndex = 2;
      // 
      // frmTreeView
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdView);
      this.Controls.Add(this.trvDirectory);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTreeView";
      this.Text = "TreeView";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTreeView'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTreeView()
      //***
      // Action
      //   - Create instance of 'frmTreeView'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTreeView()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdView_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Generate the treeview with a starting path
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ProcessTree(String)
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ProcessTree("C:\\Program Files\\notepad++\\");
    }
    // cmdView_Click(System.Object, System.EventArgs) Handles cmdView.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTreeView
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTreeView());
    }
    // Main() 
    
    public void ProcessTree(string strDirectory)
      //***
      // Action
      //   - Generate the treeview with a starting path 'strDirectory'
      //   - Define the start directory
      //   - Define an array of directories with all the directories in the starting directory
      //   - Define a directory name
      //   - Change the treeview by adding a node
      //   - Refresh the screen
      //   - Loop thru all the direcotries (theDirectoryName)
      //     - Process the directory 'theDirectoryName'
      //     - On an error show an errormessage
      // Called by
      //   - cmdView_Click(System.Object, System.EventArgs) Handles cmdView.Click
      //   - ProcessTree(String)
      // Calls
      //   - ProcessTree(String)
      // Created
      //   - CopyPaste � 20240312 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240312 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DirectoryInfo theDirectory = new DirectoryInfo(strDirectory);
      DirectoryInfo[] arrDirectory = theDirectory.GetDirectories("*.*");
      
      trvDirectory.BeginUpdate();
      trvDirectory.Nodes.Add(new TreeNode(strDirectory));
      trvDirectory.EndUpdate();
      trvDirectory.Refresh();

      foreach (DirectoryInfo theDirectoryName in arrDirectory)
      {
      
        try
        {
          ProcessTree(theDirectoryName.FullName);
        }
        catch
        {
          MessageBox.Show("*** Error accessing " + theDirectoryName.FullName);
        }
      
      }
      // in arrDirectory


    }
    // ProcessTree(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTreeView

}
// CopyPaste.Learning