﻿//***
// Action
//   - Having DataSets in the application
// Created
//   - CopyPaste – 20210709 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210709 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

namespace DataSets
{

  partial class frmDataSets
  {

    #region Windows Form Designer generated code

    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;
    internal System.Windows.Forms.Button cmdCopy;
    internal System.Windows.Forms.Button cmdRelation;
    internal System.Windows.Forms.Button cmdTable;
    internal System.Data.SqlClient.SqlCommand cmmSelectCustomer;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwindScript;
    internal System.Data.SqlClient.SqlDataAdapter dtaCustomer;
    internal System.Windows.Forms.ListBox lstClient;
    internal System.Windows.Forms.ListBox lstEmployee;
    internal System.Windows.Forms.Label lblOrder;
    internal System.Data.SqlClient.SqlCommand cmmSelectEmployee;
    internal System.Data.SqlClient.SqlDataAdapter dtaEmployee;
    internal System.Data.SqlClient.SqlCommand cmmSelectOrder;
    internal System.Data.SqlClient.SqlDataAdapter dtaOrder;
    internal System.Windows.Forms.Label lblEmployee;
    internal System.Windows.Forms.DataGrid dgrOrder;
    internal System.Windows.Forms.Label lblClient;
    internal System.Data.DataColumn strChildValue;
    internal System.Data.DataColumn intMasterId;
    internal System.Data.DataColumn intIdChild;
    internal System.Data.DataTable dtChild;
    internal System.Data.DataColumn strMasterValue;
    internal System.Data.DataColumn intIdMaster;
    internal System.Data.DataTable dtMaster;
    internal System.Windows.Forms.Button cmdClone;
    internal System.Data.DataSet dsEmployee;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataSets));
      this.cmdCopy = new System.Windows.Forms.Button();
      this.cmdRelation = new System.Windows.Forms.Button();
      this.cmdTable = new System.Windows.Forms.Button();
      this.cmmSelectCustomer = new System.Data.SqlClient.SqlCommand();
      this.cnncpNorthwindScript = new System.Data.SqlClient.SqlConnection();
      this.dtaCustomer = new System.Data.SqlClient.SqlDataAdapter();
      this.lstClient = new System.Windows.Forms.ListBox();
      this.dsData = new DataSets.dsData();
      this.lstEmployee = new System.Windows.Forms.ListBox();
      this.lblOrder = new System.Windows.Forms.Label();
      this.cmmSelectEmployee = new System.Data.SqlClient.SqlCommand();
      this.dtaEmployee = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectOrder = new System.Data.SqlClient.SqlCommand();
      this.dtaOrder = new System.Data.SqlClient.SqlDataAdapter();
      this.lblEmployee = new System.Windows.Forms.Label();
      this.dgrOrder = new System.Windows.Forms.DataGrid();
      this.lblClient = new System.Windows.Forms.Label();
      this.strChildValue = new System.Data.DataColumn();
      this.intMasterId = new System.Data.DataColumn();
      this.intIdChild = new System.Data.DataColumn();
      this.dtChild = new System.Data.DataTable();
      this.strMasterValue = new System.Data.DataColumn();
      this.intIdMaster = new System.Data.DataColumn();
      this.dtMaster = new System.Data.DataTable();
      this.cmdClone = new System.Windows.Forms.Button();
      this.dsEmployee = new System.Data.DataSet();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dtChild)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dtMaster)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsEmployee)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdCopy
      // 
      this.cmdCopy.Location = new System.Drawing.Point(416, 102);
      this.cmdCopy.Name = "cmdCopy";
      this.cmdCopy.Size = new System.Drawing.Size(96, 23);
      this.cmdCopy.TabIndex = 19;
      this.cmdCopy.Text = "Copy DataSet";
      this.cmdCopy.Click += new System.EventHandler(this.cmdCopy_Click);
      // 
      // cmdRelation
      // 
      this.cmdRelation.Location = new System.Drawing.Point(416, 38);
      this.cmdRelation.Name = "cmdRelation";
      this.cmdRelation.Size = new System.Drawing.Size(96, 23);
      this.cmdRelation.TabIndex = 17;
      this.cmdRelation.Text = "Create Relation";
      this.cmdRelation.Click += new System.EventHandler(this.cmdRelation_Click);
      // 
      // cmdTable
      // 
      this.cmdTable.Location = new System.Drawing.Point(416, 6);
      this.cmdTable.Name = "cmdTable";
      this.cmdTable.Size = new System.Drawing.Size(96, 23);
      this.cmdTable.TabIndex = 16;
      this.cmdTable.Text = "Create Table";
      this.cmdTable.Click += new System.EventHandler(this.cmdTable_Click);
      // 
      // cmmSelectCustomer
      // 
      this.cmmSelectCustomer.CommandText = "SELECT strIdCustomer, strCompanyName, strCity, strCountry, strPostalCode, strRegi" +
    "on FROM tblCPCustomer";
      this.cmmSelectCustomer.Connection = this.cnncpNorthwindScript;
      // 
      // cnncpNorthwindScript
      // 
      this.cnncpNorthwindScript.ConnectionString = "Data Source=COPYPASTEPOWER\\COPYPASTE;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthwindScript.FireInfoMessageEventOnUserErrors = false;
      // 
      // dtaCustomer
      // 
      this.dtaCustomer.SelectCommand = this.cmmSelectCustomer;
      this.dtaCustomer.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCustomer", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("strIdCustomer", "strIdCustomer"),
                        new System.Data.Common.DataColumnMapping("strCompanyName", "strCompanyName"),
                        new System.Data.Common.DataColumnMapping("strCity", "strCity"),
                        new System.Data.Common.DataColumnMapping("strCountry", "strCountry"),
                        new System.Data.Common.DataColumnMapping("strPostalCode", "strPostalCode"),
                        new System.Data.Common.DataColumnMapping("strRegion", "strRegion")})});
      // 
      // lstClient
      // 
      this.lstClient.DataSource = this.dsData;
      this.lstClient.DisplayMember = "tblCPCustomer.strCompanyName";
      this.lstClient.Location = new System.Drawing.Point(200, 22);
      this.lstClient.Name = "lstClient";
      this.lstClient.Size = new System.Drawing.Size(200, 95);
      this.lstClient.TabIndex = 13;
      this.lstClient.ValueMember = "tblCPCustomer.strIdCustomer";
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // lstEmployee
      // 
      this.lstEmployee.Location = new System.Drawing.Point(8, 22);
      this.lstEmployee.Name = "lstEmployee";
      this.lstEmployee.Size = new System.Drawing.Size(184, 95);
      this.lstEmployee.TabIndex = 11;
      // 
      // lblOrder
      // 
      this.lblOrder.AutoSize = true;
      this.lblOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOrder.Location = new System.Drawing.Point(8, 134);
      this.lblOrder.Name = "lblOrder";
      this.lblOrder.Size = new System.Drawing.Size(48, 13);
      this.lblOrder.TabIndex = 14;
      this.lblOrder.Text = "Orders:";
      // 
      // cmmSelectEmployee
      // 
      this.cmmSelectEmployee.CommandText = "SELECT intIdEmployee, strFirstName, strLastName FROM tblCPEmployee";
      this.cmmSelectEmployee.Connection = this.cnncpNorthwindScript;
      // 
      // dtaEmployee
      // 
      this.dtaEmployee.SelectCommand = this.cmmSelectEmployee;
      this.dtaEmployee.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPEmployee", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdEmployee", "intIdEmployee"),
                        new System.Data.Common.DataColumnMapping("strFirstName", "strFirstName"),
                        new System.Data.Common.DataColumnMapping("strLastName", "strLastName")})});
      // 
      // cmmSelectOrder
      // 
      this.cmmSelectOrder.CommandText = "SELECT intEmployeeId, strCustomerId, intIdOrder, dtmOrderDate, dblFreight FROM tb" +
    "lCPOrder";
      this.cmmSelectOrder.Connection = this.cnncpNorthwindScript;
      // 
      // dtaOrder
      // 
      this.dtaOrder.SelectCommand = this.cmmSelectOrder;
      this.dtaOrder.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPOrder", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intEmployeeId", "intEmployeeId"),
                        new System.Data.Common.DataColumnMapping("strCustomerId", "strCustomerId"),
                        new System.Data.Common.DataColumnMapping("intIdOrder", "intIdOrder"),
                        new System.Data.Common.DataColumnMapping("dtmOrderDate", "dtmOrderDate"),
                        new System.Data.Common.DataColumnMapping("dblFreight", "dblFreight")})});
      // 
      // lblEmployee
      // 
      this.lblEmployee.AutoSize = true;
      this.lblEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblEmployee.Location = new System.Drawing.Point(8, 6);
      this.lblEmployee.Name = "lblEmployee";
      this.lblEmployee.Size = new System.Drawing.Size(71, 13);
      this.lblEmployee.TabIndex = 10;
      this.lblEmployee.Text = "Employees:";
      // 
      // dgrOrder
      // 
      this.dgrOrder.DataMember = "";
      this.dgrOrder.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrOrder.Location = new System.Drawing.Point(8, 150);
      this.dgrOrder.Name = "dgrOrder";
      this.dgrOrder.Size = new System.Drawing.Size(504, 208);
      this.dgrOrder.TabIndex = 15;
      // 
      // lblClient
      // 
      this.lblClient.AutoSize = true;
      this.lblClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblClient.Location = new System.Drawing.Point(200, 6);
      this.lblClient.Name = "lblClient";
      this.lblClient.Size = new System.Drawing.Size(49, 13);
      this.lblClient.TabIndex = 12;
      this.lblClient.Text = "Clients:";
      // 
      // strChildValue
      // 
      this.strChildValue.Caption = "strChildValue";
      this.strChildValue.ColumnName = "strChildValue";
      // 
      // intMasterId
      // 
      this.intMasterId.AllowDBNull = false;
      this.intMasterId.Caption = "intMasterId";
      this.intMasterId.ColumnName = "intMasterId";
      this.intMasterId.DataType = typeof(int);
      // 
      // intIdChild
      // 
      this.intIdChild.AllowDBNull = false;
      this.intIdChild.AutoIncrement = true;
      this.intIdChild.Caption = "intIdChild";
      this.intIdChild.ColumnName = "intIdChild";
      this.intIdChild.DataType = typeof(int);
      // 
      // dtChild
      // 
      this.dtChild.Columns.AddRange(new System.Data.DataColumn[] {
            this.intIdChild,
            this.intMasterId,
            this.strChildValue});
      this.dtChild.Constraints.AddRange(new System.Data.Constraint[] {
            new System.Data.ForeignKeyConstraint("relMasterChild", "dtMaster", new string[] {
                        "intIdMaster"}, new string[] {
                        "intMasterId"}, System.Data.AcceptRejectRule.None, System.Data.Rule.Cascade, System.Data.Rule.Cascade)});
      this.dtChild.TableName = "dtChild";
      // 
      // strMasterValue
      // 
      this.strMasterValue.Caption = "strMasterValue";
      this.strMasterValue.ColumnName = "strMasterValue";
      // 
      // intIdMaster
      // 
      this.intIdMaster.AllowDBNull = false;
      this.intIdMaster.AutoIncrement = true;
      this.intIdMaster.Caption = "intIdMaster";
      this.intIdMaster.ColumnName = "intIdMaster";
      this.intIdMaster.DataType = typeof(int);
      // 
      // dtMaster
      // 
      this.dtMaster.Columns.AddRange(new System.Data.DataColumn[] {
            this.intIdMaster,
            this.strMasterValue});
      this.dtMaster.Constraints.AddRange(new System.Data.Constraint[] {
            new System.Data.UniqueConstraint("Constraint1", new string[] {
                        "intIdMaster"}, false)});
      this.dtMaster.TableName = "dtMaster";
      // 
      // cmdClone
      // 
      this.cmdClone.Location = new System.Drawing.Point(416, 70);
      this.cmdClone.Name = "cmdClone";
      this.cmdClone.Size = new System.Drawing.Size(96, 23);
      this.cmdClone.TabIndex = 18;
      this.cmdClone.Text = "Clone DataSet";
      this.cmdClone.Click += new System.EventHandler(this.cmdClone_Click);
      // 
      // dsEmployee
      // 
      this.dsEmployee.DataSetName = "NewDataSet";
      this.dsEmployee.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsEmployee.Relations.AddRange(new System.Data.DataRelation[] {
            new System.Data.DataRelation("relMasterChild", "dtMaster", "dtChild", new string[] {
                        "intIdMaster"}, new string[] {
                        "intMasterId"}, false)});
      this.dsEmployee.Tables.AddRange(new System.Data.DataTable[] {
            this.dtMaster,
            this.dtChild});
      // 
      // frmDataSets
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(520, 373);
      this.Controls.Add(this.cmdCopy);
      this.Controls.Add(this.cmdRelation);
      this.Controls.Add(this.cmdTable);
      this.Controls.Add(this.lstClient);
      this.Controls.Add(this.lstEmployee);
      this.Controls.Add(this.lblOrder);
      this.Controls.Add(this.lblEmployee);
      this.Controls.Add(this.dgrOrder);
      this.Controls.Add(this.lblClient);
      this.Controls.Add(this.cmdClone);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataSets";
      this.Text = "DataSets";
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dtChild)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dtMaster)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsEmployee)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210709 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210709 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing && (components != null))
      {
        components.Dispose();
      }
      // (disposing && (components != null))

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    private dsData dsData;
    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataSets

}
// DataSets