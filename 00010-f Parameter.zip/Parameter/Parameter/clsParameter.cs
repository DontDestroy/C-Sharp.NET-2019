//***
// Action
//   - Example of the use of subroutines with parameters
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Parameter
{

  class cpParameter
	{

    static void Main()
    //***
    // Action
    //   - Write messages at console screen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - CharacterLine(byte, char)
    //   - Line(byte)
    //   - string System.Console.ReadLine() 
    //   - System.Console.WriteLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Main menu");
      Line(9);
      Console.WriteLine("1. From cm to inch.");
      Console.WriteLine("2. From inch to cm.");
      Line(19);
      Console.WriteLine();
      Console.WriteLine("Make your choice:");
      CharacterLine(17, '~');
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

    static void CharacterLine(byte bytNumber, char chrCharacter)
    //***
    // Action
    //   - Write 'chrCharactre' 'bytNumber' times
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.Write(char)
    //   - System.Console.WriteLine()
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      byte bytCounter;

      for (bytCounter = 1; bytCounter <= bytNumber; bytCounter++)
      {
        Console.Write(chrCharacter);
      }
      // bytCounter = bytNumber + 1

      Console.WriteLine();
    }
    // CharacterLine(byte, char)

    static void Line(byte bytNumber)
    //***
    // Action
    //   - Write "-" 'bytNumber' times
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.Write(char)
    //   - System.Console.WriteLine()
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      byte bytCounter;

      for (bytCounter = 1; bytCounter <= bytNumber; bytCounter++)
      {
        Console.Write('-');
      }
      // bytCounter = bytNumber + 1
      
      Console.WriteLine();
    }
    // Line(byte)

	}
  // cpParameter

}
// Parameter