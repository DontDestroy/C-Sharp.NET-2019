﻿//***
// Action
//   - Prepare the options "Migrate Database" for CommandLine Parser
// Created
//   - CopyPaste – 20230717 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230717 – VVDW
// Proposal (To Do)
//   -
//***

using CommandLine;
using System;
using System.Collections.Generic;
using System.Text;


namespace ForwardEngineerBiggerDatabase
{

  [VerbAttribute("Migrate", HelpText = "Migrate the forward engineered database")]
  public class cpMigrateDatabaseVerb
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int Migrate()
    //***
    // Action
    //   - No commands yet
    // Called by
    //   - int cpProgram.Main(string[])
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230717 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230717 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine("Not implemented yet");
      return 0;
    }
    // Migrate()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCreateTestDataVerb

}
// ForwardEngineerBiggerDatabase