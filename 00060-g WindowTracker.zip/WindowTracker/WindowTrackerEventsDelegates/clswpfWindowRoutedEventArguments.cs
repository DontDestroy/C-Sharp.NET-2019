﻿//***
// Action
//   - The arguments that are given thru the events
// Created
//   - CopyPaste – 20220817 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220817 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace WindowTrackerEventsDelegates
{

  public class cpwpfWindowRoutedEventArguments : RoutedEventArgs
  {
    #region "Constructors / Destructors"

    public cpwpfWindowRoutedEventArguments(string strTitle, string strContent)
    //***
    // Action
    //   - Create instance of 'cpwpfWindowRoutedEventArguments'
    // Called by
    //   - wpfWindow.SomeActionsOnTheWindow()
    // Calls
    //   - string Content() (Autmatic set)
    //   - string Title() (Autmatic set)
    // Created
    //   - CopyPaste – 20220817 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220817 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Content = strContent;
      Title = strTitle;
    }
    // cpwpfWindowRoutedEventArguments(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public string Content { get; set; }
    public string Title { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpwpfWindowRoutedEventArguments : RoutedEventArgs

}
// WindowTrackerEventsDelegates