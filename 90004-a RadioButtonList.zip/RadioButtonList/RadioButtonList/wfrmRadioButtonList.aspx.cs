﻿//***
// Action
//   - Example of a radio button list
// Created
//   - CopyPaste – 20260501 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260501 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmRadioButtonList : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.Load += new System.EventHandler(this.Page_Load);
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260501 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260501 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    protected void cmdChoose_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - If option was selected
      //       - Show information on the form about the selected option
      //     - If not
      //       - Show a message on the form to select a name
      //   - On possible null reference exception
      //     - Show a message on the form to select a name
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste – 20260501 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260501 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {

        if (optNames.SelectedIndex == -1)
        {
          lblResult.Text = "You have to select a name";
        }
        else
        // optNames.SelectedIndex <> -1
        {
          lblResult.Text = "You have choosen: " + optNames.SelectedItem.Value + " (" +
            (optNames.SelectedIndex + 1) + "°) item with name : " +
            optNames.SelectedItem.Text;
        }
        // optNames.SelectedIndex = -1

      }
      catch (NullReferenceException theException)
      {
        lblResult.Text = "You have to select a name";
      }

    }
    // optNames_SelectedIndexChanged(System.Object, System.EventArgs) Handles optNames.SelectedIndexChanged

    protected void optNames_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a list item
    //   - Loop thru the option list items
    //     - Set the item text to lowercase
    //   - Set the text of the selected iten to uppercase
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260501 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260501 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      foreach (ListItem theListItem in optNames.Items)
      {
        theListItem.Text = theListItem.Text.Substring(0, 1).ToUpper() + theListItem.Text.Substring(1).ToLower();
      }
      // in optNames.Items

      optNames.SelectedItem.Text = optNames.SelectedItem.Text.ToUpper();
    }
    // optNames_SelectedIndexChanged(System.Object, System.EventArgs) Handles optNames.SelectedIndexChanged

    protected void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - 
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260501 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260501 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // Page_Load(System.Object, System.EventArgs) Handles base.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmRadioButtonList

}
// CopyPaste.Learning