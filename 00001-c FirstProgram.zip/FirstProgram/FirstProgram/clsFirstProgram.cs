//***
// Action
//   - Read from and write to message to console screen
// Created
//   - CopyPaste � 20210823 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210823 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace FirstProgram
{

  class clsFirstProgram
	{

		static void Main()
    //***
    // Action
    //   - Write message
    //   - Read info
    // Created
    //   - CopyPaste � 20210823 � VVDW
    // Called by
    //   - 
    // Calls
    //   - System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210823 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Console.WriteLine("My first C#.NET 2019 Program!");
      Console.ReadLine();
		}
    // Main()

  }
  // clsFirstProgram

}
// FirstProgram