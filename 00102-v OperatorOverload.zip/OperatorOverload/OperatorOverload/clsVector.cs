//***
// Action
//   - Implementation of a vector
//   - A vector is a direction determined by 2 coordinates (X and Y)
//   - You can add 2 vectors
//   - You can multiply a vector by a number
//   - You can negate a vector
//   - You can subtract 2 vectors
// Created
//   - CopyPaste � 20240403 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240403 � VVDW
// Proposal (To Do)
//   - Multiplying vectors is not implemented in the exercise
//***

using System;

namespace CopyPaste.Learning
{

  public class cpVector
  {

    #region "Constructors / Destructors"

    public cpVector(double dblX, double dblY)
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpVector +(cpVector, cpVector)
      //   - cpVector -(cpVector)
      //   - cpVector *(cpVector, double)
      //   - cpVector frmVectorCalculation.FirstVector (Get)
      //   - cpVector frmVectorCalculation.SecondVector (Get)
      //   - cpVector Parse(string)
      //   - frmVectorCalculation.DrawVector(cpVector, Color)
      //   - User action (Creating an instance)
      // Calls
      //   - X(double) (Set)
      //   - Y(double) (Set)
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      X = dblX;
      Y = dblY;
    }
    // cpVector(double, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private double _dblX;
    private double _dblY;

    #endregion

    #region "Properties"

    public double X
    {

      get
        //***
        // Action Get
        //   - Returns the X coordinate of the vector
        // Called by
        //   - bool ==(cpVector, cpVector)
        //   - cpVector +(cpVector, cpVector)
        //   - cpVector -(cpVector)
        //   - cpVector -(cpVector, cpVector)
        //   - cpVector *(cpVector, double)
        //   - int GetHashCode()
        //   - Point frmVectorCalculation.cpVectorCoordinateToPoint(cpVector)
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240403 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240403 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return _dblX;
      }
      // double X (Get)
       
      set
        //***
        // Action Set
        //   - The X coordinate of the vector becomes value
        // Called by
        //   - cpVector(double, double)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240403 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240403 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        _dblX = value;
      }
      // X(double) (Set)
      
    }
    // double X

    public double Y
    {

      get
        //***
        // Action Get
        //   - Returns the Y coordinate of the vector
        // Called by
        //   - bool ==(cpVector, cpVector)
        //   - cpVector +(cpVector, cpVector)
        //   - cpVector -(cpVector)
        //   - cpVector -(cpVector, cpVector)
        //   - cpVector *(cpVector, double)
        //   - int GetHashCode()
        //   - Point frmVectorCalculation.cpVectorCoordinateToPoint(cpVector)
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240403 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240403 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return _dblY;
      }
      // double Y (Get)
       
      set
        //***
        // Action Set
        //   - The Y coordinate of the vector becomes value
        // Called by
        //   - cpVector(double, double)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240403 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240403 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        _dblY = value;
      }
      // Y(double) (Set)
      
    }
    // double Y

    #endregion

    #region "Methods"

    #region "Overrides"

    public override bool Equals(System.Object theObject)
      //***
      // Action
      //   - Override the method Equals
      //   - When theObject is a cpVector and this equals theObject, it is considered equal
      // Called by
      //   - 
      // Calls
      //   - bool ==(cpVector, cpVector)
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;

      if ((theObject is cpVector) && (this == (cpVector)theObject))
      {
        blnResult = true;
      }
      else
        // (theObject is not cpVector) OrElse (this <> (cpVector)theObject)
      {
        blnResult = false;
      }
      // (theObject is cpVector) AndAlso (this == (cpVector)theObject)

      return blnResult;
    }
    // bool Equals(System.Object)

    public override int GetHashCode()
      //***
      // Action
      //   - Absolute value of X coordinate is multiplied by 10
      //   - Absolute value of Y coordinate is multiplied by 1000
      //   - Both results are added
      //   - (0.5, 0.5) becomes 505
      //   - (-0.5, -0.5) becomes 505
      //     - Having an equal hashcode does not mean they are equal objects
      //     - Having a different hashcode does mean they are different objects
      // Called by
      //   - 
      // Calls
      //   - double cpVector.X (Get) 
      //   - double cpVector.Y (Get) 
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - We know that the doubles can have only 1 decimal
      //   - Having an equal hashcode does not mean they are equal
      //***
    {
      int lngResult;

      lngResult = (int) (Math.Abs(X) * 10);
      lngResult += (int) (Math.Abs(Y) * 1000);

      return lngResult;
    }
    // int GetHashCode()

    public override string ToString()
      //***
      // Action
      //   - A vector is visualised with its coordinates in the format (x; y)
      //   - An example: (2,4; 3,1)
      // Called by
      //   - frmVectorCalculation.AddVectors(cpVector, cpVector)
      //   - frmVectorCalculation.SubtractVectors(cpVector, cpVector)
      // Calls
      //   - double cpVector.X (Get) 
      //   - double cpVector.Y (Get) 
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - We know that the doubles can have only 1 decimal
      //   - Having an equal hashcode does not mean they are equal
      //***
    {
      string strReturn;

      strReturn = string.Format("({0}; {1})", X, Y);

      return strReturn;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static cpVector operator +(cpVector theFirstVector, cpVector theSecondVector)
      //***
      // Action
      //   - Definition of + (adding) of vectors
      //   - Both coordinates are added
      // Called by
      //   - cpVector -(cpVector, cpVector)
      //   - frmVectorCalculation.AddVectors(cpVector, cpVector)
      //   - frmVectorCalculation.DrawVector(cpVector, cpVector, Color)
      //   - frmVectorCalculation.SomethingChanged(System.Object, System.EventArgs) Handles xxx
      // Calls
      //   - cpVector(double, double)
      //   - double cpVector.X (Get) 
      //   - double cpVector.Y (Get) 
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return new cpVector(theFirstVector.X + theSecondVector.X, theFirstVector.Y + theSecondVector.Y);
    }
    // cpVector +(cpVector, cpVector)

    public static cpVector operator -(cpVector theFirstVector)
      //***
      // Action
      //   - Definition of - (negation) of vectors
      //   - Both coordinates are negated
      // Called by
      //   - cpVector -(cpVector, cpVector)
      //   - frmVectorCalculation.SubtractVectors(cpVector, cpVector)
      // Calls
      //   - cpVector(double, double)
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return new cpVector(- theFirstVector.X, - theFirstVector.Y);
    }
    // cpVector -(cpVector)

    public static cpVector operator -(cpVector theFirstVector, cpVector theSecondVector)
      //***
      // Action
      //   - Definition of - (subtracting) of vectors
      //   - Second vector is negated
      //   - Both coordinates are added
      // Called by
      //   - frmVectorCalculation.SomethingChanged(System.Object, System.EventArgs) Handles xxx
      //   - frmVectorCalculation.SubtractVectors(cpVector, cpVector)
      // Calls
      //   - cpVector +(cpVector, cpVector)
      //   - cpVector -(cpVector)
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return theFirstVector + (-theSecondVector);
    }
    // cpVector -(cpVector, cpVector)

    public static cpVector operator *(cpVector theFirstVector, double dblScalar)
      //***
      // Action
      //   - Definition of * (multiplying) a vector with a value
      //   - Both coordinates are multiplied with the value
      // Called by
      //   - cpVector *(double, cpVector)
      //   - frmVectorCalculation.SomethingChanged(System.Object, System.EventArgs) Handles xxx
      // Calls
      //   - cpVector(double, double)
      //   - double cpVector.X (Get) 
      //   - double cpVector.Y (Get) 
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return new cpVector(theFirstVector.X * dblScalar, theFirstVector.Y * dblScalar);
    }
    // cpVector *(cpVector, double)

    public static cpVector operator *(double dblScalar, cpVector theFirstVector)
      //***
      // Action
      //   - Definition of * (multiplying) a value with a vector
      //   - Both coordinates are multiplied with the value
      // Called by
      //   - 
      // Calls
      //   - cpVector *(cpVector, double)
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return theFirstVector * dblScalar;
    }
    // cpVector *(double, cpVector)

    public static bool operator !=(cpVector theFirstVector, cpVector theSecondVector)
      //***
      // Action
      //   - Definition of != (not equals opeator) of vectors
      //   - The negation of being equal
      // Called by
      //   - 
      // Calls
      //   - bool ==(cpVector, cpVector)
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return !(theFirstVector == theSecondVector);
    }
    // bool !=(cpVector, cpVector)

    public static bool operator ==(cpVector theFirstVector, cpVector theSecondVector)
      //***
      // Action
      //   - Definition of == (equals opeator) of vectors
      //   - When both X and Y coordinates are equal, the vectors are considered equal
      // Called by
      //   - bool !=(cpVector, cpVector)
      //   - bool Equals(System.Object)
      //   - frmVectorCalculation.AreVectorsEqual(cpVector, cpVector)
      //   - frmVectorCalculation.SomethingChanged(System.Object, System.EventArgs) Handles xxx
      // Calls
      //   - double cpVector.X (Get) 
      //   - double cpVector.Y (Get) 
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - When defining this it is usual you also define !=, Equals and GetHashCode
      //***
    {
      bool blnResult;

      if ((theFirstVector.X == theSecondVector.X) && (theFirstVector.Y == theSecondVector.Y))
      {
        blnResult = true;
      }
      else
        // (theFirstVector.X <> theSecondVector.X) OrElse (theFirstVector.Y <> theSecondVector.Y))
      {
        blnResult = false;
      }
      // (theFirstVector.X = theSecondVector.X) AndAlso (theFirstVector.Y = theSecondVector.Y)

      return blnResult;
    }
    // bool ==(cpVector, cpVector)

    public static cpVector Parse(string strVector)
      //***
      // Action
      //   - If the format of the string is correct
      //     - Parse (convert) a text into a cpVector
      //   - If not
      //     - Throw error message
      // Called by
      //   - bool !=(cpVector, cpVector)
      //   - bool Equals(System.Object)
      // Calls
      //   - cpVector(double, double)
      //   - double cpVector.X (Get) 
      //   - double cpVector.Y (Get)
      // Created
      //   - CopyPaste � 20240403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        double dblX;
        double dblY;
        string[] arrstrValues;
          
        arrstrValues = strVector.Split("(; )".ToCharArray());
        dblX = double.Parse(arrstrValues[1]);
        dblY = double.Parse(arrstrValues[3]);

        return new cpVector(dblX, dblY);
      }
      catch
      {
        throw new ArgumentException("Unable to parse '" + strVector + "' into an instance of cpVector.");
      }

    }
    // cpVector Parse(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpVector

}
// CopyPaste.Learning