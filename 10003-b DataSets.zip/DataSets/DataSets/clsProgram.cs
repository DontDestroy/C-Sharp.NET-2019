﻿//***
// Action
//   - Having DataSets in the application
//   - Alternative way to start application
// Created
//   - CopyPaste – 20210706 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210706 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Forms;

namespace DataSets
{

  static class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Starting the application frmDataSets
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmDataDataSets()
    // Created
    //   - CopyPaste – 20210706 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210706 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run(new frmDataSets());
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// DataSets