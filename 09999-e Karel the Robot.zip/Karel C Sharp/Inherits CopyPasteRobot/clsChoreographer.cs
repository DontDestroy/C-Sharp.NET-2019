﻿//***
// Action
//   - A definition of an Choreographer
// Created
//   - CopyPaste – 20251027 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251027 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpChoreographer : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

    public cpChoreographer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpChoreographer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpChoreographer(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpChoreographer(int, int, Directions.Direction, int) 

    public cpChoreographer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpChoreographer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpChoreographer(int, int, Directions.Direction, int) 
    //   - cpProgram.Choreographer()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpChoreographer(int, int, Directions.Direction, int, Color) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpCopyPasteRobot helperRightSide = new cpCopyPasteRobot(2, 6, Directions.North, Directions.infinity, Color.blue);
    private cpCopyPasteRobot helperTopSide = new cpCopyPasteRobot(6, 6, Directions.West, Directions.infinity, Color.blue);
    private cpCopyPasteRobot helperLeftSide = new cpCopyPasteRobot(6, 2, Directions.South, Directions.infinity, Color.blue);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override void move()
    //***
    // Action
    //   - The robot and all the helpers move
    // Called by
    //   - cpProgram.Choreographer()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      base.move();
      helperRightSide.move();
      helperTopSide.move();
      helperLeftSide.move();
    }
    // move()

    public override void pickBeeper()
    //***
    // Action
    //   - The robot and all the helpers will pick a beeper
    // Called by
    //   - cpProgram.Choreographer()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      base.pickBeeper();
      helperRightSide.pickBeeper();
      helperTopSide.pickBeeper();
      helperLeftSide.pickBeeper();
    }
    // pickBeeper()

    public override void putBeeper()
    //***
    // Action
    //   - The robot and all the helpers will put a beeper
    // Called by
    //   - cpProgram.Choreographer()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      base.putBeeper();
      helperRightSide.putBeeper();
      helperTopSide.putBeeper();
      helperLeftSide.putBeeper();
    }
    // putBeeper()

    public override void turnLeft()
    //***
    // Action
    //   - The robot and all the helpers will turn left
    // Called by
    //   - cpProgram.Choreographer()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      base.turnLeft();
      helperRightSide.turnLeft();
      helperTopSide.turnLeft();
      helperLeftSide.turnLeft();
    }
    // turnLeft()

    public override void turnOff()
    //***
    // Action
    //   - The robot and all the helpers will turn off
    // Called by
    //   - cpProgram.Choreographer()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      base.turnOff();
      helperRightSide.turnOff();
      helperTopSide.turnOff();
      helperLeftSide.turnOff();
    }
    // turnOff()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpChoreographer

}
// cpKarelTheRobot