//***
// Action
//   - Create a basic form with error provider as default
// Created
//   - CopyPaste � 20250719 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250719 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace CopyPaste.Learning.UserInterface
{

  public class cpctlRequiredFieldForm: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(cpctlRequiredFieldForm));
      // 
      // cpctlRequiredFieldForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "cpctlRequiredFieldForm";
      this.Closing += new System.ComponentModel.CancelEventHandler(this.cpctlRequiredFieldForm_Closing);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpctlRequiredFieldForm'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpctlRequiredFieldForm()
      //***
      // Action
      //   - Basic constructor that sets the error provider
      // Called by
      //   - User action (Starting the control, in this case a form)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      merpIndicator = new ErrorProvider();
    }
    // cpctlRequiredFieldForm()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private Control[] marrctlRequired;
    protected const string mcstrComboBoxError = "A combobox item must be selected.";
    protected const string mcstrListBoxError = "A Listbox item must be selected.";
    protected const string mcstrNoControl = "Specific Validation not coded for this control.";
    protected const string mcstrTextBoxError = "The text area cannot be empty.";
    private ErrorProvider merpIndicator;

    #endregion

    #region "Properties"

    public Control[] RequiredControls
    {

      get
        //***
        // Action Get
        //   - Return the list of required controls (part of the form) (marrctlRequired)
        // Called by
        //   - bool RequiredFieldsAreValid()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250719 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250719 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return marrctlRequired;
      }
      // Control[] RequiredControls (Get)

      set
        //***
        // Action Set
        //   - Set the list of required controls (part of the form)
        //     - marrctlRequired becomes arrctlValue
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250719 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250719 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        marrctlRequired = value;
      }
      // RequiredControls(Control[]) (Set)

    }
    // Control[] RequiredControls

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cpctlRequiredFieldForm_Closing(System.Object theSender, System.ComponentModel.CancelEventArgs theCancelEventArguments)
      //***
      // Action
      //   - If CausesValidation of the control
      //     - Negate the result of RequiredFieldsAreValid
      //     - Set this in the cancel property of the event
      // Called by
      //   - User action (Closing the control, in this case a form)
      // Calls
      //   - bool RequiredFieldsAreValid()
      // Created
      //   - CopyPaste � 20250719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (this.CausesValidation)
      {
        theCancelEventArguments.Cancel = !RequiredFieldsAreValid();
      }
      else
        // Not this.CausesValidation
      {
      }
      // this.CausesValidation
    
    }
    // cpctlRequiredFieldForm_Closing(System.Object, System.ComponentModel.CancelEventArgs) Handles this.Closing

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public bool RequiredFieldsAreValid()
      //***
      // Action
      //   - Try to
      //     - If there is no array with required fields
      //       - blnResult becomes True
      //     - If not
      //       - Loop thru array of required fields
      //         - If item does not exist
      //           - Do nothing
      //         - If not
      //           - Get the control that is required
      //           - Find the types of the control (array of types)
      //           - Find the Validate method that corresponds with the array of types
      //           - Create an array of that control
      //           - Invoke the validate method, that gives an error message (or not)
      //           - If there is an error message
      //             - blnResult becomes false
      //           - If not
      //             - Do nothing
      //           - The error indicator gets that error message
      //   - On error
      //     - Show error message
      //     - blnResult becomes False
      //   - Return blnResult
      // Called by
      //   - cpctlRequiredFieldForm_Closing(System.Object, System.ComponentModel.CancelEventArgs) Handles this.Closing
      // Calls
      //   - Control[] RequiredControls (Get)
      //   - string Validate(ComboBox)
      //   - string Validate(Control)
      //   - string Validate(ListBox)
      //   - string Validate(TextBox)
      // Created
      //   - CopyPaste � 20250719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnResult = true;
      int lngIndex;
      string strValidationMessage;

      try
      {

        if (RequiredControls == null)
        {
          blnResult = true;
        }
        else
          // RequiredControls <> null
        {
          
          for (lngIndex = 0; lngIndex < RequiredControls.Length; lngIndex++)
          {
            
            if (RequiredControls[lngIndex] == null)
            {
            }
            else
              // RequiredControls[lngIndex] <> null
            {
              Control theControl = RequiredControls[lngIndex];
              Type[] arrType = {theControl.GetType()};
              MethodInfo theMethodInfo = this.GetType().GetMethod("Validate", arrType);
              Control[] arrArgument = {theControl};

              strValidationMessage = theMethodInfo.Invoke(this, arrArgument).ToString();

              if (strValidationMessage.Length == 0)
              {
              }
              else
                // strValidationMessage.Length <> 0
              {
                blnResult = false;
              }
              // strValidationMessage.Length = 0

              merpIndicator.SetError(theControl, strValidationMessage);
            }
            // RequiredControls[lngIndex] = null

          }
          // lngIndex = RequiredControls.Length

        }
        // RequiredControls = null
      
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
        blnResult = false;
      }
      finally
      {
      }

      return blnResult;
    }
    // bool RequiredFieldsAreValid()

    public string Validate(ComboBox cmbValue)
      //***
      // Action
      //   - If combobox is a simple combobox and the text is empty
      //        Or nothing is selected
      //     - Return the combobox error
      //   - If not
      //     - Return an empty string
      // Called by
      //   - bool RequiredFieldsAreValid()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strResult;

      if ((cmbValue.DropDownStyle == ComboBoxStyle.Simple && cmbValue.Text.Trim() == String.Empty) || cmbValue.SelectedIndex == -1)
      {
        strResult = mcstrComboBoxError;
      }
      else
        // (cmbValue.DropDownStyle <> ComboBoxStyle.Simple OrElse cmbValue.Text.Trim() <> String.Empty) AndAlso cmbValue.SelectedIndex <> -1
      {
        strResult = String.Empty;
      }  
      // (cmbValue.DropDownStyle = ComboBoxStyle.Simple AndAlso cmbValue.Text.Trim() = String.Empty) OrElse cmbValue.SelectedIndex = -1

      return strResult;
    }
    // string Validate(ComboBox)

    public string Validate(Control ctlValue)
      //***
      // Action
      //   - If the control has no value
      //     - Return an empty string
      //   - If not
      //     - Return the NoControl error
      // Called by
      //   - bool RequiredFieldsAreValid()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strResult;

      if (ctlValue == null)
      {
        strResult = string.Empty;
      }
      else
        // ctlValue <> null
      {
        strResult = mcstrNoControl;
      }
      // ctlValue = null

      return strResult;
    }
    // string Validate(Control)

    public string Validate(ListBox lstValue)
      //***
      // Action
      //   - If nothing is selected in the listbox
      //     - Return the ListBox error
      //   - If not
      //     - Return an empty string
      // Called by
      //   - bool RequiredFieldsAreValid()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strResult;

      if (lstValue.SelectedIndex == -1)
      {
        strResult = mcstrListBoxError;
      }
      else
        // lstValue.SelectedIndex <> -1
      {
        strResult = string.Empty;
      }
      // lstValue.SelectedIndex == -1

      return strResult;
    }
    // string Validate(ListBox)

    public string Validate(TextBox txtValue)
      //***
      // Action
      //   - If nothing is typed in the textbox
      //     - Return the TextBox error
      //   - If not
      //     - Return an empty string
      // Called by
      //   - bool RequiredFieldsAreValid()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strResult;

      if (txtValue.Text.Trim() == string.Empty)
      {
        strResult = mcstrTextBoxError;
      }
      else
        // txtValue.Text.Trim() <> string.Empty
      {
        strResult = string.Empty;
      }
      // txtValue.Text.Trim() = string.Empty

      return strResult;
    }
    // string Validate(TextBox)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpctlRequiredFieldForm

}
// CopyPaste.Learning.UserInterface