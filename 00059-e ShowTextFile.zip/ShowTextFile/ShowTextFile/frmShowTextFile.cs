//***
// Action
//   - Exercise to catch some errors
// Created
//   - CopyPaste � 20240518 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240518 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmShowTextFile: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdShowTextFile;
    internal System.Windows.Forms.TextBox txtResult;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmShowTextFile));
      this.cmdShowTextFile = new System.Windows.Forms.Button();
      this.txtResult = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdShowTextFile
      // 
      this.cmdShowTextFile.Location = new System.Drawing.Point(105, 33);
      this.cmdShowTextFile.Name = "cmdShowTextFile";
      this.cmdShowTextFile.TabIndex = 2;
      this.cmdShowTextFile.Text = "Select File";
      this.cmdShowTextFile.Click += new System.EventHandler(this.cmdShowTextFile_Click);
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(21, 89);
      this.txtResult.Multiline = true;
      this.txtResult.Name = "txtResult";
      this.txtResult.Size = new System.Drawing.Size(250, 150);
      this.txtResult.TabIndex = 3;
      this.txtResult.Text = "";
      // 
      // frmShowTextFile
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdShowTextFile);
      this.Controls.Add(this.txtResult);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmShowTextFile";
      this.Text = "Show Text File";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmShowTextFile'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmShowTextFile()
      //***
      // Action
      //   - Create instance of 'frmShowTextFile'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmShowTextFile()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdShowTextFile_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a file open dialog
      //   - Set the filter to all files and text files
      //   - Select the second filter (text files)
      //   - Set the directory
      //   - Set that the extension must be seen
      //   - Set the default extension to txt
      //   - Don't check that the file exists
      //   - If you click OK
      //     - Define a stream reader
      //     - Initialize the stream reader with the selected file (open the file)
      //     - Read the file
      //     - Show the result on the screen
      //     - Close the file
      //   - If not
      //     - Show that the user has choosen "Cancel"
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      OpenFileDialog dlgFileOpen = new OpenFileDialog();

      dlgFileOpen.Filter = "All files | *.* | Text files | *.txt";
      dlgFileOpen.FilterIndex = 2;
      dlgFileOpen.InitialDirectory = "C:\\Temp";
      dlgFileOpen.AddExtension = true;
      dlgFileOpen.DefaultExt = "txt";
      dlgFileOpen.CheckFileExists = false;

      if (dlgFileOpen.ShowDialog() == DialogResult.OK)
      {
        StreamReader strReader;

        strReader = new StreamReader(dlgFileOpen.FileName);
        txtResult.Text = strReader.ReadToEnd();
        strReader.Close();
      }
      else
        // dlgFileOpen.ShowDialog() <> DialogResult.OK
      {
        MessageBox.Show("User selected Cancel");
      }
      // dlgFileOpen.ShowDialog() = DialogResult.OK
    
    }
    // cmdShowTextFile_Click(System.Object, System.EventArgs) Handles cmdShowTextFile.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmShowTextFile
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmShowTextFile()
      // Created
      //   - CopyPaste � 20240518 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240518 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmShowTextFile());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmShowTextFile

}
// CopyPaste.Learning