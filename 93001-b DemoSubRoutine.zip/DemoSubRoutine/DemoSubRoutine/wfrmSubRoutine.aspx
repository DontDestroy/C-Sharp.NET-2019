<%@ Page Language="C#" %>

<html>
<head>
  <title>Demo Subroutine</title>
  <script runat="server">
  
  void ResponseWrite(string strValue)
  {
    Response.Write(strValue);
  }
  
  </script>
</head>
<body>

  <%
      Response.Write("Hello, world!<br>");
      Response.Write("ASP.NET is cool<br>");
      ResponseWrite("<br>") ;
      ResponseWrite("Hello again, world!<br>"); 
      ResponseWrite("ASP.NET Routines are very cool!<br>"); 
  %>

</body>
</html>