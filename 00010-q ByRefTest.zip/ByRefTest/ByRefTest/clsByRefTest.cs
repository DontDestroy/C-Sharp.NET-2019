//***
// Action
//   - Pass variable by value
//   - Pass variable by reference
//   - Pass variable by reference between parentheses
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace ByRefTest
{

  class cpByRefTest
	{

    static void Main()
    //***
    // Action
    //   - Initialize 2 variables
    //   - Square one by value
    //   - Square one by reference
    //   - Show results at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - SquareByReference(�long)
    //   - SquareByValue(long)
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    //   - System.Console.WriteLine(string, System.Object)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngNumber1 = 2;
      long lngNumber2 = 2;

      Console.WriteLine("Passing a value-type argument by value:");
      Console.WriteLine("Before calling SquareByValue, number1 is {0}", lngNumber1);
      SquareByValue(lngNumber1);
      Console.WriteLine("After returning from SquareByValue, number1 is {0}\n", lngNumber1);
      Console.WriteLine("Passing a value-type argument by reference:");
      Console.WriteLine("Before calling SquareByReference, number2 is {0}", lngNumber2);
      SquareByReference(ref lngNumber2);
      Console.WriteLine("After returning from SquareByReference, number2 is {0}\n", lngNumber2);
      Console.ReadLine();
    }
    // Main()

    static void SquareByValue(long lngNumber)
    //***
    // Action
    //   - Show 'lngNumber' at console screen
    //   - Square 'lngNumber'
    //   - Show 'lngNumber' at console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string, System.Object)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("After entering SquareByValue, number is {0}", lngNumber);
      lngNumber *= lngNumber;
      Console.WriteLine("Before exiting SquareByValue, number is {0}", lngNumber);
    }
    // SquareByValue(long)

    static void SquareByReference(ref long lngNumber)
    //***
    // Action
    //   - Show 'lngNumber' at console screen
    //   - Square 'lngNumber'
    //   - Show 'lngNumber' at console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string, System.Object)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("After entering SquareByReference, number is {0}", lngNumber);
      lngNumber *= lngNumber;
      Console.WriteLine("Before exiting SquareByReference, number is {0}", lngNumber);
    }
    // SquareByReference(�long)

  }
  // cpByRefTest

}
// ByRefTest