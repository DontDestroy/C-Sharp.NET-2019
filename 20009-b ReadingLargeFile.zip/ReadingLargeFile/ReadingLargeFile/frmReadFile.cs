//***
// Action
//   - Reading a large file and a cancel button
// Created
//   - CopyPaste � 20260129 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260129 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmReadFile: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    private Button cmdReadFile;
    private Button cmdCancel;
    private Label lblLinesTotal;
    private Button cmdCancelAsync;
    private Button cmdReadFileAsync;
    private Label lblLinesRead;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmReadFile));
      this.cmdReadFile = new System.Windows.Forms.Button();
      this.cmdCancel = new System.Windows.Forms.Button();
      this.lblLinesRead = new System.Windows.Forms.Label();
      this.lblLinesTotal = new System.Windows.Forms.Label();
      this.cmdCancelAsync = new System.Windows.Forms.Button();
      this.cmdReadFileAsync = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdReadFile
      // 
      this.cmdReadFile.Location = new System.Drawing.Point(47, 61);
      this.cmdReadFile.Name = "cmdReadFile";
      this.cmdReadFile.Size = new System.Drawing.Size(190, 45);
      this.cmdReadFile.TabIndex = 0;
      this.cmdReadFile.Text = "Read File (Blocks all)";
      this.cmdReadFile.UseVisualStyleBackColor = true;
      this.cmdReadFile.Click += new System.EventHandler(this.cmdReadFile_Click);
      // 
      // cmdCancel
      // 
      this.cmdCancel.Location = new System.Drawing.Point(266, 61);
      this.cmdCancel.Name = "cmdCancel";
      this.cmdCancel.Size = new System.Drawing.Size(190, 45);
      this.cmdCancel.TabIndex = 1;
      this.cmdCancel.Text = "Cancel";
      this.cmdCancel.UseVisualStyleBackColor = true;
      this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
      // 
      // lblLinesRead
      // 
      this.lblLinesRead.AutoSize = true;
      this.lblLinesRead.Location = new System.Drawing.Point(28, 25);
      this.lblLinesRead.Name = "lblLinesRead";
      this.lblLinesRead.Size = new System.Drawing.Size(116, 13);
      this.lblLinesRead.TabIndex = 2;
      this.lblLinesRead.Text = "Lines read: 000000000";
      // 
      // lblLinesTotal
      // 
      this.lblLinesTotal.AutoSize = true;
      this.lblLinesTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblLinesTotal.Location = new System.Drawing.Point(26, 125);
      this.lblLinesTotal.Name = "lblLinesTotal";
      this.lblLinesTotal.Size = new System.Drawing.Size(260, 25);
      this.lblLinesTotal.TabIndex = 3;
      this.lblLinesTotal.Text = "Total Lines: 000000000";
      // 
      // cmdCancelAsync
      // 
      this.cmdCancelAsync.Location = new System.Drawing.Point(266, 170);
      this.cmdCancelAsync.Name = "cmdCancelAsync";
      this.cmdCancelAsync.Size = new System.Drawing.Size(190, 45);
      this.cmdCancelAsync.TabIndex = 5;
      this.cmdCancelAsync.Text = "Cancel";
      this.cmdCancelAsync.UseVisualStyleBackColor = true;
      this.cmdCancelAsync.Click += new System.EventHandler(this.cmdCancelAsync_Click);
      // 
      // cmdReadFileAsync
      // 
      this.cmdReadFileAsync.Location = new System.Drawing.Point(47, 170);
      this.cmdReadFileAsync.Name = "cmdReadFileAsync";
      this.cmdReadFileAsync.Size = new System.Drawing.Size(190, 45);
      this.cmdReadFileAsync.TabIndex = 4;
      this.cmdReadFileAsync.Text = "Read File (Async)";
      this.cmdReadFileAsync.UseVisualStyleBackColor = true;
      this.cmdReadFileAsync.Click += new System.EventHandler(this.cmdReadFileAsync_Click);
      // 
      // frmReadFile
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(662, 273);
      this.Controls.Add(this.cmdCancelAsync);
      this.Controls.Add(this.cmdReadFileAsync);
      this.Controls.Add(this.lblLinesTotal);
      this.Controls.Add(this.lblLinesRead);
      this.Controls.Add(this.cmdCancel);
      this.Controls.Add(this.cmdReadFile);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmReadFile";
      this.Text = "Reading a Large File (To be or not to be async, that is the question)";
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmReadFile'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260129 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260129 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmReadFile()
    //***
    // Action
    //   - Create instance of 'frmReadFile'
    // Called by
    //   - Main()
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste � 20260129 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260129 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmReadFile()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    bool blnCancelled;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCancel_Click(System.Object theSender, EventArgs theEventArguments)
    //***
    // Action
    //   - Set blnCancelled to true
    //   - Enable the other buttons
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260129 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260129 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      blnCancelled = true;
      cmdReadFile.Enabled = true;
      cmdReadFileAsync.Enabled = true;
      cmdCancelAsync.Enabled = true;
    }
    // cmdCancel_Click(System.Object, EventArgs) Handles cmdCancel.Click

    private void cmdCancelAsync_Click(System.Object theSender, EventArgs theEventArguments)
    //***
    // Action
    //   - Set blnCancelled to true
    //   - Enable the other buttons
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260129 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260129 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      blnCancelled = true;
      cmdReadFile.Enabled = true;
      cmdReadFileAsync.Enabled = true;
      cmdCancel.Enabled = true;
    }
    // cmdCancelAsync_Click(System.Object, EventArgs) Handles cmdCancelAsync.Click

    private void cmdReadFile_Click(System.Object theSender, EventArgs theEventArguments)
    //***
    // Action
    //   - Define and initialize a line counter
    //   - Define and initialize a list of strings
    //   - Define a streamreader
    //   - Define a line of text
    //   - blnCancelled becomes false
    //   - All buttons except cmdCancel are disabled
    //   - Set the label with the total lines to original text
    //   - Open the file BigFile.csv
    //   - Loop thru the fill (as long you don't click on cancel)
    //     - Line of text becomes the read next line of the textfile
    //     - LineCounter is incremented
    //     - Line of text is added to the list of strings
    //     - Label with lines read is adapted
    //   - Label with total lines is adapted
    //   - Enable the disabled buttons
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260129 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260129 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intLineCounter = 0;
      List<string> lstText = new List<string>();
      StreamReader theFile;
      string strLine;

      blnCancelled = false;
      cmdReadFile.Enabled = false;
      cmdReadFileAsync.Enabled = false;
      cmdCancelAsync.Enabled = false;
      lblLinesTotal.Text = "Total Lines: 000000000";

      using (theFile = File.OpenText("BigFile.csv"))
      {

        while (!theFile.EndOfStream && !blnCancelled)
        {
          strLine = theFile.ReadLine();
          intLineCounter += 1;
          lstText.Add(strLine);
          lblLinesRead.Text = $"Lines read: {intLineCounter}";
        }
        // theFile.EndOfStream

      }
      // theFile is cleaned up

      lblLinesTotal.Text = $"Total Lines: {intLineCounter}";
      cmdReadFile.Enabled = true;
      cmdReadFileAsync.Enabled = true;
      cmdCancelAsync.Enabled = true;
    }
    // cmdReadFile_Click(System.Object, EventArgs) Handles cmdReadFile.Click

    private async void cmdReadFileAsync_Click(System.Object theSender, EventArgs theEventArguments)
    //***
    // Action
    //   - Define and initialize the total lines
    //   - blnCancelled becomes false
    //   - All buttons except cmdCancelAsync are disabled
    //   - Set the label with the total lines to original text
    //   - Label with total lines is adapted
    //   - Enable the disabled buttons
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260129 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260129 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      blnCancelled = false;
      cmdReadFile.Enabled = false;
      cmdReadFileAsync.Enabled = false;
      cmdCancel.Enabled = false;
      lblLinesTotal.Text = "Total Lines: 000000000";
      int intTotalLines = await ReadFile();
      lblLinesRead.Text = $"Lines read: {intTotalLines}";
      lblLinesTotal.Text = $"Total Lines: {intTotalLines}";
      cmdReadFile.Enabled = true;
      cmdReadFileAsync.Enabled = true;
      cmdCancel.Enabled = true;
    }
    // cmdReadFileAsync_Click(System.Object, EventArgs) Handles cmdReadFileAsync.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmReadFile
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmReadFile()
    // Created
    //   - CopyPaste � 20260129 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260129 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmReadFile());
    }
    // Main() 

    private async Task<int> ReadFile()
    //***
    // Action
    //   - Define and initialize a line counter
    //   - Define and initialize a list of strings
    //   - Define a streamreader
    //   - blnCancelled becomes false
    //   - All buttons except cmdCancel are disabled
    //   - Set the label with the total lines to original text
    //   - Open the file BigFile.csv
    //   - Loop thru the fill (as long you don't click on cancel)
    //     - Line of text becomes the read next line of the textfile
    //     - LineCounter is incremented
    //     - Line of text is added to the list of strings
    //     - Do a check on modulo 97 because showing all numbers is a bit rediculous
    //     - If lblLinesRead is on another thread
    //       - Label with lines read is adapted using invoke and a delegate with no parameters and return value
    //     - If not
    //       - Label with lines read is adapted
    //   - Label with total lines is adapted
    //   - Enable the disabled buttons
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260129 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260129 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intLineCounter = 0;
      int intModulo = 97;
      List<string> lstText = new List<string>();
      StreamReader theFile;
      string strLine;

      using (theFile = File.OpenText("BigFile.csv"))
      {

        while (!theFile.EndOfStream && !blnCancelled)
        {
          strLine = await theFile.ReadLineAsync().ConfigureAwait(false);
          intLineCounter += 1;
          lstText.Add(strLine);

          if (intLineCounter % intModulo == 0)
          {

            if (lblLinesRead.InvokeRequired)
            {
              lblLinesRead.Invoke(
                new Action(() => lblLinesRead.Text = $"Lines read: {intLineCounter}"));
            }
            else
            // Not lblLinesRead.InvokeRequired
            {
              lblLinesRead.Text = $"Lines read: {intLineCounter}";
            }
            // lblLinesRead.InvokeRequired

          }
          else
          // intLineCounter % intModulo <> 0
          {
          }
          // intLineCounter % intModulo = 0

        }
        // theFile.EndOfStream

      }
      // theFile is cleaned up

      return intLineCounter;
    }
    // Task<int> ReadFile()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmReadFile

}
// CopyPaste.Learning