<%@ Page Language="C#" %>

<html>
<head>
  <title>HTTP Header Information</title>
</head>
<body>
  <center>
    <h1>HTTP Header Information</h1>
  </center>
  <hr />

  <% 

    foreach (string strAcceptType in Request.AcceptTypes)
    {
      Response.Write("Accept Type: " + strAcceptType + "<br>");
    }

    Response.Write("Application Path: " + Request.ApplicationPath + "<br>");
    Response.Write("Browser Type: " + Request.Browser.Type + "<br>");
    Response.Write("Client Certificate: " + Request.ClientCertificate.IsPresent + "<br>");
    Response.Write("Code Page: " + Request.ContentEncoding.CodePage + "<br>");
    Response.Write("Content Length: " + Request.ContentLength + "<br>");

    foreach (string strCookie in Request.Cookies)
    {
      Response.Write("Cookie: " + strCookie + "<br>");
    }

    Response.Write("Execute File Path: " + Request.CurrentExecutionFilePath + "<br>");
    Response.Write("File Path: " + Request.FilePath + "<br>");

    foreach (string strFilename in Request.Files)
    {
      Response.Write("File: " + strFilename + "<br>");
    }

    foreach (string strHeader in Request.Headers)
    {
      Response.Write("Header: " + strHeader + "<br>");
    }

    Response.Write("HTTP Method: " + Request.HttpMethod + "<br>");
    Response.Write("Is Authenticated: " + Request.IsAuthenticated + "<br>");
    Response.Write("Is Secure Connection: " + Request.IsSecureConnection + "<br>");

    foreach (string strParam in Request.Params)
    {
      Response.Write("Param: " + strParam + "<br>");
    }

    Response.Write("Path: " + Request.Path + "<br>");
    Response.Write("Path Info: " + Request.PathInfo + "<br>");
    Response.Write("Application Path: " + Request.PhysicalApplicationPath + "<br>");
    Response.Write("Physical Path: " + Request.PhysicalPath + "<br>");
    Response.Write("Raw URL: " + Request.RawUrl + "<br>");
    Response.Write("Request Type: " + Request.RequestType + "<br>");

    foreach (string strServerVariable in Request.ServerVariables)
    {
      Response.Write("Server Variable: " + strServerVariable + "<br>");
    }

    Response.Write("Total Bytes: " + Request.TotalBytes + "<br>");
    Response.Write("URL: " + Request.Url.ToString() + "<br>");

    if (Request.UrlReferrer == null)
    {
      Response.Write("Referrer not defined<br>");
    }
    else
    {
      Response.Write("Referrer: " + Request.UrlReferrer.ToString() + "<br>");
    }

    Response.Write("User Agent: " + Request.UserAgent + "<br>");
    Response.Write("Host Address: " + Request.UserHostAddress + "<br>");
    Response.Write("Host Name: " + Request.UserHostName + "<br>");

    foreach (string strLanguage in Request.UserLanguages)
    {
      Response.Write("Language: " + strLanguage + "<br>");
    }

  %>

</body>
</html>
