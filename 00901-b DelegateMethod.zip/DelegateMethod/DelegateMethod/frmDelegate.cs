//***
// Action
//   - A button to demo the functionality of a delegate
// Created
//   - CopyPaste � 20250712 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250712 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDelegate: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdDelegate;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDelegate));
      this.cmdDelegate = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdDelegate
      // 
      this.cmdDelegate.Location = new System.Drawing.Point(24, 16);
      this.cmdDelegate.Name = "cmdDelegate";
      this.cmdDelegate.Size = new System.Drawing.Size(112, 32);
      this.cmdDelegate.TabIndex = 1;
      this.cmdDelegate.Text = "Use delegate";
      this.cmdDelegate.Click += new System.EventHandler(this.cmdDelegate_Click);
      // 
      // frmDelegate
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdDelegate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDelegate";
      this.Text = "Delegate Method";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDelegate'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDelegate()
      //***
      // Action
      //   - Create instance of 'frmDelegate'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDelegate()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdDelegate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of cpClass (thecpClass)
      //   - There are 2 different notations in doing the steps below
      //     - Define a variable that is the delegate
      //     - Create an instance of the delegate
      //     - Run (invoke) the delegate
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpClass()
      //   - cpClass.cpMethod(string)
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpClass thecpClass = new cpClass();
      cpDelegate thecpDelegate;
      cpDelegate thecpDelegateOther;

      // Longer notation
      thecpDelegate = new cpDelegate(thecpClass.cpMethod);
      thecpDelegate.Invoke("Test Delegate");

      // Shorter notation
      thecpDelegateOther = thecpClass.cpMethod;
      thecpDelegateOther("test");
    }
    // cmdDelegate_Click(System.Object, System.EventArgs) Handles cmdDelegate.Click

    #endregion

    #region "Functionality"

    #region "Event"

    public delegate void cpDelegate(string strString);

    #endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDelegate
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDelegate()
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDelegate());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDelegate

}
// CopyPaste.Learning