﻿//***
// Action
//   - Creating variables that are stored on the stack
// Created
//   - CopyPaste – 20260530 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260530 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void ForcedAssignToStack()
    //***
    // Action
    //   - Define a span to the stack
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intTotal = 0;
      Span<int> aSpanStack = stackalloc int[4] { 1, 2, 3, 4 };

      foreach (int intNumber in aSpanStack)
      {
        intTotal += intNumber;
      }
      // in aSpanStack

      Console.WriteLine($"Total: {intTotal}"); 
    }
    // ForcedAssignToStack()

    public static void Main()
    //***
    // Action
    //   - Explanation of the code in this method
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - ForcedAssignToStack()
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ForcedAssignToStack();

      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadKey();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning