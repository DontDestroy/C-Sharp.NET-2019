//***
// Action
//   - Implementation of cpDerived
// Created
//   - CopyPaste � 20240617 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240617 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpDerived : cpBase
  {

    #region "Constructors / Destructors"

    public cpDerived() : base()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - frmClassVariation_Load(System.Object, System.EventArgs) Handles this.Load
      //   - Main()
      // Calls
      //   - cpBase()
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDerived()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public new void cpBaseMethod()
      //***
      // Action
      //   - A method in a derived class that shadows the base class method
      // Called by
      //   - frmClassVariation_Load(System.Object, System.EventArgs) Handles this.Load
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("BaseMethod in Derived Class.");
    }
		// cpBaseMethod()

    public static void Main()
      //***
      // Action
      //   - Startup routine for testing cpBase and cpDerived
      // Called by
      //   - frmClassVariation_Load(System.Object, System.EventArgs) Handles MyBase.Load
      //   - User action (Starting the application)
      // Calls
      //   - cpBase.cpBaseMethod()
      //   - cpDerived()
      //   - cpDerived.cpBaseMethod()
      // Created
      //   - CopyPaste � 20240617 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240617 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - Change properties of this project to startup from this method
      //***
    {
      cpDerived thecpDerived = new cpDerived();
      cpBase thecpBase = thecpDerived;
      
      thecpBase.cpBaseMethod();
      thecpDerived.cpBaseMethod();

      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDerived

}
// CopyPaste.Learning