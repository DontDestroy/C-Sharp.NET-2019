﻿//***
// Action
//   - Setting a connection string
//   - Open the connection
//   - Show some information
//   - Close the connection
// Created
//   - CopyPaste – 20250726 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250726 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Try to
      //     - Define a connection with connection string
      //     - Open the connection
      //     - Show the database, server version and data source
      //     - Close the connection
      //   - When something fails
      //     - Put the exception message and the exception on the console
      //   - Wait for user input
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250726 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250726 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      
      try
      {
        string strConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integrated Security=True";
        SqlConnection theConnection = new SqlConnection(strConnectionString);

        theConnection.Open();
        Console.WriteLine("Database      : " + theConnection.Database);
        Console.WriteLine("Server version: " + theConnection.ServerVersion);
        Console.WriteLine("Datasource    : " + theConnection.DataSource);
        theConnection.Close();
      }
      catch (Exception theException)
      {
        Console.WriteLine("Exception: " + theException.Message);
        Console.WriteLine(theException.ToString());
      }
      finally
      {
        Console.ReadLine();
      }

    }
    // Main()
		
		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning