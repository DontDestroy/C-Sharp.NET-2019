﻿//***
// Action
//   - Definition of a Key Customer 
// Created
//   - CopyPaste – 20050508 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20050508 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpKeyCustomerTryout: cpCustomerTryout
  {

    #region "Constructors / Destructors"

    public cpKeyCustomerTryout(string strKeyCustomer)
      //***
      // Action
      //   - Create new instance of 'cpKeyCustomer' with a given string
      //   - If the given string is validated
      //     - 'mstrKeyCustomer' becomes 'strKeyCustomer'
      //   - If not
      //     - Throw a new cpInvalidKeyCustomerException
      // Called by
      //   - cpCustomerTryout(cpKeyCustomerTryout, string)
      //   - cpCustomerTryout.ReadValuesFromDataRow()
      //   - frmCustomerValidationBetterTryout.cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      // Calls
      //   - cpInvalidKeyCustomerException(string)
      //   - Validate(string)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpKeyCustomerTryout(string)

    public cpKeyCustomerTryout(cpKeyCustomerTryout thecpKeyCustomer)
      //***
      // Action
      //   - Create new instance of 'cpKeyCustomerTryout' with a cpKeyCustomerTryout
      //   - 'mstrKeyCustomer' becomes 'cpKeyCustomerTryout'.KeyCustomer
      // Called by
      //   - cpCustomerTryout(cpKeyCustomerTryout, string)
      // Calls
      //   - string cpKeyCustomerTryout.KeyCustomer (Get)
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpKeyCustomerTryout(cpKeyCustomer)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public string KeyCustomer
    {

      get
        //***
        // Action Get
        //   - Return 'mstrKeyCustomer'
        // Called by
        //   - bool cpCustomerTryout.Save() Implements cpiCustomerTryout.Save
        //   - cpKeyCustomerTryout(cpKeyCustomerTryout)
        //   - cpCustomerTryout(cpKeyCustomerTryout, string)
        //   - string ToString() Implements cpiCustomerTryout.ToString
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return "";
      }
      // string KeyCustomer (Get)

      set
        //***
        // Action Set
        //   - Raise the event BeforeUpdate
        //   - If Cancelled
        //     - Do nothing
        //   - If not
        //     - If Validation of strValue is true
        //       - mstrKeyCustomer becomes strValue
        //     - If not
        //       - Throw new cpInvalidKeyCustomerException with correct info
        // Called by
        //   - cpCustomerTryout.ReadValuesFromDataRow()
        // Calls
        //   - bool Validate(string)
        //   - cpInvalidKeyCustomerException(string)
        //   - StringValueBeforeUpdate(string, °bool)
        // Created
        //   - CopyPaste – 20050508 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20050508 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
      }
      // KeyCustomer(string) (Set)

    }
    // string KeyCustomer

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public bool Exists(string strKeyCustomer)
      //***
      // Action
      //   - Define a boolean
      //   - Define a SQL command
      //   - Define and set a SQL Statement
      //     - Count the customers with a specific key (strKeyCustomer)
      //   - Set the SQL command with the SQL statement and the connection
      //   - Open the connection
      //   - Execute the SQL command (what returns a number (0 or 1)
      //   - Convert the result to a boolean
      //   - Close the connection
      //   - Return the boolean
      // Called by
      //   - cpCustomerTryout(cpKeyCustomerTryout, string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return false;
    }
		// bool Exists(string)

    private bool Validate(string strKeyCustomer)
      //***
      // Action
      //   - Check if the customer key is 5 long
      // Called by
      //   - KeyCustomerTryout(String) (Set)
      //   - New(String)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20050508 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20050508 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return false;
    }
    // bool Validate(string)

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpKeyCustomerTryout

}
// CopyPaste.Learning