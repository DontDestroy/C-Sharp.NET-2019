﻿//***
// Action
//   - Having DataAdapters and Commands towards a database
// Created
//   - CopyPaste – 20210706 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210706 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

namespace DataAdaptersTryout
{

  partial class frmDataAdaptersTryout
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.IContainer components = null;
    internal System.Windows.Forms.TextBox txtMessages;
    internal System.Windows.Forms.DataGrid dgrCategories;
    internal System.Windows.Forms.TabPage pagCategory;
    internal System.Windows.Forms.Button cmdFillAll;
    internal System.Windows.Forms.TabControl tabTables;
    internal System.Windows.Forms.TabPage pagProduct;
    internal System.Windows.Forms.DataGrid dgrProducts;
    internal System.Windows.Forms.Button cmdUpdateCategory;
    internal System.Windows.Forms.Label lblMessage;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.txtMessages = new System.Windows.Forms.TextBox();
      this.dgrCategories = new System.Windows.Forms.DataGrid();
      this.pagCategory = new System.Windows.Forms.TabPage();
      this.cmdFillAll = new System.Windows.Forms.Button();
      this.tabTables = new System.Windows.Forms.TabControl();
      this.pagProduct = new System.Windows.Forms.TabPage();
      this.dgrProducts = new System.Windows.Forms.DataGrid();
      this.cmdUpdateCategory = new System.Windows.Forms.Button();
      this.lblMessage = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.dgrCategories)).BeginInit();
      this.pagCategory.SuspendLayout();
      this.tabTables.SuspendLayout();
      this.pagProduct.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgrProducts)).BeginInit();
      this.SuspendLayout();
      // 
      // txtMessages
      // 
      this.txtMessages.Location = new System.Drawing.Point(8, 294);
      this.txtMessages.Multiline = true;
      this.txtMessages.Name = "txtMessages";
      this.txtMessages.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtMessages.Size = new System.Drawing.Size(408, 80);
      this.txtMessages.TabIndex = 12;
      // 
      // dgrCategories
      // 
      this.dgrCategories.DataMember = "tblCPCategory";
      this.dgrCategories.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrCategories.Location = new System.Drawing.Point(8, 8);
      this.dgrCategories.Name = "dgrCategories";
      this.dgrCategories.Size = new System.Drawing.Size(384, 216);
      this.dgrCategories.TabIndex = 0;
      // 
      // pagCategory
      // 
      this.pagCategory.Controls.Add(this.dgrCategories);
      this.pagCategory.Location = new System.Drawing.Point(4, 22);
      this.pagCategory.Name = "pagCategory";
      this.pagCategory.Size = new System.Drawing.Size(400, 230);
      this.pagCategory.TabIndex = 0;
      this.pagCategory.Text = "Category";
      // 
      // cmdFillAll
      // 
      this.cmdFillAll.Location = new System.Drawing.Point(432, 38);
      this.cmdFillAll.Name = "cmdFillAll";
      this.cmdFillAll.Size = new System.Drawing.Size(112, 23);
      this.cmdFillAll.TabIndex = 13;
      this.cmdFillAll.Text = "&Fill All";
      // 
      // tabTables
      // 
      this.tabTables.Controls.Add(this.pagCategory);
      this.tabTables.Controls.Add(this.pagProduct);
      this.tabTables.Location = new System.Drawing.Point(8, 14);
      this.tabTables.Name = "tabTables";
      this.tabTables.SelectedIndex = 0;
      this.tabTables.Size = new System.Drawing.Size(408, 256);
      this.tabTables.TabIndex = 10;
      // 
      // pagProduct
      // 
      this.pagProduct.Controls.Add(this.dgrProducts);
      this.pagProduct.Location = new System.Drawing.Point(4, 22);
      this.pagProduct.Name = "pagProduct";
      this.pagProduct.Size = new System.Drawing.Size(400, 230);
      this.pagProduct.TabIndex = 1;
      this.pagProduct.Text = "Product";
      // 
      // dgrProducts
      // 
      this.dgrProducts.DataMember = "tblCPProduct";
      this.dgrProducts.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrProducts.Location = new System.Drawing.Point(8, 8);
      this.dgrProducts.Name = "dgrProducts";
      this.dgrProducts.Size = new System.Drawing.Size(384, 216);
      this.dgrProducts.TabIndex = 0;
      // 
      // cmdUpdateCategory
      // 
      this.cmdUpdateCategory.Location = new System.Drawing.Point(432, 70);
      this.cmdUpdateCategory.Name = "cmdUpdateCategory";
      this.cmdUpdateCategory.Size = new System.Drawing.Size(112, 23);
      this.cmdUpdateCategory.TabIndex = 14;
      this.cmdUpdateCategory.Text = "&Update Category";
      // 
      // lblMessage
      // 
      this.lblMessage.AutoSize = true;
      this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblMessage.Location = new System.Drawing.Point(8, 278);
      this.lblMessage.Name = "lblMessage";
      this.lblMessage.Size = new System.Drawing.Size(67, 13);
      this.lblMessage.TabIndex = 11;
      this.lblMessage.Text = "Messages:";
      // 
      // frmDataAdaptersTryout
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(552, 389);
      this.Controls.Add(this.txtMessages);
      this.Controls.Add(this.cmdFillAll);
      this.Controls.Add(this.tabTables);
      this.Controls.Add(this.cmdUpdateCategory);
      this.Controls.Add(this.lblMessage);
      this.Name = "frmDataAdaptersTryout";
      this.Text = "Data Adapters Tryout";
      ((System.ComponentModel.ISupportInitialize)(this.dgrCategories)).EndInit();
      this.pagCategory.ResumeLayout(false);
      this.tabTables.ResumeLayout(false);
      this.pagProduct.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgrProducts)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Cleanup after closing the form
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20210630 – VVDW
      // Changed
      //   - Organisation – yyyymmdd – Initials of programmer – What changed
      // Tested
      //   - CopyPaste – 20210630 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {

      if (disposing && (components != null))
      {
        components.Dispose();
      }
      // (disposing && (components != null))

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataAdaptersTryout

}
// DataAdaptersTryout