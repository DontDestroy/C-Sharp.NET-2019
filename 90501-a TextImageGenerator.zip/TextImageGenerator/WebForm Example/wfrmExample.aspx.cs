﻿//***
// Action
//   - Demo webpage with cpTextImage
// Created
//   - CopyPaste – 20260805 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260805 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Toolkit.UserInterface;
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmExample : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.ID = "wfrmExample";
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when the page is initialized
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260805 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260805 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define and initialize 1 cpTextImage
    //   - Draw the image with given parameters
    //   - Write the images as gif to the response
    // Called by
    //   - User action (Loading a form)
    // Calls
    //   - cpTextImage(int, int)
    //   - cpTextImage.DrawImage(int, int, Color, Color)
    //   - cpTextImage.DrawTextOnImage(string, Color, int, int, string, int)
    //   - cpTextImage.WriteTo(HttpResponse, Imaging.ImageFormat)
    // Created
    //   - CopyPaste – 20260805 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260805 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpTextImage theTextImage1 = new cpTextImage(0, 0);

      theTextImage1.DrawImage(100, 20, Color.Green, Color.Yellow);
      theTextImage1.DrawTextOnImage("Hello", Color.Green, 10, 1, "Tahoma", 10);
      theTextImage1.WriteTo(Response, System.Drawing.Imaging.ImageFormat.Gif);
    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmExample

}
// CopyPaste.Learning