//***
// Action
//   - Class definition of cpLunchOrder
// Created
//   - CopyPaste � 20230424 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230424 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpLunchOrder
  {

    #region "Constructors / Destructors"

    public cpLunchOrder(string strSaladType, string strMealType, string strBeverageType, string strDessertType)
    //***
    // Action
    //   - Constructor of cpLunchOrder with 4 parameters
    //   - Parameter with value for saladtype, mealtype, beveragetype and desserttype
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230424 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230424 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      mstrSalad = strSaladType;
      mstrMeal = strMealType;
      mstrBeverage = strBeverageType;
      mstrDessert = strDessertType;
    }
    // cpLunchOrder(string, string, string, string)
    
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public string mstrBeverage;
    public string mstrDessert;
    public string mstrMeal;
    public string mstrSalad;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpLunchOrder

}
// CopyPaste.Learning