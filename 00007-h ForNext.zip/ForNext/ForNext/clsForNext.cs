//***
// Action
//   - For ... Next
// Created
//   - CopyPaste � 20220119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220119 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace ForNext
{

  class cpForNext
	{

    static void Main()
    //***
    // Action
    //   - Loop 10 times
    //     - Show counter at console screen
    //     - Ask a number
    //     - Calculate total
    //   - Show total
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - int System.Convert.ToInt32(string)
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string, System.Object)
    // Created
    //   - CopyPaste � 20220119 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220119 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter;
      long lngNumber;
      long lngTotal = 0;

      for (lngCounter = 1; lngCounter <= 10; lngCounter++)
      {
        Console.Write("Type number {0}: ", lngCounter);
        lngNumber = Convert.ToInt32(Console.ReadLine());
        lngTotal += lngNumber;
      }
      // lngCounter = 11
      
      Console.WriteLine("Total: {0}", lngTotal);
      Console.ReadLine();
		}
    // Main()

  }
  // cpForNext

}
// cpForNext