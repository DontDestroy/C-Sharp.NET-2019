//***
// Action
//   - Implementation of cpCheckingAccount
//   - This is a bankAccount, but for every withdraw there is a cost of 25 cent
// Created
//   - CopyPaste � 20240227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240227 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;

namespace CopyPaste.Learning
{

  public class cpCheckingAccount : cpBankAccount
  {

    #region "Constructors / Destructors"

    public cpCheckingAccount(string strOwner) : base()
      //***
      // Action
      //   - Constructor of a cpCheckingAccount that defines an owner
      // Called by
      //   - frmBetterBank()
      // Calls
      //   - cpBankAccount(string)
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mstrOwner = strOwner;
    }
    // cpCheckingAccount(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private const decimal mdecCostsOfWithDrawal = 0.25M;
    private int mlngCheques = 0;
    private string mstrOwner;
    #endregion

    #region "Properties"

    public override string Id
    {
      
      get
        //***
        // Action Get
        //   - Returns the Id (owner) of a cpBankAccount with a "-C" added at the end
        // Called by
        //   - PrintStatement() As String
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240227 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240227 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrOwner + "-C";
      }
      // string Id (Get)

    }
    // string Id

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string PrintStatement()
      //***
      // Action
      //   - Define an array of 7 values (calculated or not)
      //     - An enter, the owner, the total deposits, the total withdrawals
      //     - the number of cheques written, the costs of the cheques, the balance
      //   - Define a message
      //   - Format the message using the 7 values of the array
      //   - Return the message
      // Called by
      //   - 
      // Calls
      //   - decimal cpBankAccount.Balance (Get)
      //   - decimal cpBankAccount.TotalDeposits (Get)
      //   - decimal cpBankAccount.TotalWithDrawals (Get)
      //   - string Id (Get)
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      

      Object[] objInformation =
        {
          Environment.NewLine, 
          Id, 
          TotalDeposits,
          TotalWithDrawals - (mlngCheques * mdecCostsOfWithDrawal),
          mlngCheques, 
          mlngCheques * mdecCostsOfWithDrawal, 
          Balance};

      string strMessage;

      strMessage = string.Format("{1}{0}" +
        "Opening balance:�0.00{0}" +
        "Deposits: {2:C}{0}" +
        "WithDrawals: {3:C}{0}" +
        "Cheques written: {4}{0}" +
        "Checking charges: {5:C}{0}" +
        "Ending balance: {6:C}{0}",
        objInformation);

      return strMessage;
    }
    // string PrintStatement()

    public override decimal Withdraw(decimal decAmount)
      //***
      // Action
      //   - A certain amount (decAmount) with a cost of 25 cent is removed from the balance of the cpCheckingAccount
      //   - The number of cheques is incremented by one
      // Called by
      //   - frmBetterBank.cmdSubmit_Click(System.Object, System.EventArgs) Handles cmdSubmit.Click
      // Calls
      //   - cpBankAccount.Withdraw(decimal)
      //   - decimal cpBankAccount.Balance (Get)
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      decimal decAmountWithCost;
      decimal decBalance;

      decAmountWithCost = decAmount + mdecCostsOfWithDrawal;
      mlngCheques += 1;
      decBalance = base.Withdraw(decAmountWithCost);

      return Balance;
    }
    // decimal Withdraw(decimal)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpCheckingAccount

}
// CopyPaste.Learning