﻿//***
// Action
//   - Definition of a cpCache
// Created
//   - CopyPaste – 20260617 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260617 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;

namespace CopyPaste.Learning
{

  public class cpCache
  {

    #region "Constructors / Destructors"

    public cpCache()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   -
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260617 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260617 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpCache()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static readonly Dictionary<string, string> dicTexts = new Dictionary<string, string>();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Add(string strKey, string strValue)
    //***
    // Action
    //   - Adding an element to a dictionary with the key strKey and the value strValue
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260617 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260617 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - This is never cleared of trimmed, so it is a memory sink
    //***
    {
      dicTexts[strKey] = strValue;
    }
    // Add(string, string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpWorker

}
// CopyPaste.Learning