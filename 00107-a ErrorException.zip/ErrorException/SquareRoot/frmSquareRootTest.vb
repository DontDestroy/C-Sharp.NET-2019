'***
' Action
'   - Testroutine for cpNegativeNumberException
' Created
'   - CopyPaste � 20230820 � VVDW
' Changed
'   - CopyPaste � yyyymmdd � VVDW � What changed
' Tested
'   - CopyPaste � 20230820 � VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On
Option Strict On

Imports CopyPaste.Learning
Imports System.Windows.Forms

Namespace CopyPaste.Learning

  Public Class frmSquareRoot
    Inherits Form

#Region " Windows Form Designer generated code "
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    ' Label for showing square root
    Friend WithEvents lblOutput As Label
    Friend WithEvents lblInput As Label

    ' Button invokes square-root calculation
    Friend WithEvents cmdSquareRoot As Button

    ' TextBox receives user's Integer input
    Friend WithEvents txtInput As TextBox

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmSquareRoot))
      Me.lblOutput = New System.Windows.Forms.Label
      Me.txtInput = New System.Windows.Forms.TextBox
      Me.cmdSquareRoot = New System.Windows.Forms.Button
      Me.lblInput = New System.Windows.Forms.Label
      Me.SuspendLayout()
      '
      'lblOutput
      '
      Me.lblOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
      Me.lblOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.lblOutput.Location = New System.Drawing.Point(14, 72)
      Me.lblOutput.Name = "lblOutput"
      Me.lblOutput.Size = New System.Drawing.Size(264, 23)
      Me.lblOutput.TabIndex = 3
      '
      'txtInput
      '
      Me.txtInput.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.txtInput.Location = New System.Drawing.Point(168, 8)
      Me.txtInput.Name = "txtInput"
      Me.txtInput.TabIndex = 1
      Me.txtInput.Text = ""
      '
      'cmdSquareRoot
      '
      Me.cmdSquareRoot.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.cmdSquareRoot.Location = New System.Drawing.Point(90, 40)
      Me.cmdSquareRoot.Name = "cmdSquareRoot"
      Me.cmdSquareRoot.Size = New System.Drawing.Size(112, 24)
      Me.cmdSquareRoot.TabIndex = 2
      Me.cmdSquareRoot.Text = "Square Root"
      '
      'lblInput
      '
      Me.lblInput.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
      Me.lblInput.Location = New System.Drawing.Point(8, 8)
      Me.lblInput.Name = "lblInput"
      Me.lblInput.Size = New System.Drawing.Size(144, 23)
      Me.lblInput.TabIndex = 0
      Me.lblInput.Text = "Please enter a number"
      '
      'frmSquareRoot
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(292, 100)
      Me.Controls.Add(Me.txtInput)
      Me.Controls.Add(Me.cmdSquareRoot)
      Me.Controls.Add(Me.lblOutput)
      Me.Controls.Add(Me.lblInput)
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.Name = "frmSquareRoot"
      Me.RightToLeft = System.Windows.Forms.RightToLeft.No
      Me.Text = "Computing the Square Root"
      Me.ResumeLayout(False)

    End Sub

#End Region

#Region "Constructors / Destructors"

    Protected Overloads Overrides Sub Dispose(ByVal blnDisposing As Boolean)
      '***
      ' Action
      '   - Clean up instance of 'frmSquareRoot'
      ' Called by
      '   - User action (Closing the form)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste � 20230820 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20230820 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      If blnDisposing Then

        If components Is Nothing Then
        Else
          ' Not components Is Nothing
          components.Dispose()
        End If
        ' components Is Nothing

      Else
        ' Not blnDisposing
      End If
      ' blnDisposing

      MyBase.Dispose(blnDisposing)
    End Sub
    ' Dispose(Boolean)

    Public Sub New()
      '***
      ' Action
      '   - Create new instance of 'frmSquareRoot'
      ' Called by
      '   - User action (Starting the form)
      ' Calls
      '   - InitializeComponent()
      ' Created
      '   - CopyPaste � 20230820 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20230820 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      MyBase.New()
      InitializeComponent()
    End Sub
    ' New()

#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

    '#Region "Fields"
    '#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

#Region "Controls"

    Private Sub cmdSquareRoot_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdSquareRoot.Click
      '***
      ' Action
      '   - Try to convert the typed text into a double
      '     - On error show the FormatException
      '   - Try to calculate the squareroot
      '     - On error show the cpNegativeNumberException
      '   - Show the result on the screen
      '   - On any unforseen error, show the errormessage
      ' Called by
      '   - User action (Clicking a button)
      ' Calls
      '   - SquareRoot(Double) As Double
      ' Created
      '   - CopyPaste � 20230820 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20230820 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      lblOutput.Text = ""

      Try
        Dim dblResult As Double = SquareRoot(Convert.ToDouble(txtInput.Text))

        lblOutput.Text = dblResult.ToString()
      Catch theFormatException As FormatException
        MessageBox.Show(theFormatException.Message, "Invalid Number Format", MessageBoxButtons.OK, MessageBoxIcon.Error)
      Catch thecpNegativeNumberException As cpNegativeNumberException
        MessageBox.Show(thecpNegativeNumberException.Message, "Invalid Operation", MessageBoxButtons.OK, MessageBoxIcon.Error)
      Catch theException As Exception
        MessageBox.Show(theException.Message, "Not forseen error", MessageBoxButtons.OK, MessageBoxIcon.Error)
      End Try

    End Sub
    ' cmdSquareRoot_Click(System.Object, System.EventArgs) Handles cmdSquareRoot.Click

#End Region

#Region "Functionality"

    '#Region "Event"
    '#End Region

#Region "Sub / Function"

    Public Function SquareRoot(ByVal dblOperand As Double) As Double
      '***
      ' Action
      '   - Calculate the squareroot of a double
      '   - Will throw an error when double is negative
      ' Called by
      '   - cmdSquareRoot_Click(System.Object, System.EventArgs) Handles cmdSquareRoot.Click
      ' Calls
      '   - cpNegativeNumberException.New(String)
      ' Created
      '   - CopyPaste � 20230820 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20230820 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      If dblOperand < 0 Then
        Throw New cpNegativeNumberException("Square root of negative number not permitted")
      Else
        ' dblOperand >= 0
      End If
      ' dblOperand < 0

      Return Math.Sqrt(dblOperand)
    End Function
    ' SquareRoot(Double) As Double

#End Region

#End Region

#End Region

    '#Region "Not used"
    '#End Region

  End Class
  ' frmSquareRoot

End Namespace
' CopyPaste.Learning