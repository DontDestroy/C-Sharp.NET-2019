//***
// Action
//   - Reading and writing a text or richtext in several ways
// Created
//   - CopyPaste � 20230421 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230421 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace ScratchPad
{

  public class frmScratchPad : System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.OpenFileDialog dlgFileOpen;
    internal System.Windows.Forms.MainMenu mnuMain;
    internal System.Windows.Forms.MenuItem mnuFile;
    internal System.Windows.Forms.MenuItem mnuFileNew;
    internal System.Windows.Forms.MenuItem mnuFileOpen;
    internal System.Windows.Forms.MenuItem mnuFileSave;
    internal System.Windows.Forms.MenuItem MenuItem5;
    internal System.Windows.Forms.MenuItem mnuFileQuit;
    internal System.Windows.Forms.SaveFileDialog dlgFileSave;
    internal System.Windows.Forms.RichTextBox rtxtText;

    private System.ComponentModel.Container components = null;
    
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmScratchPad));
      this.dlgFileOpen = new System.Windows.Forms.OpenFileDialog();
      this.mnuMain = new System.Windows.Forms.MainMenu();
      this.mnuFile = new System.Windows.Forms.MenuItem();
      this.mnuFileNew = new System.Windows.Forms.MenuItem();
      this.mnuFileOpen = new System.Windows.Forms.MenuItem();
      this.mnuFileSave = new System.Windows.Forms.MenuItem();
      this.MenuItem5 = new System.Windows.Forms.MenuItem();
      this.mnuFileQuit = new System.Windows.Forms.MenuItem();
      this.dlgFileSave = new System.Windows.Forms.SaveFileDialog();
      this.rtxtText = new System.Windows.Forms.RichTextBox();
      this.SuspendLayout();
      // 
      // mnuMain
      // 
      this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFile});
      // 
      // mnuFile
      // 
      this.mnuFile.Index = 0;
      this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFileNew,
                                                                            this.mnuFileOpen,
                                                                            this.mnuFileSave,
                                                                            this.MenuItem5,
                                                                            this.mnuFileQuit});
      this.mnuFile.Text = "File";
      // 
      // mnuFileNew
      // 
      this.mnuFileNew.Index = 0;
      this.mnuFileNew.Text = "New";
      this.mnuFileNew.Click += new System.EventHandler(this.mnuFileNew_Click);
      // 
      // mnuFileOpen
      // 
      this.mnuFileOpen.Index = 1;
      this.mnuFileOpen.Text = "Open";
      this.mnuFileOpen.Click += new System.EventHandler(this.mnuFileOpen_Click);
      // 
      // mnuFileSave
      // 
      this.mnuFileSave.Index = 2;
      this.mnuFileSave.Text = "Save";
      this.mnuFileSave.Click += new System.EventHandler(this.mnuFileSave_Click);
      // 
      // MenuItem5
      // 
      this.MenuItem5.Index = 3;
      this.MenuItem5.Text = "-";
      // 
      // mnuFileQuit
      // 
      this.mnuFileQuit.Index = 4;
      this.mnuFileQuit.Text = "Quit";
      this.mnuFileQuit.Click += new System.EventHandler(this.mnuFileQuit_Click);
      // 
      // dlgFileSave
      // 
      this.dlgFileSave.FileName = "doc1";
      // 
      // rtxtText
      // 
      this.rtxtText.Location = new System.Drawing.Point(0, -2);
      this.rtxtText.Name = "rtxtText";
      this.rtxtText.Size = new System.Drawing.Size(472, 416);
      this.rtxtText.TabIndex = 1;
      this.rtxtText.Text = "";
      // 
      // frmScratchPad
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(472, 413);
      this.Controls.Add(this.rtxtText);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mnuMain;
      this.Name = "frmScratchPad";
      this.Text = "ScratchPad";
      this.Resize += new System.EventHandler(this.frmScratchPad_Resize);
      this.ResumeLayout(false);

    }
    
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmDefault'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmScratchPad()
    //***
    // Action
    //   - Create instance of 'frmScratchPad'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmScratchPad()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmScratchPad_Resize(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Set the height and the width of the richtext textbox
    // Called by
    //   - User action (Resizing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      rtxtText.Width = this.Width - 10;
      rtxtText.Height = this.Height - 50;
    }
    // frmScratchPad_Resize(System.Object, System.EventArgs) Handles frmScreatchPad.Resize

    private void mnuFileNew_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Clear (make blanc) the richtext textbox
    // Called by
    //   - User action (Clicking a menuitem)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      rtxtText.Clear();
    }
    // mnuFileNew_Click(System.Object, System.EventArgs) Handles mnuFileNew.Click

    private void mnuFileOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Prepare and show a FileOpen dialogbox
    //   - strFileName becomes the FileOpen dialogbox FileName
    //   - If strFilename was filled in
    //     - Determine 4 positions for the extension
    //     - If extension is ".TXT"
    //       - intFileType becomes PlainText
    //     - If Not
    //       - intFileType becomes RichText
    //     - Load the content of the file (strFileName) into the richtext textbox
    //   - If Not
    //     - Do nothing
    // Called by
    //   - User action (Clicking a menuitem)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      RichTextBoxStreamType intFileType;
      string strFileName;
      string strSub;

      dlgFileOpen.DefaultExt = "*.rtf";
      dlgFileOpen.Filter = "RichText Files|*.rtf|Text Files|*.txt";
      dlgFileOpen.ShowDialog();
      strFileName = dlgFileOpen.FileName;

      if (strFileName.Length > 0)
      {
        strSub = strFileName.Substring(strFileName.Length - 4, 4);

        if (strSub.ToUpper() == ".TXT")
        {
          intFileType = RichTextBoxStreamType.PlainText;
        }
        else
        // strSub.ToUpper() <> ".TXT"
        {
          intFileType = RichTextBoxStreamType.RichText;
        }
        // strSub.ToUpper() = ".TXT"

        rtxtText.LoadFile(strFileName, intFileType);
      }
      else
      // strFileName.Length <= 0
      {
      }
      // strFileName.Length > 0

    }
    // mnuFileOpen_Click(System.Object, System.EventArgs) Handles mnuFileOpen.Click

    private void mnuFileQuit_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - End the program
    // Called by
    //   - User action (Clicking a menuitem)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.Close();
    }
    // mnuFileQuit_Click(System.Object, System.EventArgs) Handles mnuFileQuit.Click

    private void mnuFileSave_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Prepare and show a FileSave dialogbox
    //   - strFileName becomes the FileOpen dialogbox FileName
    //   - If strFilename was filled in
    //     - Determine 4 positions for the extension
    //     - If extension is ".TXT"
    //       - intFileType becomes PlainText
    //     - If Not
    //       - intFileType becomes RichText
    //     - Save the richtext textbox content into a file (strFileName)
    //   - If Not
    //     - Do nothing
    // Called by
    //   - User action (Clicking a menuitem)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      RichTextBoxStreamType intFileType;
      string strFileName;
      string strSub;

      dlgFileSave.DefaultExt = "*.rtf";
      dlgFileSave.Filter = "RichText Files|*.rtf|Text Files|*.txt";
      dlgFileSave.ShowDialog();
      strFileName = dlgFileSave.FileName;

      if (strFileName.Length > 0)
      {
        strSub = strFileName.Substring(strFileName.Length - 4, 4);

        if (strSub.ToUpper() == ".TXT")
        {
          intFileType = RichTextBoxStreamType.PlainText;
        }
        else
        // strSub.ToUpper() <> ".TXT"
        {
          intFileType = RichTextBoxStreamType.RichText;
        }
        // strSub.ToUpper() = ".TXT"

        rtxtText.SaveFile(strFileName, intFileType);
      }
      else
      // strFileName.Length <= 0
      {
      }
      // strFileName.Length > 0

    }
    // mnuFileSave_Click(System.Object, System.EventArgs) Handles mnuFileSave.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmScratchPad
    //   - The Single Treath Apartment Attribute must be there
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmScratchPad());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmScratchPad

}
// ScratchPad