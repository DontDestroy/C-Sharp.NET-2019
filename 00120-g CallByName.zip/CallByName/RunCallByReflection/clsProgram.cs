//***
// Action
//   - Testroutine of cpMath
// Created
//   - CopyPaste � 20240618 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240618 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System.Reflection;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Make a new instance of cpMath
      //   - Create an array of numbers
      //   - Define a methodinfo
      //   - Give a variable the value "Add" (or "Multiply")
      //   - Find the correct method to run
      //   - Create the parameters as array of objects
      //   - Do the calculation
      //   - Show a messagebox of the result
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpMath()
      //   - cpMath.Add() As Int32
      //   - cpMath.Multiply() As Int32
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - I use here the reflection 
      //   - You can use also Visual Basic Method Interaction.CallByName (See other project)
      //***
    {
      cpMath thecpMath; 
      int[] arrlngNumber = new int[] {1, 2, 3, 4};
      MethodInfo theMethodInfo;
      System.Object objResult;
      System.Object[] arrobjParameter;
      string strMethod;

      thecpMath = new cpMath();
      strMethod = "Add";
      // strMethod = "Multiply";

      theMethodInfo = typeof (cpMath).GetMethod(strMethod);
      arrobjParameter = new System.Object[] {arrlngNumber};
      objResult = theMethodInfo.Invoke(thecpMath, arrobjParameter);

      MessageBox.Show(objResult.ToString());
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning