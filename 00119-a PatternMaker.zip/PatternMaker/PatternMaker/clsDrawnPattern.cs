//***
// Action
//   - Implementation of a cpDrawnPattern
//     - This is a picture using only lines
//     - Lines are drawn using coordinates of points
//   - It is an implementation of cpPattern
//     - Implement a clone functionality (copy the pattern)
//     - Implement a draw functionality (visualize the pattern)
//     - Implement an editor for drawing the pattern (drawing)
//       - Draw a new pattern, change a copy of a pattern using an editor
// Created
//   - CopyPaste � 20240330 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240330 � VVDW
// Proposal (To Do)
//   -
//***

using System.Drawing;

namespace CopyPaste.Learning
{

  public class cpDrawnPattern : cpPattern
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private Point[] marrPoints = new Point[] {};

    #endregion

    #region "Properties"

    public Point[] Points
    {

      get
        //***
        // Action Get
        //   - Returns the array of points marrPoints
        // Called by
        //   - cpPattern cpClone()
        //   - cpDraw(System.Object, System.Windows.Forms.PaintEventArgs)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240330 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240330 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return marrPoints;
      }
      // Point[] Points (Get)

      set
        //***
        // Action Set
        //   - The array of points marrPoints becomes arrValue
        // Called by
        //   - cpPattern cpPattern.cpClone()
        //   - cpctlDrawnPatternEditor.cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240330 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240330 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        marrPoints = value;
      }
      // Points(Point[]) (Set)

    }
    // Point[] Points

    #endregion

    #region "Methods"

    #region "Overrides"

    public override cpPattern cpClone()
      //***
      // Action
      //   - A cpDrawnPattern is created
      //   - The array of points are cloned
      //   - the created cpDrawnPattern is returned
      // Called by
      //   - frmPatternMaker.TemplateClick(System.Object, System.EventArgs)
      // Calls
      //   - cpPattern()
      //   - Point[] Points (Get)
      //   - Points(Point[]) (Set)
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpDrawnPattern thePattern = new cpDrawnPattern();

      thePattern.Points = (Point[])Points.Clone();
      return thePattern;
    }
    // cpPattern cpClone()

    public override void cpDraw(System.Object theSender, System.Windows.Forms.PaintEventArgs thePaintEventArguments)
      //***
      // Action
      //   - There is an array of points
      //   - A rectangle is drawn of 60 by 60 pixels
      //   - For every pair of points in the array
      //     - A line is drawn using the pair or coordinates
      // Called by
      //   - 
      // Calls
      //   - Point[] Points (Get)
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int intPoint;

      thePaintEventArguments.Graphics.DrawRectangle(Pens.Black, 0, 0, 60, 60);

      for (intPoint = 0; intPoint < Points.Length - 1; intPoint++)
      {                                                                
        Point thePointOne = Points[intPoint];
        Point thePointTwo = Points[intPoint + 1];

        thePaintEventArguments.Graphics.DrawLine(Pens.Black, thePointOne, thePointTwo);
      }
      // intPoint = Points.Length - 1

    }
    // cpDraw(System.Object, System.Windows.Forms.PaintEventArgs)

    public override cpctlPatternEditor cpGetEditor()
      //***
      // Action
      //   - Return a cpctlDrawnPatternEditor
      //   - The class cpDrawnPattern is given in the constructor
      // Called by
      //   - 
      // Calls
      //   - cpctlDrawnPatternEditor(cpDrawnPattern)
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return new cpctlDrawnPatternEditor(this);
    }
    // cpctlPatternEditor cpGetEditor()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpDrawnPattern

}
// CopyPaste.Learning