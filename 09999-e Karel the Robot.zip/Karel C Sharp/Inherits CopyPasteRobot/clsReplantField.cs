﻿//***
// Action
//   - A definition of a ReplantField
// Created
//   - CopyPaste – 20251016 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251016 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpReplantField: cpReplanter
	{

		#region "Constructors / Destructors"

		public cpReplantField(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpReplantField starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpReplantFieldMultipleFiles(int, int, Directions.Direction, int, Color) 
    // Calls
    //   - cpReplanter(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251016 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251016 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpReplantField(int, int, Directions.Direction, int, Color) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override void ReplantCorner()
    //***
    // Action
    //   - If there is no beeper
    //     - Plant a beeper
    //   - If not
    //     - Pick the beeper
    //     - If there is no beeper
    //       - Plant a beeper
    //     - If not
    //       - Do nothing
    // Called by
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251016 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251016 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (nextToABeeper())
      {
        pickBeeper();

        if (nextToABeeper())
        {
        }
        else
        // Not nextToABeeper()
        {
          putBeeper();
        }
        // nextToABeeper()

      }
      else
      // Not nextToABeeper()
      {
        putBeeper();
      }
      // nextToABeeper()

    }
    // ReplantCorner()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpReplantField

}
// cpKarelTheRobot