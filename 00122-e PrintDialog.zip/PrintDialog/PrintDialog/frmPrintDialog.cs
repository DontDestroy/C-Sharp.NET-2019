//***
// Action
//   - Demo of printing multiple pages with page setup and print preview
// Created
//   - CopyPaste � 20240527 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240527 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPrintDialog: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Drawing.Printing.PrintDocument prtDocument;
    internal System.Windows.Forms.RichTextBox rtxtText;
    internal System.Windows.Forms.PrintDialog dlgPrint;
    internal System.Windows.Forms.OpenFileDialog dlgFileOpen;
    internal System.Windows.Forms.Button cmdPrint;
    internal System.Windows.Forms.Button cmdPageSetup;
    internal System.Windows.Forms.Button cmdPrintPreview;
    internal System.Windows.Forms.PrintPreviewDialog dlgPrintPreview;
    internal System.Windows.Forms.PageSetupDialog dlgPageSetup;
    internal System.Windows.Forms.Button cmdOpen;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPrintDialog));
      this.prtDocument = new System.Drawing.Printing.PrintDocument();
      this.rtxtText = new System.Windows.Forms.RichTextBox();
      this.dlgPrint = new System.Windows.Forms.PrintDialog();
      this.dlgFileOpen = new System.Windows.Forms.OpenFileDialog();
      this.cmdPrint = new System.Windows.Forms.Button();
      this.cmdOpen = new System.Windows.Forms.Button();
      this.cmdPageSetup = new System.Windows.Forms.Button();
      this.cmdPrintPreview = new System.Windows.Forms.Button();
      this.dlgPrintPreview = new System.Windows.Forms.PrintPreviewDialog();
      this.dlgPageSetup = new System.Windows.Forms.PageSetupDialog();
      this.SuspendLayout();
      // 
      // prtDocument
      // 
      this.prtDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.prtDocument_PrintPage);
      // 
      // rtxtText
      // 
      this.rtxtText.Location = new System.Drawing.Point(8, 104);
      this.rtxtText.Name = "rtxtText";
      this.rtxtText.Size = new System.Drawing.Size(312, 160);
      this.rtxtText.TabIndex = 5;
      this.rtxtText.Text = "";
      // 
      // cmdPrint
      // 
      this.cmdPrint.Enabled = false;
      this.cmdPrint.Location = new System.Drawing.Point(24, 56);
      this.cmdPrint.Name = "cmdPrint";
      this.cmdPrint.Size = new System.Drawing.Size(96, 32);
      this.cmdPrint.TabIndex = 4;
      this.cmdPrint.Text = "&Print";
      this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
      // 
      // cmdOpen
      // 
      this.cmdOpen.Location = new System.Drawing.Point(24, 16);
      this.cmdOpen.Name = "cmdOpen";
      this.cmdOpen.Size = new System.Drawing.Size(96, 32);
      this.cmdOpen.TabIndex = 3;
      this.cmdOpen.Text = "&Open";
      this.cmdOpen.Click += new System.EventHandler(this.cmdOpen_Click);
      // 
      // cmdPageSetup
      // 
      this.cmdPageSetup.Enabled = false;
      this.cmdPageSetup.Location = new System.Drawing.Point(128, 16);
      this.cmdPageSetup.Name = "cmdPageSetup";
      this.cmdPageSetup.Size = new System.Drawing.Size(96, 32);
      this.cmdPageSetup.TabIndex = 6;
      this.cmdPageSetup.Text = "Page &setup";
      this.cmdPageSetup.Click += new System.EventHandler(this.cmdPageSetup_Click);
      // 
      // cmdPrintPreview
      // 
      this.cmdPrintPreview.Enabled = false;
      this.cmdPrintPreview.Location = new System.Drawing.Point(128, 56);
      this.cmdPrintPreview.Name = "cmdPrintPreview";
      this.cmdPrintPreview.Size = new System.Drawing.Size(96, 32);
      this.cmdPrintPreview.TabIndex = 7;
      this.cmdPrintPreview.Text = "Print Previe&w";
      this.cmdPrintPreview.Click += new System.EventHandler(this.cmdPrintPreview_Click);
      // 
      // dlgPrintPreview
      // 
      this.dlgPrintPreview.AutoScrollMargin = new System.Drawing.Size(0, 0);
      this.dlgPrintPreview.AutoScrollMinSize = new System.Drawing.Size(0, 0);
      this.dlgPrintPreview.ClientSize = new System.Drawing.Size(400, 300);
      this.dlgPrintPreview.Enabled = true;
      this.dlgPrintPreview.Icon = ((System.Drawing.Icon)(resources.GetObject("dlgPrintPreview.Icon")));
      this.dlgPrintPreview.Location = new System.Drawing.Point(15, 12);
      this.dlgPrintPreview.MinimumSize = new System.Drawing.Size(375, 250);
      this.dlgPrintPreview.Name = "dlgPrintPreview";
      this.dlgPrintPreview.TransparencyKey = System.Drawing.Color.Empty;
      this.dlgPrintPreview.Visible = false;
      // 
      // frmPrintDialog
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(328, 269);
      this.Controls.Add(this.cmdPageSetup);
      this.Controls.Add(this.cmdPrintPreview);
      this.Controls.Add(this.rtxtText);
      this.Controls.Add(this.cmdPrint);
      this.Controls.Add(this.cmdOpen);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPrintDialog";
      this.Text = "File Print";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPrintDialog'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPrintDialog()
      //***
      // Action
      //   - Create instance of 'frmPrintDialog'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      mthePrintFont = new Font("Arial", 10);
      mthePrintPageSettings = new PageSettings();
    }
    // frmPrintDialog()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrToPrint;
    private Font mthePrintFont;
    private PageSettings mthePrintPageSettings;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Initialize the file open dialog
      //     - Textfiles
      //     - Current directory
      //   - Show the file open dialog
      //   - If there is a filename
      //     - Try
      //       - Define a file stream with the choosen file
      //       - Load the file into the rich text box
      //       - Close the file
      //       - Take the text of the rich text box and place it in mstrToPrint
      //       - Enable the print button
      //       - Enable the print preview button
      //       - Enable the page setup button
      //     - When there is an error
      //       - Show the corresponding error message
      //   - If not
      //     - Nothing happens
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strFilePath;

      dlgFileOpen.Filter = "Text files (*.txt)|*.txt";
      dlgFileOpen.InitialDirectory = Environment.CurrentDirectory;
      dlgFileOpen.ShowDialog();

      if (dlgFileOpen.FileName == "")
      {
      }
      else
        // dlgFileOpen.FileName <> ""
      {
        strFilePath = dlgFileOpen.FileName;

        try
        {
          FileStream theFileStream = new FileStream(strFilePath, FileMode.Open);

          rtxtText.LoadFile(theFileStream, RichTextBoxStreamType.PlainText);
          theFileStream.Close();
          mstrToPrint = rtxtText.Text;
          cmdPrint.Enabled = true;
          cmdPageSetup.Enabled = true;
          cmdPrintPreview.Enabled = true;
        }
        catch (Exception theException)
        {
          MessageBox.Show(theException.Message);
        }
        finally
        {
        }

      }
      // dlgFileOpen.FileName = ""

    }
    // cmdOpen_Click(System.Object, System.EventArgs) Handles cmdOpen.Click

    private void cmdPageSetup_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try
      //     - Define the page settings
      //     - Show the page setup dialog
      //   - When there is an error
      //     - Show the corresponding error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      
      try
      {
        dlgPageSetup.PageSettings = mthePrintPageSettings;
        dlgPageSetup.ShowDialog();
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // cmdPageSetup_Click(System.Object, System.EventArgs) Handles cmdPageSetup.Click

    private void cmdPrint_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try
      //     - Initialize the values of the print document
      //     - Show the print dialog
      //     - If button OK is clicked
      //       - Print the document
      //     - If not
      //       - Nothing happens
      //   - When there is an error
      //     - Show the corresponding error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        DialogResult shtResult; 

        prtDocument.DefaultPageSettings = mthePrintPageSettings;
        mstrToPrint = rtxtText.Text;
        dlgPrint.Document = prtDocument;

        shtResult = dlgPrint.ShowDialog();

        if (shtResult == DialogResult.OK)
        {
          prtDocument.Print();
        }
        else
          // shtResult <> DialogResult.OK
        {
        }
        // shtResult = DialogResult.OK

      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // cmdPrint_Click(System.Object, System.EventArgs) Handles cmdPrint.Click
    
    private void cmdPrintPreview_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try
      //     - Define the page settings
      //     - mstrToPrint becomes the text from the textbox
      //     - The print document is the document to preview
      //     - Show the print preview dialog
      //   - When there is an error
      //     - Show the corresponding error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        prtDocument.DefaultPageSettings = mthePrintPageSettings;
        mstrToPrint = rtxtText.Text;
        dlgPrintPreview.Document = prtDocument;
        dlgPrintPreview.ShowDialog();
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // cmdPrintPreview_Click(System.Object, System.EventArgs) Handles cmdPrintPreview.Click

    private void prtDocument_PrintPage(System.Object theSender, PrintPageEventArgs thePrintPageEventArguments)
      //***
      // Action
      //   - Define a rectangle where the margins of your page are
      //   - Define a size where your place is to print on the page
      //   - Calculate the length of the string using MeasureString
      //   - Take the part that an be printed
      //   - Draw that part on the graphics
      //   - Check if all is printed
      //     - Set HasMorePages to false
      //     - mstrToPrint becomes the text (for the next time you want to print)
      //   - If Not
      //     - Take the rest of the text that must be printed
      //     - Set HasMorePages to true
      // Called by
      //   - System action (Printing a page)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngNumChars;
      int lngNumLines;
      string strForPage;
      StringFormat theFormat = new StringFormat();

      RectangleF theRectDraw = new RectangleF(
        thePrintPageEventArguments.MarginBounds.Left, 
        thePrintPageEventArguments.MarginBounds.Top,
        thePrintPageEventArguments.MarginBounds.Width,
        thePrintPageEventArguments.MarginBounds.Height);
      SizeF theSizeMeasure = new SizeF(
        thePrintPageEventArguments.MarginBounds.Width, 
        thePrintPageEventArguments.MarginBounds.Height - mthePrintFont.GetHeight(thePrintPageEventArguments.Graphics));

      theFormat.Trimming = StringTrimming.Word;
      thePrintPageEventArguments.Graphics.MeasureString(mstrToPrint, mthePrintFont, theSizeMeasure, theFormat, out lngNumChars, out lngNumLines);
      strForPage = mstrToPrint.Substring(0, lngNumChars);
      thePrintPageEventArguments.Graphics.DrawString(strForPage, mthePrintFont, Brushes.Black, theRectDraw, theFormat);

      if (lngNumChars < mstrToPrint.Length)
      {
        mstrToPrint = mstrToPrint.Substring(lngNumChars);
        thePrintPageEventArguments.HasMorePages = true;
      }
      else
        // lngNumChars >= mstrToPrint.Length
      {
        thePrintPageEventArguments.HasMorePages = false;
        mstrToPrint = rtxtText.Text;
      }
      // lngNumChars < mstrToPrint.Length
    
    }
    // prtDocument_PrintPage(System.Object, System.Drawing.Printing.PrintPageEventArgs) Handles prtDocument.PrintPage

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPrintDialog
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmPrintDialog()
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPrintDialog());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPrintDialog

}
// CopyPaste.Learning