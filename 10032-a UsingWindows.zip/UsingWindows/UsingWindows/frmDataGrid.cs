//***
// Action
//   - Demo of a datagrid bound control (There is a hierarchy)
// Created
//   - CopyPaste � 20260113 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260113 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDataGrid: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.DataGrid dgrProductOrders;
    internal System.Windows.Forms.DataGridTableStyle dgrtblstlProduct;
    internal System.Windows.Forms.DataGridTableStyle dgrtblstlOrder;
    internal System.Windows.Forms.TextBox txtPosition;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Button cmdLast;
    internal System.Windows.Forms.Button cmdPrevious;
    internal System.Windows.Forms.Button cmdFirst;
    internal System.Windows.Forms.TextBox txtDescription;
    internal System.Windows.Forms.TextBox txtCategoryName;
    internal System.Windows.Forms.Label lblName;
    internal System.Windows.Forms.TextBox txtIdCategory;
    internal System.Data.SqlClient.SqlConnection cnncpNorthWind2019;
    internal System.Data.SqlClient.SqlDataAdapter dtaProduct;
    internal System.Data.SqlClient.SqlCommand cmmSelectProduct;
    internal System.Data.SqlClient.SqlDataAdapter dtaCategory;
    internal System.Data.SqlClient.SqlCommand cmmSelectCategory;
    internal System.Data.SqlClient.SqlDataAdapter dtaOrderDate;
    internal System.Data.SqlClient.SqlCommand cmmSelectOrderDates;
    private UsingWindows.dsData dsData;
    internal System.Windows.Forms.Label lblIdCategory;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataGrid));
      this.dgrProductOrders = new System.Windows.Forms.DataGrid();
      this.dsData = new UsingWindows.dsData();
      this.dgrtblstlProduct = new System.Windows.Forms.DataGridTableStyle();
      this.dgrtblstlOrder = new System.Windows.Forms.DataGridTableStyle();
      this.txtPosition = new System.Windows.Forms.TextBox();
      this.cmdNext = new System.Windows.Forms.Button();
      this.cmdLast = new System.Windows.Forms.Button();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.cmdFirst = new System.Windows.Forms.Button();
      this.txtDescription = new System.Windows.Forms.TextBox();
      this.txtCategoryName = new System.Windows.Forms.TextBox();
      this.lblName = new System.Windows.Forms.Label();
      this.txtIdCategory = new System.Windows.Forms.TextBox();
      this.lblIdCategory = new System.Windows.Forms.Label();
      this.cnncpNorthWind2019 = new System.Data.SqlClient.SqlConnection();
      this.dtaProduct = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectProduct = new System.Data.SqlClient.SqlCommand();
      this.dtaCategory = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectCategory = new System.Data.SqlClient.SqlCommand();
      this.dtaOrderDate = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectOrderDates = new System.Data.SqlClient.SqlCommand();
      ((System.ComponentModel.ISupportInitialize)(this.dgrProductOrders)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.SuspendLayout();
      // 
      // dgrProductOrders
      // 
      this.dgrProductOrders.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrProductOrders.DataMember = "tblCPCategory.ProductCategory";
      this.dgrProductOrders.DataSource = this.dsData;
      this.dgrProductOrders.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrProductOrders.Location = new System.Drawing.Point(16, 96);
      this.dgrProductOrders.Name = "dgrProductOrders";
      this.dgrProductOrders.Size = new System.Drawing.Size(344, 256);
      this.dgrProductOrders.TabIndex = 16;
      this.dgrProductOrders.TableStyles.AddRange(new System.Windows.Forms.DataGridTableStyle[] {
            this.dgrtblstlProduct,
            this.dgrtblstlOrder});
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // dgrtblstlProduct
      // 
      this.dgrtblstlProduct.DataGrid = this.dgrProductOrders;
      this.dgrtblstlProduct.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrtblstlProduct.MappingName = "ProductCategory";
      // 
      // dgrtblstlOrder
      // 
      this.dgrtblstlOrder.DataGrid = this.dgrProductOrders;
      this.dgrtblstlOrder.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrtblstlOrder.MappingName = "OrderDateProduct";
      // 
      // txtPosition
      // 
      this.txtPosition.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.txtPosition.Location = new System.Drawing.Point(80, 360);
      this.txtPosition.Name = "txtPosition";
      this.txtPosition.Size = new System.Drawing.Size(208, 20);
      this.txtPosition.TabIndex = 19;
      // 
      // cmdNext
      // 
      this.cmdNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdNext.Location = new System.Drawing.Point(296, 360);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(32, 23);
      this.cmdNext.TabIndex = 20;
      this.cmdNext.Text = ">";
      this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
      // 
      // cmdLast
      // 
      this.cmdLast.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdLast.Location = new System.Drawing.Point(328, 360);
      this.cmdLast.Name = "cmdLast";
      this.cmdLast.Size = new System.Drawing.Size(32, 23);
      this.cmdLast.TabIndex = 21;
      this.cmdLast.Text = ">>|";
      this.cmdLast.Click += new System.EventHandler(this.cmdLast_Click);
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdPrevious.Location = new System.Drawing.Point(40, 360);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(32, 23);
      this.cmdPrevious.TabIndex = 18;
      this.cmdPrevious.Text = "<";
      this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
      // 
      // cmdFirst
      // 
      this.cmdFirst.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdFirst.Location = new System.Drawing.Point(8, 360);
      this.cmdFirst.Name = "cmdFirst";
      this.cmdFirst.Size = new System.Drawing.Size(32, 23);
      this.cmdFirst.TabIndex = 17;
      this.cmdFirst.Text = "|<<";
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      // 
      // txtDescription
      // 
      this.txtDescription.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPCategory.memDescription", true));
      this.txtDescription.Location = new System.Drawing.Point(16, 64);
      this.txtDescription.Name = "txtDescription";
      this.txtDescription.Size = new System.Drawing.Size(344, 20);
      this.txtDescription.TabIndex = 15;
      // 
      // txtCategoryName
      // 
      this.txtCategoryName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPCategory.strCategoryName", true));
      this.txtCategoryName.Location = new System.Drawing.Point(104, 36);
      this.txtCategoryName.Name = "txtCategoryName";
      this.txtCategoryName.Size = new System.Drawing.Size(256, 20);
      this.txtCategoryName.TabIndex = 14;
      // 
      // lblName
      // 
      this.lblName.AutoSize = true;
      this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblName.Location = new System.Drawing.Point(16, 40);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(43, 13);
      this.lblName.TabIndex = 13;
      this.lblName.Text = "Name:";
      // 
      // txtIdCategory
      // 
      this.txtIdCategory.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPCategory.intIdCategory", true));
      this.txtIdCategory.Location = new System.Drawing.Point(104, 8);
      this.txtIdCategory.Name = "txtIdCategory";
      this.txtIdCategory.Size = new System.Drawing.Size(256, 20);
      this.txtIdCategory.TabIndex = 12;
      // 
      // lblIdCategory
      // 
      this.lblIdCategory.AutoSize = true;
      this.lblIdCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblIdCategory.Location = new System.Drawing.Point(16, 16);
      this.lblIdCategory.Name = "lblIdCategory";
      this.lblIdCategory.Size = new System.Drawing.Size(86, 13);
      this.lblIdCategory.TabIndex = 11;
      this.lblIdCategory.Text = "Category Key:";
      // 
      // cnncpNorthWind2019
      // 
      this.cnncpNorthWind2019.ConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthWind2019.FireInfoMessageEventOnUserErrors = false;
      // 
      // dtaProduct
      // 
      this.dtaProduct.SelectCommand = this.cmmSelectProduct;
      this.dtaProduct.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPProduct", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intCategoryId", "intCategoryId"),
                        new System.Data.Common.DataColumnMapping("intIdProduct", "intIdProduct"),
                        new System.Data.Common.DataColumnMapping("strProductName", "strProductName"),
                        new System.Data.Common.DataColumnMapping("blnDiscontinued", "blnDiscontinued"),
                        new System.Data.Common.DataColumnMapping("dblUnitPrice", "dblUnitPrice")})});
      // 
      // cmmSelectProduct
      // 
      this.cmmSelectProduct.CommandText = "SELECT        intCategoryId, intIdProduct, strProductName, blnDiscontinued, dblUn" +
    "itPrice\r\nFROM            tblCPProduct";
      this.cmmSelectProduct.Connection = this.cnncpNorthWind2019;
      // 
      // dtaCategory
      // 
      this.dtaCategory.SelectCommand = this.cmmSelectCategory;
      this.dtaCategory.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCategory", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdCategory", "intIdCategory"),
                        new System.Data.Common.DataColumnMapping("strCategoryName", "strCategoryName"),
                        new System.Data.Common.DataColumnMapping("memDescription", "memDescription")})});
      // 
      // cmmSelectCategory
      // 
      this.cmmSelectCategory.CommandText = "SELECT        intIdCategory, strCategoryName, memDescription\r\nFROM            tbl" +
    "CPCategory";
      this.cmmSelectCategory.Connection = this.cnncpNorthWind2019;
      // 
      // dtaOrderDate
      // 
      this.dtaOrderDate.SelectCommand = this.cmmSelectOrderDates;
      this.dtaOrderDate.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "OrderDate", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("dtmOrderDate", "dtmOrderDate"),
                        new System.Data.Common.DataColumnMapping("intProductId", "intProductId")})});
      // 
      // cmmSelectOrderDates
      // 
      this.cmmSelectOrderDates.CommandText = resources.GetString("cmmSelectOrderDates.CommandText");
      this.cmmSelectOrderDates.Connection = this.cnncpNorthWind2019;
      // 
      // frmDataGrid
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(368, 389);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.cmdFirst);
      this.Controls.Add(this.txtDescription);
      this.Controls.Add(this.txtCategoryName);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.txtIdCategory);
      this.Controls.Add(this.lblIdCategory);
      this.Controls.Add(this.txtPosition);
      this.Controls.Add(this.dgrProductOrders);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.cmdLast);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataGrid";
      this.Text = "Windows Controls Datagrid";
      ((System.ComponentModel.ISupportInitialize)(this.dgrProductOrders)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDataGrid'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDataGrid()
      //***
      // Action
      //   - Create new instance of 'frmDataGrid'
      //   - Fill the data set tblCPCategory with data adapter category
      //   - Fill the data set tblCPProduct with data adapter product
      //   - Fill the data set OrderDate with data adapter orderdate
      //   - Update the display
      // Called by
      //   - frmMaster.cmdDataGrid_Click(System.Object, System.EventArgs) Handles cmdDataGrid.Click
      // Calls
      //   - InitializeComponent()
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
      dtaCategory.Fill(dsData.tblCPCategory);
      dtaProduct.Fill(dsData.tblCPProduct);
      dtaOrderDate.Fill(dsData.OrderDate);
      UpdateDisplay();
    }
    // frmDataGrid()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFirst_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the first position
      //   - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsData, "tblCPCategory"].Position = 0;
      UpdateDisplay();
    }
    // cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click

    private void cmdLast_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the last position
      //   - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsData, "tblCPCategory"].Position = BindingContext[dsData, "tblCPCategory"].Count - 1;
      UpdateDisplay();
    }
    // cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click

    private void cmdNext_Click(System.Object theSender, System.EventArgs theEventArguments)
      // Action
      //   - If you are at the last position
      //     - Do nothing
      //   - If not
      //     - Go to the next position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
        
      if (BindingContext[dsData, "tblCPCategory"].Position == BindingContext[dsData, "tblCPCategory"].Count - 1)
      {
      }
      else
        // BindingContext[dsData, "tblCPCategory"].Position <> BindingContext[dsData, "tblCPCategory"].Count - 1 
      {
        BindingContext[dsData, "tblCPCategory"].Position += 1;
        UpdateDisplay();
      }
      // BindingContext[dsData, "tblCPCategory"].Position = BindingContext[dsData, "tblCPCategory"].Count - 1 
    
    }
    // cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click

    private void cmdPrevious_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If you are at the first position
      //     - Do nothing
      //   - If not
      //     - Go to the previous position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (BindingContext[dsData, "tblCPCategory"].Position == 0)
      {
      }
      else
        // BindingContext[dsData, "tblCPCategory"].Position <> 0
      {
        BindingContext[dsData, "tblCPCategory"].Position -= 1;
        UpdateDisplay();
      }
      // BindingContext[dsData, "tblCPCategory"].Position = 0

    }
    // cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void UpdateDisplay()
      //***
      // Action
      //   - Define a binding manager base
      //   - Assign the binding manager base to the data table Category from the data set
      //   - Show the current position
      // Called by
      //   - cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click
      //   - cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click
      //   - cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click
      //   - cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click
      //   - frmDataGrid()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingManagerBase bmbBindingManagerBase; 

      bmbBindingManagerBase = BindingContext[dsData, "tblCPCategory"];

      txtPosition.Text = "Category ";
      txtPosition.Text += (bmbBindingManagerBase.Position + 1).ToString();
      txtPosition.Text += " of ";
      txtPosition.Text += bmbBindingManagerBase.Count.ToString();
    }
    // UpdateDisplay()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataGrid

}
// CopyPaste.Learning