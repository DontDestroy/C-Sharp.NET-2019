﻿//***
// Action
//   - A definition of a harvester
// Created
//   - CopyPaste – 20251013 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251013 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpHarvesterVersion01 : kareltherobot.Robot
	{

		#region "Constructors / Destructors"

		public cpHarvesterVersion01(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Robot becomes a cpHarvesterVersion01 starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
		//   - Nothing else happens
		// Called by
		//   - 
		// Calls
		//   - cpHarvesterVersion01(int, int, Directions.Direction, int, Color)
		// Created
		//   - CopyPaste – 20251013 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251013 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
		}
		// cpHarvesterVersion01(int, int, Directions.Direction, int) 

		public cpHarvesterVersion01(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpHarvesterVersion01 starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpBadFieldHarvester(int, int, Directions.Direction, int, Color)
    //   - cpHarvesterVersion01(int, int, Directions.Direction, int)
    //   - cpProgram.RemoveBeepersVersion01MultipleFiles()
    //   - cpProgram.RemoveBeepersVersion03MultipleFiles()
    //   - cpRemoveBeepersVersion01MultipleFiles(int, int, Directions.Direction, int, Color) 
    //   - cpRemoveBeepersVersion03MultipleFiles(int, int, Directions.Direction, int, Color) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251013 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251013 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
		// cpHarvesterVersion01(int, int, Directions.Direction, int, Color) 

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public virtual void HarvestCorner()
		//***
		// Action
		//   - Pick the beeper
		// Called by
		//   - cpBadFieldHarvester.HarvestCorner()
		//   - HarvestOneRow()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251013 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251013 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			pickBeeper();
		}
		// HarvestCorner()

		private void HarvestOneRow()
		//***
		// Action
		//   - Take the beeper (harvest corner)
		//   - Move forward
		//   - Repeat this another 3 times
		//   - Take the beeper (harvest corner)
		// Called by
		//   - HarvestTwoRows()
		// Calls
		//   - HarvestCorner()
		// Created
		//   - CopyPaste – 20251013 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251013 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			HarvestCorner();
			move();
			HarvestCorner();
			move();
			HarvestCorner();
			move();
			HarvestCorner();
			move();
			HarvestCorner();
		}
		// HarvestOneRow()

		public void HarvestTwoRows()
    //***
    // Action
    //   - Harvest one row (going from left to right)
    //   - Position of the row above
    //     - Go one row up
    //     - Look to the other direction (look to the left)
    //   - Harvest one row (going from right to left)
    // Called by
    //   - cpRemoveBeepersVersion01MultipleFiles.HarvestTheField()
    //   - cpRemoveBeepersVersion03MultipleFiles.HarvestTheField()
    //   - cpRemoveBeepersVersion04MultipleFiles.HarvestTheField() (thru inheritance)
    //   - cpRemoveBeepersVersion05MultipleFiles.HarvestTheField() (thru inheritance)
    // Calls
    //   - HarvestOneRow()
    //   - PositionForNextRow()
    // Created
    //   - CopyPaste – 20251013 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251013 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      HarvestOneRow();
			PositionForNextRow();
			HarvestOneRow();
		}
		// HarvestTwoRows()

		public void PositionForNextHarvest()
    //***
    // Action
    //   - Turn to the right (looking North)
    //   - Go one forward (move up)
    //   - Turn to the right (looking East)
    // Called by
    //   - cpRemoveBeepersVersion01MultipleFiles.HarvestTheField()
    //   - cpRemoveBeepersVersion03MultipleFiles.HarvestTheField()
    //   - cpRemoveBeepersVersion04MultipleFiles.HarvestTheField() (thru inheritance)
    //   - cpRemoveBeepersVersion05MultipleFiles.HarvestTheField() (thru inheritance)
    // Calls
    //   - TurnRight()
    // Created
    //   - CopyPaste – 20251013 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251013 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      TurnRight();
			move();
			TurnRight();
		}
		// PositionForNextHarvest()

		private void PositionForNextRow()
		//***
		// Action
		//   - Turn to the left (looking North)
		//   - Go one forward (move up)
		//   - Turn to the left (looking West)
		// Called by
		//   - HarvestTwoRows()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251013 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251013 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			turnLeft();
			move();
			turnLeft();
		}
		// PositionForNextRow()

		private void TurnRight()
		//***
		// Action
		//   - Turn to the right by turning 3 times to the left
		// Called by
		//   - PositionForNextHarvest()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251013 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251013 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			turnLeft();
			turnLeft();
			turnLeft();
		}
		// TurnRight()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpHarvesterVersion01

}
// cpKarelTheRobot