﻿//***
// Action
//   - Example of a web service (predicting the future)
// Created
//   - CopyPaste – 20260424 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260424 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace CopyPaste.Learning
{

  [WebService(Namespace = "http://www.copypaste.eu/webservices/")]
  [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
  [System.ComponentModel.ToolboxItem(false)]
  public class cpPredictFutureWebService : System.Web.Services.WebService
  {

    #region Web Service Designer generated code

    System.ComponentModel.IContainer components;

    [System.Diagnostics.DebuggerStepThrough()]
    private void InitializeComponent()
    {
    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'cpPredictFutureWebService'
    // Called by
    //   - User action (Closing the web service)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260424 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260424 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null)
        {
        }
        else
        // (components != null)
        {
          components.Dispose();
        }
        // (components == null)

      }
      else
      // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpPredictFutureWebService()
    //***
    // Action
    //   - Create a new instance of 'cpPredictFutureWebService'
    // Called by
    //   - Main()
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260424 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260424 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // cpPredictFutureWebService()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string[] arrstrPossibleFutures =
      {"The answer is unclear",
       "Uncertain at this time",
       "I have no idea",
       "Absolutely yes!",
       "Ask again later",
       "Emphatically No!",
       "We are certain of it",
       "We are sure of it"};

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [WebMethodAttribute(Description = "Provides an answer")]
    public string GetFuture()
      //***
      // Action
      //   - A random element of arrstrPossibleFutures is returned
      // Called by
      //   - User action (Asking for GetFuture)
      //   - GetAnswer(String) As String
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260424 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260424 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      System.Random rndRandom = new System.Random();
      System.Int32 intLower = arrstrPossibleFutures.GetLowerBound(0);
      System.Int32 intUpper = arrstrPossibleFutures.GetUpperBound(0);

      return arrstrPossibleFutures[rndRandom.Next(intLower, intUpper + 1)];
    }
    // string GetFuture()

    [WebMethodAttribute(Description = "Ask me a question")]
    public string GetAnswer(string question)
    //***
    // Action
    //   - The given question is returned with a random answer
    // Called by
    //   - User action (Asking for GetAnswer)
    // Calls
    //   - string GetFuture()
    // Created
    //   - CopyPaste – 20260424 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260424 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strAnswer;

      strAnswer = question + "?  " + GetFuture();
      return strAnswer;
    }
    // string GetAnswer(string)

    #endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPredictFutureWebService 

}
// CopyPaste.Learning