﻿//***
// Action
//   - Implementation of a cpRedHeadDuck
//     - Inherits from cpDuck
//   - The way a cpRedHeadDuck moves on water is inherited
//     - All cpDuck and child classes moves on water the same way
//   - The sound that a cpRedHeadDuck makes is given thru a delegate and an event
//   - The way a cpRedHeadDuck moves on land is given thru a delegate and an event
//   - The way a cpRedHeadDuck moves in the air is given thru a delegate and an event
//   - The way a cpRedHeadDuck is shown is given thru a delegate and an event (new event are added)
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
// Created
//   - CopyPaste – 20240727 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240727 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Animal.Library;

namespace CopyPaste.Game.Duck.Library
{

	public class cpRedHeadDuck : cpDuck
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpRedHeadDuck
		/// </summary>
		public cpRedHeadDuck() : base()
		//***
		// Action
		//   - Basic constructor
		//   - Define how a cpRedHeadDuck is displayed (Output Window)
		//   - Define how a cpRedHeadDuck flies (with wings)
		//   - Define how a cpRedHeadDuck makes some noise (quacking)
		//   - Define how a cpRedHeadDuck walks (with feet)
		//   - Define how many times this duck quacks (four times)
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - cpDisplayOutputWindow()
		//   - cpDuck()
		//   - cpDuck.HowToDisplay(cpiDisplay) (Set)
		//   - cpDuck.HowToFly(cpiFly) (Set)
		//   - cpDuck.HowToMakeNoise(cpiMakeNoise) (Set)
		//   - cpDuck.HowToWalk(cpiWalk) (Set)
		//   - cpFlyWithWings()
		//   - cpQuack()
		//   - cpWalkWithFeet()
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			HowToDisplay = new cpDisplayOutputWindow();
			HowToFly = new cpFlyWithWings();
			HowToMakeNoise = new cpQuack();
			HowToWalk = new cpWalkWithFeet();
			NumberOfQuacks = 4;
		}
		// cpRedHeadDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// cpRedHeadDuck

}
// CopyPaste.Game.Duck.Library