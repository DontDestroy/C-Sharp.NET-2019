//***
// Action
//   - Show difference between Option Explicit On and Off
//   - Show difference between Option Strict On and Off
// Created
//   - CopyPaste � 20210823 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210823 � VVDW
// Proposal (To Do)
//   -
//***

using System;

// This statements has no alternative in C#
// Declaring a variable is always obligatory and is always strict

//Option Explicit Off
//Option Explicit On 
//Option Strict Off
//Option Strict On

namespace OptionExplicit
{

  class cpOptionExplicit
	{

		static void Main()
    //***
    // Action
    //   - Use an integer variable
    //   - Show message in console screen
    //   - Wait for user to hit enter
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20210823 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210823 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      int intVariable;
      
      intVariable = 100;
      intVariable = intVariable + 50;
      Console.WriteLine("Result: " + intVariable);
      Console.ReadLine();
		}
    // Main()

	}
  // cpOptionExplicit

}
// OptionExplicit