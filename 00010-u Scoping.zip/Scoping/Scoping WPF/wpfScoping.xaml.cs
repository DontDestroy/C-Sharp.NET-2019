﻿//***
// Action
//   - Scoping variables
// Created
//   - CopyPaste – 20220817 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220817 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Scoping_WPF
{

  public partial class wpfScoping : Window
  {

    #region "Constructors / Destructors"

    public wpfScoping()
    //***
    // Action
    //   - Create instance of 'wpfScoping'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220817 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220817 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfScoping()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    static long lngValue = 1;
    // Instance variable can be used anywhere in class
    // long mlngValue = 1:

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void Window_Loaded(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Initialize a local variable (same as module variable)
    //   - Call some subroutines
    //   - Show result in form
    // Called by
    //   - System action (Loading the Window)
    // Calls
    //   - Environment.NewLine
    //   - MethodA()
    //   - MethodB()
    // Created
    //   - CopyPaste – 20220817 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220817 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngValue = 5;
      // Variable local to window_loaded hides instance variable

      lblOutput.Content = "Local variable value in wpfScoping_Loaded is " + lngValue;
      MethodA();
      // MethodA has automatic local value
      MethodB();
      // MethodB uses instance variable value
      MethodA();
      // MethodA creates new automatic local value
      MethodB();
      // Instance variable value retains its value
      lblOutput.Content += Environment.NewLine + Environment.NewLine + "Local variable value in wpfScoping_Loaded is " + lngValue;

    }
    // Window_Loaded(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments) Handles Window.Loaded

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void MethodA()
    //***
    // Action
    //   - Initialize a local variable (automatic local variable value hides instance variable)
    //   - This variable is initialized after each call
    //   - Show result in Window
    // Called by
    //   - Window_Loaded(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments) Handles Window.Loaded
    // Calls
    //   - Environment.NewLine
    // Created
    //   - CopyPaste – 20220207 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220207 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngValue = 25;

      lblOutput.Content += Environment.NewLine + Environment.NewLine + "Local variable value in MethodA is " + lngValue + " after entering MethodA";
      lngValue += 1;
      lblOutput.Content += Environment.NewLine + "Local variable value in MethodA is " + lngValue + " before exiting MethodA";
    }
    // MethodA()

    private void MethodB()
    //***
    // Action
    //  - Initialize a local variable (uses instance variable value)
    //  - This variable is initialized after each call
    //  - Show result in Window
    // Called by
    //   - Window_Loaded(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments) Handles Window.Loaded
    // Calls
    //   - Environment.NewLine
    // Created
    //   - CopyPaste – 20220207 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220207 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      lblOutput.Content += Environment.NewLine + Environment.NewLine + "Instance variable value is " + lngValue + " after entering MethodB";
      lngValue *= 10;
      lblOutput.Content += Environment.NewLine + "Instance variable value is " + lngValue + " before exiting MethodB";
    }
    // MethodB()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfScoping

}
// Scoping_WPF