//***
// Action
//   - Threads that are joined (waiting for each other)
// Created
//   - CopyPaste � 20250709 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250709 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Threading;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static Thread thrLotOfA;
    public static Thread thrLotOfB;
    public static Thread thrLotOfC;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void DisplayLotOfA()
      //***
      // Action
      //   - Wait till Thread B is finished
      //   - Display 251 times "A"
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250709 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250709 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      thrLotOfB.Join();

      for (int lngCounter = 0; lngCounter <= 250; lngCounter++)
      {
        Console.Write("A");
      }
      // lngCounter = 251

    }
    // DisplayLotOfA()

    public static void DisplayLotOfB()
      //***
      // Action
      //   - Display 251 times "B"
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250709 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250709 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      for (int lngCounter = 0; lngCounter <= 250; lngCounter++)
      {
        Console.Write("B");
      }
      // lngCounter = 251

    }
    // DisplayLotOfB()

    public static void DisplayLotOfC()
      //***
      // Action
      //   - Display 251 times "C"
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250709 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250709 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      for (int lngCounter = 0; lngCounter <= 250; lngCounter++)
      {
        Console.Write("C");
      }
      // lngCounter = 251

    }
    // DisplayLotOfC()

    public static void Main()
      //***
      // Action
      //   - Display 251 times "A", "B" and "C" using threading
      //   - Thread A waits for Thread B to finish
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - DisplayLotOfA()
      //   - DisplayLotOfB()
      //   - DisplayLotOfC()
      // Created
      //   - CopyPaste � 20250709 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250709 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      thrLotOfA = new Thread(new ThreadStart(DisplayLotOfA));
      thrLotOfB = new Thread(new ThreadStart(DisplayLotOfB));
      thrLotOfC = new Thread(new ThreadStart(DisplayLotOfC));

      thrLotOfA.Start();
      thrLotOfB.Start();
      thrLotOfC.Start();

      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning