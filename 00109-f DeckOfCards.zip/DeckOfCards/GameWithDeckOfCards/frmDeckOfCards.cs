//***
// Action
//   - A Card game using the library of DeckOfCards
//   - There is a testroutine inside the DeckOfCards.
//   - But later the project has been changed from "Console Application" to "Class Library"
//     - We assume the library works correct (according to modDeckOfCardsTest)
// Created
//   - CopyPaste � 20240128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240128 � VVDW
// Proposal (To Do)
//   - Members used from the library are not documented
//***

using CopyPaste.Learning.Games;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning.Games
{

	public class frmDeckOfCards: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdNewGame;
    internal System.Windows.Forms.Button cmdRemovePairs;
    internal System.Windows.Forms.Panel panPlayer1;
    internal System.Windows.Forms.Label lblPlayer1;
    internal System.Windows.Forms.Label lblPlayer2;
    internal System.Windows.Forms.Panel panPlayer2;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDeckOfCards));
      this.cmdNewGame = new System.Windows.Forms.Button();
      this.cmdRemovePairs = new System.Windows.Forms.Button();
      this.panPlayer1 = new System.Windows.Forms.Panel();
      this.lblPlayer1 = new System.Windows.Forms.Label();
      this.lblPlayer2 = new System.Windows.Forms.Label();
      this.panPlayer2 = new System.Windows.Forms.Panel();
      this.SuspendLayout();
      // 
      // cmdNewGame
      // 
      this.cmdNewGame.Location = new System.Drawing.Point(96, 256);
      this.cmdNewGame.Name = "cmdNewGame";
      this.cmdNewGame.Size = new System.Drawing.Size(96, 23);
      this.cmdNewGame.TabIndex = 9;
      this.cmdNewGame.Text = "New game";
      this.cmdNewGame.Click += new System.EventHandler(this.cmdNewGame_Click);
      // 
      // cmdRemovePairs
      // 
      this.cmdRemovePairs.Location = new System.Drawing.Point(96, 224);
      this.cmdRemovePairs.Name = "cmdRemovePairs";
      this.cmdRemovePairs.Size = new System.Drawing.Size(96, 23);
      this.cmdRemovePairs.TabIndex = 8;
      this.cmdRemovePairs.Text = "Remove pairs";
      this.cmdRemovePairs.Click += new System.EventHandler(this.cmdRemovePairs_Click);
      // 
      // panPlayer1
      // 
      this.panPlayer1.AllowDrop = true;
      this.panPlayer1.AutoScroll = true;
      this.panPlayer1.BackColor = System.Drawing.Color.WhiteSmoke;
      this.panPlayer1.Location = new System.Drawing.Point(16, 32);
      this.panPlayer1.Name = "panPlayer1";
      this.panPlayer1.Size = new System.Drawing.Size(120, 184);
      this.panPlayer1.TabIndex = 7;
      this.panPlayer1.DragEnter += new System.Windows.Forms.DragEventHandler(this.panPlayer1_DragEnter);
      this.panPlayer1.DragDrop += new System.Windows.Forms.DragEventHandler(this.panPlayer1_DragDrop);
      // 
      // lblPlayer1
      // 
      this.lblPlayer1.Location = new System.Drawing.Point(16, 8);
      this.lblPlayer1.Name = "lblPlayer1";
      this.lblPlayer1.TabIndex = 4;
      this.lblPlayer1.Text = "Player 1";
      // 
      // lblPlayer2
      // 
      this.lblPlayer2.Location = new System.Drawing.Point(160, 8);
      this.lblPlayer2.Name = "lblPlayer2";
      this.lblPlayer2.TabIndex = 5;
      this.lblPlayer2.Text = "Player 2";
      // 
      // panPlayer2
      // 
      this.panPlayer2.AllowDrop = true;
      this.panPlayer2.AutoScroll = true;
      this.panPlayer2.BackColor = System.Drawing.Color.WhiteSmoke;
      this.panPlayer2.Location = new System.Drawing.Point(160, 32);
      this.panPlayer2.Name = "panPlayer2";
      this.panPlayer2.Size = new System.Drawing.Size(120, 184);
      this.panPlayer2.TabIndex = 6;
      this.panPlayer2.DragEnter += new System.Windows.Forms.DragEventHandler(this.panPlayer2_DragEnter);
      this.panPlayer2.DragDrop += new System.Windows.Forms.DragEventHandler(this.panPlayer2_DragDrop);
      // 
      // frmDeckOfCards
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 286);
      this.Controls.Add(this.cmdNewGame);
      this.Controls.Add(this.cmdRemovePairs);
      this.Controls.Add(this.panPlayer1);
      this.Controls.Add(this.lblPlayer1);
      this.Controls.Add(this.lblPlayer2);
      this.Controls.Add(this.panPlayer2);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDeckOfCards";
      this.Text = "Deck of Cards";
      this.Load += new System.EventHandler(this.frmDeckOfCards_Load);
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmDeckOfCards'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240128 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240128 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmDeckOfCards()
			//***
			// Action
			//   - Create instance of 'frmDeckOfCards'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240128 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240128 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmDeckOfCards()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

    private Button mcmdPickedUp;
    private cpHand mcpHand1 = new cpHand();
    private cpHand mcpHand2 = new cpHand();
    private SortedList marrIcon = new SortedList();

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"

    private void cmdNewGame_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Setting up the card game for a new game
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - Setup()
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      SetUp();
    }
    // cmdNewGame_Click(System.Object, System.EventArgs) Handles cmdNewGame.Click

    private void cmdRemovePairs_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Removing the pairs for a hand
      //     - According to the pair definition of the library
      //   - Show both hands on the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ShowHand(Panel, cpHand)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mcpHand1.RemovePairs();
      mcpHand2.RemovePairs();
      ShowHand(panPlayer1, mcpHand1);
      ShowHand(panPlayer2, mcpHand2);
    }
    // cmdRemovePairs_Click(System.Object, System.EventArgs) Handles cmdRemovePairs.Click
    
    private void frmDeckOfCards_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Add pictures for the 4 suits to tha marrIcon
      //   - The icons are placed in the same directory where the executable is located
      //   - The game is setup for the first play
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - Setup()
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strPath;

      strPath = Directory.GetCurrentDirectory() + "\\";
      marrIcon.Add(cpSuit.Clubs, Image.FromFile(strPath + "Clubs.ico"));
      marrIcon.Add(cpSuit.Diamonds, Image.FromFile(strPath + "Diamonds.ico"));
      marrIcon.Add(cpSuit.Hearts, Image.FromFile(strPath + "Hearts.ico"));
      marrIcon.Add(cpSuit.Spades, Image.FromFile(strPath + "Spades.ico"));
      SetUp();
    }
    // frmDeckOfCards_Load(System.Object, System.EventArgs) Handles this.Load

    private void panPlayer1_DragDrop(System.Object theSender, System.Windows.Forms.DragEventArgs theDragEventArguments)
      //***
      // Action
      //   - The tag of the button that is dropped contains the card
      //   - The card is put into a variable of type cpCard
      //   - Check if the hand does contain that card
      //   - If so
      //     - Do nothing
      //   - If not
      //     - Add the card to hand of player 1
      //     - Remove the card from hand of player 2
      //   - Show the 2 hands on the screen
      //   - Clear the global variable that was used to move
      // Called by
      //   - User action (Drop into panel of player 1)
      // Calls
      //   - ShowHand(Panel, cpHand)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpCard thecpCard = (cpCard)mcmdPickedUp.Tag;
      
      if (mcpHand1.Contains(thecpCard))
      {
      }
      else
        // Not mcpHand1.Contains(thecpCard)
      {
        mcpHand1.Add(thecpCard);
        mcpHand2.Remove(thecpCard);
      }
      // mcpHand1.Contains(thecpCard)
      
      ShowHand(panPlayer1, mcpHand1);
      ShowHand(panPlayer2, mcpHand2);
      mcmdPickedUp = null;
    }
    // panPlayer1_DragDrop(System.Object, System.Windows.Forms.DragEventArgs) Handles panPlayer1.DragDrop
    
    private void panPlayer1_DragEnter(System.Object theSender, System.Windows.Forms.DragEventArgs theDragEventArguments)
      //***
      // Action
      //   - You dragged into panel 1
      // Called by
      //   - User action (Drag into panel of player 1)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      theDragEventArguments.Effect = DragDropEffects.Move;
    }
    // panPlayer1_DragEnter(System.Object, System.Windows.Forms.DragEventArgs) Handles panPlayer1.DragEnter

    private void panPlayer2_DragDrop(System.Object theSender, System.Windows.Forms.DragEventArgs theDragEventArguments)
      //***
      // Action
      //   - The tag of the button that is dropped contains the card
      //   - The card is put into a variable of type cpCard
      //   - Check if the hand does contain that card
      //   - If so
      //     - Do nothing
      //   - If not
      //     - Add the card to hand of player 2
      //     - Remove the card from hand of player 1
      //   - Show the 2 hands on the screen
      //   - Clear the global variable that was used to move
      // Called by
      //   - User action (Drop into panel of player 2)
      // Calls
      //   - ShowHand(Panel, cpHand)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpCard thecpCard = (cpCard)mcmdPickedUp.Tag;
      
      if (mcpHand2.Contains(thecpCard))
      {
      }
      else
        // Not mcpHand2.Contains(thecpCard)
      {
        mcpHand2.Add(thecpCard);
        mcpHand1.Remove(thecpCard);
      }
      // mcpHand2.Contains(thecpCard)
      
      ShowHand(panPlayer1, mcpHand1);
      ShowHand(panPlayer2, mcpHand2);
      mcmdPickedUp = null;
    }
    // panPlayer2_DragDrop(System.Object, System.Windows.Forms.DragEventArgs) Handles panPlayer2.DragDrop
    
    private void panPlayer2_DragEnter(System.Object theSender, System.Windows.Forms.DragEventArgs theDragEventArguments)
      //***
      // Action
      //   - You dragged into panel 2
      // Called by
      //   - User action (Drag into panel of player 2)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      theDragEventArguments.Effect = DragDropEffects.Move;
    }
    // panPlayer2_DragEnter(System.Object, System.Windows.Forms.DragEventArgs) Handles panPlayer2.DragEnter

    #endregion

		#region "Functionality"

		#region "Event"

    private void CommandMouseDown(System.Object theSender, System.Windows.Forms.MouseEventArgs theMouseEventArguments)
      //***
      // Action
      //   - Set the button that is clicked (theSender) into a global variable
      //   - Start Drag and drop functionality 
      // Called by
      //   - ShowHand(Panel, cpHand)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mcmdPickedUp = (Button)theSender;
      mcmdPickedUp.DoDragDrop(theSender, DragDropEffects.Move);
    }
    // CommandMouseDown(System.Object, System.Windows.Forms.MouseEventArgs)

		#endregion

		#region "Sub / Function"

    [STAThreadAttribute]
		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmDeckOfCards
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmDeckOfCards()
			// Created
			//   - CopyPaste � 20240128 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240128 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmDeckOfCards());
		}
		// Main() 
    
    private void SetUp()
      //***
      // Action
      //   - Setting up the card game for a new game
      //   - Define an array of 2 suits (Diamonds and Hearts)
      //   - Define an array of 5 face values (Ace, King, Queen, Jack, Ten)
      //   - Make the deck (10 cards)
      //   - Shuffle the deck
      //   - Make two hands
      //   - Deal the deck over the two hands
      //   - Show the hand on the screen
      // Called by
      //   - cmdNewGame_Click(System.Object, System.EventArgs) Handles cmdNewGame.Click
      //   - frmDeckOfCards_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - ShowHand(Panel, cpHand)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpSuit[] arrcpSuit = new cpSuit[] {cpSuit.Diamonds, cpSuit.Hearts};
      cpFaceValue[] arrcpFaceValue = new cpFaceValue[] {cpFaceValue.Ace, cpFaceValue.King, cpFaceValue.Queen, cpFaceValue.Jack, cpFaceValue.Ten};
      cpDeck thecpDeck = new cpDeck(arrcpSuit, arrcpFaceValue);

      thecpDeck.Shuffle();
      mcpHand1 = new cpHand();
      mcpHand2 = new cpHand();
      thecpDeck.Deal(new cpHand[] {mcpHand1, mcpHand2});
      ShowHand(panPlayer1, mcpHand1);
      ShowHand(panPlayer2, mcpHand2);
    }
    // SetUp()

    private void ShowHand(Panel thePanel, cpHand thecpHand)
      //***
      // Action
      //   - Clear the panel (make it empty)
      //   - Loop thru the cards of the hand (thecpCard)
      //     - Create a button
      //     - Add it to the panel
      //     - Add an image (the suit of the card)
      //     - Add a text (the face value of the card)
      //     - Text bottom center
      //     - Image top center
      //     - Flat button
      //     - A height of 40
      //     - Calculate the top position of the button
      //     - The tag becomes the card
      //     - Add functionality to the botton (MouseDown)
      // Called by
      //   - cmdRemovePairs_Click(System.Object, System.EventArgs) Handles cmdRemovePairs.Click
      //   - panPlayer1_DragDrop(System.Object, System.Windows.Forms.DragEventArgs) Handles panPlayer1.DragDrop
      //   - panPlayer2_DragDrop(System.Object, System.Windows.Forms.DragEventArgs) Handles panPlayer2.DragDrop
      //   - SetUp()
      // Calls
      //   - CommandMouseDown(System.Object, System.Windows.Forms.MouseEventArgs)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngCounter;
      Button theButton;
      cpCard thecpCard;

      thePanel.Controls.Clear();

      for (lngCounter = 0; lngCounter < thecpHand.Count; lngCounter++)
      {
        thecpCard = thecpHand[lngCounter];
        theButton = new Button();
        // Make the button and add it to the panel
        thePanel.Controls.Add(theButton);
        
        theButton.Image = (Image)marrIcon[thecpCard.Suit];
        theButton.Text = thecpCard.FaceValue.ToString();
        theButton.TextAlign = ContentAlignment.BottomCenter;
        theButton.ImageAlign = ContentAlignment.TopCenter;
        theButton.FlatStyle = FlatStyle.Flat;
        // Modify the appearance of the button
        theButton.Height = 40;
        // Locate the button on the panel
        theButton.Top = 45 * lngCounter;
        // Save the associated card
        theButton.Tag = thecpCard;
        // Add a MouseDown event to the new button
        theButton.MouseDown += new MouseEventHandler(CommandMouseDown);
      }
      // lngCounter = thecpHand.Count 

    }
    // ShowHand(Panel, cpHand)

		#endregion

		#endregion

		#endregion

		//#region "Not used"
    //#endregion

  }
	// frmDeckOfCards

}
// CopyPaste.Learning.Games