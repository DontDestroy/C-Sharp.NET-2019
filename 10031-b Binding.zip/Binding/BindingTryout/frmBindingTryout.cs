//***
// Action
//   - Working with a data set with 3 tables and 2 relations
//   - Having a binding context
// Created
//   - CopyPaste � 20251210 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251210 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBindingTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdComplex;
    internal System.Windows.Forms.Button cmdSimple;
    internal System.Windows.Forms.Button cmdBindings;
    internal System.Windows.Forms.Button cmdReadOnly;
    internal System.Windows.Forms.ListBox lstOrderDate;
    internal System.Windows.Forms.Label lblOrderedOn;
    internal System.Windows.Forms.Label lblProduct;
    internal System.Windows.Forms.ListBox lstProduct;
    internal System.Windows.Forms.TextBox txtPosition;
    internal System.Windows.Forms.Button cmdLast;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Button cmdPrevious;
    internal System.Windows.Forms.Button cmdFirst;
    internal System.Windows.Forms.TextBox txtCategoryDescription;
    internal System.Windows.Forms.TextBox txtCategoryName;
    internal System.Windows.Forms.Label lblName;
    internal System.Windows.Forms.TextBox txtIdCategory;
    internal System.Windows.Forms.Label lblCategoryKey;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBindingTryout));
      this.cmdComplex = new System.Windows.Forms.Button();
      this.cmdSimple = new System.Windows.Forms.Button();
      this.cmdBindings = new System.Windows.Forms.Button();
      this.cmdReadOnly = new System.Windows.Forms.Button();
      this.lstOrderDate = new System.Windows.Forms.ListBox();
      this.lblOrderedOn = new System.Windows.Forms.Label();
      this.lblProduct = new System.Windows.Forms.Label();
      this.lstProduct = new System.Windows.Forms.ListBox();
      this.txtPosition = new System.Windows.Forms.TextBox();
      this.cmdLast = new System.Windows.Forms.Button();
      this.cmdNext = new System.Windows.Forms.Button();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.cmdFirst = new System.Windows.Forms.Button();
      this.txtCategoryDescription = new System.Windows.Forms.TextBox();
      this.txtCategoryName = new System.Windows.Forms.TextBox();
      this.lblName = new System.Windows.Forms.Label();
      this.txtIdCategory = new System.Windows.Forms.TextBox();
      this.lblCategoryKey = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdComplex
      // 
      this.cmdComplex.Location = new System.Drawing.Point(324, 63);
      this.cmdComplex.Name = "cmdComplex";
      this.cmdComplex.Size = new System.Drawing.Size(112, 23);
      this.cmdComplex.TabIndex = 33;
      this.cmdComplex.Text = "Complex";
      this.cmdComplex.Click += new System.EventHandler(this.cmdComplex_Click);
      // 
      // cmdSimple
      // 
      this.cmdSimple.Location = new System.Drawing.Point(324, 31);
      this.cmdSimple.Name = "cmdSimple";
      this.cmdSimple.Size = new System.Drawing.Size(112, 23);
      this.cmdSimple.TabIndex = 32;
      this.cmdSimple.Text = "Simple";
      this.cmdSimple.Click += new System.EventHandler(this.cmdSimple_Click);
      // 
      // cmdBindings
      // 
      this.cmdBindings.Location = new System.Drawing.Point(324, 127);
      this.cmdBindings.Name = "cmdBindings";
      this.cmdBindings.Size = new System.Drawing.Size(112, 23);
      this.cmdBindings.TabIndex = 35;
      this.cmdBindings.Text = "BindingMemberInfo";
      this.cmdBindings.Click += new System.EventHandler(this.cmdBindings_Click);
      // 
      // cmdReadOnly
      // 
      this.cmdReadOnly.Location = new System.Drawing.Point(324, 95);
      this.cmdReadOnly.Name = "cmdReadOnly";
      this.cmdReadOnly.Size = new System.Drawing.Size(112, 23);
      this.cmdReadOnly.TabIndex = 34;
      this.cmdReadOnly.Text = "Read-Only";
      this.cmdReadOnly.Click += new System.EventHandler(this.cmdReadOnly_Click);
      // 
      // lstOrderDate
      // 
      this.lstOrderDate.Location = new System.Drawing.Point(188, 151);
      this.lstOrderDate.Name = "lstOrderDate";
      this.lstOrderDate.Size = new System.Drawing.Size(120, 134);
      this.lstOrderDate.TabIndex = 26;
      // 
      // lblOrderedOn
      // 
      this.lblOrderedOn.AutoSize = true;
      this.lblOrderedOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblOrderedOn.Location = new System.Drawing.Point(188, 135);
      this.lblOrderedOn.Name = "lblOrderedOn";
      this.lblOrderedOn.Size = new System.Drawing.Size(69, 16);
      this.lblOrderedOn.TabIndex = 25;
      this.lblOrderedOn.Text = "Ordered On:";
      // 
      // lblProduct
      // 
      this.lblProduct.AutoSize = true;
      this.lblProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblProduct.Location = new System.Drawing.Point(12, 135);
      this.lblProduct.Name = "lblProduct";
      this.lblProduct.Size = new System.Drawing.Size(54, 16);
      this.lblProduct.TabIndex = 23;
      this.lblProduct.Text = "Products:";
      // 
      // lstProduct
      // 
      this.lstProduct.DisplayMember = "tblCPCategory.ProductCategory.strProductName";
      this.lstProduct.Location = new System.Drawing.Point(12, 151);
      this.lstProduct.Name = "lstProduct";
      this.lstProduct.Size = new System.Drawing.Size(160, 134);
      this.lstProduct.TabIndex = 24;
      this.lstProduct.ValueMember = "tblCPCategory.ProductCategory.lngIdProduct";
      this.lstProduct.SelectedValueChanged += new System.EventHandler(this.lstProduct_SelectedValueChanged);
      // 
      // txtPosition
      // 
      this.txtPosition.Location = new System.Drawing.Point(84, 351);
      this.txtPosition.Name = "txtPosition";
      this.txtPosition.Size = new System.Drawing.Size(280, 20);
      this.txtPosition.TabIndex = 29;
      this.txtPosition.Text = "TextBox1";
      // 
      // cmdLast
      // 
      this.cmdLast.Location = new System.Drawing.Point(412, 351);
      this.cmdLast.Name = "cmdLast";
      this.cmdLast.Size = new System.Drawing.Size(32, 23);
      this.cmdLast.TabIndex = 31;
      this.cmdLast.Text = ">>|";
      this.cmdLast.Click += new System.EventHandler(this.cmdLast_Click);
      // 
      // cmdNext
      // 
      this.cmdNext.Location = new System.Drawing.Point(372, 351);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(32, 23);
      this.cmdNext.TabIndex = 30;
      this.cmdNext.Text = ">";
      this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Location = new System.Drawing.Point(44, 351);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(32, 23);
      this.cmdPrevious.TabIndex = 28;
      this.cmdPrevious.Text = "<";
      this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
      // 
      // cmdFirst
      // 
      this.cmdFirst.Location = new System.Drawing.Point(4, 351);
      this.cmdFirst.Name = "cmdFirst";
      this.cmdFirst.Size = new System.Drawing.Size(32, 23);
      this.cmdFirst.TabIndex = 27;
      this.cmdFirst.Text = "|<<";
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      // 
      // txtCategoryDescription
      // 
      this.txtCategoryDescription.Location = new System.Drawing.Point(12, 55);
      this.txtCategoryDescription.Multiline = true;
      this.txtCategoryDescription.Name = "txtCategoryDescription";
      this.txtCategoryDescription.Size = new System.Drawing.Size(296, 64);
      this.txtCategoryDescription.TabIndex = 22;
      this.txtCategoryDescription.Text = "";
      // 
      // txtCategoryName
      // 
      this.txtCategoryName.Location = new System.Drawing.Point(100, 31);
      this.txtCategoryName.Name = "txtCategoryName";
      this.txtCategoryName.Size = new System.Drawing.Size(208, 20);
      this.txtCategoryName.TabIndex = 21;
      this.txtCategoryName.Text = "";
      // 
      // lblName
      // 
      this.lblName.AutoSize = true;
      this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblName.Location = new System.Drawing.Point(12, 31);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(39, 16);
      this.lblName.TabIndex = 20;
      this.lblName.Text = "Name:";
      // 
      // txtIdCategory
      // 
      this.txtIdCategory.Location = new System.Drawing.Point(100, 7);
      this.txtIdCategory.Name = "txtIdCategory";
      this.txtIdCategory.Size = new System.Drawing.Size(88, 20);
      this.txtIdCategory.TabIndex = 19;
      this.txtIdCategory.Text = "";
      // 
      // lblCategoryKey
      // 
      this.lblCategoryKey.AutoSize = true;
      this.lblCategoryKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblCategoryKey.Location = new System.Drawing.Point(12, 7);
      this.lblCategoryKey.Name = "lblCategoryKey";
      this.lblCategoryKey.Size = new System.Drawing.Size(79, 16);
      this.lblCategoryKey.TabIndex = 18;
      this.lblCategoryKey.Text = "Category Key:";
      // 
      // frmBindingTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(448, 381);
      this.Controls.Add(this.lblOrderedOn);
      this.Controls.Add(this.lblProduct);
      this.Controls.Add(this.txtPosition);
      this.Controls.Add(this.txtCategoryDescription);
      this.Controls.Add(this.txtCategoryName);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.txtIdCategory);
      this.Controls.Add(this.lblCategoryKey);
      this.Controls.Add(this.lstProduct);
      this.Controls.Add(this.cmdLast);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.cmdFirst);
      this.Controls.Add(this.cmdComplex);
      this.Controls.Add(this.cmdSimple);
      this.Controls.Add(this.cmdBindings);
      this.Controls.Add(this.cmdReadOnly);
      this.Controls.Add(this.lstOrderDate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBindingTryout";
      this.Text = "Windows Data Binding Tryout";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBindingTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBindingTryout()
      //***
      // Action
      //   - Create new instance of 'frmBindingTryout'
      //   - Fill the data set with category info
      //   - Fill the data set with product info
      //   - Fill the data set with order info
      //   - Update the display
      //   - Add an event to the position changed of the binding context category
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - InitializeComponent()
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
    }
    // frmBindingTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdBindings_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a binding member info
      //   - Set the first data binding of txdIdCategory to binding member info
      //   - Define a message (What binding member, what path, what field)
      //   - Show the message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdBindings_Click(System.Object, System.EventArgs) Handles cmdBindings.Click

    private void cmdComplex_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the data view order as data source of the list order
      //   - Show the date of the order in the list
      //   - Execute code when listbox item is changed
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdComplex_Click(System.Object, System.EventArgs) Handles cmdComplex.Click

    private void cmdFirst_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the last record of category
      //   - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click

    private void cmdPrevious_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If you are on the first position
      //     - Do nothing
      //   - If not
      //     - Select previous position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click

    private void cmdNext_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If you are on the last position
      //     - Do nothing
      //   - If not
      //     - Select next position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click

    private void cmdLast_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the last record of category
      //   - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click

    private void cmdReadOnly_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a currency manager
      //   - Create a data view
      //   - Set the current manager to the binding context category
      //   - Set the data view to the list of the currency manager
      //   - Define a message (how many rows in what table and how many controls that are bound to it)
      //   - Show the message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdReadOnly_Click(System.Object, System.EventArgs) Handles cmdReadOnly.Click

    private void cmdSimple_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a binding
      //   - Set the binding to the data set, table category, field memDescription
      //   - Add the binding to the textbox of Category Description
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdSimple_Click(System.Object, System.EventArgs) Handles cmdSimple.Click
    
    private void lstProduct_SelectedValueChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a data row view
      //   - Data row view becomes the current item of the list box with products
      //   - If something is selected
      //     - Do nothing
      //   - If not
      //     - Filter the data view of orders with the selected product key
      // Called by
      //   - User action (Selecting an item in a list)
      //   - cmdComplex_Click(System.Object, System.EventArgs) Handles cmdComplex.Click
      //   - Position_Changed(System.Object, System.EventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // lstProduct_SelectedValueChanged(System.Object, System.EventArgs) Handles lstProduct.SelectedValueChanged

    #endregion

    #region "Functionality"

    #region "Event"

    private void frmBinding_PositionChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a message where position info is given
      //   - Show that on the screen
      //   - Execute code when listbox item is changed
      // Called by
      //   - User action (Changing position of a binding context)
      // Calls
      //   - lstProduct_SelectedValueChanged(System.Object, System.EventArgs) Handles lstProduct.SelectedValueChanged
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // Position_Changed(System.Object, System.EventArgs)

    #endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmBindingTryout
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmBindingTryout()
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmBindingTryout());
    }
    // Main() 
    
    private void UpdateDisplay()
      //***
      // Action
      //   - Showing correct information on the current position
      //   - Define a binding context
      //   - Set the binding context to Category
      //   - Set the position text
      // Called by
      //   - cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click
      //   - cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click
      //   - cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click
      //   - cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click
      //   - frmBindingTryout()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251210 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251210 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // UpdateDisplay()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBindingTryout

}
// CopyPaste.Learning