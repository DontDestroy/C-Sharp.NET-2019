//***
// Action
//   - Testroutine for cpSortablePoints
//   - We have a grid of 200 by 200 pixels
//   - Somewhere in that grid we place a center
//   - At random places we put 250 other points
//   - All points are visualised depending on the distance towards the center
//   - The closer to the center, the darker the color is
// Created
//   - CopyPaste � 20240313 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240313 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSortablePoint: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdSetNewCenter;
    internal System.Windows.Forms.TextBox txtNewCenter;
    internal System.Windows.Forms.Button cmdAddPoint;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSortablePoint));
      this.cmdSetNewCenter = new System.Windows.Forms.Button();
      this.txtNewCenter = new System.Windows.Forms.TextBox();
      this.cmdAddPoint = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdSetNewCenter
      // 
      this.cmdSetNewCenter.Location = new System.Drawing.Point(136, 280);
      this.cmdSetNewCenter.Name = "cmdSetNewCenter";
      this.cmdSetNewCenter.Size = new System.Drawing.Size(96, 23);
      this.cmdSetNewCenter.TabIndex = 5;
      this.cmdSetNewCenter.Text = "Set New Center";
      this.cmdSetNewCenter.Click += new System.EventHandler(this.cmdSetNewCenter_Click);
      // 
      // txtNewCenter
      // 
      this.txtNewCenter.Location = new System.Drawing.Point(16, 280);
      this.txtNewCenter.Name = "txtNewCenter";
      this.txtNewCenter.TabIndex = 4;
      this.txtNewCenter.Text = "(0, 0)";
      // 
      // cmdAddPoint
      // 
      this.cmdAddPoint.Location = new System.Drawing.Point(136, 248);
      this.cmdAddPoint.Name = "cmdAddPoint";
      this.cmdAddPoint.Size = new System.Drawing.Size(96, 23);
      this.cmdAddPoint.TabIndex = 3;
      this.cmdAddPoint.Text = "Add Points";
      this.cmdAddPoint.Click += new System.EventHandler(this.cmdAddPoint_Click);
      // 
      // frmSortablePoint
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 310);
      this.Controls.Add(this.cmdSetNewCenter);
      this.Controls.Add(this.txtNewCenter);
      this.Controls.Add(this.cmdAddPoint);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSortablePoint";
      this.Text = "Test clsSortablePoint";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSortablePoint'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240313 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240313 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSortablePoint()
      //***
      // Action
      //   - Create instance of 'frmSortablePoint'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240313 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240313 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSortablePoint()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    
    private void cmdAddPoint_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - An arraylist is created 
      //   - 250 cpSortable points are created and added to the list
      //   - The list is sorted (technically the implementation of CompareTo is used)
      //   - Depending of the position in the array
      //     - The blue color is becoming lighter and lighter
      //   - For every point
      //     - A color is defined in a brush
      //     - The brush is used to draw a little circle (of 10 pixels)
      //     - The brush is destroyed
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpSortablePoint(int, int)
      //   - int cpSortablePoint.X (Get)
      //   - int cpSortablePoint.Y (Get)
      // Created
      //   - CopyPaste � 20240313 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240313 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ArrayList arrPoint = new ArrayList();
      Color theColor;
      cpSortablePoint thecpPoint;
      Graphics theGraph = this.CreateGraphics();
      int lngCounter;
      int lngNumberOfPoints;
      Random rndGenerator = new System.Random();

      lngNumberOfPoints = 250;

      for (lngCounter = 0; lngCounter < lngNumberOfPoints; lngCounter++)
      {
        thecpPoint = new cpSortablePoint(rndGenerator.Next(200), rndGenerator.Next(200));
        arrPoint.Add(thecpPoint);
      }
      // lngCounter = lngNumberOfPoints 

      arrPoint.Sort();

      for (lngCounter = 0; lngCounter < lngNumberOfPoints; lngCounter++)
      {
        thecpPoint = (cpSortablePoint) arrPoint[lngCounter];
        theColor = Color.FromArgb(25, 25, lngCounter);
        
        SolidBrush theBrush = new SolidBrush(theColor);
        
        theGraph.FillEllipse(theBrush, thecpPoint.X, thecpPoint.Y, 10, 10);
        theBrush.Dispose();
      }
      // lngCounter = lngNumberOfPoints 

    }
    // cmdAddPoint_Click(System.Object, System.EventArgs) Handles cmdAddPoint.Click

    
    private void cmdSetNewCenter_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - In the screen there is a textbox with the coordinates of the center
      //   - This text is tried to be parsed toward a cpSortablePoint
      //   - If successful
      //     - The center Is defined
      //   - If Not
      //     - The exception is catched
      //     - An error is shown
      //     - The center is defined on coordinates 0 and 0
      //     - The textbox shows coordinates "(0, 0)"
      //   - Screen is refreshed
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpSortablePoint cpSortablePoint.Center (Get)
      //   - cpSortablePoint cpSortablePoint.cpParse(string)
      //   - cpSortablePoint(int, int)
      //   - cpSortablePoint.Center(cpSortablePoint) (Set)
      //   - string cpSortablePoint.ToString()
      // Created
      //   - CopyPaste � 20240313 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240313 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    
      try
      {
        cpSortablePoint thecpCenter = cpSortablePoint.cpParse(txtNewCenter.Text);
        
        cpSortablePoint.Center = thecpCenter;
      }
      catch (ArgumentException theArgumentException)
      {
        MessageBox.Show(theArgumentException.Message + Environment.NewLine + "Setting center to the origin.");
        cpSortablePoint.Center = new cpSortablePoint(0, 0);
        txtNewCenter.Text = cpSortablePoint.Center.ToString();
      }

      this.Refresh();
    }
    // cmdSetNewCenter_Click(System.Object, System.EventArgs) Handles cmdSetNewCenter_Click(System.Object, System.EventArgs)

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSortablePoint
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240313 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240313 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSortablePoint());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSortablePoint

}
// CopyPaste.Learning