using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using Microsoft.VisualBasic;

namespace CopyPaste.Learning
{

	public class frmReadBooks: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

		internal System.Windows.Forms.Button cmdShowPage;
		internal System.Windows.Forms.Label lblPageToDisplay;
		internal System.Windows.Forms.Label lblPageLength;
		internal System.Windows.Forms.Label lblListOfBooks;
		internal System.Windows.Forms.Label lblTitle;
		internal System.Windows.Forms.RichTextBox txtPage;
		internal System.Windows.Forms.NumericUpDown nudPageToDisplay;
		internal System.Windows.Forms.NumericUpDown nudPageLength;
		internal System.Windows.Forms.ListBox lstBooks;
		private System.ComponentModel.Container components = null;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmReadBooks));
      this.cmdShowPage = new System.Windows.Forms.Button();
      this.lblPageToDisplay = new System.Windows.Forms.Label();
      this.lblPageLength = new System.Windows.Forms.Label();
      this.lblListOfBooks = new System.Windows.Forms.Label();
      this.lblTitle = new System.Windows.Forms.Label();
      this.txtPage = new System.Windows.Forms.RichTextBox();
      this.nudPageToDisplay = new System.Windows.Forms.NumericUpDown();
      this.nudPageLength = new System.Windows.Forms.NumericUpDown();
      this.lstBooks = new System.Windows.Forms.ListBox();
      ((System.ComponentModel.ISupportInitialize)(this.nudPageToDisplay)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudPageLength)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdShowPage
      // 
      this.cmdShowPage.Location = new System.Drawing.Point(16, 215);
      this.cmdShowPage.Name = "cmdShowPage";
      this.cmdShowPage.Size = new System.Drawing.Size(272, 23);
      this.cmdShowPage.TabIndex = 17;
      this.cmdShowPage.Text = "Show page (TestDriver)";
      this.cmdShowPage.Click += new System.EventHandler(this.cmdShowPage_Click);
      // 
      // lblPageToDisplay
      // 
      this.lblPageToDisplay.Location = new System.Drawing.Point(168, 143);
      this.lblPageToDisplay.Name = "lblPageToDisplay";
      this.lblPageToDisplay.Size = new System.Drawing.Size(100, 16);
      this.lblPageToDisplay.TabIndex = 15;
      this.lblPageToDisplay.Text = "Page to display";
      // 
      // lblPageLength
      // 
      this.lblPageLength.Location = new System.Drawing.Point(16, 143);
      this.lblPageLength.Name = "lblPageLength";
      this.lblPageLength.TabIndex = 13;
      this.lblPageLength.Text = "Page length";
      // 
      // lblListOfBooks
      // 
      this.lblListOfBooks.Location = new System.Drawing.Point(16, 7);
      this.lblListOfBooks.Name = "lblListOfBooks";
      this.lblListOfBooks.Size = new System.Drawing.Size(100, 16);
      this.lblListOfBooks.TabIndex = 9;
      this.lblListOfBooks.Text = "List of books";
      // 
      // lblTitle
      // 
      this.lblTitle.Location = new System.Drawing.Point(168, 7);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(100, 16);
      this.lblTitle.TabIndex = 11;
      // 
      // txtPage
      // 
      this.txtPage.Location = new System.Drawing.Point(168, 31);
      this.txtPage.Name = "txtPage";
      this.txtPage.Size = new System.Drawing.Size(120, 96);
      this.txtPage.TabIndex = 12;
      this.txtPage.Text = "";
      // 
      // nudPageToDisplay
      // 
      this.nudPageToDisplay.Location = new System.Drawing.Point(168, 167);
      this.nudPageToDisplay.Minimum = new System.Decimal(new int[] {
                                                                     1,
                                                                     0,
                                                                     0,
                                                                     0});
      this.nudPageToDisplay.Name = "nudPageToDisplay";
      this.nudPageToDisplay.TabIndex = 16;
      this.nudPageToDisplay.Value = new System.Decimal(new int[] {
                                                                   1,
                                                                   0,
                                                                   0,
                                                                   0});
      this.nudPageToDisplay.ValueChanged += new System.EventHandler(this.nudPageToDisplay_ValueChanged);
      // 
      // nudPageLength
      // 
      this.nudPageLength.Location = new System.Drawing.Point(16, 167);
      this.nudPageLength.Minimum = new System.Decimal(new int[] {
                                                                  1,
                                                                  0,
                                                                  0,
                                                                  0});
      this.nudPageLength.Name = "nudPageLength";
      this.nudPageLength.TabIndex = 14;
      this.nudPageLength.Value = new System.Decimal(new int[] {
                                                                1,
                                                                0,
                                                                0,
                                                                0});
      this.nudPageLength.ValueChanged += new System.EventHandler(this.nudPageLength_ValueChanged);
      // 
      // lstBooks
      // 
      this.lstBooks.Location = new System.Drawing.Point(16, 31);
      this.lstBooks.Name = "lstBooks";
      this.lstBooks.Size = new System.Drawing.Size(120, 95);
      this.lstBooks.TabIndex = 10;
      this.lstBooks.SelectedIndexChanged += new System.EventHandler(this.lstBooks_SelectedIndexChanged);
      // 
      // frmReadBooks
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(304, 245);
      this.Controls.Add(this.cmdShowPage);
      this.Controls.Add(this.lblPageToDisplay);
      this.Controls.Add(this.lblPageLength);
      this.Controls.Add(this.lblListOfBooks);
      this.Controls.Add(this.lblTitle);
      this.Controls.Add(this.txtPage);
      this.Controls.Add(this.nudPageToDisplay);
      this.Controls.Add(this.nudPageLength);
      this.Controls.Add(this.lstBooks);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmReadBooks";
      this.Text = "Read Books";
      this.Load += new System.EventHandler(this.frmReadBooks_Load);
      ((System.ComponentModel.ISupportInitialize)(this.nudPageToDisplay)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.nudPageLength)).EndInit();
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmDefault'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � yyyymmdd � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � yyyymmdd � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - List of actions that can be added to the functionality
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmReadBooks()
			//***
			// Action
			//   - Create instance of 'frmDefault'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � yyyymmdd � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � yyyymmdd � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - List of actions that can be added to the functionality
			//***
		{
			InitializeComponent();
		}
		// frmReadBooks()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

    private cpLibrary mcpLibrary;

    #endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"

    private void cmdShowPage_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - This is a test routine to see if the functionality of the class cpBook works
      //   - lngPage becomes 3
      //   - Two cpBooks are defined
      //   - Both books gets a text (variable)
      //   - Both books get a page length (variable)
      //   - Both books gets a title (property)
      //   - Find for both books the lngPage page
      //   - Show the pages
      //   - Show the titles
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpBook()
      //   - cpBook.Title(string) (Set)
      //   - string cpBook.GetPage(int) (Get)
      //   - string cpBook.Title (Get)
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBook thecpCookies = new cpBook();
      cpBook thecpFairyTales;
      int lngPage = 3;
      string strReport = "";

      thecpFairyTales = new cpBook();

      thecpFairyTales.mstrText = "Once upon a time there was a bear.";
      thecpFairyTales.mlngPageLength = 8;
      thecpFairyTales.Title = "Fairy Tales";

      thecpCookies.mstrText = "Chocolate chip cookies are the most delicious cookies.";
      thecpCookies.mlngPageLength = 8;
      thecpCookies.Title = "Cookie Recipes";
      
      strReport = "Page " + lngPage.ToString() + ControlChars.CrLf
        + thecpFairyTales.Title + ": " + thecpFairyTales.GetPage(lngPage) + ControlChars.CrLf
        + "Cookies: " + thecpCookies.GetPage(lngPage);
      MessageBox.Show(strReport);

      strReport = "Titles: " + thecpFairyTales.Title + " and " + thecpCookies.Title;
      MessageBox.Show(strReport);
    }
    // cmdShowPage_Click(System.Object, System.EventArgs) Handles cmdShowPage.Click

    private void frmReadBooks_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Two cpBooks are defined
      //   - A Library is defined
      //   - Both books gets a text (variable)
      //   - Both books get a page length (variable)
      //   - Both books gets a title (property)
      //   - Add both books to the library
      //   - Add both books to the listbox
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpBook()
      //   - cpBook.Title(string) (Set)
      //   - cpLibrary()
      //   - cpLibrary.CheckIn(cpBook)
      //   - string cpBook.Title (Get)
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBook thecpCookies = new cpBook();
      cpBook thecpFairyTales = new cpBook();

      mcpLibrary = new cpLibrary();

      thecpCookies.mstrText = "Chocolate chip cookies are the most delicious cookies.";
      thecpCookies.mlngPageLength = 8;
      thecpCookies.Title = "Cookies";

      thecpFairyTales.mstrText = "Once upon a time there was a bear.";
      thecpFairyTales.mlngPageLength = 8;
      thecpFairyTales.Title = "Fairy Tales";

      mcpLibrary.CheckIn(thecpCookies);
      mcpLibrary.CheckIn(thecpFairyTales);
      
      lstBooks.Items.Add(thecpCookies.Title);
      lstBooks.Items.Add(thecpFairyTales.Title);
    }
    // frmReadBooks_Load(System.Object, System.EventArgs) Handles MyBase.Load

    private void lstBooks_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there is an item selected in the listbox
      //     - Get the title of the selected item
      //     - Get the book out of the library
      //     - Define the pagelength of the book by the value of the numeric up down component
      //     - Define the page of the book by the value of the numeric up down component
      //     - Show the title on the screen
      //     - Show the pagetext on the screen
      //     - Add the book to the library
      //   - If Not
      //     - Do nothing
      // Called by
      //   - nudPageLength_ValueChanged(System.Object, System.EventArgs) Handles nudPageLength.ValueChanged
      //   - nudPageToDisplay_ValueChanged(System.Object, System.EventArgs) Handles nudPageToDisplay.ValueChanged
      //   - User action (Selecting an item in a listbox)
      // Calls
      //   - cpBook cpLibrary.CheckOut(string)
      //   - cpLibrary.CheckIn(cpBook)
      //   - string cpBook.Title (Get)
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
   
      if (lstBooks.SelectedItem == null)
      {
      }
      else
        // lstBooks.SelectedItem <> null
      {
        cpBook thecpBook;
        string strTitle;
        
        strTitle = lstBooks.SelectedItem.ToString();
        thecpBook = mcpLibrary.CheckOut(strTitle);

        thecpBook.mlngPageLength = Convert.ToInt32(nudPageLength.Value);
        lblTitle.Text = thecpBook.Title;
        txtPage.Text = thecpBook.GetPage(Convert.ToInt32(nudPageToDisplay.Value));
        mcpLibrary.CheckIn(thecpBook);
      }
      // lstBooks.SelectedItem = null

    }
    // lstBooks_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBooks.SelectedIndexChanged

    private void nudPageLength_ValueChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Starts an event as if you selected an item in the listbox
      // Called by
      //   - User action (Changing a value of a numeric up down)
      // Calls
      //   - lstBooks_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBooks.SelectedIndexChanged
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      lstBooks_SelectedIndexChanged(this.lstBooks, new EventArgs());
    }
    // nudPageLength_ValueChanged(System.Object, System.EventArgs) Handles nudPageLength.ValueChanged
    
    private void nudPageToDisplay_ValueChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Starts an event as if you selected an item in the listbox
      // Called by
      //   - User action (Changing a value of a numeric up down)
      // Calls
      //   - lstBooks_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstBooks.SelectedIndexChanged
      // Created
      //   - CopyPaste � 20240106 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240106 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      lstBooks_SelectedIndexChanged(this.lstBooks, new EventArgs());
    }
    // nudPageToDisplay_ValueChanged(System.Object, System.EventArgs) Handles nudPageToDisplay.ValueChanged

		#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmDefault
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � yyyymmdd � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � yyyymmdd � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - List of actions that can be added to the functionality
			//***
		{
			Application.Run(new frmReadBooks());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmReadBooks

}
// CopyPaste.Learning