﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CopyPaste.DataAccess.Migrations
{
    public partial class Version02 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Planet",
                table: "PersonDetail",
                type: "nvarchar(130)",
                maxLength: 130,
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Planet",
                table: "PersonDetail");
        }
    }
}
