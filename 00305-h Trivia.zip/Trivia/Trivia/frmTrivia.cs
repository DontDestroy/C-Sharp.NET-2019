//***
// Action
//   - Reading and writing a random access file
//   - Simulating a Trivial Pursuit game
// Created
//   - CopyPaste � 20230809 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230809 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTrivia : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    public System.Windows.Forms.Label lblAnswer4;
    internal System.Windows.Forms.Label lblAnswer3;
    internal System.Windows.Forms.Label lblAnswer2;
    internal System.Windows.Forms.Label lblAnswer1;
    internal System.Windows.Forms.Button cmdAnswer4;
    internal System.Windows.Forms.Button cmdAnswer3;
    internal System.Windows.Forms.Button cmdAnswer2;
    internal System.Windows.Forms.Button cmdAnswer1;
    internal System.Windows.Forms.Label lblQuestion;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTrivia));
      this.lblAnswer4 = new System.Windows.Forms.Label();
      this.lblAnswer3 = new System.Windows.Forms.Label();
      this.lblAnswer2 = new System.Windows.Forms.Label();
      this.lblAnswer1 = new System.Windows.Forms.Label();
      this.cmdAnswer4 = new System.Windows.Forms.Button();
      this.cmdAnswer3 = new System.Windows.Forms.Button();
      this.cmdAnswer2 = new System.Windows.Forms.Button();
      this.cmdAnswer1 = new System.Windows.Forms.Button();
      this.lblQuestion = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // lblAnswer4
      // 
      this.lblAnswer4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblAnswer4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblAnswer4.Location = new System.Drawing.Point(96, 232);
      this.lblAnswer4.Name = "lblAnswer4";
      this.lblAnswer4.Size = new System.Drawing.Size(352, 23);
      this.lblAnswer4.TabIndex = 17;
      // 
      // lblAnswer3
      // 
      this.lblAnswer3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblAnswer3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblAnswer3.Location = new System.Drawing.Point(96, 184);
      this.lblAnswer3.Name = "lblAnswer3";
      this.lblAnswer3.Size = new System.Drawing.Size(352, 23);
      this.lblAnswer3.TabIndex = 15;
      // 
      // lblAnswer2
      // 
      this.lblAnswer2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblAnswer2.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblAnswer2.Location = new System.Drawing.Point(96, 136);
      this.lblAnswer2.Name = "lblAnswer2";
      this.lblAnswer2.Size = new System.Drawing.Size(352, 23);
      this.lblAnswer2.TabIndex = 13;
      // 
      // lblAnswer1
      // 
      this.lblAnswer1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblAnswer1.Font = new System.Drawing.Font("Arial", 10F);
      this.lblAnswer1.Location = new System.Drawing.Point(96, 88);
      this.lblAnswer1.Name = "lblAnswer1";
      this.lblAnswer1.Size = new System.Drawing.Size(352, 23);
      this.lblAnswer1.TabIndex = 11;
      // 
      // cmdAnswer4
      // 
      this.cmdAnswer4.Location = new System.Drawing.Point(8, 232);
      this.cmdAnswer4.Name = "cmdAnswer4";
      this.cmdAnswer4.TabIndex = 16;
      this.cmdAnswer4.Text = "Answer 4";
      this.cmdAnswer4.Click += new System.EventHandler(this.cmdAnswer4_Click);
      // 
      // cmdAnswer3
      // 
      this.cmdAnswer3.Location = new System.Drawing.Point(8, 184);
      this.cmdAnswer3.Name = "cmdAnswer3";
      this.cmdAnswer3.TabIndex = 14;
      this.cmdAnswer3.Text = "Answer 3";
      this.cmdAnswer3.Click += new System.EventHandler(this.cmdAnswer3_Click);
      // 
      // cmdAnswer2
      // 
      this.cmdAnswer2.Location = new System.Drawing.Point(8, 136);
      this.cmdAnswer2.Name = "cmdAnswer2";
      this.cmdAnswer2.TabIndex = 12;
      this.cmdAnswer2.Text = "Answer 2";
      this.cmdAnswer2.Click += new System.EventHandler(this.cmdAnswer2_Click);
      // 
      // cmdAnswer1
      // 
      this.cmdAnswer1.Location = new System.Drawing.Point(8, 88);
      this.cmdAnswer1.Name = "cmdAnswer1";
      this.cmdAnswer1.TabIndex = 10;
      this.cmdAnswer1.Text = "Answer 1";
      this.cmdAnswer1.Click += new System.EventHandler(this.cmdAnswer1_Click);
      // 
      // lblQuestion
      // 
      this.lblQuestion.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblQuestion.Font = new System.Drawing.Font("Arial", 10F);
      this.lblQuestion.Location = new System.Drawing.Point(8, 8);
      this.lblQuestion.Name = "lblQuestion";
      this.lblQuestion.Size = new System.Drawing.Size(440, 48);
      this.lblQuestion.TabIndex = 9;
      // 
      // frmTrivia
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(456, 317);
      this.Controls.Add(this.lblAnswer4);
      this.Controls.Add(this.lblAnswer3);
      this.Controls.Add(this.lblAnswer2);
      this.Controls.Add(this.lblAnswer1);
      this.Controls.Add(this.cmdAnswer4);
      this.Controls.Add(this.cmdAnswer3);
      this.Controls.Add(this.cmdAnswer2);
      this.Controls.Add(this.cmdAnswer1);
      this.Controls.Add(this.lblQuestion);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTrivia";
      this.Text = "Trivia";
      this.Load += new System.EventHandler(this.frmTrivia_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTrivia'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTrivia()
      //***
      // Action
      //   - Create instance of 'frmTrivia'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTrivia()

    #endregion

    //#region "Designer"
    //#endregion

    #region "Structures"

    public struct TriviaData
    {
      [VBFixedStringAttribute(80)]
      public string strQuestion;
      [VBFixedStringAttribute(30)]
      public string strAnswer1;
      [VBFixedStringAttribute(30)]
      public string strAnswer2;
      [VBFixedStringAttribute(30)]
      public string strAnswer3;
      [VBFixedStringAttribute(30)]
      public string strAnswer4;
      public int lngCorrectAnswer;
    }
    // TriviaData

    #endregion

    #region "Fields"

    private static int mlngCurrentRecord;
    private static int mlngFileNumber;
    private static int mlngTotalQuestions;
    private static string mstrFileName;
    private static TriviaData mtheTrivia;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAnswer1_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Check answer 1
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - CheckAnswer(int)
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      CheckAnswer(1);
    }
    // cmdAnswer1_Click(System.Object, System.EventArgs) Handles cmdAnswer1.Click

    private void cmdAnswer2_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Check answer 2
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - CheckAnswer(int)
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      CheckAnswer(2);
    }
    // cmdAnswer2_Click(System.Object, System.EventArgs) Handles cmdAnswer1.Click

    private void cmdAnswer3_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Check answer 3
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - CheckAnswer(int)
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      CheckAnswer(3);
    }
    // cmdAnswer3_Click(System.Object, System.EventArgs) Handles cmdAnswer1.Click

    private void cmdAnswer4_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Check answer 4
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - CheckAnswer(int)
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      CheckAnswer(4);
    }
    // cmdAnswer4_Click(System.Object, System.EventArgs) Handles cmdAnswer1.Click

    private void frmTrivia_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create the database with questions and correspondings answers
      //   - Set a counter to 1
      //   - Get the next question
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - CreateDatabase()
      //   - GetNextQuestion()
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      CreateDatabase();
      mlngCurrentRecord = 1;
      GetNextQuestion();
    }
    // frmTrivia_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void CheckAnswer(int lngAnswer)
      //***
      // Action
      //   - Check the answer on correctness
      //   - If lngCorrectAnswer of mtheTrivia record = lngAnswer
      //     - Show "That's correct!"
      //   - If Not
      //     - Show that is it wrong and the correct answer
      //   - Increment mlngCurrentRecord
      //   - If you have had all the questions
      //     - Show "Game over!"
      //   - If Not
      //     - Go to next question
      // Called by
      //   - cmdAnswer1_Click(System.Object, System.EventArgs) Handles cmdAnswer1.Click
      //   - cmdAnswer2_Click(System.Object, System.EventArgs) Handles cmdAnswer1.Click
      //   - cmdAnswer3_Click(System.Object, System.EventArgs) Handles cmdAnswer1.Click
      //   - cmdAnswer4_Click(System.Object, System.EventArgs) Handles cmdAnswer1.Click
      // Calls
      //   - GetNextQuestion()
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (mtheTrivia.lngCorrectAnswer == lngAnswer)
      {
        MessageBox.Show("That's correct!");
      }
      else
        // mtheTrivia.lngCorrectAnswer <> lngAnswer
      {
        MessageBox.Show("I'm sorry, the correct answer is " + mtheTrivia.lngCorrectAnswer + ".");
      }
      // mtheTrivia.lngCorrectAnswer = lngAnswer

      mlngCurrentRecord += 1;

      if (mlngCurrentRecord <= mlngTotalQuestions)
      {
        GetNextQuestion();
      }
      else
        // mlngCurrentRecord > mlngTotalQuestions
      {
        MessageBox.Show("Game over!");
        Application.Exit();
      }
      // mlngCurrentRecord <= mlngTotalQuestions

    }
    // CheckAnswer(int)

    private void CreateDatabase()
      //***
      // Action
      //   - Create the database
      //   - Find the first free FileNumber (mlngFileNumber)
      //   - Define the File Name
      //   - Open the file in random read write access with a record lenght of mtheTrivia
      //   - Enter first question
      //   - Enter second question
      //   - Enter third question
      //   - Enter fourth question
      //   - Close the file
      // Called by
      //   - frmTrivia_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mlngFileNumber = FileSystem.FreeFile();
      mstrFileName = Directory.GetCurrentDirectory() + "\\Trivia.dat";
      FileSystem.FileOpen(mlngFileNumber, mstrFileName, OpenMode.Random, OpenAccess.ReadWrite, OpenShare.Default, Strings.Len(mtheTrivia));

      mtheTrivia.strQuestion = "Who was the first president of the United States?";
      mtheTrivia.strAnswer1 = "James Madison";
      mtheTrivia.strAnswer2 = "George Washington";
      mtheTrivia.strAnswer3 = "Thomas Edison";
      mtheTrivia.strAnswer4 = "Patrick Henry";
      mtheTrivia.lngCorrectAnswer = 2;
      mlngTotalQuestions = 1;
      FileSystem.FilePut(mlngFileNumber, mtheTrivia, mlngTotalQuestions);

      mtheTrivia.strQuestion = "Who was the first person to fly across the Atlantic Ocean?";
      mtheTrivia.strAnswer1 = "Roscoe Tuner";
      mtheTrivia.strAnswer2 = "Steve Wittman";
      mtheTrivia.strAnswer3 = "Charles Lindbergh";
      mtheTrivia.strAnswer4 = "George Lucas";
      mtheTrivia.lngCorrectAnswer = 3;
      mlngTotalQuestions += 1;
      FileSystem.FilePut(mlngFileNumber, mtheTrivia, mlngTotalQuestions);

      mtheTrivia.strQuestion = "Precisely how many days make up a complete year?";
      mtheTrivia.strAnswer1 = "365.25";
      mtheTrivia.strAnswer2 = "360.00";
      mtheTrivia.strAnswer3 = "364.75";
      mtheTrivia.strAnswer4 = "365.00";
      mtheTrivia.lngCorrectAnswer = 1;
      mlngTotalQuestions += 1;
      FileSystem.FilePut(mlngFileNumber, mtheTrivia, mlngTotalQuestions);

      mtheTrivia.strQuestion = "What is the closest to the speed of light in kilometers per second?";
      mtheTrivia.strAnswer1 = "50.000 km";
      mtheTrivia.strAnswer2 = "186.000 km";
      mtheTrivia.strAnswer3 = "4.890.000 km";
      mtheTrivia.strAnswer4 = "300.000 km";
      mtheTrivia.lngCorrectAnswer = 4;
      mlngTotalQuestions += 1;
      FileSystem.FilePut(mlngFileNumber, mtheTrivia, mlngTotalQuestions);

      FileSystem.FileClose(mlngFileNumber);
    }
    // CreateDatabase()
    
    private void GetNextQuestion()
      //***
      // Action
      //   - Go to next question
      //   - Open the file random read access with the lengt of mtheTrivia record
      //   - Get the record (use of System.ValueType to define what is returned)
      //   - Show the information on the screen
      //   - Close the file
      // Called by
      //   - CheckAnswer(int)
      //   - frmTrivia_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      System.ValueType theResult = mtheTrivia;

      FileSystem.FileOpen(mlngFileNumber, mstrFileName, OpenMode.Random, OpenAccess.ReadWrite, OpenShare.Default, Strings.Len(mtheTrivia));
      FileSystem.FileGet(mlngFileNumber, ref theResult, mlngCurrentRecord);

      mtheTrivia = (TriviaData)theResult;
      lblQuestion.Text = mtheTrivia.strQuestion;
      lblAnswer1.Text = mtheTrivia.strAnswer1;
      lblAnswer2.Text = mtheTrivia.strAnswer2;
      lblAnswer3.Text = mtheTrivia.strAnswer3;
      lblAnswer4.Text = mtheTrivia.strAnswer4;
      FileSystem.FileClose(mlngFileNumber);
    }
    // GetNextQuestion()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTrivia
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTrivia());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmTrivia

}
// CopyPaste.Learning