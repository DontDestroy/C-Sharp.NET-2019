//***
// Action
//   - Use a single Windows form to update multiple lookup tables
//   - Select a table
//   - Show the information of that table in an updateable grid
//   - Update the changes
// Created
//   - CopyPaste � 20251211 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251211 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmUpdateMultipleLookupTable: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdUpdate;
    internal System.Windows.Forms.Label lblData;
    internal System.Windows.Forms.DataGrid dgrData;
    internal System.Windows.Forms.ListBox lstTable;
    internal System.Windows.Forms.Label lblTable;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmUpdateMultipleLookupTable));
      this.cmdUpdate = new System.Windows.Forms.Button();
      this.lblData = new System.Windows.Forms.Label();
      this.dgrData = new System.Windows.Forms.DataGrid();
      this.lstTable = new System.Windows.Forms.ListBox();
      this.lblTable = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.dgrData)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdUpdate
      // 
      this.cmdUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdUpdate.Location = new System.Drawing.Point(520, 6);
      this.cmdUpdate.Name = "cmdUpdate";
      this.cmdUpdate.Size = new System.Drawing.Size(80, 24);
      this.cmdUpdate.TabIndex = 9;
      this.cmdUpdate.Text = "Update";
      this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
      // 
      // lblData
      // 
      this.lblData.Location = new System.Drawing.Point(160, 14);
      this.lblData.Name = "lblData";
      this.lblData.Size = new System.Drawing.Size(144, 16);
      this.lblData.TabIndex = 7;
      this.lblData.Text = "Lookup Table Data";
      // 
      // dgrData
      // 
      this.dgrData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrData.DataMember = "";
      this.dgrData.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrData.Location = new System.Drawing.Point(160, 38);
      this.dgrData.Name = "dgrData";
      this.dgrData.Size = new System.Drawing.Size(448, 208);
      this.dgrData.TabIndex = 8;
      // 
      // lstTable
      // 
      this.lstTable.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left)));
      this.lstTable.IntegralHeight = false;
      this.lstTable.Items.AddRange(new object[] {
                                                  "tblCPCategory",
                                                  "tblCPRegion",
                                                  "tblCPTerritory"});
      this.lstTable.Location = new System.Drawing.Point(8, 38);
      this.lstTable.Name = "lstTable";
      this.lstTable.Size = new System.Drawing.Size(144, 208);
      this.lstTable.TabIndex = 6;
      this.lstTable.SelectedIndexChanged += new System.EventHandler(this.lstTable_SelectedIndexChanged);
      // 
      // lblTable
      // 
      this.lblTable.Location = new System.Drawing.Point(8, 14);
      this.lblTable.Name = "lblTable";
      this.lblTable.Size = new System.Drawing.Size(144, 16);
      this.lblTable.TabIndex = 5;
      this.lblTable.Text = "Lookup Table to Edit";
      // 
      // frmUpdateMultipleLookupTable
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(616, 253);
      this.Controls.Add(this.cmdUpdate);
      this.Controls.Add(this.lblData);
      this.Controls.Add(this.dgrData);
      this.Controls.Add(this.lstTable);
      this.Controls.Add(this.lblTable);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmUpdateMultipleLookupTable";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Use a Single Form for Updating Multiple Lookup Tables Using a Windows Form";
      this.Load += new System.EventHandler(this.frmUpdateMultipleLookupTable_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrData)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmUpdateMultipleLookupTable'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmUpdateMultipleLookupTable()
      //***
      // Action
      //   - Create instance of 'frmUpdateMultipleLookupTable'
      // Called by
      //   - frmMain.cmdUpdateMultipleLookupTable_Click(System.Object, System.EventArgs) Handles cmdUpdateMultipleLookupTable.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmUpdateMultipleLookupTable()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    SqlDataAdapter mdtaLookupData;
    SqlConnection mtheConnection = new SqlConnection();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdUpdate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a command builder (using the data adapter)
      //   - Define a data table
      //   - Try to
      //     - Open the connection
      //     - Set the data table to the data source of the data grid
      //     - Update the data table using the data adapter
      //     - Accept the changes in the data table
      //   - On error
      //     - Show message that you could not update
      //   - Close connection
      // Called by
      //   - User action (Click a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      SqlCommandBuilder cmmBuild = new SqlCommandBuilder(mdtaLookupData);
      DataTable dtFromGrid;

      try
      {
        mtheConnection.Open();
        dtFromGrid = (DataTable)dgrData.DataSource;
        mdtaLookupData.Update(dtFromGrid);
        dtFromGrid.AcceptChanges();
      }
      catch (Exception theException)
      {
        MessageBox.Show("Couldn't update server");
      }
      finally
      {
        mtheConnection.Close();
      }
    
    }
    // cmdUpdate_Click(System.Object, System.EventArgs) Handles cmdUpdate.Click

    private void frmUpdateMultipleLookupTable_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the connection
      //   - Select the first item in the listbox
      // Called by
      //   - User action (Start the form)
      // Calls
      //   - cpGeneralRoutines()
      //   - SqlConnection cpGeneralRoutines.GetConnection()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpGeneralRoutines theConnection = new cpGeneralRoutines();

      mtheConnection = theConnection.GetConnection();
      lstTable.SelectedIndex = 0;
    }
    // frmUpdateMultipleLookupTable_Load(System.Object, System.EventArgs) Handles MyBase.Load

    private void lstTable_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and create a data table
      //   - Try to
      //     - Create a data adapter with a SQL statement (all the fields from selected table) and the connection
      //     - Fill the data table using the data adapter
      //     - The data source of the data grid becomes the data table
      //   - On error
      //     - Show exception message
      // Called by
      //   - User action (Selected an item in a list box)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DataTable dtData = new DataTable();

      try
      {
        mdtaLookupData = new SqlDataAdapter("SELECT * FROM " + lstTable.Text, mtheConnection);

        mdtaLookupData.Fill(dtData);
        dgrData.DataSource = dtData;
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // lstTable_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstTable.SelectedIndexChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmUpdateMultipleLookupTable

}
// CopyPaste.Learning