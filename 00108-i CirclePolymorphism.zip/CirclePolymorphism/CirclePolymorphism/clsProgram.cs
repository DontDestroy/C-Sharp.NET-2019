//***
// Action
//   - Testroutine of an instance of cpCircle
// Created
//   - CopyPaste � 20231231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231231 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Math;
using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace CopyPaste.Learning.Math
{

	public class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main()
			//***
			// Action
			//   - Create a few instances of a cpCircle
			//   - Create a few instances of a cpPoint
			//   - Show information about point1 and circle1
			//   - Point2 becomes circle1
			//   - Show information about point2
			//   - Circle2 becomes point2 (using case)
			//   - Show information about circle2
			//   - If point1 is a circle (it is not the case)
			//     - Circle2 becomes point1 (using cast)
			//     - Show information that cast is succesful
			//   - If not
			//     - Show information that cast is not possible
			//   - If point2 is a circle (it is the case)
			//     - Circle2 becomes point2 (using cast)
			//     - Show information that cast is succesful
			//   - If not
			//     - Show information that cast is not possible
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - cpCircle()
			//   - cpCircle(cpPoint, double)
			//   - cpCircle(Int32, Int32, double)
			//   - cpPoint(int, int)
			//   - double cpCircle.Area()
			//   - string cpCircle.ToString()
			//   - string cpPoint.ToString()
			// Created
			//   - CopyPaste � 20231231 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231231 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			cpCircle thecpCircle1;
			cpCircle thecpCircle2;
			cpPoint thecpPoint1;
			cpPoint thecpPoint2;
			string strOutput;

			thecpPoint1 = new cpPoint(30, 50);
			thecpCircle1 = new cpCircle(120, 89, 2.7);

      strOutput = "cpPoint 1: " + thecpPoint1.ToString() + Environment.NewLine + "cpCircle 1: " + thecpCircle1.ToString();
      MessageBox.Show(strOutput, "Demonstrating the 'is a' relationship");

			// Use is-a relationship to assign cpCircle to cpPoint reference
			thecpPoint2 = thecpCircle1;

      strOutput = "cpCircle 1 (via cpPoint 2): " + thecpPoint2.ToString();
      MessageBox.Show(strOutput, "Demonstrating the 'is a' relationship");

      thecpCircle2 = (cpCircle) thecpPoint2;
      // Allowed only via cast, "thecpCircle2 = thecpPoint2" is not correct
			// Downcast (cast base-class reference to derived-class data type) point2 to circle2
			strOutput = "cpCircle 1 (via cpCircle 2): " + thecpCircle2.ToString();
			MessageBox.Show(strOutput, "Demonstrating the 'is a' relationship");

      strOutput = "Area of cpCircle 1 (via cpCircle 2): " + String.Format("{0:F}", thecpCircle2.Area());
      MessageBox.Show(strOutput, "Demonstrating the 'is a' relationship");

      // Assign cpPoint object to cpCircle reference
			if (thecpPoint1 is cpCircle)
			{
				thecpCircle2 = (cpCircle) thecpPoint1;
				strOutput = "cpPoint 1 does refer to a cpCircle. Cast successful";
				MessageBox.Show(strOutput, "Demonstrating the 'is a' relationship");
			}
      else
        // Not (thecpPoint1 is cpCircle)
			{
        strOutput = "cpPoint 1 does not refer to a cpCircle";
				MessageBox.Show(strOutput, "Demonstrating the 'is a' relationship");
			}
			// thecpPoint1 is cpCircle 

      // Assign cpPoint object to cpCircle reference
			if (thecpPoint2 is cpCircle)
			{
				thecpCircle2 = (cpCircle) thecpPoint2;
				strOutput = "cpPoint 2 does refer to a cpCircle. Cast successful";
				MessageBox.Show(strOutput, "Demonstrating the 'is a' relationship");
			}
			else
				// Not (thecpPoint1 is cpCircle)
			{
				strOutput = "cpPoint 2 does not refer to a cpCircle";
				MessageBox.Show(strOutput, "Demonstrating the 'is a' relationship");
			}
			// (thecpPoint1 Is cpCircle)

		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.Learning.Math