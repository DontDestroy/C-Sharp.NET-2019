//***
// Action
//   - Get the current directory and get the root
// Created
//   - CopyPaste � 20240722 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240722 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Try to
      //     - Get the current directory
      //     - Get the rood of the current directory
      //     - Write the current directory
      //     - Write the root
      //   - On error
      //     - Write a message
      //     - Write the exception message
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240722 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strCurrent;
      string strRoot;

      try
      {
        strCurrent = Directory.GetCurrentDirectory();
        strRoot = Directory.GetDirectoryRoot(strCurrent);

        Console.WriteLine("Current directory {0}", strCurrent);
        Console.WriteLine("Root directory {0}", strRoot);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error determining root directory");
        Console.WriteLine(theException.Message);
      }
      finally
      {
      }

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning