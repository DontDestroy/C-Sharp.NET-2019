//***
// Action
//   - Demo of a datagrid bound control (There is a hierarchy)
// Created
//   - CopyPaste � 20260113 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260113 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDataGridWizard: System.Windows.Forms.Form
  {
    private IContainer components;

    #region Windows Form Designer generated code
    internal System.Windows.Forms.DataGrid dgrProductOrders;
    internal System.Windows.Forms.DataGridTableStyle dgrtblstlProduct;
    internal System.Windows.Forms.DataGridTableStyle dgrtblstlOrder;
    internal System.Windows.Forms.TextBox txtPosition;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Button cmdLast;
    internal System.Windows.Forms.Button cmdPrevious;
    internal System.Windows.Forms.Button cmdFirst;
    internal System.Windows.Forms.TextBox txtDescription;
    internal System.Windows.Forms.TextBox txtCategoryName;
    internal System.Windows.Forms.Label lblName;
    internal System.Windows.Forms.TextBox txtIdCategory;
    private UsingWindowsWizard.dsData dsData;
    private BindingSource bdsrcCategory;
    private UsingWindowsWizard.dsDataTableAdapters.tbaCategory tbaCategory;
    private BindingSource bdsrcProductCategory;
    private UsingWindowsWizard.dsDataTableAdapters.tbaProduct tbaProduct;
    private BindingSource bdscrOrderDateProduct;
    private UsingWindowsWizard.dsDataTableAdapters.tbaOrderDate tbaOrderDate;
    internal System.Windows.Forms.Label lblIdCategory;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataGridWizard));
      this.dgrProductOrders = new System.Windows.Forms.DataGrid();
      this.bdsrcProductCategory = new System.Windows.Forms.BindingSource(this.components);
      this.bdsrcCategory = new System.Windows.Forms.BindingSource(this.components);
      this.dsData = new UsingWindowsWizard.dsData();
      this.dgrtblstlProduct = new System.Windows.Forms.DataGridTableStyle();
      this.dgrtblstlOrder = new System.Windows.Forms.DataGridTableStyle();
      this.txtPosition = new System.Windows.Forms.TextBox();
      this.cmdNext = new System.Windows.Forms.Button();
      this.cmdLast = new System.Windows.Forms.Button();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.cmdFirst = new System.Windows.Forms.Button();
      this.txtDescription = new System.Windows.Forms.TextBox();
      this.txtCategoryName = new System.Windows.Forms.TextBox();
      this.lblName = new System.Windows.Forms.Label();
      this.txtIdCategory = new System.Windows.Forms.TextBox();
      this.lblIdCategory = new System.Windows.Forms.Label();
      this.tbaCategory = new UsingWindowsWizard.dsDataTableAdapters.tbaCategory();
      this.tbaProduct = new UsingWindowsWizard.dsDataTableAdapters.tbaProduct();
      this.bdscrOrderDateProduct = new System.Windows.Forms.BindingSource(this.components);
      this.tbaOrderDate = new UsingWindowsWizard.dsDataTableAdapters.tbaOrderDate();
      ((System.ComponentModel.ISupportInitialize)(this.dgrProductOrders)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcProductCategory)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCategory)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdscrOrderDateProduct)).BeginInit();
      this.SuspendLayout();
      // 
      // dgrProductOrders
      // 
      this.dgrProductOrders.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrProductOrders.DataMember = "";
      this.dgrProductOrders.DataSource = this.bdsrcProductCategory;
      this.dgrProductOrders.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrProductOrders.Location = new System.Drawing.Point(16, 96);
      this.dgrProductOrders.Name = "dgrProductOrders";
      this.dgrProductOrders.Size = new System.Drawing.Size(344, 256);
      this.dgrProductOrders.TabIndex = 16;
      this.dgrProductOrders.TableStyles.AddRange(new System.Windows.Forms.DataGridTableStyle[] {
            this.dgrtblstlProduct,
            this.dgrtblstlOrder});
      // 
      // bdsrcProductCategory
      // 
      this.bdsrcProductCategory.DataMember = "ProductCategory";
      this.bdsrcProductCategory.DataSource = this.bdsrcCategory;
      // 
      // bdsrcCategory
      // 
      this.bdsrcCategory.DataMember = "tblCPCategory";
      this.bdsrcCategory.DataSource = this.dsData;
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // dgrtblstlProduct
      // 
      this.dgrtblstlProduct.DataGrid = this.dgrProductOrders;
      this.dgrtblstlProduct.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrtblstlProduct.MappingName = "ProductCategory";
      // 
      // dgrtblstlOrder
      // 
      this.dgrtblstlOrder.DataGrid = this.dgrProductOrders;
      this.dgrtblstlOrder.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrtblstlOrder.MappingName = "OrderDateProduct";
      // 
      // txtPosition
      // 
      this.txtPosition.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.txtPosition.Location = new System.Drawing.Point(80, 360);
      this.txtPosition.Name = "txtPosition";
      this.txtPosition.Size = new System.Drawing.Size(208, 20);
      this.txtPosition.TabIndex = 19;
      // 
      // cmdNext
      // 
      this.cmdNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdNext.Location = new System.Drawing.Point(296, 360);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(32, 23);
      this.cmdNext.TabIndex = 20;
      this.cmdNext.Text = ">";
      this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
      // 
      // cmdLast
      // 
      this.cmdLast.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdLast.Location = new System.Drawing.Point(328, 360);
      this.cmdLast.Name = "cmdLast";
      this.cmdLast.Size = new System.Drawing.Size(32, 23);
      this.cmdLast.TabIndex = 21;
      this.cmdLast.Text = ">>|";
      this.cmdLast.Click += new System.EventHandler(this.cmdLast_Click);
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdPrevious.Location = new System.Drawing.Point(40, 360);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(32, 23);
      this.cmdPrevious.TabIndex = 18;
      this.cmdPrevious.Text = "<";
      this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
      // 
      // cmdFirst
      // 
      this.cmdFirst.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdFirst.Location = new System.Drawing.Point(8, 360);
      this.cmdFirst.Name = "cmdFirst";
      this.cmdFirst.Size = new System.Drawing.Size(32, 23);
      this.cmdFirst.TabIndex = 17;
      this.cmdFirst.Text = "|<<";
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      // 
      // txtDescription
      // 
      this.txtDescription.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCategory, "memDescription", true));
      this.txtDescription.Location = new System.Drawing.Point(16, 64);
      this.txtDescription.Name = "txtDescription";
      this.txtDescription.Size = new System.Drawing.Size(344, 20);
      this.txtDescription.TabIndex = 15;
      // 
      // txtCategoryName
      // 
      this.txtCategoryName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCategory, "strCategoryName", true));
      this.txtCategoryName.Location = new System.Drawing.Point(104, 35);
      this.txtCategoryName.Name = "txtCategoryName";
      this.txtCategoryName.Size = new System.Drawing.Size(256, 20);
      this.txtCategoryName.TabIndex = 14;
      // 
      // lblName
      // 
      this.lblName.AutoSize = true;
      this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblName.Location = new System.Drawing.Point(16, 40);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(43, 13);
      this.lblName.TabIndex = 13;
      this.lblName.Text = "Name:";
      // 
      // txtIdCategory
      // 
      this.txtIdCategory.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCategory, "intIdCategory", true));
      this.txtIdCategory.Location = new System.Drawing.Point(104, 8);
      this.txtIdCategory.Name = "txtIdCategory";
      this.txtIdCategory.Size = new System.Drawing.Size(256, 20);
      this.txtIdCategory.TabIndex = 12;
      // 
      // lblIdCategory
      // 
      this.lblIdCategory.AutoSize = true;
      this.lblIdCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblIdCategory.Location = new System.Drawing.Point(16, 16);
      this.lblIdCategory.Name = "lblIdCategory";
      this.lblIdCategory.Size = new System.Drawing.Size(86, 13);
      this.lblIdCategory.TabIndex = 11;
      this.lblIdCategory.Text = "Category Key:";
      // 
      // tbaCategory
      // 
      this.tbaCategory.ClearBeforeFill = true;
      // 
      // tbaProduct
      // 
      this.tbaProduct.ClearBeforeFill = true;
      // 
      // bdscrOrderDateProduct
      // 
      this.bdscrOrderDateProduct.DataMember = "OrderDateProduct";
      // 
      // tbaOrderDate
      // 
      this.tbaOrderDate.ClearBeforeFill = true;
      // 
      // frmDataGridWizard
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(368, 389);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.cmdFirst);
      this.Controls.Add(this.txtDescription);
      this.Controls.Add(this.txtCategoryName);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.txtIdCategory);
      this.Controls.Add(this.lblIdCategory);
      this.Controls.Add(this.txtPosition);
      this.Controls.Add(this.dgrProductOrders);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.cmdLast);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataGridWizard";
      this.Text = "Windows Controls Datagrid Wizard";
      ((System.ComponentModel.ISupportInitialize)(this.dgrProductOrders)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcProductCategory)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCategory)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdscrOrderDateProduct)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDataGridWizard'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDataGridWizard()
      //***
      // Action
      //   - Create new instance of 'frmDataGridWizard'
      //   - Fill the data set tblCPCategory with data adapter category
      //   - Fill the data set tblCPProduct with data adapter product
      //   - Fill the data set OrderDate with data adapter orderdate
      //   - Update the display
      // Called by
      //   - frmMasterWizard.cmdDataGrid_Click(System.Object, System.EventArgs) Handles cmdDataGrid.Click
      // Calls
      //   - InitializeComponent()
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
      tbaCategory.Fill(dsData.tblCPCategory);
      tbaProduct.Fill(dsData.tblCPProduct);
      tbaOrderDate.Fill(dsData.OrderDate);
      UpdateDisplay();
    }
    // frmDataGridWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFirst_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the first position
      //   - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcCategory.Position = 0;
      UpdateDisplay();
    }
    // cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click

    private void cmdLast_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the last position
      //   - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcCategory.Position = tbaCategory.GetData().Count - 1;
      UpdateDisplay();
    }
    // cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click

    private void cmdNext_Click(System.Object theSender, System.EventArgs theEventArguments)
      // Action
      //   - If you are at the last position
      //     - Do nothing
      //   - If not
      //     - Go to the next position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcCategory.Position += 1;
      UpdateDisplay();
    }
    // cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click

    private void cmdPrevious_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If you are at the first position
      //     - Do nothing
      //   - If not
      //     - Go to the previous position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcCategory.Position -= 1;
      UpdateDisplay();
    }
    // cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void UpdateDisplay()
      //***
      // Action
      //   - Define a binding manager base
      //   - Assign the binding manager base to the data table Category from the data set
      //   - Show the current position
      // Called by
      //   - cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click
      //   - cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click
      //   - cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click
      //   - cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click
      //   - frmDataGridWizard()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtPosition.Text = "Category " + (bdsrcCategory.Position + 1).ToString() +
        " of " + tbaCategory.GetData().Count.ToString();
    }
    // UpdateDisplay()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataGridWizard

}
// CopyPaste.Learning