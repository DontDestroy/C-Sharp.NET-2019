//***
// Action
//   - Move an object
// Created
//   - CopyPaste � 20240107 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240107 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmMoveIcon: System.Windows.Forms.Form
	{
		#region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdDown;
    internal System.Windows.Forms.Timer tmrMove;
    internal System.Windows.Forms.Button cmdUp;
    internal System.Windows.Forms.PictureBox picSun;
    private System.ComponentModel.IContainer components;


		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMoveIcon));
      this.cmdDown = new System.Windows.Forms.Button();
      this.tmrMove = new System.Windows.Forms.Timer(this.components);
      this.cmdUp = new System.Windows.Forms.Button();
      this.picSun = new System.Windows.Forms.PictureBox();
      this.SuspendLayout();
      // 
      // cmdDown
      // 
      this.cmdDown.Location = new System.Drawing.Point(28, 224);
      this.cmdDown.Name = "cmdDown";
      this.cmdDown.Size = new System.Drawing.Size(88, 24);
      this.cmdDown.TabIndex = 5;
      this.cmdDown.Text = "&Down";
      this.cmdDown.Click += new System.EventHandler(this.cmdDown_Click);
      // 
      // tmrMove
      // 
      this.tmrMove.Interval = 25;
      this.tmrMove.Tick += new System.EventHandler(this.tmrMove_Tick);
      // 
      // cmdUp
      // 
      this.cmdUp.Location = new System.Drawing.Point(28, 184);
      this.cmdUp.Name = "cmdUp";
      this.cmdUp.Size = new System.Drawing.Size(88, 24);
      this.cmdUp.TabIndex = 4;
      this.cmdUp.Text = "&Up";
      this.cmdUp.Click += new System.EventHandler(this.cmdUp_Click);
      // 
      // picSun
      // 
      this.picSun.Image = ((System.Drawing.Image)(resources.GetObject("picSun.Image")));
      this.picSun.Location = new System.Drawing.Point(284, 216);
      this.picSun.Name = "picSun";
      this.picSun.Size = new System.Drawing.Size(40, 32);
      this.picSun.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picSun.TabIndex = 6;
      this.picSun.TabStop = false;
      // 
      // frmMoveIcon
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(352, 269);
      this.Controls.Add(this.cmdUp);
      this.Controls.Add(this.picSun);
      this.Controls.Add(this.cmdDown);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMoveIcon";
      this.Text = "Basic Animation";
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmMoveIcon'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � yyyymmdd � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � yyyymmdd � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - List of actions that can be added to the functionality
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmMoveIcon()
			//***
			// Action
			//   - Create instance of 'frmMoveIcon'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � yyyymmdd � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � yyyymmdd � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - List of actions that can be added to the functionality
			//***
		{
			InitializeComponent();
		}
		// frmMoveIcon()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

    bool mblnGoingUp;
    short mshtMove = 1;

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"

    private void cmdDown_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set 'mblnGoingUp' to false
      //   - Enable 'tmrMove'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240107 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240107 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mblnGoingUp = false;
      tmrMove.Enabled = true;
    }
    // cmdDown_Click(System.Object, System.EventArgs) Handles cmdUp.Click

    private void cmdUp_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set 'mblnGoingUp' to true
      //   - Enable 'tmrMove'
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240107 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240107 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mblnGoingUp = true;
      tmrMove.Enabled = true;
    }
    // cmdUp_Click(System.Object, System.EventArgs) Handles cmdUp.Click
    
    private void tmrMove_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Run code at timer tick
      //   - If 'mblnGoingUp'
      //     - Check if sun is at the top
      //       - If so, do nothing
      //       - If Not, change location of picture (move at higher position to the left)
      //   - If Not
      //     - Check if sun is at the bottom
      //       - If so, do nothing
      //       - If not, change location of picture (move at lower position to the right)
      // Called by
      //   - System action (Timer tick is passed)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240107 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240107 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngMaxTopForSun;
      Point theLocationPoint = new Point();

      lngMaxTopForSun = this.Size.Height - 75;

      if (mblnGoingUp)
      {

        if (picSun.Top > 10)
        {
          theLocationPoint.X = picSun.Location.X - mshtMove;
          theLocationPoint.Y = picSun.Location.Y - mshtMove;
          picSun.Location = theLocationPoint;
        }
        else
          // picSun.Top <= 10
        {
        }
        // picSun.Top > 10
      
      }
      else
        // Not mblnGoingUp
      {

        if (picSun.Top < lngMaxTopForSun)
        {
          theLocationPoint.X = picSun.Location.X + mshtMove;
          theLocationPoint.Y = picSun.Location.Y + mshtMove;
          picSun.Location = theLocationPoint;
        }
        else
          // picSun.Top >= lngMaxTopForSun
        {
        }
        // picSun.Top < lngMaxTopForSun

      }
      // mblnGoingUp

    
    }
    // tmrMove_Tick(System.Object, System.EventArgs) Handles tmrMove.Tick

		#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmMoveIcon
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmMoveIcon()
			// Created
			//   - CopyPaste � 20240107 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240107 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - List of actions that can be added to the functionality
			//***
		{
			Application.Run(new frmMoveIcon());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmMoveIcon

}
// CopyPaste.Learning