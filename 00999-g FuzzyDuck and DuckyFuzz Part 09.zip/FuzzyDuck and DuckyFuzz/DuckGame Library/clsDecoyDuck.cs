﻿//***
// Action
//   - Implementation of a cpDecoyDuck
//     - Inherits from cpDuck
//   - The way a cpDecoyDuck moves on water is inherited
//     - All cpDuck and child classes moves on water the same way
//   - The sound that a cpDecoyDuck makes is given thru a delegate and an event
//   - The way a cpDecoyDuck moves on land is given thru a delegate and an event
//   - The way a cpDecoyDuck moves in the air is given thru a delegate and an event
//   - The way a cpDecoyDuck is shown is given thru a delegate and an event (new event are added)
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
// Created
//   - CopyPaste – 20240727 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240727 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Animal.Library;

namespace CopyPaste.Game.Duck.Library
{

	public class cpDecoyDuck : cpDuck
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpDecoyDuck
		/// </summary>
		public cpDecoyDuck() : base()
		//***
		// Action
		//   - Basic constructor
		//   - Define how a cpDecoyDuck is displayed (Output Window)
		//   - Define how a cpDecoyDuck flies (not)
		//   - Define how a cpDecoyDuck makes some noise (not)
		//   - Define how a cpDecoyDuck walks (not)
		//   - Define how many times this duck quacks (one time)
		// Called by
		//   - CopyPaste.Game.Duck.Test.cpProgram.Main()
		// Calls
		//   - cpDisplayOutputWindow()
		//   - cpDuck()
		//   - cpDuck.HowToDisplay(cpiDisplay) (Set)
		//   - cpDuck.HowToFly(cpiFly) (Set)
		//   - cpDuck.HowToMakeNoise(cpiMakeNoise) (Set)
		//   - cpDuck.HowToWalk(cpiWalk) (Set)
		//   - cpFlyNoWay()
		//   - cpMute()
		//   - cpWalkNoWay()
		//   - NumberOfQuacks(byte) (Set)
		// Created
		//   - CopyPaste – 20240727 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240727 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			HowToDisplay = new cpDisplayOutputWindow();
			HowToFly = new cpFlyNoWay();
			HowToMakeNoise = new cpMute();
			HowToWalk = new cpWalkNoWay();
			NumberOfQuacks = 1;
		}
		// cpDecoyDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// cpDecoyDuck

}
// CopyPaste.Game.Duck.Library