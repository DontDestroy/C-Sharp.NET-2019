﻿//***
// Action
//   - A visualisation of a cpPhone
// Created
//   - CopyPaste – 20230614 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230614 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.TelecomNetwork
{

  partial class frmPhone
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.IContainer components = null;

    private System.Windows.Forms.Label lblMessage;
    private System.Windows.Forms.Label lblPhoneNumber;
    private System.Windows.Forms.RichTextBox txtMessage;
    private System.Windows.Forms.Button cmdCall;
    private System.Windows.Forms.TextBox txtNumber;
    private System.Windows.Forms.Button cmdSend;

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPhone));
      this.lblMessage = new System.Windows.Forms.Label();
      this.lblPhoneNumber = new System.Windows.Forms.Label();
      this.txtMessage = new System.Windows.Forms.RichTextBox();
      this.cmdCall = new System.Windows.Forms.Button();
      this.txtNumber = new System.Windows.Forms.TextBox();
      this.cmdSend = new System.Windows.Forms.Button();
      this.tmrNotify = new System.Windows.Forms.Timer(this.components);
      this.SuspendLayout();
      // 
      // lblMessage
      // 
      this.lblMessage.AutoSize = true;
      this.lblMessage.Location = new System.Drawing.Point(12, 133);
      this.lblMessage.Name = "lblMessage";
      this.lblMessage.Size = new System.Drawing.Size(53, 15);
      this.lblMessage.TabIndex = 11;
      this.lblMessage.Text = "Message";
      // 
      // lblPhoneNumber
      // 
      this.lblPhoneNumber.AutoSize = true;
      this.lblPhoneNumber.Location = new System.Drawing.Point(12, 19);
      this.lblPhoneNumber.Name = "lblPhoneNumber";
      this.lblPhoneNumber.Size = new System.Drawing.Size(134, 15);
      this.lblPhoneNumber.TabIndex = 10;
      this.lblPhoneNumber.Text = "Whom to call or send to";
      // 
      // txtMessage
      // 
      this.txtMessage.Location = new System.Drawing.Point(12, 150);
      this.txtMessage.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.txtMessage.Name = "txtMessage";
      this.txtMessage.Size = new System.Drawing.Size(220, 97);
      this.txtMessage.TabIndex = 9;
      this.txtMessage.Text = "";
      // 
      // cmdCall
      // 
      this.cmdCall.Location = new System.Drawing.Point(97, 72);
      this.cmdCall.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.cmdCall.Name = "cmdCall";
      this.cmdCall.Size = new System.Drawing.Size(135, 38);
      this.cmdCall.TabIndex = 7;
      this.cmdCall.Text = "Call";
      this.cmdCall.UseVisualStyleBackColor = true;
      this.cmdCall.Click += new System.EventHandler(this.cmdCall_Click);
      // 
      // txtNumber
      // 
      this.txtNumber.Location = new System.Drawing.Point(12, 36);
      this.txtNumber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.txtNumber.Name = "txtNumber";
      this.txtNumber.Size = new System.Drawing.Size(220, 23);
      this.txtNumber.TabIndex = 6;
      // 
      // cmdSend
      // 
      this.cmdSend.Location = new System.Drawing.Point(97, 261);
      this.cmdSend.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
      this.cmdSend.Name = "cmdSend";
      this.cmdSend.Size = new System.Drawing.Size(135, 39);
      this.cmdSend.TabIndex = 8;
      this.cmdSend.Text = "Send";
      this.cmdSend.UseVisualStyleBackColor = true;
      this.cmdSend.Click += new System.EventHandler(this.cmdSend_Click);
      // 
      // tmrNotify
      // 
      this.tmrNotify.Interval = 750;
      this.tmrNotify.Tick += new System.EventHandler(this.tmrNotify_Tick);
      // 
      // frmPhone
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
      this.ClientSize = new System.Drawing.Size(244, 311);
      this.Controls.Add(this.lblMessage);
      this.Controls.Add(this.lblPhoneNumber);
      this.Controls.Add(this.txtMessage);
      this.Controls.Add(this.cmdSend);
      this.Controls.Add(this.cmdCall);
      this.Controls.Add(this.txtNumber);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPhone";
      this.Text = "Phone";
      this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmPhone_FormClosing);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmPhone'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230614 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230614 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null)
        {
        }
        else
        // (components != null)
        {
          components.Dispose();
        }
        // (components == null)

      }
      else
      // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }

    private System.Windows.Forms.Timer tmrNotify;
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmPhone

}
// CopyPaste.TelecomNetwork