//***
// Action
//   - The definition of a cpImage
//   - The implementation of the methods is forced in the base class
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   -
//***

using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpImage : cpShape
  {

    #region "Constructors / Destructors"

    public cpImage(System.Windows.Forms.PictureBox thePicture)
      //***
      // Action
      //   - Constructor of a cpImage
      //   - A picturebox is assigned to the field anImage
      // Called by
      //   - frmShape.cmdReal_Click(System.Object, System.EventArgs) Handles cmdFake.Click
      // Calls
      //   - cpShape()
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      anImage = thePicture;
    }
    // cpFakeShape()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    System.Windows.Forms.PictureBox anImage;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override void Draw()
      //***
      // Action
      //   - It makes the picture box visible
      // Called by
      //   - frmShape.cmdReal_Click(System.Object, System.EventArgs) Handles cmdFake.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      anImage.Visible = true;
    }
    // Draw()

    public override void Reflect()
      //***
      // Action
      //   - Mirror a picturebox
      // Called by
      //   - frmShape.cmdReal_Click(System.Object, System.EventArgs) Handles cmdFake.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Image theImage;

      theImage = anImage.Image;

      anImage.Visible = false;
      theImage.RotateFlip(RotateFlipType.RotateNoneFlipXY);
      anImage.Visible = true;
    }
    // Reflect()

    public override void Rotate(System.Single sngDegrees)
      //***
      // Action
      //   - Rotate an image in the picturebox (only by a factor of 90 degrees)
      // Called by
      //   - frmShape.cmdReal_Click(System.Object, System.EventArgs) Handles cmdFake.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Image theImage;
      System.Single sngDegreesSmallerthan360;

      theImage = anImage.Image;
      sngDegreesSmallerthan360 = sngDegrees % 360;

      anImage.Visible = false;

      if (sngDegreesSmallerthan360 < 89)
      {
        theImage.RotateFlip(RotateFlipType.RotateNoneFlipNone);
      }
      else if (sngDegreesSmallerthan360 < 179)
      {
        theImage.RotateFlip(RotateFlipType.Rotate90FlipNone);
      }
      else if (sngDegreesSmallerthan360 < 269)
      {
        theImage.RotateFlip(RotateFlipType.Rotate180FlipNone);
      }
      else if (sngDegreesSmallerthan360 < 359)
      {
        theImage.RotateFlip(RotateFlipType.Rotate270FlipNone);
      }
      else
        // sngDegreesSmallerthan360 >= 89
        // sngDegreesSmallerthan360 >= 179
        // sngDegreesSmallerthan360 >= 269
        // sngDegreesSmallerthan360 >= 359
      {
      }
      // sngDegreesSmallerthan360 < 89
      // sngDegreesSmallerthan360 < 179
      // sngDegreesSmallerthan360 < 269
      // sngDegreesSmallerthan360 < 359

      anImage.Visible = true;
    }
    // Rotate(System.Single)

    public override void Translate(int lngX, int lngY)
      //***
      // Action
      //   - It moves the picture box
      // Called by
      //   - frmShape.cmdReal_Click(System.Object, System.EventArgs) Handles cmdFake.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      anImage.Left = anImage.Left + lngX;
      anImage.Top = anImage.Top + lngY;
    }
    // Translate(int, int)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpShape

}
// CopyPaste.Learning