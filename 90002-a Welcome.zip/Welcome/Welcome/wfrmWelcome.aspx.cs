﻿//***
// Action
//   - Showing a welcome screen
// Created
//   - CopyPaste – 20260413 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260413 – VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmWelcome : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cmdStart.Click += new System.EventHandler(this.cmdStart_Click);
    }

    #endregion

    #region "Constructors / Destructors"
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Initalize the page
    // Called by
    //   - User action (Starting the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20051122 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20051122 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***    
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdStart_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change the label of the form
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20051122 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20051122 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lblMessage.Text = "Welcome, " + txtName.Text;
    }
    // cmdStart_Click(System.Object, System.EventArgs) Handles cmdStart.Click

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Loading the page
    // Called by
    //   - User action (Starting the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20051122 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20051122 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // Page_Load(System.Object, System.EventArgs)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmWelcome

}
// CopyPaste.Learning