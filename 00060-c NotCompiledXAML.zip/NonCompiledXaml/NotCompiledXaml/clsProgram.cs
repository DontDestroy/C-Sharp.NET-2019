//***
// Action
//   - Startup application
// Created
//   - CopyPaste � 20220814 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220814 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows;

namespace NonCompiledXaml
{

  public class cpProgram : Application
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute()]
    static void Main()
    //***
    // Action
    //   - Create a new instance of cpProgram
    //   - Create a new instance of Startup screen
    //   - Show the Startup screen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpStartupScreen()
    // Created
    //   - CopyPaste � 20220814 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220814 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpProgram theProgram = new cpProgram();

      theProgram.MainWindow = new cpStartupScreen();
      theProgram.MainWindow.ShowDialog();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// NonCompiledXaml