﻿//***
// Action
//   - Demo of the simple stack
// Created
//   - CopyPaste – 20220930 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220930 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Simple_Stack
{
  class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Create an instance of the simpel stack
    //   - 
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpSimpleStack()
    //   - cpSimpleStack.Push(Object)
    //   - Object cpSimpleStack.Pop()
    // Created
    //   - CopyPaste – 20220930 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220930 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      cpSimpleStack aSimpleStack = new cpSimpleStack();
      string strResult;

      aSimpleStack.Push("Apple");
      aSimpleStack.Push("Pear");
      aSimpleStack.Push("Orange");

      strResult = (string)aSimpleStack.Pop(); // Downcast to string
      Console.WriteLine(strResult);
      strResult = (string)aSimpleStack.Pop(); // Downcast to string
      Console.WriteLine(strResult);
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram 

}
// Simple_Stack