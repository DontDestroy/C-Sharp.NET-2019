﻿//***
// Action
//   - Implementation of the model cpTask
//   - All the business logic is here
// Created
//   - CopyPaste – 20260427 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260427 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AgileTasks.Models
{
  public class cpTask
  {

    #region "Constructors / Destructors"

    public cpTask()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - ActionResult cpTaskController.Index()
    //   - ActionResult HomeController.Dashboard()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpTask()

    public cpTask(int intTaskNumber, string strTaskTitle, string strTaskBody, DateTime dtmDue)
    //***
    // Action
    //   - Basic constructor with four parameters
    //     - A number
    //     - A title
    //     - A description
    //     - A due date
    // Called by
    //   - List<cpTask> GetTasks()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      TaskID = intTaskNumber;
      TaskTitle = strTaskTitle;
      TaskBody = strTaskBody;
      DueDate = dtmDue;
    }
    // cpTask(int, string, string, DateTime)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public DateTime DueDate { get; set; }
    public string TaskBody { get; set; }
    public int TaskID { get; set; }
    public string TaskTitle { get; set; }

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public List<cpTask> GetTasks()
    //***
    // Action
    //   - Returns a list of cpTask
    //   - This is hardcoded, dummy data
    // Called by
    //   - ActionResult cpTaskController.Index()
    //   - ActionResult HomeController.Dashboard()
    // Calls
    //   - cpTask(int, string, string, DateTime)
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - This is for demo purpose
    //   - Link this to a database
    //***
    {
      List<cpTask> theListOfTasks = new List<cpTask>();

      cpTask firstTask = new cpTask(1, "Review the MVC Tutorials", "Plan some time to view the Pluralsight videos on MVC", DateTime.Now);
      cpTask secondTask = new cpTask(2, "Create a Test Project", "Create a basic test project to demo some stuff", DateTime.Now.AddDays(1));
      cpTask thirdTask = new cpTask(3, "Eat a Pizza", "Remember to make a lunch reservation", DateTime.Now.AddDays(2));
      cpTask fourthTask = new cpTask(4, "Plan your holiday", "Look up some nice locations to visit", DateTime.Now.AddDays(3));

      theListOfTasks.Add(firstTask);
      theListOfTasks.Add(secondTask);
      theListOfTasks.Add(thirdTask);
      theListOfTasks.Add(fourthTask);

      return theListOfTasks;
    }
    // List<cpTask> GetTasks()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpTask

}
// AgileTasks.Models