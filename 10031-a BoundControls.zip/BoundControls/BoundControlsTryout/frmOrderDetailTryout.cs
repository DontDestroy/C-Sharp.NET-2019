//***
// Action
//   - Show the order details of a selected order in frmDataGridDrillDownTryout
// Created
//   - CopyPaste � 20251231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251231 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmOrderDetailTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtOrderID;
    internal System.Windows.Forms.DataGrid dgrOrderDetails;
    internal System.Windows.Forms.DateTimePicker dtpOrderDate;
    internal System.Windows.Forms.Label lblEmployee;
    internal System.Windows.Forms.ComboBox cmbEmployees;
    internal System.Windows.Forms.Label lblOrderDate;
    internal System.Windows.Forms.Label lblOrderId;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOrderDetailTryout));
      this.txtOrderID = new System.Windows.Forms.TextBox();
      this.dgrOrderDetails = new System.Windows.Forms.DataGrid();
      this.dtpOrderDate = new System.Windows.Forms.DateTimePicker();
      this.lblEmployee = new System.Windows.Forms.Label();
      this.cmbEmployees = new System.Windows.Forms.ComboBox();
      this.lblOrderDate = new System.Windows.Forms.Label();
      this.lblOrderId = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrderDetails)).BeginInit();
      this.SuspendLayout();
      // 
      // txtOrderID
      // 
      this.txtOrderID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtOrderID.Location = new System.Drawing.Point(96, 6);
      this.txtOrderID.Name = "txtOrderID";
      this.txtOrderID.Size = new System.Drawing.Size(72, 20);
      this.txtOrderID.TabIndex = 8;
      // 
      // dgrOrderDetails
      // 
      this.dgrOrderDetails.AllowSorting = false;
      this.dgrOrderDetails.DataMember = "";
      this.dgrOrderDetails.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrOrderDetails.Location = new System.Drawing.Point(16, 86);
      this.dgrOrderDetails.Name = "dgrOrderDetails";
      this.dgrOrderDetails.ReadOnly = true;
      this.dgrOrderDetails.Size = new System.Drawing.Size(432, 120);
      this.dgrOrderDetails.TabIndex = 13;
      // 
      // dtpOrderDate
      // 
      this.dtpOrderDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
      this.dtpOrderDate.Location = new System.Drawing.Point(96, 30);
      this.dtpOrderDate.Name = "dtpOrderDate";
      this.dtpOrderDate.Size = new System.Drawing.Size(200, 20);
      this.dtpOrderDate.TabIndex = 10;
      // 
      // lblEmployee
      // 
      this.lblEmployee.Location = new System.Drawing.Point(24, 54);
      this.lblEmployee.Name = "lblEmployee";
      this.lblEmployee.Size = new System.Drawing.Size(56, 16);
      this.lblEmployee.TabIndex = 11;
      this.lblEmployee.Text = "Employee";
      // 
      // cmbEmployees
      // 
      this.cmbEmployees.DisplayMember = "tblCPEmployee.FullName";
      this.cmbEmployees.Location = new System.Drawing.Point(96, 54);
      this.cmbEmployees.Name = "cmbEmployees";
      this.cmbEmployees.Size = new System.Drawing.Size(200, 21);
      this.cmbEmployees.TabIndex = 12;
      this.cmbEmployees.ValueMember = "intIdEmployee";
      // 
      // lblOrderDate
      // 
      this.lblOrderDate.Location = new System.Drawing.Point(24, 30);
      this.lblOrderDate.Name = "lblOrderDate";
      this.lblOrderDate.Size = new System.Drawing.Size(64, 16);
      this.lblOrderDate.TabIndex = 9;
      this.lblOrderDate.Text = "Order Date";
      // 
      // lblOrderId
      // 
      this.lblOrderId.Location = new System.Drawing.Point(24, 6);
      this.lblOrderId.Name = "lblOrderId";
      this.lblOrderId.Size = new System.Drawing.Size(48, 16);
      this.lblOrderId.TabIndex = 7;
      this.lblOrderId.Text = "Order ID";
      // 
      // frmOrderDetailTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(456, 213);
      this.Controls.Add(this.cmbEmployees);
      this.Controls.Add(this.lblOrderDate);
      this.Controls.Add(this.lblOrderId);
      this.Controls.Add(this.txtOrderID);
      this.Controls.Add(this.dgrOrderDetails);
      this.Controls.Add(this.dtpOrderDate);
      this.Controls.Add(this.lblEmployee);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmOrderDetailTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Detail Order Tryout";
      this.Load += new System.EventHandler(this.frmOrderDetailTryout_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrderDetails)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmOrderDetailTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmOrderDetailTryout()
      //***
      // Action
      //   - Create instance of 'frmOrderDetailTryout'
      // Called by
      //   - frmDataGridDrillDownTryout.cmdOrderDetail_Click(System.Object, System.EventArgs) Handles cmdOrderDetail.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmOrderDetailTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmOrderDetailTryout_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a variable to store the order key
      //   - Get the selected order key of the global variable (the current frmDataGridDrillDownTryout)
      //   - Fill the data set of employees with the data adapter
      //   - Get the order key
      //   - Set the title of the screen with order key and customer
      //   - Set the parameter for select command of order info
      //   - Fill the data set of order info using the data adapter
      //   - Set the parameter for select command of order details
      //   - Fill the data set of order details using the data adapter
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmOrderDetailTryout_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmOrderDetailTryout

}
// CopyPaste.Learning