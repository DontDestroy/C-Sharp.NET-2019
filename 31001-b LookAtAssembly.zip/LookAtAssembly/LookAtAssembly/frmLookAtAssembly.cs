//***
// Action
//   - Select an assembly and show the information of it
// Created
//   - CopyPaste � 20240702 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240702 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmLookAtAssembly: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.MenuItem mnuFile;
    internal System.Windows.Forms.MenuItem mnuOpenAssembly;
    internal System.Windows.Forms.MenuItem mnuAssemblyInformation;
    internal System.Windows.Forms.MenuItem mnuHorizontal;
    internal System.Windows.Forms.MenuItem mnuQuit;
    internal System.Windows.Forms.TreeView trvInternal;
    internal System.Windows.Forms.MainMenu mnuMain;
    internal System.Windows.Forms.ListBox lstNamespace;
    internal System.Windows.Forms.OpenFileDialog dlgOpenAssemblies;
    internal System.Windows.Forms.Splitter splVertical;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmLookAtAssembly));
      this.mnuFile = new System.Windows.Forms.MenuItem();
      this.mnuOpenAssembly = new System.Windows.Forms.MenuItem();
      this.mnuAssemblyInformation = new System.Windows.Forms.MenuItem();
      this.mnuHorizontal = new System.Windows.Forms.MenuItem();
      this.mnuQuit = new System.Windows.Forms.MenuItem();
      this.trvInternal = new System.Windows.Forms.TreeView();
      this.mnuMain = new System.Windows.Forms.MainMenu();
      this.lstNamespace = new System.Windows.Forms.ListBox();
      this.dlgOpenAssemblies = new System.Windows.Forms.OpenFileDialog();
      this.splVertical = new System.Windows.Forms.Splitter();
      this.SuspendLayout();
      // 
      // mnuFile
      // 
      this.mnuFile.Index = 0;
      this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuOpenAssembly,
                                                                            this.mnuAssemblyInformation,
                                                                            this.mnuHorizontal,
                                                                            this.mnuQuit});
      this.mnuFile.Text = "&File";
      // 
      // mnuOpenAssembly
      // 
      this.mnuOpenAssembly.Index = 0;
      this.mnuOpenAssembly.Text = "&Open Assembly";
      this.mnuOpenAssembly.Click += new System.EventHandler(this.mnuOpenAssembly_Click);
      // 
      // mnuAssemblyInformation
      // 
      this.mnuAssemblyInformation.Index = 1;
      this.mnuAssemblyInformation.Text = "&Assembly Information";
      this.mnuAssemblyInformation.Click += new System.EventHandler(this.mnuAssemblyInformation_Click);
      // 
      // mnuHorizontal
      // 
      this.mnuHorizontal.Index = 2;
      this.mnuHorizontal.Text = "-";
      // 
      // mnuQuit
      // 
      this.mnuQuit.Index = 3;
      this.mnuQuit.Text = "&Quit";
      this.mnuQuit.Click += new System.EventHandler(this.mnuQuit_Click);
      // 
      // trvInternal
      // 
      this.trvInternal.Dock = System.Windows.Forms.DockStyle.Fill;
      this.trvInternal.ImageIndex = -1;
      this.trvInternal.Location = new System.Drawing.Point(216, 0);
      this.trvInternal.Name = "trvInternal";
      this.trvInternal.SelectedImageIndex = -1;
      this.trvInternal.Size = new System.Drawing.Size(224, 258);
      this.trvInternal.TabIndex = 7;
      // 
      // mnuMain
      // 
      this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFile});
      // 
      // lstNamespace
      // 
      this.lstNamespace.Dock = System.Windows.Forms.DockStyle.Left;
      this.lstNamespace.IntegralHeight = false;
      this.lstNamespace.Location = new System.Drawing.Point(0, 0);
      this.lstNamespace.Name = "lstNamespace";
      this.lstNamespace.Size = new System.Drawing.Size(216, 258);
      this.lstNamespace.Sorted = true;
      this.lstNamespace.TabIndex = 6;
      this.lstNamespace.SelectedIndexChanged += new System.EventHandler(this.lstNamespace_SelectedIndexChanged);
      // 
      // splVertical
      // 
      this.splVertical.Location = new System.Drawing.Point(216, 0);
      this.splVertical.Name = "splVertical";
      this.splVertical.Size = new System.Drawing.Size(3, 258);
      this.splVertical.TabIndex = 8;
      this.splVertical.TabStop = false;
      // 
      // frmLookAtAssembly
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(440, 258);
      this.Controls.Add(this.splVertical);
      this.Controls.Add(this.trvInternal);
      this.Controls.Add(this.lstNamespace);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mnuMain;
      this.Name = "frmLookAtAssembly";
      this.Text = "Look at Assembly";
      this.Load += new System.EventHandler(this.frmLookAtAssembly_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmLookAtAssembly'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmLookAtAssembly()
      //***
      // Action
      //   - Create instance of 'frmLookAtAssembly'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmLookAtAssembly()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    const string mstrProgramName = "Look inside an Assembly";
    string mstrAssemblyLocation = "";
    Assembly mtheAssembly;
    TreeNode mtheRootNode;
    TreeNode mtheTreeNode;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmLookAtAssembly_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the correct title to the form
      //   - Disable the menu item mnuAssemblyInformation
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      this.Text = mstrProgramName;
      mnuAssemblyInformation.Enabled = false;
    }
    // frmLookAtAssembly_Load(System.Object, System.EventArgs) Handles this.Load

    private void lstNamespace_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Start updating a tree view
      //   - Get the type of the selected item as string
      //   - Get the effective type of the string in the assembly
      //   - Create the top node of the tree view
      //   - mtheRootNode becomes that node
      //   - Set the text to "Class: " and the name of the type
      //   - Clear all the nodes of the tree view
      //   - Add the top node
      //   - Select the top node
      //   - Add a category "Static Constructors"
      //   - Get a list of all Static (Shared), Public or NonPublic constructors
      //   - Add info of that list to the tree view
      //   - Add a category "Constructors"
      //   - Get a list of all Instance, Public or NonPublic constructors
      //   - Add info of that list to the tree view
      //   - Add a category "Static (Shared) Fields"
      //   - Get a list of all Static (Shared), Public or NonPublic static (shared) fields
      //   - Add info of that list to the tree view
      //   - Add a category "Fields"
      //   - Get a list of all Instance, Public or NonPublic fields
      //   - Add info of that list to the tree view
      //   - Add a category "Static (Shared) Properties"
      //   - Get a list of all Static (Shared), Public or NonPublic static (shared) properties
      //   - Add info of that list to the tree view
      //   - Add a category "Properties"
      //   - Get a list of all Instance, Public or NonPublic properties
      //   - Add info of that list to the tree view
      //   - Add a category "Static (Shared) Events"
      //   - Get a list of all Static (Shared), Public or NonPublic static (shared) events
      //   - Add info of that list to the tree view
      //   - Add a category "Events"
      //   - Get a list of all Instance, Public or NonPublic events
      //   - Add info of that list to the tree view
      //   - End updating a tree view
      //   - Add a category "Methods"
      //   - Add a subcategory "Static / Shared Methods (Accessed thru class)"
      //   - Add a subcategory "Public / Protected Static Methods"
      //   - Get a list of all Static (Shared) or Public static (shared) methods
      //   - Go one level up
      //   - Add a subcategory "Private Static Methods"
      //   - Get a list of all Static (Shared) or Private static (shared) methods
      //   - Go two levels up
      //   - Add a category "Instance Methods (Not shared : Accessed thru instance of class)"
      //   - Add a subcategory "Public / Protected Instance Methods"
      //   - Get a list of all Instance or Public methods
      //   - Go one level up
      //   - Add a subcategory "Private Instance Methods"
      //   - Get a list of all Instance or Non Public methods
      //   - Go two levels up
      //   - Expand all brances of the tree view
      // Called by
      //   - User action (Selecting an item of a list box
      // Calls
      //   - AddCategory(String)
      //   - AddInfo(MemberInfo())
      //   - AddSubCategory(String)
      //   - GoToParent()
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strType;
      Type theType;

      trvInternal.BeginUpdate();

      try
      {
        strType = (string)lstNamespace.SelectedItem;
        theType = mtheAssembly.GetType(strType);

        if (theType == null)
        {
        }
        else
        // theType <> null
        {

          mtheRootNode = new TreeNode();
          mtheRootNode.Text = "Class: " + theType.Name;

          trvInternal.Nodes.Clear();
          trvInternal.Nodes.Add(mtheRootNode);
          trvInternal.SelectedNode = mtheRootNode;

          AddCategory("Static Constructors");
          ConstructorInfo[] arrStaticConstructorInfo = theType.GetConstructors(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public);
          AddInfo(arrStaticConstructorInfo);

          AddCategory("Constructors");
          ConstructorInfo[] arrConstructorInfo = theType.GetConstructors(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
          AddInfo(arrConstructorInfo);

          AddCategory("Static Fields");
          FieldInfo[] arrFieldInfo = theType.GetFields(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public);
          AddInfo(arrFieldInfo);

          AddCategory("Instance Fields");
          FieldInfo[] arrInstanceFieldInfo = theType.GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
          AddInfo(arrInstanceFieldInfo);

          AddCategory("Static Properties");
          PropertyInfo[] arrPropertyInfo = theType.GetProperties(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public);
          AddInfo(arrPropertyInfo);

          AddCategory("Instance Properties");
          PropertyInfo[] arrInstancePropertyInfo = theType.GetProperties(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
          AddInfo(arrInstancePropertyInfo);

          AddCategory("Static Events");
          EventInfo[] arrEventInfo = theType.GetEvents(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public);
          AddInfo(arrEventInfo);

          AddCategory("Instance Events");
          EventInfo[] arrInstanceEventInfo = theType.GetEvents(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
          AddInfo(arrInstanceEventInfo);

          AddCategory("Methods");
          AddSubCategory("Static / Shared Methods (Accessed thru class)");

          AddSubCategory("Public / Protected Static Methods");
          MethodInfo[] arrStaticPublicMethodInfo = theType.GetMethods(BindingFlags.Static | BindingFlags.Public);
          AddInfo(arrStaticPublicMethodInfo);

          GoToParent();
          AddSubCategory("Private Static Methods");
          MethodInfo[] arrStaticProtectedMethodInfo = theType.GetMethods(BindingFlags.Static | BindingFlags.NonPublic);
          AddInfo(arrStaticProtectedMethodInfo);

          GoToParent();
          GoToParent();

          AddCategory("Instance Methods (Not shared : Accessed thru instance of class)");
          AddSubCategory("Public / Protected Instance Methods");
          MethodInfo[] arrInstancePublicMethodInfo = theType.GetMethods(BindingFlags.Instance | BindingFlags.Public);
          AddInfo(arrInstancePublicMethodInfo);

          GoToParent();
          AddSubCategory("Private Instance Methods");
          MethodInfo[] arrInstanceProtectedMethodInfo = theType.GetMethods(BindingFlags.Instance | BindingFlags.NonPublic);
          AddInfo(arrInstanceProtectedMethodInfo);

          GoToParent();
          GoToParent();
          GoToParent();

          trvInternal.SelectedNode.ExpandAll();
        }
        // theType = null

      }
      catch
      {
      }

      trvInternal.EndUpdate();
    }
    // lstNamespace_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstNamespace.SelectedIndexChanged

    private void mnuAssemblyInformation_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a string builder
      //   - Add "Assembly information"
      //   - Add "Full name: " and the full name
      //   - Add "Location: " and the location
      //   - Show a messagebox with the information
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      StringBuilder strBuildAssemblyInfo = new StringBuilder();

      strBuildAssemblyInfo.Append("Assembly Information" + Environment.NewLine + Environment.NewLine);
      strBuildAssemblyInfo.Append("Full Name: " + mtheAssembly.FullName + Environment.NewLine);
      strBuildAssemblyInfo.Append("Location: " + mtheAssembly.Location + Environment.NewLine);
      MessageBox.Show(strBuildAssemblyInfo.ToString(), mstrProgramName, MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // mnuAssemblyInformation_Click(System.Object, System.EventArgs) Handles mnuAssemblyInformation.Click

    private void mnuOpenAssembly_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show a file open screen
      //     - Go to a specific directory
      //     - Show .dll and .exe files
      //     - Filter by default on .dll
      //     - The current directory will be restored when file open dialog is closed
      //   - If OK button is clicked
      //     - Set the file name to the screen
      //     - Clear all the namespaces
      //     - Clear all the nodes in the treeview
      //     - Load the assembly
      //   - If not
      //     - Nothing happens
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - LoadAssembly(string)
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      dlgOpenAssemblies.InitialDirectory = "C:\\Windows\\Microsoft.NET\\Framework\\";
      dlgOpenAssemblies.Filter = "Assemblies (*.dll *.exe)|*.dll; *.exe";
      dlgOpenAssemblies.FilterIndex = 1;
      dlgOpenAssemblies.RestoreDirectory = true;

      if (dlgOpenAssemblies.ShowDialog() == DialogResult.OK)
      {
        mstrAssemblyLocation = dlgOpenAssemblies.FileName;
        lstNamespace.Items.Clear();
        trvInternal.Nodes.Clear();
        lstNamespace.Items.Add("--- Click one of the items below ---");
        LoadAssembly(mstrAssemblyLocation);
      }
      else
        // dlgOpenAssemblies.ShowDialog() <> DialogResult.OK
      {
      }
      // dlgOpenAssemblies.ShowDialog() = DialogResult.OK 
    
    }
    // mnuOpenAssembly_Click(System.Object, System.EventArgs) Handles mnuOpenAssembly.Click

    private void mnuQuit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop the application
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Exit();
    }
    // mnuQuit_Click(System.Object, System.EventArgs) Handles mnuQuit_Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void AddCategory(string strTitle)
      //***
      // Action
      //   - Create a node
      //   - mtheTreeNode becomes that node
      //   - Set the text to strTitle
      //   - Select the top node
      //   - Add the created node to the selected node
      //   - Select the newly created node
      // Called by
      //   - lstNamespace_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstNamespace.SelectedIndexChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheTreeNode = new TreeNode();
      mtheTreeNode.Text = strTitle;
      trvInternal.SelectedNode = mtheRootNode;
      trvInternal.SelectedNode.Nodes.Add(mtheTreeNode);
      trvInternal.SelectedNode = mtheTreeNode;
    }
    // AddCategory(string)

    private void AddInfo(MemberInfo[] arrMemberInfo)
      //***
      // Action
      //   - An array of member info is given
      //   - For each item in the array
      //     - Create a node
      //     - mtheTreeNode becomes that node
      //     - Set the text to the info of the member
      //     - Add the created node to the selected node
      //     - Select the newly created node
      // Called by
      //   - lstNamespace_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstNamespace.SelectedIndexChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      foreach (MemberInfo theMemberInfo in arrMemberInfo)
      {
        mtheTreeNode = new TreeNode();
        mtheTreeNode.Text = Convert.ToString(theMemberInfo);
        trvInternal.SelectedNode.Nodes.Add(mtheTreeNode);
      }
      // in arrMemberInfo

    }
    // AddInfo(MemberInfo[])

    private void AddSubCategory(string strTitle)
      //***
      // Action
      //   - Create a node
      //   - mtheTreeNode becomes that node
      //   - Set the text to strTitle
      //   - Add the created node to the selected node
      //   - Select the newly created node
      // Called by
      //   - lstNamespace_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstNamespace.SelectedIndexChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheTreeNode = new TreeNode();
      mtheTreeNode.Text = strTitle;
      trvInternal.SelectedNode.Nodes.Add(mtheTreeNode);
      trvInternal.SelectedNode = mtheTreeNode;
    }
    // AddSubCategory(string)

    private void GoToParent()
      //***
      // Action
      //   - mtheTreeNode becomes the selected node
      //   - mtheRootNode becomes the parent of the selected node
      //   - mtheRootNode is the selected node in the tree view
      // Called by
      //   - lstNamespace_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstNamespace.SelectedIndexChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheTreeNode = trvInternal.SelectedNode;
      mtheRootNode = mtheTreeNode.Parent;
      trvInternal.SelectedNode = mtheRootNode;
    }
    // GoToParent()

    private void LoadAssembly(string strAssemblyPath)
      //***
      // Action
      //   - Load an assembly with a given path
      //   - Try to
      //     - Set the path on the screen
      //     - Load the assembly
      //     - Show the public members of the assembly of a given list of types
      //     - Enable the menu item mnuAssemblyInformation
      //   - When it fails
      //     - Disable the menu item mnuAssemblyInformation
      //     - Show a messagebox that the selected file is not an assembly
      //     - Clear the path on the screen
      // Called by
      //   - mnuOpenAssembly_Click(System.Object, System.EventArgs) Handles mnuOpenAssembly.Click
      // Calls
      //   - ShowPublicTypes(Type[])
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        this.Text = "Assembly: " + strAssemblyPath;
        mtheAssembly = Assembly.LoadFrom(strAssemblyPath);
        ShowPublicTypes(mtheAssembly.GetTypes());
        mnuAssemblyInformation.Enabled = true;
      }
      catch
      {
        mnuAssemblyInformation.Enabled = false;
        MessageBox.Show(strAssemblyPath + " is not an assembly of .NET Version 1.1. ", mstrProgramName, MessageBoxButtons.OK, MessageBoxIcon.Information);
        strAssemblyPath = "";
      }

    }
    // LoadAssembly(string)

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmLookAtAssembly
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmLookAtAssembly()
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmLookAtAssembly());
    }
    // Main() 
    
    private void ShowPublicTypes(Type[] arrType)
      //***
      // Action
      //   - Start updating a list box
      //   - Change the cursor into a wait cursor
      //   - Loop thru all the types in the given array of types
      //     - If the type is public
      //       - Add it to the listbox
      //     - If not
      //       - Do nothing
      //   - Change the cursor into the default cursor
      //   - End updating a list box
      // Called by
      //   - LoadAssembly(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      lstNamespace.BeginUpdate();
      Cursor.Current = System.Windows.Forms.Cursors.WaitCursor;

      foreach (Type theType in arrType)
      {

        if (theType.IsPublic)
        {
          lstNamespace.Items.Add(theType.FullName);
        }
        else
          // Not theType.IsPublic 
        {
        }
        // theType.IsPublic 

      }
      // In arrType

      Cursor.Current = System.Windows.Forms.Cursors.Default;
      lstNamespace.EndUpdate();
    }
    // ShowPublicTypes(Type[])

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmLookAtAssembly

}
// CopyPaste.Learning