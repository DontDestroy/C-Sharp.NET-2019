//***
// Action
//   - Demo the static path class
// Created
//   - CopyPaste � 20240723 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240723 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Show the alternate directory separator of a path
      //   - Show the directory separator of a path
      //   - Loop thru the invalid characters in a path
      //     - Show the characters
      //   - Show a new line
      //   - Show the path separator
      //   - Show the volume separator
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240723 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240723 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Alternate Directory Separator {0}", Path.AltDirectorySeparatorChar);
      Console.WriteLine("Directory Separator {0}", Path.DirectorySeparatorChar);
      Console.Write("Invalid Path Characters:");

      foreach (Char theChar in Path.InvalidPathChars)
      {
        Console.Write(" {0}", theChar);
      }
      // in Path.InvalidPathChars

      Console.WriteLine();
      Console.WriteLine("Path Separator {0}", Path.PathSeparator);
      Console.WriteLine("Volume Separator {0}", Path.VolumeSeparatorChar);
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning