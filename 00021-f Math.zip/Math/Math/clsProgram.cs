//***
// Action
//   - Demo of some functions of System.Math
// Created
//   - CopyPaste � 20240412 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240412 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Some methods from System.Math
      //     - Abs, Acos, Ceiling, Cos, Exp, Floor, Log10, Max, Min, Pow, Round, Sqrt
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240412 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240412 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    { 
      Console.WriteLine("Abs(-1) = " + Math.Abs(-1));
      Console.WriteLine("Acos(0) = " + Math.Acos(0.0));
      Console.WriteLine("Acos(pi/4) = " + Math.Acos(Math.PI / 4));
      Console.WriteLine("Ceiling(1.1), Ceiling(0.9) = " + Math.Ceiling(1.1) + " " + Math.Ceiling(0.9));
      Console.WriteLine("Cos(pi) = " + Math.Cos(Math.PI));
      Console.WriteLine("Exp(5) = " + Math.Exp(5));
      Console.WriteLine("Log10(100) = " + Math.Log10(100));
      Console.WriteLine("Max(1001, 100) = " + Math.Max(1001, 100));
      Console.WriteLine("Min(1001, 100) = " + Math.Min(1001, 100));
      Console.WriteLine("Floor(1.1), Floor(0.9) = " + Math.Floor(1.1) + " " + Math.Floor(0.9));
      Console.WriteLine("Round(1.1), Round(0.9) = " + Math.Round(1.1) + " " + Math.Round(0.9));
      Console.WriteLine("Pow(5, 2) = " + Math.Pow(5, 2));
      Console.WriteLine("Sqrt(25) = " + Math.Sqrt(25));
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning