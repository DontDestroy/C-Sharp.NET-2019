﻿//***
// Action
//   - Demo of Conversion with Linq, Element with Linq, Generation with Linq
//   - Keyword AsEnumerable
// Created
//   - CopyPaste – 20230522 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230522 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPasteNorthWind;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace DeferredOperatorLinq
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void AsEnumerableSequence()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Make a connection to the database cpNorthwindScript2019
    //   - Get the collection of customers using fluent expression
    //   - Loop them
    //   - Get the collection of customers using Lambda expression
    //   - Loop them
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230328 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230328 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpNorthWindScript2019 theDatabase;
      IEnumerable<tblCPCustomer> colCustomersToReverse;
      IEnumerable<tblCPCustomer> colCustomersAlternativeToReverse;
      IQueryable<tblCPCustomer> colCustomers;
      IQueryable<tblCPCustomer> colCustomersAlternative;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      theDatabase = new cpNorthWindScript2019(@"Data Source=COPYPASTEPOWER\COPYPASTE;Initial Catalog=cpNorthWindScript2019;Integrated Security=True");
      // Set the datacontext

      colCustomers = from aCPCustomer in theDatabase.tblCPCustomers
                     where aCPCustomer.strCity == "Rio de Janeiro"
                     select aCPCustomer;
      // Query customers using fluent syntax

      colCustomers = colCustomers;
      // colCustomers = colCustomers.Reverse();
      // Reverse the items of the collection
      // This will fail in the loop
      // Reverse functionality is not known in an IQueryable<tblCPCustomer>

      Console.WriteLine("The result using fluent syntax");

      foreach (tblCPCustomer aCPCustomer in colCustomers)
      {
        Console.WriteLine("  {0}", aCPCustomer.strCompanyName);
      }
      // in colCustomers

      colCustomersToReverse = colCustomers.AsEnumerable().Reverse();
      // Reverse the items of the collection

      Console.WriteLine("The result reversed using fluent syntax");

      foreach (tblCPCustomer aCPCustomer in colCustomersToReverse)
      {
        Console.WriteLine("  {0}", aCPCustomer.strCompanyName);
      }
      // in colCustomersToReverse

      colCustomersAlternative = theDatabase.tblCPCustomers.Where<tblCPCustomer>(aCPCustomer => aCPCustomer.strCity == "Paris");
      // Query array using Lambda expression

      colCustomersAlternative = colCustomersAlternative;
      // colCustomersAlternative = colCustomersAlternative.Reverse();
      // Reverse the items of the collection
      // This will fail in the loop
      // Reverse functionality is not known in an IQueryable<tblCPCustomer>

      Console.WriteLine("The result using Lambda syntax (other query, same structure)");

      foreach (tblCPCustomer aCPCustomer in colCustomersAlternative)
      {
        Console.WriteLine("  {0}", aCPCustomer.strCompanyName);
      }
      // in colCustomersAlternative

      colCustomersAlternativeToReverse = colCustomersAlternative.AsEnumerable().Reverse();
      // Reverse the items of the collection

      Console.WriteLine("The result reversed using Lambda syntax (other query, same structure)");

      foreach (tblCPCustomer aCPCustomer in colCustomersAlternativeToReverse)
      {
        Console.WriteLine("  {0}", aCPCustomer.strCompanyName);
      }
      // in colCustomersAlternativeToReverse

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // AsEnumerableSequence()

    public static void Main()
    //***
    // Action
    //   - Study the methods in order
    //   - Try to experiment, your own location to try things out
    //   - AsEnumerable a sequence to a sequence of type IEnumerable<T>
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - TryToExperiment()
    // Created
    //   - CopyPaste – 20230522 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230522 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      TryToExperiment();
      // AsEnumerableSequence();
      Console.ReadLine();
    }
    // Main()

    public static void TryToExperiment()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Method used for experimenting
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230522 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230522 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      //  Do your stuff here

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // TryToExperiment()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion  

  }
  // cpProgram

}
// DeferredOperatorLinq