//***
// Action
//   - Demo of a toolbar
// Created
//   - CopyPaste � 20240516 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240516 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmToolBar: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.ToolBar tlbProgram;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmToolBar));
      this.tlbProgram = new System.Windows.Forms.ToolBar();
      this.SuspendLayout();
      // 
      // tlbProgram
      // 
      this.tlbProgram.DropDownArrows = true;
      this.tlbProgram.Location = new System.Drawing.Point(0, 0);
      this.tlbProgram.Name = "tlbProgram";
      this.tlbProgram.ShowToolTips = true;
      this.tlbProgram.Size = new System.Drawing.Size(288, 42);
      this.tlbProgram.TabIndex = 1;
      this.tlbProgram.ButtonClick += new System.Windows.Forms.ToolBarButtonClickEventHandler(this.tlbProgram_ButtonClick);
      // 
      // frmToolBar
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(288, 189);
      this.Controls.Add(this.tlbProgram);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmToolBar";
      this.Text = "ToolBar";
      this.Load += new System.EventHandler(this.frmToolBar_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmToolBar'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmToolBar()
      //***
      // Action
      //   - Create instance of 'frmToolBar'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmToolBar()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public ToolBarButton mtbbMonday = new ToolBarButton("Monday");
    public ToolBarButton mtbbTuesday = new ToolBarButton("Tuesday");
    public ToolBarButton mtbbWednesday = new ToolBarButton("Wednesday");
    public ToolBarButton mtbbThursday = new ToolBarButton("Thursday");
    public ToolBarButton mtbbFriday = new ToolBarButton("Friday");

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmToolBar_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - 5 buttons are added to the toolbar
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      tlbProgram.Buttons.Add(mtbbMonday);
      tlbProgram.Buttons.Add(mtbbTuesday);
      tlbProgram.Buttons.Add(mtbbWednesday);
      tlbProgram.Buttons.Add(mtbbThursday);
      tlbProgram.Buttons.Add(mtbbFriday);
    }
    // frmToolBar_Load(System.Object, System.EventArgs) Handles this.Load

    private void tlbProgram_ButtonClick(System.Object theSender, System.Windows.Forms.ToolBarButtonClickEventArgs theToolBarButtonClickEventArguments)
      //***
      // Action
      //   - Click event on the toolbar
      //   - The event arguments are used to determine on what button was clicked
      // Called by
      //   - User action (Clicking a button on the toolbar)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ToolBarButton tbbPicked = theToolBarButtonClickEventArguments.Button;

      if (tbbPicked.Equals(mtbbMonday))
      {
        MessageBox.Show("You picked Monday");
      }
      else if (tbbPicked.Equals(mtbbTuesday))
        // Not tbbPicked.Equals(mtbbMonday)
      {
        MessageBox.Show("You picked Tuesday");
      }
      else if (tbbPicked.Equals(mtbbWednesday))
        // tbbPicked.Equals(mtbbTuesday)
      {
        MessageBox.Show("You picked Wednesday");
      }
      else if (tbbPicked.Equals(mtbbThursday))
        // tbbPicked.Equals(mtbbWednesday)
      {
        MessageBox.Show("You picked Thursday");
      }
      else if (tbbPicked.Equals(mtbbFriday))
        // tbbPicked.Equals(mtbbThursday)
      {
        MessageBox.Show("You picked Friday");
      }
      // tbbPicked.Equals(mtbbMonday)
      // tbbPicked.Equals(mtbbTuesday)
      // tbbPicked.Equals(mtbbWednesday)
      // tbbPicked.Equals(mtbbThursday)
      // tbbPicked.Equals(mtbbFriday)
    
    }
    // tlbProgram_ButtonClick(System.Object, System.Windows.Forms.ToolBarButtonClickEventArgs) Handles tlbProgram.ButtonClick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmToolBar
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmToolBar()
      // Created
      //   - CopyPaste � 20240516 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240516 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmToolBar());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmToolBar

}
// CopyPaste.Learning