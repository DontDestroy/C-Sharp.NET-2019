﻿//***
// Action
//   - Having a command towards a database
//   - Defining the command functionality
// Created
//   - CopyPaste – 20210809 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210809 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Data;
using System.Data.SqlClient;

namespace WPFCommand.ViewModel
{
  public class cpCommandViewModel : cpViewModelBase
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    private cpProduct _EntityInput = new cpProduct { ProductKey = -1, ProductName = "A New Product", Introduction = DateTime.Now, Price = 29, Retire = null, Url = "www.CopyPaste.com" };
    private cpProduct _EntitySearch = new cpProduct { ProductName = "WPF%" };
    #endregion

    #region "Properties"

    public cpProduct InputEntity
    {
      get
      //***
      // Action Get
      //   - Returns _EntityInput
      // Called by (Get)
      //   - ctrlProductDetail
      //   - int InsertProductOutputParameters()
      //   - int InsertProductUsingParameters()
      //   - int TransactionProcessing()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20210809 – VVDW
      // Changed
      //   - Organisation – yyyymmdd – Initials of programmer – What changed
      // Tested
      //   - CopyPaste – 20210809 – VVDW
      // Keyboard key
      //   - 
      // Proposal(To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _EntityInput;
      }
      // cpProduct InputEntity() (Get)

      set
      //***
      // Action Set
      //   - _EntityInput becomes cpValue
      //   - RaisePropertyChanged is triggered
      // Called by (Set)
      //   -
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20210809 – VVDW
      // Changed
      //   - Organisation – yyyymmdd – Initials of programmer – What changed
      // Tested
      //   - CopyPaste – 20210809 – VVDW
      // Keyboard key
      //   - 
      // Proposal(To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        _EntityInput = value;
        RaisePropertyChanged("InputEntity");
      }
      // InputEntity(cpProduct) (Set)

    }
    // InputEntity()

    public cpProduct SearchEntity
    {
      get
      //***
      // Action Get
      //   - Returns _EntitySearch
      // Called by (Get)
      //   - int GetProductsCountScalarUsingParameters()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20210809 – VVDW
      // Changed
      //   - Organisation – yyyymmdd – Initials of programmer – What changed
      // Tested
      //   - CopyPaste – 20210809 – VVDW
      // Keyboard key
      //   - 
      // Proposal(To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _EntitySearch;
      }
      // cpProduct SearchEntity() (Get)

      set
      //***
      // Action Set
      //   - _EntitySearch becomes cpValue
      //   - RaisePropertyChanged is triggered
      // Called by (Set)
      //   -
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20210809 – VVDW
      // Changed
      //   - Organisation – yyyymmdd – Initials of programmer – What changed
      // Tested
      //   - CopyPaste – 20210809 – VVDW
      // Keyboard key
      //   - 
      // Proposal(To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        _EntitySearch = value;
        RaisePropertyChanged("SearchEntity");
      }
      // SearchEntity(cpProduct) (Set)

    }
    // SearchEntity()

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int GetProductsCountScalar()
    //***
    // Action
    //   - RowsAffected becomes 0
    //   - Define SQL Statement (strSQL)
    //   - Create SQL Connection object (cnnSQL) based on application settings inside a nested using block
    //   - Create SQL Command object (cmdSQL) inside a nested using block
    //   - Open Connection 
    //   - Execute cmdSQL (RowsAffected)
    //   - Set a result text with result
    //   - Return RowsAffected
    // Called by
    //   - ctrlCommand.cmdScalar_Click(System.Object, System.Windows.RoutedEventArgs)
    // Calls
    //   - cpViewModelBase.ResultText(string) (Set)
    //   - cpViewModelBase.RowsAffected(int) (Set)
    //   - int cpViewModelBase.RowsAffected() (Get)
    //   - string cpApplicationSetting.ConnectionString (Get)
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //    - List of actions that can be added to the functionality
    //***
    {
      RowsAffected = 0;
      string strSQL = "SELECT COUNT(*) FROM tblCPProduct";

      using (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))
      {
        using (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))
        {
          cnnSQL.Open();
          RowsAffected = (int)cmdSQL.ExecuteScalar();
        }
        // (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))

      }
      // (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))
 
      ResultText = "Rows Affected: " + RowsAffected.ToString();
      return RowsAffected;
    }
    // int GetProductsCountScalar()

    public int GetProductsCountScalarUsingParameters()
    //***
    // Action
    //   - RowsAffected becomes 0
    //   - Define SQL Statement (strSQL)
    //   - Create SQL Connection object (cnnSQL) based on application settings inside a nested using block
    //   - Create SQL Command object (cmdSQL) inside a nested using block 
    //   - Add parameter
    //   - Open Connection 
    //   - Execute cmdSQL (RowsAffected)
    //   - Set a result text with result
    //   - Return RowsAffected
    // Called by
    //   - ctrlCommand.cmdScalarParameter_Click(System.Object, System.Windows.RoutedEventArgs)
    // Calls
    //   - cpProduct SearchEntity() (Get)
    //   - cpViewModelBase.ResultText(string) (Set)
    //   - cpViewModelBase.RowsAffected(int) (Set)
    //   - int cpViewModelBase.RowsAffected() (Get)
    //   - string cpApplicationSetting.ConnectionString (Get)
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //    - List of actions that can be added to the functionality
    //    - Possible exercise: Let this work with the textbox on the screen in stead of hardcoded
    //***
    {
      RowsAffected = 0;
      string strSQL = "SELECT COUNT(*) FROM tblCPProduct";
      strSQL += " WHERE strProductName LIKE @ProductName";

      using (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))
      {
        using (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))
        {
          cmdSQL.Parameters.Add(new SqlParameter("@ProductName", SearchEntity.ProductName));
          cnnSQL.Open();
          RowsAffected = (int)cmdSQL.ExecuteScalar();
        }
        // (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))

      }
      // (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))

      ResultText = "Rows Affected: " + RowsAffected.ToString();
      return RowsAffected;
    }
    // int GetProductsCountScalarUsingParameters()

    public int InsertProduct()
    //***
    // Action
    //   - RowsAffected becomes 0
    //   - Define SQL Statement (strSQL)
    //     - Attention: Date is in format YYYY-MM-DD
    //   - Try to
    //     - Create SQL Connection object (cnnSQL) based on application settings inside a nested using block
    //     - Create SQL Command object (cmdSQL) inside a nested using block 
    //     - Set CommandType to Text
    //     - Open Connection 
    //     - Execute cmdSQL (RowsAffected)
    //     - Set a result text with result
    //   - Catch
    //     - Set a result text with error description
    //   - Return RowsAffected
    // Called by
    //   - ctrlCommand.cmdInput_Click(System.Object, System.Windows.RoutedEventArgs)
    // Calls
    //   - cpViewModelBase.ResultText(string) (Set)
    //   - cpViewModelBase.RowsAffected(int) (Set)
    //   - int cpViewModelBase.RowsAffected() (Get)
    //   - string cpApplicationSetting.ConnectionString (Get)
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //    - List of actions that can be added to the functionality
    //    - Date is in format (YYYY-MM-DD)
    //***
    {
      RowsAffected = 0;

      string strSQL = "INSERT INTO tblCPProduct(strProductName, dtmIntroduction, strUrl, decPrice)";
      strSQL += " VALUES('WPF VB.NET Fundamentals', '2019-05-21', 'https://bit.ly/30KKHjs', 19.99)";

      try
      {
        using (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))
        {
          using (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))
          {
            cmdSQL.CommandType = CommandType.Text;
            cnnSQL.Open();
            RowsAffected = cmdSQL.ExecuteNonQuery();
            ResultText = "Rows Affected: " + RowsAffected.ToString();
          }
          // (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))

        }
        // (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))

      }
      catch (System.Exception theException)
      {
        ResultText = theException.ToString();
      }

      return RowsAffected;
    }
    // int InsertProduct()

    public int InsertProductOutputParameters()
    //***
    // Action
    //   - RowsAffected becomes 0
    //   - Define SQL Statement (strSQL)
    //     - Attention: Date should be in format YYYY-MM-DD
    //   - Try to
    //     - Create SQL Connection object (cnnSQL) based on application settings inside a nested using block
    //     - Create SQL Command object (cmdSQL) inside a nested using block 
    //     - Define Input Parameters with their values
    //     - Define Output Parameter
    //     - Set CommandType to StoredProcedure
    //     - Open Connection 
    //     - Execute cmdSQL (RowsAffected)
    //     - Show the output parameter on the screen
    //     - RaisePropertyChanged is triggered
    //     - Set a result text with result
    //   - Catch
    //     - Set a result text with error description
    //   - Return RowsAffected
    // Called by
    //   - ctrlCommand.cmdInsertParameter_Click(System.Object, System.Windows.RoutedEventArgs)
    // Calls
    //   - cpCommon.RaisePropertyChanged(string)
    //   - cpProduct InputEntity() (Get)
    //   - cpViewModelBase.ResultText(string) (Set)
    //   - cpViewModelBase.RowsAffected(int) (Set)
    //   - int cpViewModelBase.RowsAffected() (Get)
    //   - string cpApplicationSetting.ConnectionString (Get)
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //    - List of actions that can be added to the functionality
    //    - Date is in format (YYYY-MM-DD)
    //***
    {
      RowsAffected = 0;
      string strSQL = "tblCPProduct_Insert";

      try
      {
        using (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))
        {
          using (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))
          {
            cmdSQL.Parameters.Add(new SqlParameter("@ProductName", InputEntity.ProductName));
            cmdSQL.Parameters.Add(new SqlParameter("@Introduction", InputEntity.Introduction));
            cmdSQL.Parameters.Add(new SqlParameter("@Url", InputEntity.Url));
            cmdSQL.Parameters.Add(new SqlParameter("@Price", InputEntity.Price));
            cmdSQL.Parameters.Add(new SqlParameter { ParameterName = "@ProductKey", Value = InputEntity.ProductKey, IsNullable = false, DbType = System.Data.DbType.Int32, Direction = ParameterDirection.Output });
            cmdSQL.CommandType = CommandType.StoredProcedure;
            cnnSQL.Open();
            RowsAffected = cmdSQL.ExecuteNonQuery();
            InputEntity.ProductKey = (int)cmdSQL.Parameters["@ProductKey"].Value;
            RaisePropertyChanged("InputEntity");
            ResultText = "Rows Affected: " + RowsAffected.ToString();
          }
          // (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))

        }
        // (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))

      }
      catch (System.Exception theException)
      {
        ResultText = theException.ToString();
      }

      return RowsAffected;
    }
    // int InsertProductOutputParameters()

    public int InsertProductUsingParameters()
    //***
    // Action
    //   - RowsAffected becomes 0
    //   - Define SQL Statement (strSQL)
    //     - Attention: Date should be in format YYYY-MM-DD
    //   - Try to
    //     - Create SQL Connection object (cnnSQL) based on application settings inside a nested using block
    //     - Create SQL Command object (cmdSQL) inside a nested using block 
    //     - Define Parameters with their values
    //     - Set CommandType to Text
    //     - Open Connection 
    //     - Execute cmdSQL (RowsAffected)
    //     - Set a result text with result
    //   - Catch
    //     - Set a result text with error description
    //   - Return RowsAffected
    // Called by
    //   - ctrlCommand.cmdInsertParameter_Click(System.Object, System.Windows.RoutedEventArgs)
    // Calls
    //   - cpProduct InputEntity() (Get)
    //   - cpViewModelBase.ResultText(string) (Set)
    //   - cpViewModelBase.RowsAffected(int) (Set)
    //   - int cpViewModelBase.RowsAffected() (Get)
    //   - string cpApplicationSetting.ConnectionString (Get)
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //    - List of actions that can be added to the functionality
    //    - Date is in format (YYYY-MM-DD)
    //***
    {
      RowsAffected = 0;

      string strSQL = "INSERT INTO tblCPProduct(strProductName, dtmIntroduction, strUrl, decPrice)";
      strSQL += " VALUES(@ProductName, @Introduction, @Url, @Price)";

      try
      {
        using (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))
        {
          using (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))
          {
            cmdSQL.Parameters.Add(new SqlParameter("@ProductName", InputEntity.ProductName));
            cmdSQL.Parameters.Add(new SqlParameter("@Introduction", InputEntity.Introduction));
            cmdSQL.Parameters.Add(new SqlParameter("@Url", InputEntity.Url));
            cmdSQL.Parameters.Add(new SqlParameter("@Price", InputEntity.Price));
            cmdSQL.CommandType = CommandType.Text;
            cnnSQL.Open();
            RowsAffected = cmdSQL.ExecuteNonQuery();
            ResultText = "Rows Affected: " + RowsAffected.ToString();
          }
          // (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))

        }
        // (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))

      }
      catch (System.Exception theException)
      {
        ResultText = theException.ToString();
      }

      return RowsAffected;
    }
    // int InsertProductUsingParameters()

    public int TransactionProcessing()
    //***
    // Action
    //   - RowsAffected becomes 0
    //   - Define SQL Statement (strSQL)
    //     - Attention: Date should be in format YYYY-MM-DD
    //   - Try to
    //     - Create SQL Connection object (cnnSQL) based on application settings inside a nested using block
    //     - Open Connection 
    //     - Create SQL Transaction object (trnSQL) inside a nested using block
    //     - Begin Transaction 
    //     - Try to
    //       - Create SQL Command object (cmdSQL) inside a nesting using block
    //       - Set the transaction of the Command object
    //       - Define Parameters with their values
    //       - Set CommandType to Text
    //       - Execute cmdSQL (RowsAffected)
    //       - Set a result text with result
    //       - Define a second SQL Statement (strSQL)
    //       - Set CommandType to Text
    //       - Clear the parameters
    //       - Define Parameter with value
    //       - Execute cmdSQL (RowsAffected) (will fail due to a wrong fieldname)
    //       - Append the result text with result
    //       - Commit Transaction (here it goes wrong)
    //     - Catch
    //       - Rollback the transaction
    //       - Set a result text with error description
    //   - Catch
    //     - Set a result text with error description
    //   - Return RowsAffected
    // Called by
    //   - ctrlCommand.cmdTransaction_Click(System.Object, System.Windows.RoutedEventArgs)
    // Calls
    //   - cpProduct InputEntity() (Get)
    //   - cpViewModelBase.ResultText(string) (Set)
    //   - cpViewModelBase.RowsAffected(int) (Set)
    //   - int cpViewModelBase.RowsAffected() (Get)
    //   - string cpApplicationSetting.ConnectionString (Get)
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //    - List of actions that can be added to the functionality
    //    - Date is in format (YYYY-MM-DD)
    //***
    {
      RowsAffected = 0;

      string strSQL = "INSERT INTO tblCPProduct(strProductName, dtmIntroduction, strUrl, decPrice)";
      strSQL += " VALUES(@ProductName, @Introduction, @Url, @Price)";

      try
      {
        using (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))
        {
          cnnSQL.Open();

          using (SqlTransaction trnSQL = cnnSQL.BeginTransaction())
          {
            try
            {
              using (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))
              {
                cmdSQL.Transaction = trnSQL;
                cmdSQL.Parameters.Add(new SqlParameter("@ProductName", InputEntity.ProductName));
                cmdSQL.Parameters.Add(new SqlParameter("@Introduction", InputEntity.Introduction));
                cmdSQL.Parameters.Add(new SqlParameter("@Url", InputEntity.Url));
                cmdSQL.Parameters.Add(new SqlParameter("@Price", InputEntity.Price));
                cmdSQL.CommandType = CommandType.Text;
                RowsAffected = cmdSQL.ExecuteNonQuery();
                ResultText = "Product Rows Affected: " + RowsAffected.ToString() + Environment.NewLine;

                strSQL = "INSERT INTO tblCPProductCategory(strWrongFieldName)";
                strSQL += " VALUES(@CategoryName)";
                cmdSQL.CommandText = strSQL;
                cmdSQL.Parameters.Clear();
                cmdSQL.Parameters.Add(new SqlParameter("@CategoryName", "A New Category"));
                RowsAffected = cmdSQL.ExecuteNonQuery();
                ResultText += "Product Category Rows Affected: " + RowsAffected.ToString();
                trnSQL.Commit();
              }
              // (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))

            }
            catch (System.Exception theException)
            {
              trnSQL.Rollback();
              ResultText = "Transaction Rolled Back" + Environment.NewLine + theException.ToString();
            }

          }
          // (SqlTransaction trnSQL = cnnSQL.BeginTransaction())

        }
        // (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))

      }
      catch (System.Exception theException)  
      {
        ResultText = theException.ToString();
      }

      return RowsAffected;
    }
    // int TransactionProcessing()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCommandViewModel

}
// WPFCommand.ViewModel