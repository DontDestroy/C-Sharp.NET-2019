//***
// Action
//   - Implementation of a normal deck of cards
//   - Some comments are in Dutch for clarification
//   - Some comments are in West-Flemish for clarification
//   - 2 constructor for creating a deck
//   - Make deck (mix the Face Values with the Suits)
//   - Indexer / Default property to get a card from the deck
//   - Counter of the number of cards in the deck
//   - Deal a hand (the full deck is divided over the hands)
//   - Draw a card (from the deck)
//   - Shuffle the cards (from the deck)
// Created
//   - CopyPaste � 20240128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240128 � VVDW
// Proposal (To Do)
//   - Only references between cpCard, cpDeck, cpHand and modDeckOfCardsTests are documented
//***

using System;
using System.Collections;

namespace CopyPaste.Learning.Games
{

  public class cpDeck
  {

    #region "Constructors / Destructors"

    public cpDeck()
      //***
      // Action
      //   - Constructor of a deck of playing cards
      //     - You set a list of face values (cpFaceValue)
      //       - 13 possibilities
      //     - You set a list of suits (cpSuit)
      //       - 4 possibilities
      //     - You combine them, so you have 52 playing cards
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - MakeDeck(cpSuit[], cpFaceValue[])
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      cpFaceValue[] arrcpFaceValue = new cpFaceValue[] 
        {cpFaceValue.Ace, cpFaceValue.Two, cpFaceValue.Three, cpFaceValue.Four, 
         cpFaceValue.Five, cpFaceValue.Six, cpFaceValue.Seven, cpFaceValue.Eight, 
         cpFaceValue.Nine, cpFaceValue.Ten, cpFaceValue.Jack, cpFaceValue.Queen, 
         cpFaceValue.King};
      cpSuit[] arrcpSuit = new cpSuit[] {cpSuit.Clubs, cpSuit.Diamonds, cpSuit.Hearts, cpSuit.Spades};

      MakeDeck(arrcpSuit, arrcpFaceValue);
    }
    // cpDeck()

    public cpDeck(cpSuit[] arrcpSuit, cpFaceValue[] arrcpFaceValue)
      //***
      // Action
      //   - Constructor of a deck of playing cards
      //     - You receive a list of face values (cpFaceValue)
      //       - Unknown possibilities at this moment
      //     - You receive a list of suits (cpSuit)
      //       - Unknown possibilities at this moment
      //     - You combine them, so you have x playing cards
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - MakeDeck(cpSuit(), cpFaceValue())
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MakeDeck(arrcpSuit, arrcpFaceValue);
    }
    // cpDeck(cpSuit[], cpFaceValue[])

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private ArrayList marrCard = new ArrayList();

    #endregion

    #region "Properties"

    public int Count
    {

      get
        //***
        // Action Get
        //   - Returns a the number of Cards in the Deck
        // Called by
        //   - cpCard Draw()
        //   - cpProgram.Main()
        //   - Deal(cpHand[])
        //   - Shuffle()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240128 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240128 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return marrCard.Count;
      }
      // int Count (Get)

    }
    // int Count

    public cpCard this[int lngIndex]
    {

      get
        //***
        // Action Get
        //   - If the index is accepted (possible)
        //     - Returns a specific Card from the Deck
        //   - If Not
        //     - An error is thrown
        // Called by
        //   - cpCard Draw()
        //   - cpProgram.Main()
        //   - Shuffle()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240128 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240128 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (lngIndex >= 0 && lngIndex < Count)
        {
          return (cpCard)marrCard[lngIndex];
        }
        else
          // lngIndex < 0 Or lngIndex >= Count
        {
          throw new ArgumentOutOfRangeException("You ask an x-th card that is not part of the deck.");
        }
        // lngIndex >= 0 And lngIndex < Count

      }
      // cpCard this[int] (Get)

    }
    // cpCard this[int]

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Deal(cpHand[] arrHands)
      //***
      // Action
      //   - All the Cards are divides over the Hands
      //   - The deck is empty after dealing the cards
      //   - Indexer of the Hands becomes zero
      //   - As long there are Cards in the Deck
      //     - Draw a Card from the Deck 
      //       - Add it to a Hand
      //       - Make the indexer of the hands one higher
      //       - If the number of hands is too big
      //         - Indexer becomes 0
      // Called by
      //   - modDeckOfCardsTest.Main()
      // Calls
      //   - cpHand.Add(cpCard)
      //   - Draw()
      //   - int Count (Get)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngHandIndex = 0;

      while (Count > 0)
      {
        arrHands[lngHandIndex].Add(Draw());
        lngHandIndex++;

        if (lngHandIndex == arrHands.Length)
        {
          lngHandIndex = 0;
        }
        else
          // lngHandIndex <> arrHands.Length
        {
        }
        // lngHandIndex = arrHands.Length

      }
      // Count <= 0

    }
    // Deal(cpHand[] arrHands)

    public cpCard Draw()
      //***
      // Action
      //   - A top card is defined to nothing
      //   - When there is a Card in the Deck
      //     - The top card (index 0) is assigned
      //     - The card is removed from the deck
      //   - The top card is returned
      //   - Attention
      //     - When there are no Cards, nothing is returned
      // Called by
      //   - Deal(cpHand[])
      //   - cpProgram.Main()
      // Calls
      //   - cpCard this[int] (Get)
      //   - int Count (Get)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpCard theTopCard = null;

      if (Count > 0)
      {
        theTopCard = this[0];
        marrCard.RemoveAt(0);
      }
      else
        // Count <= 0
      {
      }
      // Count > 0

      return theTopCard;
    }
    // cpCard Draw()

    private void MakeDeck(cpSuit[] arrcpSuit, cpFaceValue[] arrcpFaceValue)
      //***
      // Action
      //   - Loop thru all the given Suits
      //     - Loop thru all the given FaceValues
      //       - Create a Card of that Suit and FaceValue
      //       - Add it to the list of Cards
      // Called by
      //   - cpDeck()
      //   - cpDeck(cpSuit(), cpFaceValue())
      // Calls
      //   - cpCard(cpSuit, cpFaceValue)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpCard newcpCard;
      cpFaceValue newcpFaceValue;
      cpSuit newcpSuit;
      int lngFaceValue;
      int lngSuit;

      for (lngSuit = 0; lngSuit < arrcpSuit.Length; lngSuit++)
      {

        for (lngFaceValue = 0; lngFaceValue < arrcpFaceValue.Length; lngFaceValue++)
        {
          // Select a Suit
          newcpSuit = arrcpSuit[lngSuit];
          // Select a FaceValue
          newcpFaceValue = arrcpFaceValue[lngFaceValue];
          // Create a Card
          newcpCard = new cpCard(newcpSuit, newcpFaceValue);
          // Add the Card to the Deck
          marrCard.Add(newcpCard);

          // You can replace the four preceding lines with this
          // marrCards.Add(new cpCard(arrcpSuit(lngSuit), arrcpFaceValue(lngFaceValue)));
        }
        // lngFaceValue = arrcpFaceValue.Length

      }
      // lngSuit = arrcpSuit.Length

    }
    // MakeDeck(cpSuit[], cpFaceValue[])

    public void Shuffle()
      //***
      // Action
      //   - A new Deck is defined
      //   - You take the current Deck
      //   - As long there are Cards in the Deck
      //     - Take randomly a Card (one of the possible)
      //     - Remove it from the current Deck
      //     - Add it to the new Deck
      //   - The current Deck becomes the new Deck
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpCard this[int] (Get)
      //   - int Count (Get)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - A lot of different solutions are possible
      //***
    {
      ArrayList newDeck = new ArrayList();
      Random rndGenerate = new Random();

      while (Count > 0)
      {
        // Choose one card at random to remove
        int lngRemoveIndex = rndGenerate.Next(0, Count);
        System.Object objRemove = this[lngRemoveIndex];

        marrCard.RemoveAt(lngRemoveIndex);
        // Add the removed card to the new deck
        newDeck.Add(objRemove);
      }
      // Count <= 0

      // Replace the old deck with the new deck
      marrCard = newDeck;
    }
    // Shuffle()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDeck

}
// CopyPaste.Learning.Games