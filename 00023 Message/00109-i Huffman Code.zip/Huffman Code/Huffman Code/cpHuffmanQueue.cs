﻿//***
// Action
//   - Defines a Huffman queue (using a list to fake a queue)
//   - Temporary tool to generate a cpHuffmanTree
// Created
//   - CopyPaste – 20220719 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220719 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Text;

namespace CopyPaste.Huffman_Code
{

  public class cpHuffmanQueue
  {

    #region "Constructors / Destructors"

    public cpHuffmanQueue()
    //***
    // Action
    //   - Constructor of a queue (cpHuffmanQueue) (a faked queue using a list)
    // Called by
    //   - cpHuffmanTree(string)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20220719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
    }
    // cpHuffmanQueue()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    protected List<cpHuffmanNode> lstHuffmanNodes = new List<cpHuffmanNode>();
    #endregion

    #region "Properties"

    public int Count
    {
    
      get
      //***
      // Action Get
      //   - Count the items in the queue (a faked queue using a list)
      // Called by
      //   - cpHuffmanNode cpHuffmanNode.Dequeue()
      //   - cpHuffmanTree(string)
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220719 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220719 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return lstHuffmanNodes.Count; 
      }
      // int Count() (Get)

    }
    // int Count

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public cpHuffmanNode Dequeue()
    //***
    // Action
    //   - Remove (dequeue) a node from the queue (a faked queue using a list)
    // Called by
    //   - cpHuffmanTree(string)
    // Calls
    //   - int Count() (Get)
    // Created
    //   - CopyPaste – 20220719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (Count == 0)
      {
        throw new IndexOutOfRangeException("Tried to take an item from an empty queue");
      }
      else
      // Count <> 0
      {
        cpHuffmanNode cpReturn = lstHuffmanNodes[0];
        lstHuffmanNodes.Remove(cpReturn);
        return cpReturn;
      }
      // Count = 0

    }
    // cpHuffmanNode Dequeue()

    public void Enqueue(cpHuffmanNode aNode)
    //***
    // Action
    //   - Add (enqueue) a node to the queue (a faked queue using a list)
    // Called by
    //   - cpHuffmanTree(string)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20220719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lstHuffmanNodes.Add(aNode);
    }
    // Enqueue(cpHuffmanNode)

    public void Sort()
    //***
    // Action
    //   - Sort the queue (a faked queue using a list)
    // Called by
    //   - cpHuffmanTree(string)
    // Calls
    //   - int cpHuffmanNode.CompareTo(object)
    // Created
    //   - CopyPaste – 20220719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      lstHuffmanNodes.Sort();
    }
    // Sort()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpHuffmanQueue

}
// CopyPaste.Huffman_Code
