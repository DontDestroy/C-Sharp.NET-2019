//***
// Action
//   - Demo of a treeview bound control (There is a hierarchy)
// Created
//   - CopyPaste � 20260113 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260113 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using UsingWindows;

namespace CopyPaste.Learning
{

  public class frmTreeView: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Data.OleDb.OleDbCommand cmmSelectProduct;
    internal System.Data.OleDb.OleDbConnection cnncpNorthwind2000;
    internal System.Data.OleDb.OleDbCommand cmmSelectCategory;
    internal System.Data.OleDb.OleDbDataAdapter dtaProduct;
    internal System.Windows.Forms.TreeView trvProductOrder;
    internal System.Windows.Forms.TextBox txtPosition;
    internal System.Windows.Forms.TextBox txtDescription;
    internal System.Windows.Forms.TextBox txtCategoryName;
    internal System.Data.OleDb.OleDbCommand cmmSelectOrderDate;
    internal System.Windows.Forms.Label lblName;
    internal System.Windows.Forms.TextBox txtIdCategory;
    internal System.Windows.Forms.Label lblIdCategory;
    internal System.Data.OleDb.OleDbDataAdapter dtaOrderDate;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Button cmdLast;
    internal System.Data.OleDb.OleDbDataAdapter dtaCategory;
    internal System.Windows.Forms.Button cmdPrevious;
    private UsingWindows.dsData dsData;
    internal System.Windows.Forms.Button cmdFirst;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTreeView));
      this.cmmSelectProduct = new System.Data.OleDb.OleDbCommand();
      this.cnncpNorthwind2000 = new System.Data.OleDb.OleDbConnection();
      this.cmmSelectCategory = new System.Data.OleDb.OleDbCommand();
      this.dtaProduct = new System.Data.OleDb.OleDbDataAdapter();
      this.trvProductOrder = new System.Windows.Forms.TreeView();
      this.txtPosition = new System.Windows.Forms.TextBox();
      this.txtDescription = new System.Windows.Forms.TextBox();
      this.dsData = new UsingWindows.dsData();
      this.txtCategoryName = new System.Windows.Forms.TextBox();
      this.cmmSelectOrderDate = new System.Data.OleDb.OleDbCommand();
      this.lblName = new System.Windows.Forms.Label();
      this.txtIdCategory = new System.Windows.Forms.TextBox();
      this.lblIdCategory = new System.Windows.Forms.Label();
      this.dtaOrderDate = new System.Data.OleDb.OleDbDataAdapter();
      this.cmdNext = new System.Windows.Forms.Button();
      this.cmdLast = new System.Windows.Forms.Button();
      this.dtaCategory = new System.Data.OleDb.OleDbDataAdapter();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.cmdFirst = new System.Windows.Forms.Button();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.SuspendLayout();
      // 
      // cmmSelectProduct
      // 
      this.cmmSelectProduct.CommandText = "SELECT lngCategoryId, lngIdProduct, strProductName, blnDiscontinued, dblUnitPrice" +
    " FROM tblCPProduct";
      this.cmmSelectProduct.Connection = this.cnncpNorthwind2000;
      // 
      // cnncpNorthwind2000
      // 
      this.cnncpNorthwind2000.ConnectionString = resources.GetString("cnncpNorthwind2000.ConnectionString");
      // 
      // cmmSelectCategory
      // 
      this.cmmSelectCategory.CommandText = "SELECT lngIdCategory, strCategoryName, memDescription FROM tblCPCategory";
      this.cmmSelectCategory.Connection = this.cnncpNorthwind2000;
      // 
      // dtaProduct
      // 
      this.dtaProduct.SelectCommand = this.cmmSelectProduct;
      this.dtaProduct.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPProduct", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("lngCategoryId", "lngCategoryId"),
                        new System.Data.Common.DataColumnMapping("lngIdProduct", "lngIdProduct"),
                        new System.Data.Common.DataColumnMapping("strProductName", "strProductName"),
                        new System.Data.Common.DataColumnMapping("blnDiscontinued", "blnDiscontinued"),
                        new System.Data.Common.DataColumnMapping("dblUnitPrice", "dblUnitPrice")})});
      // 
      // trvProductOrder
      // 
      this.trvProductOrder.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.trvProductOrder.Location = new System.Drawing.Point(16, 93);
      this.trvProductOrder.Name = "trvProductOrder";
      this.trvProductOrder.Size = new System.Drawing.Size(344, 272);
      this.trvProductOrder.TabIndex = 16;
      // 
      // txtPosition
      // 
      this.txtPosition.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.txtPosition.Location = new System.Drawing.Point(88, 381);
      this.txtPosition.Name = "txtPosition";
      this.txtPosition.Size = new System.Drawing.Size(208, 20);
      this.txtPosition.TabIndex = 19;
      // 
      // txtDescription
      // 
      this.txtDescription.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPCategory.memDescription", true));
      this.txtDescription.Location = new System.Drawing.Point(16, 61);
      this.txtDescription.Name = "txtDescription";
      this.txtDescription.Size = new System.Drawing.Size(344, 20);
      this.txtDescription.TabIndex = 15;
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // txtCategoryName
      // 
      this.txtCategoryName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPCategory.strCategoryName", true));
      this.txtCategoryName.Location = new System.Drawing.Point(104, 36);
      this.txtCategoryName.Name = "txtCategoryName";
      this.txtCategoryName.Size = new System.Drawing.Size(256, 20);
      this.txtCategoryName.TabIndex = 14;
      // 
      // cmmSelectOrderDate
      // 
      this.cmmSelectOrderDate.CommandText = "SELECT tblCPOrder.dtmOrderDate, tblCPOrderDetail.lngIdProduct FROM (tblCPOrderDet" +
    "ail INNER JOIN tblCPOrder ON tblCPOrderDetail.lngIdOrder = tblCPOrder.lngIdOrder" +
    ")";
      this.cmmSelectOrderDate.Connection = this.cnncpNorthwind2000;
      // 
      // lblName
      // 
      this.lblName.AutoSize = true;
      this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblName.Location = new System.Drawing.Point(16, 37);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(43, 13);
      this.lblName.TabIndex = 13;
      this.lblName.Text = "Name:";
      // 
      // txtIdCategory
      // 
      this.txtIdCategory.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPCategory.lngIdCategory", true));
      this.txtIdCategory.Location = new System.Drawing.Point(104, 9);
      this.txtIdCategory.Name = "txtIdCategory";
      this.txtIdCategory.Size = new System.Drawing.Size(256, 20);
      this.txtIdCategory.TabIndex = 12;
      // 
      // lblIdCategory
      // 
      this.lblIdCategory.AutoSize = true;
      this.lblIdCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblIdCategory.Location = new System.Drawing.Point(16, 13);
      this.lblIdCategory.Name = "lblIdCategory";
      this.lblIdCategory.Size = new System.Drawing.Size(86, 13);
      this.lblIdCategory.TabIndex = 11;
      this.lblIdCategory.Text = "Category Key:";
      // 
      // dtaOrderDate
      // 
      this.dtaOrderDate.SelectCommand = this.cmmSelectOrderDate;
      this.dtaOrderDate.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "OrderDate", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("ProductID", "ProductID"),
                        new System.Data.Common.DataColumnMapping("OrderDate", "OrderDate")})});
      // 
      // cmdNext
      // 
      this.cmdNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdNext.Location = new System.Drawing.Point(304, 381);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(32, 23);
      this.cmdNext.TabIndex = 20;
      this.cmdNext.Text = ">";
      this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
      // 
      // cmdLast
      // 
      this.cmdLast.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdLast.Location = new System.Drawing.Point(336, 381);
      this.cmdLast.Name = "cmdLast";
      this.cmdLast.Size = new System.Drawing.Size(32, 23);
      this.cmdLast.TabIndex = 21;
      this.cmdLast.Text = ">>|";
      this.cmdLast.Click += new System.EventHandler(this.cmdLast_Click);
      // 
      // dtaCategory
      // 
      this.dtaCategory.SelectCommand = this.cmmSelectCategory;
      this.dtaCategory.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCategory", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("lngIdCategory", "lngIdCategory"),
                        new System.Data.Common.DataColumnMapping("strCategoryName", "strCategoryName"),
                        new System.Data.Common.DataColumnMapping("memDescription", "memDescription")})});
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdPrevious.Location = new System.Drawing.Point(48, 381);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(32, 23);
      this.cmdPrevious.TabIndex = 18;
      this.cmdPrevious.Text = "<";
      this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
      // 
      // cmdFirst
      // 
      this.cmdFirst.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdFirst.Location = new System.Drawing.Point(16, 381);
      this.cmdFirst.Name = "cmdFirst";
      this.cmdFirst.Size = new System.Drawing.Size(32, 23);
      this.cmdFirst.TabIndex = 17;
      this.cmdFirst.Text = "|<<";
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      // 
      // frmTreeView
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(376, 413);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.txtIdCategory);
      this.Controls.Add(this.lblIdCategory);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.cmdLast);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.cmdFirst);
      this.Controls.Add(this.trvProductOrder);
      this.Controls.Add(this.txtPosition);
      this.Controls.Add(this.txtDescription);
      this.Controls.Add(this.txtCategoryName);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTreeView";
      this.Text = "Windows Controls Treeview";
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTreeView'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTreeView()
      //***
      // Action
      //   - Create new instance of 'frmTreeView'
      //   - Fill the data set tblCPCategory with data adapter category
      //   - Fill the data set tblCPProduct with data adapter product
      //   - Fill the data set tblCPOrderDate with data adapter orderdate
      //   - Update the display
      //   - Add the nodes
      //   - When position of binding context is changed, the nodes must be added
      // Called by
      //   - frmMaster.cmdTreeView_Click(System.Object, System.EventArgs) Handles cmdTreeView.Click
      // Calls
      //   - AddNodes(System.Object, System.EventArgs)
      //   - InitializeComponent()
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
      dtaCategory.Fill(dsData.tblCPCategory);
      dtaProduct.Fill(dsData.tblCPProduct);
      dtaOrderDate.Fill(dsData.OrderDate);
      UpdateDisplay();
      
      AddNodes(this, new System.EventArgs());
      BindingContext[dsData, "tblCPCategory"].PositionChanged += new EventHandler(AddNodes);
    }
    // frmTreeView()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFirst_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the first position
      //   - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsData, "tblCPCategory"].Position = 0;
      UpdateDisplay();
    }
    // cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click

    private void cmdLast_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the last position
      //   - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsData, "tblCPCategory"].Position = BindingContext[dsData, "tblCPCategory"].Count - 1;
      UpdateDisplay();
    }
    // cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click

    private void cmdNext_Click(System.Object theSender, System.EventArgs theEventArguments)
      // Action
      //   - If you are at the last position
      //     - Do nothing
      //   - If not
      //     - Go to the next position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
        
      if (BindingContext[dsData, "tblCPCategory"].Position == BindingContext[dsData, "tblCPCategory"].Count - 1)
      {
      }
      else
        // BindingContext[dsData, "tblCPCategory"].Position <> BindingContext[dsData, "tblCPCategory"].Count - 1 
      {
        BindingContext[dsData, "tblCPCategory"].Position += 1;
        UpdateDisplay();
      }
      // BindingContext[dsData, "tblCPCategory"].Position = BindingContext[dsData, "tblCPCategory"].Count - 1 
    
    }
    // cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click

    private void cmdPrevious_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If you are at the first position
      //     - Do nothing
      //   - If not
      //     - Go to the previous position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (BindingContext[dsData, "tblCPCategory"].Position == 0)
      {
      }
      else
        // BindingContext[dsData, "tblCPCategory"].Position <> 0
      {
        BindingContext[dsData, "tblCPCategory"].Position -= 1;
        UpdateDisplay();
      }
      // BindingContext[dsData, "tblCPCategory"].Position = 0

    }
    // cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click

    #endregion

    #region "Functionality"

    #region "Event"

    private void AddNodes(System.Object theSender, EventArgs theEventArguments)
      //***
      // Action
      //   - Define a data row array for order
      //   - Define a data row array for product
      //   - Define a current row for order
      //   - Define a current row for product
      //   - Define a data row view for category
      //   - Define a root node
      //   - Start updating the treeview
      //   - Clear the treeview
      //   - Assign the data row view to the current row in tblCPCategory
      //   - Get the child records thru the relation ProductCategory
      //   - Loop thru the products
      //     - Add a node with the product name
      //     - This node becomes the root
      //     - Get the child records thru the relation OrderDateProduct
      //     - Loop thru the orderdates
      //       - Add a node to the root with the order date
      //   - Stop updating the treeview
      // Called by
      //   - frmTreeView()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DataRow[] arrdrwOrder;
      DataRow[] arrdrwProduct;
      DataRowView drvCategory;
      System.Windows.Forms.TreeNode tndroot;

      trvProductOrder.BeginUpdate();
      trvProductOrder.Nodes.Clear();

      drvCategory = ((DataRowView)BindingContext[dsData, "tblCPCategory"].Current);
      arrdrwProduct = drvCategory.Row.GetChildRows("ProductCategory");

      foreach(dsData.tblCPProductRow currProduct in arrdrwProduct)
      {
        tndroot = trvProductOrder.Nodes.Add(currProduct.strProductName);
        arrdrwOrder = currProduct.GetChildRows("OrderDateProduct");
        
        foreach (dsData.OrderDateRow currOrder in arrdrwOrder)
        {
          tndroot.Nodes.Add(currOrder.dtmOrderDate.ToString("dd/MM/yyyy"));
        }
        // in arrdrwOrder

      }
      // in arrdrwProduct

      trvProductOrder.EndUpdate();
    }
    // AddNodes(System.Object, System.EventArgs)

    #endregion

    #region "Sub / Function"

    private void UpdateDisplay()
      //***
      // Action
      //   - Define a binding manager base
      //   - Assign the binding manager base to the data table Category from the data set
      //   - Show the current position
      // Called by
      //   - cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click
      //   - cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click
      //   - cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click
      //   - cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click
      //   - frmTreeView()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingManagerBase bmbBindingManagerBase;

      bmbBindingManagerBase = BindingContext[dsData, "tblCPCategory"];
      txtPosition.Text = "Category ";
      txtPosition.Text += (bmbBindingManagerBase.Position + 1).ToString();
      txtPosition.Text += " of ";
      txtPosition.Text += bmbBindingManagerBase.Count.ToString();
    }
    // UpdateDisplay()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTreeView

}
// CopyPaste.Learning