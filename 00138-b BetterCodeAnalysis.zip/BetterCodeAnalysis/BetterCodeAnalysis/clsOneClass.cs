//***
// Action
//   - Implementation of cpOneClass
// Created
//   - CopyPaste � 20240124 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240124 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  /// <summary>
  /// Definition of a public class
  /// </summary>
  public class cpOneClass
  {

    #region "Constructors / Destructors"

    /// <summary>
    /// Constructor of a cpOneClass
    /// </summary>
    /// <param name="strName">The name of the class</param>
    /// <param name="strFileName">The filename of the class</param>
    public cpOneClass(string strName, string strFileName)
      //***
      // Action
      //   - Constructor with 2 parameters
      //   - It defines one class by its name and filename
      // Called by
      //   - cpClass.ReadFromFile(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240124 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240124 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mstrFilename = strFileName;
      mstrName = strName;
    }
    // cpOneClass(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrFilename;
    private string mstrName;

    #endregion

    #region "Properties"

    /// <summary>
    /// The filename of a cpOneClass
    /// </summary>
    public string FileName
    {

      get
        //***
        // Action Get
        //   - Returns mstrFileName
        // Called by
        //   - Visualisation of cpOneClass in data grid 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240124 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240124 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrFilename;
      }
      // string FileName (Get)

    }
    // string FileName

    /// <summary>
    /// The name of a cpOneClass
    /// </summary>
    public string Name
    {

      get
        //***
        // Action Get
        //   - Returns mstrName
        // Called by
        //   - Visualisation of cpOneClass in data grid 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240124 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240124 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

    }
    // string Name

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpOneClass

}
// CopyPaste.Learning