//***
// Action
//   - Show a file open dialog box
// Created
//   - CopyPaste � 20240925 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240925 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFileOpen: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdSelect;

    private void InitializeComponent()
    {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmFileOpen));
			this.cmdSelect = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// cmdSelect
			// 
			this.cmdSelect.Location = new System.Drawing.Point(102, 88);
			this.cmdSelect.Name = "cmdSelect";
			this.cmdSelect.Size = new System.Drawing.Size(88, 32);
			this.cmdSelect.TabIndex = 1;
			this.cmdSelect.Text = "Select a File";
			this.cmdSelect.Click += new System.EventHandler(this.cmdSelect_Click);
			// 
			// frmFileOpen
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 273);
			this.Controls.Add(this.cmdSelect);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmFileOpen";
			this.Text = "File Open";
			this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFileOpen'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240925 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240925 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFileOpen()
      //***
      // Action
      //   - Create instance of 'frmFileOpen'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240925 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240925 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFileOpen()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdSelect_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a File open Dialog
      //   - Set the filter to specific file formats
      //   - Select the third option
      //   - Set an initial directory
      //   - If OK button is clicked after showing it
      //     - Show a messagebox with what file is selected
      //   - If not
      //     - Show a messagebox that cancel was clicked
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240925 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240925 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      OpenFileDialog dlgFileOpen = new OpenFileDialog();

      dlgFileOpen.Filter = "All files | *.* | Word files | *.doc | Text files | *.txt";
      dlgFileOpen.FilterIndex = 3;
      dlgFileOpen.InitialDirectory = "T:\\";

      if (dlgFileOpen.ShowDialog() == DialogResult.OK)
      {
        MessageBox.Show("File: " + dlgFileOpen.FileName);
      }
      else
        // dlgFileOpen.ShowDialog() <> DialogResult.OK
      {
        MessageBox.Show("User selected Cancel");
      }
      // dlgFileOpen.ShowDialog() = DialogResult.OK
    
    }
    // cmdSelect_Click(System.Object, System.EventArgs) Handles cmdSelect.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFileOpen
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmFileOpen()
      // Created
      //   - CopyPaste � 20240925 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240925 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFileOpen());
    }
		// Main() 

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
  // frmFileOpen

}
// CopyPaste.Learning