//***
// Action
//   - Testroutine for cpEmployee, cpHandWorker, cpOfficeWorker and cpManager
// Created
//   - CopyPaste � 20240405 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240405 � VVDW
// Proposal (To Do)
//   - Not all getters and setters are tested, but the usual stuff is
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Instantiation of a cpEmployee
      //   - Instantiation of a cpHandWorker
      //   - Instantiation of a cpManager
      //   - Instantiation of a cpOfficeWorker
      //   - Show information of a cpEmployee using ShowInfo
      //   - Show information of a cpEmployee using ToString
      //   - Show information about the data type of cpEmployee
      //   - Show information of a cpHandWorker using ShowInfo
      //   - Show information of a cpHandWorker using ToString
      //   - Show information about the data type of cpHandWorker
      //   - Show information of a cpOfficeWorker using ShowInfo
      //   - Show information of a cpOfficeWorker using ToString
      //   - Show information about the data type of cpOfficeWorker 
      //   - Show information of a cpManager using ShowInfo
      //   - Show information of a cpManager using ToString
      //   - Show information about the data type of cpManager
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpEmployee(string)
      //   - cpEmployee.ShowInfo()
      //   - cpHandWorker(string)
      //   - cpHandWorker.ShowInfo()
      //   - cpManager(string)
      //   - cpManager.ShowInfo()
      //   - cpOfficeWorker(string)
      //   - cpOfficeWorker.ShowInfo()
      //   - string cpEmployee.ToString()
      //   - string cpHandWorker.ToString()
      //   - string cpManager.ToString()
      //   - string cpOfficeWorker.ToString()
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpEmployee thecpEmployee = new cpEmployee("Alfons");
      cpHandWorker thecpHandWorker = new cpHandWorker("Xavier");
      cpManager thecpManager = new cpManager("Vincent");
      cpOfficeWorker thecpOfficeWorker = new cpOfficeWorker("Hilde");

      thecpEmployee.ShowInfo();
      Console.WriteLine(thecpEmployee.ToString());
      Console.WriteLine("Is Alfons employee? " + (thecpEmployee is cpEmployee));
      Console.WriteLine("Is Alfons handworker? " + (thecpEmployee is cpHandWorker));
      Console.WriteLine("Is Alfons officeworker? " + (thecpEmployee is cpOfficeWorker));
      Console.WriteLine("Is Alfons manager? " + (thecpEmployee is cpManager));
      Console.WriteLine();
      thecpHandWorker.ShowInfo();
      Console.WriteLine(thecpHandWorker.ToString());
      Console.WriteLine("Is Xavier employee? " + (thecpHandWorker is cpEmployee));
      Console.WriteLine("Is Xavier handworker? " + (thecpHandWorker is cpHandWorker));
      Console.WriteLine("Is Xavier officeworker? " + (thecpHandWorker is cpOfficeWorker));
      Console.WriteLine("Is Xavier manager? " + (thecpHandWorker is cpManager));
      Console.WriteLine();
      thecpOfficeWorker.ShowInfo();
      Console.WriteLine(thecpOfficeWorker.ToString());
      Console.WriteLine("Is Hilde employee? " + (thecpOfficeWorker is cpEmployee));
      Console.WriteLine("Is Hilde handworker? " + (thecpOfficeWorker is cpHandWorker));
      Console.WriteLine("Is Hilde officeworker? " + (thecpOfficeWorker is cpOfficeWorker));
      Console.WriteLine("Is Hilde manager? " + (thecpOfficeWorker is cpManager));
      Console.WriteLine();
      thecpManager.ShowInfo();
      Console.WriteLine(thecpManager);
      Console.WriteLine("Is Vincent employee? " + (thecpManager is cpEmployee));
      Console.WriteLine("Is Vincent handworker? " + (thecpManager is cpHandWorker));
      Console.WriteLine("Is Vincent officeworker? " + (thecpManager is cpOfficeWorker));
      Console.WriteLine("Is Vincent manager? " + (thecpManager is cpManager));
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning.Employee