//***
// Action
//   - Testroutine for cpContact
//   - This application does not work correctly
//   - It is the purpose of this exercise, to demo the finalize
// Created
//   - CopyPaste � 20230704 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230704 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;

namespace Finalize
{

  public class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Create 3 instances of cpContact
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpContact.new(string, string, string)
    //   - cpContact.Finalize()
    // Created
    //   - CopyPaste � 20230704 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230704 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpContact Amanda = new cpContact("Amanda", "281-555-1111", "Duh@aol.com");
      cpContact Megan = new cpContact("Megan", "713-555-1212", "Megan@hotmail.com");
      cpContact Sara = new cpContact("Sara", "281-555-1212", "Sara@yahoo.com");

      Console.WriteLine("Hit any key");
      Console.ReadLine();
    }
    // Main()

    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// Finalize