//***
// Action
//   - Use some variables
//   - Scope test
// Created
//   - CopyPaste � 20220128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220128 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace VariableScope
{

  public class cpVariableScopePart2
	{

    public cpVariableScopePart2()
    //***
    // Action
    //   - Constructor
    // Called by
    //   - System action (Creating an object)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    //cpVariableScopePart2()

    public void ShowVariables()
    //***
    // Action
    //   - Show some variables
    // Called by
    //   - cpVariableScope.Main()
    // Calls
    //   - cpAnotherVariableScope.strModuleLevelPublic
    //   - aAnotherVariableScope.VariableScopePart3()
    //   - cpVariableScope.strModuleLevelInternal
    //   - cpVariableScope.strModuleLevelPrivate
    //   - cpVariableScope.strModuleLevelPublic
    //   - DialogResult System.Windows.Forms.MessageBox.Show(string) 
    // Created
    //   - CopyPaste � 20220128 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220128 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      cpAnotherVariableScope aAnotherVariableScope;
      cpVariableScope aVariableScope;

      aAnotherVariableScope = new cpAnotherVariableScope();
      aVariableScope = new cpVariableScope();

      MessageBox.Show(aVariableScope.strModuleLevelInternal);
      // MessageBox.Show(aVariableScope.strModuleLevelPrivate);
      MessageBox.Show(aVariableScope.strModuleLevelPublic);
      MessageBox.Show(aAnotherVariableScope.strModuleLevelPublic);
      aAnotherVariableScope.VariableScopePart3();
    }
    // ShowVariables()

  }
  // cpVariableScopePart2

}
// VariableScope