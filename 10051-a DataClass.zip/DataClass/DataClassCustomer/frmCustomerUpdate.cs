//***
// Action
//   - Update a customer
//   - Retrieved with a given key
// Created
//   - CopyPaste � 20260117 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260117 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmCustomerUpdate: ifrmCustomer
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCustomerUpdate));
      // 
      // cmdNew
      // 
      this.cmdNew.Enabled = true;
      this.cmdNew.Name = "cmdNew";
      this.cmdNew.Click += new System.EventHandler(this.cmdNew_Click);
      // 
      // cmdDelete
      // 
      this.cmdDelete.Enabled = true;
      this.cmdDelete.Name = "cmdDelete";
      this.cmdDelete.Click += new System.EventHandler(this.cmdDelete_Click);
      // 
      // cmdSave
      // 
      this.cmdSave.Enabled = true;
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // cmdRetrieve
      // 
      this.cmdRetrieve.Enabled = true;
      this.cmdRetrieve.Name = "cmdRetrieve";
      this.cmdRetrieve.Click += new System.EventHandler(this.cmdRetrieve_Click);
      // 
      // txtFax
      // 
      this.txtFax.Name = "txtFax";
      // 
      // txtPhone
      // 
      this.txtPhone.Name = "txtPhone";
      // 
      // txtRegion
      // 
      this.txtRegion.Name = "txtRegion";
      // 
      // txtCountry
      // 
      this.txtCountry.Name = "txtCountry";
      // 
      // txtZip
      // 
      this.txtZip.Name = "txtZip";
      // 
      // txtCity
      // 
      this.txtCity.Name = "txtCity";
      // 
      // txtAddress
      // 
      this.txtAddress.Name = "txtAddress";
      // 
      // txtContactTitle
      // 
      this.txtContactTitle.Name = "txtContactTitle";
      // 
      // txtIdCustomer
      // 
      this.txtIdCustomer.Name = "txtIdCustomer";
      // 
      // txtContactName
      // 
      this.txtContactName.Name = "txtContactName";
      // 
      // txtCompanyName
      // 
      this.txtCompanyName.Name = "txtCompanyName";
      // 
      // frmCustomerUpdate
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(688, 325);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCustomerUpdate";
      this.Text = "Default";

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmCustomerUpdate'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - ifrmCustomer.Dispose(bool)
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmCustomerUpdate() : base()
      //***
      // Action
      //   - Create new instance of 'frmCustomerUpdate'
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCustomer()
      //   - ifrmCustomer()
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
      mcpCustomer = new cpCustomer();
    }
    // frmCustomerUpdate()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpCustomer mcpCustomer;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void TextBoxChange(string strProperty, string strValue)
      //***
      // Action
      //   - Try to
      //     - Depending on the textbox (property)
      //       - Fill the corresponding property of the customer instance (linked to the form)
      //     - Fill the rich text box with the customer info (ToString())
      //   - When there is no cpCustomer instance
      //     - Do nothing
      //   - When other exception
      //     - Show exception message
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCustomer.Address(string) (Set)
      //   - cpCustomer.City(string) (Set)
      //   - cpCustomer.CompanyName(string) (Set)
      //   - cpCustomer.ContactName(string) (Set)
      //   - cpCustomer.ContactTitle(string) (Set)
      //   - cpCustomer.Country(string) (Set)
      //   - cpCustomer.Fax(string) (Set)
      //   - cpCustomer.Phone(string) (Set)
      //   - cpCustomer.Region(string) (Set)
      //   - cpCustomer.PostalCode(string) (Set)
      //   - string cpCustomer.ToString()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {

        switch (strProperty)
        {
          case "Address":
            mcpCustomer.Address = strValue;
            break;
          case "City":
            mcpCustomer.City = strValue;
            break;
          case "CompanyName":
            mcpCustomer.CompanyName = strValue;
            break;
          case "ContactName":
            mcpCustomer.ContactName = strValue;
            break;
          case "ContactTitle":
            mcpCustomer.ContactTitle = strValue;
            break;
          case "Country":
            mcpCustomer.Country = strValue;
            break;
          case "Fax":
            mcpCustomer.Fax = strValue;
            break;
          case "Phone":
            mcpCustomer.Phone = strValue;
            break;
          case "Region":
            mcpCustomer.Region = strValue;
            break;
          case "Zip":
            mcpCustomer.PostalCode = strValue;
            break;
        }
        // strProperty

        rtxtToString.Text = mcpCustomer.ToString();
      }
      catch (NullReferenceException theNullReferenceException)
      {
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }

    }
    // TextBoxChange(string, string)

    #endregion

    #region "Controls"

    private void cmdDelete_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Delete the instance of cpCustomer
      //     - If successful
      //       - Show message that delete was successful
      //       - Set instance of cpCustomer to nothing
      //       - Clear the textboxes
      //     - If not
      //       - Show message that delete was unsuccessful
      //   - When exception occurs
      //     - Show exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool cpCustomer.Delete() Implements cpiCustomer.Delete
      //   - ClearAllTextBoxes()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
       
        if (mcpCustomer.Delete())
        {
          MessageBox.Show("Delete succeeded.");
          mcpCustomer = null;
          ClearAllTextBoxes();
        }
        else
          // mcpCustomer.Delete()
        {
          MessageBox.Show("Delete failed.");
        }
        // mcpCustomer.Delete()
      
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
      
    }
    // cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click

    private void cmdNew_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - If there is a value in the customer key
      //       - If there is a value in the customer name
      //         - Create a new instance of cpCustomer with key and name
      //       - If not
      //         - Show message that a customer name is obligatory
      //     - If not
      //       - Show message that a unique key is obligatory, ask to create one by the program
      //       - If yes
      //         - A default customer is created
      //       - If no
      //         - All textboxes are cleared
      //   - When exception occurs
      //     - Show exception message
      //     - All textboxes are cleared
      // Called by
      //   - User action (Clicking a button)
      //   - cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      // Calls
      //   - ClearAllTextBoxes()
      //   - cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      //   - cpCustomer(string, string)
      //   - cpCustomer.Address(string) (Set)
      //   - cpCustomer.City(string) (Set)
      //   - cpCustomer.ContactName(string) (Set)
      //   - cpCustomer.ContactTitle(string) (Set)
      //   - cpCustomer.Country(string) (Set)
      //   - cpCustomer.Fax(string) (Set)
      //   - cpCustomer.Phone(string) (Set)
      //   - cpCustomer.PostalCode(string) (Set)
      //   - cpCustomer.Region(string) (Set)
      //   - CustomerProperties()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    
      try
      {
        string strMessage;

        if (txtIdCustomer.Text.Length > 0)
        {

          if (txtCompanyName.Text.Length > 0)
          {
            mcpCustomer = new cpCustomer(txtIdCustomer.Text, txtCompanyName.Text);
          }
          else
            // txtCompanyName.Text.Length <= 0
          {
            MessageBox.Show("A company name is required for a new Customer");
          }
          // txtCompanyName.Text.Length > 0

        }
        else
          // txtIdCustomer.Text.Length <= 0
        {
          strMessage = "A CustomerKey is required for a new Customer." + Environment.NewLine +
            "Would you like a new customer created for you?";

          switch (MessageBox.Show(strMessage, "New Customer", MessageBoxButtons.YesNoCancel))
          {
            case DialogResult.Yes:
              txtIdCustomer.Text = "COPYP";
              txtCompanyName.Text = "Copy Paste";
              cmdNew_Click(theSender, theEventArguments);
              mcpCustomer.Address = "Hazebos 13";
              mcpCustomer.City = "Zonnebeke";
              mcpCustomer.ContactName = "Vincent Van De Walle";
              mcpCustomer.ContactTitle = "Mister";
              mcpCustomer.Country = "Belgium";
              mcpCustomer.Fax = "+32 (0)57/21.25.72";
              mcpCustomer.Phone = "+32 (0)57/21.25.71";
              mcpCustomer.PostalCode = "8980";
              mcpCustomer.Region = "West-Vlaanderen";
              break;
            case DialogResult.No:
            case DialogResult.Cancel:
              ClearAllTextBoxes();
              break;
            default:
              break;
          }
          // MessageBox.Show(xxx)

        }
        // txtIdCustomer.Text.Length > 0

        CustomerProperties();
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
        ClearAllTextBoxes();
      }
      finally
      {
      }
    
    }
    // cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click

    private void cmdRetrieve_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Create a new cpCustomer instance with a given key
      //     - Fill the textboxes with customer properties
      //   - When error occurs
      //     - Show exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpCustomer(string)
      //   - CustomerProperties()
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
            
      try
      {
        mcpCustomer = new cpCustomer(txtIdCustomer.Text);
        CustomerProperties();
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click

    private void cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Save the cpCustomer instance
      //     - If successfull
      //       - Show message
      //     - If not
      //       - Show message
      //   - When error occurs
      //     - Show exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool cpCustomer.Save() Implements cpiCustomer.Save
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {

        if (mcpCustomer.Save())
        {
          MessageBox.Show("Save succeeded.");
        }
        else
          // not mcpCustomer.Save()
        {
          MessageBox.Show("Save failed.");
        }
        // mcpCustomer.Save()
      
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void CustomerProperties()
      //***
      // Action
      //   - Fill all textboxes with the corresponding property
      // Called by
      //   - cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      //   - cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click
      // Calls
      //   - string cpCustomer.Address (Get)
      //   - string cpCustomer.City (Get)
      //   - string cpCustomer.CompanyName (Get)
      //   - string cpCustomer.ContactName (Get)
      //   - string cpCustomer.ContactTitle (Get)
      //   - string cpCustomer.Country (Get)
      //   - string cpCustomer.Fax (Get)
      //   - string cpCustomer.Phone (Get)
      //   - string cpCustomer.Region (Get)
      //   - string cpCustomer.PostalCode (Get)
      // Created
      //   - CopyPaste � 20260117 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260117 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtAddress.Text = mcpCustomer.Address;
      txtCity.Text = mcpCustomer.City;
      txtCompanyName.Text = mcpCustomer.CompanyName;
      txtContactName.Text = mcpCustomer.ContactName;
      txtContactTitle.Text = mcpCustomer.ContactTitle;
      txtCountry.Text = mcpCustomer.Country;
      txtFax.Text = mcpCustomer.Fax;
      txtPhone.Text = mcpCustomer.Phone;
      txtRegion.Text = mcpCustomer.Region;
      txtZip.Text = mcpCustomer.PostalCode;
    }
    // CustomerProperties()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmCustomerUpdate

}
// CopyPaste.Learning