//***
// Action
//   - Check if text is numeric
//   - There is a naming convention error in this example (try to find it)
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using Microsoft.VisualBasic;

namespace IsNumeric
{

  class cpIsNumeric
	{

    static void Main()
    //***
    // Action
    //   - Ask for a length (lngInput)
    //   - If 'lngInput' is numeric
    //     - Do a calculation (length from cm to inch)
    //   - If Not
    //     - Show error message
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - bool Microsoft.VisualBasic.Information.IsNumeric(string)
    //   - decimal System.Convert.ToDecimal(string)
    //   - string System.Console.ReadLine()
    //   - System.Console.Write(string)
    //   - System.Console.WriteLine(string, System.Object)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      const decimal decCmInch = 2.54M;
      decimal decInch;
      string lngInput;

      Console.Write("Type a length in cm.: ");
      lngInput = Console.ReadLine();

      if (Information.IsNumeric(lngInput))
      {
        decInch = Convert.ToDecimal(lngInput) / decCmInch;
        Console.WriteLine("Length in inch: {0}", decInch);
      }
      else
        // Not (Information.IsNumeric(lngInput))
      {
        Console.WriteLine("Wrong input");
      }
      // (Information.IsNumeric(sngInput))

      Console.ReadLine();
    }
    // Main()

  }
  // cpIsNumeric

}
// IsNumeric