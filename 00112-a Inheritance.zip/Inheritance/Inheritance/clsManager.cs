//***
// Action
//   - Implementation of a cpManager
//   - Inherits from cpOffice
// Created
//   - CopyPaste � 20240405 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240405 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpManager : cpOffice
  {

    #region "Constructors / Destructors"

    public cpManager() : base()
      //***
      // Action
      //   - Default constructor
      // Called by
      //   - cpOffice()
      //   - Extra(decimal) (Set)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Extra = 0;
    }
    // cpManager()

    public cpManager(string strName, cpSex thecpSex, DateTime dtmStartDate, decimal decEarnings, decimal decExtra) : base(strName, thecpSex, dtmStartDate, decEarnings)
      //***
      // Action
      //   - Constructor with Name, Sex, StartDate, Earnings and Extra
      // Called by
      //   - cpProgram.Main()
      //   - Extra(decimal) (Set)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Extra = decExtra;
    }
    // cpManager(string, cpSex, DateTime, decimal, decimal)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private decimal mdecExtra;

    #endregion

    #region "Properties"

    public decimal Extra
    {

      get
        //***
        // Action Get
        //   - Returns mdecExtra
        // Called by
        //   - ShowInfo() 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecExtra;
      }
      // decimal Extra (Get)

      set
        //***
        // Action Set
        //   - mdecExtra becomes value
        //   - Only positive values or zero are allowed
        // Called by
        //   - cpManager()
        //   - cpManager(string, cpSex, DateTime, decimal, decimal)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value >= 0)
        {
          mdecExtra = value;
        }
        else
          // value < 0
        {
        }
        // value >= 0

      }
      // Extra(decimal) (Set)

    }
    // decimal Extra

    #endregion

    #region "Methods"

    #region "Overrides"

    public override void ShowInfo()
      //***
      // Action
      //   - Shows information to the console
      //     - Name, Sex, StartDate, Is it a Workanniversary, Is it CompanyParty
      //     - Extra
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpOffice.ShowInfo()
      //   - decimal Extra (Get)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      base.ShowInfo();
      Console.WriteLine("Extra: {0}", Extra);
    }
    // ShowInfo()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpManager

}
// CopyPaste.Learning.Employee