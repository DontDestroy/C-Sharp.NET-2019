//***
// Action
//   - Consumer of the Predict Future webservice
// Created
//   - CopyPaste � 20260424 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260424 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using PredictFuture.cpServiceReference;

namespace CopyPaste.Learning
{

  public class frmPredictFuture: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdAskQuestion;
    internal System.Windows.Forms.Label lblQuestion;
    internal System.Windows.Forms.Button cmdRetrieve;
    internal System.Windows.Forms.Label lblRetrieveAnswer;
    internal System.Windows.Forms.TextBox txtQuestion;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPredictFuture));
      this.cmdAskQuestion = new System.Windows.Forms.Button();
      this.lblQuestion = new System.Windows.Forms.Label();
      this.cmdRetrieve = new System.Windows.Forms.Button();
      this.lblRetrieveAnswer = new System.Windows.Forms.Label();
      this.txtQuestion = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdAskQuestion
      // 
      this.cmdAskQuestion.Location = new System.Drawing.Point(16, 208);
      this.cmdAskQuestion.Name = "cmdAskQuestion";
      this.cmdAskQuestion.Size = new System.Drawing.Size(120, 23);
      this.cmdAskQuestion.TabIndex = 9;
      this.cmdAskQuestion.Text = "&Ask a Question";
      this.cmdAskQuestion.Click += new System.EventHandler(this.cmdAskQuestion_Click);
      // 
      // lblQuestion
      // 
      this.lblQuestion.Location = new System.Drawing.Point(16, 136);
      this.lblQuestion.Name = "lblQuestion";
      this.lblQuestion.Size = new System.Drawing.Size(264, 56);
      this.lblQuestion.TabIndex = 8;
      // 
      // cmdRetrieve
      // 
      this.cmdRetrieve.Location = new System.Drawing.Point(16, 56);
      this.cmdRetrieve.Name = "cmdRetrieve";
      this.cmdRetrieve.Size = new System.Drawing.Size(120, 23);
      this.cmdRetrieve.TabIndex = 7;
      this.cmdRetrieve.Text = "&Retrieve an Answer";
      this.cmdRetrieve.Click += new System.EventHandler(this.cmdRetrieve_Click);
      // 
      // lblRetrieveAnswer
      // 
      this.lblRetrieveAnswer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblRetrieveAnswer.Location = new System.Drawing.Point(16, 16);
      this.lblRetrieveAnswer.Name = "lblRetrieveAnswer";
      this.lblRetrieveAnswer.Size = new System.Drawing.Size(152, 23);
      this.lblRetrieveAnswer.TabIndex = 6;
      // 
      // txtQuestion
      // 
      this.txtQuestion.Location = new System.Drawing.Point(16, 104);
      this.txtQuestion.Name = "txtQuestion";
      this.txtQuestion.Size = new System.Drawing.Size(264, 20);
      this.txtQuestion.TabIndex = 5;
      this.txtQuestion.Text = "";
      // 
      // frmPredictFuture
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdAskQuestion);
      this.Controls.Add(this.lblQuestion);
      this.Controls.Add(this.cmdRetrieve);
      this.Controls.Add(this.lblRetrieveAnswer);
      this.Controls.Add(this.txtQuestion);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPredictFuture";
      this.Text = "Predict Future";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmPredictFuture'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260424 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260424 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPredictFuture()
    //***
    // Action
    //   - Create instance of 'frmPredictFuture'
    // Called by
    //   - Main()
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste � 20260424 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260424 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmPredictFuture()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAskQuestion_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define and initialize the predict future webservice
    //   - If the length of the question is to short
    //     - Show error message
    //   - If not
    //     - Gets the answer (return of the webservice)
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - cpPredictFutureWebService()
    //   - cpPredictFutureWebService.GetAnswer(string)
    // Created
    //   - CopyPaste � 20260424 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260424 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpPredictFutureWebService thePredictFutureWebService = new cpPredictFutureWebService();

      if (txtQuestion.Text.Length < 2)
      {
        MessageBox.Show("Please enter a question to submit.", "Predict Future Client", MessageBoxButtons.OK, MessageBoxIcon.Question);
      }
      else
        // txtQuestion.Text.Length >= 2
      {
        lblQuestion.Text = thePredictFutureWebService.GetAnswer(txtQuestion.Text);
      }
      // txtQuestion.Text.Length < 2
    
    }
    // cmdAskQuestion_Click(System.Object, System.EventArgs) Handles cmdAskQuestion.Click

    private void cmdRetrieve_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define and initialize the predict future webservice
    //   - Get Future (return of the webservice)
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - cpPredictFutureWebService.GetFuture()
    //   - cpPredictFutureWebService.New()
    // Created
    //   - CopyPaste � 20260424 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260424 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpPredictFutureWebService thePredictFutureWebService = new cpPredictFutureWebService();
    
      lblRetrieveAnswer.Text = thePredictFutureWebService.GetFuture();
    }
    // cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmPredictFuture
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmPredictFuture()
    // Created
    //   - CopyPaste � 20260424 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260424 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmPredictFuture());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPredictFuture

}
// CopyPaste.Learning