//***
// Action
//   - Example of logical operators
//   - & = And
//   - | = Or
//   - && = AndAlso
//   - || = OrElse
//   - Xor = Exclusive Or
//   - Not = Negation
// Created
//   - CopyPaste � 20220119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220119 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace LogicalOperator
{

  class cpLogicalOperator
	{

    static void Main()
    //***
    // Action
    //   - Test logical operator && (AndAlso)
    //   - Test logical operator || (OrElse)
    //   - Test logical operator & (And)
    //   - Test logical operator | (Or)
    //   - Test logical operator ^ (Xor)
    //   - Test logical operator ! (Not)
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.Write(string)
    // Created
    //   - CopyPaste � 20220119 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220119 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.Write("&& AndAlso" +
      "\nFalse && False: " + (false && false) +
      "\nFalse && True: " + (false && true) +
      "\nTrue && False: " + (true && false) +
      "\nTrue && True: " + (true && true) + "\n\n");

      Console.Write("|| OrElse" +
      "\nFalse || False: " + (false || false) +
      "\nFalse || True: " + (false || true) +
      "\nTrue || False: " + (true || false) +
      "\nTrue || True: " + (true || true) + "\n\n");

      Console.Write("& And" +
      "\nFalse & False: " + (false & false) +
      "\nFalse & True: " + (false & true) +
      "\nTrue & False: " + (true & false) +
      "\nTrue & True: " + (true & true) + "\n\n");

      Console.Write("| Or" +
      "\nFalse | False: " + (false | false) +
      "\nFalse | True: " + (false | true) +
      "\nTrue | False: " + (true | false) +
      "\nTrue | True: " + (true | true) + "\n\n");

      Console.Write("^ Xor" +
      "\nFalse ^ False: " + (false ^ false) +
      "\nFalse ^ True: " + (false ^ true) +
      "\nTrue ^ False: " + (true ^ false) +
      "\nTrue ^True: " + (true ^ true) + "\n\n");

      Console.Write("! Not" +
      "\n!False: " + !false +
      "\n!True: " + !true + "\n\n");

      Console.ReadLine();
    }
    // Main()

  }
  // cpLogicalOperator

}
// LogicalOperator