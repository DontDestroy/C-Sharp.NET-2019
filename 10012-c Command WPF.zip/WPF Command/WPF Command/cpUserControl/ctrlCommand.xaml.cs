﻿//***
// Action
//   - Having a command towards a database
//   - Interaction logic for ctrlCommand.xaml (part of MainWindow.xaml)
// Created
//   - CopyPaste – 20210809 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210809 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Controls;
using WPFCommand.ViewModel;

namespace WPFCommand.cpUserControl
{

  public partial class ctrlCommand : UserControl
  {

    #region "Constructors / Destructors"

    public ctrlCommand()
    //***
    // Action
    //   - Creating an instance of the WPF control
    //   - Initialize the components of that control
    //   - Define a cpCommandViewModel
    // Called by
    //   - User Action Or System action (Showing the control)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      InitializeComponent();
      _viewModel = (cpCommandViewModel)this.Resources["viewModel"];
    }
    // ctrlCommand()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private readonly cpCommandViewModel _viewModel;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdInsert_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Insert a product
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - int cpCommandViewModel.InsertProduct()
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.InsertProduct();
    }
    // cmdInsert_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdInsert.Click

    private void cmdInsertParameter_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Insert a product with parameters
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - int cpCommandViewModel.InsertProductUsingParameters()
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.InsertProductUsingParameters();
    }
    // cmdInsertParameter_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdInsertParameter.Click

    private void cmdOutputParameter_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Insert a product with parameters and return one parameter
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - int cpCommandViewModel.InsertProductOutputParameters()
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.InsertProductOutputParameters();
    }
    // cmdOutputParameter_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdOutputParameter.Click

    private void cmdScalar_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Count the products
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - int cpCommandViewModel.GetProductsCountScalar()
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.GetProductsCountScalar();
    }
    // cmdScalar_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdScalar.Click

    private void cmdScalarParameter_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Count the products with a parameter
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - int cpCommandViewModel.GetProductsCountScalarUsingParameters()
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.GetProductsCountScalarUsingParameters();
    }
    // cmdScalarParameter_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdScalarParameter.Click

    private void cmdTransaction_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Begin a Transaction, do something that fails, Rollback transaction
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - int cpCommandViewModel.InsertProductOutputParameters()
    // Created
    //   - CopyPaste – 20210809 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210809 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _viewModel.TransactionProcessing();
    }
    // cmdTransaction_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdTransaction.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // ctrlCommand 

}
// WPFCommand.cpUserControl