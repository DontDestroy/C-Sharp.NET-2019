﻿//***
// Action
//   - Implementation of a NullController
// Created
//   - CopyPaste – 20251030 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251030 – VVDW
// Proposal (To Do)
//   -
//***

using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpNullController : cpinfController
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ControlIt()
    //***
    // Action
    //   - Implementation of ControlIT
    //     - Do nothing
    //   - No action will be executed by the Controller
    // Called by
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    { 
    }
    // ControlIt()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpNullController

}
// cpKarelTheRobot