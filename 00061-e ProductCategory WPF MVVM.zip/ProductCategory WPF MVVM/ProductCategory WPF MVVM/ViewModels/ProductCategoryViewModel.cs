﻿//***
// Action
//   - StartupViewModel class (in ViewModels)
// Created
//   - CopyPaste – 20220824 – VVDW
// Changed
//   - CopyPaste – 20220907 – VVDW – Added Constructor, Fields and Properties
//   - CopyPaste – 20260404 – VVDW – Changed Constructor, Fields and Properties for Adding functionality
// Tested
//   - CopyPaste – 20260404 – VVDW
// Proposal (To Do)
//   -
//***

using ProductCategory_WPF_MVVM.Models;
using ProductCategory_WPF_MVVM.Services;
using ProductCategory_WPF_MVVM.Utilities;
using System.Collections.ObjectModel;
using System.Windows.Input;

namespace ProductCategory_WPF_MVVM.ViewModels
{

  public class ProductCategoryViewModel : ObservableObject
  {

    #region "Constructors / Destructors"

    public ProductCategoryViewModel(IDataService theDataService)
    //***
    // Action
    //   - Define the DataService that will be used
    //   - Fill the Product Category Collection with all the Product Categories
    //   - Add the product category functionality to the AddProductCategoryCommand
    //   - Add the product category functionality to the UpdateProductCategoryCommand
    //   - Add the product category functionality to the DeleteProductCategoryCommand
    // Called by
    //   - 
    // Calls
    //   - AddProductCategory()
    //   - BaseCommand(Action)
    //   - DeleteProductCategory()
    //   - IList<ProductCategory> IDataService.AllProductCategories (Get)
    //   - ProductCategoryCollection(ObservableCollection<ProductCategory>) (Set)
    //   - UpdateProductCategory()
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _dataService = theDataService;
      ProductCategoryCollection = new ObservableCollection<ProductCategory>(_dataService.AllProductCategories);
      AddProductCategoryCommand = new BaseCommand(AddProductCategory);
      UpdateProductCategoryCommand = new BaseCommand(UpdateProductCategory);
      DeleteProductCategoryCommand = new BaseCommand(DeleteProductCategory);
    }
    // ProductCategoryViewModel(IDataService)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private IDataService _dataService;
    private ObservableCollection<ProductCategory> _colProductCategory;
    private ProductCategory _selectedProductCategory;

    #endregion

    #region "Properties"

    public ICommand AddProductCategoryCommand { get; private set; }
    // ProductCategoryViewModel(IDataService)

    public ICommand DeleteProductCategoryCommand { get; private set; }
    // ProductCategoryViewModel(IDataService)

    public ObservableCollection<ProductCategory> ProductCategoryCollection
    {

      get
      //***
      // Action Get
      //   - Return _colProductCategory
      // Called by
      //   - ctrlProductCategory
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220907 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220907 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _colProductCategory;
      }
      // ObservableCollection<ProductCategory> ProductCategoryCollection (Get)

      set
      //***
      // Action Set
      //   - Sets _colProductCategory with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - ProductCategoryViewModel(IDataService)
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220907 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220907 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        OnPropertyChanged(ref _colProductCategory, value);
      }
      // ProductCategoryCollection(ObservableCollection<ProductCategory>) (Set)

    }
    // ObservableCollection<ProductCategory> ProductCategoryCollection

    public ProductCategory SelectedProductCategory
    {

      get
      //***
      // Action Get
      //   - Return _selectedProductCategory
      // Called by
      //   - AddProductCategory()
      //   - ctrlProductCategory
      //   - UpdateProductCategory()
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220907 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220907 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        return _selectedProductCategory;
      }
      // ProductCategory SelectedProductCategory (Get)

      set
      //***
      // Action Set
      //   - Sets _selectedProductCategory with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - 
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220907 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220907 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   -
      //***
      {
        OnPropertyChanged(ref _selectedProductCategory, value);
      }
      // SelectedProductCategory(ProductCategory) (Set)

    }
    // ProductCategory SelectedProductCategory

    public ICommand UpdateProductCategoryCommand { get; private set; }
    // ProductCategoryViewModel(IDataService)

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void AddProductCategory()
    //***
    // Action
    //   - Create a new instance of ProductCategory
    //   - If there is a selected product category
    //     - Information will be copied (later the key will be changed)
    //   - If not
    //     - Default information is added (later the key will be changed)
    //   - The collection of product categories is updated
    // Called by
    //   - ProductCategoryViewModel(IDataService)
    // Calls
    //   - IList<ProductCategory> IDataService.AddProductCategory(ProductCategory)
    //   - int ProductCategory.Key (Get)
    //   - ObservableCollection<ProductCategory> ProductCategoryCollection (Get)
    //   - ProductCategory SelectedProductCategory (Get)
    //   - ProductCategory()
    //   - ProductCategory.Key(int) (Set)
    //   - ProductCategory.Name(string) (Set)
    //   - ProductCategoryCollection(ObservableCollection<ProductCategory>) (Set)
    //   - SelectedProductCategory(ProductCategory) (Set)
    //   - string ProductCategory.Name (Get)
    // Created
    //   - CopyPaste – 20260404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260404 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      ProductCategory aNewProductCategory = new ProductCategory();

      if (SelectedProductCategory == null)
      {
        aNewProductCategory.Key = 1;
        aNewProductCategory.Name = "New Product Category";
      }
      else
      // SelectedProductCategory <> null
      {
        aNewProductCategory.Key = SelectedProductCategory.Key;
        aNewProductCategory.Name = SelectedProductCategory.Name;
      }
      // SelectedProductCategory == null

      ProductCategoryCollection = new ObservableCollection<ProductCategory>(_dataService.AddProductCategory(aNewProductCategory));
      SelectedProductCategory = ProductCategoryCollection[^1];
    }
    // AddProductCategory()

    private void DeleteProductCategory()
    //***
    // Action
    //   - Remove the instance of a ProductCategory
    //   - If there is a selected product category
    //     - Information will be removed
    //   - The collection of product categories is updated
    //   - The selected product category becomes the first of the list (if there is one)
    // Called by
    //   - ProductCategoryViewModel(IDataService)
    // Calls
    //   - IList<ProductCategory> IDataService.DeleteProductCategory(ProductCategory)
    //   - ObservableCollection<ProductCategory> ProductCategoryCollection (Get)
    //   - ProductCategory SelectedProductCategory (Get)
    //   - ProductCategoryCollection(ObservableCollection<ProductCategory>) (Set)
    //   - SelectedProductCategory(ProductCategory) (Set)
    // Created
    //   - CopyPaste – 20260404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260404 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      ProductCategoryCollection = new ObservableCollection<ProductCategory>(_dataService.DeleteProductCategory(SelectedProductCategory));

      if (ProductCategoryCollection.Count > 0)
      {
        SelectedProductCategory = ProductCategoryCollection[0];
      }
      // ProductCategoryCollection.Count > 0

    }
    // DeleteProductCategory()

    private void UpdateProductCategory()
    //***
    // Action
    //   - Change an instance of ProductCategory
    // Called by
    //   - ProductCategoryViewModel(IDataService)
    // Calls
    //   - IList<ProductCategory> IDataService.UpdateProductCategory(ProductCategory)
    //   - ProductCategory SelectedProductCategory (Get)
    // Created
    //   - CopyPaste – 20260404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260404 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      _dataService.UpdateProductCategory(SelectedProductCategory);
    }
    // UpdateProductCategory()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // ProductCategoryViewModel

}
// ProductCategory_WPF_MVVM.ViewModels