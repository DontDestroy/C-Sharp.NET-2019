//***
// Action
//   - Possible variable types
// Created
//   - CopyPaste � 20210825 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210825 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Proposal (To Do)
//   -
//***

using System;

namespace Variables
{

  class cpVariables
	{
    static bool blnMarried;
    static byte bytAsciiCode;
    static char chrMiddleInitial;
    static double dblCarLoan;
    static decimal decHomeLoan;
    static DateTime dtmBirthDate;
    static int intShoeSize;
    static long lngWeight;
    static object objSomething;
    static short shtAge;
    static float sngAnnualIncome;
    static string strAddress;

    static void Main()
    //***
    // Action
    //   - Set some variables with values
    //   - Show the variable contents
    // Called by
    //   - 
    // Calls
    //   - System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    //   - System.Console.WriteLine(string, System.Object)
    // Created
    //   - CopyPaste � 20210825 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210825 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      blnMarried = true;
      bytAsciiCode = 17;
      chrMiddleInitial = 'V';
      dblCarLoan = 23752.65;
      decHomeLoan = 137240.25M;
      dtmBirthDate = new DateTime(1970, 5, 6);
      intShoeSize = 42;
      lngWeight = 179;
      objSomething = "A nice message";
      shtAge = 50;
      sngAnnualIncome = 12345.67F;
      strAddress = "C. Ameyestraat";

      Console.WriteLine("THE VARIABLES PROGRAM");
      Console.WriteLine("---------------------");
      Console.WriteLine("The Boolean is {0}.", blnMarried);
      Console.WriteLine("The Byte is {0}.", bytAsciiCode);
      Console.WriteLine("The Char is {0}.", chrMiddleInitial);
      Console.WriteLine("The Double is {0}.", dblCarLoan);
      Console.WriteLine("The Decimal is {0}.", decHomeLoan);
      Console.WriteLine("The Date is {0}.", dtmBirthDate.Date);
      Console.WriteLine("The Integer is {0}.", intShoeSize);
      Console.WriteLine("The Long is {0}.", lngWeight);
      Console.WriteLine("The Object is {0}.", objSomething);
      Console.WriteLine("The Short is {0}.", shtAge);
      Console.WriteLine("The Single is {0}.", sngAnnualIncome);
      Console.WriteLine("The String is {0}.", strAddress);
      Console.WriteLine("");
      Console.WriteLine("Press Enter...");
      Console.ReadLine();
    }
    // Main()

  }
  // cpVariables

}
// Variables