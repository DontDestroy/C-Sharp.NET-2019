//***
// Action
//   - Having a list of brewers, show the correct information
//   - Go thru the records in the data set (brewers)
//   - Create, Read, Update and Delete a brewer
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBrewerTypedDatagridUpdate: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Panel panBottom;
    internal System.Windows.Forms.DataGrid dgrBrewerBeer;
    internal System.Windows.Forms.Panel panTop;
    internal System.Windows.Forms.Button cmdSave;
    private Code.dsData dsData;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBrewerTypedDatagridUpdate));
      this.panBottom = new System.Windows.Forms.Panel();
      this.dgrBrewerBeer = new System.Windows.Forms.DataGrid();
      this.dsData = new Code.dsData();
      this.panTop = new System.Windows.Forms.Panel();
      this.cmdSave = new System.Windows.Forms.Button();
      this.panBottom.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgrBrewerBeer)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.panTop.SuspendLayout();
      this.SuspendLayout();
      // 
      // panBottom
      // 
      this.panBottom.Controls.Add(this.dgrBrewerBeer);
      this.panBottom.Dock = System.Windows.Forms.DockStyle.Fill;
      this.panBottom.Location = new System.Drawing.Point(0, 56);
      this.panBottom.Name = "panBottom";
      this.panBottom.Size = new System.Drawing.Size(592, 413);
      this.panBottom.TabIndex = 4;
      // 
      // dgrBrewerBeer
      // 
      this.dgrBrewerBeer.AllowNavigation = false;
      this.dgrBrewerBeer.AlternatingBackColor = System.Drawing.Color.FromArgb(((System.Byte)(255)), ((System.Byte)(255)), ((System.Byte)(128)));
      this.dgrBrewerBeer.DataMember = "tblCPBrewer";
      this.dgrBrewerBeer.DataSource = this.dsData;
      this.dgrBrewerBeer.Dock = System.Windows.Forms.DockStyle.Fill;
      this.dgrBrewerBeer.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrBrewerBeer.Location = new System.Drawing.Point(0, 0);
      this.dgrBrewerBeer.Name = "dgrBrewerBeer";
      this.dgrBrewerBeer.Size = new System.Drawing.Size(592, 413);
      this.dgrBrewerBeer.TabIndex = 0;
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.Locale = new System.Globalization.CultureInfo("en-US");
      // 
      // panTop
      // 
      this.panTop.Controls.Add(this.cmdSave);
      this.panTop.Dock = System.Windows.Forms.DockStyle.Top;
      this.panTop.Location = new System.Drawing.Point(0, 0);
      this.panTop.Name = "panTop";
      this.panTop.Size = new System.Drawing.Size(592, 56);
      this.panTop.TabIndex = 3;
      // 
      // cmdSave
      // 
      this.cmdSave.Location = new System.Drawing.Point(16, 16);
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.TabIndex = 0;
      this.cmdSave.Text = "Save";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // frmBrewerTypedDatagridUpdate
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(592, 469);
      this.Controls.Add(this.panBottom);
      this.Controls.Add(this.panTop);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBrewerTypedDatagridUpdate";
      this.Text = "Beer Brewer Typed Datagrid Update";
      this.Load += new System.EventHandler(this.frmBrewerTypedDatagridUpdate_Load);
      this.panBottom.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgrBrewerBeer)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.panTop.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBrewerTypedDatagridUpdate'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBrewerTypedDatagridUpdate()
      //***
      // Action
      //   - Create instance of 'frmBrewerTypedDatagridUpdate'
      // Called by
      //   - frmMain.cmdBrewerDatagrid_Click(System.Object, System.EventArgs) Handles cmdBrewerDatagrid.Click
      //   - User action (Starting the form)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmBrewerTypedDatagridUpdate()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Save the complete changes in the dataset thru the data grid
      //   - If there are changes
      //     - Define a new instance of cpCommand
      //     - Set the cursor to wait
      //     - Try to
      //       - Update the brewer data set thru the instance of the command
      //     - On possible error
      //       - Show the exception information
      //     - Set the cursor to default
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking the button)
      // Calls
      //   - bool cpCommand.UpdateBrewer(dsData)
      //   - cpCommand()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (dsData.HasChanges())
      {
        cpCommand thecpCommand = new cpCommand();

        try
        {
          this.Cursor = Cursors.WaitCursor;
          thecpCommand.UpdateBrewer(dsData);
        }
        catch (Exception theException)
        {
          MessageBox.Show(theException.Message);
        }
        finally
        {
          this.Cursor = Cursors.Default;
        }
      
      }
      else
        // Not dsData.HasChanges
      {
      }
      // dsData.HasChanges
    
    }
    // cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click

    private void frmBrewerTypedDatagridUpdate_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Preparing the form to show correct information about brewers
      //   - Define an instance of cpCommand
      //   - Try to
      //     - Find the Brewers Beers Typed data set (Brewers is True, Beers is False)
      //     - Merge it into the data set
      //     - Show the correct buttons
      //   - On possible error
      //     - Show exception message
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCommand.FindBrewerBeersTypedDataSet([Boolean], [Boolean]) As dsData
      //   - cpCommand.New()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpCommand thecpCommand = new cpCommand();

      try
      {
        dsData.Merge(thecpCommand.FindBrewerBeersTypedDataSet(true, false));
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // frmBrewerTypedDatagridUpdate_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBrewerTypedDatagridUpdate

}
// CopyPaste.Learning