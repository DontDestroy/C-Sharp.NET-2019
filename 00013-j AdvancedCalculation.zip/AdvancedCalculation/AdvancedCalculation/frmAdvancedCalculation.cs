//***
// Action
//   - Basic calculations
// Created
//   - CopyPaste � 20240118 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240118 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmAdvancedCalculation: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.Label lblVariable2;
    internal System.Windows.Forms.Label lblVariable1;
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.Button cmdCalculate;
    internal System.Windows.Forms.TextBox txtResult;
    internal System.Windows.Forms.GroupBox grpOperator;
    internal System.Windows.Forms.RadioButton optConcatenate;
    internal System.Windows.Forms.RadioButton optRest;
    internal System.Windows.Forms.RadioButton optExponent;
    internal System.Windows.Forms.RadioButton optIntegerDivision;
    internal System.Windows.Forms.TextBox txtVariable1;
    internal System.Windows.Forms.TextBox txtVariable2;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmAdvancedCalculation));
      this.lblResult = new System.Windows.Forms.Label();
      this.lblVariable2 = new System.Windows.Forms.Label();
      this.lblVariable1 = new System.Windows.Forms.Label();
      this.cmdExit = new System.Windows.Forms.Button();
      this.cmdCalculate = new System.Windows.Forms.Button();
      this.txtResult = new System.Windows.Forms.TextBox();
      this.grpOperator = new System.Windows.Forms.GroupBox();
      this.optConcatenate = new System.Windows.Forms.RadioButton();
      this.optRest = new System.Windows.Forms.RadioButton();
      this.optExponent = new System.Windows.Forms.RadioButton();
      this.optIntegerDivision = new System.Windows.Forms.RadioButton();
      this.txtVariable1 = new System.Windows.Forms.TextBox();
      this.txtVariable2 = new System.Windows.Forms.TextBox();
      this.grpOperator.SuspendLayout();
      this.SuspendLayout();
      // 
      // lblResult
      // 
      this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblResult.Location = new System.Drawing.Point(296, 22);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(96, 16);
      this.lblResult.TabIndex = 14;
      this.lblResult.Text = "Result";
      // 
      // lblVariable2
      // 
      this.lblVariable2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblVariable2.Location = new System.Drawing.Point(16, 78);
      this.lblVariable2.Name = "lblVariable2";
      this.lblVariable2.Size = new System.Drawing.Size(88, 16);
      this.lblVariable2.TabIndex = 11;
      this.lblVariable2.Text = "Variable 2";
      // 
      // lblVariable1
      // 
      this.lblVariable1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblVariable1.Location = new System.Drawing.Point(16, 22);
      this.lblVariable1.Name = "lblVariable1";
      this.lblVariable1.Size = new System.Drawing.Size(88, 16);
      this.lblVariable1.TabIndex = 9;
      this.lblVariable1.Text = "Variable 1";
      // 
      // cmdExit
      // 
      this.cmdExit.Location = new System.Drawing.Point(312, 118);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.Size = new System.Drawing.Size(72, 24);
      this.cmdExit.TabIndex = 17;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // cmdCalculate
      // 
      this.cmdCalculate.Location = new System.Drawing.Point(312, 78);
      this.cmdCalculate.Name = "cmdCalculate";
      this.cmdCalculate.Size = new System.Drawing.Size(72, 24);
      this.cmdCalculate.TabIndex = 16;
      this.cmdCalculate.Text = "&Calculate";
      this.cmdCalculate.Click += new System.EventHandler(this.cmdCalculate_Click);
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(296, 38);
      this.txtResult.Name = "txtResult";
      this.txtResult.Size = new System.Drawing.Size(112, 20);
      this.txtResult.TabIndex = 15;
      this.txtResult.Text = "";
      // 
      // grpOperator
      // 
      this.grpOperator.Controls.Add(this.optConcatenate);
      this.grpOperator.Controls.Add(this.optRest);
      this.grpOperator.Controls.Add(this.optExponent);
      this.grpOperator.Controls.Add(this.optIntegerDivision);
      this.grpOperator.Location = new System.Drawing.Point(120, 30);
      this.grpOperator.Name = "grpOperator";
      this.grpOperator.Size = new System.Drawing.Size(168, 104);
      this.grpOperator.TabIndex = 13;
      this.grpOperator.TabStop = false;
      this.grpOperator.Text = "Operator";
      // 
      // optConcatenate
      // 
      this.optConcatenate.Location = new System.Drawing.Point(8, 72);
      this.optConcatenate.Name = "optConcatenate";
      this.optConcatenate.Size = new System.Drawing.Size(152, 16);
      this.optConcatenate.TabIndex = 3;
      this.optConcatenate.Text = "Text concatenate (&&)";
      // 
      // optRest
      // 
      this.optRest.Location = new System.Drawing.Point(8, 56);
      this.optRest.Name = "optRest";
      this.optRest.Size = new System.Drawing.Size(128, 16);
      this.optRest.TabIndex = 2;
      this.optRest.Text = "Rest in division (Mod)";
      // 
      // optExponent
      // 
      this.optExponent.Location = new System.Drawing.Point(8, 40);
      this.optExponent.Name = "optExponent";
      this.optExponent.Size = new System.Drawing.Size(144, 16);
      this.optExponent.TabIndex = 1;
      this.optExponent.Text = "Exponent - (Math.Pow)";
      // 
      // optIntegerDivision
      // 
      this.optIntegerDivision.Location = new System.Drawing.Point(8, 24);
      this.optIntegerDivision.Name = "optIntegerDivision";
      this.optIntegerDivision.Size = new System.Drawing.Size(112, 16);
      this.optIntegerDivision.TabIndex = 0;
      this.optIntegerDivision.Text = "Integer division (\\)";
      // 
      // txtVariable1
      // 
      this.txtVariable1.Location = new System.Drawing.Point(16, 38);
      this.txtVariable1.Name = "txtVariable1";
      this.txtVariable1.Size = new System.Drawing.Size(88, 20);
      this.txtVariable1.TabIndex = 10;
      this.txtVariable1.Text = "";
      // 
      // txtVariable2
      // 
      this.txtVariable2.Location = new System.Drawing.Point(16, 94);
      this.txtVariable2.Name = "txtVariable2";
      this.txtVariable2.Size = new System.Drawing.Size(88, 20);
      this.txtVariable2.TabIndex = 12;
      this.txtVariable2.Text = "";
      // 
      // frmAdvancedCalculation
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(416, 165);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.lblVariable2);
      this.Controls.Add(this.lblVariable1);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.cmdCalculate);
      this.Controls.Add(this.txtResult);
      this.Controls.Add(this.grpOperator);
      this.Controls.Add(this.txtVariable1);
      this.Controls.Add(this.txtVariable2);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmAdvancedCalculation";
      this.Text = "Test advanced calculation";
      this.grpOperator.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmAdvancedCalculation'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240118 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240118 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmAdvancedCalculation()
			//***
			// Action
			//   - Create instance of 'frmAdvancedCalculation'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240118 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240118 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmAdvancedCalculation()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

    int mlngFirstNumber;
    int mlngSecondNumber;

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"

    private void cmdCalculate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Read the two textboxes and place them into integer variables
      //   - Depending the check option
      //     - Do calculation and place ToString property into textbox
      //     - Concatenation is an exception
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - int System.Convert.ToInt32(string)
      // Created
      //   - CopyPaste � 20240118 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240118 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      double dblResult;
      string strResult;

      mlngFirstNumber = Convert.ToInt32(txtVariable1.Text);
      mlngSecondNumber = Convert.ToInt32(txtVariable2.Text);

      if (optIntegerDivision.Checked)
      {
        dblResult = mlngFirstNumber / mlngSecondNumber;
        txtResult.Text = dblResult.ToString();
      }
      else if (optExponent.Checked)
      {
        dblResult = Math.Pow(mlngFirstNumber, mlngSecondNumber);
        txtResult.Text = dblResult.ToString();
      }
      else if (optRest.Checked)
      {
        dblResult = mlngFirstNumber % mlngSecondNumber;
        txtResult.Text = dblResult.ToString();
      }
       else if (optConcatenate.Checked)
      {
        strResult = mlngFirstNumber.ToString() + mlngSecondNumber.ToString();
        txtResult.Text = strResult;
      }
      // What optionbutton is selected

    }
    // cmdCalculate_Click(System.Object, System.EventArgs ) Handles cmdCalculate.Click

    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop program
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240118 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240118 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit.Click

    #endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmAdvancedCalculation
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmAdvancedCalculation()
			// Created
			//   - CopyPaste � yyyymmdd � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � yyyymmdd � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmAdvancedCalculation());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmAdvancedCalculation

}
// CopyPaste.Learning