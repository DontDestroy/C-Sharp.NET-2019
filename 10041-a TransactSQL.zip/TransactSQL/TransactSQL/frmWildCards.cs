//***
// Action
//   - Show a result set of a SQL statement with wildcards and a date range
//   - Use Wildcards and Ranges of Values in a SQL Query
// Created
//   - CopyPaste � 20260114 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260114 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmWildCards: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.IContainer components;
    internal System.Windows.Forms.Label lblDateTo;
    internal System.Windows.Forms.TextBox txtDateTo;
    internal System.Windows.Forms.TextBox txtDateFrom;
    internal System.Windows.Forms.TextBox txtIdCustomer;
    internal System.Windows.Forms.Label lblDateFrom;
    internal System.Windows.Forms.Label lblCustomerKey;
    internal System.Windows.Forms.DataGrid dgrResult;
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.Label lblSQLString;
    internal System.Windows.Forms.Label lblSQLStatement;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmWildCards));
      this.lblDateTo = new System.Windows.Forms.Label();
      this.txtDateTo = new System.Windows.Forms.TextBox();
      this.txtDateFrom = new System.Windows.Forms.TextBox();
      this.txtIdCustomer = new System.Windows.Forms.TextBox();
      this.lblDateFrom = new System.Windows.Forms.Label();
      this.lblCustomerKey = new System.Windows.Forms.Label();
      this.dgrResult = new System.Windows.Forms.DataGrid();
      this.lblResult = new System.Windows.Forms.Label();
      this.lblSQLString = new System.Windows.Forms.Label();
      this.lblSQLStatement = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.dgrResult)).BeginInit();
      this.SuspendLayout();
      // 
      // lblDateTo
      // 
      this.lblDateTo.Location = new System.Drawing.Point(184, 30);
      this.lblDateTo.Name = "lblDateTo";
      this.lblDateTo.Size = new System.Drawing.Size(96, 16);
      this.lblDateTo.TabIndex = 14;
      this.lblDateTo.Text = "To";
      this.lblDateTo.TextAlign = System.Drawing.ContentAlignment.TopRight;
      // 
      // txtDateTo
      // 
      this.txtDateTo.Location = new System.Drawing.Point(288, 30);
      this.txtDateTo.Name = "txtDateTo";
      this.txtDateTo.TabIndex = 15;
      this.txtDateTo.Text = "12/01/2006";
      this.txtDateTo.TextChanged += new System.EventHandler(this.txtDateTo_TextChanged);
      // 
      // txtDateFrom
      // 
      this.txtDateFrom.Location = new System.Drawing.Point(288, 6);
      this.txtDateFrom.Name = "txtDateFrom";
      this.txtDateFrom.TabIndex = 13;
      this.txtDateFrom.Text = "11/01/2006";
      this.txtDateFrom.TextChanged += new System.EventHandler(this.txtDateFrom_TextChanged);
      // 
      // txtIdCustomer
      // 
      this.txtIdCustomer.Location = new System.Drawing.Point(104, 6);
      this.txtIdCustomer.Name = "txtIdCustomer";
      this.txtIdCustomer.Size = new System.Drawing.Size(64, 20);
      this.txtIdCustomer.TabIndex = 11;
      this.txtIdCustomer.Text = "A%";
      this.txtIdCustomer.TextChanged += new System.EventHandler(this.txtIdCustomer_TextChanged);
      // 
      // lblDateFrom
      // 
      this.lblDateFrom.Location = new System.Drawing.Point(184, 9);
      this.lblDateFrom.Name = "lblDateFrom";
      this.lblDateFrom.Size = new System.Drawing.Size(96, 16);
      this.lblDateFrom.TabIndex = 12;
      this.lblDateFrom.Text = "Order Date: From";
      this.lblDateFrom.TextAlign = System.Drawing.ContentAlignment.TopRight;
      // 
      // lblCustomerKey
      // 
      this.lblCustomerKey.Location = new System.Drawing.Point(16, 9);
      this.lblCustomerKey.Name = "lblCustomerKey";
      this.lblCustomerKey.Size = new System.Drawing.Size(88, 16);
      this.lblCustomerKey.TabIndex = 10;
      this.lblCustomerKey.Text = "Customer Key";
      // 
      // dgrResult
      // 
      this.dgrResult.AlternatingBackColor = System.Drawing.Color.Silver;
      this.dgrResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrResult.BackColor = System.Drawing.Color.White;
      this.dgrResult.CaptionBackColor = System.Drawing.Color.Maroon;
      this.dgrResult.CaptionFont = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.CaptionForeColor = System.Drawing.Color.White;
      this.dgrResult.DataMember = "";
      this.dgrResult.Font = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.ForeColor = System.Drawing.Color.Black;
      this.dgrResult.GridLineColor = System.Drawing.Color.Silver;
      this.dgrResult.HeaderBackColor = System.Drawing.Color.Silver;
      this.dgrResult.HeaderFont = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.HeaderForeColor = System.Drawing.Color.Black;
      this.dgrResult.LinkColor = System.Drawing.Color.Maroon;
      this.dgrResult.Location = new System.Drawing.Point(16, 190);
      this.dgrResult.Name = "dgrResult";
      this.dgrResult.ParentRowsBackColor = System.Drawing.Color.Silver;
      this.dgrResult.ParentRowsForeColor = System.Drawing.Color.Black;
      this.dgrResult.PreferredColumnWidth = 110;
      this.dgrResult.SelectionBackColor = System.Drawing.Color.Maroon;
      this.dgrResult.SelectionForeColor = System.Drawing.Color.White;
      this.dgrResult.Size = new System.Drawing.Size(464, 144);
      this.dgrResult.TabIndex = 19;
      // 
      // lblResult
      // 
      this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblResult.Location = new System.Drawing.Point(16, 166);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(96, 16);
      this.lblResult.TabIndex = 18;
      this.lblResult.Text = "Results";
      // 
      // lblSQLString
      // 
      this.lblSQLString.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblSQLString.Location = new System.Drawing.Point(16, 78);
      this.lblSQLString.Name = "lblSQLString";
      this.lblSQLString.Size = new System.Drawing.Size(464, 80);
      this.lblSQLString.TabIndex = 17;
      // 
      // lblSQLStatement
      // 
      this.lblSQLStatement.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblSQLStatement.Location = new System.Drawing.Point(16, 54);
      this.lblSQLStatement.Name = "lblSQLStatement";
      this.lblSQLStatement.Size = new System.Drawing.Size(168, 16);
      this.lblSQLStatement.TabIndex = 16;
      this.lblSQLStatement.Text = "SQL Statement";
      // 
      // frmWildCards
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(488, 341);
      this.Controls.Add(this.lblDateTo);
      this.Controls.Add(this.txtDateTo);
      this.Controls.Add(this.txtDateFrom);
      this.Controls.Add(this.txtIdCustomer);
      this.Controls.Add(this.lblDateFrom);
      this.Controls.Add(this.lblCustomerKey);
      this.Controls.Add(this.dgrResult);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.lblSQLString);
      this.Controls.Add(this.lblSQLStatement);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmWildCards";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Use Wildcards and Ranges of Values in a SQL Query";
      this.Load += new System.EventHandler(this.frmWildCards_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrResult)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmWildCards'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmWildCards()
      //***
      // Action
      //   - Create instance of 'frmWildCards'
      // Called by
      //   - frmMain.cmdWildcards_Click(System.Object, System.EventArgs) Handles cmdWildcards.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmWildCards()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void txtDateFrom_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The date from textbox is changed
      // Called by
      //   - User action (Changing a textbox)
      // Calls
      //   - GenerateData()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      GenerateData();
    }
    // txtDateFrom_TextChanged(System.Object, System.EventArgs) Handles txtDateFrom.TextChanged
    
    private void txtDateTo_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The date to textbox is changed
      // Called by
      //   - User action (Changing a textbox)
      // Calls
      //   - GenerateData()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      GenerateData();
    }
    // txtDateTo_TextChanged(System.Object, System.EventArgs) Handles txtDateTo.TextChanged

    private void txtIdCustomer_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The key customer textbox is changed
      // Called by
      //   - User action (Changing a textbox)
      // Calls
      //   - GenerateData()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      GenerateData();
    }
    // txtIdCustomer_TextChanged(System.Object, System.EventArgs) Handles txtIdCustomer.TextChanged

    private void frmWildCards_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the data with the default wildcards and date range
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - GenerateData()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      GenerateData();
    }
    // frmWildcards_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void GenerateData()
      //***
      // Action
      //   - Define a data adapter
      //   - Define and create a data table
      //   - Define and set a SQL statement (using the values of the form)
      //   - Create the data adapter using the SQL statement and the connection
      //   - Try to
      //     - Fill the data table using the data adapter
      //     - Set the data table as data source for the data grid
      //   - When an error occurs
      //     - Show the exception message
      // Called by
      //   - frmWildcards_Load(System.Object, System.EventArgs) Handles this.Load
      //   - txtDateFrom_TextChanged(System.Object, System.EventArgs) Handles txtDateFrom.TextChanged
      //   - txtDateTo_TextChanged(System.Object, System.EventArgs) Handles txtDateTo.TextChanged
      //   - txtIdCustomer_TextChanged(System.Object, System.EventArgs) Handles txtIdCustomer.TextChanged
      // Calls
      //   - cpGeneralRoutines()
      //   - SqlClient.SqlConnection cpGeneralRoutines.GetConnection()
      //   - string cpGeneralRoutines.BuildConnectionString()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpGeneralRoutines theRoutines = new cpGeneralRoutines();
      DataTable dtResult = new DataTable();
      SqlDataAdapter dtaResult;
      string strSQLStatement;

      strSQLStatement = "SELECT tblCPCustomer.strCompanyName, tblCPOrder.intIdOrder, tblCPOrder.dtmOrderDate " +
        "FROM tblCPOrder INNER JOIN tblCPCustomer " +
        "ON tblCPOrder.strCustomerId = tblCPCustomer.strIdCustomer" + Environment.NewLine +
        "WHERE tblCPCustomer.strIdCustomer LIKE '" + txtIdCustomer.Text + "' AND " +
        "tblCPOrder.dtmOrderDate Between '" + txtDateFrom.Text +
        "' AND '" + txtDateTo.Text + "'";
      lblSQLString.Text = strSQLStatement;

      dtaResult = new SqlDataAdapter(strSQLStatement, theRoutines.GetConnection());
      // dtaResult = new SqlDataAdapter(strSQLStatement, theRoutines.BuildConnectionString());

      try
      {
        dtaResult.Fill(dtResult);
        dgrResult.DataSource = dtResult;
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }

    }
    // GenerateData()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmWildCards

}
// CopyPaste.Learning