﻿//***
// Action
//   - An example of working with Tuples
// Created
//   - CopyPaste – 20251130 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251130 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpTupleNamedItems
  {

    #region "Constructors / Destructors"

    public cpTupleNamedItems()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.TupleWithItems()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251130 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpTuple()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public (string GuitarType, int GuitarStringCount) GetGuitarType()
    //***
    // Action
    //   - Return a tuple (string, int)
    //     - The type / brand of the Guitar
    //     - The number of strings of the Guitar
    // Called by
    //   - cpProgram.TupleWithItems()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251130 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return ("Bass Guitar", 4);
    }
    // (string, int) GetGuitarType()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpTupleNamedItems

}
// CopyPaste.Learning