//***
// Action
//   - Using a Xor operator to encrypt and decrypt text
// Created
//   - CopyPaste � 20240506 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240506 � VVDW
// Proposal (To Do)
//   - 
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSecret: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.MenuItem mnuFileClose;
    internal System.Windows.Forms.OpenFileDialog dlgFileOpen;
    internal System.Windows.Forms.TextBox txtNote;
    internal System.Windows.Forms.MenuItem mnuFileInsertDate;
    internal System.Windows.Forms.MenuItem mnuFileExit;
    internal System.Windows.Forms.SaveFileDialog dlgFileSave;
    internal System.Windows.Forms.MenuItem mnuFile;
    internal System.Windows.Forms.MenuItem mnuFileOpen;
    internal System.Windows.Forms.MenuItem mnuFileSaveAs;
    internal System.Windows.Forms.MainMenu mnuXorEncryption;
    internal System.Windows.Forms.Label lblNote;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSecret));
      this.mnuFileClose = new System.Windows.Forms.MenuItem();
      this.dlgFileOpen = new System.Windows.Forms.OpenFileDialog();
      this.txtNote = new System.Windows.Forms.TextBox();
      this.mnuFileInsertDate = new System.Windows.Forms.MenuItem();
      this.mnuFileExit = new System.Windows.Forms.MenuItem();
      this.dlgFileSave = new System.Windows.Forms.SaveFileDialog();
      this.mnuFile = new System.Windows.Forms.MenuItem();
      this.mnuFileOpen = new System.Windows.Forms.MenuItem();
      this.mnuFileSaveAs = new System.Windows.Forms.MenuItem();
      this.mnuXorEncryption = new System.Windows.Forms.MainMenu();
      this.lblNote = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // mnuFileClose
      // 
      this.mnuFileClose.Enabled = false;
      this.mnuFileClose.Index = 1;
      this.mnuFileClose.Text = "&Close";
      this.mnuFileClose.Click += new System.EventHandler(this.mnuFileClose_Click);
      // 
      // txtNote
      // 
      this.txtNote.Location = new System.Drawing.Point(16, 48);
      this.txtNote.Multiline = true;
      this.txtNote.Name = "txtNote";
      this.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtNote.Size = new System.Drawing.Size(360, 184);
      this.txtNote.TabIndex = 3;
      this.txtNote.Text = "";
      // 
      // mnuFileInsertDate
      // 
      this.mnuFileInsertDate.Index = 3;
      this.mnuFileInsertDate.Text = "&Insert date";
      this.mnuFileInsertDate.Click += new System.EventHandler(this.mnuFileInsertDate_Click);
      // 
      // mnuFileExit
      // 
      this.mnuFileExit.Index = 4;
      this.mnuFileExit.Text = "&Exit";
      this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
      // 
      // dlgFileSave
      // 
      this.dlgFileSave.FileName = "doc1";
      // 
      // mnuFile
      // 
      this.mnuFile.Index = 0;
      this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFileOpen,
                                                                            this.mnuFileClose,
                                                                            this.mnuFileSaveAs,
                                                                            this.mnuFileInsertDate,
                                                                            this.mnuFileExit});
      this.mnuFile.Text = "&File";
      // 
      // mnuFileOpen
      // 
      this.mnuFileOpen.Index = 0;
      this.mnuFileOpen.Text = "&Open secret text...";
      this.mnuFileOpen.Click += new System.EventHandler(this.mnuFileOpen_Click);
      // 
      // mnuFileSaveAs
      // 
      this.mnuFileSaveAs.Index = 2;
      this.mnuFileSaveAs.Text = "Secret text &save as...";
      this.mnuFileSaveAs.Click += new System.EventHandler(this.mnuFileSaveAs_Click);
      // 
      // mnuXorEncryption
      // 
      this.mnuXorEncryption.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                     this.mnuFile});
      // 
      // lblNote
      // 
      this.lblNote.Location = new System.Drawing.Point(16, 8);
      this.lblNote.Name = "lblNote";
      this.lblNote.Size = new System.Drawing.Size(344, 24);
      this.lblNote.TabIndex = 2;
      this.lblNote.Text = "Type your text and create a secret text.";
      // 
      // frmSecret
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(392, 277);
      this.Controls.Add(this.txtNote);
      this.Controls.Add(this.lblNote);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mnuXorEncryption;
      this.Name = "frmSecret";
      this.Text = "XorSecret";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSecret'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSecret()
      //***
      // Action
      //   - Create instance of 'frmSecret'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSecret()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void mnuFileClose_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set application back to starting position
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtNote.Text = "";
      lblNote.Text = "Type your text and create a secret text.";
      mnuFileClose.Enabled = false;
      mnuFileOpen.Enabled = true;    
    }
    // mnuFileClose_Click(System.Object, System.EventArgs) Handles mnuFileClose.Click

    private void mnuFileExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop the application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // mnuFileExit_Click(System.Object, System.EventArgs) Handles mnuFileExit.Click

    private void mnuFileInsertDate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The current date is added in front of the text
      //   - Cursor is placed at the start
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtNote.Text = DateTime.Now.ToString("dd/MM/yyyy") + Environment.NewLine + txtNote.Text;
      txtNote.Select(0, 0);
    }
    // mnuFileInsertDate_Click(System.Object, System.EventArgs) Handles mnuFileInsertDate.Click

    private void mnuFileOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Open a textfile
      //   - Initialize a file open dialog
      //     - Filter is textfile
      //     - Folder is current directory
      //   - Show the dialog
      //   - If there is no file name
      //     - Do nothing
      //   - If not
      //     - Try to
      //       - Ask an encryption code
      //       - If there is no code
      //         - Action stops
      //       - If not
      //         - Nothing happens
      //       - Open a textfile
      //       - Decrypt every character with the encryption code
      //       - Show the decrypted text
      //       - Show the filename
      //       - Set cursor at the start of the text
      //       - Enable the text
      //       - Enable File Close
      //       - Disable File Open
      //     - On error show error message
      //     - Close file
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      char chrChar;
      short shtCode;
      short shtNumber;
      StreamReader strReader = null;
      string strCode;
      string strDecrypt = "";

      dlgFileOpen.Filter = "Text files (*.TXT)|*.TXT";
      dlgFileOpen.InitialDirectory = Environment.CurrentDirectory;
      dlgFileOpen.ShowDialog();

      if (dlgFileOpen.FileName == "")
      {
      }
      else
        // dlgFileOpen.FileName <> ""
      {
        
        try
        {
          strCode = Interaction.InputBox("Enter Encryption Code", "Copy Paste", "", 0, 0);
          
          if (strCode == "")
          {
          }
          else
            // strCode <> ""
          {
            shtCode = Convert.ToInt16(strCode);
            strReader = new StreamReader(dlgFileOpen.FileName);

            while (strReader.Peek() > 0)
            {
              shtNumber = Convert.ToInt16(strReader.ReadLine());
              chrChar = (char)(shtNumber ^ shtCode);
              strDecrypt += chrChar;
            }
            // strReader.Peek() = 0
            
            txtNote.Text = strDecrypt;
            lblNote.Text = dlgFileOpen.FileName;
            txtNote.Select(0, 0);
            txtNote.Enabled = true;
            mnuFileClose.Enabled = true;
            mnuFileOpen.Enabled = false;
          }
          // strCode = ""

        }
        catch
        {
          MessageBox.Show("There was an error trying to open a file");
        }
        finally
        {
          strReader.Close();
        }
        
      }
      // dlgFileOpen.FileName = ""
    
    }
    // mnuFileOpen_Click(System.Object, System.EventArgs) Handles mnuFileOpen.Click

    private void mnuFileSaveAs_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Open a textfile
      //   - Initialize a file save dialog
      //     - Filter is textfile
      //     - Folder is current directory
      //   - Show the dialog
      //   - If there is no file name
      //     - Do nothing
      //   - If not
      //     - Ask an encryption code
      //     - If there is no code
      //       - Action stops
      //     - If not
      //       - Nothing happens
      //     - Open a textfile
      //     - Decrypt every character with the encryption code
      //     - Close file
      //     - Enable File Close
      //     - Disable File Open
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      byte[] arrByte;
      int lngCharactersInFile;
      int lngCounter;
      short shtCode;
      StreamWriter strWriter = null;
      string strCode;
      string strLetter;

      dlgFileSave.Filter = "Text files (*.txt)|*.txt";
      dlgFileSave.InitialDirectory = Environment.CurrentDirectory;
      dlgFileSave.ShowDialog();

      if (dlgFileSave.FileName == "")
      {
      }
      else
        // dlgFileSave.FileName <> ""
      {
        strCode = Interaction.InputBox("Type the code", "Copy Paste", "", 0, 0);

        if (strCode == "")
        {
        }
        else
          // strCode <> ""
        {
        }
        // strCode = ""

        shtCode = Convert.ToInt16(strCode);
        lngCharactersInFile = txtNote.Text.Length;
        strWriter = new StreamWriter(dlgFileSave.FileName);

        for (lngCounter = 0; lngCounter < lngCharactersInFile; lngCounter++)
        {
          strLetter = txtNote.Text.Substring(lngCounter, 1);
          arrByte = Encoding.ASCII.GetBytes(strLetter);
          strWriter.WriteLine(arrByte[0] ^ shtCode);
        }
        // lngCounter = lngCharactersInFile 

        strWriter.Close();
        mnuFileClose.Enabled = true;
        mnuFileOpen.Enabled = false;
      }
      // dlgFileSave.FileName = ""
    
    }
    // mnuFileSaveAs_Click(System.Object, System.EventArgs) Handles mnuFileSaveAs.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSecret
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSecret()
      // Created
      //   - CopyPaste � 20240506 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240506 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSecret());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSecret

}
// CopyPaste.Learning