//***
// Action
//   - Reading and writing a text in several ways
// Created
//   - CopyPaste � 20220527 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20220527 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace ReadWrite
{

  public class frmReadWrite : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    internal System.Windows.Forms.TextBox txtText;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmReadWrite));
      this.txtText = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(8, 8);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(392, 352);
      this.txtText.TabIndex = 1;
      this.txtText.Text = "";
      // 
      // frmReadWrite
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(408, 365);
      this.Controls.Add(this.txtText);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmReadWrite";
      this.Text = "ReadWrite";
      this.Load += new System.EventHandler(this.frmReadWrite_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmReadWrite'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmReadWrite()
      //***
      // Action
      //   - Create instance of 'frmReadWrite'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmReadWrite()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmReadWrite_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Show the form
    //   - Set the font of txtText
    //   - Write and read textfile with IO
    //   - Write and read textfile with streams (put in comment)
    // Called by
    //   - User action (starting the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220527 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20220527 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.Show();
      txtText.Font = new Font("Times New Roman", 12);
      // TestFileIO();
      TestStreams();
    }
    // frmReadWrite_Load(System.Object, System.EventArgs) Handles this.Load
  
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Start application
      //   - Showing frmDefault
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmReadWrite());
    }
    // Main() 

    private void TestFileIO()
      //***
      // Action
      //   - Set a filename (strFileName)
      //   - Determine the first free file number (lngFileNumber)
      //   - Open the file for Output and Write
      //   - Write several lines
      //   - Close the file
      //   - Determine the first free file number (lngFileNumber)
      //   - Open the file for Input and Read
      //   - Loop until end of file
      //     - strInputLine become the next line
      //     - strInputText is concatenated with strInputLine
      //   - Close the file
      //   - Show the text on the screen
      //   - Set cursor before first position
      // Called by
      //   - frmReadWrite_Load(System.Object, System.EventArgs) Handles MyBase.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220527 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      int lngFileNumber;
      string strFileName;
      string strInputLine;
      string strInputText = "";

      strFileName = Directory.GetCurrentDirectory() + "\\ReadWrite.txt";
      lngFileNumber = FileSystem.FreeFile();
      FileSystem.FileOpen(lngFileNumber, strFileName, OpenMode.Output, OpenAccess.Write, OpenShare.Shared, 100);
      
      FileSystem.WriteLine(lngFileNumber, "Once upon a time, a girl by the name of Danielle");
      FileSystem.WriteLine(lngFileNumber, "loved to read Utopia. Her evil stepmother treated");
      FileSystem.WriteLine(lngFileNumber, "her badly. But then the crowned prince of France");
      FileSystem.WriteLine(lngFileNumber, "fell in love with Danielle, and they were married.");
      FileSystem.WriteLine(lngFileNumber, "Her evil stepmother, meanwhile, was put to work.");
      
      FileSystem.FileClose(lngFileNumber);

      lngFileNumber = FileSystem.FreeFile();
      FileSystem.FileOpen(lngFileNumber, strFileName, OpenMode.Input, OpenAccess.Read, OpenShare.Shared, 100);
      
      while (!FileSystem.EOF(lngFileNumber))
      {
        strInputLine = FileSystem.LineInput(lngFileNumber);
        strInputText += strInputLine.Substring(1, strInputLine.Length - 2) + ControlChars.NewLine;
      }

      // FileSystem.EOF(lngFileNumber)
      
      FileSystem.FileClose(lngFileNumber);

      txtText.Text = "Testing File I/O..." + ControlChars.NewLine;
      txtText.Text += "-------------------" + ControlChars.NewLine;
      txtText.Text += strInputText;
    }
    // TestFileIO()

    private void TestStreams()
      // Action
      //   - Set a filename (strFileName)
      //   - strWriter becomes a StreamWriter
      //   - Write several lines
      //   - Close the StreamWriter
      //   - strReader becomes a StreamReader
      //   - Read the complete text
      //   - Show the text on the screen
      //   - Close the file
      //   - Set cursor before first position
      // Called by
      //   - frmReadWrite_Load(System.Object, System.EventArgs) Handles MyBase.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220527 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20220527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      string strFileName;
      string strInputText;
      StreamReader strReader;
      StreamWriter strWriter;
      
      strFileName = Directory.GetCurrentDirectory() + "\\ReadWrite.txt";

      strWriter = new StreamWriter(strFileName);
      strWriter.WriteLine("Once upon a time, a girl by the name of Danielle");
      strWriter.WriteLine("loved to read Utopia. Her evil stepmother treated");
      strWriter.WriteLine("her badly. But then the crowned prince of France");
      strWriter.WriteLine("fell in love with Danielle, and they were married.");
      strWriter.WriteLine("Her evil stepmother, meanwhile, was put to work.");
      
      strWriter.Close();
      
      strReader = new StreamReader(strFileName);
      strInputText = strReader.ReadToEnd();
      txtText.Text += "Testing Streams..." + ControlChars.NewLine;
      txtText.Text += "------------------" + ControlChars.NewLine;
      txtText.Text += strInputText;
    }

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmReadWrite

}
// ReadWrite