﻿//***
// Action
//   - Create an implementation of ILoggerProvider
// Created
//   - CopyPaste – 20230403 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230403 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using Microsoft.Extensions.Logging;

namespace LogDatabaseActionsEntityFrameWorkCore
{
  public class cpLoggerProvider : ILoggerProvider
  {

    #region "Constructors / Destructors"

    public cpLoggerProvider(List<string> colLogs)
    //***
    // Action
    //   - Create an instance of 'cpLoggerProvider'
    // Called by
    //   - cpProgram.SwitchOnLogging(bool, cpApplicationDatabaseContext, List<string>)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20230403 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230403 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      _colLogs = colLogs;
    }
    // cpLoggerProvider(List<string>)

    public void Dispose()
    {
    }
    // Dispose()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private readonly List<string> _colLogs;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public ILogger CreateLogger(string strCategoryName)
    //***
    // Action
    //   - Create a cpLogger
    //   - strCategoryName is not used
    // Called by
    //   - string ReadTestData(cpApplicationDatabaseContext, bool = False)
    //   - string UpdateTestData(cpApplicationDatabaseContext, bool = False)
    // Calls
    //   - cpLogger(List<string>)
    // Created
    //   - CopyPaste – 20230403 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230403 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return new cpLogger(_colLogs);
    }
    // ILogger CreateLogger(strCategoryName)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpLoggerProvider

}
// LogDatabaseActionsEntityFrameWorkCore