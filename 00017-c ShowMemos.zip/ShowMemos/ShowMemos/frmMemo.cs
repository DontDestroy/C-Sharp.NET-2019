//***
// Action
//   - Load a textfile into a textbox
// Created
//   - CopyPaste � 20240229 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240229 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMemo: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdLoad;
    internal System.Windows.Forms.TextBox txtResult;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMemo));
      this.cmdLoad = new System.Windows.Forms.Button();
      this.txtResult = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdLoad
      // 
      this.cmdLoad.Location = new System.Drawing.Point(128, 296);
      this.cmdLoad.Name = "cmdLoad";
      this.cmdLoad.Size = new System.Drawing.Size(80, 23);
      this.cmdLoad.TabIndex = 3;
      this.cmdLoad.Text = "Load Memos";
      this.cmdLoad.Click += new System.EventHandler(this.cmdLoad_Click);
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(24, 24);
      this.txtResult.Multiline = true;
      this.txtResult.Name = "txtResult";
      this.txtResult.ReadOnly = true;
      this.txtResult.Size = new System.Drawing.Size(288, 248);
      this.txtResult.TabIndex = 2;
      this.txtResult.Text = "";
      // 
      // frmMemo
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(336, 349);
      this.Controls.Add(this.cmdLoad);
      this.Controls.Add(this.txtResult);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMemo";
      this.Text = "Memo";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMemo'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240229 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240229 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMemo()
      //***
      // Action
      //   - Create instance of 'frmMemo'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240229 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240229 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdLoad_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a StreamReader
      //   - Try to open the file "C:\Memos.txt"
      //     - When it fails show a messsagebox
      //   - Try to
      //     - Read the text and put it in the textbox
      //     - Close the file
      //     - When it fails show a messagebox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240229 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240229 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      StreamReader strReader = null;

      try
      {
        strReader = new StreamReader("C:\\Memos.txt");
      }
      catch
      {
        MessageBox.Show("Error opening " + "C:\\Memos.txt");
      }
      
      try
      {
        txtResult.Text = strReader.ReadToEnd();
        strReader.Close();
      }
      catch
      {
        MessageBox.Show("Error reading file");
      }
    
    }
    // cmdLoad_Click(System.Object, System.EventArgs) Handles cmdLoad.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMemo
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240229 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240229 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMemo());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMemo

}
// CopyPaste.Learning