//***
// Action
//   - Demo of the use of System.Drawing (basic functionality)
// Created
//   - CopyPaste � 20240521 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240521 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmShapes: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmShapes));
      // 
      // frmShapes
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(416, 293);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmShapes";
      this.Text = "Shapes";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.frmShapes_Paint);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmShapes'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240521 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240521 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmShapes()
      //***
      // Action
      //   - Create instance of 'frmShapes'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240521 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240521 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmShapes()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmShapes_Paint(System.Object theSender, System.Windows.Forms.PaintEventArgs thePaintEventArguments)
      //***
      // Action
      //   - Define a brushcolor
      //   - Define a Graphics
      //   - Define a pencolor
      //   - Start creating some graphics inside the form
      //   - Draw a line
      //   - Draw an Ellips
      //   - Draw a filled rectangle
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240521 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240521 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      SolidBrush BrushColor = new SolidBrush(Color.Cyan);
      Graphics GraphicsFun;
      Pen PenColor = new Pen(Color.Blue);

      GraphicsFun = this.CreateGraphics();

      GraphicsFun.DrawLine(PenColor, 20, 30, 100, 80);
      GraphicsFun.DrawEllipse(PenColor, 10, 120, 200, 160);
      GraphicsFun.FillRectangle(BrushColor, 150, 10, 250, 100);
    }
    // frmShapes_Paint(System.Object, System.Windows.Forms.PaintEventArgs)

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmShapes
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmShapes()
      // Created
      //   - CopyPaste � 20240521 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240521 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmShapes());
    }
    // Main() 
    
    #endregion
    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmShapes

}
// CopyPaste.Learning