//***
// Action
//   - Implementation of a cpOfficeWorker
//   - Inherits from cpEmployee
// Created
//   - CopyPaste � 20240405 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240405 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpOfficeWorker : cpEmployee
  {

    #region "Constructors / Destructors"

    public cpOfficeWorker(string strName) : base(strName)
      //***
      // Action
      //   - Constructor with Name
      // Called by
      //   - cpProgram.Main()
      //   - cpManager(string)
      // Calls
      //   - cpEmployee(string)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpOfficeWorker(string)
 
    public cpOfficeWorker(string strName, string strDepartment ) : base(strName, strDepartment)
      //***
      // Action
      //   - Constructor with Name and Department
      // Called by
      //   - cpProgram.Main()
      //   - cpManager(string, string)
      // Calls
      //   - cpEmployee(string, string)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpOfficeWorker(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override void ShowInfo()
      //***
      // Action
      //   - Shows information to the console
      //     - OfficeWorker + Name
      //     - Department
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - string cpEmployee.Department (Get)
      //   - string cpEmployee.Name (Get)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Officeworker - Name: {0}", Name);
      Console.WriteLine("Department: {0}", Department);
    }
    // ShowInfo()

    public override string ToString()
      //***
      // Action
      //   - Returns the Name (Department) and that the person is an officeworker
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - string cpEmployee.Department (Get)
      //   - string cpEmployee.Name (Get)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Name + "(" + Department + ") is an officeworker.";
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpOfficeWorker

}
// CopyPaste.Learning.Employee