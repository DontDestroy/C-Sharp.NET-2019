﻿//***
// Action
//   - A process that takes some time for testing multithreading
//   - Sieve of Eratosthenes
//     - Finding prime numbers (between a from and a to value)
// Created
//   - CopyPaste – 20220818 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220818 – VVDW
// Proposal (To Do)
//   - Not optimised, because it is not needed in this test routine of multithreading
//***

using System;

namespace Multithreading
{

  public class cpSieveOfEratosthenes
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static uint[] FindPrimes(uint intFromNumber, uint intToNumber)
    //***
    // Action
    //   - Find primes between 2 values
    //   - Calls the same routine, but within a background worker
    //   - Returns an array of prime numbers
    // Called by
    //   - 
    // Calls
    //   - uint[] FindPrimes(uint, uint, System.ComponentModel.BackgroundWorker)
    // Created
    //   - CopyPaste – 20220818 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return FindPrimes(intFromNumber, intToNumber, null);
    }
    // uint[] FindPrimes(uint, uint)

    public static uint[] FindPrimes(uint intFromNumber, uint intToNumber, System.ComponentModel.BackgroundWorker theBackgroundWorker)
    //***
    // Action
    //   - Find primes between 2 values inside a background worker
    //     - From included, To excluded
    //   - Create an array of the needed numbers (intToNumber - intFromNumber)
    //   - Filling that array with integers between the two specified numbers
    //   - Find the modulo for each item in list, divided by each divisor (marked with 1), where divisor is smaller or equal to sqrt(intToNumber)
    //     - If the remainder is 0, the number is a composite, and thus not a prime
    //       - This position is marked with 0
    //     - If the remainder is 0, it is prime, and this position will be marked with 1
    //   - During the process, the progressbar is maintained and checked if cancel is pressed
    //   - Create an array that contains only the primes
    //   - Returns an array of prime numbers
    // Called by
    //   - uint[] FindPrimes(uint, uint)
    //   - wpfBackGroundWorkerDemo.backgroundWorkerDemo_DoWork(System.Object, System.ComponentModel.DoWorkEventArgs) Handles backgroundWorkerDemo.DoWork
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220818 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - Optimize this routine
    //   - The progressbar and cancel does not work when you have a very large list of numbers to check
    //   - Every 1/100 time of the process, it is checked if you have cancelled the process
    //   - This can be made more elegant, but is not done here, because the demo can be shown
    //***
    {
      uint[] arrintList = new uint[intToNumber - intFromNumber];
      uint[] arrintPrime;
      uint[] arrintMark = new uint[arrintList.Length];

      for (uint intCounter = (uint)intFromNumber; intCounter < intToNumber; intCounter++)
      {
        arrintList[intCounter - intFromNumber] = intCounter;
      }
      // intCounter = intToNumber

      uint intMaxDivisor = (uint)Math.Floor(Math.Sqrt(intToNumber));

      if (arrintList[0] == 0 || arrintList[0] == 1)
      {
        arrintMark[0] = 1;
      }
      else
      // arrintList[0] <>= 0 && arrintList[0] <> 1
      {
      }
      // arrintList[0] == 0 || arrintList[0] == 1

      if (arrintList[1] == 1)
      {
        arrintMark[1] = 1;
      }
      else
      // arrintList[1] <> 1
      {
      }
      // arrintList[1] == 1

      for (uint intCounter = 0; intCounter < arrintList.Length; intCounter++)
      {
        
        for (uint intCounterInner = 2; intCounterInner <= intMaxDivisor; intCounterInner++)
        {

          if ((arrintList[intCounter] != intCounterInner) && (arrintList[intCounter] % intCounterInner == 0))
          {
            arrintMark[intCounter] = 1;
          }
          else
          // (arrintList[intCounter] = intCounterInner) || (arrintList[intCounter] % intCounterInner <> 0)
          {
          }
          // (arrintList[intCounter] <> intCounterInner) && (arrintList[intCounter] % intCounterInner = 0)

        }
        // intCounterInner = intMaxDivisor

        uint intProgress = Convert.ToUInt32(arrintList.Length / 100);

        // intProgress is used to divide the work in hunderds
        // You have a very small list to show on the progressbar
        // The progressbar is useless here
        // You will not be fast enough to click on the cancel button :-)

        if (intProgress == 0)
        {
          intProgress = 1;
        }
        else
        // intProgress <> 0
        {
        }
        // intProgress = 0

        if ((intCounter % intProgress == 0) && (theBackgroundWorker != null))
        {

          if (theBackgroundWorker.WorkerReportsProgress)
          {
            theBackgroundWorker.ReportProgress(Convert.ToInt32(intCounter / intProgress));
          }
          else
          // Not theBackgroundWorker.WorkerReportsProgress
          {
          }
          // theBackgroundWorker.WorkerReportsProgress

          if (theBackgroundWorker.CancellationPending)
          {
            return null;
          }
          else
          // Not theBackgroundWorker.CancellationPending
          {
          }
          // theBackgroundWorker.CancellationPending

        }
        else
        // ((intCounter % intProgress <> 0) || (theBackgroundWorker = null)) 
        {
        }
        // ((intCounter % intProgress = 0) && (theBackgroundWorker <> null))

      }
      // intCounter = arrintList.Length

      uint intPrimes = 0;

      for (uint intCounter = 0; intCounter < arrintMark.Length; intCounter++)
      {

        if (arrintMark[intCounter] == 0)
        {
          intPrimes += 1;
        }
        else
          // arrintMark[intCounter] <> 0
        {
        }
        // arrintMark[intCounter] = 0

      }
      // intCounter = arrintMark.Length

      arrintPrime = new uint[intPrimes];

      uint intCursor = 0;

      for (uint intCounter = 0; intCounter < arrintMark.Length; intCounter++)
      {

        if (arrintMark[intCounter] == 0)
        {
          arrintPrime[intCursor] = arrintList[intCounter];
          intCursor += 1;
        }
        else
          // arrintMark[intCounter] <> 0
        {
        }
        // arrintMark[intCounter] = 0

      }
      // intCounter = arrintMark.Length

      if (theBackgroundWorker != null && theBackgroundWorker.WorkerReportsProgress)
      {
        theBackgroundWorker.ReportProgress(100);
      }
      else
      // theBackgroundWorker = null || Not theBackgroundWorker.WorkerReportsProgress
      {
      }
      // theBackgroundWorker <> null && theBackgroundWorker.WorkerReportsProgress

      return arrintPrime;
    }
    // uint[] FindPrimes(uint, uint, System.ComponentModel.BackgroundWorker)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpSieveOfEratosthenes

}
// Multithreading 