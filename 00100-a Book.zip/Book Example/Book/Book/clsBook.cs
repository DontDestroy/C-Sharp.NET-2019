//***
// Action
//   - Define a class cpBook
// Created
//   - CopyPaste � 20220224 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220224 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpBook
	{

    #region "Constructors / Destructors"

    public cpBook(string strTitle, string strAuthor, string strPublisher, double dblPrice)
    //***
    // Action
    //   - Create an instance of a cpBook
    //   - Fill in the attributes / properties Price, Author, Publisher and Title
    // Called by
    //   - Not documented here
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220224 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220224 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      mdblPrice = dblPrice;
      mstrAuthor = strAuthor;
      mstrPublisher = strPublisher;
      mstrTitle = strTitle;
    }
    // cpBook(string, string, string, double)
    
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
      public double mdblPrice;
      public string mstrAuthor;
      public string mstrPublisher;
      public string mstrTitle;
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
    
    public void ShowBook()
    //***
    // Action
    //   - Show a messagebox with the info of the instance of a cpBook()
    // Called by
    //   - Not documented here
    // Calls
    //   - DialogResult MessageBox.Show(string)
    // Created
    //   - CopyPaste � 20220224 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220224 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      MessageBox.Show("Title: " + mstrTitle + "\n" + 
      "Author:" + mstrAuthor + "\n" +
      "Publisher: " + mstrPublisher + "\n" + 
      "Price: " + mdblPrice);
    }
    // ShowBook()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBook

}
// CopyPaste.Learning