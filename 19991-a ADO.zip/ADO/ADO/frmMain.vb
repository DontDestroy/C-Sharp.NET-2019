'***
' Action
'   - Demo of ADO statements (in stead of ADO.NET statements)
'   - This is oldschool, but necessary when you want to convert existing projects to .NET
' Created
'   - CopyPaste � 20260331 � VVDW
' Changed
'   - CopyPaste � yyyymmdd � VVDW � What changed
' Tested
'   - CopyPaste � 20260331 � VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On
Option Strict On

Namespace CopyPaste.Learning

  Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cmdOpenConnection As System.Windows.Forms.Button
    Friend WithEvents cmdEditingARecordset As System.Windows.Forms.Button
    Friend WithEvents txtResult As System.Windows.Forms.TextBox
    Friend WithEvents lblResult As System.Windows.Forms.Label
    Friend WithEvents cmdGetStringDisplay As System.Windows.Forms.Button
    Friend WithEvents cmdPersistingARecordset As System.Windows.Forms.Button
    Friend WithEvents cmdStoredProcWithParam As System.Windows.Forms.Button
    Friend WithEvents cmdBatchUpdate As System.Windows.Forms.Button
    Friend WithEvents cmdCreatingSQLServerObjects As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
      Me.cmdOpenConnection = New System.Windows.Forms.Button
      Me.cmdEditingARecordset = New System.Windows.Forms.Button
      Me.txtResult = New System.Windows.Forms.TextBox
      Me.lblResult = New System.Windows.Forms.Label
      Me.cmdGetStringDisplay = New System.Windows.Forms.Button
      Me.cmdPersistingARecordset = New System.Windows.Forms.Button
      Me.cmdStoredProcWithParam = New System.Windows.Forms.Button
      Me.cmdBatchUpdate = New System.Windows.Forms.Button
      Me.cmdCreatingSQLServerObjects = New System.Windows.Forms.Button
      Me.SuspendLayout()
      '
      'cmdOpenConnection
      '
      Me.cmdOpenConnection.Location = New System.Drawing.Point(8, 8)
      Me.cmdOpenConnection.Name = "cmdOpenConnection"
      Me.cmdOpenConnection.Size = New System.Drawing.Size(128, 48)
      Me.cmdOpenConnection.TabIndex = 0
      Me.cmdOpenConnection.Text = "Open An ADO Connection"
      '
      'cmdEditingARecordset
      '
      Me.cmdEditingARecordset.Location = New System.Drawing.Point(168, 64)
      Me.cmdEditingARecordset.Name = "cmdEditingARecordset"
      Me.cmdEditingARecordset.Size = New System.Drawing.Size(128, 48)
      Me.cmdEditingARecordset.TabIndex = 2
      Me.cmdEditingARecordset.Text = "Open A Recordset with Editing"
      '
      'txtResult
      '
      Me.txtResult.Location = New System.Drawing.Point(8, 200)
      Me.txtResult.Multiline = True
      Me.txtResult.Name = "txtResult"
      Me.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
      Me.txtResult.Size = New System.Drawing.Size(456, 152)
      Me.txtResult.TabIndex = 8
      Me.txtResult.Text = ""
      '
      'lblResult
      '
      Me.lblResult.Location = New System.Drawing.Point(8, 176)
      Me.lblResult.Name = "lblResult"
      Me.lblResult.Size = New System.Drawing.Size(100, 16)
      Me.lblResult.TabIndex = 7
      Me.lblResult.Text = "Current Results"
      '
      'cmdGetStringDisplay
      '
      Me.cmdGetStringDisplay.Location = New System.Drawing.Point(168, 8)
      Me.cmdGetStringDisplay.Name = "cmdGetStringDisplay"
      Me.cmdGetStringDisplay.Size = New System.Drawing.Size(128, 48)
      Me.cmdGetStringDisplay.TabIndex = 1
      Me.cmdGetStringDisplay.Text = "Open A Recordset with GetString Display"
      '
      'cmdPersistingARecordset
      '
      Me.cmdPersistingARecordset.Location = New System.Drawing.Point(168, 120)
      Me.cmdPersistingARecordset.Name = "cmdPersistingARecordset"
      Me.cmdPersistingARecordset.Size = New System.Drawing.Size(128, 48)
      Me.cmdPersistingARecordset.TabIndex = 3
      Me.cmdPersistingARecordset.Text = "Persisting A Recordset"
      '
      'cmdStoredProcWithParam
      '
      Me.cmdStoredProcWithParam.Location = New System.Drawing.Point(328, 8)
      Me.cmdStoredProcWithParam.Name = "cmdStoredProcWithParam"
      Me.cmdStoredProcWithParam.Size = New System.Drawing.Size(128, 48)
      Me.cmdStoredProcWithParam.TabIndex = 4
      Me.cmdStoredProcWithParam.Text = "Stored Procedure with Parameter"
      '
      'cmdBatchUpdate
      '
      Me.cmdBatchUpdate.Location = New System.Drawing.Point(328, 64)
      Me.cmdBatchUpdate.Name = "cmdBatchUpdate"
      Me.cmdBatchUpdate.Size = New System.Drawing.Size(128, 48)
      Me.cmdBatchUpdate.TabIndex = 5
      Me.cmdBatchUpdate.Text = "Batch Updates with ADO and SQL Server"
      '
      'cmdCreatingSQLServerObjects
      '
      Me.cmdCreatingSQLServerObjects.Location = New System.Drawing.Point(328, 120)
      Me.cmdCreatingSQLServerObjects.Name = "cmdCreatingSQLServerObjects"
      Me.cmdCreatingSQLServerObjects.Size = New System.Drawing.Size(128, 48)
      Me.cmdCreatingSQLServerObjects.TabIndex = 6
      Me.cmdCreatingSQLServerObjects.Text = "Creating SQL Objects using ADO"
      '
      'frmMain
      '
      Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
      Me.ClientSize = New System.Drawing.Size(472, 357)
      Me.Controls.Add(Me.cmdCreatingSQLServerObjects)
      Me.Controls.Add(Me.cmdBatchUpdate)
      Me.Controls.Add(Me.cmdStoredProcWithParam)
      Me.Controls.Add(Me.cmdPersistingARecordset)
      Me.Controls.Add(Me.cmdGetStringDisplay)
      Me.Controls.Add(Me.lblResult)
      Me.Controls.Add(Me.txtResult)
      Me.Controls.Add(Me.cmdEditingARecordset)
      Me.Controls.Add(Me.cmdOpenConnection)
      Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
      Me.Name = "frmMain"
      Me.Text = "ADO Interopt"
      Me.ResumeLayout(False)

    End Sub

#End Region

#Region "Constructors / Destructors"

    Protected Overloads Overrides Sub Dispose(ByVal blnDisposing As Boolean)
      '***
      ' Action
      '   - Clean up instance of 'frmMain'
      ' Called by
      '   - User action (Closing the form)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      If blnDisposing Then

        If components Is Nothing Then
        Else
          ' Not components Is Nothing
          components.Dispose()
        End If
        ' components Is Nothing

      Else
        ' Not blnDisposing
      End If
      ' blnDisposing

      MyBase.Dispose(blnDisposing)
    End Sub
    ' Dispose(Boolean)

    Public Sub New()
      '***
      ' Action
      '   - Create new instance of 'frmMain'
      ' Called by
      '   - User action (Starting the form)
      ' Calls
      '   - InitializeComponent()
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      MyBase.New()
      InitializeComponent()
    End Sub
    ' New()

#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

    '#Region "Fields"
    '#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

#Region "Controls"

    Private Sub cmdBatchUpdate_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdBatchUpdate.Click
      '***
      ' Action
      '   - Update a recordset with a SQL Statement
      ' Called by
      '   - User action (Clicking a button)
      ' Calls
      '   - modCommand.ExecuteABatchCommand(TextBox)
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      ExecuteABatchCommand(txtResult)
    End Sub
    ' cmdBatchUpdate_Click(System.Object, System.EventArgs) Handles cmdBatchUpdate.Click

    Private Sub cmdCreatingSQLServerObjects_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdCreatingSQLServerObjects.Click
      '***
      ' Action
      '   - Create an object using ADO statements
      ' Called by
      '   - User action (Clicking a button)
      ' Calls
      '   - CreatingASQLServerObjectFromADO()
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      CreatingASQLServerObjectFromADO()
    End Sub
    ' cmdCreatingSQLServerObjects_Click(System.Object, System.EventArgs) Handles cmdCreatingSQLServerObjects.Click

    Private Sub cmdEditingARecordset_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdEditingARecordset.Click
      '***
      ' Action
      '   - Open a recordset and edit information
      ' Called by
      '   - User action (Clicking a button)
      ' Calls
      '   - OpenRecordsetWithEditing(TextBox)
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      OpenRecordsetWithEditing(txtResult)
    End Sub
    ' cmdEditingARecordset_Click(System.Object, System.EventArgs) Handles cmdEditingARecordset.Click

    Private Sub cmdGetStringDisplay_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdGetStringDisplay.Click
      '***
      ' Action
      '   - 
      ' Called by
      '   - User action (Clicking a button)
      ' Calls
      '   - OpenRecordsetWithGetStringDisplay(TextBox)
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      OpenRecordsetWithGetStringDisplay(txtResult)
    End Sub
    ' cmdGetStringDisplay_Click(System.Object, System.EventArgs) Handles cmdGetStringDisplay.Click

    Private Sub cmdOpenConnection_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdOpenConnection.Click
      '***
      ' Action
      '   - Open a connection
      '   - Show the result in the text box
      ' Called by
      '   - User action (Clicking a button)
      ' Calls
      '   - modConnection.OpenAndDisplayADOConnection(TextBox)
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      OpenAndDisplayADOConnection(txtResult)
    End Sub
    ' cmdOpenConnection_Click(System.Object, System.EventArgs) Handles cmdOpenConnection.Click

    Private Sub cmdPersistingARecordset_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdPersistingARecordset.Click
      '***
      ' Action
      '   - Open a recordset and persist information
      ' Called by
      '   - User action (Clicking a button)
      ' Calls
      '   - modRecordset.PersistingARecordset(TextBox)
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      PersistingARecordset(txtResult)
    End Sub
    ' cmdPersistingARecordset_Click(System.Object, System.EventArgs) Handles cmdPersistingARecordset.Click

    Private Sub cmdStoredProcWithParam_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdStoredProcWithParam.Click
      '***
      ' Action
      '   - Open a recordset with a stored procedure
      ' Called by
      '   - User action (Clicking a button)
      ' Calls
      '   - UseAStoredProcedureWithAParameter(TextBox)
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      UseAStoredProcedureWithAParameter(txtResult)
    End Sub
    ' cmdStoredProcWithParam_Click(System.Object, System.EventArgs) Handles cmdStoredProcWithParam.Click

#End Region

    '#Region "Functionality"

    '#Region "Event"
    '#End Region

    '#Region "Sub / Function"
    '#End Region

    '#End Region

    '#Region "Not used"
    '#End Region

#End Region

  End Class
  ' frmMain

End Namespace
' CopyPaste.Learning