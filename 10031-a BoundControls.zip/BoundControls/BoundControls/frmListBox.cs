//***
// Action
//   - Show a listbox bound to a data set
// Created
//   - CopyPaste � 20251231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251231 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmListBox: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwindScript2005;
    internal System.Data.SqlClient.SqlCommand cmmSelectCustomer;
    internal System.Data.SqlClient.SqlDataAdapter dtaCustomer;
    internal System.Windows.Forms.ListBox lstListbox;
    private BoundControls.dsCustomer dsCustomer;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmListBox));
      this.cnncpNorthwindScript2005 = new System.Data.SqlClient.SqlConnection();
      this.cmmSelectCustomer = new System.Data.SqlClient.SqlCommand();
      this.dtaCustomer = new System.Data.SqlClient.SqlDataAdapter();
      this.lstListbox = new System.Windows.Forms.ListBox();
      this.dsCustomer = new BoundControls.dsCustomer();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomer)).BeginInit();
      this.SuspendLayout();
      // 
      // cnncpNorthwindScript2005
      // 
      this.cnncpNorthwindScript2005.ConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthwindScript2005.FireInfoMessageEventOnUserErrors = false;
      // 
      // cmmSelectCustomer
      // 
      this.cmmSelectCustomer.CommandText = "SELECT strIdCustomer, strCompanyName FROM tblCPCustomer";
      this.cmmSelectCustomer.Connection = this.cnncpNorthwindScript2005;
      // 
      // dtaCustomer
      // 
      this.dtaCustomer.SelectCommand = this.cmmSelectCustomer;
      this.dtaCustomer.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCustomer", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("strIdCustomer", "strIdCustomer"),
                        new System.Data.Common.DataColumnMapping("strCompanyName", "strCompanyName")})});
      // 
      // lstListbox
      // 
      this.lstListbox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.lstListbox.DataSource = this.dsCustomer;
      this.lstListbox.DisplayMember = "tblCPCustomer.strCompanyName";
      this.lstListbox.Location = new System.Drawing.Point(8, 8);
      this.lstListbox.Name = "lstListbox";
      this.lstListbox.Size = new System.Drawing.Size(352, 277);
      this.lstListbox.TabIndex = 1;
      this.lstListbox.ValueMember = "tblCPCustomer.strIdCustomer";
      // 
      // dsCustomer
      // 
      this.dsCustomer.DataSetName = "dsCustomer";
      this.dsCustomer.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsCustomer.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // frmListBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(368, 293);
      this.Controls.Add(this.lstListbox);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmListBox";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Displaying a Bound Listbox";
      this.Load += new System.EventHandler(this.frmListBox_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomer)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmListBox'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmListBox()
      //***
      // Action
      //   - Create instance of 'frmListBox'
      // Called by
      //   - frmBoundControlMain.cmdListbox_Click(System.Object, System.EventArgs) Handles cmdListbox.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmListBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmListBox_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Fill the data set using the data adapter
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dtaCustomer.Fill(dsCustomer);
    }
    // frmListBox_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmListBox

}
// CopyPaste.Learning