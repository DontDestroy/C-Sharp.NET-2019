//***
// Action
//   - Implementation of cpDerived
// Created
//   - CopyPaste � 20240618 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240618 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpDerived : cpBase
  {

    #region "Constructors / Destructors"

    public cpDerived() : base()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpDerived()
      //   - cpProgram.Main()
      // Calls
      //   - cpBase()
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpBase()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    // public override void SubMustOverride()
    // {
    //   Console.WriteLine("Sub Must Override in Derived");
    // }
    // // SubMustOverride()

    // public override void SubNotOverridable()
    // {
    //   Console.WriteLine("Sub Not Overridable in Derived");
    // }
    // // SubNotOverridable()

    public override void SubOverridable()
      //***
      // Action
      //   - Show that the subroutine is overridden
      // Called by
      //   - modSub.Main()
      //   - SubTestDerived()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Sub Overridable in Derived");
    }
    // SubOverridable()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public new void SubShadows()
      //***
      // Action
      //   - Show that the subroutine is shadowed
      // Called by
      //   - cpProgram.Main()
      //   - SubTestTest()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Sub Shadows in Derived");
    }
    // SubShadows()

    public void SubTestDerived()
      //***
      // Action
      //   - Execute all subroutines
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - SubMustOverride()
      //   - SubNotOverridable()
      //   - SubOverLoad()
      //   - SubOverLoad(string)
      //   - SubOverridable()
      //   - SubShadows()
      //   - SubStatic()
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      SubOverLoad();
      SubOverLoad("This is overloaded");
      SubOverridable();
      // SubNotOverridable();
      // SubMustOverride();
      SubShadows();
      SubStatic();
    }
    // SubTestDerived()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDerived

}
// CopyPaste.Learning