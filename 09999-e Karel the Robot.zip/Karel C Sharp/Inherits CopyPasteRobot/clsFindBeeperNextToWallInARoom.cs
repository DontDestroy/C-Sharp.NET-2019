﻿//***
// Action
//   - A definition of a FindBeeperNextToWallInARoom
// Created
//   - CopyPaste – 20251025 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251025 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpFindBeeperNextToWallInARoom : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpFindBeeperNextToWallInARoom(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpFindBeeperNextToWallInARoom starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpFindBeeperNextToWallInARoom(int, int, Directions.Direction, int)
    //   - cpProgram.FindBeeperNextToWallInARoom()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpFindBeeperNextToWallInARoom(int, int, Directions.Direction, int, Color) 

    public cpFindBeeperNextToWallInARoom(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpFindBeeperNextToWallInARoom starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpFindBeeperNextToWallInARoom(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpFindBeeperNextToWallInARoom(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void FindBeeperNextToWall()
    //***
    // Action
    //   - As long robot is not finding a beeper
    //     - If robot is not blocked
    //       - Move forward
    //     - If not
    //       - Turn left
    //   - Pick beeper
    // Called by
    //   - cpProgram.FindBeeperNextToWallInARoom()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (!nextToABeeper())
      {

        if (frontIsClear())
        {
          move();
        }
        else
        // Not frontIsClear()
        {
          turnLeft();
        }
        // frontIsClear()
      }
      // Not nextToABeeper()

      pickBeeper();
    }
    // FindBeeperNextToWall()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpFindBeeperNextToWallInARoom

}
// cpKarelTheRobot