//***
// Action
//   - Implementation cpDemo
// Created
//   - CopyPaste � 20240710 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240710 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpDemo
  {

    #region "Constructors / Destructors"

    public cpDemo(string strMessage)
      //***
      // Action
      //   - Basic constructor with a given message
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240710 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrMessage = strMessage;
    }
    // cpDemo(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public string mstrMessage;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [cpProgrammerName("Kris Jamsa")]
    public void DemoMessage()
      //***
      // Action
      //   - Show mstrMessage
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240710 � Kris Jamsa
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � Kris Jamsa
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine(mstrMessage);
    }
    // DemoMessage()

    [cpProgrammerName("Phil Schmauder")]
    public void Greet()
      //***
      // Action
      //   - Show a text
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240710 � Phil Schmauder
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240710 � Phil Schmauder
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Hello, C#");
    }
    // Greet()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDemo

}
// CopyPaste.Learning