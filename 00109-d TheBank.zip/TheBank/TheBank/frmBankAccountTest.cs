//***
// Action
//   - Test routine for cpBankAccount
// Created
//   - CopyPaste � 20240221 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240221 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBankAccountTest: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBankAccountTest));
      // 
      // frmBankAccountTest
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBankAccountTest";
      this.Text = "The Bank";
      this.Load += new System.EventHandler(this.frmBankAccountTest_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBankAccountTest'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBankAccountTest()
      //***
      // Action
      //   - Create instance of 'frmBankAccountTest'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmBankAccountTest()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmBankAccountTest_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of cpBankAccount
      //     - The owner is "Vincent"
      //   - Put �100 on it
      //   - Show the owner and the balance of it
      //   - Remove �25 off it
      //   - Show the owner and the balance of it
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpBankAccount.Deposit(decimal)
      //   - cpBankAccount.New(string)
      //   - cpBankAccount.Withdraw(decimal)
      //   - decimal cpBankAccount.Balance (Get)
      //   - string cpBankAccount.Id (Get)
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpBankAccount anAccount = new cpBankAccount("Vincent");
      
      anAccount.Deposit(100M);
      MessageBox.Show(String.Format("{0} has {1:C} on the bankaccount.", anAccount.Id, anAccount.Balance));
      anAccount.Withdraw(25M);
      MessageBox.Show(String.Format("{0} has {1:C} on the bankaccount.", anAccount.Id, anAccount.Balance));
    }
    // frmBankAccountTest_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmBankAccountTest
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmBankAccountTest());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBankAccountTest

}
// CopyPaste.Learning