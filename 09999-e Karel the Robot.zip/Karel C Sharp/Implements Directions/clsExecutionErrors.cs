﻿//***
// Action
//   - Create a class cpExecutionErrors that uses the interface Directions
// Created
//   - CopyPaste – 20251011 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251011 – VVDW
// Proposal (To Do)
//   - This is put into comments because it contains errors (on purpose)
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpExecutionErrors : Directions
	{

		#region "Constructors / Destructors"

		public cpExecutionErrors()
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Reset the world
		//   - Build the world according to the One Wall Segment specifications
		//   - Make the world visible
		//   - Karel becomes a green robot starting at position (1, 1), looking to the right with no beepers in the bag
		//   - Karel will move one forward
		//   - Karel will move one forward
		//   - Karel will turn left
		//   - Karel will turn left
		//   - Karel will turn left
		//   - Karel will move one forward
		//   - Karel is switched off
		// Called by
		//   - cpProgram.LexicalErrors()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251011 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251011 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - This code is full of execution errors and will never work
		//***
		{
			World.reset();
			World.readWorld("Worlds\\01.01 The Robot World.kwld");
			World.setVisible(true);
			UrRobot karel = new UrRobot(1, 1, Directions.East, 0, Color.green);
			karel.move(); // Moving one to the East (position Street 1, Avenue 2)
			karel.move(); // Moving one to the East (position Street 1, Avenue 3)
			karel.turnLeft(); // Turn to the left (Looking to the North)
			karel.turnLeft(); // Turn to the left (Looking to the West)
			karel.turnLeft(); // Turn to the left (Looking to the South)
			karel.move(); // Moving one to the South (position Street 0, Avenue 3) (You hit a wall)
			karel.turnOff(); // Robot karel is switched off
		}
		// cpExecutionErrors()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// cpExecutionErrors

}
// cpKarelTheRobot