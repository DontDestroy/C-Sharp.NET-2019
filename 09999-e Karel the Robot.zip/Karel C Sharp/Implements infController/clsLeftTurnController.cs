﻿//***
// Action
//   - Implementation of a LeftTurnController
// Created
//   - CopyPaste – 20251030 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251030 – VVDW
// Proposal (To Do)
//   -
//***

using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpLeftTurnController : cpinfController
	{

    #region "Constructors / Destructors"

    public cpLeftTurnController(cpCopyPasteRobot aRobot)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - If the given aRobot is null
    //     - The internal robot becomes a new default cpCopyPasteRobot will be created
    //   - If not
    //     - The internal robot becomes the given aRobot (when it is not null)
    //   - Nothing else happens
    // Called by
    //   - cpControllerStrategyVersion01(int, int, Directions.Direction, int, Color) 
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (aRobot == null)
      {
        theInternalRobot = new cpCopyPasteRobot();
      }
      else
      // aRobot <> null
      {
        theInternalRobot = aRobot;  
      }
      // aRobot = null

    }
    // cpLeftTurnController(cpCopyPasteRobot) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpCopyPasteRobot theInternalRobot = null;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ControlIt()
    //***
    // Action
    //   - Implementation of ControlIT
    //     - Turn to the left
    //     - Move one forward
    //     - Turn to the left
    // Called by
    //   - cpControllerStrategyVersion01.Turn()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theInternalRobot.turnLeft();
      theInternalRobot.move();
      theInternalRobot.turnLeft();
    }
    // ControlIt()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpLeftTurnController

}
// cpKarelTheRobot