﻿//***
// Action
//   - Data Service
//   - Gets the needed data
// Created
//   - CopyPaste – 20220825 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220825 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Text;

namespace CopyPaste.ServerApplication
{

  public class cpDataService
  {

    #region "Constructors / Destructors"

    public cpDataService()
    //***
    // Action
    //   - Create instance of cpDataService
    //   - Create a list of product categories.
    //   - Fill the list with product category items
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220825 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220825 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      _lstProductCategory = new List<string>();
      _lstProductCategory.Add("Development");
      _lstProductCategory.Add("Soft Skills");
      _lstProductCategory.Add("DevOps");
    }
    // cpDataService()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private IList<string> _lstProductCategory;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public IList<string> AllProductCategories()
    //***
    // Action
    //   - Returns the full list of product categories
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220825 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220825 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      return _lstProductCategory;
    }
    // IList<string> AllProductCategories()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDataService

}
// CopyPaste.ServerApplication