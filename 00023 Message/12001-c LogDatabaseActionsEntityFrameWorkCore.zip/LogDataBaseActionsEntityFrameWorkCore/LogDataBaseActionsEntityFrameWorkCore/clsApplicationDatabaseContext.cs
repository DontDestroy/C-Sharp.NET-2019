﻿//***
// Action
//   - The class that sets up the context towards a SQL Server database
// Created
//   - CopyPaste – 20230401 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230401 – VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.EntityFrameworkCore;

namespace LogDatabaseActionsEntityFrameWorkCore
{

  public class cpApplicationDatabaseContext : DbContext
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    // private const string strConnectionString =
    //   @"Server=(localdb)\mssqllocaldb;Database=DemoEntityFrameWorkCore;Trusted_Connection=True";
    private const string strConnectionString =
      @"Server=CopyPastePower\CopyPaste;Database=DemoEntityFrameWorkCore;Trusted_Connection=True";

    #endregion

    #region "Properties"

    //***
    // Action Get and Set
    //   - Entry point for the database context to create the model towards the database
    // Called by
    //   - string cpProgram.ReadTestData(cpApplicationDatabaseContext)
    //   - cpProgram.WriteTestData(cpApplicationDatabaseContext)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    public DbSet<cpBook> cpBook { get; set; }
    // DbSet<cpBook> cpBook (Get)
    // cpBook(DbSet<cpBook>) (Set)

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    protected override void OnConfiguring(DbContextOptionsBuilder theOptionsBuilder)
    //***
    // Action
    //   - While configuring the database context, we say it is a SQL Server database
    // Called by
    //   - System action (Configuring the database context)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230401 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230401 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theOptionsBuilder.UseSqlServer(strConnectionString);
    }
    // OnConfiguring(DbContextOptionsBuilder)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpApplicationDatabaseContext

}
// LogDatabaseActionsEntityFrameWorkCore