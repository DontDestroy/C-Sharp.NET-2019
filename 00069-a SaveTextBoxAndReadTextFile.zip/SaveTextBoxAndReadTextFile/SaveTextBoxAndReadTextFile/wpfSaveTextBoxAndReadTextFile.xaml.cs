﻿//***
// Action
//   - Type some text and save it in a file
//   - Read the file and show it as result in a label
// Created
//   - CopyPaste – 20220903 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220903 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace SaveTextBoxAndReadTextFile
{

  public partial class wpfSaveTextBoxAndReadTextFile : Window
  {

    #region "Constructors / Destructors"

    public wpfSaveTextBoxAndReadTextFile()
    //***
    // Action
    //   - Create an instance of 'wpfSaveTextBoxAndReadTextFile'
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220903 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220903 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfSaveTextBoxAndReadTextFile()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdGetName_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Define a stream reader for T:\UserName.txt
    //   - Write the content of the file towards a label
    //   - Close the stream reader
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220903 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220903 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      System.IO.StreamReader strReader = new System.IO.StreamReader("T:\\username.txt");

      lblOutput.Content = "Hello " + strReader.ReadToEnd();
      strReader.Close();
    }
    // cmdGetName_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdGetName.Click


    private void cmdSetName_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Define a stream writer for T:\UserName.txt
    //   - Write the content of txtInput towards it
    //   - Close the stream writer
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220903 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220903 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      System.IO.StreamWriter strWriter = new System.IO.StreamWriter("T:\\UserName.txt");

      strWriter.WriteLine(txtInput.Text);
      strWriter.Close();
    }
    // cmdSetName_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdSetName.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfSaveTextBoxAndReadTextFile

}
// SaveTextBoxAndReadTextFile