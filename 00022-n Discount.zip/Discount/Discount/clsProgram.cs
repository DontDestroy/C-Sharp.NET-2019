//***
// Action
//   - Determine the percentage discount depending on a value of products
// Created
//   - CopyPaste � 20240502 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240502 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Ask the value of products
      //   - Depending on the amount a percentage discount is calculated
      //     - <= 25 --> 1%
      //     - <= 50 --> 2%
      //     - <= 100 --> 3%
      //     - Other --> 5%
      //   - Show the result (% multiplied by amount)
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240502 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240502 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      decimal decDiscountPercent;
      decimal decDiscountValue;
      decimal decProductValue;
      
      Console.Write("What is the value of the products: ");
      decProductValue = Convert.ToDecimal(Console.ReadLine());

      if (decProductValue <= 25)
      {
        decDiscountPercent = 0.01M;
      }
      else if (decProductValue <= 50)
        // decProductValue > 25
      {
        decDiscountPercent = 0.02M;
      }
        // decProductValue > 50
      else if (decProductValue <= 100)
      {
        decDiscountPercent = 0.03M;
      }
      else
        // decProductValue > 100
      {
        decDiscountPercent = 0.05M;
      }
      // decProductValue <= 25
      // decProductValue <= 50
      // decProductValue <= 100
      
      Console.WriteLine("Your discount is: {0}", decProductValue * decDiscountPercent);
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx