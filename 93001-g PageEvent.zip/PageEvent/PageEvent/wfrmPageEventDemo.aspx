<%@ Page Language="C#" %>

<%@ Import Namespace="System.Diagnostics" %>

<!--
  VVDW - To be able to have a log, you must create under 
    HKEY_LOCAL_MACHINE/System/CurrentControlSet/Services/EventLog/Application
    a Key "wfrmPageEventDemo.aspx"
  
  VVDW - To be able to have a log, you must give
    HKEY_LOCAL_MACHINE/System/CurrentControlSet/Services/EventLog/Application
    permissions (Full Control) for the users IUSR
-->

<script language="C#" runat="server">

  protected void Page_Error(System.Object theSender, EventArgs theEventArguments)
  {
    EventLog log = new EventLog("Application");

    log.Source = "wfrmPageEventDemo.aspx";

    log.WriteEntry("Error on the page");
    // VVDW - Comment out when remarks above are not executed

    log.Close();
  }

  protected void Page_Load(System.Object theSender, EventArgs theEventArguments)
  {
    EventLog log = new EventLog("Application");

    log.Source = "wfrmPageEventDemo.aspx";

    log.WriteEntry("Page loaded at " + DateTime.Now);
    // VVDW - Comment out when remarks above are not executed

    log.Close();

    Session["LoadTime"] = DateTime.Now;
  }

  protected void Page_PreRender(System.Object theSender, EventArgs theEventArguments)
  {
    Response.Write("<i>");
  }

  protected void Page_Unload(System.Object theSender, EventArgs theEventArguments)
  {
    EventLog log = new EventLog("Application");

    log.Source = "wfrmPageEventDemo.aspx";

    log.WriteEntry("Page unloaded at " + DateTime.Now);
    // VVDW - Comment out when remarks above are not executed

    log.Close();
  }

</script>

<html>
<head>
  <title>Page Event Demo</title>
</head>
<body>
  <center>
    <h1>Hello ASP.NET World!</h1>
  </center>
</body>
</html>
