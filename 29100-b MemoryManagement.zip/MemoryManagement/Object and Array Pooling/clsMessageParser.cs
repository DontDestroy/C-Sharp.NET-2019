﻿//***
// Action
//   - Parsing an array of bytes into an array of integers
//     - A calculation is executed with every group of 8 bytes
// Created
//   - CopyPaste – 20260608 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260608 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpMessageParser
  {

    #region "Constructors / Destructors"

    public cpMessageParser()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpMessageParser(byte[])
    //   - cpReuseInstances.MessageParserObjectPool()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260608 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260608 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpMessageParser()

    public cpMessageParser(byte[] arrToParse) : this()
    //***
    // Action
    //   - Basic constructor with a given array of bytes
    //   - Buffer is set
    // Called by
    //   - cpReuseInstances.MessageParserArray()
    //   - cpReuseInstances.MessageParserArrayPool()
    // Calls
    //   - Buffer(byte[]) (Set)
    //   - cpMessageParser()
    // Created
    //   - CopyPaste – 20260607 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260607 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Buffer = arrToParse;
    }
    // cpMessageParser(byte[])

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    const int intBufferLength = 8;
    private byte[] arrMessage;
    private int intLength;
    private int intPosition;
    private int[] arrResult;

    #endregion

    #region "Properties"

    public byte[] Buffer
    {

      set
      //***
      // Action set
      //   - A given array is put in arrMessage
      //   - The length is calculated
      // Called by
      //   - cpMessageParser(byte[])
      //   - cpReuseInstances.MessageParserObjectPool()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260607 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260607 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        arrMessage = value;
        intLength = value.Length / intBufferLength;
        arrResult = new int[intLength];
      }
      // Buffer(byte[]) (Set)

    }
    // byte[] Buffer

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int[] Parse()
    //***
    // Action
    //   - A given array of bytes is rearranged in a range of integers
    //   - First intBufferLength bytes are added to the first integer
    //   - Second intBufferLength bytes are added to the second integer
    //   - Loop for every next 8 items
    // Called by
    //   - cpReuseInstances.MessageParserArray()
    //   - cpReuseInstances.MessageParserArrayPool()
    //   - cpReuseInstances.MessageParserObjectPool()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260607 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260607 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - An assumption is taken that the length of the given array is divisible by intBufferLength
    //***
    {

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {
        intPosition = intCounter * intBufferLength;
        arrResult[intCounter] = arrMessage[intPosition] + arrMessage[intPosition + 1] + arrMessage[intPosition + 2]
              + arrMessage[intPosition + 3] + arrMessage[intPosition + 4] + arrMessage[intPosition + 5]
              + arrMessage[intPosition + 6] + arrMessage[intPosition + 7];
      }
      // intCounter = intLength

      return arrResult;
    }
    // int[] Parse()

    public void Reset()
    //***
    // Action
    //   - Maybe it is needed to reinitialize the internal state for reuse
    //   - In this example it is not needed, but the method is here for clarity
    // Called by
    //   -
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260607 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260607 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // Reset()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpMessageParser

}
// CopyPaste.Learning