//***
// Action
//   - Example of using &, &&, | and ||
//   - & = And
//   - | = Or
//   - && = AndAlso
//   - || = OrElse
// Created
//   - CopyPaste � 20220119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220119 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace LazyEvaluation
{

  class cpLazyEvaluation
	{
    static bool blnOwnsDog = true;
    static bool blnOwnsCat = false;

    static void Main()
    //***
    // Action
    //   - Initialise two booleans
    //   - Show message if both are true
    //   - Show message if one is true
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - bool CatOwning()
    //   - bool DogOwning()
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220119 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220119 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("First run");
      
      if (blnOwnsDog && blnOwnsCat)
      {
        Console.WriteLine("Owns both a dog and a cat");
      }
      else
        // Not(blnOwnsDog && blnOwnsCat)
      {
      }
      // blnOwnsDog && blnOwnsCat 

      if (blnOwnsDog || blnOwnsCat)
      {
        Console.WriteLine("Owns a dog or cat - maybe both");
      }
      else
        // Not (blnOwnsDog || blnOwnsCat)
      {
      }
      // blnOwnsDog || blnOwnsCat

      Console.WriteLine("Second run");

      if (blnOwnsDog & blnOwnsCat)
      {
        Console.WriteLine("Owns both a dog and a cat");
      }
      else
        // Not(blnOwnsDog & blnOwnsCat)
      {
      }
      // blnOwnsDog & blnOwnsCat 

      if (blnOwnsDog | blnOwnsCat)
      {
        Console.WriteLine("Owns a dog or cat - maybe both");
      }
      else
        // Not (blnOwnsDog | blnOwnsCat)
      {
      }
      // blnOwnsDog | blnOwnsCat

      Console.WriteLine("Third run");
      
      if (DogOwning() && CatOwning())
      {
        Console.WriteLine("Owns both a dog and a cat");
      }
      else
        // Not(DogOwning() && CatOwning())
      {
      }
      // DogOwning() && CatOwning() 

      if (DogOwning() || CatOwning())
      {
        Console.WriteLine("Owns a dog or cat - maybe both");
      }
      else
        // Not (DogOwning() || CatOwning())
      {
      }
      // DogOwning() || CatOwning()

      Console.WriteLine("Fourth run");
      
      if (DogOwning() & CatOwning())
      {
        Console.WriteLine("Owns both a dog and a cat");
      }
      else
        // Not(DogOwning() & CatOwning())
      {
      }
      // DogOwning() & CatOwning() 

      if (DogOwning() | CatOwning())
      {
        Console.WriteLine("Owns a dog or cat - maybe both");
      }
      else
        // Not (DogOwning() | CatOwning())
      {
      }
      // DogOwning() | CatOwning()

      Console.ReadLine();
    }
    // Main()

    static bool CatOwning()
    //'***
    //' Action
    //'   - Returns true is owning a cat
    //' Called by
    //'   - Main()
    //' Calls
    //'   - 
    //' Created
    //'   - CopyPaste � 20220119 � VVDW
    //' Changed
    //'   - CopyPaste � yyyymmdd � VVDW � What changed
    //' Tested
    //'   - CopyPaste � 20220119 � VVDW
    //' Keyboard key
    //'   -
    //' Proposal (To Do)
    //'   -
    //'***
    {
      return blnOwnsCat;
    }
    // bool CatOwning()

    static bool DogOwning()
    //'***
    //' Action
    //'   - Returns true is owning a dog
    //' Called by
    //'   - Main()
    //' Calls
    //'   - 
    //' Created
    //'   - CopyPaste � 20220119 � VVDW
    //' Changed
    //'   - CopyPaste � yyyymmdd � VVDW � What changed
    //' Tested
    //'   - CopyPaste � 20220119 � VVDW
    //' Keyboard key
    //'   -
    //' Proposal (To Do)
    //'   -
    //'***
    {
      return blnOwnsDog;
    }
    // bool DogOwning()

  }
  // cpLazyEvaluation

}
// LazyEvaluation