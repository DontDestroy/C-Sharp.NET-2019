//***
// Action
//   - Class definition of cpBookDetails
// Created
//   - CopyPaste � 20230421 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230421 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpBook
  {

    #region "Constructors / Destructors"

    public cpBook(string strTitle)
    //***
    // Action
    //   - Constructor of cpBook with 1 parameter
    //   - Parameter with value for title
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      mstrTitle = strTitle;
      mstrAuthor = "Unknown";
      mstrPublisher = "Unknown";
      mdblPrice = 0;
    }
    // cpBook(string)

    public cpBook(string strTitle, string strAuthor)
    //***
    // Action
    //   - Constructor of cpBook with 2 parameters
    //   - Parameters with values for title and author
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      mstrTitle = strTitle;
      mstrAuthor = strAuthor;
      mstrPublisher = "Unknown";
      mdblPrice = 0;
    }
    // cpBook(string, string)

    public cpBook(string strTitle, string strAuthor, string strPublisher)
    //***
    // Action
    //   - Constructor of cpBook with 3 parameters
    //   - Parameters with values for title, author and publisher
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      mstrTitle = strTitle;
      mstrAuthor = strAuthor;
      mstrPublisher = strPublisher;
      mdblPrice = 0;
    }
    // cpBook(string, string, string)

    public cpBook(string strTitle, string strAuthor, string strPublisher, double dblPrice)
    // ***
    //  Action
    //    - Constructor of cpBook with 4 parameters
    //    - Parameters with values for title, author, publisher and price
    //  Called by
    //    - cpProgram.Main()
    //  Calls
    //    - 
    //  Created
    //    - CopyPaste � 20230421 � VVDW
    //  Changed
    //    - CopyPaste � yyyymmdd � VVDW � What changed
    //  Tested
    //    - CopyPaste � 20230421 � VVDW
    //  Keyboard key
    //    - 
    //  Proposal (To Do)
    //    - 
    // ***
    {
      mstrTitle = strTitle;
      mstrAuthor = strAuthor;
      mstrPublisher = strPublisher;
      mdblPrice = dblPrice;
    }
    // cpBook(string, string, string, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public double mdblPrice;
    public string mstrAuthor;
    public string mstrPublisher;
    public string mstrTitle;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ShowBook()
    //***
    // Action
    //   - Show the title
    //   - Show the author (if there is one)
    //   - Show the publisher (if there is one)
    //   - Show the price (if there is one)
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine("Title: " + mstrTitle);
      Console.WriteLine("Author: " + mstrAuthor);
      Console.WriteLine("Publisher: " + mstrPublisher);
      Console.WriteLine("Price: " + mdblPrice);
      Console.WriteLine();
    }
    // ShowBook()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBook

}
// CopyPaste.Learning