﻿//***
// Action
//   - Having Transactions in database actions
// Created
//   - CopyPaste – 20210707 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210707 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

namespace TransactionsTryout
{
  partial class frmTransactionsTryout
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdRollback;
    internal System.Windows.Forms.Button cmdCommit;
    internal System.Windows.Forms.Button cmdCreate;
    internal System.Windows.Forms.Button cmdNested;
    internal System.Windows.Forms.DataGrid dgrOrder;
    internal System.Windows.Forms.Label lblOrder;
    internal System.Windows.Forms.ListBox lstCustomer;
    internal System.Windows.Forms.Button cmdLoad;
    internal System.Windows.Forms.Label lblCustomer;
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.cmdRollback = new System.Windows.Forms.Button();
      this.cmdCommit = new System.Windows.Forms.Button();
      this.cmdCreate = new System.Windows.Forms.Button();
      this.cmdNested = new System.Windows.Forms.Button();
      this.dgrOrder = new System.Windows.Forms.DataGrid();
      this.lblOrder = new System.Windows.Forms.Label();
      this.lstCustomer = new System.Windows.Forms.ListBox();
      this.cmdLoad = new System.Windows.Forms.Button();
      this.lblCustomer = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdRollback
      // 
      this.cmdRollback.Location = new System.Drawing.Point(304, 138);
      this.cmdRollback.Name = "cmdRollback";
      this.cmdRollback.Size = new System.Drawing.Size(96, 23);
      this.cmdRollback.TabIndex = 17;
      this.cmdRollback.Text = "Rollback";
      // 
      // cmdCommit
      // 
      this.cmdCommit.Location = new System.Drawing.Point(304, 106);
      this.cmdCommit.Name = "cmdCommit";
      this.cmdCommit.Size = new System.Drawing.Size(96, 23);
      this.cmdCommit.TabIndex = 16;
      this.cmdCommit.Text = "Commit";
      // 
      // cmdCreate
      // 
      this.cmdCreate.Location = new System.Drawing.Point(304, 42);
      this.cmdCreate.Name = "cmdCreate";
      this.cmdCreate.Size = new System.Drawing.Size(96, 23);
      this.cmdCreate.TabIndex = 14;
      this.cmdCreate.Text = "Create";
      // 
      // cmdNested
      // 
      this.cmdNested.Location = new System.Drawing.Point(304, 74);
      this.cmdNested.Name = "cmdNested";
      this.cmdNested.Size = new System.Drawing.Size(96, 23);
      this.cmdNested.TabIndex = 15;
      this.cmdNested.Text = "Create Nested";
      // 
      // dgrOrder
      // 
      this.dgrOrder.DataMember = "";
      this.dgrOrder.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrOrder.Location = new System.Drawing.Point(8, 146);
      this.dgrOrder.Name = "dgrOrder";
      this.dgrOrder.Size = new System.Drawing.Size(280, 128);
      this.dgrOrder.TabIndex = 12;
      // 
      // lblOrder
      // 
      this.lblOrder.AutoSize = true;
      this.lblOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOrder.Location = new System.Drawing.Point(8, 130);
      this.lblOrder.Name = "lblOrder";
      this.lblOrder.Size = new System.Drawing.Size(48, 13);
      this.lblOrder.TabIndex = 11;
      this.lblOrder.Text = "Orders:";
      // 
      // lstCustomer
      // 
      this.lstCustomer.DisplayMember = "strIdCustomer";
      this.lstCustomer.Location = new System.Drawing.Point(8, 26);
      this.lstCustomer.Name = "lstCustomer";
      this.lstCustomer.Size = new System.Drawing.Size(280, 95);
      this.lstCustomer.TabIndex = 10;
      this.lstCustomer.ValueMember = "strIdCustomer";
      // 
      // cmdLoad
      // 
      this.cmdLoad.Location = new System.Drawing.Point(304, 10);
      this.cmdLoad.Name = "cmdLoad";
      this.cmdLoad.Size = new System.Drawing.Size(96, 23);
      this.cmdLoad.TabIndex = 13;
      this.cmdLoad.Text = "Load Data";
      // 
      // lblCustomer
      // 
      this.lblCustomer.AutoSize = true;
      this.lblCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblCustomer.Location = new System.Drawing.Point(8, 10);
      this.lblCustomer.Name = "lblCustomer";
      this.lblCustomer.Size = new System.Drawing.Size(69, 13);
      this.lblCustomer.TabIndex = 9;
      this.lblCustomer.Text = "Customers:";
      // 
      // frmTransactionsTryout
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(408, 285);
      this.Controls.Add(this.cmdRollback);
      this.Controls.Add(this.cmdCommit);
      this.Controls.Add(this.cmdCreate);
      this.Controls.Add(this.cmdNested);
      this.Controls.Add(this.dgrOrder);
      this.Controls.Add(this.lblOrder);
      this.Controls.Add(this.lstCustomer);
      this.Controls.Add(this.cmdLoad);
      this.Controls.Add(this.lblCustomer);
      this.Name = "frmTransactionsTryout";
      this.Text = "Transactions Tryout";
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"
    
    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210707 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210707 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing && (components != null))
      {
        components.Dispose();
      }
      // (disposing && (components != null))

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmTransactionsTryout

}
// TransactionsTryout