﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmBritain.aspx.cs" Inherits="CopyPaste.Learning.wfrmBritain" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>myPod: Britain</title>
  <style type="text/css">
    body {
      background-color: #eaf3da;
    }
  </style>
</head>
<body>
  <form id="wfrmBritain" runat="server">
    <h1>Britain</h1>
    <p>
      <img src="../Resources/Britain.jpg" alt="An iPod in Birmingham at a telephone box" />
    </p>
  </form>
</body>
</html>
