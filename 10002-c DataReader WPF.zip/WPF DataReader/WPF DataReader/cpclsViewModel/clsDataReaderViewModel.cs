﻿//***
// Action
//   - Having a Data Reader towards a database
//   - Defining the Data Reader functionality
//   - Interaction logic for MainWindow.xaml
// Created
//   - CopyPaste – 20210819 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210819 – VVDW
// Proposal(To Do)
//   -
//***

using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using WPFDataReader.cpclsManager;

namespace WPFDataReader.ViewModel
{

  public class cpDataReaderViewModel : cpViewModelBase
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private ObservableCollection<cpProductCategory> _colobsCategories = new ObservableCollection<cpProductCategory>();
    private ObservableCollection<cpProduct> _colobsProducts = new ObservableCollection<cpProduct>();
    
    #endregion

    #region "Properties"

    public ObservableCollection<cpProductCategory> Categories
    {

      get
      //***
      // Action Get
      //   - Returns _colobsCategories
      // Called by
      //   - ctrlDataReader
      //   - GetMultipleResultSets()
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20210819 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20210819 – VVDW
      // Keyboard Key
      //   -
      // Proposal(To Do)
      //   -
      //***
      {
        return _colobsCategories;
      }
      // ObservableCollection<cpProductCategory> Categories (Get)

      set
      //***
      // Action Set
      //   - _colobsCategories becomes colobsValue
      //   - RaisePropertyChanged is triggered
      // Called by
      //   - 
      // Calls
      //   - cpCommon.RaisePropertyChanged(String)
      // Created
      //   - CopyPaste – 20210819 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20210819 – VVDW
      // Keyboard Key
      //   -
      // Proposal(To Do)
      //   -
      //***
      {
        _colobsCategories = value;
        RaisePropertyChanged("Categories");
      }
      // Categories(ObservableCollection<cpProductCategory>) (Set)

    }
    // ObservableCollection<Product> Products

    public ObservableCollection<cpProduct> Products
    {

      get
      //***
      // Action Get
      //   - Returns _colobsProducts
      // Called by
      //   - ctrlDataReader
      //   - GetMultipleResultSets()
      //   - ObservableCollection<cpProduct> GetProductsAsGenericList()
      //   - ObservableCollection<cpProduct> GetProductsUsingExtensionMethods()
      //   - ObservableCollection<cpProduct> GetProductsUsingFieldValue()
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20210819 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20210819 – VVDW
      // Keyboard Key
      //   -
      // Proposal(To Do)
      //   -
      //***
      {
        return _colobsProducts;
      }
      // ObservableCollection<Product> Products (Get)

      set
      //***
      // Action Set
      //   - _colobsProducts becomes colobsValue
      //   - RaisePropertyChanged is triggered
      // Called by
      //   -
      // Calls
      //   - cpCommon.RaisePropertyChanged(String)
      // Created
      //   - CopyPaste – 20210819 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20210819 – VVDW
      // Keyboard Key
      //   -
      // Proposal(To Do)
      //   -
      //***
      {
        _colobsProducts = value;
        RaisePropertyChanged("Products");
      }
      // Products(ObservableCollection<cpProduct>) (Set)

    }
    // ObservableCollection<cpProduct> Products

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void GetMultipleResultSets()
    //***
    // Action
    //   - Clear the collection Products
    //   - Clear the collection Categories
    //   - Define SQL Statement (strSQL)
    //   - Create SQL Connection object (cnnSQL) based on application settings inside a nested using block
    //   - Open Connection
    //   - Create SQL Command object (cmdSQL) inside a nested using block
    //   - Create SQL Data Reader (drdSQL) inside a nested using block
    //   - Loop thru records
    //     - Create a new cpProduct with
    //        - Product Key using GetFieldValue (own written helper)
    //        - Product Name using GetFieldValue (own written helper)
    //        - Introduction using GetFieldValue (own written helper)
    //        - Price using GetFieldValue (own written helper)
    //        - Retire (null check) using GetFieldValue (own written helper)
    //        - Product Category (null check) GetFieldValue (own written helper)
    //   - Go to next result
    //   - Loop thru records
    //     - Create a new cpCategory with
    //        - Product Category Key using GetFieldValue (own written helper)
    //        - Category Name using GetFieldValue (own written helper)
    // Called by
    //   - ctrlDataReader.cmdMultipleResultSets_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdMultipleResultSets.Click
    // Calls
    //   - string cpApplicationSetting.ConnectionString (Get)
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //    - GetFieldValue() does not work correctly on nullable fields
    //    - Dates are shown in the wrong format, when the field is nullable (hardcoded solution)
    //***
    {
      Products.Clear();
      Categories.Clear();

      string strSQL = cpProductManager.mcstrProductSQL;
      strSQL += ";" + cpProductManager.mcstrProductCategorySQL;

      using (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))
      {
        cnnSQL.Open();

        using (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))
        {

          using (SqlDataReader drdSQL = cmdSQL.ExecuteReader(CommandBehavior.CloseConnection))
          {

            while (drdSQL.Read())
            {
              Products.Add(new cpProduct
              {
                ProductKey = drdSQL.GetFieldValue<int>("intIdProduct"),
                ProductName = drdSQL.GetFieldValue<string>("strProductName"),
                Introduction = drdSQL.GetFieldValue<DateTime>("dtmIntroduction"),
                Url = drdSQL.GetFieldValue<string>("strUrl"),
                Price = drdSQL.GetFieldValue<decimal>("decPrice"),
                Retire = drdSQL.GetFieldValue<DateTime?>("dtmRetire"),
                ProductCategory = drdSQL.GetFieldValue<int?>("intProductCategoryId")
              });

            }
            // (drdSQL.Read())

            drdSQL.NextResult();

            while (drdSQL.Read())
            {
              Categories.Add(new cpProductCategory
              {
                ProductCategoryKey = drdSQL.GetFieldValue<int>("intIdProductCategory"),
                CategoryName = drdSQL.GetFieldValue<string>("strCategoryName")
              });

            }
            // (drdSQL.Read())

          }
          // (SqlDataReader drdSQL = cmdSQL.ExecuteReader(CommandBehavior.CloseConnection))

        }
        // (SqlCommand cmdSQL = new SqlCommand(strSQL, cnnSQL))

      }
      // (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))

    }
    // GetMultipleResultSets()

    public void GetProductsAsDataReader()
    //***
    // Action
    //   - Define a string builder to store the result
    //   - Create SQL Connection object (cnnSQL) based on application settings inside a nested using block
    //   - Open Connection
    //   - Create SQL Command object (cmdSQL) inside a nested using block
    //   - Create SQL Data Reader (drdSQL) inside a nested using block
    //   - Loop thru records
    //     - Append Product Key to string builder
    //     - Append Product Name to string builder
    //     - Append Introduction date to string builder (local format)
    //     - Append Price to string builder (local currency format)
    //     - Append empty line to string builder
    //   - Show content of string builder on the screen
    // Called by
    //   - ctrlDataReader.cmdDataReader_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdDataReader.Click
    // Calls
    //   - string cpApplicationSetting.ConnectionString (Get)
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //    -
    //***
    {
      StringBuilder strBuildResult = new StringBuilder();

      using (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))
      {
        cnnSQL.Open();

        using (SqlCommand cmdSQL = new SqlCommand(cpProductManager.mcstrProductSQL, cnnSQL))
        {

          using (SqlDataReader drdSQL = cmdSQL.ExecuteReader(CommandBehavior.CloseConnection))
          {
          
            while (drdSQL.Read())
            {
              strBuildResult.AppendLine("Product: " + drdSQL["intIdProduct"].ToString());
              strBuildResult.AppendLine(drdSQL["strProductName"].ToString());
              strBuildResult.AppendLine(Convert.ToDateTime(drdSQL["dtmIntroduction"]).ToShortDateString());
              strBuildResult.AppendLine(Convert.ToDecimal(drdSQL["decPrice"]).ToString("c"));
              strBuildResult.AppendLine();
            }
            // (drdSQL.Read())

          }
          // (SqlDataReader drdSQL = cmdSQL.ExecuteReader(CommandBehavior.CloseConnection))

        }
        // (SqlCommand cmdSQL = new SqlCommand(cpProductManager.mcstrProductSQL, cnnSQL))

      }
      // (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))

      ResultText = strBuildResult.ToString();
    }
    // GetProductsAsDataReader()

    public ObservableCollection<cpProduct> GetProductsAsGenericList()
    //***
    // Action
    //   - Clear the collection Products
    //   - Create SQL Connection object (cnnSQL) based on application settings inside a nested using block
    //   - Open Connection
    //   - Create SQL Command object (cmdSQL) inside a nested using block
    //   - Create SQL Data Reader (drdSQL) inside a nested using block
    //   - Loop thru records
    //     - Create a new cpProduct with
    //        - Product Key using GetOrdinal and conversion to Integer
    //        - Product Name using GetOrdinal and conversion to String
    //        - Introduction using GetOrdinal and conversion to DateTime
    //        - Price using GetOrdinal and conversion to Decimal
    //        - Retire (null check) using GetOrdinal and conversion to DateTime
    //        - Product Category (null check) using GetOrdinal and conversion to Integer
    //   - Return collection of Products
    // Called by
    //   - ctrlDataReader.cmdGenericList_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdGenericList.Click
    // Calls
    //   - ObservableCollection<cpProduct> Products() (Get)
    //   - string cpApplicationSetting.ConnectionString (Get)
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //    - Dates are shown in the wrong format, when the field is nullable
    //***
    {
      Products.Clear();

      using (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))
      {
        cnnSQL.Open();

        using (SqlCommand cmdSQL = new SqlCommand(cpProductManager.mcstrProductSQL, cnnSQL))
        {

          using (SqlDataReader drdSQL = cmdSQL.ExecuteReader(CommandBehavior.CloseConnection))
          {

            while (drdSQL.Read())
            {

              Products.Add(new cpProduct
              {
                ProductKey = drdSQL.GetInt32(drdSQL.GetOrdinal("intIdProduct")),
                ProductName = drdSQL.GetString(drdSQL.GetOrdinal("strProductName")),
                Introduction = drdSQL.GetDateTime(drdSQL.GetOrdinal("dtmIntroduction")),
                Url = drdSQL.GetString(drdSQL.GetOrdinal("strUrl")),
                Price = drdSQL.GetDecimal(drdSQL.GetOrdinal("decPrice")),
                Retire = drdSQL.IsDBNull(drdSQL.GetOrdinal("dtmRetire"))
                                  ? (DateTime?)null
                                  : Convert.ToDateTime(drdSQL["dtmRetire"]),
                ProductCategory = drdSQL.IsDBNull(drdSQL.GetOrdinal("intProductCategoryId"))
                                         ? (int?)null
                                         : Convert.ToInt32(drdSQL["intProductCategoryId"]),
              });

            }
            // (drdSQL.Read())

          }
          // (SqlDataReader drdSQL = cmdSQL.ExecuteReader(CommandBehavior.CloseConnection))

        }
        // (SqlCommand cmdSQL = new SqlCommand(cpProductManager.mcstrProductSQL, cnnSQL))

      }
      // (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))

      return Products;
    }
    // ObservableCollection<cpProduct> GetProductsAsGenericList()

    public ObservableCollection<cpProduct> GetProductsUsingExtensionMethods()
    //***
    // Action
    //   - Clear the collection Products
    //   - Create SQL Connection object (cnnSQL) based on application settings inside a nested using block
    //   - Open Connection
    //   - Create SQL Command object (cmdSQL) inside a nested using block
    //   - Create SQL Data Reader (drdSQL) inside a nested using block
    //   - Loop thru records
    //     - Create a new cpProduct with
    //        - Product Key using GetFieldValue (own written helper)
    //        - Product Name using GetFieldValue (own written helper)
    //        - Introduction using GetFieldValue (own written helper)
    //        - Price using GetFieldValue (own written helper)
    //        - Retire (null check) using GetFieldValue (own written helper)
    //        - Product Category using GetFieldValue (own written helper)
    //   - Return collection of Products
    // Called by
    //   - ctrlDataReader.cmdExtensionMethods_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdExtensionMethods.Click
    // Calls
    //   - ObservableCollection<cpProduct> Products() (Get)
    //   - string cpApplicationSetting.ConnectionString (Get)
    //   - T cpDataReaderHelper.GetFieldValue<T>(SqlDataReader, string)
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //    -
    //***
    {
      Products.Clear();

      using (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))
      {
        cnnSQL.Open();

        using (SqlCommand cmdSQL = new SqlCommand(cpProductManager.mcstrProductSQL, cnnSQL))
        {

          using (SqlDataReader drdSQL = cmdSQL.ExecuteReader(CommandBehavior.CloseConnection))
          {

            while (drdSQL.Read())
            {
              Products.Add(new cpProduct
              {
                ProductKey = drdSQL.GetFieldValue<int>("intIdProduct"),
                ProductName = drdSQL.GetFieldValue<string>("strProductName"),
                Introduction = drdSQL.GetFieldValue<DateTime>("dtmIntroduction"),
                Url = drdSQL.GetFieldValue<string>("strUrl"),
                Price = drdSQL.GetFieldValue<decimal>("decPrice"),
                Retire = drdSQL.GetFieldValue<DateTime?>("dtmRetire"),
                ProductCategory = drdSQL.GetFieldValue<int?>("intProductCategoryId")
              });

            }
            // (drdSQL.Read())

          }
          // (SqlDataReader drdSQL = cmdSQL.ExecuteReader(CommandBehavior.CloseConnection))

        }
        // (SqlCommand cmdSQL = new SqlCommand(cpProductManager.mcstrProductSQL, cnnSQL))

      }
      // (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))

      return Products;
    }
    // ObservableCollection<cpProduct> GetProductsUsingExtensionMethods()

    public ObservableCollection<cpProduct> GetProductsUsingFieldValue()
    //***
    // Action
    //   - Clear the collection Products
    //   - Create SQL Connection object (cnnSQL) based on application settings inside a nested using block
    //   - Open Connection
    //   - Create SQL Command object (cmdSQL) inside a nested using block
    //   - Create SQL Data Reader (drdSQL) inside a nested using block
    //   - Loop thru records
    //     - Create a new cpProduct with
    //        - Product Key using GetOrdinal and GetFieldValue
    //        - Product Name using GetOrdinal and GetFieldValue
    //        - Introduction using GetOrdinal and GetFieldValue
    //        - Price using GetOrdinal and GetFieldValue
    //        - Retire (null check) using GetOrdinal and conversion to DateTime
    //        - Product Category (null check) using GetOrdinal and conversion to Integer
    //   - Return collection of Products
    // Called by
    //   - ctrlDataReader.cmdFieldValue_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdFieldValue.Click
    // Calls
    //   - ObservableCollection<cpProduct> Products() (Get)
    //   - string cpApplicationSetting.ConnectionString (Get)
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //    - GetFieldValue() does not work correctly on nullable fields
    //    - Dates are shown in the wrong format, when the field is nullable (hardcoded solution)
    //***
    {
      Products.Clear();

      using (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))
      {
        cnnSQL.Open();

        using (SqlCommand cmdSQL = new SqlCommand(cpProductManager.mcstrProductSQL, cnnSQL))
        {

          using (SqlDataReader drdSQL = cmdSQL.ExecuteReader(CommandBehavior.CloseConnection))
          {

            while (drdSQL.Read())
            {
              Products.Add(new cpProduct
              {
                ProductKey = drdSQL.GetFieldValue<int>(drdSQL.GetOrdinal("intIdProduct")),
                ProductName = drdSQL.GetFieldValue<string>(drdSQL.GetOrdinal("strProductName")),
                Introduction = drdSQL.GetFieldValue<DateTime>(drdSQL.GetOrdinal("dtmIntroduction")),
                Url = drdSQL.GetFieldValue<string>(drdSQL.GetOrdinal("strUrl")),
                Price = drdSQL.GetFieldValue<decimal>(drdSQL.GetOrdinal("decPrice")),
                // Retire = drdSQL.GetFieldValue<DateTime?>(drdSQL.GetOrdinal("dtmRetire")),
                // ProductCategory = drdSQL.GetFieldValue<int?>(drdSQL.GetOrdinal("intProductCategoryId"))

                Retire = drdSQL.IsDBNull(drdSQL.GetOrdinal("dtmRetire"))
                                  ? (DateTime?)null
                                  : Convert.ToDateTime(drdSQL["dtmRetire"]),
                ProductCategory = drdSQL.IsDBNull(drdSQL.GetOrdinal("intProductCategoryId"))
                                         ? (int?)null
                                         : Convert.ToInt32(drdSQL["intProductCategoryId"])
              });

            }
            // (drdSQL.Read())

          }
          // (SqlDataReader drdSQL = cmdSQL.ExecuteReader(CommandBehavior.CloseConnection))

        }
        // (SqlCommand cmdSQL = new SqlCommand(cpProductManager.mcstrProductSQL, cnnSQL))

      }
      // (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))

      return Products;
    }
    // ObservableCollection<cpProduct> GetProductsUsingFieldValue()

  #endregion

  #endregion

  #endregion

  //#region "Not used"
  //#endregion

  }
  // cpDataReaderViewModel

}
// WPFDataReader.ViewModel