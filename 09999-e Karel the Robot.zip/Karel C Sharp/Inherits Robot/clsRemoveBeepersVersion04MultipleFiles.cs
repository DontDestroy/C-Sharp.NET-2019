﻿//***
// Action
//   - A field of crops must be harvested
// Created
//   - CopyPaste – 20251013 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251013 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpRemoveBeepersVersion04MultipleFiles : cpBadFieldHarvester
	{

		#region "Constructors / Destructors"

		public cpRemoveBeepersVersion04MultipleFiles(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Robot becomes a theColor cpRemoveBeepersVersion04MultipleFiles starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
		//   - Nothing else happens
		// Called by
		//   - cpProgram.RemoveBeepersVersion04MultipleFiles()
		// Calls
		//   - cpBadFieldHarvester(int, int,  Directions.Direction, int, Color)
		// Created
		//   - CopyPaste – 20251013 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251013 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
		}
		// RemoveBeepersVersion04MultipleFiles(int, int, Directions.Direction, int, Color) 

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public void HarvestTheField()
		//***
		// Action
		//   - Harvest two rows
		//   - Set the robot good for the next harvest of 2 rows
		//   - Repeat this another 2 times
		//   - Harvest the last 2 rows
		// Called by
		//   - 
		// Calls
		//   - cpBadFieldHarvester.HarvestTwoRows() (thru inheritance of clsHarvesterVersion01)
		//   - cpBadFieldHarvester.PositionForNextHarvest() (thru inheritance of clsHarvesterVersion01)
		// Created
		//   - CopyPaste – 20251013 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251013 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			move(); // The robot must be placed on the first beeper (looking East)
			HarvestTwoRows();
			PositionForNextHarvest();
			HarvestTwoRows();
			PositionForNextHarvest();
			HarvestTwoRows();
			PositionForNextHarvest();
			HarvestTwoRows();
			move(); // The robot must be placed one further (looking West)
		}
		// HarvestTheField()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// RemoveBeepersVersion04MultipleFiles

}
// cpKarelTheRobot