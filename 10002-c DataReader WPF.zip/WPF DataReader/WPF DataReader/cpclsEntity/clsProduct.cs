﻿//***
// Action
//   - Class implements the Product object
//   - Decided not to document this class in the normal way
// Created
//   - CopyPaste – 20210819 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210819 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace WPFDataReader
{
  public class cpProduct : cpCommon
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    DateTime _dtmIntroduction;
    #endregion

    #region "Properties"
    
    public DateTime Introduction { get; set; }
    public decimal Price { get; set; }
    public int? ProductCategory { get; set; }
    public int ProductKey { get; set; }
    public string ProductName { get; set; }
    public DateTime? Retire { get; set; }
    public string Url { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpProduct 

}
// WPFDataReader