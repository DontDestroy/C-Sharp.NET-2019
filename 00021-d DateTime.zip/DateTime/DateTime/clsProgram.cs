//***
// Action
//   - Some basis stuff with a date time
// Created
//   - CopyPaste � 20240412 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240412 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Get some basis elements out of a date time
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240412 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240412 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      DateTime theDateTime = DateTime.Now;

      Console.WriteLine("Day: " + theDateTime.Day.ToString());
      Console.WriteLine("Month: " + theDateTime.Month.ToString());
      Console.WriteLine("Year: " + theDateTime.Year.ToString());
      Console.WriteLine("Hour: " + theDateTime.Hour.ToString());
      Console.WriteLine("Minute: " + theDateTime.Minute.ToString());
      Console.WriteLine("Second: " + theDateTime.Second.ToString());
      Console.WriteLine("Today: " + DateTime.Today);
      Console.WriteLine("TimeOfDay: " + DateTime.Now.TimeOfDay.ToString());
      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning