﻿'***
' Action
'   - Showing a welcome screen
' Created
'   - CopyPaste – 20260413 – VVDW
' Changed
'   - CopyPaste – yyyymmdd – VVDW – What changed
' Tested
'   - CopyPaste – 20260413 – VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On
Option Strict On

Namespace CopyPaste.Learning

  Partial Public Class wfrmWelcome
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.ID = "wfrmWelcome"
    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

#End Region

    '#Region "Constructors"
    '#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

    '#Region "Fields"
    '#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

#Region "Controls"

    Private Sub cmdStart_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdStart.Click
      '***
      ' Action
      '   - Change the label of the form
      ' Called by
      '   - User action (Clicking a button)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20260413 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260413 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      lblMessage.Text = "Welcome, " & txtName.Text
    End Sub
    ' cmdStart_Click(System.Object, System.EventArgs) Handles cmdStart.Click

    Private Sub Page_Init(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Init
      '***
      ' Action
      '   - Initalize the page
      ' Called by
      '   - User action (Starting the page)
      ' Calls
      '   - InitializeComponent()
      ' Created
      '   - CopyPaste – 20260413 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260413 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      InitializeComponent()
    End Sub
    ' Page_Init(System.Object, System.EventArgs) Handles MyBase.Init

    Private Sub Page_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Load
      '***
      ' Action
      '   - Loading the page
      ' Called by
      '   - User action (Starting the page)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20260413 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260413 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

    End Sub
    ' Page_Load(System.Object, System.EventArgs) Handles MyBase.Load

#End Region

    '#Region "Functionality"

    '#Region "Event"
    '#End Region

    '#Region "Sub / Function"
    '#End Region

    '#End Region

    '#Region "Not used"
    '#End Region

#End Region

  End Class
  ' wfrmWelcome

End Namespace
' CopyPaste.Learning