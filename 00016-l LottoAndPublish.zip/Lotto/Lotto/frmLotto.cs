//***
// Action
//   - Pick 6 numbers out of a list of 45 number (Belgian Lotto rules)
// Created
//   - CopyPaste � 20260705 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260705 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmLotto: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    
    private System.ComponentModel.Container components = null;
    private Button cmdPlay;
    private Button cmdReset;
    private Label lbl01;
    private Label lbl02;
    private Label lbl03;
    private Label lbl04;
    private Label lbl05;
    private Label lbl06;
    private PictureBox picLogo;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLotto));
      this.cmdPlay = new System.Windows.Forms.Button();
      this.cmdReset = new System.Windows.Forms.Button();
      this.lbl01 = new System.Windows.Forms.Label();
      this.lbl02 = new System.Windows.Forms.Label();
      this.lbl03 = new System.Windows.Forms.Label();
      this.lbl04 = new System.Windows.Forms.Label();
      this.lbl05 = new System.Windows.Forms.Label();
      this.lbl06 = new System.Windows.Forms.Label();
      this.picLogo = new System.Windows.Forms.PictureBox();
      ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdPlay
      // 
      this.cmdPlay.Location = new System.Drawing.Point(162, 47);
      this.cmdPlay.Name = "cmdPlay";
      this.cmdPlay.Size = new System.Drawing.Size(94, 23);
      this.cmdPlay.TabIndex = 0;
      this.cmdPlay.Text = "Pick &Numbers";
      this.cmdPlay.UseVisualStyleBackColor = true;
      this.cmdPlay.Click += new System.EventHandler(this.cmdPlay_Click);
      // 
      // cmdReset
      // 
      this.cmdReset.Location = new System.Drawing.Point(285, 47);
      this.cmdReset.Name = "cmdReset";
      this.cmdReset.Size = new System.Drawing.Size(75, 23);
      this.cmdReset.TabIndex = 1;
      this.cmdReset.Text = "&Reset";
      this.cmdReset.UseVisualStyleBackColor = true;
      this.cmdReset.Click += new System.EventHandler(this.cmdReset_Click);
      // 
      // lbl01
      // 
      this.lbl01.AutoSize = true;
      this.lbl01.Location = new System.Drawing.Point(110, 12);
      this.lbl01.Name = "lbl01";
      this.lbl01.Size = new System.Drawing.Size(16, 13);
      this.lbl01.TabIndex = 2;
      this.lbl01.Text = "...";
      // 
      // lbl02
      // 
      this.lbl02.AutoSize = true;
      this.lbl02.Location = new System.Drawing.Point(151, 12);
      this.lbl02.Name = "lbl02";
      this.lbl02.Size = new System.Drawing.Size(16, 13);
      this.lbl02.TabIndex = 3;
      this.lbl02.Text = "...";
      // 
      // lbl03
      // 
      this.lbl03.AutoSize = true;
      this.lbl03.Location = new System.Drawing.Point(192, 12);
      this.lbl03.Name = "lbl03";
      this.lbl03.Size = new System.Drawing.Size(16, 13);
      this.lbl03.TabIndex = 4;
      this.lbl03.Text = "...";
      // 
      // lbl04
      // 
      this.lbl04.AutoSize = true;
      this.lbl04.Location = new System.Drawing.Point(233, 12);
      this.lbl04.Name = "lbl04";
      this.lbl04.Size = new System.Drawing.Size(16, 13);
      this.lbl04.TabIndex = 5;
      this.lbl04.Text = "...";
      // 
      // lbl05
      // 
      this.lbl05.AutoSize = true;
      this.lbl05.Location = new System.Drawing.Point(274, 12);
      this.lbl05.Name = "lbl05";
      this.lbl05.Size = new System.Drawing.Size(16, 13);
      this.lbl05.TabIndex = 6;
      this.lbl05.Text = "...";
      // 
      // lbl06
      // 
      this.lbl06.AutoSize = true;
      this.lbl06.Location = new System.Drawing.Point(315, 12);
      this.lbl06.Name = "lbl06";
      this.lbl06.Size = new System.Drawing.Size(16, 13);
      this.lbl06.TabIndex = 7;
      this.lbl06.Text = "...";
      // 
      // picLogo
      // 
      this.picLogo.Image = global::Lotto.Properties.Resources.LottoLogo;
      this.picLogo.Location = new System.Drawing.Point(12, 12);
      this.picLogo.Name = "picLogo";
      this.picLogo.Size = new System.Drawing.Size(92, 95);
      this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
      this.picLogo.TabIndex = 8;
      this.picLogo.TabStop = false;
      // 
      // frmLotto
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(375, 124);
      this.Controls.Add(this.lbl06);
      this.Controls.Add(this.lbl05);
      this.Controls.Add(this.lbl04);
      this.Controls.Add(this.lbl03);
      this.Controls.Add(this.lbl02);
      this.Controls.Add(this.lbl01);
      this.Controls.Add(this.picLogo);
      this.Controls.Add(this.cmdReset);
      this.Controls.Add(this.cmdPlay);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "frmLotto";
      this.Text = "Belgian Lotto Number Picker";
      ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmLotto'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260706 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260706 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmLotto()
    //***
    // Action
    //   - Create instance of 'frmLotto'
    //   - Run the reset functionality
    //   - Fill the array with the possible numbers
    // Called by
    //   - Main()
    // Calls
    //   - cmdReset_Click(System.Object, System.EventArgs)
    //   - InitializeComponent()
    // Created
    //   - CopyPaste � 20260706 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260706 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      cmdReset_Click(cmdReset, new EventArgs());

      for (int intCounter = 0; intCounter < arrNumbers.Length; )
      {
        arrNumbers[intCounter] = ++intCounter;
      }
      // intCounter = arrNumbers.Length

    }
    // frmLotto()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private const int intMaximum = 45;
    private int[] arrNumbers = new int[intMaximum];
    private Random rndRandomizer = new Random();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdPlay_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Swap the numbers in the array
    //   - Try to 
    //     - Fill the labels with the first six numbers
    //   - Switch the enabled of the buttons
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - Swap()
    // Created
    //   - CopyPaste � 20260706 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260706 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Swap();

      try
      {
        lbl01.Text = arrNumbers[0].ToString();
        lbl02.Text = arrNumbers[1].ToString();
        lbl03.Text = arrNumbers[2].ToString();
        lbl04.Text = arrNumbers[3].ToString();
        lbl05.Text = arrNumbers[4].ToString();
        lbl06.Text = arrNumbers[5].ToString();
      }
      catch
      {
      }
      finally
      {
        cmdPlay.Enabled = false;
        cmdReset.Enabled = true;
      }

    }
    // cmdPlay_Click(System.Object, System.EventArgs) Handles cmdPlay.Click

    private void cmdReset_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Reset the information on the form
    // Called by
    //   - frmLotto()
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260706 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260706 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lbl01.Text = "...";
      lbl02.Text = lbl01.Text;
      lbl03.Text = lbl01.Text;
      lbl04.Text = lbl01.Text;
      lbl05.Text = lbl01.Text;
      lbl06.Text = lbl01.Text;
      cmdPlay.Enabled = true;
      cmdReset.Enabled = false;
    }
    // cmdReset_Click(System.Object, System.EventArgs) Handles cmdReset.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmLotto
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmLotto()
    // Created
    //   - CopyPaste � 20260706 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260706 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmLotto());
    }
    // Main() 

    private void Swap()
    //***
    // Action
    //   - Swap the numbers randomly in the array
    //   - Loop from start to finish
    //     - Take a random number out of the array (position)
    //     - Swap the elements
    // Called by
    //   - cmdPlay_Click(System.Object, System.EventArgs) Handles cmdPlay.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260706 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260706 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intHelper;
      int intPosition;

      for (int intCounter = 0; intCounter < intMaximum; intCounter++)
      {
        intPosition = rndRandomizer.Next(0, intMaximum);
        intHelper = arrNumbers[intCounter];
        arrNumbers[intCounter] = arrNumbers[intPosition];
        arrNumbers[intPosition] = intHelper;
      }
      // intCounter = intMaximum

    }
    // Swap()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmLotto

}
// CopyPaste.Learning