﻿//***
// Action
//   - Testroutine for cpCamera, cpBasicCamera, cpSpecialCamera, cpiShare, cpWhatsApp, cpEmail, cpTextBySMS
// Created
//   - CopyPaste – 20240810 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240810 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Camera.Library;
using System.Diagnostics;

namespace CopyPaste.Camera.Test
{

	internal static class cpProgram
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		///  The main entry point for the test application
		/// </summary>
		public static void Main()
		//***
		// Action
		//   - Start application
		//   - Create a list of cpCamera
		//   - Add a cpBasicCamera and a cpSpecialCamera to it
		//   - Loop thru all the cameras
		//     - Let the camera Take, Save, Edit and Share a photo
		//   - Show some information on where to check if it was successful
		//   - Wait for the user to hit the keyboard
		// Called by
		//   - User action (Starting the application)
		// Calls
		//   - CopyPaste.Camera.Library.
		// Created
		//   - CopyPaste – 20240810 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240810 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			List<cpCamera> lstCameras = new List<cpCamera>();

			cpBasicCamera aBasicCamera = new cpBasicCamera();
			cpSpecialCamera aSpecialCamera = new cpSpecialCamera();

			lstCameras.Add(aBasicCamera);
			lstCameras.Add(aSpecialCamera);

			Console.WriteLine("Deciding what behaviour the cameras for sharing has in the list");

			foreach (cpCamera theCamera in lstCameras)
			{
				ConsoleKeyInfo ckiAnswer;
				string strType = theCamera.GetType().Name;
				
				Console.WriteLine("Give the way a {0} is sharing photos (<E>mail, <T>ext or <W>hatsApp)", strType);
				ckiAnswer = Console.ReadKey();
				Console.WriteLine();

				switch (ckiAnswer.KeyChar)
				{
					case 'E':
						theCamera.HowToShare = new cpEmail();
						break;
					case 'T':
						theCamera.HowToShare = new cpTextBySMS();
						break;
					case 'W':
						theCamera.HowToShare = new cpWhatsApp();
						break;
					default:
						Console.WriteLine("Key is not accepted, behaviour is not changed.");
						break;
				}
				// ckiAnswer.KeyChar

			}
			// in lstCameras

			Debug.Print("Executing the behaviour of all the cameras in the list");
			Debug.Print("");

			foreach (cpCamera theCamera in lstCameras)
			{
				string strType = theCamera.GetType().Name;

				Debug.Print(strType);
				theCamera.Take();
				theCamera.Save();
				theCamera.Edit();
				theCamera.Share();
				Debug.Print("");
			}
			// in lstCameras

			Console.WriteLine("Information about the execution of methods can be found in the immeadiate / output window");
			Console.WriteLine();
			Console.WriteLine("Hit any key to exit the program ...");
			Console.ReadLine();
		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#Region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.Camera.Test