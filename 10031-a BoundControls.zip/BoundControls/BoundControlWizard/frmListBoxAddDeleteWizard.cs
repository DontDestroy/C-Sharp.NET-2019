//***
// Action
//   - Add and delete records using bound controls
// Created
//   - CopyPaste � 20251231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251231 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmListBoxAddDeleteWizard: System.Windows.Forms.Form
  {
    private IContainer components;

    #region Windows Form Designer generated code
    internal System.Windows.Forms.Button cmdLoadList;
    internal System.Windows.Forms.GroupBox grpInfoCustomer;
    internal System.Windows.Forms.TextBox txtFax;
    internal System.Windows.Forms.TextBox txtCompanyName;
    internal System.Windows.Forms.TextBox txtAddress;
    internal System.Windows.Forms.TextBox txtContactTitle;
    internal System.Windows.Forms.TextBox txtIdCustomer;
    internal System.Windows.Forms.TextBox txtContact;
    internal System.Windows.Forms.TextBox txtCountry;
    internal System.Windows.Forms.TextBox txtCity;
    internal System.Windows.Forms.TextBox txtPostalCode;
    internal System.Windows.Forms.TextBox txtRegion;
    internal System.Windows.Forms.TextBox txtPhone;
    internal System.Windows.Forms.Label lblContactTitle;
    internal System.Windows.Forms.Label lblFax;
    internal System.Windows.Forms.Label lblRegion;
    internal System.Windows.Forms.Label lblCountry;
    internal System.Windows.Forms.Label lblPostalCode;
    internal System.Windows.Forms.Label lblCity;
    internal System.Windows.Forms.Label lblAddress;
    internal System.Windows.Forms.Label lblCustomerName;
    internal System.Windows.Forms.Label lblContact;
    internal System.Windows.Forms.Label lblIdCustomer;
    internal System.Windows.Forms.Label lblPhone;
    internal System.Windows.Forms.ListBox lstCustomer;
    internal System.Windows.Forms.GroupBox fraAction;
    internal System.Windows.Forms.Button cmdDelete;
    internal System.Windows.Forms.Button cmdNew;
    internal System.Windows.Forms.Button cmdSave;
    internal System.Windows.Forms.Button cmdCancel;
    internal System.Windows.Forms.Button cmdEdit;
    internal System.Windows.Forms.Label lblCustomer;
    private BindingSource bdsrcCustomerInfo;
    private BoundControlWizard.dsCustomerInfo dsCustomerInfo;
    private BindingSource bdsrcCustomerFilter;
    private BoundControlWizard.dsCustomerFilter dsCustomerFilter;
    private BoundControlWizard.dsCustomerFilterTableAdapters.tbaCustomerFilter tbaCustomerFilter;
    private BoundControlWizard.dsCustomerInfoTableAdapters.tbaCustomerInfo tbaCustomerInfo;
    internal System.Windows.Forms.TextBox txtCustomerLimit;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmListBoxAddDeleteWizard));
      this.cmdLoadList = new System.Windows.Forms.Button();
      this.grpInfoCustomer = new System.Windows.Forms.GroupBox();
      this.txtFax = new System.Windows.Forms.TextBox();
      this.txtCompanyName = new System.Windows.Forms.TextBox();
      this.txtAddress = new System.Windows.Forms.TextBox();
      this.txtContactTitle = new System.Windows.Forms.TextBox();
      this.txtIdCustomer = new System.Windows.Forms.TextBox();
      this.txtContact = new System.Windows.Forms.TextBox();
      this.txtCountry = new System.Windows.Forms.TextBox();
      this.txtCity = new System.Windows.Forms.TextBox();
      this.txtPostalCode = new System.Windows.Forms.TextBox();
      this.txtRegion = new System.Windows.Forms.TextBox();
      this.txtPhone = new System.Windows.Forms.TextBox();
      this.lblContactTitle = new System.Windows.Forms.Label();
      this.lblFax = new System.Windows.Forms.Label();
      this.lblRegion = new System.Windows.Forms.Label();
      this.lblCountry = new System.Windows.Forms.Label();
      this.lblPostalCode = new System.Windows.Forms.Label();
      this.lblCity = new System.Windows.Forms.Label();
      this.lblAddress = new System.Windows.Forms.Label();
      this.lblCustomerName = new System.Windows.Forms.Label();
      this.lblContact = new System.Windows.Forms.Label();
      this.lblIdCustomer = new System.Windows.Forms.Label();
      this.lblPhone = new System.Windows.Forms.Label();
      this.lstCustomer = new System.Windows.Forms.ListBox();
      this.fraAction = new System.Windows.Forms.GroupBox();
      this.cmdDelete = new System.Windows.Forms.Button();
      this.cmdNew = new System.Windows.Forms.Button();
      this.cmdSave = new System.Windows.Forms.Button();
      this.cmdCancel = new System.Windows.Forms.Button();
      this.cmdEdit = new System.Windows.Forms.Button();
      this.lblCustomer = new System.Windows.Forms.Label();
      this.txtCustomerLimit = new System.Windows.Forms.TextBox();
      this.bdsrcCustomerInfo = new System.Windows.Forms.BindingSource(this.components);
      this.dsCustomerInfo = new BoundControlWizard.dsCustomerInfo();
      this.bdsrcCustomerFilter = new System.Windows.Forms.BindingSource(this.components);
      this.dsCustomerFilter = new BoundControlWizard.dsCustomerFilter();
      this.tbaCustomerFilter = new BoundControlWizard.dsCustomerFilterTableAdapters.tbaCustomerFilter();
      this.tbaCustomerInfo = new BoundControlWizard.dsCustomerInfoTableAdapters.tbaCustomerInfo();
      this.grpInfoCustomer.SuspendLayout();
      this.fraAction.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCustomerInfo)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomerInfo)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCustomerFilter)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomerFilter)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdLoadList
      // 
      this.cmdLoadList.Location = new System.Drawing.Point(288, 6);
      this.cmdLoadList.Name = "cmdLoadList";
      this.cmdLoadList.Size = new System.Drawing.Size(88, 24);
      this.cmdLoadList.TabIndex = 8;
      this.cmdLoadList.Text = "Load List";
      this.cmdLoadList.Click += new System.EventHandler(this.cmdLoadList_Click);
      // 
      // grpInfoCustomer
      // 
      this.grpInfoCustomer.Controls.Add(this.txtFax);
      this.grpInfoCustomer.Controls.Add(this.txtCompanyName);
      this.grpInfoCustomer.Controls.Add(this.txtAddress);
      this.grpInfoCustomer.Controls.Add(this.txtContactTitle);
      this.grpInfoCustomer.Controls.Add(this.txtIdCustomer);
      this.grpInfoCustomer.Controls.Add(this.txtContact);
      this.grpInfoCustomer.Controls.Add(this.txtCountry);
      this.grpInfoCustomer.Controls.Add(this.txtCity);
      this.grpInfoCustomer.Controls.Add(this.txtPostalCode);
      this.grpInfoCustomer.Controls.Add(this.txtRegion);
      this.grpInfoCustomer.Controls.Add(this.txtPhone);
      this.grpInfoCustomer.Controls.Add(this.lblContactTitle);
      this.grpInfoCustomer.Controls.Add(this.lblFax);
      this.grpInfoCustomer.Controls.Add(this.lblRegion);
      this.grpInfoCustomer.Controls.Add(this.lblCountry);
      this.grpInfoCustomer.Controls.Add(this.lblPostalCode);
      this.grpInfoCustomer.Controls.Add(this.lblCity);
      this.grpInfoCustomer.Controls.Add(this.lblAddress);
      this.grpInfoCustomer.Controls.Add(this.lblCustomerName);
      this.grpInfoCustomer.Controls.Add(this.lblContact);
      this.grpInfoCustomer.Controls.Add(this.lblIdCustomer);
      this.grpInfoCustomer.Controls.Add(this.lblPhone);
      this.grpInfoCustomer.Location = new System.Drawing.Point(384, 28);
      this.grpInfoCustomer.Name = "grpInfoCustomer";
      this.grpInfoCustomer.Size = new System.Drawing.Size(296, 304);
      this.grpInfoCustomer.TabIndex = 10;
      this.grpInfoCustomer.TabStop = false;
      this.grpInfoCustomer.Text = "Info customer";
      // 
      // txtFax
      // 
      this.txtFax.BackColor = System.Drawing.SystemColors.Control;
      this.txtFax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtFax.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCustomerInfo, "strFax", true));
      this.txtFax.Enabled = false;
      this.txtFax.Location = new System.Drawing.Point(120, 272);
      this.txtFax.Name = "txtFax";
      this.txtFax.Size = new System.Drawing.Size(160, 20);
      this.txtFax.TabIndex = 21;
      // 
      // txtCompanyName
      // 
      this.txtCompanyName.BackColor = System.Drawing.SystemColors.Control;
      this.txtCompanyName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCompanyName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCustomerInfo, "strCompanyName", true));
      this.txtCompanyName.Enabled = false;
      this.txtCompanyName.Location = new System.Drawing.Point(120, 56);
      this.txtCompanyName.Name = "txtCompanyName";
      this.txtCompanyName.Size = new System.Drawing.Size(160, 20);
      this.txtCompanyName.TabIndex = 3;
      // 
      // txtAddress
      // 
      this.txtAddress.BackColor = System.Drawing.SystemColors.Control;
      this.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtAddress.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCustomerInfo, "strAddress", true));
      this.txtAddress.Enabled = false;
      this.txtAddress.Location = new System.Drawing.Point(120, 128);
      this.txtAddress.Name = "txtAddress";
      this.txtAddress.Size = new System.Drawing.Size(160, 20);
      this.txtAddress.TabIndex = 9;
      // 
      // txtContactTitle
      // 
      this.txtContactTitle.BackColor = System.Drawing.SystemColors.Control;
      this.txtContactTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtContactTitle.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCustomerInfo, "strContactTitle", true));
      this.txtContactTitle.Enabled = false;
      this.txtContactTitle.Location = new System.Drawing.Point(120, 104);
      this.txtContactTitle.Name = "txtContactTitle";
      this.txtContactTitle.Size = new System.Drawing.Size(160, 20);
      this.txtContactTitle.TabIndex = 7;
      // 
      // txtIdCustomer
      // 
      this.txtIdCustomer.BackColor = System.Drawing.SystemColors.Control;
      this.txtIdCustomer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtIdCustomer.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCustomerInfo, "strIdCustomer", true));
      this.txtIdCustomer.Enabled = false;
      this.txtIdCustomer.Location = new System.Drawing.Point(120, 32);
      this.txtIdCustomer.Name = "txtIdCustomer";
      this.txtIdCustomer.Size = new System.Drawing.Size(160, 20);
      this.txtIdCustomer.TabIndex = 1;
      // 
      // txtContact
      // 
      this.txtContact.BackColor = System.Drawing.SystemColors.Control;
      this.txtContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtContact.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCustomerInfo, "strContactName", true));
      this.txtContact.Enabled = false;
      this.txtContact.Location = new System.Drawing.Point(120, 80);
      this.txtContact.Name = "txtContact";
      this.txtContact.Size = new System.Drawing.Size(160, 20);
      this.txtContact.TabIndex = 5;
      // 
      // txtCountry
      // 
      this.txtCountry.BackColor = System.Drawing.SystemColors.Control;
      this.txtCountry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCountry.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCustomerInfo, "strCountry", true));
      this.txtCountry.Enabled = false;
      this.txtCountry.Location = new System.Drawing.Point(120, 224);
      this.txtCountry.Name = "txtCountry";
      this.txtCountry.Size = new System.Drawing.Size(160, 20);
      this.txtCountry.TabIndex = 17;
      // 
      // txtCity
      // 
      this.txtCity.BackColor = System.Drawing.SystemColors.Control;
      this.txtCity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCity.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCustomerInfo, "strCity", true));
      this.txtCity.Enabled = false;
      this.txtCity.Location = new System.Drawing.Point(120, 152);
      this.txtCity.Name = "txtCity";
      this.txtCity.Size = new System.Drawing.Size(160, 20);
      this.txtCity.TabIndex = 11;
      // 
      // txtPostalCode
      // 
      this.txtPostalCode.BackColor = System.Drawing.SystemColors.Control;
      this.txtPostalCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtPostalCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCustomerInfo, "strPostalCode", true));
      this.txtPostalCode.Enabled = false;
      this.txtPostalCode.Location = new System.Drawing.Point(120, 200);
      this.txtPostalCode.Name = "txtPostalCode";
      this.txtPostalCode.Size = new System.Drawing.Size(160, 20);
      this.txtPostalCode.TabIndex = 15;
      // 
      // txtRegion
      // 
      this.txtRegion.BackColor = System.Drawing.SystemColors.Control;
      this.txtRegion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtRegion.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCustomerInfo, "strRegion", true));
      this.txtRegion.Enabled = false;
      this.txtRegion.Location = new System.Drawing.Point(120, 176);
      this.txtRegion.Name = "txtRegion";
      this.txtRegion.Size = new System.Drawing.Size(160, 20);
      this.txtRegion.TabIndex = 13;
      // 
      // txtPhone
      // 
      this.txtPhone.BackColor = System.Drawing.SystemColors.Control;
      this.txtPhone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtPhone.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcCustomerInfo, "strPhone", true));
      this.txtPhone.Enabled = false;
      this.txtPhone.Location = new System.Drawing.Point(120, 248);
      this.txtPhone.Name = "txtPhone";
      this.txtPhone.Size = new System.Drawing.Size(160, 20);
      this.txtPhone.TabIndex = 19;
      // 
      // lblContactTitle
      // 
      this.lblContactTitle.Location = new System.Drawing.Point(16, 104);
      this.lblContactTitle.Name = "lblContactTitle";
      this.lblContactTitle.Size = new System.Drawing.Size(88, 16);
      this.lblContactTitle.TabIndex = 6;
      this.lblContactTitle.Text = "Contact Title";
      // 
      // lblFax
      // 
      this.lblFax.Location = new System.Drawing.Point(16, 272);
      this.lblFax.Name = "lblFax";
      this.lblFax.Size = new System.Drawing.Size(88, 16);
      this.lblFax.TabIndex = 20;
      this.lblFax.Text = "Fax";
      // 
      // lblRegion
      // 
      this.lblRegion.Location = new System.Drawing.Point(16, 176);
      this.lblRegion.Name = "lblRegion";
      this.lblRegion.Size = new System.Drawing.Size(88, 16);
      this.lblRegion.TabIndex = 12;
      this.lblRegion.Text = "Region";
      // 
      // lblCountry
      // 
      this.lblCountry.Location = new System.Drawing.Point(16, 224);
      this.lblCountry.Name = "lblCountry";
      this.lblCountry.Size = new System.Drawing.Size(88, 16);
      this.lblCountry.TabIndex = 16;
      this.lblCountry.Text = "Country";
      // 
      // lblPostalCode
      // 
      this.lblPostalCode.Location = new System.Drawing.Point(16, 200);
      this.lblPostalCode.Name = "lblPostalCode";
      this.lblPostalCode.Size = new System.Drawing.Size(88, 16);
      this.lblPostalCode.TabIndex = 14;
      this.lblPostalCode.Text = "Postal Code";
      // 
      // lblCity
      // 
      this.lblCity.Location = new System.Drawing.Point(16, 152);
      this.lblCity.Name = "lblCity";
      this.lblCity.Size = new System.Drawing.Size(88, 16);
      this.lblCity.TabIndex = 10;
      this.lblCity.Text = "City";
      // 
      // lblAddress
      // 
      this.lblAddress.Location = new System.Drawing.Point(16, 128);
      this.lblAddress.Name = "lblAddress";
      this.lblAddress.Size = new System.Drawing.Size(88, 16);
      this.lblAddress.TabIndex = 8;
      this.lblAddress.Text = "Address";
      // 
      // lblCustomerName
      // 
      this.lblCustomerName.Location = new System.Drawing.Point(16, 56);
      this.lblCustomerName.Name = "lblCustomerName";
      this.lblCustomerName.Size = new System.Drawing.Size(88, 16);
      this.lblCustomerName.TabIndex = 2;
      this.lblCustomerName.Text = "Company Name";
      // 
      // lblContact
      // 
      this.lblContact.Location = new System.Drawing.Point(16, 80);
      this.lblContact.Name = "lblContact";
      this.lblContact.Size = new System.Drawing.Size(88, 16);
      this.lblContact.TabIndex = 4;
      this.lblContact.Text = "Contact";
      // 
      // lblIdCustomer
      // 
      this.lblIdCustomer.Location = new System.Drawing.Point(16, 32);
      this.lblIdCustomer.Name = "lblIdCustomer";
      this.lblIdCustomer.Size = new System.Drawing.Size(88, 16);
      this.lblIdCustomer.TabIndex = 0;
      this.lblIdCustomer.Text = "Customer Key";
      // 
      // lblPhone
      // 
      this.lblPhone.Location = new System.Drawing.Point(16, 248);
      this.lblPhone.Name = "lblPhone";
      this.lblPhone.Size = new System.Drawing.Size(88, 16);
      this.lblPhone.TabIndex = 18;
      this.lblPhone.Text = "Phone";
      // 
      // lstCustomer
      // 
      this.lstCustomer.DataSource = this.bdsrcCustomerFilter;
      this.lstCustomer.DisplayMember = "strCompanyName";
      this.lstCustomer.Location = new System.Drawing.Point(8, 36);
      this.lstCustomer.Name = "lstCustomer";
      this.lstCustomer.Size = new System.Drawing.Size(368, 290);
      this.lstCustomer.TabIndex = 9;
      this.lstCustomer.ValueMember = "strIdCustomer";
      this.lstCustomer.SelectedIndexChanged += new System.EventHandler(this.lstCustomer_SelectedIndexChanged);
      // 
      // fraAction
      // 
      this.fraAction.Controls.Add(this.cmdDelete);
      this.fraAction.Controls.Add(this.cmdNew);
      this.fraAction.Controls.Add(this.cmdSave);
      this.fraAction.Controls.Add(this.cmdCancel);
      this.fraAction.Controls.Add(this.cmdEdit);
      this.fraAction.Location = new System.Drawing.Point(688, 30);
      this.fraAction.Name = "fraAction";
      this.fraAction.Size = new System.Drawing.Size(112, 304);
      this.fraAction.TabIndex = 11;
      this.fraAction.TabStop = false;
      this.fraAction.Text = "Actions";
      // 
      // cmdDelete
      // 
      this.cmdDelete.Location = new System.Drawing.Point(16, 120);
      this.cmdDelete.Name = "cmdDelete";
      this.cmdDelete.Size = new System.Drawing.Size(88, 32);
      this.cmdDelete.TabIndex = 2;
      this.cmdDelete.Text = "&Delete";
      this.cmdDelete.Click += new System.EventHandler(this.cmdDelete_Click);
      // 
      // cmdNew
      // 
      this.cmdNew.Location = new System.Drawing.Point(16, 72);
      this.cmdNew.Name = "cmdNew";
      this.cmdNew.Size = new System.Drawing.Size(88, 32);
      this.cmdNew.TabIndex = 1;
      this.cmdNew.Text = "&New";
      this.cmdNew.Click += new System.EventHandler(this.cmdNew_Click);
      // 
      // cmdSave
      // 
      this.cmdSave.Enabled = false;
      this.cmdSave.Location = new System.Drawing.Point(16, 168);
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.Size = new System.Drawing.Size(88, 32);
      this.cmdSave.TabIndex = 3;
      this.cmdSave.Text = "&Save";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // cmdCancel
      // 
      this.cmdCancel.Enabled = false;
      this.cmdCancel.Location = new System.Drawing.Point(16, 264);
      this.cmdCancel.Name = "cmdCancel";
      this.cmdCancel.Size = new System.Drawing.Size(88, 32);
      this.cmdCancel.TabIndex = 4;
      this.cmdCancel.Text = "C&ancel";
      this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
      // 
      // cmdEdit
      // 
      this.cmdEdit.Location = new System.Drawing.Point(16, 24);
      this.cmdEdit.Name = "cmdEdit";
      this.cmdEdit.Size = new System.Drawing.Size(88, 32);
      this.cmdEdit.TabIndex = 0;
      this.cmdEdit.Text = "&Edit";
      this.cmdEdit.Click += new System.EventHandler(this.cmdEdit_Click);
      // 
      // lblCustomer
      // 
      this.lblCustomer.Location = new System.Drawing.Point(8, 6);
      this.lblCustomer.Name = "lblCustomer";
      this.lblCustomer.Size = new System.Drawing.Size(56, 16);
      this.lblCustomer.TabIndex = 6;
      this.lblCustomer.Text = "Customer";
      // 
      // txtCustomerLimit
      // 
      this.txtCustomerLimit.Location = new System.Drawing.Point(72, 6);
      this.txtCustomerLimit.Name = "txtCustomerLimit";
      this.txtCustomerLimit.Size = new System.Drawing.Size(208, 20);
      this.txtCustomerLimit.TabIndex = 7;
      this.txtCustomerLimit.Text = "A";
      // 
      // bdsrcCustomerInfo
      // 
      this.bdsrcCustomerInfo.DataMember = "tblCPCustomer";
      this.bdsrcCustomerInfo.DataSource = this.dsCustomerInfo;
      // 
      // dsCustomerInfo
      // 
      this.dsCustomerInfo.DataSetName = "dsCustomerInfo";
      this.dsCustomerInfo.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // bdsrcCustomerFilter
      // 
      this.bdsrcCustomerFilter.DataMember = "tblCPCustomer";
      this.bdsrcCustomerFilter.DataSource = this.dsCustomerFilter;
      // 
      // dsCustomerFilter
      // 
      this.dsCustomerFilter.DataSetName = "dsCustomerFilter";
      this.dsCustomerFilter.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // tbaCustomerFilter
      // 
      this.tbaCustomerFilter.ClearBeforeFill = true;
      // 
      // tbaCustomerInfo
      // 
      this.tbaCustomerInfo.ClearBeforeFill = true;
      // 
      // frmListBoxAddDeleteWizard
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(808, 341);
      this.Controls.Add(this.fraAction);
      this.Controls.Add(this.lblCustomer);
      this.Controls.Add(this.txtCustomerLimit);
      this.Controls.Add(this.cmdLoadList);
      this.Controls.Add(this.grpInfoCustomer);
      this.Controls.Add(this.lstCustomer);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmListBoxAddDeleteWizard";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Add and Delete Records Using Bound Controls Wizard";
      this.Load += new System.EventHandler(this.frmListBoxAddDeleteWizard_Load);
      this.grpInfoCustomer.ResumeLayout(false);
      this.grpInfoCustomer.PerformLayout();
      this.fraAction.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCustomerInfo)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomerInfo)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCustomerFilter)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomerFilter)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmListBoxAddDeleteWizard'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmListBoxAddDeleteWizard()
      //***
      // Action
      //   - Create instance of 'frmListBoxAddDeleteWizard'
      // Called by
      //   - frmBoundControlsMainWizard.cmdListBoxAddDelete_Click(System.Object, System.EventArgs) Handles cmdListBoxAddDelete.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmListBoxAddDeleteWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdCancel_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Cancel the current edits of the context
      //   - Disable the editing of the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ActivateEditing(bool)
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcCustomerInfo.CancelEdit();
      ActivateEditing(false);
    }
    // cmdCancel_Click(System.Object, System.EventArgs) Handles cmdCancel.Click

    private void cmdDelete_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If a record is selected in the list box
      //     - Remove the record that is selected form the data set
      //     - Update the data set thru the data adapter
      //     - Accept the changes
      //     - Disable the editing
      //     - Load the list (because a record is deleted)
      //     - Refresh the current record (because a record is deleted)
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ActivateEditing(bool)
      //   - LoadList()
      //   - RefreshIndividual()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (lstCustomer.SelectedIndex == -1)
      {
      }
      else
      // lstCustomer.SelectedIndex <> -1
      {
        bdsrcCustomerInfo.RemoveAt(bdsrcCustomerInfo.Position);
        tbaCustomerInfo.Update(dsCustomerInfo);
        dsCustomerInfo.AcceptChanges();
        ActivateEditing(false);
        LoadList();
        RefreshIndividual();
      }
      // lstCustomer.SelectedIndex = -1

    }
    // cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click

    private void cmdEdit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If a record is selected in the list box
      //     - Activate the editing
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ActivateEditing(bool)
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (lstCustomer.SelectedIndex == -1)
      {
      }
      else
      // lstCustomer.SelectedIndex <> -1
      {
        ActivateEditing(true);
      }
      // lstCustomer.SelectedIndex = -1

    }
    // cmdEdit_Click(System.Object, System.EventArgs) Handles cmdEdit.Click

    private void cmdLoadList_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Load the list
      //   - Show the currently selected record in detail
      // Called by
      //   - frmListBoxAddDeleteWizard_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - LoadList()
      //   - RefreshIndividual()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      LoadList();
      RefreshIndividual();
    }
    // cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click

    private void cmdNew_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Add a new record to the data set of customer
      //   - Enable the editing of the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ActivateEditing(bool)
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcCustomerInfo.AddNew();
      ActivateEditing(true);
    }
    // cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click

    private void cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Save the record
      //   - Disable the editing of the form
      //   - Load the list (because data can be changed)
      //   - Refresh the detailed information (because record can be changed)
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ActivateEditing(bool)
      //   - LoadList()
      //   - RefreshIndividual()
      //   - SaveRecord()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      SaveRecord();
      ActivateEditing(false);
      LoadList();
      RefreshIndividual();
    }
    // cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click

    private void frmListBoxAddDeleteWizard_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Run the code that is executed when you click the LoadList button 
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click   
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cmdLoadList_Click(new System.Object(), new System.EventArgs());
    }
    // frmListBoxAddDeleteWizard_Load(System.Object, System.EventArgs) Handles this.Load

    private void lstCustomer_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Refresh the current information
      // Called by
      //   - User action (Choosing item in list box)
      // Calls
      //   - RefreshIndividual()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      RefreshIndividual();
    }
    // lstCustomer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstCustomer.SelectedIndexChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void ActivateEditing(bool blnEnable)
      //***
      // Action
      //   - Define two controls
      //   - Loop thru the controls of the form
      //     - If the control is a groupbox
      //       - Loop thru the controls of the groupbox
      //         - If the control is a textbox
      //           - Define a new textbox
      //           - Assign the textbox
      //           - If boolean enabled
      //             - Change borderstyle to Fixed3D and colour to white
      //           - If not
      //             - Change borderstyle to FixedSingle and colour to the backcolor of the form
      //           - Set enabled of textbox to the boolean
      //         - If not
      //           - Do nothing
      //     - If not
      //       - Do nothing
      //   - Change the enabled of cmdCancel to boolean
      //   - Change the enabled of cmdSave to boolean
      // Called by
      //   - cmdCancel_Click(System.Object, System.EventArgs) Handles cmdCancel.Click
      //   - cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click
      //   - cmdEdit_Click(System.Object, System.EventArgs) Handles cmdEdit.Click
      //   - cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      //   - cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      foreach (Control ctlCurrent in this.Controls)
      {

        if (ctlCurrent.GetType() == typeof(GroupBox))
        {

          foreach (Control ctlCurrentInGroupBox in ctlCurrent.Controls)
          {

            if (ctlCurrentInGroupBox.GetType() == typeof(TextBox))
            {
              TextBox ctlTextBox = new TextBox();

              ctlTextBox = (TextBox)ctlCurrentInGroupBox;

              if (blnEnable)
              {
                ctlTextBox.BorderStyle = BorderStyle.Fixed3D;
                ctlCurrentInGroupBox.BackColor = Color.White;
              }
              else
              // Not blnEnable
              {
                ctlTextBox.BorderStyle = BorderStyle.FixedSingle;
                ctlCurrentInGroupBox.BackColor = BackColor;
              }
              // blnEnable

              ctlCurrentInGroupBox.Enabled = blnEnable;
            }
            else
            // ctlCurrentInGroupBox.GetType() <> typeof(TextBox)
            {
            }
            // ctlCurrentInGroupBox.GetType() = typeof(TextBox)

          }
          // In ctlCurrent.Controls

        }
        else
        // ctlCurrent.GetType() <> typeof(GroupBox)
        {
        }
        // ctlCurrent.GetType() = typeof(GroupBox)

      }
      // in Controls()

      cmdCancel.Enabled = blnEnable;
      cmdSave.Enabled = blnEnable;
    }
    // ActivateEditing(bool)

    private void LoadList()
      //***
      // Action
      //   - Set the parameter of the select command to the text on the form
      //   - Clear the data set
      //   - Fill the data set using the data adapter
      // Called by
      //   - cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click
      //   - cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click
      //   - cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsCustomerFilter.Clear();
      tbaCustomerFilter.Fill(dsCustomerFilter.tblCPCustomer, txtCustomerLimit.Text);
    }
    // LoadList()

    private void RefreshIndividual()
      //***
      // Action
      //   - Clear the data set with detailed information
      //   - If an item is selected in the listbox
      //     - Define and set a data row view with the currently selected item
      //     - Set the parameter to the data table select command to select the correct customer
      //     - Fill the data set using the data adapter
      //   - If not
      //     - Do nothing
      // Called by
      //   - cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click
      //   - cmdDelete_Click(System.Object, System.EventArgs) Handles cmdDelete.Click
      //   - cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      //   - lstCustomer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstCustomer.SelectedIndexChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsCustomerInfo.Clear();

      if (lstCustomer.SelectedIndex == -1)
      {
      }
      else
      // lstCustomer.SelectedIndex <> -1
      {
        DataRowView drvCustomer = (DataRowView)lstCustomer.SelectedItem;

        tbaCustomerInfo.Fill(dsCustomerInfo.tblCPCustomer, drvCustomer["strIdCustomer"].ToString());
      }
      // lstCustomer.SelectedIndex = -1

    }
    // RefreshIndividual()

    private void SaveRecord()
      //***
      // Action
      //   - Stop editing the context
      //   - Update the data set using the data adapter
      //   - Accept the changes
      // Called by
      //   - cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcCustomerInfo.EndEdit();
      tbaCustomerInfo.Adapter.Update(dsCustomerInfo);
      dsCustomerInfo.AcceptChanges();
    }
    // SaveRecord()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmListBoxAddDeleteWizard

}
// CopyPaste.Learning