﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmPost1.aspx.cs" Inherits="CopyPaste.Learning.wfrmPost1" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Post</title>
</head>
<body>
  <form id="wfrmPost1" method="post" action="wfrmPost2.aspx" runat="server">
    <asp:Label ID="lblName" Style="z-index: 106; position: absolute; top: 104px; left: 64px" runat="server">Name</asp:Label>
    <asp:Button ID="cmdOK" PostBackUrl="./wfrmPost2.aspx" Style="z-index: 105; position: absolute; top: 184px; left: 64px" runat="server"
      Text="OK" TabIndex="3"></asp:Button>
    <asp:TextBox ID="txtEmail" Style="z-index: 104; position: absolute; top: 144px; left: 136px"
      runat="server" TabIndex="2"></asp:TextBox>
    <asp:TextBox ID="txtName" Style="z-index: 103; position: absolute; top: 104px; left: 136px" runat="server"
      TabIndex="1"></asp:TextBox>
    <asp:Label ID="lblEmail" Style="z-index: 102; position: absolute; top: 144px; left: 64px" runat="server">E-mail</asp:Label>
  </form>
</body>
</html>
