//***
// Action
//   - Example to show the Intermediate Language Disassembler
// Created
//   - CopyPaste � 20220105 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220105 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace IntermediateLanguageDisassembler
{

  class cpIntermediateLanguageDisassembler
	{

    static void Main()
    //***
    // Action
    //   - Define a number 10
    //   - Show an increment of 2 on the screen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - int Increment(int)
    //   - System.Windows.Forms.MessageBox.Show(String, String, System.Windows.Forms.MessageBoxButtons)
    // Created
    //   - CopyPaste � 20220105 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220105 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      int intNumber;

      intNumber = 10;
      MessageBox.Show(Increment(intNumber).ToString(), "Copy Paste", MessageBoxButtons.OK);
    }
    // Main()

    static int Increment(int intNumber)
    //***
    // Action
    //   - Add 2 to a number (intNumber)
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220105 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220105 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return (intNumber + 2);
    }
    // int Increment(int)

  }
  // cpIntermediateLanguageDisassembler

}
// IntermediateLanguageDisassembler