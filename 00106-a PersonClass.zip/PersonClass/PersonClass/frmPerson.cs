//***
// Action
//   - Testroutine for cpPerson
// Created
//   - CopyPaste � 20230819 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230819 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPerson : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdUse;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPerson));
      this.cmdUse = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdUse
      // 
      this.cmdUse.Location = new System.Drawing.Point(24, 24);
      this.cmdUse.Name = "cmdUse";
      this.cmdUse.TabIndex = 1;
      this.cmdUse.Text = "&Use Class";
      this.cmdUse.Click += new System.EventHandler(this.cmdUse_Click);
      // 
      // frmPerson
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdUse);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPerson";
      this.Text = "Person Class";
      this.Load += new System.EventHandler(this.frmPerson_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPerson'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230819 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230819 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPerson()
      //***
      // Action
      //   - Create instance of 'frmPerson'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230819 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230819 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPerson()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpPerson mthePerson01 = new cpPerson("Vincent");

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdUse_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the information of the person attached to the form (this is the first cpPerson)
      //   - Define a cpPerson 
      //   - Create an instance of cpPerson (this is the second cpPerson)
      //   - Set the age thru a property
      //   - Set the age thru a variable
      //   - Set the name
      //   - Show the information of that person
      //   - Try to set the age negative
      //   - Try to set the age too big
      //   - Create another instance of cpPerson (this is the third cpPerson)
      //   - Set the age
      //   - Show the information of that person
      //   - Create another instance of cpPerson (this is the fourth cpPerson)
      //   - Set the age
      //   - Set the name
      //   - Show the information of that person
      //   - Start the test routine
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpPerson()
      //   - cpPerson(string)
      //   - cpPerson.Age(int) (Set)
      //   - cpPerson.Name(string) (Set)
      //   - cpPerson.Test()
      //   - int cpPerson.Count()
      //   - string cpPerson.Name (Get)
      // Created
      //   - CopyPaste � 20230819 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230819 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show("Person " + cpPerson.Count() + " - " + mthePerson01.Name);

      cpPerson thePerson02;
      thePerson02 = new cpPerson();

      thePerson02.Age = 15;
      thePerson02.mlngAgePublic = 15;
      thePerson02.Name = "Ernest";
      MessageBox.Show("Person " + cpPerson.Count() + " - " + thePerson02.Name);
      // MessageBox.Show("Person " + thePerson02.Count() + " - " + thePerson02.Name); // This will not work
      thePerson02.Age = -5; // Will show an error
      thePerson02.Age = 125; // Will show another error

      cpPerson thePerson03 = new cpPerson("Gertrude");
      thePerson03.Age = 35;
      MessageBox.Show("Person " + cpPerson.Count() + " - " + thePerson03.Name);

      cpPerson thePerson04 = new cpPerson();
      thePerson04.Age = 37;
      thePerson04.Name = "Hilde";
      MessageBox.Show("Person " + cpPerson.Count() + " - " + thePerson04.Name);
      mthePerson01.Test();
    }
    // cmdUse_Click(System.Object, System.EventArgs) Handles cmdUse.Click

    private void frmPerson_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The method "PersonTest" is delegated towards the event cpTesting
      //   - The method "PersonTest" is given thru the delegate to the class functionality
      //     - cpPerson.Test() just starts the method coming from frmPerson
      //     - This makes cpPerson.Test() adaptable without changing the code
      //     - This makes cpPerson a black box, the test is executed, without knowing what it is
      //     - The test functionality can be changed by the client developer of the class
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - cpDelegate cpPerson.cpTesting
      //   - cpPerson.cpDelegate(string)
      // Created
      //   - CopyPaste � 20230819 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230819 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mthePerson01.cpTesting += new cpPerson.cpDelegate(PersonTest);
    }
    // frmPerson_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    #region "Event"

    public void PersonTest() 
      //***
      // Action
      //   - This method is executed when the cpTesting event is triggered
      //   - Show the name of mthePerson01 (element of frmPerson)
      // Called by
      //   - frmPerson.Test()
      // Calls
      //   - string cpPerson.Name (Get)
      // Created
      //   - CopyPaste � 20230819 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230819 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show(mthePerson01.Name);
    }
    // PersonTest() Handles mthePerson01.cpTesting

    #endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Start application
      //   - Showing frmPerson
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230819 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230819 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPerson());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPerson

}
// CopyPaste.Learning