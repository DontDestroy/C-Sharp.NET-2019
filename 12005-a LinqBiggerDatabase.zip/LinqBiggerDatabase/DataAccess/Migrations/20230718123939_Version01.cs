﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace CopyPaste.DataAccess.Migrations
{
    public partial class Version01 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AircraftType",
                columns: table => new
                {
                    TypeId = table.Column<byte>(type: "tinyint", nullable: false),
                    Manufacturer = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AircraftType", x => x.TypeId);
                });

            migrationBuilder.CreateTable(
                name: "Airline",
                columns: table => new
                {
                    Code = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: false),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Airline", x => x.Code);
                });

            migrationBuilder.CreateTable(
                name: "PersonDetail",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    City = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    Country = table.Column<string>(type: "nvarchar(3)", maxLength: 3, nullable: true),
                    Memo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Photo = table.Column<byte[]>(type: "varbinary(max)", nullable: true),
                    Street = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    ZipCode = table.Column<string>(type: "nvarchar(8)", maxLength: 8, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PersonDetail", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AircraftTypeDetail",
                columns: table => new
                {
                    AircraftTypeId = table.Column<byte>(type: "tinyint", nullable: false),
                    Length = table.Column<float>(type: "real", nullable: true),
                    Memo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Tare = table.Column<short>(type: "smallint", nullable: true),
                    TurbineCount = table.Column<byte>(type: "tinyint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AircraftTypeDetail", x => x.AircraftTypeId);
                    table.ForeignKey(
                        name: "FK_AircraftTypeDetail_AircraftType_AircraftTypeId",
                        column: x => x.AircraftTypeId,
                        principalTable: "AircraftType",
                        principalColumn: "TypeId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Employee",
                columns: table => new
                {
                    PersonId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Salary = table.Column<float>(type: "real", nullable: false),
                    SupervisorPersonId = table.Column<int>(type: "int", nullable: true),
                    Discriminator = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    FlightHours = table.Column<int>(type: "int", nullable: true),
                    FlightSchool = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    LicenseDate = table.Column<DateTime>(type: "datetime2", nullable: true),
                    PilotLicenseType = table.Column<int>(type: "int", nullable: true),
                    BirthDay = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GivenName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DetailId = table.Column<int>(type: "int", nullable: true),
                    Surname = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.PersonId);
                    table.ForeignKey(
                        name: "FK_Employee_Employee_SupervisorPersonId",
                        column: x => x.SupervisorPersonId,
                        principalTable: "Employee",
                        principalColumn: "PersonId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Employee_PersonDetail_DetailId",
                        column: x => x.DetailId,
                        principalTable: "PersonDetail",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Passenger",
                columns: table => new
                {
                    PersonId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CustomerSince = table.Column<DateTime>(type: "datetime2", nullable: true),
                    FrequentFlyer = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Status = table.Column<string>(type: "nvarchar(1)", maxLength: 1, nullable: true),
                    BirthDay = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    GivenName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DetailId = table.Column<int>(type: "int", nullable: true),
                    Surname = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Passenger", x => x.PersonId);
                    table.ForeignKey(
                        name: "FK_Passenger_PersonDetail_DetailId",
                        column: x => x.DetailId,
                        principalTable: "PersonDetail",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Flight",
                columns: table => new
                {
                    FlightNo = table.Column<int>(type: "int", nullable: false),
                    AircraftTypeId = table.Column<byte>(type: "tinyint", nullable: true),
                    AirlineCode = table.Column<string>(type: "nvarchar(3)", nullable: true),
                    CoPilotId = table.Column<int>(type: "int", nullable: true),
                    FlightDate = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "getdate()"),
                    Departure = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true),
                    Destination = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: true, defaultValue: "(not set)"),
                    FreeSeats = table.Column<short>(type: "smallint", nullable: false),
                    Memo = table.Column<string>(type: "nvarchar(4000)", maxLength: 4000, nullable: true),
                    NonSmokingFlight = table.Column<bool>(type: "bit", nullable: true),
                    PilotId = table.Column<int>(type: "int", nullable: false),
                    Price = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    Seats = table.Column<short>(type: "smallint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Flight", x => x.FlightNo);
                    table.ForeignKey(
                        name: "FK_Flight_AircraftType_AircraftTypeId",
                        column: x => x.AircraftTypeId,
                        principalTable: "AircraftType",
                        principalColumn: "TypeId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Flight_Airline_AirlineCode",
                        column: x => x.AirlineCode,
                        principalTable: "Airline",
                        principalColumn: "Code",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Flight_Employee_CoPilotId",
                        column: x => x.CoPilotId,
                        principalTable: "Employee",
                        principalColumn: "PersonId",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_Flight_Employee_PilotId",
                        column: x => x.PilotId,
                        principalTable: "Employee",
                        principalColumn: "PersonId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Booking",
                columns: table => new
                {
                    FlightNo = table.Column<int>(type: "int", nullable: false),
                    PassengerId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Booking", x => new { x.FlightNo, x.PassengerId });
                    table.ForeignKey(
                        name: "FK_Booking_Flight_FlightNo",
                        column: x => x.FlightNo,
                        principalTable: "Flight",
                        principalColumn: "FlightNo",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Booking_Passenger_PassengerId",
                        column: x => x.PassengerId,
                        principalTable: "Passenger",
                        principalColumn: "PersonId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Booking_PassengerId",
                table: "Booking",
                column: "PassengerId");

            migrationBuilder.CreateIndex(
                name: "IX_Employee_DetailId",
                table: "Employee",
                column: "DetailId");

            migrationBuilder.CreateIndex(
                name: "IX_Employee_SupervisorPersonId",
                table: "Employee",
                column: "SupervisorPersonId");

            migrationBuilder.CreateIndex(
                name: "IndexFreeSeats",
                table: "Flight",
                column: "FreeSeats");

            migrationBuilder.CreateIndex(
                name: "IndexFromTo",
                table: "Flight",
                columns: new[] { "Departure", "Destination" });

            migrationBuilder.CreateIndex(
                name: "IX_Flight_AircraftTypeId",
                table: "Flight",
                column: "AircraftTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Flight_AirlineCode",
                table: "Flight",
                column: "AirlineCode");

            migrationBuilder.CreateIndex(
                name: "IX_Flight_CoPilotId",
                table: "Flight",
                column: "CoPilotId");

            migrationBuilder.CreateIndex(
                name: "IX_Flight_PilotId",
                table: "Flight",
                column: "PilotId");

            migrationBuilder.CreateIndex(
                name: "IX_Passenger_DetailId",
                table: "Passenger",
                column: "DetailId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AircraftTypeDetail");

            migrationBuilder.DropTable(
                name: "Booking");

            migrationBuilder.DropTable(
                name: "Flight");

            migrationBuilder.DropTable(
                name: "Passenger");

            migrationBuilder.DropTable(
                name: "AircraftType");

            migrationBuilder.DropTable(
                name: "Airline");

            migrationBuilder.DropTable(
                name: "Employee");

            migrationBuilder.DropTable(
                name: "PersonDetail");
        }
    }
}
