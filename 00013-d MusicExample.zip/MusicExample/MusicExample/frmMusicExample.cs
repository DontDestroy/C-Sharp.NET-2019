//***
// Action
//   - Working with controls
// Created
//   - CopyPaste � 20240107 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240107 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmMusicExample: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

    internal System.Windows.Forms.Label lblAnswer;
    internal System.Windows.Forms.Label lblQuestion;
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.Button cmdAnswer;
    internal System.Windows.Forms.PictureBox picGitar;
    private System.ComponentModel.Container components = null;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMusicExample));
      this.lblAnswer = new System.Windows.Forms.Label();
      this.lblQuestion = new System.Windows.Forms.Label();
      this.cmdExit = new System.Windows.Forms.Button();
      this.cmdAnswer = new System.Windows.Forms.Button();
      this.picGitar = new System.Windows.Forms.PictureBox();
      this.SuspendLayout();
      // 
      // lblAnswer
      // 
      this.lblAnswer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblAnswer.ForeColor = System.Drawing.Color.Red;
      this.lblAnswer.Location = new System.Drawing.Point(17, 79);
      this.lblAnswer.Name = "lblAnswer";
      this.lblAnswer.Size = new System.Drawing.Size(152, 56);
      this.lblAnswer.TabIndex = 7;
      this.lblAnswer.Text = "The Bassgitar";
      this.lblAnswer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      this.lblAnswer.Visible = false;
      // 
      // lblQuestion
      // 
      this.lblQuestion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblQuestion.Location = new System.Drawing.Point(17, 23);
      this.lblQuestion.Name = "lblQuestion";
      this.lblQuestion.Size = new System.Drawing.Size(152, 48);
      this.lblQuestion.TabIndex = 6;
      this.lblQuestion.Text = "What rock and roll instrument is played by the thum?";
      // 
      // cmdExit
      // 
      this.cmdExit.Location = new System.Drawing.Point(193, 207);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.Size = new System.Drawing.Size(104, 32);
      this.cmdExit.TabIndex = 9;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // cmdAnswer
      // 
      this.cmdAnswer.Location = new System.Drawing.Point(65, 207);
      this.cmdAnswer.Name = "cmdAnswer";
      this.cmdAnswer.Size = new System.Drawing.Size(104, 32);
      this.cmdAnswer.TabIndex = 8;
      this.cmdAnswer.Text = "&Answer";
      this.cmdAnswer.Click += new System.EventHandler(this.cmdAnswer_Click);
      // 
      // picGitar
      // 
      this.picGitar.Image = ((System.Drawing.Image)(resources.GetObject("picGitar.Image")));
      this.picGitar.Location = new System.Drawing.Point(185, 23);
      this.picGitar.Name = "picGitar";
      this.picGitar.Size = new System.Drawing.Size(168, 160);
      this.picGitar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picGitar.TabIndex = 5;
      this.picGitar.TabStop = false;
      this.picGitar.Visible = false;
      // 
      // frmMusicExample
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(371, 262);
      this.Controls.Add(this.lblAnswer);
      this.Controls.Add(this.lblQuestion);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.cmdAnswer);
      this.Controls.Add(this.picGitar);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMusicExample";
      this.Text = "Music Question";
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmMusicExample'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � yyyymmdd � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � yyyymmdd � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmMusicExample()
			//***
			// Action
			//   - Create instance of 'frmMusicExample'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � yyyymmdd � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � yyyymmdd � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmMusicExample()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"

    private void cmdAnswer_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the correct answer
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240107 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240107 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblAnswer.Visible = true;
      picGitar.Visible = true;   
    }
    // cmdAnswer_Click(System.Object, System.EventArgs) Handles cmdAnswer.Click

    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop program
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240107 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240107 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit.Click

    #endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmMusicExample
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmMusicExample()
			// Created
			//   - CopyPaste � yyyymmdd � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � yyyymmdd � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmMusicExample());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmMusicExample

}
// CopyPaste.Learning