﻿//***
// Action
//   - Show a screen with 2 buttons
//   - Every button has his own handler
// Created
//   - CopyPaste – 20220901 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220901 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace EventHandles
{

  public partial class wpfButtonHandlers : Window
  {

    #region "Constructors / Destructors"

    public wpfButtonHandlers()
    //***
    // Action
    //   - Create an instance of 'wpfButtonHandlers'
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220901 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220901 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfButtonHandlers

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFirstInWindowGrid_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Show a message that you have clicked the first button
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220901 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220901 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      MessageBox.Show("You have clicked the first button");
    }
    // cmdFirstInWindowGrid_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdFirstInWindowGrid.Click

    private void cmdSecondInWindowGrid_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Show a message that you have clicked the second button
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220901 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220901 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      MessageBox.Show("You have clicked the second button");
    }
    // cmdSecondInWindowGrid_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdSecondInWindowGrid.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfButtonHandlers

}
// EventHandles