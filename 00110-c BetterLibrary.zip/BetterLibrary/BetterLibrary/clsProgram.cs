//***
// Action
//   - Explanation of the code in this module or class
// Created
//   - CopyPaste � 20240227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240227 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;
using System.Collections;

namespace CopyPaste.Learning
{

  public class cpProgram
	{

    #region "Constructors / Destructors"

    public cpProgram()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Create a cpLibrary.
      //   - Check in 2 new books to the cpLibrary
      //   - Loop thru the items of the cpLibrary
      //   - Checkout a book from the cpLibrary
      //   - Loop thru the items of the cpLibrary
      //   - Check it back in
      //   - Loop thru the items of the cpLibrary
      // Called by
      //   - User action (Starting the application
      // Calls
      //   - cpBook(string, string)
      //   - cpLibrary.CheckIn(cpBook)
      //   - cpLibrary.CheckOut(string)
      //   - cpLibrary()
      //   - string cpBook.Text (Get)
      //   - string cpBook.Title (Get)
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBook thecpBook;
      cpLibrary thecpLibrary = new cpLibrary();

      thecpLibrary.CheckIn(new cpBook("First book", " This is the text of the first book."));
      thecpLibrary.CheckIn(new cpBook("Second book", " This is the text of the second book."));

      Console.WriteLine("Books in library");
      Console.WriteLine("----------------");

      foreach (DictionaryEntry theThing in thecpLibrary.mcpBookShelf)
      {
        Console.WriteLine(theThing.Key);
      }
      // in thecpLibrary.mcpBookShelf

      cpBook thecpFirstBook = thecpLibrary.CheckOut("First book");

      Console.WriteLine();
      Console.WriteLine("The text of '{0}' is '{1}'.", thecpFirstBook.Title, thecpFirstBook.Text);

      Console.WriteLine();
      Console.WriteLine("Books in library");
      Console.WriteLine("----------------");

      foreach (DictionaryEntry theThing in thecpLibrary.mcpBookShelf)
      {
        Console.WriteLine(theThing.Key);
      }
      // in thecpLibrary.mcpBookShelf

      thecpLibrary.CheckIn(thecpFirstBook);

      Console.WriteLine();
      Console.WriteLine("Books in library");
      Console.WriteLine("----------------");

      foreach (DictionaryEntry theThing in thecpLibrary.mcpBookShelf)
      {
        Console.WriteLine(theThing.Key);
      }
      // in thecpLibrary.mcpBookShelf

      Console.WriteLine();
      Console.WriteLine("Hit enter to stop the application.");
      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// CopyPaste.Learning