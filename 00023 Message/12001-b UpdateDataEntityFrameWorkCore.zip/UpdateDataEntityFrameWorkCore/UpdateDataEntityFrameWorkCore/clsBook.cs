﻿//***
// Action
//   - The class cpBook
//   - Will be used to read data from a table in a SQL Server database
//   - The primary key is by default setting in Entity FrameWork Core the <classname>Id notification
//     - This is not according to Copy Paste naming conventions (it should be intIdBook)
//   - There is a link towards the class cpAuthor (also here there is a mismatch between the naming conventions)
// Created
//   - CopyPaste – 20230401 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230401 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace UpdateDataEntityFrameWorkCore
{

  public class cpBook
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public int cpBookId { get; set; }
    public string strTitle { get; set; }
    public string strDescription { get; set; }
    public DateTime dtmPublishedOn { get; set; }
    public int cpAuthorId { get; set; }
    public cpAuthor Author { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpBook

}
// UpdateDataEntityFrameWorkCore