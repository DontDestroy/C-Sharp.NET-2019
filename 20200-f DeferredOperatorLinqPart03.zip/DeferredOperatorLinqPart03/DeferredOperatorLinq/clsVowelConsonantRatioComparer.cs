﻿//***
// Action
//   - Class that defines a way to compare 2 elements
//   - We compare the ratio between the vowels and the consonents of strings
// Created
//   - CopyPaste – 20230428 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230428 – VVDW
// Proposal (To Do)
//   -
//***

using System.Collections.Generic;

namespace CopyPaste.Learning
{

  public class cpVowelConsonantRatioComparer : IComparer<string>
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int Compare(string strFirst, string strSecond)
    //***
    // Action
    //   - There are 2 strings (strFirst and strSecond)
    //   - We count the vowels and consonants of the first string
    //   - We count the vowels and consonants of the second string
    // Called by
    //   - cpProgram.OrderningOrderBy()
    // Calls
    //   - GetVowelConsonantCount(string, °int, °int)
    // Created
    //   - CopyPaste – 20230428 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230428 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      double dblRatioFirst;
      double dblRatioSecond;
      int intConsonantCountFirst = 0;
      int intConsonantCountSecond = 0;
      int intVowelCountFirst = 0;
      int intVowelCountSecond = 0;

      GetVowelConsonantCount(strFirst, ref intVowelCountFirst, ref intConsonantCountFirst);
      GetVowelConsonantCount(strSecond, ref intVowelCountSecond, ref intConsonantCountSecond);

      if (intConsonantCountFirst == 0)
      {
        dblRatioFirst = 1;
      }
      else
      // intConsonantCountFirst <> 0
      {
        dblRatioFirst = intVowelCountFirst / (double)intConsonantCountFirst;
      }
      // intConsonantCountFirst = 0

      if (intConsonantCountSecond == 0)
      {
        dblRatioSecond = 1;
      }
      else
      // intConsonantCountSecond <> 0
      {
        dblRatioSecond = intVowelCountSecond / (double)intConsonantCountSecond;
      }
      // intConsonantCountSecond = 0

      if (dblRatioFirst < dblRatioSecond)
      {
        return -1;
      }
      else if (dblRatioFirst > dblRatioSecond)
      // (dblRatioFirst >= dblRatioSecond)
      {
        return 1;
      }
      else
      // (dblRatioFirst = dblRatioSecond)
      {
        return 0;
      }
      // (dblRatioFirst < dblRatioSecond)

    }
    // int Compare(string, string)

    public void GetVowelConsonantCount(string strText, ref int intVowelCount, ref int intConsonantCount)
    //***
    // Action
    //   - There is a string (strText)
    //   - We count the vowels and consonants of that string
    //   - We define the vowels in uppercase
    //   - We loop thru each character of the text in uppercase
    //   - If the character can be found in the vowels
    //     - intVowelCount becomes 1 bigger
    //   - If Not
    //     - intConsonantCount becomes 1 bigger
    // Called by
    //   - cpProgram.ShowContentOfSequenceComparer(IOrderedEnumerable<cpPresident>, cpVowelConsonantRatioComparer, string)
    //   - int Compare(string, string)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230428 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230428 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      string strUpper;
      string strVowels = "AEIOU";

      intConsonantCount = 0;
      intVowelCount = 0;

      strUpper = strText.ToUpper();

      foreach (char aChar in strUpper)
      {

        if (strVowels.IndexOf(aChar) < 0)
        {
          intConsonantCount++;
        }
        else
        // strVowels.IndexOf(aChar) >= 0
        {
          intVowelCount++;
        }
        // strVowels.IndexOf(aChar) < 0

      }
      // in strUpper

    }
    // GetVowelConsonantCount(string, °int, °int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpVowelConsonantRatioComparer

}
// CopyPaste.Learning 