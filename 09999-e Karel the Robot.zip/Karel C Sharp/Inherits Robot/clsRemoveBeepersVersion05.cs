﻿//***
// Action
//   - A field of crops must be harvested
// Created
//   - CopyPaste – 20251020 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251020 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpRemoveBeepersVersion05 : kareltherobot.Robot
	{

		#region "Constructors / Destructors"

		public cpRemoveBeepersVersion05(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Robot becomes a cpRemoveBeepersVersion05 starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
		//   - Nothing else happens
		// Called by
		//   - 
		// Calls
		//   - cpRemoveBeepersVersion05(int, int, Directions.Direction, int, Color)
		// Created
		//   - CopyPaste – 20251020 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251020 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
		}
		// cpRemoveBeepersVersion05(int, int, Directions.Direction, int) 

		public cpRemoveBeepersVersion05(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Robot becomes a theColor cpRemoveBeepersVersion05 starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
		//   - Nothing else happens
		// Called by
		//   - cpProgram.RemoveBeepersVersion05()
		//   - cpRemoveBeepersVersion05(int, int, Directions.Direction, int)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251020 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251020 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
		}
		// cpRemoveBeepersVersion05(int, int, Directions.Direction, int, Color) 

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		private void HarvestCorner()
		//***
		// Action
		//   - Pick the beeper (if there is one)
		// Called by
		//   - HarvestOneRow()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251020 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251020 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{

			if (nextToABeeper())
			{
				pickBeeper();
			}
      // nextToABeeper()

    }
    // HarvestCorner()

    private void HarvestOneRow()
		//***
		// Action
		//   - Take the beeper (harvest corner)
		//   - Repeat this another 4 times
		//     - Move one forward
		//     - Take the beeper (harvest corner)
		// Called by
		//   - HarvestTwoRows()
		// Calls
		//   - HarvestCorner()
		// Created
		//   - CopyPaste – 20251020 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251020 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			HarvestCorner();

			for (int index = 0; index < 4; index++)
			{
				move();
				HarvestCorner();
			}
      // index = 4

    }
    // HarvestCorner()

    public void HarvestTheField()
		//***
		// Action
		//   - Repeat this twice
		//     - Harvest two rows
		//     - Set the robot good for the next harvest of 2 rows
		//   - Harvest the last 2 rows
		// Called by
		//   - 
		// Calls
		//   - HarvestTwoRows()
		//   - PositionForNextHarvest()
		// Created
		//   - CopyPaste – 20251020 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251020 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			move(); // The robot must be placed on the first beeper (looking East)

			for (int index = 0; index < 2; index++)
			{
				HarvestTwoRows();
				PositionForNextHarvest();
			}
      // index = 2

      HarvestTwoRows();
			move(); // The robot must be placed one further (looking West)
		}
		// HarvestTheField()

		private void HarvestTwoRows()
		//***
		// Action
		//   - Harvest one row (going from left to right)
		//   - Position of the row above
		//     - Go one row up
		//     - Look to the other direction (look to the left)
		//   - Harvest one row (going from right to left)
		// Called by
		//   - HarvestTheField()
		// Calls
		//   - HarvestOneRow()
		//   - PositionForNextRow()
		// Created
		//   - CopyPaste – 20251020 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251020 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			HarvestOneRow();
			PositionForNextRow();
			HarvestOneRow();
		}
		// HarvestTwoRows()

		private void PositionForNextHarvest()
		//***
		// Action
		//   - Turn to the right (looking North)
		//   - Go one forward (move up)
		//   - Turn to the right (looking East)
		// Called by
		//   - HarvestTheField()
		// Calls
		//   - TurnRight()
		// Created
		//   - CopyPaste – 20251020 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251020 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			TurnRight();
			move();
			TurnRight();
		}
		// PositionForNextHarvest()

		private void PositionForNextRow()
		//***
		// Action
		//   - Turn to the left (looking North)
		//   - Go one forward (move up)
		//   - Turn to the left (looking West)
		// Called by
		//   - HarvestTwoRows()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251020 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251020 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			turnLeft();
			move();
			turnLeft();
		}
		// PositionForNextRow()

		private void TurnRight()
		//***
		// Action
		//   - Turn to the right by turning 3 times to the left
		// Called by
		//   - PositionForNextHarvest()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251020 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251020 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			turnLeft();
			turnLeft();
			turnLeft();
		}
		// TurnRight()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpRemoveBeepersVersion05

}
// cpKarelTheRobot