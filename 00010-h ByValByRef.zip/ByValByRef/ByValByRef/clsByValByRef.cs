//***
// Action
//   - Change two variables with each other
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace ByValByRef
{

  class cpByValByRef
	{

    static void Main()
    //***
    // Action
    //   - Initialise two variables
    //   - Change them
    //   - Show result at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - Change(byte, byte)
    //   - ChangeByRef(�byte, �byte)
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(byte)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      byte bytNumber1 = 1;
      byte bytNumber2 = 2;

      Console.WriteLine("By Value");
      Change(bytNumber1, bytNumber2);

      Console.WriteLine(bytNumber1);
      Console.WriteLine(bytNumber2);
      Console.WriteLine();

      Console.WriteLine("By Reference");
      ChangeByRef(ref bytNumber1, ref bytNumber2);

      Console.WriteLine(bytNumber1);
      Console.WriteLine(bytNumber2);
      
      Console.ReadLine();
    }
    // Main()

    static void Change(byte bytFirstNumber, byte bytSecondNumber)
    //***
    // Action
    //   - Change the two values of variables with each other
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      byte bytHelp;

      bytHelp = bytFirstNumber;
      bytFirstNumber = bytSecondNumber;
      bytSecondNumber = bytHelp;
    }
    // Change(byte, byte)

    static void ChangeByRef(ref byte bytFirstNumber, ref byte bytSecondNumber)
    //***
    // Action
    //   - Change the two values of variables with each other
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      byte bytHelp;

      bytHelp = bytFirstNumber;
      bytFirstNumber = bytSecondNumber;
      bytSecondNumber = bytHelp;
    }
    // ChangeByRef (�byte, �byte)

  }
  // cpByValByRef

}
// ByValByRef