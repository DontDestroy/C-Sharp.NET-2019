//***
// Action
//   - Implementation of cpStock
// Created
//   - CopyPaste � 20240524 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240524 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpStock
  {

    #region "Constructors / Destructors"

    public cpStock()
      //***
      // Action
      //   - Default constructor
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpStock()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public event cpEarnings Earnings;
    public event cpPriceDown PriceDown;
    public event cpPriceUp PriceUp;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate void cpEarnings(double dblAmount, DateTime dtmAnnouce);
    // GenerateEvents()
    public delegate void cpPriceDown(double dblAmount);
    // GenerateEvents()
    public delegate void cpPriceUp(double dblAmount);
    // GenerateEvents()

    #endregion

    #region "Sub / Function"

    public void GenerateEvents()
      //***
      // Action
      //   - Execute the 3 events (when not null)
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - Earnings(Double, DateTime)
      //   - PriceDown(Double)
      //   - PriceUp(Double)
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (PriceUp == null)
      {
      }
      else
        // PriceUp <> null
      {
        PriceUp(2);
      }
      // PriceUp = null

      if (PriceDown == null)
      {
      }
      else
        // PriceDown <> null
      {
        PriceDown(-5.5);
      }
      // PriceDown = null

      if (Earnings == null)
      {
      }
      else
        // Earnings <> null
      {
        Earnings(1.25, DateTime.Now);
      }
      // Earnings = null

    }
    // GenerateEvents()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpStock

}
// CopyPaste.Learning