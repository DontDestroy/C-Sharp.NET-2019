<%@ Page Language="C#" %>

<html>
<head>
  <title>Look for Variables</title>
</head>
<body>
  <center>
    <h1>Look for Session and Application Variables</h1>
  </center>
  <hr>

  <%

    string strAuthor;
    string strBook;
    string strChapter;
    string strPublisher;

    strAuthor = Application["Author"].ToString();
    strBook = Session["Book"].ToString();
    strChapter = Session["Chapter"].ToString();
    strPublisher = Application["Publisher"].ToString();

    if (strBook == null)
    {
      Response.Write("Book: Unknown <br>");
    }
    else
    {
      Response.Write("Book: " + strBook + "<br>");
    }

    if (strChapter == null)
    {
      Response.Write("Chapter: Unknown <br>");
    }
    else
    {
      Response.Write("Chapter: " + strChapter + "<br>");
    }

    if (strPublisher == null)
    {
      Response.Write("Publisher: Unknown <br>");
    }
    else
    {
      Response.Write("Publisher: " + strPublisher + "<br>");
    }

    if (strAuthor == null)
    {
      Response.Write("Author: Unknown <br>");
    }
    else
    {
      Response.Write("Author: " + strAuthor + "<br>");
    }

  %>

</body>
</html>
