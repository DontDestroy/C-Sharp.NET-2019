//***
// Action
//   - Changing a parameter of a procedure
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace ByRef
{

  class cpByRef
	{

    static void Main()
    //***
    // Action
    //   - Show a variable at the console screen
    //   - Call a procedure with that variable
    //   - Show that variable again at the console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - ParameterChange(�long)
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngNumber = 100;

      Console.WriteLine("Number before function call: " + lngNumber);
      ParameterChange(ref lngNumber);
      Console.WriteLine("Number after function call: " + lngNumber);
      Console.ReadLine();
    }
    // Main()

    static void ParameterChange(ref long lngValue)
    //***
    // Action
    //   - Change the variable
    //   - Show value at the console screen
    // Called by
    //   - Main()
    // Calls
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      lngValue = 1001;
      Console.WriteLine("Value of Number in subroutine " + lngValue);
    }
    // ParameterChange(�long)

	}
  // cpByRef

}
// ByRef