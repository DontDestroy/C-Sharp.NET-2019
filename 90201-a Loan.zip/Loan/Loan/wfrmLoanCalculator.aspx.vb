﻿'***
' Action
'   - Starting form, asking for information to do a calculation
'   - There are some labels
'   - There are some text boxes
'   - There is a drop down list
'   - There is a button,
'   - There are validators (rangevalidators, requiredfieldvalidator and regularexpressionvalidator)
'   - There is a hyperlink
'   - All is forced towards Belgium formatting (€, . as thousand separator and , as decimal symbol)
' Created
'   - CopyPaste – 20260417 – VVDW
' Changed
'   - CopyPaste – yyyymmdd – VVDW – What changed
' Tested
'   - CopyPaste – 20260417 – VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On
Option Strict On

Imports System.Globalization
Imports System.Math
Imports System.Web.Caching

Namespace CopyPaste.Learning

  Public Class wfrmLoanCalculator
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Init
      InitializeComponent()
    End Sub

#End Region

    '#Region "Constructors"
    '#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

#Region "Fields"
    Protected WithEvents cmbTerm As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cmdCalculate As System.Web.UI.WebControls.Button
    Protected WithEvents hypSchedule As System.Web.UI.WebControls.HyperLink
    Protected WithEvents lblAmount As System.Web.UI.WebControls.Label
    Protected WithEvents lblMonthly As System.Web.UI.WebControls.Label
    Protected WithEvents lblRate As System.Web.UI.WebControls.Label
    Protected WithEvents lblTerm As System.Web.UI.WebControls.Label
    Protected WithEvents lblTitle As System.Web.UI.WebControls.Label
    Protected WithEvents revRate As System.Web.UI.WebControls.RegularExpressionValidator
    Protected WithEvents rfvAmount As System.Web.UI.WebControls.RequiredFieldValidator
    Protected WithEvents rfvRate As System.Web.UI.WebControls.RequiredFieldValidator
    Protected WithEvents rgvAmount As System.Web.UI.WebControls.RangeValidator
    Protected WithEvents txtAmount As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtRate As System.Web.UI.WebControls.TextBox
#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

#Region "Controls"

    Private Sub cmdCalculate_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdCalculate.Click
      '***
      ' Action
      '   - Calculate the monthy payment
      '   - Enable the hyperlink
      ' Called by
      '   - User action (Clicking a button)
      ' Calls
      '   - CalculatePayment()
      ' Created
      '   - CopyPaste – 20260417 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260417 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      CalculatePayment()
      hypSchedule.Enabled = True
    End Sub
    ' cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click

    Private Sub Page_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Load
      '***
      ' Action
      '   - If it is the first time you render the page
      '     - Select first element in combo box
      '     - Disable the hyperlink
      '   - If not (loaded by a client postback)
      '     - Do nothing
      ' Called by
      '   - User action (Loading the page)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20260417 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260417 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      If IsPostBack Then
      Else
        ' Not IsPostBack
        cmbTerm.SelectedIndex = 0
        hypSchedule.Enabled = False
      End If
      ' IsPostBack

    End Sub
    ' Page_Load(System.Object, System.EventArgs) Handles MyBase.Load

#End Region

#Region "Functionality"

    '#Region "Event"
    '#End Region

#Region "Sub / Function"

    Private Sub CalculatePayment()
      '***
      ' Action
      '   - Define and initialize a Belgian culture info
      '   - Define and initialize the loan amount
      '   - Define and initialize the number of monthly terms
      '   - Define and initialize the wanted number format
      '   - Define and initialize the interest rate (Convert from the correct Belgian number format)
      '   - Define and initialize the monthly payment (Payment is done at the end of the period)
      '   - Set the result on the form in the correct format (Belgian number format)
      '   - Cache the needed data (Loan amount, rate, terms and monthy payments)
      ' Called by
      '   - cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20260417 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260417 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      Dim culinfBelgium As New CultureInfo("fr-BE", False)
      Dim intLoanAmount As Int32 = Convert.ToInt32(txtAmount.Text)
      Dim intTerm As Int32 = Convert.ToInt32(cmbTerm.SelectedItem.Value)
      Dim nfiBelgium As NumberFormatInfo = culinfBelgium.NumberFormat
      Dim sngRate As Single = Convert.ToSingle(Convert.ToDouble(txtRate.Text, nfiBelgium) / 100)
      ' The given rate is forced to Belgian formatting using a Regular Expression validator
      Dim sngPayment As Single = Convert.ToSingle(Pmt(sngRate / 12, intTerm, -intLoanAmount, 0, DueDate.EndOfPeriod))

      lblMonthly.Text = "Monthly Payment: " & Math.Round(sngPayment, 2).ToString("€ #,##0.00", nfiBelgium)

      Cache("cpLoanAmount") = intLoanAmount
      Cache("cpRate") = sngRate
      Cache("cpTerm") = intTerm
      Cache("cpPayment") = Math.Round(sngPayment, 2)
    End Sub
    ' CalculatePayment()

#End Region

#End Region

#End Region

    '#Region "Overrides"
    '#End Region

  End Class
  ' wfrmLoanCalculator

End Namespace
' CopyPaste.Learning
