//***
// Action
//   - Startup screen of the Morse code
//   - Testroutine for visualisation of a Morse code
//     - By output (text of dash and dots)
//     - By sound
//     - By light
// Created
//   - CopyPaste � 20241227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20241227 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.MorseCode.Library;
using System.Net.Security;
using System.Reflection;

namespace CopyPaste.MorseCode
{

	public partial class frmMorseCode : System.Windows.Forms.Form
	{

		#region "Constructors / Destructors"

		/// <summary>
		///  Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		//***
		// Action
		//   - Clean up instance of 'frmMorseCode'
		// Called by
		//   - User action (Closing the form)
		// Calls
		//   - 
		// Created
		//   - CopyPaste � 20241227 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20241227 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{

			if (disposing)
			{

				if (components == null)
				{
				}
				else
				// (components != null)
				{
					components.Dispose();
				}
				// (components == null)

			}
			else
			// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		/// <summary>
		/// Constructor of the start screen of the Morse Code
		/// </summary>
		public frmMorseCode()
		//***
		// Action
		//   - Create instance of 'frmMorseCode'
		// Called by
		//   - Main()
		// Calls
		//   - InitializeComponent()
		// Created
		//   - CopyPaste � 20241227 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20241227 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			InitializeComponent();
		}
		// frmMorseCode()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private cpMorse thecpMorseCode;

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"

		private void cmdSend_Click(System.Object theSender, EventArgs theEventArguments)
		//***
		// Action
		//   - Set the text of the morse code to nothing
		//   - Clean the behaviour of the cpMorseCode
		//   - If a checkbox is marked
		//     - Set the message to send
		//     - If checkbox of Output is checked
		//       - Define a cpMorseByOutputWindow
		//       - Send the message
		//       - Get the output of the send message and show it on the screen
		//     - If not
		//       - Do nothing
		//     - Clean the behaviour of the cpMorseCode
		//     - If checkbox of Sound is checked
		//       - Define a cpMorseBySound
		//       - Send the message
		//     - If not
		//       - Do nothing
		//     - Clean the behaviour of the cpMorseCode
		//     - If checkbox of Light is checked
		//       - Define a cpMorseByLight
		//       - Send the message
		//     - If not
		//       - Do nothing
		//   - If not
		//     - Do nothing
		// Called by
		//   - User action (Clicking a button)
		// Calls
		//   - CopyPaste.MorseCode.Library.cpiMessageMorse HowToSendMessage (Get)
		//   - CopyPaste.MorseCode.Library.cpMorse.CleanBehaviour()
		//   - CopyPaste.MorseCode.Library.cpMorse.Message(string) (Set)
		//   - CopyPaste.MorseCode.Library.cpMorseByLight(PictureBox)
		//   - CopyPaste.MorseCode.Library.cpMorseByOutputWindow(int)
		//   - CopyPaste.MorseCode.Library.cpMorseBySound()
		//   - HowToSendMessage(CopyPaste.MorseCode.Library.cpiMessageMorse) (Set)
		//   - int CopyPaste.MorseCode.Library.cpMorse.Speed (Get)
		//   - string CopyPaste.MorseCode.Library.cpMorseByOutputWindow.OutputWindow (Get)
		// Created
		//   - CopyPaste � 20241227 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20241227 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			txtMorseCode.Text = "";
			thecpMorseCode.CleanBehaviour();

			if (chkOutput.Checked || chkLight.Checked || chkSound.Checked)
			{
				thecpMorseCode.Message = txtTextToSend.Text;

				if (chkOutput.Checked)
				{
					cpMorseByOutputWindow theWayToSend;

					thecpMorseCode.HowToSendMessage = new cpMorseByOutputWindow(thecpMorseCode.Speed);
					thecpMorseCode.SendMessage();

					theWayToSend = (cpMorseByOutputWindow)thecpMorseCode.HowToSendMessage;
					txtMorseCode.Text = theWayToSend.OutputWindow;
				}
				else
				// Not chkOutput.Checked
				{
				}
				// chkOutput.Checked

				thecpMorseCode.CleanBehaviour();

				if (chkSound.Checked)
				{
					thecpMorseCode.HowToSendMessage = new cpMorseBySound();
					thecpMorseCode.SendMessage();
				}
				else
				// Not chkSound.Checked
				{
				}
				// chkSound.Checked

				thecpMorseCode.CleanBehaviour();

				if (chkLight.Checked)
				{
					thecpMorseCode.HowToSendMessage = new cpMorseByLight(this.picLightBulb);
					thecpMorseCode.SendMessage();
				}
				else
				// Not chkLight.Checked
				{
				}
				// chkLight.Checked

			}
			else
			// Not chkOutput.Checked And Not chkLight.Checked And Not chkSound.Checked
			{
			}
			// chkOutput.Checked Or chkLight.Checked Or chkSound.Checked

		}
		// cmdSend_Click(System.Object, EventArgs) Handles cmdSend.Click

		private void frmMorseCode_Load(System.Object theSender, EventArgs theEventArguments)
		//***
		// Action
		//   - A new instance of cpMorse is created with a speed of 250
		//   - All behaviour of the class cpMorse is cleaned (all delegated are removed)
		// Called by
		//   - User action (Clicking a button)
		// Calls
		//   - CopyPaste.MorseCode.Library.cpMorse.CleanBehaviour()
		//   - CopyPaste.MorseCode.Library.cpMorse(int)
		// Created
		//   - CopyPaste � 20241227 � VVDW
		// Changed
		//   - CopyPaste � yyyymmdd � VVDW � What changed
		// Tested
		//   - CopyPaste � 20241227 � VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			thecpMorseCode = new cpMorse(250);
			thecpMorseCode.CleanBehaviour();
		}
		// frmMorseCode_Load(System.Object, EventArgs) Handles frmMorseCode.Load

		#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmMorseCode

}
// CopyPaste.MorseCode