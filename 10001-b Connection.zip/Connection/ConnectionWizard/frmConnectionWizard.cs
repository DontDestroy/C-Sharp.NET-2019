//***
// Action
//   - Having a connection towards a database
// Created
//   - CopyPaste � 20210630 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20210630 � VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Forms;

namespace CopyPaste.Learning.Data
{

	public class frmConnectionWizard : System.Windows.Forms.Form
	{

    #region Windows Form Designer generated code
    private System.Windows.Forms.GroupBox grpConnectionType;
    private System.Windows.Forms.RadioButton optOleDB;
    private System.Windows.Forms.RadioButton optSQL;
    private System.Windows.Forms.Label lblConnectionString;
    private System.Windows.Forms.TextBox txtConnectionString;
    private System.Windows.Forms.Label lblDatabase;
    private System.Windows.Forms.TextBox txtDatabase;
    private System.Windows.Forms.Label lblTimeOut;
    private System.Windows.Forms.TextBox txtTimeOut;
    private System.Windows.Forms.Button cmdTest;
		private cpNorthwind_2000DataSet dsCPNorthWindAccess;
		private cpNorthwind_2007DataSetTableAdapters.TableAdapterManager tbaCategoryNorthWindAccess;
		private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmConnectionWizard));
			this.grpConnectionType = new System.Windows.Forms.GroupBox();
			this.optSQL = new System.Windows.Forms.RadioButton();
			this.optOleDB = new System.Windows.Forms.RadioButton();
			this.lblConnectionString = new System.Windows.Forms.Label();
			this.txtConnectionString = new System.Windows.Forms.TextBox();
			this.lblDatabase = new System.Windows.Forms.Label();
			this.txtDatabase = new System.Windows.Forms.TextBox();
			this.lblTimeOut = new System.Windows.Forms.Label();
			this.txtTimeOut = new System.Windows.Forms.TextBox();
			this.cmdTest = new System.Windows.Forms.Button();
			this.tbaCategorySQLClient = new CopyPaste.Learning.Data.cpNorthWindScript2019DataSetTableAdapters.tbaCategory();
			this.dsCPNorthWindScript2019 = new CopyPaste.Learning.Data.cpNorthWindScript2019DataSet();
			this.tbaCategoryOleDB = new CopyPaste.Learning.Data.cpNorthwind_2007DataSetTableAdapters.tbaCategory();
			this.dsCPNorthwind_2007 = new CopyPaste.Learning.Data.cpNorthwind_2000DataSet();
			this.dsCPNorthWindAccess = new CopyPaste.Learning.Data.cpNorthwind_2000DataSet();
			this.tbaCategoryNorthWindAccess = new CopyPaste.Learning.Data.cpNorthwind_2007DataSetTableAdapters.TableAdapterManager();
			this.grpConnectionType.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dsCPNorthWindScript2019)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dsCPNorthwind_2007)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dsCPNorthWindAccess)).BeginInit();
			this.SuspendLayout();
			// 
			// grpConnectionType
			// 
			this.grpConnectionType.Controls.Add(this.optSQL);
			this.grpConnectionType.Controls.Add(this.optOleDB);
			this.grpConnectionType.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.grpConnectionType.Location = new System.Drawing.Point(16, 8);
			this.grpConnectionType.Name = "grpConnectionType";
			this.grpConnectionType.Size = new System.Drawing.Size(144, 80);
			this.grpConnectionType.TabIndex = 0;
			this.grpConnectionType.TabStop = false;
			this.grpConnectionType.Text = "Connection Type";
			// 
			// optSQL
			// 
			this.optSQL.Location = new System.Drawing.Point(16, 48);
			this.optSQL.Name = "optSQL";
			this.optSQL.Size = new System.Drawing.Size(104, 24);
			this.optSQL.TabIndex = 2;
			this.optSQL.Text = "SQL Server";
			this.optSQL.CheckedChanged += new System.EventHandler(this.optSQL_CheckChanged);
			// 
			// optOleDB
			// 
			this.optOleDB.Checked = true;
			this.optOleDB.Location = new System.Drawing.Point(16, 16);
			this.optOleDB.Name = "optOleDB";
			this.optOleDB.Size = new System.Drawing.Size(104, 24);
			this.optOleDB.TabIndex = 1;
			this.optOleDB.TabStop = true;
			this.optOleDB.Text = "OleDB";
			this.optOleDB.CheckedChanged += new System.EventHandler(this.optOleDb_CheckChanged);
			// 
			// lblConnectionString
			// 
			this.lblConnectionString.AutoSize = true;
			this.lblConnectionString.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblConnectionString.Location = new System.Drawing.Point(8, 96);
			this.lblConnectionString.Name = "lblConnectionString";
			this.lblConnectionString.Size = new System.Drawing.Size(112, 13);
			this.lblConnectionString.TabIndex = 1;
			this.lblConnectionString.Text = "&Connection String:";
			// 
			// txtConnectionString
			// 
			this.txtConnectionString.Location = new System.Drawing.Point(8, 112);
			this.txtConnectionString.Multiline = true;
			this.txtConnectionString.Name = "txtConnectionString";
			this.txtConnectionString.Size = new System.Drawing.Size(432, 96);
			this.txtConnectionString.TabIndex = 4;
			this.txtConnectionString.Text = "Connection String";
			// 
			// lblDatabase
			// 
			this.lblDatabase.AutoSize = true;
			this.lblDatabase.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDatabase.Location = new System.Drawing.Point(8, 220);
			this.lblDatabase.Name = "lblDatabase";
			this.lblDatabase.Size = new System.Drawing.Size(65, 13);
			this.lblDatabase.TabIndex = 5;
			this.lblDatabase.Text = "&Database:";
			// 
			// txtDatabase
			// 
			this.txtDatabase.Location = new System.Drawing.Point(88, 216);
			this.txtDatabase.Name = "txtDatabase";
			this.txtDatabase.Size = new System.Drawing.Size(352, 20);
			this.txtDatabase.TabIndex = 6;
			this.txtDatabase.Text = "Database";
			// 
			// lblTimeOut
			// 
			this.lblTimeOut.AutoSize = true;
			this.lblTimeOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblTimeOut.Location = new System.Drawing.Point(8, 240);
			this.lblTimeOut.Name = "lblTimeOut";
			this.lblTimeOut.Size = new System.Drawing.Size(62, 13);
			this.lblTimeOut.TabIndex = 7;
			this.lblTimeOut.Text = "Time &Out:";
			// 
			// txtTimeOut
			// 
			this.txtTimeOut.Location = new System.Drawing.Point(88, 240);
			this.txtTimeOut.Name = "txtTimeOut";
			this.txtTimeOut.Size = new System.Drawing.Size(352, 20);
			this.txtTimeOut.TabIndex = 8;
			this.txtTimeOut.Text = "TimeOut";
			// 
			// cmdTest
			// 
			this.cmdTest.Location = new System.Drawing.Point(11, 266);
			this.cmdTest.Name = "cmdTest";
			this.cmdTest.Size = new System.Drawing.Size(75, 23);
			this.cmdTest.TabIndex = 10;
			this.cmdTest.Text = "&Test";
			this.cmdTest.Click += new System.EventHandler(this.cmdTest_Click);
			// 
			// tbaCategorySQLClient
			// 
			this.tbaCategorySQLClient.ClearBeforeFill = true;
			// 
			// dsCPNorthWindScript2019
			// 
			this.dsCPNorthWindScript2019.DataSetName = "cpNorthWindScript2019DataSet";
			this.dsCPNorthWindScript2019.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// tbaCategoryOleDB
			// 
			this.tbaCategoryOleDB.ClearBeforeFill = true;
			// 
			// dsCPNorthwind_2007
			// 
			this.dsCPNorthwind_2007.DataSetName = "cpNorthwind_2007DataSet";
			this.dsCPNorthwind_2007.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// dsCPNorthWindAccess
			// 
			this.dsCPNorthWindAccess.DataSetName = "dscpNorthwind_2007";
			this.dsCPNorthWindAccess.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// tbaCategoryNorthWindAccess
			// 
			this.tbaCategoryNorthWindAccess.BackupDataSetBeforeUpdate = false;
			this.tbaCategoryNorthWindAccess.tbaCategory = this.tbaCategoryOleDB;
			this.tbaCategoryNorthWindAccess.UpdateOrder = CopyPaste.Learning.Data.cpNorthwind_2007DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
			// 
			// frmConnectionWizard
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(448, 301);
			this.Controls.Add(this.cmdTest);
			this.Controls.Add(this.txtTimeOut);
			this.Controls.Add(this.lblTimeOut);
			this.Controls.Add(this.txtDatabase);
			this.Controls.Add(this.lblDatabase);
			this.Controls.Add(this.txtConnectionString);
			this.Controls.Add(this.lblConnectionString);
			this.Controls.Add(this.grpConnectionType);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmConnectionWizard";
			this.Text = "Connection Properties Wizard";
			this.grpConnectionType.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dsCPNorthWindScript2019)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dsCPNorthwind_2007)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dsCPNorthWindAccess)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210630 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20210630 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      if (disposing)
      {
        if (components == null)
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)

      }
      else
        // Not (disposing)
      {
      }
      // (disposing)

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmConnectionWizard()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Setting the ConnectionString of a SQLConnection object 
    //   - mtheConnection becomes cnncpNorthWind2007
    //   - Refresh info on screen
    // Called by
    //   - cpProgram.Main()
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210630 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20210630 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      InitializeComponent();
      this.mcnnSQLConnection = new System.Data.SqlClient.SqlConnection();
      this.mcnnOleDBConnection = new System.Data.OleDb.OleDbConnection();

      dsCPNorthWindScript2019.Clear();
      dsCPNorthwind_2007.Clear();

      this.mcnnSQLConnection.StateChange += new System.Data.StateChangeEventHandler(this.mcnnSQLConnection_StateChange);
      this.mcnnOleDBConnection.StateChange += new System.Data.StateChangeEventHandler(this.mcnnOleDBConnection_StateChange);
      mcnnSQLConnection.ConnectionString = tbaCategorySQLClient.Connection.ConnectionString;
      mcnnOleDBConnection.ConnectionString = tbaCategoryOleDB.Connection.ConnectionString;
      mtheConnection = mcnnOleDBConnection;
      RefreshValues();
    }
    // frmConnectionWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private System.Data.SqlClient.SqlConnection mcnnSQLConnection;
    private System.Data.OleDb.OleDbConnection mcnnOleDBConnection;
    private System.Data.IDbConnection mtheConnection;
    private CopyPaste.Learning.Data.cpNorthwind_2007DataSetTableAdapters.tbaCategory tbaCategoryOleDB;
    private CopyPaste.Learning.Data.cpNorthWindScript2019DataSetTableAdapters.tbaCategory tbaCategorySQLClient;
    private cpNorthwind_2000DataSet dsCPNorthwind_2007;
    private CopyPaste.Learning.Data.cpNorthWindScript2019DataSet dsCPNorthWindScript2019;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdTest_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Open connection
    //   - Show the state of the connection
    //   - Close connection
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - mcnnOleDBConnection_StateChange(System.Object, System.Data.StateChangeEventArgs) Handles cnncpNorthWind2007.StateChange
    //   - mcnnSQLConnection_StateChange(System.Object, System.Data.StateChangeEventArgs) Handles mcnnSQLConnection.StateChange
    // Created
    //   - CopyPaste � 20210630 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20210630 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      this.mtheConnection.Open();
      MessageBox.Show(this.mtheConnection.State.ToString());
      this.mtheConnection.Close();
    }
    // cmdTest_Click(System.Object, System.EventArgs) Handles cmdTest.Click

    private void mcnnOleDBConnection_StateChange(System.Object theSender, System.Data.StateChangeEventArgs theStateChangeEventArguments)
    //***
    // Action
    //   - Prepare message with the statechange
    //   - Show message
    // Called by
    //   - cmdTest_Click(System.Object, System.EventArgs) Handles cmdTest.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210629 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20210629 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      string theMessage;

      theMessage = "The Connection State is changing from " +
        theStateChangeEventArguments.OriginalState.ToString() +
        " to " + theStateChangeEventArguments.CurrentState.ToString();
      MessageBox.Show(theMessage);
    }
    // mcnnOleDBConnection_StateChange(System.Object, System.Data.StateChangeEventArgs) Handles mcnnOleDBConnection.StateChange

    private void mcnnSQLConnection_StateChange(System.Object theSender, System.Data.StateChangeEventArgs theStateChangeEventArguments)
    //***
    // Action
    //   - Prepare message with the statechange
    //   - Show message
    // Called by
    //   - cmdTest_Click(System.Object, System.EventArgs) Handles cmdTest.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210630 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20210630 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      string theMessage;

      theMessage = "The Connection State is changing from " +
        theStateChangeEventArguments.OriginalState.ToString() +
        " to " + theStateChangeEventArguments.CurrentState.ToString();
      MessageBox.Show(theMessage);
    }
    // mcnnSQLConnection_StateChange(System.Object, System.Data.StateChangeEventArgs) Handles mcnnSQLConnection.StateChange

    private void optOleDb_CheckChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - mtheConnection becomes cnncpNorthWind2007
    //   - Refresh info on screen
    // Called by
    //   - 
    // Calls
    //   - RefreshValues()
    // Created
    //   - CopyPaste � 20210629 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20210629 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      mtheConnection = mcnnOleDBConnection;
      RefreshValues();
    }
    // optOleDb_CheckChanged(theSender, theEventArguments) Handles optOleDb.CheckChanged

    private void optSQL_CheckChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - mtheConnection becomes mcnnSQLConnection
    //   - Refresh info on screen
    // Called by
    //   - 
    // Calls
    //   - RefreshValues()
    // Created
    //   - CopyPaste � 20210630 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20210630 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      mtheConnection = mcnnSQLConnection;
      RefreshValues();
    }
    // optSQL_CheckChanged(System.Object, System.EventArgs) Handles optSQL.CheckChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Startingpoint of the application
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmConnectionWizard()
    // Created
    //   - CopyPaste � 20210630 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20210630 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - There is an alternative available in Program.cs
    //***
    {
      Application.Run(new frmConnectionWizard());
    }
    // Main()

    private void RefreshValues()
    //***
    // Action
    //   - Set the connection string as text.
    //   - Determine the database
    //   - Determing the timeout
    // Called by
    //   - frmConnectionWizard()
    //   - optOleDB_CheckedChanged(System.Object, System.EventArgs) Handles optOleDB.CheckedChanged
    //   - optSQL_CheckedChanged(System.Object, System.EventArgs) Handles optSQL.CheckedChanged
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210630 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20210630 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      this.txtConnectionString.Text = this.mtheConnection.ConnectionString;
      this.txtDatabase.Text = this.mtheConnection.Database;
      this.txtTimeOut.Text = this.mtheConnection.ConnectionTimeout.ToString();
    }
    // RefreshValues()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmConnectionWizard

}
// CopyPaste.Learning.Data