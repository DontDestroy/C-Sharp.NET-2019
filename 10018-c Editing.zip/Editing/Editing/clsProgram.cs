﻿//***
// Action
//   - Having DataViews in database actions
// Created
//   - CopyPaste – 20210818 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210818 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Forms;

namespace Editing
{

  static class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Starting the application frmEditing
    // Called by
    //   - User Action (Starting the application)
    // Calls
    //   - frmEditing()
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run(new frmEditing());
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// Editing