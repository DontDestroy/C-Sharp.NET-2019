//***
// Action
//   - Definition of cpPoint
// Created
//   - CopyPaste � 20231230 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231230 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Math
{

	public class cpPoint
	{

		#region "Constructors / Destructors"

		public cpPoint()
			//***
			// Action
			//   - Default constructor
			//   - Sets X and Y property to 0
			// Called by
			//   - cpCircle()
			//   - cpProgram.Main()
			// Calls
			//   - X(int) (Set)
			//   - Y(int) (Set)
			// Created
			//   - CopyPaste � 20231230 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231230 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			X = 0;
			Y = 0;
		}
		// cpPoint()

		public cpPoint(int lngX, int lngY)
			//***
			// Action
			//   - Constructor with 2 arguments
			//   - Sets X and Y property to the given arguments
			// Called by
			//   - cpCircle()
			//   - cpCircle(int, int, double)
			//   - cpProgram.Main()
			// Calls
			//   - X(int) (Set)
			//   - Y(int) (Set)
			// Created
			//   - CopyPaste � 20231230 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231230 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			X = lngX;
			Y = lngY;
		}
		// cpPoint(int, int)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private int mlngX;
		private int mlngY;

		#endregion

		#region "Properties"

		public virtual int X
		{

			get
				//***
				// Action Get
				//   - Returns mlngX
				// Called by
				//   - cpCircle.Center(cpPoint) (Set)
				//   - cpProgram.Main()
				//   - int cpCircle.X (Get)
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231230 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231230 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mlngX;
			}
			// int X (Get)

			set
				//***
				// Action Set
				//   - mlngX becomes value
				// Called by
				//   - cpPoint()
				//   - cpPoint(int, int)
				//   - cpPoint.X(int) (Set)
				//   - cpProgram.Main()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231230 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231230 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				mlngX = value;
			}
			// X(int) (Set)

		}
		// int X

		public virtual int Y
		{

			get
				//***
				// Action Get
				//   - Returns mlngY
				// Called by
				//   - cpCircle.Center(cpPoint) (Set)
				//   - cpProgram.Main()
				//   - int cpCircle.Y (Get)
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231230 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231230 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mlngY;
			}
			// int Y (Get)

			set
				//***
				// Action Set
				//   - mlngY becomes value
				// Called by
				//   - cpPoint()
				//   - cpPoint(int, int)
				//   - cpPoint.Y(int) (Set)
				//   - cpProgram.Main()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20231230 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20231230 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				mlngY = value;
			}
			// Y(int) (Set)

		}
		// int Y

		#endregion

		#region "Methods"

		#region "Overrides"

		public override string ToString()
			//***
			// Action
			//   - Genererates the items shown when asking ToString()
			// Called by
			//   - cpProgram.Main()
			//   - string cpCircle.ToString()
			// Calls
			//   - int X (Get)
			//   - int Y (Get)
			// Created
			//   - CopyPaste � 20231230 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20231230 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			return "[" + X + ", " + Y + "]";
		}
		// string ToString()

		#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpPoint

}
// CopyPaste.Learning.Math