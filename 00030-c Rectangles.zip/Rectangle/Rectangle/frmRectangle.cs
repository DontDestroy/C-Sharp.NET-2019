//***
// Action
//   - Show some lines on the screen
// Created
//   - CopyPaste � 20230614 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230614 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Rectangles
{

  public class frmRectangles : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code
    internal System.Windows.Forms.Timer tmrTimer;
    private System.ComponentModel.IContainer components;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmRectangles));
      this.tmrTimer = new System.Windows.Forms.Timer(this.components);
      // 
      // tmrTimer
      // 
      this.tmrTimer.Interval = 10;
      this.tmrTimer.Tick += new System.EventHandler(this.tmrTimer_Tick);
      // 
      // frmRectangles
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(492, 373);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmRectangles";
      this.Text = "Rectangles";
      this.Load += new System.EventHandler(this.frmRectangles_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmRectangles'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmRectangles()
      //***
      // Action
      //   - Create instance of 'frmRectangles'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmRectangles()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    Graphics mtheGraphic;
    int mlngCounter = 0;
    int mlngHeight;
    int mlngWidth;
    int mlngX1;
    int mlngY1;
    Random mrndRandom = new Random(DateTime.Now.Millisecond);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmRectangles_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a graphic tool
    //   - Start a timer with an interval of 50 milliseconds
    // Called by
    //   - System action (Starting the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      mtheGraphic = CreateGraphics();
      tmrTimer.Interval = 50;
      tmrTimer.Enabled = true;
    }
    // frmRectangles_Load(System.Object, System.EventArgs) Handles this.Load
    
    private void tmrTimer_Tick(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - An X and Y coordinate are calculated for one point
    //   - A width and a heightare calculated for having the size of the rectangle
    //   - With all information a rectangle is drawn
    //   - The number of rectangle is added by 1
    //   - The number of rectangle is shown in the title of the form
    // Called by
    //   - System action (Timer Tick)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      mlngX1 = Convert.ToInt32(mrndRandom.Next(Width - 100));
      mlngY1 = Convert.ToInt32(mrndRandom.Next(Height - 100));
      mlngHeight = Convert.ToInt32(mrndRandom.Next(100));
      mlngWidth = Convert.ToInt32(mrndRandom.Next(100));
      mtheGraphic.DrawRectangle(Pens.Red, mlngX1, mlngY1, mlngWidth, mlngHeight);
      mlngCounter += 1;
      this.Text = "Number of rectangles: " + mlngCounter.ToString();
    }
    // tmrTimer_Tick(System.Object theSender, System.EventArgs theEventArguments) Handles tmrTimer.Tick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmRectangles
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmRectangles());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmRectangles

}
// Rectangles