﻿//***
// Action
//   - Check the validations on a string
// Created
//   - CopyPaste – 20260121 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260121 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpInvalidStringException: System.ApplicationException
  {

    #region "Constructors / Destructors"

    public cpInvalidStringException(string strMessage): base(strMessage)
      //***
      // Action
      //   - Define the error message
      // Called by
      //   - cpInvalidBelgianBankAccountException(string)
      //   - cpInvalidExtensionException(string)
      //   - cpInvalidPhoneNumberException(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpInvalidStringException(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
		//#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpInvalidStringException

}
// CopyPaste.Learning