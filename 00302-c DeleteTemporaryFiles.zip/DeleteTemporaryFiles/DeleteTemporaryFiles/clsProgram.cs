// Action
//   - Delete all files with an extension 'tmp'
// Created
//   - CopyPaste � 20240902 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240902 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Process the tree T:\
      //   - Show a message
      //   - Wait till enter is hit
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      ProcessTree("T:\\");
      Console.Write("Press Enter to Continue...");
      Console.ReadLine();
    }
		// Main()

    public static void ProcessTree(string strDirectory)
      //***
      // Action
      //   - Get all the directories
      //   - Get all the files that has an extension 'tmp'
      //   - Loop thru all the files
      //     - Try
      //       - Switch off the read only attribute of the file
      //       - Delete the file
      //       - Show what file is deleted
      //     - On error
      //       - Show that a file could not be deleted
      //       - Show the exception error
      //   - Loop thru all the directories
      //     - Try
      //       - Process the directory
      //     - On error
      //       - Show that a directory could not be accessed
      //       - Show the exception error
      // Called by
      //   - Main()
      //   - ProcessTree(string)
      // Calls
      //   - ProcessTree(string)
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      DirectoryInfo theDirectory = new DirectoryInfo(strDirectory);

      DirectoryInfo[] arrDirectoryInfo = theDirectory.GetDirectories("*.*");
      FileInfo[] arrFile = theDirectory.GetFiles("*.tmp");

      foreach(FileInfo theFile in arrFile)
      {

        try
        {

          if (Convert.ToBoolean(theFile.Attributes & FileAttributes.ReadOnly))
          {
            theFile.Attributes = theFile.Attributes & ~FileAttributes.ReadOnly;
          }
          else
            // Not Convert.ToBoolean(theFile.Attributes And FileAttributes.ReadOnly)
          {
          }
          // Convert.ToBoolean(theFile.Attributes And FileAttributes.ReadOnly)

          File.Delete(theFile.FullName);
          Console.WriteLine("Delete {0}", theFile.FullName);
        }
        catch (Exception theException)
        {
          Console.WriteLine("*** Error deleting {0}", theFile.FullName);
          Console.WriteLine("Error: {0}", theException.Message);
        }

      }
      // in arrFile
      
      foreach (DirectoryInfo theDirectoryName in arrDirectoryInfo)
      {

        try
        {
          ProcessTree(theDirectoryName.FullName);
        }
        catch (Exception theException)
        {
          Console.WriteLine("*** Error accessing {0}", theDirectoryName.FullName);
          Console.WriteLine("Error: {0}", theException.Message);
        }

      }
      // in arrDirectoryInfo

    }
    // ProcessTree(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning