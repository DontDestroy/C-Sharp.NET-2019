//***
// Action
//   - Definition of a cpDataGridComboBoxColumn
//   - How it works
//   - Step 1. You need a column style
//	    - 1a) Add a ComboBox
//     - 1b) Focus in Enter and Leave events for that ComboBox (1a)
//     - 1c) Override Edit (TextBox is not longer active, ComboBox is)
//     - 1d) Override Commit to save the changed data
// Created
//   - CopyPaste � 20260706 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260706 � VVDW
// Proposal (To Do)
//   - Data is not changed in the database, the update is not executed / programmed
//***

using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.Data
{

  public class cpDataGridComboBoxColumn : System.Windows.Forms.DataGridTextBoxColumn
  {

    #region "Constructors / Destructors"

    public cpDataGridComboBoxColumn()
      //***
      // Action
      //   - Set the currency manager to nothing
      //   - Set editing to false
      //   - Set row count to no rows
      //   - Create a new instance of cpNoKeyUpCombo
      //   - Set the dropdown style to a dropdown list
      //   - Set the event Leave to LeaveComboBox functionality
      //   - Set the event SelectionChangeCommitted to ComboStartEditing functionality
      // Called by
      //   - frmTryout.MakeDataSetAndBindGrid()
      //   - User action (Creating the control)
      // Calls
      //   - ComboStartEditing(System.Object, System.EventArgs)
      //   - cpNoKeyUpCombo()
      //   - LeaveComboBox(System.Object, System.EventArgs)
      // Created
      //   - CopyPaste � 20260706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheCurrencyManager = null;
      mblnEditing = false;
      mlngRowCount = -1;

      mcpComboBox = new cpNoKeyUpCombo();
      mcpComboBox.DropDownStyle = ComboBoxStyle.DropDownList;

      mcpComboBox.Leave += new EventHandler(LeaveComboBox);
      mcpComboBox.SelectedIndexChanged += new EventHandler(ComboBoxStartEditing);
    }
    // cpDataGridComboBoxColumn()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private bool mblnEditing;
    public cpNoKeyUpCombo mcpComboBox;
    private CurrencyManager mtheCurrencyManager;
    private int mlngRow;
    private static int mlngRowCount;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override bool Commit(CurrencyManager theCurrencyManager, int lngRowNumber)
      //***
      // Action
      //   - If you are editing
      //     - Set editing to false
      //     - Set the correct column value at a specific row
      //   - If not
      //     - Do nothing
      //   - Return that is was successfully committed
      // Called by
      //   - User action (A value is changes with combobox and an other column of row is selected)
      // Calls
      //   - SetColumnValueAtRow(CurrencyManager, int, System.Object)
      // Created
      //   - CopyPaste � 20260706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (mblnEditing)
      {
        mblnEditing = false;
        SetColumnValueAtRow(theCurrencyManager, lngRowNumber, mcpComboBox.Text);
      }
      else
        // Not mblnEditing 
      {
      }
      // mblnEditing 

      return true;
    }
    // bool Commit(CurrencyManager, int)

    protected override void Edit(CurrencyManager theCurrencyManager, int lngRowNumber, Rectangle theRectangle, bool blnReadOnly, string strInstant, bool blnCellIsVisible)
      //***
      // Action
      //   - Execute the base actions
      //   - Set the row number
      //   - Set the currency mananger
      //   - Set the parent of the combobox (inside the textbox)
      //   - Set the location
      //   - Set the size
      //   - Set the index (Select the correct item)
      //   - Set the text
      //   - Textbox is not needed, so not visible
      //   - Show the combobox
      //   - Make sure the scrolling in the datagrid works correctly
      //   - Combo box is at front of the screen
      //   - Combo box gets the focus
      // Called by
      //   - User action (Selecting a column and row where a combobox is placed)
      // Calls
      //   - HandleScroll(System.Object, System.EventArgs)
      // Created
      //   - CopyPaste � 20260706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      base.Edit(theCurrencyManager, lngRowNumber, theRectangle, blnReadOnly, strInstant, blnCellIsVisible);

      mlngRow = lngRowNumber;
      mtheCurrencyManager = theCurrencyManager;
      mcpComboBox.Parent = TextBox.Parent;
      mcpComboBox.Location = TextBox.Location;
      mcpComboBox.Size = new Size(TextBox.Size.Width, TextBox.Size.Height);
      mcpComboBox.SelectedIndex = mcpComboBox.FindStringExact(TextBox.Text);
      mcpComboBox.Text = TextBox.Text;
      TextBox.Visible = false;
      mcpComboBox.Visible = true;
      DataGridTableStyle.DataGrid.Scroll += new EventHandler(HandleScroll);
      mcpComboBox.BringToFront();
      mcpComboBox.Focus();
    }
    // Edit(CurrencyManager, int, Rectangle, bool, String, bool)

    protected override object GetColumnValueAtRow(CurrencyManager theCurrencyManager, int lngRow)
    {
      DataView theDataView = (DataView)mcpComboBox.DataSource;
      int lngCount = 0;
      int lngRowCount;
      System.Object theObject1 = base.GetColumnValueAtRow(theCurrencyManager, lngRow);
      System.Object theObject2; 
      System.Object theReturnObject; 

      lngRowCount = theDataView.Count;

      while (lngCount < lngRowCount)
      {
        theObject2 = theDataView[lngCount][mcpComboBox.ValueMember];
                                                                     
        if ((theObject2 != DBNull.Value) && (theObject1 != DBNull.Value) && ((string)theObject2 == (string)theObject1))
        {
          lngRowCount = -1;
        }
        else
          // (theObject2 = DBNull.Value) OrElse (theObject1 = DBNull.Value) OrElse theObject2 <> theObject1
        {
          lngCount += 1;
        }
        // (Not theObject2 Is DBNull.Value) AndAlso (Not theObject1 Is DBNull.Value) AndAlso theObject2 = theObject1 
                                                                   
      }
      // lngCount >= lngRowCount

      lngRowCount = theDataView.Count;

      if (lngCount < lngRowCount)
      {
        theReturnObject = theDataView[lngCount][mcpComboBox.DisplayMember];
      }
      else
        // lngCount >= lngRowCount 
      {
        theReturnObject = DBNull.Value;
      }
      // lngCount < lngRowCount 

      return theReturnObject;
    }
    // GetColumnValueAtRow(CurrencyManager, int) As System.Object

    protected override void SetColumnValueAtRow(CurrencyManager theCurrencyManager, int lngRow, System.Object objValue)
      //***
      // Action
      //   - Sets the choosen value to a specific column at a specific row
      //   - Define and initialize a data view on the data source of the combobox
      //   - Get the value (Object, because it can be everything)
      //   - Count the number of rows (in the data view)
      //   - Loop thru the rows
      //     - Get the value at a specific row
      //     - If the value is found
      //       - Set the criteria to exit the loop
      //     - If not
      //       - Increment the counter
      //   - Count the number of rows (in the data view)
      //   - If counter is inside the range (lower than the count)
      //     - Value can be set
      //   - If not
      //     - Null value is set
      // Called by
      //   - Commit(CurrencyManager, int) As bool
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngCount = 0;
      int lngRowCount;
      DataView theDataView = (DataView)mcpComboBox.DataSource;
      System.Object theObject1 = objValue;
      System.Object theObject2;

      lngRowCount = theDataView.Count;

      while (lngCount < lngRowCount)
      {
        theObject2 = theDataView[lngCount][mcpComboBox.DisplayMember];

        if ((theObject1 != DBNull.Value) && ((string)theObject1 == (string)theObject2))
        {
          lngRowCount = -1;
        }
        else
          // (theObject1 = DBNull.Value) OrElse theObject1 <> theObject2 
        {
          lngCount += 1;
        }
        // (Not theObject1 Is DBNull.Value) AndAlso theObject1 = theObject2 

      }
      // lngCount >= lngRowCount

      lngRowCount = theDataView.Count;

      if (lngCount < lngRowCount)
      {
        theObject2 = theDataView[lngCount][mcpComboBox.ValueMember];
      }
      else
        // lngCount >= lngRowCount
      {
        theObject2 = DBNull.Value;
      }
      // lngCount < lngRowCount

      base.SetColumnValueAtRow (theCurrencyManager, lngRow, theObject2);
    }
    // SetColumnValueAtRow(CurrencyManager, int, System.Object)

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void ComboBoxStartEditing(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set editing to true
      //   - Default execution of ColumnStartedEditing
      // Called by
      //   - User action (Starting editing combo box)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mblnEditing = true;
      base.ColumnStartedEditing((Control)theSender);
    }
    // ComboStartEditing(System.Object, System.EventArgs)

    private void HandleScroll(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - When you scroll through the data grid
      //   - If combo box is visible
      //     - Hide the combo box
      //   - If not
      //     - Do nothing
      // Called by
      //   - Edit(CurrencyManager, int, Rectangle, bool, String, bol)
      //   - LeaveComboBox(System.Object, System.EventArgs)
      //   - User action (Scrolling in data grid)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (mcpComboBox.Visible)
      {
        mcpComboBox.Hide();
      }
      else
        // not mcpComboBox.Visible
      {
      }
      // mcpComboBox.Visible

    }
    // HandleScroll(System.Object, System.EventArgs)

    private void LeaveComboBox(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If you are editing
      //     - Set the choosen value of combo box in the data grid
      //     - Set editing to false
      //     - Redraw the grid
      //   - If not
      //     - Do nothing
      //   - Hide the combo box
      //   - Make sure when you scroll the the combo box is treated correctly
      // Called by
      //   - cpDataGridComboBoxColumn()
      //   - User action (Exiting the Combo Box)
      // Calls
      //   - HandleScroll(System.Object, System.EventArgs)
      // Created
      //   - CopyPaste � 20260706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (mblnEditing)
      {
        SetColumnValueAtRow(mtheCurrencyManager, mlngRow, mcpComboBox.Text);
        mblnEditing = false;
        Invalidate();
      }
      else
        // Not mblnEditing
      {
      }
      // mblnEditing

      mcpComboBox.Hide();
      DataGridTableStyle.DataGrid.Scroll += new EventHandler(HandleScroll);
    }
    // LeaveComboBox(System.Object, System.EventArgs)

    #endregion

    #endregion

    #endregion

    #region "Not used"

    protected override void ConcedeFocus()
      //***
      // Action
      //   - The focus is not necessary anymore
      // Called by
      //   - During tests, I could not trigger this
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      base.ConcedeFocus ();
    }

    #endregion

  }
  // cpDataGridComboBoxColumn

}
// CopyPaste.Learning.Data