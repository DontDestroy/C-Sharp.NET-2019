//***
// Action
//   - Demo of a progressbar
// Created
//   - CopyPaste � 20240330 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240330 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmProgressBar: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.StatusBar stbInfo;
    internal System.Windows.Forms.Button cmdCalculate;
    internal System.Windows.Forms.ProgressBar prgBar;
    internal System.Windows.Forms.Label lblThird;
    internal System.Windows.Forms.Label lblSecond;
    internal System.Windows.Forms.Label lblFirst;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmProgressBar));
      this.stbInfo = new System.Windows.Forms.StatusBar();
      this.cmdCalculate = new System.Windows.Forms.Button();
      this.prgBar = new System.Windows.Forms.ProgressBar();
      this.lblThird = new System.Windows.Forms.Label();
      this.lblSecond = new System.Windows.Forms.Label();
      this.lblFirst = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // stbInfo
      // 
      this.stbInfo.Location = new System.Drawing.Point(0, 207);
      this.stbInfo.Name = "stbInfo";
      this.stbInfo.Size = new System.Drawing.Size(456, 22);
      this.stbInfo.TabIndex = 11;
      // 
      // cmdCalculate
      // 
      this.cmdCalculate.Location = new System.Drawing.Point(328, 32);
      this.cmdCalculate.Name = "cmdCalculate";
      this.cmdCalculate.Size = new System.Drawing.Size(112, 23);
      this.cmdCalculate.TabIndex = 10;
      this.cmdCalculate.Text = "Calculate";
      this.cmdCalculate.Click += new System.EventHandler(this.cmdCalculate_Click);
      // 
      // prgBar
      // 
      this.prgBar.Location = new System.Drawing.Point(24, 160);
      this.prgBar.Name = "prgBar";
      this.prgBar.Size = new System.Drawing.Size(408, 23);
      this.prgBar.TabIndex = 9;
      // 
      // lblThird
      // 
      this.lblThird.Location = new System.Drawing.Point(24, 112);
      this.lblThird.Name = "lblThird";
      this.lblThird.Size = new System.Drawing.Size(280, 23);
      this.lblThird.TabIndex = 8;
      this.lblThird.Text = "Factorial of ";
      // 
      // lblSecond
      // 
      this.lblSecond.Location = new System.Drawing.Point(24, 72);
      this.lblSecond.Name = "lblSecond";
      this.lblSecond.Size = new System.Drawing.Size(272, 23);
      this.lblSecond.TabIndex = 7;
      this.lblSecond.Text = "Factorial of ";
      // 
      // lblFirst
      // 
      this.lblFirst.Location = new System.Drawing.Point(24, 32);
      this.lblFirst.Name = "lblFirst";
      this.lblFirst.Size = new System.Drawing.Size(280, 23);
      this.lblFirst.TabIndex = 6;
      this.lblFirst.Text = "Factorial of  ";
      // 
      // frmProgressBar
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(456, 229);
      this.Controls.Add(this.stbInfo);
      this.Controls.Add(this.cmdCalculate);
      this.Controls.Add(this.prgBar);
      this.Controls.Add(this.lblThird);
      this.Controls.Add(this.lblSecond);
      this.Controls.Add(this.lblFirst);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmProgressBar";
      this.Text = "ProgressBar";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmProgressBar'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmProgressBar()
      //***
      // Action
      //   - Create instance of 'frmProgressBar'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmProgressBar()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCalculate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Reset to the start values of the form
      //   - Calculate the factorial of 5
      //   - Set progress bar to 33%
      //   - Calculate the factorial of 10
      //   - Set progress bar to 66%
      //   - Calculate the factorial of 15
      //   - Set progress bar to 100%
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - double Factorial(int)
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      byte bytValue;

      this.Text = "Progress Bar";
      lblFirst.Text = "";
      lblFirst.Refresh();
      lblSecond.Text = "";
      lblSecond.Refresh();
      lblThird.Text = "";
      lblThird.Refresh();
      prgBar.Value = 0;

      bytValue = 5;

      stbInfo.Text = "Calculating Factorial(" + bytValue + ")";
      lblFirst.Text = "Factorial of " + bytValue + ": " + Factorial(bytValue);
      lblFirst.Refresh();
      prgBar.Value = 33;

      bytValue = 10;

      stbInfo.Text = "Calculating Factorial(" + bytValue + ")";
      lblSecond.Text = "Factorial of " + bytValue + ": " + Factorial(bytValue);
      lblSecond.Refresh();
      prgBar.Value = 66;

      bytValue = 15;

      stbInfo.Text = "Calculating Factorial(" + bytValue + ")";
      lblThird.Text = "Factorial of " + bytValue + ": " + Factorial(bytValue);
      lblThird.Refresh();
      prgBar.Value = 100;

      this.Text = "Done";
    }
    // cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static double Factorial(int intValue)
      //***
      // Action
      //   - We calculate the factorial of a number
      //   - How is this done
      //     - The factorial of 6 => 6! => is 6 times the factorial of 5
      //     - and so on
      //     - The factorial of 0 is 1.
      //     --> Factorial of 6 = 6 * 5 * 4 * 3 * 2 * 1
      //   - If intValue equals 0
      //     - Wait 2 seconds
      //     - return 1
      //   - If not
      //     - Calculate the factorial of one less and multiply with intValue
      //     - Return that value
      // Called by
      //   - cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click
      //   - double Factorial(int)
      // Calls
      //   - double Factorial(int)
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      double dblReturnValue;

      if (intValue == 0)
      {
        System.Threading.Thread.Sleep(2000);
        dblReturnValue = 1.0;
      }
      else
        // intValue <> 0
      {
        dblReturnValue = (intValue * Factorial(intValue - 1));
      }
      // bytValue = 0

      return dblReturnValue;
    }
    // double Factorial(int)

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmProgressBar
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmProgressBar());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmProgressBar

}
// CopyPaste.Learning