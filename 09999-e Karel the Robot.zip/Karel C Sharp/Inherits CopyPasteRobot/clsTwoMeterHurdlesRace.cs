﻿//***
// Action
//   - A definition of a TwoMeterHurdlesRace
// Created
//   - CopyPaste – 20251014 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251014 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpTwoMeterHurdlesRace : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpTwoMeterHurdlesRace(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpTwoMeterHurdlesRace starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpProgram.TwoMeterHurdlesRace()
    //   - cpTwoMeterHurdlesRace(int, int, Directions.Direction, int)
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
		// cpTwoMeterHurdlesRace(int, int, Directions.Direction, int, Color) 

		public cpTwoMeterHurdlesRace(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Robot becomes a cpTwoMeterHurdlesRace starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
		//   - Nothing else happens
		// Called by
		//   - 
		// Calls
		//   - cpTwoMeterHurdlesRace(int, int, Directions.Direction, int, Color)
		// Created
		//   - CopyPaste – 20251014 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251014 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
		}
		// cpTwoMeterHurdlesRace(int, int, Directions.Direction, int) 

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		private void GlideDown()
    //***
    // Action
    //   - Turn right
    //   - Move
    //   - Turn left
    // Called by
    //   - JumpHurdle()
    // Calls
    //   - cpCopyPasteRobot.TurnRight()
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      TurnRight();
			move();
			turnLeft();
		}
    // GlideDown()

    private void JumpHurdle()
    //***
    // Action
    //   - Jump up
    //   - Move
    //   - Glide down
    // Called by
    //   - RunRacePart()
    // Calls
    //   - GlideDown()
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      JumpUp();
      move();
      GlideDown();
    }
    // JumpHurdle()

    private void JumpUp()
    //***
    // Action
    //   - Turn left
    //   - Move
    //   - Turn right
    // Called by
    //   - JumpHurdle()
    // Calls
    //   - cpCopyPasteRobot.TurnRight()
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      turnLeft();
      move();
      TurnRight();
    }
    // JumpUp()

    public void RunRacePart()
    //***
    // Action
    //   - If there is a hurdle
    //     - Jump over it
    //   - If not
    //     - Move forward
    // Called by
    //   - cpProgram.TwoMeterHurdlesRace()
    // Calls
    //   - JumpHurdle()
    // Created
    //   - CopyPaste – 20251014 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251014 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (frontIsClear())
      {
        move();
      }
      else
      // Not frontIsClear()
      {
        JumpHurdle();
      }
      // frontIsClear()

    }
    // RunRacePart()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpTwoMeterHurdlesRace

}
// cpKarelTheRobot