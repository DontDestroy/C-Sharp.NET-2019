//***
// Action
//   - Working with a basic array list
// Created
//   - CopyPaste � 20220214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220214 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace BasicArrayList
{

  public class frmBasicArrayList : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code
    internal System.Windows.Forms.Button cmdFind;
    internal System.Windows.Forms.Button cmdToDo;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBasicArrayList));
      this.cmdFind = new System.Windows.Forms.Button();
      this.cmdToDo = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdFind
      // 
      this.cmdFind.Location = new System.Drawing.Point(16, 64);
      this.cmdFind.Name = "cmdFind";
      this.cmdFind.Size = new System.Drawing.Size(264, 32);
      this.cmdFind.TabIndex = 3;
      this.cmdFind.Text = "&Find something in Array";
      this.cmdFind.Click += new System.EventHandler(this.cmdFind_Click);
      // 
      // cmdToDo
      // 
      this.cmdToDo.Location = new System.Drawing.Point(16, 16);
      this.cmdToDo.Name = "cmdToDo";
      this.cmdToDo.Size = new System.Drawing.Size(264, 32);
      this.cmdToDo.TabIndex = 2;
      this.cmdToDo.Text = "&Things to do today";
      this.cmdToDo.Click += new System.EventHandler(this.cmdToDo_Click);
      // 
      // frmBasicArrayList
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdFind);
      this.Controls.Add(this.cmdToDo);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBasicArrayList";
      this.Text = "Basic ArrayList";
      this.Load += new System.EventHandler(this.frmBasicArrayList_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmBasicArrayList'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220214 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220214 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBasicArrayList()
    //***
    // Action
    //   - Create instance of 'frmBasicArrayList'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220214 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220214 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmBasicArrayList()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    ArrayList marrLaborsOfHercules = new ArrayList();
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFind_Click(object sender, System.EventArgs e)
    //***
    // Action
    //   - Find a specific element in the array list
    //   - Show info in MessageBox
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - int ArrayList.IndexOf(Array, System.Object)
    //   - DialogResult MessageBox.Show(string, string)
    //   - ArrayList.Sort(Array)
    // Created
    //   - CopyPaste � 20220214 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220214 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngIndex;
      
      lngIndex = marrLaborsOfHercules.IndexOf("Learn C# .NET");
      MessageBox.Show("In element: " + lngIndex.ToString(), "Copy Paste Tryout");

      marrLaborsOfHercules.Sort();
      lngIndex = marrLaborsOfHercules.IndexOf("Learn C# .NET");
      MessageBox.Show("In element: " + lngIndex.ToString(), "Copy Paste Tryout");
    }
    // cmdFind_Click(System.Object, System.EventArgs) Handles cmdFind.Click

    private void cmdToDo_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Loop thru elements of array
    //     - Prepare message with value of element
    //   - Show info in MessageBox
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - ArrayList.Reverse()
    //   - ArrayList.Sort()
    //   - DialogResult MessageBox.Show(string, string) 
    // Created
    //   - CopyPaste � 20220214 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220214 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      long lngIndex = 0;
      string strCollectionContent = "";
      
      // marrLaborsOfHercules.Sort()
      // marrLaborsOfHercules.Reverse()
      
      foreach (string strCollectionItemContent in marrLaborsOfHercules)
      {
        strCollectionContent += strCollectionItemContent + "\n";
        // lngIndex += 1;
        // strCollectionContent += lngIndex.ToString() + ". " + strCollectionItemContent + "\n";
      }
      // In marrLaborsOfHercules
      
      MessageBox.Show(strCollectionContent, "Copy Paste Tryout");
    }
    // cmdToDo_Click(theSender, theEventArguments) Handles cmdToDo.Click

    private void frmBasicArrayList_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Fill an array list with 13 elements
    //   - Show some info in MessageBox
    // Called by
    //   - User action (Loading a form)
    // Calls
    //   - ArrayList.Clear()
    //   - ArrayList.TrimToSize()
    //   - DialogResult MessageBox.Show(string, string)
    //   - int ArrayList.Add(string)
    //   - int ArrayList.Capacity()
    //   - int ArrayList.Count()
    // Created
    //   - CopyPaste � 20220214 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220214 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strCollectionInfo;
            
      marrLaborsOfHercules.Add("Kill Nemean Lion");
      marrLaborsOfHercules.Add("Slay nine-headed hydra of Lerna");
      marrLaborsOfHercules.Add("Capture elusive Stag of Arcadia");
      marrLaborsOfHercules.Add("Capture wild boar on Mt. Erymantus");
      marrLaborsOfHercules.Add("Clean Stables of King Augeas of Elis");
      marrLaborsOfHercules.Add("Shoot monstrous man-eating burds of the Stymphalian Marshes");
      marrLaborsOfHercules.Add("Capture mad bul of Crete");
      marrLaborsOfHercules.Add("Kill man-eating mares of King Diomedes");
      marrLaborsOfHercules.Add("Steal Girdle of Hippolyta");
      marrLaborsOfHercules.Add("Seize cattle of Geryon of Erytheia");
      marrLaborsOfHercules.Add("Fetch golden apples of Hesperides");
      marrLaborsOfHercules.Add("Retrieve three-headed dog Cerberus from Hell");
      marrLaborsOfHercules.Add("Learn C# .NET");
      // marrLaborsOfHercules.Add("Learn C# .NET in a single day");
      
      // marrLaborsOfHercules.Clear()
      // marrLaborsOfHercules.TrimToSize()
      
      strCollectionInfo = "Collection Count is: " + marrLaborsOfHercules.Count.ToString() + "\n";
      strCollectionInfo += "Collection Capacity is: " + marrLaborsOfHercules.Capacity.ToString() + "\n";
      
      MessageBox.Show(strCollectionInfo, "Copy Paste Tryout: Collection Information");
    }
    // frmBasicArrayList_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmBasicArrayList
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220214 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220214 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmBasicArrayList());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmBasicArrayList

}
// BasicArrayList