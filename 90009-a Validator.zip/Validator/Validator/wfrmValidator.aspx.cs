﻿//***
// Action
//   - Demo of a Validator Web Control
// Created
//   - CopyPaste – 20260529 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260529 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmValidator : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.calSelectDay.SelectionChanged += new System.EventHandler(this.calSelectDay_SelectionChanged);
      this.cstvalDateSelected.ServerValidate += new System.Web.UI.WebControls.ServerValidateEventHandler(this.cstvalDateSelected_ServerValidate);
      this.txtSelectedDay.TextChanged += new System.EventHandler(this.txtSelectedDay_TextChanged);
      this.ID = "wfrmValidator";
      this.Load += new System.EventHandler(this.Page_Load);
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when initializing the page
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260529 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260529 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void calSelectDay_SelectionChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Selected date is shown in a text box
    // Called by
    //   - User action (Selecting a date)
    // Calls
    //   - InitializeComponent
    // Created
    //   - CopyPaste – 20260529 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260529 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      txtSelectedDay.Text = calSelectDay.SelectedDate.ToString("dd/MM/yyyy");
      txtSelectedDayMonthFormat.Text = calSelectDay.SelectedDate.ToShortDateString();
    }
    // calSelectDay_SelectionChanged(System.Object, System.EventArgs) Handles calSelectDay.SelectionChanged

    private void cstvalDateSelected_ServerValidate(System.Object theSource, System.Web.UI.WebControls.ServerValidateEventArgs theServerValidateEventArguments)
    //***
    // Action
    //   - Try to
    //     - Set a culture info for NL-BE
    //     - Convert the selected date
    //     - Define a date from to first day of the year
    //     - Define a date till to last day of the year
    //     - Depending on the date
    //       - Before date from
    //         - The argument IsValid of the routine is set to false
    //         - The custom validator error message is set to "Date must be greater or equal to date from"
    //       - After date till
    //         - The argument IsValid of the routine is set to false
    //         - The custom validator error message is set to "Date must be smaller or equal to date till"
    //       - All other cases
    //         - The argument IsValid of the routine is set to true
    //   - On occuring error
    //     - The argument IsValid of the routine is set to false
    //     - The custom validator error message is set to "No date"
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260529 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260529 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      try
      {
        DateTimeFormatInfo theDateTimeFormatInfo = new CultureInfo("NL-BE", false).DateTimeFormat;
        DateTime theDate = Convert.ToDateTime(theServerValidateEventArguments.Value, theDateTimeFormatInfo);
        DateTime dtmFrom = new DateTime(DateTime.Today.Year, 1, 1);
        DateTime dtmTill = new DateTime(DateTime.Today.Year, 12, 31);

        if (theDate < dtmFrom)
        {
          theServerValidateEventArguments.IsValid = false;
          cstvalDateSelected.ErrorMessage = "Date must be greater or equal to " + dtmFrom.ToString("dd/MM/yyyy");
        }
        else if (theDate > dtmTill)
        {
          theServerValidateEventArguments.IsValid = false;
          cstvalDateSelected.ErrorMessage = "Date must be smaller or equal to " + dtmTill.ToString("dd/MM/yyyy");
        }
        else
        {
          theServerValidateEventArguments.IsValid = true;
        }

      }
      catch (Exception theException)
      {
        theServerValidateEventArguments.IsValid = false;
        cstvalDateSelected.ErrorMessage = "No date";
      }

    }
    // cstvalDateSelected_ServerValidate(System.Object, System.Web.UI.WebControls.ServerValidateEventArgs) Handles cstvalDateSelected.ServerValidate

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when the page is loaded
    //   - If is postback
    //     - Do nothing
    //   - If not
    //     - Define and initialize the first day of the year
    //     - Define and intiialize the last day of the year
    //     - Selected date is today
    //     - Set the error message and value to compare validator for date from
    //     - Set the error message and value to compare validator for date to
    //     - Set minimum value for range validator
    //     - Set maximum value for range validator
    //     - Set the error message for the range validator
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260529 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260529 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (IsPostBack)
      {
      }
      else
      // Not IsPostBack
      {
        DateTime dtmFrom = new DateTime(DateTime.Today.Year, 1, 1);
        DateTime dtmTill = new DateTime(DateTime.Today.Year, 12, 31);

        calSelectDay.SelectedDate = DateTime.Today;
        calSelectDay_SelectionChanged(theSender, theEventArguments);

        cmpvDateSelectedFrom.ErrorMessage = "Date must be greater of equal to " + dtmFrom.ToString("dd/MM/yyyy");
        cmpvDateSelectedFrom.ValueToCompare = dtmFrom.ToShortDateString();
        cmpvDateSelectedTo.ErrorMessage = "Date must be smaller or equal to " + dtmTill.ToString("dd/MM/yyyy");
        cmpvDateSelectedTo.ValueToCompare = dtmTill.ToShortDateString();

        rgvDateSelected.MinimumValue = dtmFrom.ToShortDateString();
        rgvDateSelected.MaximumValue = dtmTill.ToShortDateString();
        rgvDateSelected.ErrorMessage = "Date must be between " + dtmFrom.ToString("dd/MM/yyyy") + " and " + dtmTill.ToString("dd/MM/yyyy");
      }
      // IsPostBack

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    private void txtSelectedDay_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - If the text in the textbox is a date
    //     - Adapt the selected date in the calendar
    //   - If not
    //     - Do nothing
    // Called by
    //   - User action (Changing a text box)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260529 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260529 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      try
      {
        DateTimeFormatInfo theDateTimeFormatInfo = new CultureInfo("NL-BE", false).DateTimeFormat;

        calSelectDay.SelectedDate = Convert.ToDateTime(txtSelectedDay.Text, theDateTimeFormatInfo);
        txtSelectedDayMonthFormat.Text = calSelectDay.SelectedDate.ToShortDateString();
      }
      catch (Exception theException)
      {
        txtSelectedDayMonthFormat.Text = txtSelectedDay.Text;
      }

    }
    // txtSelectedDay_TextChanged(System.Object, System.EventArgs) Handles txtSelectedDay.TextChanged

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmValidator

}
// CopyPaste.Learning