﻿//***
// Action
//   - A definition of a StrategyBeeperLayerAlternative
// Created
//   - CopyPaste – 20251028 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251028 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

  public class cpStrategyBeeperLayerAlternative : cpAbstractBeeperLayer
  {

    #region "Constructors / Destructors"

    public cpStrategyBeeperLayerAlternative(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpStrategyBeeperLayerAlternative starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag with a given strategy
    // Called by
    //   - cpStrategyBeeperLayerAlternative(int, int, Directions.Direction, int) 
    // Calls
    //   - cpAbstractBeeperLayer(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpStrategyBeeperLayerAlternative(int, int, Directions.Direction, int, Color) 

    public cpStrategyBeeperLayerAlternative(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpStrategyBeeperLayerAlternative starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpStrategyBeeperLayerAlternative(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpStrategyBeeperLayerAlternative(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpinfStrategy myStrategy = new cpNullStrategy();

    #endregion

    #region "Properties"

    public cpinfStrategy Strategy
    {

      set
      //***
      // Action Set
      //   - The given strategy (value) is assigned to myStrategy
      // Called by
      //   - cpProgram.StrategyDelegation()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251028 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251028 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        myStrategy = value;
      }
      // Strategy(cpinfStrategy) (Set)

    }
    // cpinfStrategy Strategy

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override void PutBeepers()
    //***
    // Action
    //   - Execute by delegation the given strategy in the constructor
    // Called by
    //   - cpProgram.StrategyDelegation()
    // Calls
    //   - cpinfStrategy.DoIt(cpCopyPasteRobot);
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      myStrategy.DoIt(this);
    }
    // PutBeepers()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpStrategyBeeperLayerAlternative

}
// cpKarelTheRobot