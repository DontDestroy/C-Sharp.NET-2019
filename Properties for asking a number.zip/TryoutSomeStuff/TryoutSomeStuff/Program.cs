﻿using System;

namespace LearnCSharp
{
  class CorrectPositiveNumber
  {
    private decimal number;
    private bool isWrong = true;

    public decimal Number
    {

      get
      {

        while (isWrong)
        {

          try
          {
            Console.WriteLine("Give a number");
            number = Convert.ToDecimal(Console.ReadLine());

            if (number < 0)
            {
              Console.WriteLine("You fool, give a positive number");
            }
            else
            {
              isWrong = false;
            }
          }
          catch
          {
          }

        }

        return number;
      }

    }

  }

  class TestSomeStuff
  {

    static void Main()
    {
      // Give a demo of what is possible

      CorrectPositiveNumber aFirstNumber = new CorrectPositiveNumber();
      CorrectPositiveNumber aSecondNumber = new CorrectPositiveNumber();

      Console.WriteLine(aFirstNumber.Number + aSecondNumber.Number);

      Console.ReadLine();
    }

  }

}