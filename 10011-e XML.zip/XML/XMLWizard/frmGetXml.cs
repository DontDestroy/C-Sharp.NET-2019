//***
// Action
//   - Get the Schema, XML Data and XML Nested data
// Created
//   - CopyPaste � 20251129 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251129 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmGetXml: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private IContainer components;
    internal System.Windows.Forms.TextBox txtResult;
    internal System.Windows.Forms.Button cmdDataNested;
    internal System.Windows.Forms.Button cmdData;
    private BindingSource bdsrcCategory;
    private XMLWizard.dsData dsData;
    private XMLWizard.dsDataTableAdapters.tbaCategory tbaCategory;
    private XMLWizard.dsDataTableAdapters.tbaProduct tbaProduct;
    internal System.Windows.Forms.Button cmdSchema;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGetXml));
      this.txtResult = new System.Windows.Forms.TextBox();
      this.cmdDataNested = new System.Windows.Forms.Button();
      this.cmdData = new System.Windows.Forms.Button();
      this.cmdSchema = new System.Windows.Forms.Button();
      this.bdsrcCategory = new System.Windows.Forms.BindingSource(this.components);
      this.dsData = new XMLWizard.dsData();
      this.tbaCategory = new XMLWizard.dsDataTableAdapters.tbaCategory();
      this.tbaProduct = new XMLWizard.dsDataTableAdapters.tbaProduct();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCategory)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.SuspendLayout();
      // 
      // txtResult
      // 
      this.txtResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.txtResult.Location = new System.Drawing.Point(8, 38);
      this.txtResult.Multiline = true;
      this.txtResult.Name = "txtResult";
      this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtResult.Size = new System.Drawing.Size(392, 360);
      this.txtResult.TabIndex = 7;
      this.txtResult.WordWrap = false;
      // 
      // cmdDataNested
      // 
      this.cmdDataNested.Location = new System.Drawing.Point(200, 6);
      this.cmdDataNested.Name = "cmdDataNested";
      this.cmdDataNested.Size = new System.Drawing.Size(128, 23);
      this.cmdDataNested.TabIndex = 6;
      this.cmdDataNested.Text = "Show Data Nested";
      this.cmdDataNested.Click += new System.EventHandler(this.cmdDataNested_Click);
      // 
      // cmdData
      // 
      this.cmdData.Location = new System.Drawing.Point(104, 6);
      this.cmdData.Name = "cmdData";
      this.cmdData.Size = new System.Drawing.Size(88, 23);
      this.cmdData.TabIndex = 5;
      this.cmdData.Text = "Show Data";
      this.cmdData.Click += new System.EventHandler(this.cmdData_Click);
      // 
      // cmdSchema
      // 
      this.cmdSchema.Location = new System.Drawing.Point(8, 6);
      this.cmdSchema.Name = "cmdSchema";
      this.cmdSchema.Size = new System.Drawing.Size(88, 23);
      this.cmdSchema.TabIndex = 4;
      this.cmdSchema.Text = "Show Schema";
      this.cmdSchema.Click += new System.EventHandler(this.cmdSchema_Click);
      // 
      // bdsrcCategory
      // 
      this.bdsrcCategory.DataSource = this.dsData;
      this.bdsrcCategory.Position = 0;
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // tbaCategory
      // 
      this.tbaCategory.ClearBeforeFill = true;
      // 
      // tbaProduct
      // 
      this.tbaProduct.ClearBeforeFill = true;
      // 
      // frmGetXml
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(408, 405);
      this.Controls.Add(this.cmdSchema);
      this.Controls.Add(this.txtResult);
      this.Controls.Add(this.cmdDataNested);
      this.Controls.Add(this.cmdData);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmGetXml";
      this.Text = "GetXml";
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCategory)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmGetXml'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251129 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251129 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmGetXml()
      //***
      // Action
      //   - Create instance of 'frmGetXml'
      //   - Fill data set with Product and category information
      // Called by
      //   - 
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251129 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251129 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      tbaProduct.Fill(dsData.tblCPProduct);
      tbaCategory.Fill(dsData.tblCPCategory);
    }
    // frmGetXml()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdData_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the nested relation to false
      //   - Get data as XML
      //   - Put XML into textbox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251129 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251129 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strXML;

      dsData.Relations["ProductCategory"].Nested = false;
      strXML = dsData.GetXml();
      txtResult.Text = strXML;
    }
    // cmdData_Click(System.Object, System.EventArgs) Handling cmdData.Click

    private void cmdDataNested_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the nested relation to true
      //   - Get data as XML
      //   - Put XML into textbox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251129 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251129 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strXML;

      dsData.Relations["ProductCategory"].Nested = true;
      strXML = dsData.GetXml();
      txtResult.Text = strXML;
    }
    // cmdDataNested_Click(System.Object, System.EventArgs) Handles cmdDataNested.Click

    private void cmdSchema_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Get schema of data as XML
      //   - Put XML into textbox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251129 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251129 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strXML;

      strXML = dsData.GetXmlSchema();
      txtResult.Text = strXML;
    }
    // cmdSchema_Click(System.Object, System.EventArgs) Handles cmdSchema.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmGetXml

}
// CopyPaste.Learning