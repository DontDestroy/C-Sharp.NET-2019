﻿//***
// Action
//   - Explain the basic principles of Performance
//     - Algoritmic efficiency 
//     - Memory behaviour
//       - MemoryAllocation
//     - Runtime execution
//   - Measured by throughput, latency and resource utilization
// Created
//   - CopyPaste – 20260525 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260525 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Allocate some memory
    //   - Wait for a user key
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - MemoryAllocation()
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      MemoryAllocation();

      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadKey();
    }
    // Main()

    static void MemoryAllocation()
    //***
    // Action
    //   - Allocate a span in stack
    //     - Fill from 0 till length - 1
    //   - Create an array
    //   - Allocate a span in the heap based on the array
    //     - Fill from 0 till length - 1
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Span<int> aSpanStack = stackalloc int[1000];
      int intLength = aSpanStack.Length;

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {
        aSpanStack[intCounter] = intCounter;
      }
      // intCounter = intLength;

      int[] arrNumbers = new int[intLength];

      Span<int> aSpanHeap = new Span<int>(arrNumbers);

      for (int intCounter = 0; intCounter < intLength; intCounter++)
      {
        aSpanHeap[intCounter] = intCounter;
      }
      // intCounter = intLength;

    }
    // MemoryAllocation()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning