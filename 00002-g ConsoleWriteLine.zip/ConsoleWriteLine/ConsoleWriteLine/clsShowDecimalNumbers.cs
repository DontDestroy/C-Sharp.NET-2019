//***
// Action
//   - 
// Created
//   - CopyPaste � 20211018 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20211018 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace ConsoleWriteLine
{

  class cpShowDecimalNumbers
	{

    static void Main()
    //***
    // Action
    //   - Initialize a double variable
    //   - Write some info to the console screen
    //   - Wait for user interaction
    //   - Explanation of the contents of WriteLine statements can be found in "Format function, predefined numeric values"
    // Called by
    //   - 
    // Calls
    //   - System.Console.ReadLine()
    //   - System.Console.WriteLine()
    //   - System.Console.WriteLine(Double)
    //   - System.Console.WriteLine(String)
    //   - System.Console.WriteLine(String, System.Object)
    //   - System.Console.WriteLine(String, System.Object, System.Object, System.Object)
    // Created
    //   - CopyPaste � 20211018 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20211018 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      double dblNumber = 1.23456789;

      Console.WriteLine(dblNumber);
      Console.WriteLine("----------");
      Console.WriteLine();
      Console.WriteLine("{0} {1} {2}", 1, 2, 3);
      Console.WriteLine("{0, 1:D} {1, 3:D} {2, 5:D}", 1, 2, 3);
      Console.WriteLine("{0, 7:F1} {1, 7:F3} {2, 7:F5}", dblNumber, dblNumber, dblNumber);
      Console.WriteLine("{0, 0:#.#}", dblNumber);
      Console.WriteLine("{0, 0:#.###}", dblNumber);
      Console.WriteLine("{0, 0:#.#####}", dblNumber);
      Console.ReadLine();
    }
    // Main()

  }
  // cpShowDecimalNumbers

}
// ConsoleWriteLine