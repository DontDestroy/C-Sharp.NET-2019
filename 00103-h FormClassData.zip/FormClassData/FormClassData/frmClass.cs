//***
// Action
//   - Show the connection between a class and a Windows form
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   - As exercise, rework this example with properties
//   - The checks of the properties lengths changes towards the class in stead of in the application
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmClass : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdSubmit;
    internal System.Windows.Forms.TextBox txtEmail;
    internal System.Windows.Forms.TextBox txtPhone;
    internal System.Windows.Forms.TextBox txtName;
    internal System.Windows.Forms.Label lblEmail;
    internal System.Windows.Forms.Label lblPhone;
    internal System.Windows.Forms.Label lblName;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmClass));
      this.cmdSubmit = new System.Windows.Forms.Button();
      this.txtEmail = new System.Windows.Forms.TextBox();
      this.txtPhone = new System.Windows.Forms.TextBox();
      this.txtName = new System.Windows.Forms.TextBox();
      this.lblEmail = new System.Windows.Forms.Label();
      this.lblPhone = new System.Windows.Forms.Label();
      this.lblName = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdSubmit
      // 
      this.cmdSubmit.Location = new System.Drawing.Point(98, 168);
      this.cmdSubmit.Name = "cmdSubmit";
      this.cmdSubmit.TabIndex = 13;
      this.cmdSubmit.Text = "Submit";
      this.cmdSubmit.Click += new System.EventHandler(this.cmdSubmit_Click);
      // 
      // txtEmail
      // 
      this.txtEmail.Location = new System.Drawing.Point(90, 112);
      this.txtEmail.Name = "txtEmail";
      this.txtEmail.Size = new System.Drawing.Size(160, 20);
      this.txtEmail.TabIndex = 12;
      this.txtEmail.Text = "";
      // 
      // txtPhone
      // 
      this.txtPhone.Location = new System.Drawing.Point(90, 72);
      this.txtPhone.Name = "txtPhone";
      this.txtPhone.Size = new System.Drawing.Size(160, 20);
      this.txtPhone.TabIndex = 10;
      this.txtPhone.Text = "";
      // 
      // txtName
      // 
      this.txtName.Location = new System.Drawing.Point(90, 32);
      this.txtName.Name = "txtName";
      this.txtName.Size = new System.Drawing.Size(160, 20);
      this.txtName.TabIndex = 8;
      this.txtName.Text = "";
      // 
      // lblEmail
      // 
      this.lblEmail.Location = new System.Drawing.Point(22, 112);
      this.lblEmail.Name = "lblEmail";
      this.lblEmail.TabIndex = 11;
      this.lblEmail.Text = "E-Mail";
      // 
      // lblPhone
      // 
      this.lblPhone.Location = new System.Drawing.Point(22, 72);
      this.lblPhone.Name = "lblPhone";
      this.lblPhone.TabIndex = 9;
      this.lblPhone.Text = "Phone";
      // 
      // lblName
      // 
      this.lblName.Location = new System.Drawing.Point(22, 32);
      this.lblName.Name = "lblName";
      this.lblName.TabIndex = 7;
      this.lblName.Text = "Name";
      // 
      // frmClass
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(272, 213);
      this.Controls.Add(this.cmdSubmit);
      this.Controls.Add(this.txtEmail);
      this.Controls.Add(this.txtPhone);
      this.Controls.Add(this.txtName);
      this.Controls.Add(this.lblEmail);
      this.Controls.Add(this.lblPhone);
      this.Controls.Add(this.lblName);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmClass";
      this.Text = "Class Data";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmClass'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmClass()
      //***
      // Action
      //   - Create instance of 'frmClass'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    #region "Designer"

    public class cpEmployee
    {

      #region "Constructors / Destructors"

      public cpEmployee(string strName, string strPhone, string strEmail)
        //***
        // Action
        //   - Constructor of a cpEmployee
        //   - Parameters are a name, a phonenumber and an emailaddress
        // Called by
        //   - frmClass.cmdSubmit_Click(System.Object, System.EventArgs) Handles cmdSubmit.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230804 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230804 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrName = strName;
        mstrPhone = strPhone;
        mstrEmail = strEmail;
      }
      // cpEmployee(string, string, string)
      
      #endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      #region "Fields"
      
      public string mstrEmail;
      public string mstrName;
      public string mstrPhone;

      #endregion

      //#region "Properties"
      //#endregion

      //#region "Methods"

      #region "Overrides"

      public override string ToString()
        //***
        // Action
        //   - Builds the information of a cpWorker
        // Called by
        //   - frmClass.cmdSubmit_Click(System.Object, System.EventArgs) Handles cmdSubmit.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230804 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230804 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return "Employee: " + mstrName + " - Phone: " + mstrPhone + " - Email: " + mstrEmail;
      }
      // string ToString()

      #endregion

      //#region "Controls"
      //#endregion

      //#region "Functionality"

      //#region "Event"
      //#endregion

      //#region "Sub / Function"

      //***
      // Action
      //   - Explanation of the code in this module or class
      // Called by
      //   - List of code that uses this procedure
      // Calls
      //   - List of procedures that are called by this piece of code
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***

      //#endregion

      //#endregion

      //#endregion

      //#region "Not used"
      //#endregion

    }
    // 

    #endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdSubmit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Constructor of a cpEmployee
      //   - Parameters are a name, a phonenumber and an emailaddress
      //   - Check if the length of the name is ok
      //   - If not, show an error message
      //   - Check if the length of the name is ok
      //   - If not, show an error message
      //   - Check if the length of the name is ok
      //   - If not, show an error message
      //   - If all is ok
      //     - Create an instance of the worker and show the information
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpWorker(string, string, string)
      //   - string cpWorker.ToString()
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - As exercise, remove the checks from inside this routine
      //   - Place them in the properties (set) of your class cpEmployee
      //***
    {

      if (txtName.Text.Length == 0)
      {
        MessageBox.Show("Must specify employee name");
      }
      else if (txtPhone.Text.Length == 0)
      {
        MessageBox.Show("Must specify employee phone number");
      }
      else if (txtEmail.Text.Length == 0)
      {
        MessageBox.Show("Must specify employee e-mail address");
      }
      else
        // txtName.Text.Length <> 0
        // txtPhone.Text.Length <> 0
        // txtEmail.Text.Length <> 0
      {
        cpEmployee theWorker = new cpEmployee(txtName.Text, txtPhone.Text, txtEmail.Text);
        MessageBox.Show(theWorker.ToString());
      }
      // txtName.Text.Length = 0
      // txtPhone.Text.Length = 0
      // txtEmail.Text.Length = 0
    
    }
    // cmdSubmit_Click(System.Object, System.EventArgs) Handles cmdSubmit.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmClass
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmClass());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmClass

}
// CopyPaste.Learning