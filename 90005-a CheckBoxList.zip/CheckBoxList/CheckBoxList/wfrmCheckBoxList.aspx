﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCheckBoxList.aspx.cs" Inherits="CopyPaste.Learning.wfrmCheckBoxList" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>CheckBox List</title>
</head>
<body>
    <form id="wfrmCheckBoxList" method="post" runat="server">
      <asp:Label id="lblTitle" style="Z-INDEX: 101; POSITION: absolute; TOP: 16px; LEFT: 24px" runat="server">Which languages do you speak?</asp:Label>
      <asp:Label id="lblResult" style="Z-INDEX: 104; POSITION: absolute; TOP: 256px; LEFT: 88px"
        runat="server" Width="368px"></asp:Label>
      <asp:Button id="cmdSelect" style="Z-INDEX: 103; POSITION: absolute; TOP: 208px; LEFT: 64px"
        runat="server" Text="Select and click" Width="120px"></asp:Button>
      <asp:CheckBoxList id="chkLanguages" style="Z-INDEX: 102; POSITION: absolute; TOP: 48px; LEFT: 56px"
        runat="server" BorderStyle="Solid" BorderWidth="1px" Width="120px">
        <asp:ListItem Value="Dutch">Dutch</asp:ListItem>
        <asp:ListItem Value="French">French</asp:ListItem>
        <asp:ListItem Value="English">English</asp:ListItem>
        <asp:ListItem Value="German">German</asp:ListItem>
        <asp:ListItem Value="Spanish">Spanish</asp:ListItem>
        <asp:ListItem Value="Italian">Italian</asp:ListItem>
      </asp:CheckBoxList>
    </form>
</body>
</html>
