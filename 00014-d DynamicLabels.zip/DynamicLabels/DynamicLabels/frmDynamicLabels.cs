//***
// Action
//   - Demo the power of labels
// Created
//   - CopyPaste � 20240207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240207 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDynamicLabels: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblSecond;
    internal System.Windows.Forms.Label lblFirst;
    internal System.Windows.Forms.Button cmdClear;
    internal System.Windows.Forms.Button cmdTime;
    internal System.Windows.Forms.Button cmdDate;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDynamicLabels));
      this.lblSecond = new System.Windows.Forms.Label();
      this.lblFirst = new System.Windows.Forms.Label();
      this.cmdClear = new System.Windows.Forms.Button();
      this.cmdTime = new System.Windows.Forms.Button();
      this.cmdDate = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // lblSecond
      // 
      this.lblSecond.Location = new System.Drawing.Point(33, 101);
      this.lblSecond.Name = "lblSecond";
      this.lblSecond.Size = new System.Drawing.Size(150, 20);
      this.lblSecond.TabIndex = 6;
      this.lblSecond.Visible = false;
      // 
      // lblFirst
      // 
      this.lblFirst.Location = new System.Drawing.Point(33, 51);
      this.lblFirst.Name = "lblFirst";
      this.lblFirst.Size = new System.Drawing.Size(150, 20);
      this.lblFirst.TabIndex = 5;
      this.lblFirst.Visible = false;
      // 
      // cmdClear
      // 
      this.cmdClear.Location = new System.Drawing.Point(211, 195);
      this.cmdClear.Name = "cmdClear";
      this.cmdClear.TabIndex = 9;
      this.cmdClear.Text = "Clear";
      this.cmdClear.Click += new System.EventHandler(this.cmdClear_Click);
      // 
      // cmdTime
      // 
      this.cmdTime.Location = new System.Drawing.Point(115, 195);
      this.cmdTime.Name = "cmdTime";
      this.cmdTime.TabIndex = 8;
      this.cmdTime.Text = "Time";
      this.cmdTime.Click += new System.EventHandler(this.cmdTime_Click);
      // 
      // cmdDate
      // 
      this.cmdDate.Location = new System.Drawing.Point(19, 195);
      this.cmdDate.Name = "cmdDate";
      this.cmdDate.TabIndex = 7;
      this.cmdDate.Text = "Date";
      this.cmdDate.Click += new System.EventHandler(this.cmdDate_Click);
      // 
      // frmDynamicLabels
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(304, 269);
      this.Controls.Add(this.lblSecond);
      this.Controls.Add(this.lblFirst);
      this.Controls.Add(this.cmdClear);
      this.Controls.Add(this.cmdTime);
      this.Controls.Add(this.cmdDate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDynamicLabels";
      this.Text = "Dynamic Labels";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDynamicLabels'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDynamicLabels()
      //***
      // Action
      //   - Create instance of 'frmDynamicLabels'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDynamicLabels()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdClear_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Don't show the date and the time anymore
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblFirst.Visible = false;
      lblSecond.Visible = false;
    }
    // cmdClear_Click(theSender, theEventArguments) Handles cmdClear.Click
    
    private void cmdDate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Put the current date as text and show the label
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblFirst.Text = "Date: " + DateTime.Now.Date;
      lblFirst.Visible = true;
    }
    // cmdDate_Click(theSender, theEventArguments) Handles cmdDate.Click

    private void cmdTime_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Put the current time as text and show the label
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblSecond.Text = "Time: " + DateTime.Now.TimeOfDay;
      lblSecond.Visible = true;
    }
    // cmdTime.Click(theSender, theEventArguments) Handles cmdTime.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDynamicLabels
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDynamicLabels());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDynamicLabels

}
// CopyPaste.Learning