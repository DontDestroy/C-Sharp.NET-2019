//***
// Action
//   - The execution of operators has a specific order
// Created
//   - CopyPaste � 20240412 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240412 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Playing around with the operators (Math.Pow), +, -, * 
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240412 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240412 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      double dblExpression1;
      double dblExpression2;
      double dblExpression3;
      double dblExpression4;

      dblExpression1 = Math.Pow(5, 2) + 1 * 3 - 4;
      dblExpression2 = Math.Pow(5, (2 + 1)) * 3 - 4;
      dblExpression3 = Math.Pow(5, (2 + 1)) * (3 - 4);
      dblExpression4 = Math.Pow(5, (2 + 1) * (3 - 4));

      Console.WriteLine("5 ^ 2 + 1 * 3 - 4 = " + dblExpression1.ToString());
      Console.WriteLine("5 ^ (2 + 1) * 3 - 4 = " + dblExpression2.ToString());
      Console.WriteLine("5 ^ (2 + 1) * (3 - 4) = " + dblExpression3.ToString());
      Console.WriteLine("5 ^ ((2 + 1) * (3 - 4)) = " + dblExpression4.ToString());

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning