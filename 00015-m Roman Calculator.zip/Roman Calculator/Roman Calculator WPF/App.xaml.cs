﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Roman_Calculator_WPF
{

  public partial class App : Application
  {
  }
  // App

}
// Roman_Calculator_WPF