//***
// Action
//   - Implementation of a cpXYPoint that is serializable
//   - By default 3 points defines a triangle (or a line)
// Created
//   - CopyPaste � 20240408 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240408 � VVDW
// Proposal (To Do)
//   - There is no check if the 3 point are on a line
//   - There is no check if one of the 3 points are equal to another
//***

using System;

namespace CopyPaste.Learning
{

  // The Serializable attritube marks the class to be serializable
  [SerializableAttribute()]
  public class cpTriangle
  {

    #region "Constructors / Destructors"

    public cpTriangle()
      //***
      // Action
      //   - Default constructor 
      // Called by
      //   - frmSerialize.cmdLoadXML_Click(System.Object, System.EventArgs) Handles cmdLoadXML.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpTriangle()

    public cpTriangle(cpXYPoint theAPoint, cpXYPoint theBPoint, cpXYPoint theCPoint)
      //***
      // Action
      //   - Constructor of a triangle with 3 points
      // Called by
      //   - frmSerialize.cmdAddTriangle_Click(System.Object, System.EventArgs) Handles cmdAddTriangle.Click
      // Calls
      //   - Points(cpXYPoint()) (Set)
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Points = new cpXYPoint[] {theAPoint, theBPoint, theCPoint};
    }
    // cpTriangle(cpXYPoint, cpXYPoint, cpXYPoint)
  
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpXYPoint[] marrcpPoints = {new cpXYPoint(), new cpXYPoint(), new cpXYPoint()};
      // cpXYPoint.New()

    #endregion

    #region "Properties"

    public cpXYPoint[] Points
    {

      get
        //***
        // Action Get
        //   - Returns the array of 3 points of a triable
        // Called by
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240408 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240408 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return marrcpPoints;
      }
      // cpXPPoint[] Points (Get)

      set
        //***
        // Action Set
        //   - Array of 3 points of a triagle is given by arrcpValue
        //   - If the length of the array is exactly 3
        //     - marrcpPoints becomes value 
        //   - If not
        //     - Nothing happens
        // Called by
        //   - cpTraingle(cpXYPoint, cpXYPoint, cpXYPoint)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240408 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240408 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value.Length == 3)
        {
          marrcpPoints = value;
        }
        else
          // value.Length <> 3
        {
        }
        // value.Length = 3

      }
      // Points(cpXPPoint[]) (Set)

    }
    // cpXPPoint[] Points

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Visualisation of a cpTriagle
      //   - Given by the coordinates of the 3 points
      // Called by
      //   - string cpTriangleCollection.ToString()
      // Calls
      //   - cpXYPoint[] Points (Get)
      //   - string cpXYPoint.ToString()
      // Created
      //   - CopyPaste � 20240408 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240408 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngPoint;
      string strTriangle = "";

      for (lngPoint = 0; lngPoint < Points.Length; lngPoint++)
      {
        strTriangle += Points[lngPoint].ToString() + " ";
      }
      // lngPoint = Points.Length

      return strTriangle;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpTriangle

}
// CopyPaste.Learning