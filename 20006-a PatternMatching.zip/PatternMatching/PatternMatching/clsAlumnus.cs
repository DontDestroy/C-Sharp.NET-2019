﻿//***
// Action
//   - Definition of a Alumnus class
// Created
//   - CopyPaste – 20221211 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20221211 – VVDW
// Proposal (To Do)
//   -
//***

using static CopyPaste.Learning.cpProgram;

namespace CopyPaste.Learning
{

  public class cpAlumnus: cpPerson
  {

    #region "Constructors / Destructors"

    public cpAlumnus() : base()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - cpPerson()
    // Created
    //   - CopyPaste – 20221211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20221211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpAlumnus()
     
    public cpAlumnus((string strFirstName, string strLastName, int intAge) thePersonDetails, int intCompletedStudiesYear, cpUniversityDegree theObtainedDegree) : this()
    //***
    // Action
    //   - Constructor with 3 parameters
    //     - thePersonDetails: A tuple with the personal details firstname, lastname and age
    //     - intCompletedStudiesYear: The year the studies were completed
    //     - theObtainedDegree: The degree obtained
    // Called by
    //   - cpProgram.cpMain()
    // Calls
    //   - cpStudent()
    //   - FirstName(string) (Set)
    //   - LastName(string) (Set)
    //   - Age(int) (Set)
    // Created
    //   - CopyPaste – 20221211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20221211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Age = thePersonDetails.intAge;
      CompletedYear = intCompletedStudiesYear;
      FirstName = thePersonDetails.strFirstName;
      LastName = thePersonDetails.strLastName;
      ObtainedDegree = theObtainedDegree;
    }
    // cpAlumnus((string, string, int), int, cpUniversityDegree)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public cpUniversityDegree ObtainedDegree { get; }
    public int CompletedYear { get; }

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public (string strFullName, int intCompletedYear, string strObtainedDegree) AlumnusDetails()
    //***
    // Action
    //   - Return information about the alumnus
    //     - A tuple of 2 strings and an integer is used
    // Called by
    //   - cpPatternMatching.GetPersonCourseBeforeCSharp07()
    //   - cpPatternMatching.GetPersonCourseIsTypePattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchPattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchPatternNull(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchWhenPattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchWhenPatternExclusion(System.Object)
    // Calls
    //   - cpUniversityDegree ObtainedDegree (Get)
    //   - int CompletedYear (Get)
    //   - string FirstName (Get)
    //   - string LastName (Get)
    // Created
    //   - CopyPaste – 20221211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20221211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      (string, int, string) alumnusDetails = ($"{FirstName} {LastName}", CompletedYear, ObtainedDegree.ToString());

      return alumnusDetails;
    }
    // (string, int, string) AlumnusDetails()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpAlumnus

}
// CopyPaste.Learning