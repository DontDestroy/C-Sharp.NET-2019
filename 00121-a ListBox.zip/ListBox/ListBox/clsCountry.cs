//***
// Action
//   - Implementation of cpCountry
// Created
//   - CopyPaste � 20240624 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240624 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;
using System.Drawing;

namespace CopyPaste.Learning
{

  public class cpCountry
  {

    #region "Constructors / Destructors"

    public cpCountry(string strName, string strCapital, Image picFlag, int lngSize)
      //***
      // Action
      //   - Constructor with a given name, capital, flag and size
      // Called by
      //   - frmListBox()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240624 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240624 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrName = strName;
      mstrCapital = strCapital;
      mpicFlag = picFlag;
      mlngSize = lngSize;
    }
    // cpCountry(string, string, Image, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    private Image mpicFlag;
    private int mlngSize;
    private string mstrCapital;
    private string mstrName;

    #endregion

    #region "Properties"

    public string Capital
    {

      get
        //***
        // Action Get
        //   - Returns mstrCapital
        // Called by
        //   - frmListBox.ListBox_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstCountry.SelectedIndexChanged, lstCapital.SelectedIndexChanged
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240624 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240624 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrCapital;
      }
      // string Capital (Get)

    }
    // string Capital

    public Image Flag
    {

      get
        //***
        // Action Get
        //   - Returns mpicFlag
        // Called by
        //   - frmListBox.ListBox_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstCountry.SelectedIndexChanged, lstCapital.SelectedIndexChanged
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240624 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240624 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mpicFlag;
      }
      // Image Flag (Get)

    }
    // Image Flag

    public string Name
    {

      get
        //***
        // Action Get
        //   - Returns mstrName
        // Called by
        //   - frmListBox.ListBox_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstCountry.SelectedIndexChanged, lstCapital.SelectedIndexChanged
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240624 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240624 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

    }
    // string Name

    public int Size
    {

      get
        //***
        // Action Get
        //   - Returns mlngSize
        // Called by
        //   - frmListBox.ListBox_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstCountry.SelectedIndexChanged, lstCapital.SelectedIndexChanged
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240624 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240624 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngSize;
      }
      // int Size (Get)

    }
    // int Size

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Returns the name of the country
      // Called by
      //   - 
      // Calls
      //   - Name() As String (Get)
      // Created
      //   - CopyPaste � 20240624 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240624 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Name;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCountry

}
// CopyPaste.Learning