//***
// Action
//   - Demo of threading
// Created
//   - CopyPaste � 20250707 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250707 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Threading;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void DisplayLotOfA()
      //***
      // Action
      //   - Display 251 times "A"
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      for (int lngCounter = 0; lngCounter <= 250; lngCounter++)
      {
        Console.Write("A");
      }
      // lngCounter = 251

    }
    // DisplayLotOfA()

    public static void DisplayLotOfB()
      //***
      // Action
      //   - Display 251 times "B"
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      for (int lngCounter = 0; lngCounter <= 250; lngCounter++)
      {
        Console.Write("B");
      }
      // lngCounter = 251

    }
    // DisplayLotOfB()

    public static void DisplayLotOfC()
      //***
      // Action
      //   - Display 251 times "C"
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      for (int lngCounter = 0; lngCounter <= 250; lngCounter++)
      {
        Console.Write("C");
      }
      // lngCounter = 251

    }
    // DisplayLotOfC()

    public static void Main()
      //***
      // Action
      //   - Display 251 times "A", "B" and "C" using threading
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - DisplayLotOfA()
      //   - DisplayLotOfB()
      //   - DisplayLotOfC()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Thread thrLotOfA = new Thread(new ThreadStart(DisplayLotOfA));
      Thread thrLotOfB = new Thread(new ThreadStart(DisplayLotOfB));
      Thread thrLotOfC = new Thread(new ThreadStart(DisplayLotOfC));

      thrLotOfA.Start();
      thrLotOfB.Start();
      thrLotOfC.Start();

      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning