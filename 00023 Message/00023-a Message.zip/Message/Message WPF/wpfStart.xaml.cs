﻿//***
// Action
//   - Showing a messagebox. Starting point is an empty form.
// Created
//   - CopyPaste – 20220922 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20220922 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Message_WPF
{

  public partial class wpfStart : Window
  {

    #region "Constructors / Destructors"

    public wpfStart()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220922 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220922 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfStart()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void Window_Loaded(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Show a MessageBox message
    //   - Show a MessageBox message with button OK
    //   - Show a MessageBox message with title and 3 buttons
    //   - Show a MessageBox message with title and 2 buttons
    //   - Show a MessageBox message with title and 2 buttons with icon and remember the answer
    //   - Depending on the answer, show a MessageBox message
    // Called by
    //   - User action (starting the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220922 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20220922 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      MessageBoxResult dlgrResponse;

      MessageBox.Show("C# .NET Programming For The Absolute Beginner");
      MessageBox.Show("Hi There!", "Copy Paste", MessageBoxButton.OK);
      MessageBox.Show("Nuclear Meltdown In Progress!", "Copy Paste", MessageBoxButton.OKCancel);
      MessageBox.Show("Do you want to format your hard drive?", "Copy Paste", MessageBoxButton.YesNo, MessageBoxImage.Question);
      MessageBox.Show("Error connecting to server...", "Copy Paste", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation);
      dlgrResponse = MessageBox.Show("How about a game of Global Thermonuclear War?", "Copy Paste", MessageBoxButton.YesNo, MessageBoxImage.Question);

      if (dlgrResponse == MessageBoxResult.Yes)
      {
        MessageBox.Show("On second thought, that's not such a good idea.", "Result");
      }
      else
      // dlgrResponse <> MessageBoxResult.Yes
      {
        MessageBox.Show("Chicken!", "Result");
      }
      // dlgrResponse = MessageBoxResult.Yes

    }
    // Window_Loaded(System.Object, System.Windows.RoutedEventArgs) Handles Window.Loaded

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfStart

}
// Message_WPF