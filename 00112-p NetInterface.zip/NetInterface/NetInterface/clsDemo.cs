//***
// Action
//   - Demo of an IFormattable and IComparable implementation
// Created
//   - CopyPaste � 20240529 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240529 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpDemo : IComparable, IFormattable
  {

    #region "Constructors / Destructors"

    public cpDemo(string strValue)
      //***
      // Action
      //   - Constructor of cpDemo
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrValue = strValue;
    }
    // cpDemo(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public string mstrValue;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public virtual int CompareTo(System.Object theObject)
      //***
      // Action
      //   - Implementation of CompareTo (from IComparable)
      //   - Depending on the value of the object theObject (take the length)
      //     - When equal to mstrValue (length)
      //       - Zero is returned
      //     - When smaller than mstrValue (length)
      //       - One is returned
      //     - When bigger than  mstrValue (length)
      //       - Minus one is returned
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngValue;
      int lngCompareValue;

      lngCompareValue = ((cpDemo)theObject).mstrValue.Length;

      if (lngCompareValue == mstrValue.Length)
      {
        lngValue = 0;
      }
      else if (lngCompareValue < mstrValue.Length)
        // (lngCompareValue <> mstrValue.Length)
      {
        lngValue = 1;
      }
      else
        // strCompareValue.Length > mstrValue.Length
      {
        lngValue = -1;
      }
      // lngCompareValue = mstrValue.Length
      // lngCompareValue < mstrValue.Length

      return lngValue;
    }
    // int CompareTo(System.Object)

    public string ToString(string strFormat, IFormatProvider theFormatProvider)
      //***
      // Action
      //   - Return mstrValue
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
  {
      return mstrValue;
    }
    // string ToString(string, IFormatProvider)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpDemo

}
// CopyPaste.Learning