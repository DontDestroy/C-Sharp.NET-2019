//***
// Action
//   - Implementation of cpPerson
// Created
//   - CopyPaste � 20240610 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240610 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpPerson
  {

    #region "Constructors / Destructors"

    public cpPerson(string strName, string strPhoneNumber)
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - frmPhoneBook.cmdAdd_Click(System.Object, System.EventArgs) Handles cmdAdd.Click
      //   - frmPhoneBook.cmdOpen_Click(System.Object, System.EventArgs) Handles cmdOpen.Click
      // Calls
      //   - Name(String) (Set)
      //   - PhoneNumber(String) (Set)
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Name = strName;
      PhoneNumber = strPhoneNumber;
    }
    // cpPerson(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    private string mstrName;
    private string mstrPhoneNumber;

    #endregion

    #region "Properties"

    public string Name
    {

      get
        //***
        // Action Get
        //   - Returns mstrName
        // Called by
        //   - frmPhoneBook.cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240610 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240610 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

      set
        //***
        // Action Set
        //   - mstrName becomes value
        // Called by
        //   - cpPerson(string, string)
        // Call
        //   - 
        // Created
        //   - CopyPaste � 20240610 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240610 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    public string PhoneNumber
    {

      get
        //***
        // Action Get
        //   - Returns mstrPhoneNumber
        // Called by
        //   - frmPhoneBook.cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240610 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240610 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrPhoneNumber;
      }
      // string PhoneNumber (Get)

      set
        //***
        // Action Set
        //   - mstrPhoneNumber becomes value
        // Called by
        //   - cpPerson(string, string)
        // Call
        //   - 
        // Created
        //   - CopyPaste � 20240610 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240610 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrPhoneNumber = value;
      }
      // PhoneNumber(string) (Set)

    }
    // string PhoneNumber

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action Set
      //   - Returns the name
      // Called by
      //   - 
      // Call
      //   - string Name (Get)
      // Created
      //   - CopyPaste � 20240610 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240610 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Name;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPerson

}
// CopyPaste.Learning