﻿//***
// Action
//   - Definition of an AircraftTypeDetail
// Created
//   - CopyPaste – 20230714 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230714 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CopyPaste.BusinessObjects
{

  public class AircraftTypeDetail
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    // A relation towards entity class AircraftType (the one part)
    public virtual AircraftType AircraftType { get; set; }

    // Towards AircraftType it is a 1:1 relationship using the same Primary Key
    [KeyAttribute]
    public virtual byte AircraftTypeId { get; set; }

    public float? Length { get; set; }
    public string Memo { get; set; }
    public short? Tare { get; set; }
    public byte? TurbineCount{ get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // AircraftTypeDetail

}
// CopyPaste.BusinessObjects 