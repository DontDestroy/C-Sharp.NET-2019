//***
// Action
//   - Implementation of cpMorning
// Created
//   - CopyPaste � 20240524 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240524 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpMorning
  {

    #region "Constructors / Destructors"

    public cpMorning()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - cpProgram.Main()
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpMorning()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public event cpStartCoffee StartCoffee;
    public event cpStartShower StartShower;
    public event cpTurnOnTV TurnOnTV;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate void cpStartCoffee(string strItem, DateTime dtmStart);
    // GenerateEvents()
    public delegate void cpStartShower(string strItem, DateTime dtmStart);
    // GenerateEvents()
    public delegate void cpTurnOnTV(string strItem, DateTime dtmStart);
    // GenerateEvents()

    #endregion

    #region "Sub / Function"

    public void GenerateEvents()
      //***
      // Action
      //   - Start 3 events (when not null)
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - StartCoffee(string, DateTime)
      //   - StartShower(string, DateTime)
      //   - TurnOnTV(string, DateTime)
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      DateTime dtmDate;

      dtmDate = DateTime.Now;

      if (StartCoffee == null)
      {
      }
      else
        // StartCoffee <> null
      {
        StartCoffee("Coffee", dtmDate);
      }
      // StartCoffee = null

      if (StartShower == null)
      {
      }
      else
        // StartShower <> null
      {
        StartShower("Shower", dtmDate.AddMinutes(5.0));
      }
      // StartCoffee = null

      if (TurnOnTV == null)
      {
      }
      else
        // TurnOnTV <> null
      {
        TurnOnTV ("TV", dtmDate.AddMinutes(12.5));
      }
      // TurnOnTV = null

    }
    // GenerateEvents()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpMorning

}
// CopyPaste.Learning