//***
// Action
//   - Show Pi into control on form
// Created
//   - CopyPaste � 20220111 � VVDW
// Changed
//   - - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220111 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Windows.Forms;

namespace ConstantTester
{

  public class frmConstantTest: System.Windows.Forms.Form
  {
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.Button cmdShow;

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmConstantTest));
      this.cmdExit = new System.Windows.Forms.Button();
      this.lblResult = new System.Windows.Forms.Label();
      this.cmdShow = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdExit
      // 
      this.cmdExit.Location = new System.Drawing.Point(32, 80);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.Size = new System.Drawing.Size(88, 32);
      this.cmdExit.TabIndex = 5;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // lblResult
      // 
      this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblResult.Location = new System.Drawing.Point(152, 24);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(160, 32);
      this.lblResult.TabIndex = 4;
      // 
      // cmdShow
      // 
      this.cmdShow.Location = new System.Drawing.Point(32, 24);
      this.cmdShow.Name = "cmdShow";
      this.cmdShow.Size = new System.Drawing.Size(88, 32);
      this.cmdShow.TabIndex = 3;
      this.cmdShow.Text = "&Show constant";
      this.cmdShow.Click += new System.EventHandler(this.cmdShow_Click);
      // 
      // frmConstantTest
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(392, 133);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.cmdShow);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmConstantTest";
      this.Text = "Constant Tester";
      this.ResumeLayout(false);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmConstantTest'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmConstantTest()
    //***
    // Action
    //   - Create instance of 'frmDefault'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmConstantTest()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Exit the program
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      this.Close();
    }
    // cmdExit_Click(System.Object, System.EventArgs)

    private void cmdShow_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Assign Pi to a Double variable
    //   - Label.Text becomes the the value of the Double variable
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - System.Convert.ToString(Double)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      const double dblPi = 3.14159265;
      lblResult.Text = Convert.ToString(dblPi);
    }                                                         
    // cmdShow_Click(System.Object, System.EventArgs)

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmConstantTest
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmConstantTest());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmConstantTest

}
// ConstantTester