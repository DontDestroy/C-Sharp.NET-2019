﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmInteractivityAnswer.aspx.cs" Inherits="CopyPaste.Learning.wfrmInteractivityAnswer" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Interactivity Answer</title>
</head>
<body>
  <form id="wfrmInteractivityAnswer" method="post">
    <asp:Label ID="lblResult" Style="z-index: 102; position: absolute; top: 80px; left: 120px" runat="server"></asp:Label>
  </form>
</body>
</html>
