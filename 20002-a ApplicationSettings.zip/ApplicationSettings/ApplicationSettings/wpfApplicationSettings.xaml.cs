﻿//***
// Action
//   - A screen with Application settings
// Created
//   - CopyPaste – yyyymmdd – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – yyyymmdd – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ApplicationSettings
{

  public partial class wpfApplicationSettings : Window
  {

    #region "Constructors / Destructors"

    public wpfApplicationSettings()
    //***
    // Action
    //   - Create instance of 'wpfApplicationSettings'
    //   - Read the property ApplicationName and use it for the title of the form
    //   - Read the property BackgroundColour and use it for the backgroundcolour of the form
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - ApplicationSettings.Properties.Settings.Default.ApplicationName (Get)
    //   - ApplicationSettings.Properties.Settings.Default.BackgroundColour (Get)
    // Created
    //   - CopyPaste – 20220906 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220906 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
      this.Title = Properties.Settings.Default.ApplicationName;
      this.Background = new System.Windows.Media.SolidColorBrush(Properties.Settings.Default.BackgroundColour);
    }

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdChange_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Check what colour is selected in the listbox
    //   - Change the property BackgroundColour and use it for the backgroundcolour of the form
    //   - Save the properties (all of them)
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - ApplicationSettings.Properties.Settings.Default.BackgroundColour (Set)
    // Created
    //   - CopyPaste – 20220906 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220906 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (lstColour.SelectedItem == null)
      {
      }
      else
      // lstColour.SelectedItem <> null
      {
        string strColour = ((ListBoxItem)lstColour.SelectedItem).Content.ToString();

        switch (strColour)
        {
          case "Red":
            Properties.Settings.Default.BackgroundColour = Colors.Red;
            break;
          case "Blue":
            Properties.Settings.Default.BackgroundColour = Colors.Blue;
            break;
          case "Green":
            Properties.Settings.Default.BackgroundColour = Colors.Green;
            break;
          case "Tomato":
            Properties.Settings.Default.BackgroundColour = Colors.Tomato;
            break;
        }
        // strColour

        this.Background = new System.Windows.Media.SolidColorBrush(Properties.Settings.Default.BackgroundColour);
        Properties.Settings.Default.Save();
      }
      // lstColour.SelectedItem = null

    }
    // cmdChange_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdChange.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfApplicationSettings

}
// ApplicationSettings