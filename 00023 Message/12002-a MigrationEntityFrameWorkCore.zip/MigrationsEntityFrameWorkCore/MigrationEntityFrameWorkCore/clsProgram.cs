﻿//***
// Action
//   - Use in Visual Studio in the Package Manager Console the commands below
//     - Add-Migration StartPoint
//       - This will create a StartPoint Migration
//     - Update-database
//       - This will create the database with only the cpBook in it
//   - Add some data in the table "cpBook"
//   - Uncomment the 2 commented proporties
//   - Use in Visual Studio in the Package Manager Console the commands below
//     - Add-Migration Author
//       - This will create an Author Migration
//     - Update-database
//       - This will update the database - cpBook (1 field is added)
//       - This will update the database - cpAuthor (1 table is added)
//       - This will update the database - A relation between the 2 tables is added
// Created
//   - CopyPaste – 20230404 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230404 – VVDW
// Proposal (To Do)
//   - Application will fail when the database is not present
//***

using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace MigrationEntityFrameWorkCore
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Create a cpApplicationDatabaseContext
    //   - Read data from the database
    //   - Cleaning up the cpApplicationDatabaseContext
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - ReadTestData(cpApplicationDatabaseContext)
    // Created
    //   - CopyPaste – 20230404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230404 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      using (cpApplicationDatabaseContext theDatabaseContext = new cpApplicationDatabaseContext())
      {
        ReadTestData(theDatabaseContext);
        // Read data from the two tables thru the context
        Console.ReadLine();
      }
      // cpApplicationDatabaseContext theDatabaseContext

    }
    // Main()

    public static void ReadTestData(cpApplicationDatabaseContext theDatabaseContext)
    //***
    // Action
    //   - Reads all the books
    //   - AsNoTracking() says this is a read-only access
    //   - After the second migration
    //   -   The include causes the cpAuthor information to be loaded with each cpBook
    //   - Loop thru all the books
    // Called by
    //   - Main()
    // Calls
    //   - cpApplicationDatabaseContext.DbSet<cpBook> cpBook (Get)
    //   - cpAuthor cpBook.Author (Get)
    //   - DateTime cpBook.dtmPublishedOn (Get)
    //   - string cpAuthor.strName (Get)
    //   - string cpAuthor.strWebUrl (Get)
    //   - string cpBook.strTitle (Get)
    // Created
    //   - CopyPaste – 20230404 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230404 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strWebUrl = "";

      // After first migration (when there is some data)
      foreach (cpBook aBook in theDatabaseContext.cpBook.AsNoTracking())
      {
        Console.WriteLine($"{aBook.strTitle}");
        Console.WriteLine($"     Published on {aBook.dtmPublishedOn:dd/MM/yyyy}.");
        Console.WriteLine();
      }
      // in theDatabaseContext.cpBook.AsNoTracking())

      //// After second migration (when there is some data)
      //foreach (cpBook aBook in theDatabaseContext.cpBook.AsNoTracking().Include(theBook => theBook.Author))
      //{

      //  if (aBook.Author == null)
      //  { 
      //  }
      //  else
      //  // aBook.Author <> null
      //  {

      //    if (aBook.Author.strWebUrl == null)
      //    {
      //      strWebUrl = "- no web url given yet -";
      //    }
      //    // aBook.Author.strWebUrl <> null
      //    else
      //    {
      //      strWebUrl = aBook.Author.strWebUrl;
      //    }
      //    // aBook.Author.strWebUrl = null

      //  }
      //  // aBook.Author = null

      //  if (aBook.Author == null)
      //  {
      //    Console.WriteLine($"{aBook.strTitle} by unknown author");
      //    Console.WriteLine($"     Published on {aBook.dtmPublishedOn:dd/MM/yyyy}.");
      //  }
      //  else
      //  // aBook.Author <> null
      //  {
      //    Console.WriteLine($"{aBook.strTitle} by {aBook.Author.strName}");
      //    Console.WriteLine($"     Published on {aBook.dtmPublishedOn:dd/MM/yyyy}.");
      //    Console.WriteLine($"     More info can be found on the internet: {strWebUrl}");
      //  }
      //  // aBook.Author = null

      //  Console.WriteLine();
      //}
      //// in theDatabaseContext.cpBook.AsNoTracking().Include(theBook => theBook.Author)

    }
    // ReadTestData(cpApplicationDatabaseContext)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// MigrationEntityFrameWorkCore