//***
// Action
//   - The startup screen
//   - Create some Windows
//   - Loop thru the Windows
//     - Change something on it thru events
// Created
//   - CopyPaste � 20220817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220817 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows;

namespace WindowTrackerEvents
{

  public partial class wpfStartupScreen : Window
  {

    #region "Constructors / Destructors"

    public wpfStartupScreen()
    //***
    // Action
    //   - Create instance of 'wpfStartupScreen'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfStartupScreen()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCreate_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Initialize a new wpfWindow
    //   - Make it child of the wpfStartupScreen
    //   - Show it
    //   - Add it to the list of started Windows
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - ActionOnTheWindow(System.Object, System.Windows.RoutedEventArgs)
    //   - List<wpfWindow> App.StartedWindows (Get)
    //   - OtherActionOnTheWindow(System.Object, System.Windows.RoutedEventArgs)
    //   - RoutedEventHandler wpfWindow.ActionWithWindow
    //   - wpfWindow()
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      wpfWindow aWindow = new wpfWindow();

      aWindow.ActionWithWindow += ActionOnTheWindow;
      aWindow.ActionWithWindow += OtherActionOnTheWindow;

      aWindow.Owner = this;
      aWindow.Show();
      ((App)Application.Current).StartedWindows.Add(aWindow);
    }
    // cmdCreate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCreate.Click

    private void cmdUpdate_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Loop thru the list of started windows
    //     - Content becomes the current time
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - List<wpfWindow> App.StartedWindows (Get)
    //   - wpfWindow.SomeActionsOnTheWindow()
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      foreach (wpfWindow aWindow in ((App)Application.Current).StartedWindows)
      {
        aWindow.SomeActionsOnTheWindow();
      }
      // in ((App)Application.Current).StartedWindows

    }
    // cmdUpdate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdUpdate.Click

    #endregion

    //#region "Functionality"

    #region "Event"

    static void ActionOnTheWindow(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Content becomes the current time
    // Called by
    //   - Event (Clicking a button)
    // Calls
    //   - string wpfWindow.Content (Get)
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      wpfWindow theThingThatContainsEvent;

      theThingThatContainsEvent = (wpfWindow)theSender;
      theThingThatContainsEvent.Content = "Refreshed at " + DateTime.Now.ToLongTimeString() + ".";
    }
    // ActionOnTheWindow(System.Object, System.Windows.RoutedEventArgs)

    static void OtherActionOnTheWindow(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Title becomes another text
    // Called by
    //   - Event (Clicking a button)
    // Calls
    //   - string wpfWindow.Title (Get)
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      wpfWindow theThingThatContainsEvent;

      theThingThatContainsEvent = (wpfWindow)theSender;
      theThingThatContainsEvent.Title = "This is also changed.";
    }
    // OtherActionOnTheWindow(System.Object, System.Windows.RoutedEventArgs)

    #endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfStartupScreen

}
// WindowTrackerEvents