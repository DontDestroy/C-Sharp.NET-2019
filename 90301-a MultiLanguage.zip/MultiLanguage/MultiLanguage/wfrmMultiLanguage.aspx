﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmMultiLanguage.aspx.cs" Inherits="CopyPaste.Learning.wfrmMultiLanguage" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Default</title>
</head>
<body>
  <form id="wfrmMultilanguage" method="post" runat="server">
    <asp:Label ID="lblNumber" Style="z-index: 101; left: 40px; position: absolute; top: 32px" runat="server"></asp:Label>
    <asp:Label ID="lblName" Style="z-index: 105; left: 40px; position: absolute; top: 160px" runat="server"></asp:Label>
    <asp:Label ID="lblAddress" Style="z-index: 104; left: 40px; position: absolute; top: 128px"
      runat="server"></asp:Label>
    <asp:Label ID="lblZipcode" Style="z-index: 103; left: 40px; position: absolute; top: 96px"
      runat="server"></asp:Label>
    <asp:Label ID="lblCity" Style="z-index: 102; left: 40px; position: absolute; top: 64px" runat="server"></asp:Label>
  </form>
</body>
</html>
