//***
// Action
//   - Demo of ADO Interop thrue ADODB and ADOX
// Created
//   - CopyPaste � 20260503 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260503 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmADOInterop: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdUpdate;
    internal System.Windows.Forms.TextBox txtPosition;
    internal System.Windows.Forms.TextBox txtCategoryDescription;
    internal System.Windows.Forms.TextBox txtCategoryName;
    internal System.Windows.Forms.TextBox txtIdCategory;
    internal System.Windows.Forms.Label lblDescription;
    internal System.Windows.Forms.Label lblCategoryName;
    internal System.Windows.Forms.Label lblCategoryKey;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Button cmdLast;
    internal System.Windows.Forms.Button cmdPrevious;
    internal System.Windows.Forms.Button cmdMakeDB;
    internal System.Windows.Forms.Button cmdMakeTable;
    internal System.Windows.Forms.Button cmdOpen;
    private ADOInterop.dsData dsData;
    internal System.Windows.Forms.Button cmdFirst;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmADOInterop));
      this.cmdUpdate = new System.Windows.Forms.Button();
      this.txtPosition = new System.Windows.Forms.TextBox();
      this.txtCategoryDescription = new System.Windows.Forms.TextBox();
      this.txtCategoryName = new System.Windows.Forms.TextBox();
      this.txtIdCategory = new System.Windows.Forms.TextBox();
      this.lblDescription = new System.Windows.Forms.Label();
      this.lblCategoryName = new System.Windows.Forms.Label();
      this.lblCategoryKey = new System.Windows.Forms.Label();
      this.cmdNext = new System.Windows.Forms.Button();
      this.cmdLast = new System.Windows.Forms.Button();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.cmdMakeDB = new System.Windows.Forms.Button();
      this.cmdMakeTable = new System.Windows.Forms.Button();
      this.cmdOpen = new System.Windows.Forms.Button();
      this.cmdFirst = new System.Windows.Forms.Button();
      this.dsData = new ADOInterop.dsData();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdUpdate
      // 
      this.cmdUpdate.Location = new System.Drawing.Point(352, 39);
      this.cmdUpdate.Name = "cmdUpdate";
      this.cmdUpdate.Size = new System.Drawing.Size(80, 23);
      this.cmdUpdate.TabIndex = 22;
      this.cmdUpdate.Text = "Update ADO";
      this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
      // 
      // txtPosition
      // 
      this.txtPosition.Location = new System.Drawing.Point(72, 111);
      this.txtPosition.Name = "txtPosition";
      this.txtPosition.Size = new System.Drawing.Size(200, 20);
      this.txtPosition.TabIndex = 27;
      this.txtPosition.Text = "";
      // 
      // txtCategoryDescription
      // 
      this.txtCategoryDescription.Location = new System.Drawing.Point(112, 55);
      this.txtCategoryDescription.Multiline = true;
      this.txtCategoryDescription.Name = "txtCategoryDescription";
      this.txtCategoryDescription.Size = new System.Drawing.Size(224, 40);
      this.txtCategoryDescription.TabIndex = 20;
      this.txtCategoryDescription.Text = "";
      // 
      // txtCategoryName
      // 
      this.txtCategoryName.Location = new System.Drawing.Point(112, 31);
      this.txtCategoryName.Name = "txtCategoryName";
      this.txtCategoryName.Size = new System.Drawing.Size(224, 20);
      this.txtCategoryName.TabIndex = 18;
      this.txtCategoryName.Text = "";
      // 
      // txtIdCategory
      // 
      this.txtIdCategory.Location = new System.Drawing.Point(112, 7);
      this.txtIdCategory.Name = "txtIdCategory";
      this.txtIdCategory.TabIndex = 16;
      this.txtIdCategory.Text = "";
      // 
      // lblDescription
      // 
      this.lblDescription.AutoSize = true;
      this.lblDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblDescription.Location = new System.Drawing.Point(16, 59);
      this.lblDescription.Name = "lblDescription";
      this.lblDescription.Size = new System.Drawing.Size(67, 16);
      this.lblDescription.TabIndex = 19;
      this.lblDescription.Text = "Description:";
      // 
      // lblCategoryName
      // 
      this.lblCategoryName.AutoSize = true;
      this.lblCategoryName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblCategoryName.Location = new System.Drawing.Point(16, 35);
      this.lblCategoryName.Name = "lblCategoryName";
      this.lblCategoryName.Size = new System.Drawing.Size(90, 16);
      this.lblCategoryName.TabIndex = 17;
      this.lblCategoryName.Text = "Category Name:";
      // 
      // lblCategoryKey
      // 
      this.lblCategoryKey.AutoSize = true;
      this.lblCategoryKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblCategoryKey.Location = new System.Drawing.Point(16, 11);
      this.lblCategoryKey.Name = "lblCategoryKey";
      this.lblCategoryKey.Size = new System.Drawing.Size(79, 16);
      this.lblCategoryKey.TabIndex = 15;
      this.lblCategoryKey.Text = "Category Key:";
      // 
      // cmdNext
      // 
      this.cmdNext.Location = new System.Drawing.Point(272, 111);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(32, 23);
      this.cmdNext.TabIndex = 28;
      this.cmdNext.Text = ">";
      this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
      // 
      // cmdLast
      // 
      this.cmdLast.Location = new System.Drawing.Point(304, 111);
      this.cmdLast.Name = "cmdLast";
      this.cmdLast.Size = new System.Drawing.Size(32, 23);
      this.cmdLast.TabIndex = 29;
      this.cmdLast.Text = ">|";
      this.cmdLast.Click += new System.EventHandler(this.cmdLast_Click);
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Location = new System.Drawing.Point(40, 111);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(32, 23);
      this.cmdPrevious.TabIndex = 26;
      this.cmdPrevious.Text = "<";
      this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
      // 
      // cmdMakeDB
      // 
      this.cmdMakeDB.Location = new System.Drawing.Point(352, 71);
      this.cmdMakeDB.Name = "cmdMakeDB";
      this.cmdMakeDB.Size = new System.Drawing.Size(80, 23);
      this.cmdMakeDB.TabIndex = 23;
      this.cmdMakeDB.Text = "Make DB";
      this.cmdMakeDB.Click += new System.EventHandler(this.cmdMakeDB_Click);
      // 
      // cmdMakeTable
      // 
      this.cmdMakeTable.Location = new System.Drawing.Point(352, 103);
      this.cmdMakeTable.Name = "cmdMakeTable";
      this.cmdMakeTable.Size = new System.Drawing.Size(80, 23);
      this.cmdMakeTable.TabIndex = 24;
      this.cmdMakeTable.Text = "Make Table";
      this.cmdMakeTable.Click += new System.EventHandler(this.cmdMakeTable_Click);
      // 
      // cmdOpen
      // 
      this.cmdOpen.Location = new System.Drawing.Point(352, 7);
      this.cmdOpen.Name = "cmdOpen";
      this.cmdOpen.Size = new System.Drawing.Size(80, 23);
      this.cmdOpen.TabIndex = 21;
      this.cmdOpen.Text = "Open ADO";
      this.cmdOpen.Click += new System.EventHandler(this.cmdOpen_Click);
      // 
      // cmdFirst
      // 
      this.cmdFirst.Location = new System.Drawing.Point(8, 111);
      this.cmdFirst.Name = "cmdFirst";
      this.cmdFirst.Size = new System.Drawing.Size(32, 23);
      this.cmdFirst.TabIndex = 25;
      this.cmdFirst.Text = "|<";
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.Locale = new System.Globalization.CultureInfo("nl-BE");
      // 
      // frmADOInterop
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(456, 141);
      this.Controls.Add(this.cmdUpdate);
      this.Controls.Add(this.txtPosition);
      this.Controls.Add(this.txtCategoryDescription);
      this.Controls.Add(this.txtCategoryName);
      this.Controls.Add(this.txtIdCategory);
      this.Controls.Add(this.lblDescription);
      this.Controls.Add(this.lblCategoryName);
      this.Controls.Add(this.lblCategoryKey);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.cmdLast);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.cmdMakeDB);
      this.Controls.Add(this.cmdMakeTable);
      this.Controls.Add(this.cmdOpen);
      this.Controls.Add(this.cmdFirst);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmADOInterop";
      this.Text = "ADO Interoperability";
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmADOInterop'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260503 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260503 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmADOInterop()
    //***
    // Action
    //   - Create instance of 'frmADOInterop'
    // Called by
    //   - Main()
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste � 20260503 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260503 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmADOInterop()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdFirst_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Select the first record in the data set thru binding
    //   - Update the display
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste � 20260503 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260503 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      BindingContext[dsData, "tblCPCategory"].Position = 0;
      UpdateDisplay();
    }
    // cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click

    private void cmdLast_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Select the last record in the data set thru binding
    //   - Update the display
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - UpdateDisplay()
    // Created
    //   - CopyPaste � 20260503 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260503 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      BindingContext[dsData, "tblCPCategory"].Position = BindingContext[dsData, "tblCPCategory"].Count - 1;
      UpdateDisplay();
    }
    // cmdLast_Click(System.Object, .EventArgs) Handles cmdLast.Click

    private void cmdMakeDB_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and create a new ADOX catalog
      //   - Define and create a new ADODB connection
      //   - Set a file path
      //   - Set a connection string
      //   - Set the connection string as connection string of the connection
      //   - Create the database
      //   - Show a message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20070508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - When database is already created, the routine crashes
      //***
    {
      ADOX.Catalog catmdb = new ADOX.Catalog();
      ADODB.Connection cnnADO =  new ADODB.Connection();
      string strConnection;
      string strFilePath;

      strFilePath = "T:\\Knowledge\\Data\\Test.mdb";
      strConnection = "Microsoft.ACE.OLEDB.12.0; Data Source = " + strFilePath + "; ";
      cnnADO.ConnectionString = strConnection;
      catmdb.Create(strConnection);
      MessageBox.Show("Finished", "Make DB");
    }
    // cmdMakeDB_Click(System.Object, System.EventArgs) Handles cmdMakeDB.Click

    private void cmdMakeTable_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and create a new ADOX catalog
      //   - Define and create a new ADODB connection
      //   - Define and create a new ADOX table
      //   - Try to
      //     - Set a file path
      //     - Set a connection string
      //     - Set the connection string as connection string of the connection
      //     - Open the connection
      //     - Set the connection to the catalog
      //     - Define the wanted table
      //     - Append the table to the list of tables of the catalog
      //     - Close the connection
      //     - Show a messsagebox with the result
      //   - On possible error
      //     - Show corresponding error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20070508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      ADOX.Catalog catmdb = new ADOX.Catalog();
      ADODB.Connection cnnADO = new ADODB.Connection();
      string strConnection;
      string strFilePath;
      ADOX.Table tabTable = new ADOX.Table();

      try
      {
        strFilePath = "T:\\Knowledge\\Data\\Test.mdb";
        strConnection = "Microsoft.ACE.OLEDB.12.0;Data Source=" + strFilePath + ";";
        cnnADO.ConnectionString = strConnection;
        cnnADO.Open(cnnADO.ConnectionString, "", "", 0);
        catmdb.ActiveConnection = cnnADO;

        tabTable.Name = "New Table";
        tabTable.Columns.Append("strIdTable", ADOX.DataTypeEnum.adWChar, 5);
        tabTable.Columns.Append("strValue", ADOX.DataTypeEnum.adWChar, 20);
        tabTable.Keys.Append("PKNewTable", ADOX.KeyTypeEnum.adKeyPrimary, "strIdTable", "", "");
      
        catmdb.Tables.Append(tabTable);
        cnnADO.Close();
        MessageBox.Show("Finished", "Make Table");
      }
      catch (Exception theException)
      {
        MessageBox.Show("The database does not exist!", "Copy Paste Error");
      }
      finally
      {
      }
    
    }
    // cmdMakeTable_Click(System.Object, .EventArgs) Handles cmdMakeTable.Click

    private void cmdNext_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If you are not on the last record
      //     - Select the next record in the data set thru binding
      //     - Update the display
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20070508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      
      if (BindingContext[dsData, "tblCPCategory"].Position == BindingContext[dsData, "tblCPCategory"].Count - 1)
      {
      }
      else
      // BindingContext[dsData, "tblCPCategory"].Position <> BindingContext[dsData, "tblCPCategory"].Count - 1
      {
        BindingContext[dsData, "tblCPCategory"].Position += 1;
        UpdateDisplay();
      }
      // BindingContext[dsData, "tblCPCategory"].Position = BindingContext[dsData, "tblCPCategory"].Count - 1
    
    }
    // cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click

    private void cmdOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a connection
      //   - Define and create an OleDb DataAdapter
      //   - Define and create a ADODB recordset
      //   - Create the connection
      //   - Open the connection
      //   - Open a recordset
      //   - Clear the dataset
      //   - Fill the dataset category with the recordset
      //   - Close the connection
      //   - Bind the dataset with the controls on the form
      // Called by
      //   - cmdUpdate_Click(System.Object, System.EventArgs) Handles cmdUpdate.Click
      //   - User action (Clicking a button)
      // Calls
      //   - CreateConnection() As ADODB.Connection
      //   - SetBindings(DataSet)
      // Created
      //   - CopyPaste � 20070508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      ADODB.Connection cnnADO; 
      System.Data.OleDb.OleDbDataAdapter dtaTemp = new System.Data.OleDb.OleDbDataAdapter();
      ADODB.Recordset rstRecordset = new ADODB.Recordset();

      cnnADO = CreateConnection();
      cnnADO.Open(cnnADO.ConnectionString, "", "", 0);
      rstRecordset.Open("SELECT * FROM tblCPCategory ORDER BY strCategoryName", cnnADO, ADODB.CursorTypeEnum.adOpenUnspecified, ADODB.LockTypeEnum.adLockUnspecified, 0);
      dsData.Clear();
      dtaTemp.Fill(dsData.tblCPCategory, rstRecordset);
      cnnADO.Close();
      SetBindings(dsData);
    }
    // cmdOpen_Click(System.Object, System.EventArgs) Handles cmdOpen.Click

    private void cmdPrevious_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If you are not on the first record
      //     - Select the previous record in the data set thru binding
      //     - Update the display
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20070508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (BindingContext[dsData, "tblCPCategory"].Position == 0)
      {
      }
      else
        // BindingContext[dsData, "tblCPCategory"].Position <> 0
      {
        BindingContext[dsData, "tblCPCategory"].Position -= 1;
        UpdateDisplay();
      }
      // .Position = 0
    
    }
    // cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click

    private void cmdUpdate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and create an ADODB recordset
      //   - Define a connection
      //   - Try to
      //     - Create a connection
      //     - Open the connection
      //     - Open a recordset
      //     - Add a record to the recordset
      //     - Fill in some values to the fields
      //     - Update the recordset
      //     - Close the recordset
      //     - Close the connection
      //     - Show a message that the update is finished
      //     - Fake a click on the open button
      //   - On possible error
      //     - Show the corresponding error message
      //     - You can't have twice the same category name
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cmdOpen_Click(System.Object, System.EventArgs) Handles cmdOpen.Click
      //   - CreateConnection()
      // Created
      //   - CopyPaste � 20070508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      ADODB.Recordset rstRecordset = new ADODB.Recordset();
      ADODB.Connection cnnADO;

      try
      {
        cnnADO = CreateConnection();
        cnnADO.Open(cnnADO.ConnectionString, "", "", 0);
        rstRecordset.Open("SELECT * FROM tblCPCategory ORDER BY strCategoryName", cnnADO, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockOptimistic, 0);
        
        rstRecordset.AddNew(Type.Missing, Type.Missing);
        rstRecordset.Fields["strCategoryName"].Value = "Test";
        rstRecordset.Fields["memDescription"].Value = "Description";
        rstRecordset.Update(Type.Missing, Type.Missing);
        
        rstRecordset.Close();
        cnnADO.Close();
        MessageBox.Show("Finished", "Update");
        cmdOpen_Click(theSender, theEventArguments);
      }
      catch (Exception theException)
      {
        MessageBox.Show("This record is already added!", "Copy Paste Error");
      }
      finally
      {
      }
    
    }
    // cmdUpdate_Click(System.Object, System.EventArgs) Handles cmdUpdate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private ADODB.Connection CreateConnection()
      //***
      // Action
      //   - Create a connection to cpNorthwind 2000 mdb (Access database)
      //   - Define and initialize a ADODB connection
      //   - Define and initialize a connection string
      //   - Set the connection string as to hte ADODB connection
      //   - Return the connection
      // Called by
      //   - cmdOpen_Click(System.Object, System.EventArgs) Handles cmdOpen.Click
      //   - cmdUpdate_Click(System.Object, System.EventArgs) Handles cmdUpdate.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20070508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      ADODB.Connection cnnConnection = new ADODB.Connection();
      string strConnectionString;

      strConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=T:\\Knowledge\\Data\\cpNorthwind 2000.mdb";
      cnnConnection.ConnectionString = strConnectionString;

      return cnnConnection;
    }
    // ADODB.Connection CreateConnection()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmADOInterop
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmADOInterop()
      // Created
      //   - CopyPaste � 20070508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmADOInterop());
    }
    // Main() 
    
    private void SetBindings(DataSet dsDataset)
      //***
      // Action
      //   - Clear the data bindings for txtIDCategory, txtCategoryName and txtCategoryDescription
      //   - Add new data bindings for the same controls
      //   - Update the display
      // Called by
      //   - cmdOpen_Click(System.Object, System.EventArgs) Handles cmdOpen.Click
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20070508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      txtIdCategory.DataBindings.Clear();
      txtCategoryName.DataBindings.Clear();
      txtCategoryDescription.DataBindings.Clear();
      txtIdCategory.DataBindings.Add("Text", dsDataset, "tblCPCategory.lngIdCategory");
      txtCategoryName.DataBindings.Add("Text", dsDataset, "tblCPCategory.strCategoryName");
      txtCategoryDescription.DataBindings.Add("Text", dsDataset, "tblCPCategory.memDescription");
      UpdateDisplay();
    }
    // SetBindings(DataSet)

    private void UpdateDisplay()
      //***
      // Action
      //   - Define a Binding Manager Base
      //   - Set the table "tblCPCategory" as the context of the binding
      //   - Set the correct position (Current record)
      // Called by
      //   - cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click
      //   - cmdLast_Click(System.Object, .EventArgs) Handles cmdLast.Click
      //   - cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click
      //   - cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click
      //   - SetBindings(DataSet)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20070508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      System.Windows.Forms.BindingManagerBase bmbBindingManagerBase;

      bmbBindingManagerBase = BindingContext[dsData, "tblCPCategory"];
      txtPosition.Text = "Category ";
      txtPosition.Text += (bmbBindingManagerBase.Position + 1).ToString();
      txtPosition.Text += " of ";
      txtPosition.Text += bmbBindingManagerBase.Count.ToString();
    }
    // UpdateDisplay()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmADOInterop

}
// CopyPaste.Learning