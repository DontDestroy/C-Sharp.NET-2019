//***
// Action
//   - Doing some actions with 3 buttons
// Created
//   - CopyPaste � 20240228 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240228 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmControlCollection: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdMoveObjects;
    internal System.Windows.Forms.Button cmdSecond;
    internal System.Windows.Forms.Button cmdFirst;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmControlCollection));
      this.cmdMoveObjects = new System.Windows.Forms.Button();
      this.cmdSecond = new System.Windows.Forms.Button();
      this.cmdFirst = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdMoveObjects
      // 
      this.cmdMoveObjects.Location = new System.Drawing.Point(24, 152);
      this.cmdMoveObjects.Name = "cmdMoveObjects";
      this.cmdMoveObjects.TabIndex = 6;
      this.cmdMoveObjects.Text = "Button3";
      this.cmdMoveObjects.Click += new System.EventHandler(this.cmdMoveObjects_Click);
      // 
      // cmdSecond
      // 
      this.cmdSecond.Location = new System.Drawing.Point(24, 96);
      this.cmdSecond.Name = "cmdSecond";
      this.cmdSecond.TabIndex = 5;
      this.cmdSecond.Text = "Button2";
      this.cmdSecond.Click += new System.EventHandler(this.cmdSecond_Click);
      // 
      // cmdFirst
      // 
      this.cmdFirst.Location = new System.Drawing.Point(24, 40);
      this.cmdFirst.Name = "cmdFirst";
      this.cmdFirst.Size = new System.Drawing.Size(72, 24);
      this.cmdFirst.TabIndex = 4;
      this.cmdFirst.Text = "Button1";
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      // 
      // frmControlCollection
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 253);
      this.Controls.Add(this.cmdMoveObjects);
      this.Controls.Add(this.cmdSecond);
      this.Controls.Add(this.cmdFirst);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmControlCollection";
      this.Text = "Test control collection";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmControlCollection'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmControlCollection()
      //***
      // Action
      //   - Create instance of 'frmControlCollection'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmControlCollection()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFirst_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Every control on the form gets the text "Click Me!".
      //     - We assume that the controls are buttons
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      foreach (Control mtheControl in Controls)
      {
        mtheControl.Text = "Click Me!";
      }
      // in Controls
    
    }
    // cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click

    private void cmdMoveObjects_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Every control on the form except cmdMoveObjects is put 25 pixels to the right
      //     - We assume that the controls are buttons
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      foreach (Control mtheControl in Controls)
      {

        if (mtheControl.Name == "cmdMoveObjects")
        {
        }
        else
          // mtheControl.Name <> "cmdMoveObjects"
        {
          mtheControl.Left = mtheControl.Left + 25;
        }
        // mtheControl.Name = "cmdMoveObjects"

      }
      // in Controls

    }
    // cmdMoveObjects_Click(System.Object, System.EventArgs) Handles cmdMoveObjects.Click

    private void cmdSecond_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Every control on the form is put 25 pixels to the right
      //     - We assume that the controls are buttons
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      foreach (Control mtheControl in Controls)
      {
        mtheControl.Left = mtheControl.Left + 25;
      }
      // in Controls
    
    }
    // cmdSecond_Click(System.Object , System.EventArgs) Handels cmdSecond.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmControlCollection
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmControlCollection());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmControlCollection

}
// CopyPaste.Learning