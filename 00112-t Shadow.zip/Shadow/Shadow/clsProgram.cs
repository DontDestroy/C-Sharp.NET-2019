//***
// Action
//   - TestRoutine for cpBase and cpDerived
// Created
//   - CopyPaste � 20240531 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240531 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define an instance of cpBase
      //   - Define an instance of cpDerived
      //   - Define an instance of mixed classes (polymorphism)
      //     - All cases are there, 3 of them are in comments
      //   - Show of the 3 instances the message
      //   - Show of the 3 instances the other message
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpBase.Message()
      //   - cpBase.New()
      //   - cpBase.OtherMessage()
      //   - cpDerived.Message()
      //   - cpDerived.New()
      //   - cpDerived.OtherMessage()
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBase thecpBase = new cpBase();
      cpDerived thecpDerived = new cpDerived();
      cpBase thecpMixed = new cpDerived();
      // cpBase thecpMixed = new cpBase();
      // cpDerived thecpMixed = new cpBase();
      // cpDerived thecpMixed = new cpDerived();

      Console.WriteLine("Message");
      Console.WriteLine("Base object Message: " + thecpBase.Message());
      Console.WriteLine("Derived object Message: " + thecpDerived.Message());
      Console.WriteLine("Mixed message: " + thecpMixed.Message());
      Console.WriteLine();
      Console.WriteLine("Other Message");
      Console.WriteLine("Base object Message2: " + thecpBase.OtherMessage());
      Console.WriteLine("Derived object Message2: " + thecpDerived.OtherMessage());
      Console.WriteLine("Mixed message2: " + thecpMixed.OtherMessage());
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx