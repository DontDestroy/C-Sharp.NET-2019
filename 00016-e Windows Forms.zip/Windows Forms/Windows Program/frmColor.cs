//***
// Action
//   - Three buttons executes the same code, , added with EventHandler
//   - A textbox is added that shows what color is clicked
//   - A link to the Microsoft website and MSDN is added
// Created
//   - CopyPaste � 20240221 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240221 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmColor: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblTitle;
    internal System.Windows.Forms.Button cmdGreen;
    internal System.Windows.Forms.Button cmdBlue;
    internal System.Windows.Forms.LinkLabel lnlMicrosoft;
    internal System.Windows.Forms.Button cmdRed;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmColor));
      this.lblTitle = new System.Windows.Forms.Label();
      this.cmdGreen = new System.Windows.Forms.Button();
      this.cmdBlue = new System.Windows.Forms.Button();
      this.cmdRed = new System.Windows.Forms.Button();
      this.lnlMicrosoft = new System.Windows.Forms.LinkLabel();
      this.SuspendLayout();
      // 
      // lblTitle
      // 
      this.lblTitle.Location = new System.Drawing.Point(16, 8);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(248, 23);
      this.lblTitle.TabIndex = 10;
      this.lblTitle.Text = "Choose a color";
      this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cmdGreen
      // 
      this.cmdGreen.BackColor = System.Drawing.Color.Green;
      this.cmdGreen.Location = new System.Drawing.Point(104, 40);
      this.cmdGreen.Name = "cmdGreen";
      this.cmdGreen.TabIndex = 12;
      this.cmdGreen.Text = "&Green";
      // 
      // cmdBlue
      // 
      this.cmdBlue.BackColor = System.Drawing.Color.Blue;
      this.cmdBlue.Location = new System.Drawing.Point(192, 40);
      this.cmdBlue.Name = "cmdBlue";
      this.cmdBlue.TabIndex = 13;
      this.cmdBlue.Text = "&Blue";
      // 
      // cmdRed
      // 
      this.cmdRed.BackColor = System.Drawing.Color.Red;
      this.cmdRed.ForeColor = System.Drawing.SystemColors.ControlText;
      this.cmdRed.Location = new System.Drawing.Point(16, 40);
      this.cmdRed.Name = "cmdRed";
      this.cmdRed.TabIndex = 11;
      this.cmdRed.Text = "&Red";
      // 
      // lnlMicrosoft
      // 
      this.lnlMicrosoft.LinkArea = new System.Windows.Forms.LinkArea(0, 0);
      this.lnlMicrosoft.Location = new System.Drawing.Point(17, 80);
      this.lnlMicrosoft.Name = "lnlMicrosoft";
      this.lnlMicrosoft.Size = new System.Drawing.Size(248, 56);
      this.lnlMicrosoft.TabIndex = 14;
      this.lnlMicrosoft.Text = "The Microsoft Site offers computer information, and the MSDN site contains techni" +
        "cal information.";
      this.lnlMicrosoft.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      this.lnlMicrosoft.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnlMicrosoft_LinkClicked);
      // 
      // frmColor
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(282, 273);
      this.Controls.Add(this.lnlMicrosoft);
      this.Controls.Add(this.lblTitle);
      this.Controls.Add(this.cmdGreen);
      this.Controls.Add(this.cmdBlue);
      this.Controls.Add(this.cmdRed);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmColor";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Color Example";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmColor'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmColor()
      //***
      // Action
      //   - Create instance of 'frmColor'
      //   - Add the click functionality to every button
      //   - Add 2 click functionalities to the text of a label (they become links)
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      this.cmdBlue.Click += new System.EventHandler(this.cmdButton_Click);
      this.cmdGreen.Click += new System.EventHandler(this.cmdButton_Click);
      this.cmdRed.Click += new System.EventHandler(this.cmdButton_Click);
      lnlMicrosoft.Links.Add(4, 14, "www.microsoft.com");
      lnlMicrosoft.Links.Add(56, 9, "www.msdn.microsoft.com");
    }
    // frmColor()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdButton_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Check what button is clicked
      //   - Convert the object to a button
      //   - Look at the backcolor
      //   - The form gets that backcolor
      //   - A text is filled with information
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Button theClickedButton;

      theClickedButton = (Button)theSender;
      this.BackColor = theClickedButton.BackColor;
      this.lblTitle.Text = "You have choosen: " + theClickedButton.Text;
    }
    // cmdButton_Click(System.Object, System.EventArgs)
   
    private void lnlMicrosoft_LinkClicked(System.Object theSender, System.Windows.Forms.LinkLabelLinkClickedEventArgs theLinkLabelLinkClickedEventArguments)
      //***
      // Action
      //   - Start a browser to the Microsoft website
      // Called by
      //   - User action (Clicking a link)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Process.Start("msedge.exe", theLinkLabelLinkClickedEventArguments.Link.LinkData.ToString());
    }
    // lnlMicrosoft_LinkClicked(System.Object, System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnlMicrosoft.LinkClicked

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmColor
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmColor());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmColor

}
// CopyPaste.Learning