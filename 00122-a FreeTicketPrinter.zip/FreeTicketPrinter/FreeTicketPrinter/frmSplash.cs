//***
// Action
//   - Shows a splashscreen at the start of the application
// Created
//   - CopyPaste � 20240529 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240529 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSplash: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    internal System.Windows.Forms.PictureBox picLogo;
    internal System.Windows.Forms.Label lblText;
    internal System.Windows.Forms.Timer tmrSplash;
    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSplash));
      this.picLogo = new System.Windows.Forms.PictureBox();
      this.lblText = new System.Windows.Forms.Label();
      this.tmrSplash = new System.Windows.Forms.Timer(this.components);
      this.SuspendLayout();
      // 
      // picLogo
      // 
      this.picLogo.Image = ((System.Drawing.Image)(resources.GetObject("picLogo.Image")));
      this.picLogo.Location = new System.Drawing.Point(96, 208);
      this.picLogo.Name = "picLogo";
      this.picLogo.Size = new System.Drawing.Size(192, 64);
      this.picLogo.TabIndex = 3;
      this.picLogo.TabStop = false;
      // 
      // lblText
      // 
      this.lblText.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblText.Location = new System.Drawing.Point(32, 48);
      this.lblText.Name = "lblText";
      this.lblText.Size = new System.Drawing.Size(224, 96);
      this.lblText.TabIndex = 2;
      this.lblText.Text = "Free Ticket Printer";
      this.lblText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // tmrSplash
      // 
      this.tmrSplash.Enabled = true;
      this.tmrSplash.Interval = 2000;
      this.tmrSplash.Tick += new System.EventHandler(this.tmrSplash_Tick);
      // 
      // frmSplash
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.lblText);
      this.Controls.Add(this.picLogo);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "frmSplash";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Free Ticket Printer";
      this.Load += new System.EventHandler(this.frmSplash_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSplash'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSplash()
      //***
      // Action
      //   - Create instance of 'frmSplash'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSplash()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmSplash_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmData
      //   - Show the instance  
      // Called by
      //   - System action (Starting a form)
      // Calls
      //   - frmData.New()
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmData frmMain = new frmData();
      
      frmMain.Show();
    }
    // frmSplash_Load(System.Object, System.EventArgs) Handles this.Load

    private void tmrSplash_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - After a certain time (property of the timer)
      //     - Timer is switched off
      //     - This screen is hidden
      // Called by
      //   - System action (Timer ticks)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      tmrSplash.Enabled = false;
      this.Hide();
    }
    // tmrSplash_Tick(System.Object, System.EventArgs) Handles tmrSplash.Tick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSplash
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSplash()
      // Created
      //   - CopyPaste � 20240529 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240529 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSplash());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSplash

}
// CopyPaste.Learning