//***
// Action
//   - Implementation of the cpctlTrain
//   - There is a visualisation of a train (OnPaint)
//   - Property Distance is the position of the train next to the track (Read only)
//   - Property Speed is the speed of the train in pixels per second
//     - This is used in a timer control on the cpctlTrain
//   - There is an event cpDistanceChanged
//     - This signals to the listeners that the train has moved next to the track
//     - The sender is the instance of control itself (cpctlTrain)
//     - The information is given thru with a cpDistanceChangedEventArguments
// Created
//   - CopyPaste � 20240228 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240228 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace CopyPaste.Learning.Games
{

  // This attribute makes that doubleclick on the control will add the eventmethod in the code
  [DefaultEventAttribute("cpDistanceChanged")]
  public class cpctlTrain : System.Windows.Forms.UserControl
	{

    #region Component Designer generated code
    private System.ComponentModel.IContainer components;
    private System.Windows.Forms.Timer tmrDistance;

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.tmrDistance = new System.Windows.Forms.Timer(this.components);
      // 
      // tmrDistance
      // 
      this.tmrDistance.Enabled = true;
      this.tmrDistance.Tick += new System.EventHandler(this.tmrDistance_Tick);
      // 
      // cpctlTrain
      // 
      this.Name = "cpctlTrain";

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpctlTrain'
      // Called by
      //   - User action (Closing the control)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpctlTrain()
      //***
      // Action
      //   - Create instance of 'cpctlTrain'
      // Called by
      //   - User action (Starting the control)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // cpctlTrain()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mlngDistance = 0;
    private int mlngSpeed = 0;
    // The declaration of an eventhandler
    public delegate void cpDistanceChangedEventHandler(System.Object theSender, cpDistanceChangedEventArguments thecpDistanceChangedEventArguments);

    #endregion

    #region "Properties"

    public int Distance
    {

      get
        //***
        // Action Get
        //   - Returns the distance of the train next to the track
        // Called by
        //   - tmrDistance_Tick(System.Object, System.EventArgs) Handles tmrDistance.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240228 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240228 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mlngDistance;
      }
      // int Distance

    }
    // int Distance

    public int Speed
    {

      get
        //***
        // Action Get
        //   - Returns the speed of the train (the change of pixels per second)
        // Called by
        //   - cpctlTrain_cpDistanceChanged(System.Object, cpDistanceChangedEventArguments) Handles cpctlTrain.cpDistanceChanged
        //   - frmTrainGame.trbThrottle_ValueChanged(System.Object, System.EventArgs) Handles trbThrottle.ValueChanged
        //   - tmrDistance_Tick(System.Object, System.EventArgs) Handles tmrDistance.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240228 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240228 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mlngSpeed;
      }
      // int Speed (Get)

      set
        //***
        // Action Set
        //   - Set the speed of the train (the change of pixels per second)
        //   - If value is negative
        //     - The train stops by setting the speed to zero
        // Called by
        //   - frmTrainGame.cmdRestart_Click(System.Object, System.EventArgs) Handles cmdRestart.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240228 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240228 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (value >= 0)
        {
          mlngSpeed = value;
        }
        else
          // value < 0
        {
          mlngSpeed = 0;
        }
        // value >= 0

      }
      // Speed(int) (Set)

    }
    // int Speed

    #endregion

    #region "Methods"

    #region "Overrides"

    #endregion

    #region "Controls"

    private void tmrDistance_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If the speed is zero
      //     - Nothing happens
      //   - If not
      //     - The distance of the train is adapted
      //       - A number of pixels is added (speed * seconds)
      //       - An event is raised (signal is send)
      //         - Sender is the control
      //         - Arguments are the distance of the train
      // Called by
      //   - System action (Tick of a timer)
      // Calls
      //   - cpDistanceChanged(System.Object, cpDistanceChangedEventArguments)
      //   - cpDistanceChangedEventArguments(int)
      //   - int Distance (Get)
      //   - int Speed (Get)
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (Speed > 0)
      {
        cpDistanceChangedEventArguments thecpDistanceChangedEventArguments;

        mlngDistance += Convert.ToInt32(Convert.ToInt32(Speed) * (Convert.ToDouble(tmrDistance.Interval) / 1000));
        thecpDistanceChangedEventArguments = new cpDistanceChangedEventArguments(Distance);
        cpDistanceChanged(this, thecpDistanceChangedEventArguments);
      }
      else
        // Speed <= 0
      {
      }
      // Speed > 0

    }
    // tmrDistance_Tick(System.Object theSender, System.EventArgs theEventArguments) Handles tmrDistance.Tick

    #endregion

    #region "Functionality"

    #region "Event"

    public event cpDistanceChangedEventHandler cpDistanceChanged;
    // tmrFire_Tick(System.Object, System.EventArgs) Handles tmrFire.Tick

    #endregion

    #region "Sub / Function"

    public void Restart()
      //***
      // Action
      //   - Train is put back at the starting position
      // Called by
      //   - frmTrainGame.cmdRestart_Click(System.Object, System.EventArgs) Handles cmdRestart.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mlngDistance = 0;
    }
    // Restart()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpctlTrain

}
// CopyPaste.Learning.Games