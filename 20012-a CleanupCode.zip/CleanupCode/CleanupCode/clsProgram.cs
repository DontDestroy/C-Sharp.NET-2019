﻿//***
// Action
//   - Code that can be used to demo the cleanup code functionality
// Created
//   - CopyPaste – 20251223 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251223 – VVDW
// Proposal (To Do)
//   - Use Ctrl+Z or the commented code to go back to the original state
//***

using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;

// using System;
// using static System.Console;
// using System.Collections.Generic;
// using System.Linq;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private static void ConvertAnonymousTypeToClass()
    //***
    // Action
    //   - Demo some code (Conversion anonymous type to Class)
    //   - Create an anonymous type with flag, priority and log level
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      var logger = new
      {
        Flag = "Start",
        Priority = 10,
        LogLevel = "Mail"
      };

    }
    // ConvertAnonymousTypeToClass()

    //private static void ConvertAnonymousTypeToClass()
    ////***
    //// Action
    ////   - Demo some code (Conversion anonymous type to Class)
    ////   - Create an anonymous type with flag, priority and log level
    //// Called by
    ////   - Main()
    //// Calls
    ////   - 
    //// Created
    ////   - CopyPaste – 20251223 – VVDW
    //// Changed
    ////   - CopyPaste – yyyymmdd – VVDW – What changed
    //// Tested
    ////   - CopyPaste – 20251223 – VVDW
    //// Keyboard key
    ////   - 
    //// Proposal (To Do)
    ////   - 
    ////***
    //{
    //  var logger = new
    //  {
    //    flag = "Start",
    //    priority = 10,
    //    logLevel = "Mail"
    //  };
    //
    //}
    //// ConvertAnonymousTypeToClass()

    private static void ConvertToInterpolatedString()
    //***
    // Action
    //   - Demo some code (Conversion to Interpolated string)
    //   - Define some string variables to create a name
    //   - Create a full name to show
    //   - Show it in the console
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strFirstName = "Vincent";
      string strLastName = "Van De Walle";
      string strShowFullName = string.Format("My name is {0} {1}", strFirstName, strLastName);

      WriteLine(strShowFullName);
    }
    // ConvertToInterpolatedString()

    //private static void ConvertToInterpolatedString()
    ////***
    //// Action
    ////   - Demo some code (Conversion to Interpolated string)
    ////   - Define some string variables to create a name
    ////   - Create a full name to show
    ////   - Show it in the console
    //// Called by
    ////   - Main()
    //// Calls
    ////   - 
    //// Created
    ////   - CopyPaste – 20251223 – VVDW
    //// Changed
    ////   - CopyPaste – yyyymmdd – VVDW – What changed
    //// Tested
    ////   - CopyPaste – 20251223 – VVDW
    //// Keyboard key
    ////   - 
    //// Proposal (To Do)
    ////   - 
    ////***
    //{
    //  string strFirstName = "Vincent";
    //  string strLastName = "Van De Walle";
    //  string strShowFullName = string.Format("My name is {0} {1}", strFirstName, strLastName);
    //
    //  WriteLine(strShowFullName);
    //}
    //// ConvertToInterpolatedString()

    private static void ConvertToLinq()
    //***
    // Action
    //   - Demo some code (Conversion to Linq)
    //     - You can choose between expression notation or fluent notation
    //   - Define and assign a list of strings with 4 items
    //   - Loop thru the items
    //     - Show the item on the console
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      List<string> lstWidgets = new List<string>()
        {"FirstWidget", "SecondWidget", "ThirdWidget", "FourthWidget"};

      foreach (string strWidget in lstWidgets)
      {

        if (strWidget.StartsWith("F"))
        {
          WriteLine($"{strWidget} is an item in the list that starts with an F");
        }
        // strWidget.StartsWith("F")

      }
      // in lstWidgets

    }
    // ConvertToLinq()

    //private static void ConvertToLinq()
    ////***
    //// Action
    ////   - Demo some code (Conversion to Linq)
    ////     - You can chose between expression notation or fluent notation
    ////   - Define and assign a list of strings with 4 items
    ////   - Loop thru the items
    ////     - Show the item on the console
    //// Called by
    ////   - Main()
    //// Calls
    ////   - 
    //// Created
    ////   - CopyPaste – 20251223 – VVDW
    //// Changed
    ////   - CopyPaste – yyyymmdd – VVDW – What changed
    //// Tested
    ////   - CopyPaste – 20251223 – VVDW
    //// Keyboard key
    ////   - 
    //// Proposal (To Do)
    ////   - 
    ////***
    //{
    //  List<string> lstWidgets = new List<string>()
    //    {"FirstWidget", "SecondWidget", "ThirdWidget", "FourthWidget"};
    //
    //  foreach (string strWidget in lstWidgets)
    //  {
    //
    //    if (strWidget.StartsWith("F"))
    //    {
    //      WriteLine($"{strWidget} is an item in the list that starts with an F");
    //    }
    //    else
    //    // strWidget.StartsWith("F")
    //
    //  }
    //  // in lstWidgets
    //
    //}
    //// ConvertToLinq()

    private static void DemoIntellisence()
    //***
    // Action
    //   - Create and initialize a first human
    //   - Show the default info of the first human
    // Called by
    //   - Main()
    // Calls
    //   - cpHuman(string, string, int)
    //   - cpHuman.FullName(cpHuman.NameOrder)
    //   - cpHuman.ToString()
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpHuman theFirstHuman = new cpHuman("Vincent", "Van De Walle", 55);
      cpHuman theSecondHuman = new cpHuman("Hilde", "Saelens", 57);

      string strFullName = "";
      string[] strSplittedName;

      WriteLine(theFirstHuman.ToString());
      strFullName = theFirstHuman.FullName(cpHuman.NameOrder.LastFirst);
      strSplittedName = strFullName.Split(' ');
      WriteLine(strFullName);
      WriteLine(strSplittedName[0]);

      WriteLine(theSecondHuman.ToString());
      strFullName = theSecondHuman.FullName(cpHuman.NameOrder.FirstLast);
      strSplittedName = strFullName.Split(' ');
      WriteLine(strFullName);
      WriteLine(strSplittedName[0]);
    }
    // DemoIntellisence()

    private static void LinqQueryWithLet()
    //***
    // Action
    //   - Demo some code (Linq with Let)
    //   - Define and assign a list of strings with 8 items
    //   - Filter the items with Linq query
    //     - Take all the codes that are starting with "A100" and the number after the dash larger than 199
    //   - Loop thru the filtered items
    //     - Show the item on the console
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      List<string> lstStockCodes = new List<string>()
        {"A100-341", "B101-754", "A100-197", "C201-341", "B102-774", "C101-111", "A100-774", "C105-191"};

      IEnumerable<string> lstFilteredStockCodes =
        from aFiltered in lstStockCodes
        let strItem = (aFiltered.StartsWith("A100") ? (aFiltered.Replace("A100-", "")) : "0")
        where Convert.ToInt32(strItem) > 200
        select strItem;

      foreach (string strStockCode in lstFilteredStockCodes)
      {
        WriteLine($"{strStockCode} is a stock code A100 in the 200 or more range");
      }
      // in lstFilteredStockCodes

    }
    // LinqQueryWithLet()

    public static void Main()
    //***
    // Action
    //   - Demo some code (can be cleaned up)
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - ConvertAnonymousTypeToClass()
    //   - ConvertToInterpolatedString()
    //   - ConvertToLinq()
    //   - cpLogger()
    //   - cpLogger.AddLogEntry()
    //   - DemoIntellisence()
    //   - LinqQueryWithLet()
    //   - NotSoNiceCode()
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - You will need to change cpLogger into your created class
    //***
    {
      cpLogger theLogger = new cpLogger("Start", 10, "Mail");

      NotSoNiceCode();
      WriteLine();
      ConvertToLinq();
      WriteLine();
      LinqQueryWithLet();
      WriteLine();
      ConvertToInterpolatedString();
      WriteLine();
      theLogger.AddLogEntry();
      WriteLine();
      DemoIntellisence();
      WriteLine();
      WriteLine("Hit any key");
      ReadLine();
    }
    // Main()

    public static void NotSoNiceCode()
    //***
    // Action
    //   - Create an integer with a useless assignment
    //   - Change the value into zero
    //   - Show the result
    // Called by
    //   - Main()
    // Calls
    //   - ConvertToLinq()
    //   - ZeroValue(int)
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intValue = 15;
      ZeroValue(out intValue);
      WriteLine($"The variable changed to: {intValue}");
    }
    // NotSoNiceCode()

    //public static void NotSoNiceCode()
    ////***
    //// Action
    ////   - Create an integer with a useless assignment
    ////   - Change the value into zero
    ////   - Show the result
    //// Called by
    ////   - Main()
    //// Calls
    ////   - ZeroValue(int)
    //// Created
    ////   - CopyPaste – 20251223 – VVDW
    //// Changed
    ////   - CopyPaste – yyyymmdd – VVDW – What changed
    //// Tested
    ////   - CopyPaste – 20251223 – VVDW
    //// Keyboard key
    ////   - 
    //// Proposal (To Do)
    ////   - 
    ////***
    //{
    //  int intValue = 15;
    //  ZeroValue(out intValue);
    //  WriteLine($"The variable changed to: {intValue}");
    //}
    //// NotSoNiceCode()

    public static void ZeroValue(out int intValue)
    //***
    // Action
    //   - Assign the value 0 to an out variable
    // Called by
    //   - NotSoNiceCode()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251223 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251223 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      intValue = 0;
    }
    // ZeroValue(int)

    //public static void ZeroValue(out int intValue)
    ////***
    //// Action
    ////   - Assign the value 0 to an out variable
    //// Called by
    ////   - NotSoNiceCode()
    //// Calls
    ////   - 
    //// Created
    ////   - CopyPaste – 20251223 – VVDW
    //// Changed
    ////   - CopyPaste – yyyymmdd – VVDW – What changed
    //// Tested
    ////   - CopyPaste – 20251223 – VVDW
    //// Keyboard key
    ////   - 
    //// Proposal (To Do)
    ////   - 
    ////***
    //{
    //  intValue = 0;
    //}
    //// ZeroValue(int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning