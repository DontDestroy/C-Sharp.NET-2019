//***
// Action
//   - Testroutine of cpAccount, cpSavingAccount and cpUsingAccount
// Created
//   - CopyPaste � 20240105 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240105 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

	public class cpProgram
	{
	
		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public static void Main()
			//***
			// Action
			//   - Create an owner
			//   - Create a correct Belgian saving account
			//   - Create two correct Belgian using accounts
			//   - Add all accounts to an array of accounts
			//   - Show the information of all accounts
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - cpClient(string, string)
			//   - cpSavingAccount(long, decimal, DateTime, decimal, cpClient)
			//   - cpUsingAccount(long, decimal, DateTime, decimal, cpClient)
			//   - string cpAccount.ToString()
			//   - string cpSavingAccount.ToString()
			//   - string cpUsingAccount.ToString()
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - Not all properties are tested in this routine
			//***
	{

			try
			{
				cpAccount[] arrcpAccount = new cpAccount[3];
				cpClient thecpOwner = new cpClient("Vincent", "Van De Walle");

				// Happy flow
				cpSavingAccount thecpSavingAccount01 = new cpSavingAccount(83179377453, 0, new DateTime(2004, 12, 19), 4.5M, thecpOwner);
				cpSavingAccount thecpSavingAccount02 = new cpSavingAccount(83179377554, 0, new DateTime(2004, 12, 20), 3.8M, thecpOwner);
				cpUsingAccount thecpUsingAccount = new cpUsingAccount(63154756360, 0, new DateTime(2004, 12, 18), -1000, thecpOwner);

				arrcpAccount[0] = thecpUsingAccount;
				arrcpAccount[1] = thecpSavingAccount01;
				arrcpAccount[2] = thecpSavingAccount02;

				thecpUsingAccount.Add(1000);
				thecpSavingAccount01.Add(125);
				thecpSavingAccount02.Add(250);

				foreach(cpAccount thecpAccount in arrcpAccount)
				{
					Console.WriteLine(thecpAccount.ToString());
					Console.WriteLine();
				}
				// in arrcpAccount

			}			
			catch (Exception theException)
			{
				Console.WriteLine(theException.Message);
			}
			finally
			{
				Console.ReadLine();
			}

		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.Learning