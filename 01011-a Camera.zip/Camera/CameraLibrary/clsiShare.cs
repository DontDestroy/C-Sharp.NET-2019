﻿//***
// Action
//   - Interface for the behaviour (method) Share
// Created
//   - CopyPaste – 20240810 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240810 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Camera.Library
{

	public interface cpiShare
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a camera can share
		/// </summary>
		public void Share();
		// Share()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpiShare

}
// CopyPaste.Camera.Library