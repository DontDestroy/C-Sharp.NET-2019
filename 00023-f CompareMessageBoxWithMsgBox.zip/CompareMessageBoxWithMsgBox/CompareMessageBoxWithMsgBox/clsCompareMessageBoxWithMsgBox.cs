//***
// Action
//   - Comparing the functionality Msgbox (VB library) and MessageBox (.NET)
// Created
//   - CopyPaste � 20210831 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210831 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace CompareMessageBoxWithMsgBox
{

  public class cpCompareMessageBoxWithMsgBox
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Using Msgbox Functionality
    //   - Using MessageBox Functionality
    //   - Hardcoded by comment to choose one of the two
    // Called by
    //   - User action (starting the program)
    // Calls
    //   - MsgBoxTest()
    //   - MesssageBoxTest()
    // Created
    //   - CopyPaste � 20210831 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210831 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      // MsgBoxTest();
      MessageboxTest();      
    }
    // Main()

    static void MesssageBoxCheckResult(DialogResult dlgResult)
    //***
    // Action
    //   - Depending on result (dlgResult)
    //     - Show messagebox that you clicked Abort
    //     - Show messagebox that you clicked Cancel
    //     - Show messagebox that you clicked Ignore
    //     - Show messagebox that you clicked No
    //     - Show messagebox that you clicked on nothing
    //     - Show messagebox that you clicked OK
    //     - Show messagebox that you clicked Retry
    //     - Show messagebox that you clicked Yes
    //     - Show messagebox that you clicked on something for future use
    // Called by
    //   - MessageBoxTest()
    // Calls
    //   - System.Windows.Forms.MessageBox.Show(String, and a bunch of parameters / overloads)
    // Created
    //   - CopyPaste � 20210831 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210831 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      switch (dlgResult)
      {
        case DialogResult.Abort:
          MessageBox.Show("You clicked the Abort button", "Copy Paste Result", MessageBoxButtons.OK);
          break;
        case DialogResult.Cancel:
          MessageBox.Show("You clicked the Cancel button", "Copy Paste Result", MessageBoxButtons.OK);
          break;
        case DialogResult.Ignore:
          MessageBox.Show("You clicked the Ignore button", "Copy Paste Result", MessageBoxButtons.OK);
          break;
        case DialogResult.No:
          MessageBox.Show("You clicked the No button", "Copy Paste Result", MessageBoxButtons.OK);
          break;
        case DialogResult.None:
          MessageBox.Show("The modal dialogbox is still running", "Copy Paste", MessageBoxButtons.OK);
          break;
        case DialogResult.OK:
          MessageBox.Show("You clicked the OK button", "Copy Paste Result", MessageBoxButtons.OK);
          break;
        case DialogResult.Retry:
          MessageBox.Show("You clicked the Retry button", "Copy Paste Result", MessageBoxButtons.OK);
          break;
        case DialogResult.Yes:
          MessageBox.Show("You clicked the Yes button", "Copy Paste Result", MessageBoxButtons.OK);
          break;
        default:
          MessageBox.Show("Can be used for future changes", "Copy Paste Result", MessageBoxButtons.OK);
          break;
      }
      // (dlgResult)

    }
    // MessageboxCheckResult(DialogResult)

    static void MsgBoxCheckResult(MsgBoxResult msgResult)
    //***
    // Action
    //   - Depending on result (msgResult)
    //     - Show messagebox that you clicked Abort
    //     - Show messagebox that you clicked Cancel
    //     - Show messagebox that you clicked Ignore
    //     - Show messagebox that you clicked No
    //     - Show messagebox that you clicked OK
    //     - Show messagebox that you clicked Retry
    //     - Show messagebox that you clicked Yes
    //     - Show messagebox that you clicked on something for future use
    // Called by
    //   - MsgBoxTest()
    // Calls
    //  - Msgbox(Object, MsgBoxStyle, [Object]) As MsgBoxResult
    // Created
    //   - CopyPaste � 20210831 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210831 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      switch (msgResult)
      {
        case MsgBoxResult.Abort:
          Interaction.MsgBox("You clicked the Abort button", MsgBoxStyle.OkOnly, "Copy Paste Result");
          break;
        case MsgBoxResult.Cancel:
          Interaction.MsgBox("You clicked the Cancel button", MsgBoxStyle.OkOnly, "Copy Paste Result");
          break;
        case MsgBoxResult.Ignore:
          Interaction.MsgBox("You clicked the Ignore button", MsgBoxStyle.OkOnly, "Copy Paste Result");
          break;
        case MsgBoxResult.No:
          Interaction.MsgBox("You clicked the No button", MsgBoxStyle.OkOnly, "Copy Paste Result");
          break;
        case MsgBoxResult.Ok:
          Interaction.MsgBox("You clicked the OK button", MsgBoxStyle.OkOnly, "Copy Paste Result");
          break;
        case MsgBoxResult.Retry:
          Interaction.MsgBox("You clicked the Retry button", MsgBoxStyle.OkOnly, "Copy Paste Result");
          break;
        case MsgBoxResult.Yes:
          Interaction.MsgBox("You clicked the Yes button", MsgBoxStyle.OkOnly, "Copy Paste Result");
          break;
        default:
          Interaction.MsgBox("Can be used for future changes", MsgBoxStyle.OkOnly, "Copy Paste Result");
          break;
      }
      // (msgResult)

    }
    // MsgBoxCheckResult(MsgBoxResult)

    static void MessageboxTest()
    //***
    // Action
    //   - Using MessageBox Functionality
    //   - Define 2 variables (strText and strTitle)
    //   - Show a messagebox with 3 buttons, an asterix, third button default, Desktop only
    //   - Show a messagebox with OK button, an error, Right align
    //   - Show a messagebox with 2 buttons, an exclamation, second button default, Left reading order
    //   - Show a messagebox with 2 buttons, a hand, first button default, ServiceNotification
    //   - Show a messagebox with 2 buttons, an information
    //   - Show a messagebox with 3 buttons, no icon
    //   - Show a messagebox with OK button, a question mark
    //   - Show a messagebox with OK button, a stop sign
    //   - Show a messagebox with OK button, a warning
    //   - Remember the result of Show a messagebox with Yes and No button
    //   - Show the chosen result
    // Called by
    //   - Main()
    // Calls
    //   - MesssageBoxCheckResult(DialogResult)
    // Created
    //   - CopyPaste � 20210831 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210831 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      string strText = "This is the message";
    string strTitle = "Copy Paste";

    MessageBox.Show(strText, strTitle, MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Asterisk, MessageBoxDefaultButton.Button3, MessageBoxOptions.DefaultDesktopOnly);
    MessageBox.Show(strText, strTitle, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1, MessageBoxOptions.RightAlign);
    MessageBox.Show(strText, strTitle, MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2, MessageBoxOptions.RtlReading);
    MessageBox.Show(strText, strTitle, MessageBoxButtons.RetryCancel, MessageBoxIcon.Hand, MessageBoxDefaultButton.Button1, MessageBoxOptions.ServiceNotification);
    MessageBox.Show(strText, strTitle, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
    MessageBox.Show(strText, strTitle, MessageBoxButtons.YesNoCancel, MessageBoxIcon.None);
    MessageBox.Show(strText, strTitle, MessageBoxButtons.OK, MessageBoxIcon.Question);
    MessageBox.Show(strText, strTitle, MessageBoxButtons.OK, MessageBoxIcon.Stop);
    MessageBox.Show(strText, strTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
    MesssageBoxCheckResult(MessageBox.Show(strText, strTitle, MessageBoxButtons.YesNo));
    }
    // MessageboxTest()

    static void MsgBoxTest()
    //***
    // Action
    //   - Using MsgBox Functionality
    //   - Define 1 variable (strText)
    //   - Show a messagebox with 1 button and corresponding title
    //   - Show a messagebox with critical icon and corresponding title
    //   - Show a messagebox with exclamation icon and corresponding title
    //   - Show a messagebox with information icon and corresponding title
    //   - Show a messagebox with question icon and corresponding title
    //   - Show a messagebox with 2 buttons and corresponding title
    //   - Show a messagebox with 2 buttons, second default and corresponding title
    //   - Show a messagebox with 2 buttons and corresponding title
    //   - Show a messagebox with 3 buttons, third default and corresponding title
    //   - Show a messagebox with 3 buttons and corresponding title
    //   - Show a messagebox with help and corresponding title
    //   - Show a messagebox with Right and corresponding title
    //   - Show a messagebox with Right to left reading and corresponding title
    //   - Show a messagebox with on the foreground and corresponding title
    //   - Show a messagebox with modal application and corresponding title
    //   - Show a messagebox with modal system and corresponding title
    //   - Remember the result of Show a messagebox with Yes and No button and corresponding title
    //   - Show the chosen result
    // Called by
    //   - Main()
    // Calls
    //   - MsgBoxCheckResult(Int32)
    // Created
    //   - CopyPaste � 20210831 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210831 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    // ***
    {
      string strText = "This is the message";

      Interaction.MsgBox(strText, MsgBoxStyle.OkOnly, "MsgBoxStyle.OKOnly");
      Interaction.MsgBox(strText, MsgBoxStyle.Critical, "MsgBoxStyle.Critical");
      Interaction.MsgBox(strText, MsgBoxStyle.Exclamation, "MsgBoxStyle.Exclamation");
      Interaction.MsgBox(strText, MsgBoxStyle.Information, "MsgBoxStyle.Information");
      Interaction.MsgBox(strText, MsgBoxStyle.Question, "MsgBoxStyle.Question");
      
      Interaction.MsgBox(strText, MsgBoxStyle.OkCancel, "MsgBoxStyle.OKCancel");
      Interaction.MsgBox(strText, MsgBoxStyle.YesNo | MsgBoxStyle.DefaultButton2, "MsgBoxStyle.YesNo + MsgBoxStyle.DefaultButton2");
      Interaction.MsgBox(strText, MsgBoxStyle.RetryCancel, "MsgBoxStyle.RetryCancel");
      Interaction.MsgBox(strText, MsgBoxStyle.YesNoCancel | MsgBoxStyle.DefaultButton3, "MsgBoxStyle.YesNoCancel + MsgBoxStyle.DefaultButton3");
      Interaction.MsgBox(strText, MsgBoxStyle.AbortRetryIgnore, "MsgBoxStyle.AbortRetryIgnore");
      
      Interaction.MsgBox(strText, MsgBoxStyle.MsgBoxHelp, "MsgBoxStyle.MsgBoxHelp");
      Interaction.MsgBox(strText, MsgBoxStyle.MsgBoxRight, "MsgBoxStyle.MsgBoxRight");
      Interaction.MsgBox(strText, MsgBoxStyle.MsgBoxRtlReading, "MsgBoxStyle.MsgBoxRtlReading");
      Interaction.MsgBox(strText, MsgBoxStyle.MsgBoxSetForeground, "MsgBoxStyle.MsgBoxSetForeground");
      
      Interaction.MsgBox(strText, MsgBoxStyle.ApplicationModal, "MsgBoxStyle.ApplicationModal");
      Interaction.MsgBox(strText, MsgBoxStyle.SystemModal, "MsgBoxStyle.SystemModal");
      MsgBoxCheckResult(Interaction.MsgBox(strText, MsgBoxStyle.YesNo, "Return Result"));
    }
    // MsgBoxTest()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpCompareMessageBoxWithMsgBox

}
// CompareMessageBoxWithMsgBox