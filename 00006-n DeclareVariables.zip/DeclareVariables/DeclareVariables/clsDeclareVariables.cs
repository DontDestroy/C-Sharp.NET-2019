//***
// Action
//   - Declare some variables and show them in the console
// Created
//   - CopyPaste � 20220111 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220111 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace DeclareVariables
{

  class cpDeclareVariables
	{

    static void Main()
    //***
    // Action
    //   - Declare some variables
    //   - Set value to these variables
    //   - Show results at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      double dblEmployeeSalary;
      long lngNumberOfEmployees;
      string strEmployeeName;
      string strEmployeePhoneNumber;

      strEmployeeName = "Vincent Van De Walle";
      strEmployeePhoneNumber = "057-21.25.71";
      dblEmployeeSalary = 45000.0;
      lngNumberOfEmployees = 1;

      Console.WriteLine("Number of employees: " + lngNumberOfEmployees);
      Console.WriteLine("Employee name: " + strEmployeeName);
      Console.WriteLine("Employee phone number: " + strEmployeePhoneNumber);
      Console.WriteLine("Employee salary: " + dblEmployeeSalary);
      Console.ReadLine();
		}
    // Main()

  }
  // cpDeclareVariables

}
// DeclareVariables