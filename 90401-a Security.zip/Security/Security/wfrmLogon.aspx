﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmLogon.aspx.cs" Inherits="CopyPaste.Learning.wfrmLogon" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Logon</title>
</head>
<body>
  <form id="wfrmLogon" method="post" runat="server">
    <asp:Label ID="lblName" Style="z-index: 101; position: absolute; top: 40px; left: 32px" runat="server">Name</asp:Label>
    <asp:Label ID="lblMessage" Style="z-index: 106; position: absolute; top: 152px; left: 128px"
      runat="server"></asp:Label>
    <asp:Button ID="cmdLogon" Style="z-index: 105; position: absolute; top: 152px; left: 32px" runat="server"
      Text="Logon" Width="80px" TabIndex="4"></asp:Button>
    <asp:TextBox ID="txtPassword" Style="z-index: 104; position: absolute; top: 80px; left: 128px"
      runat="server" TabIndex="3"></asp:TextBox>
    <asp:TextBox ID="txtName" Style="z-index: 103; position: absolute; top: 40px; left: 128px" runat="server"
      TabIndex="1"></asp:TextBox>
    <asp:Label ID="lblPassword" Style="z-index: 102; position: absolute; top: 80px; left: 32px"
      runat="server">Password</asp:Label>
  </form>
</body>
</html>
