//***
// Action
//   - Writing messages at the console screen using overloading
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Overloading
{

  class cpOverloading
	{

    static void Main()
    //***
    // Action
    //   - Writing some messages at the console screen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - Line()
    //   - Line(byte)
    //   - Line(byte, char)
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Main menu");
      Line(9);
      Console.WriteLine("1. From cm to inch.");
      Console.WriteLine("2. From inch to cm.");
      Line(19);
      Console.WriteLine();
      Line();
      Console.WriteLine();
      Console.WriteLine("Make your choice:");
      Line(17, '~');
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

    static void Line()
    //***
    // Action
    //   - Writing a full line at the console screen
    //   - Loop from 1 to 79 (bytCounter)
    //     - Write "-" at the console scrren
    //   - Goto new line
    // Called by
    //   - Main()
    // Calls
    //   - Line(byte)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Line(79);      
    }
    // Line()

    static void Line(byte bytNumber)
    //***
    // Action
    //   - Writing some messages at the console screen
    //   - Loop from 1 to 'bytNumber' (bytCounter)
    //     - Write "-" at the console scrren
    //   - Goto new line
    // Called by
    //   - Line()
    //   - Main()
    // Calls
    //   - Line(byte, char)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Line(bytNumber, '-');
    }
    // Line(byte)

    static void Line(byte bytNumber, char chrCharacter)
    //***
    // Action
    //   - Writing some messages at the console screen
    //   - Loop from 1 to 'bytNumber' (bytCounter)
    //     - Write 'chrCharacter' at the console scrren
    //   - Goto new line
    // Called by
    //   - Line(byte)
    //   - Main()
    // Calls
    //   - System.Console.Write(char)
    //   - System.Console.WriteLine()
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      byte bytCounter;

      for (bytCounter = 1; bytCounter <= bytNumber; bytCounter++)
      {
        Console.Write(chrCharacter);
      }
      // bytCounter = bytNumber + 1

      Console.WriteLine();
    }
    // Line(byte, char)

  }
  // cpOverloading

}
// Overloading