//***
// Action
//   - The startup form
// Created
//   - CopyPaste � 20220817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220817 � VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace SingleInstanceApplication
{

  public partial class wpfcpDocumentList : System.Windows.Window
  {

    #region "Constructors / Destructors"

    public wpfcpDocumentList()
    //***
    // Action
    //   - The startup screen
    //   - Show the window names in a list
    // Called by
    //   - cpwpfApplication.OnStartup(System.Windows.StartupEventArgs)
    // Calls
    //   - cpwpfApplication.ObservableCollection<cpDocumentReference> OpenDocuments() (Get)
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();

      lstDocuments.DisplayMemberPath = "Name";
      lstDocuments.ItemsSource = ((cpwpfApplication)Application.Current).OpenDocuments;
    }
    // wpfcpDocumentList()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // wpfcpDocumentList 

}
// SingleInstanceApplication