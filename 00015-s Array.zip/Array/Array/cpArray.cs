//***
// Action
//   - Basic functionalities on arrays
// Created
//   - CopyPaste � 20220216 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220216 � VVDW
// Proposal (To Do)
//   - 
//***

using System;

namespace ArrayExample
{

  class cpArray
	{

    static void Main()
      //***
      // Action
      //   - Define an array of 3 items
      //   - Define a array to copy to (copy)
      //   - Show some info
      //   - Show the content of an array (arrstrName)
      //   - Sort array
      //   - Show the content of an array (arrstrName)
      //   - Reverse array
      //   - Show the content of an array (arrstrName)
      //   - Copy array
      //   - Show the content of an array (arrstrName)
      //   - Make array one bigger
      //   - Show the content of an array (arrstrName)
      //   - Play around with the 2 Id�fix
      //   - Clear the array
      //   - Show the content of an array (arrstrName)
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Array.Clear(Array, int, int)
      //   - Array.Copy(Array, Array, int)
      //   - Array.IndexOf(Array, string)
      //   - Array.LastIndexOf(Array, string)
      //   - Array.Reverse(Array)
      //   - Array.Sort(Array)
      //   - Console.WriteLine()
      //   - Console.WriteLine(string)
      //   - Console.WriteLine(string, int)
      //   - int Array.Length()
      //   - ShowArray(Array)
      //   - string Console.ReadLine()
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string[] arrstrName = new string[] {"Asterix", "Obelix", "Id�fix"};
      string[] arrstrCopy = new string[arrstrName.Length];

      Console.WriteLine("Start situation");
      Console.WriteLine("---------------");
      Console.WriteLine();
      ShowArray(arrstrName);

      Array.Sort(arrstrName);
      Console.WriteLine("After sort:");
      ShowArray(arrstrName);
      
      Array.Reverse(arrstrName);
      Console.WriteLine("After reverse:");
      ShowArray(arrstrName);
      
      Array.Copy(arrstrName, arrstrCopy, arrstrName.Length);
      Console.WriteLine("After copy:");
      ShowArray(arrstrCopy);
      
      arrstrName = new string[4];
      Array.Copy(arrstrCopy, arrstrName, arrstrCopy.Length);
      arrstrName[3] = "Id�fix";
      Console.WriteLine("After expansion:");
      ShowArray(arrstrName);

      Console.WriteLine("First Id�fix: {0}", Array.IndexOf(arrstrName, "Id�fix"));
      Console.WriteLine("Last Id�fix: {0}", Array.LastIndexOf(arrstrName, "Id�fix"));
      Console.WriteLine();
      
      Array.Clear(arrstrName, 0, arrstrName.Length);
      Console.WriteLine("After clear:");
      ShowArray(arrstrName);
      Console.ReadLine();
    }
    // Main()

    static void ShowArray(string[] anArray)
      //***
      // Action
      //   - Show the content of the array
      // Called by
      //   - Main()
      // Calls
      //   - Console.WriteLine()
      //   - Console.WriteLine(string)
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      foreach (string aText in anArray)
      {
        Console.WriteLine(aText);
      }
      // in anArray

      Console.WriteLine();
    }
    // ShowArray(string[])

  }
  // cpArray

}
// ArrayExample