//***
// Action
//   - Implementation of a textbox with regular expression to validate the typed content
// Created
//   - CopyPaste � 20260509 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260509 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpctlRegularExpressionTextBox : TextBox
  {

    #region "Constructors / Destructors"

    public cpctlRegularExpressionTextBox() : base()
      //***
      // Action
      //   - Create new instance of 'cpctlRegularExpressionTextBox'
      // Called by
      //   - User action (Creating an control)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260509 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260509 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
    }
    // cpctlRegularExpressionTextBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    internal ErrorProvider merpError;
    private string mstrRegularExpression;

    #endregion

    #region "Properties"

    public string RegularExpression
    {

      get
        //***
        // Action Get
        //   - Return mstrRegularExpression
        // Called by
        //   - cpctlRegularExpressionTextBox_Validating(System.Object, System.ComponentModel.CancelEventArgs) Handles MyBase.Validating
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260509 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260509 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrRegularExpression;
      }
      // string RegularExpression() (Get)

      set
        //***
        // Action Get
        //   - mstrRegularExpression becomes value
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260509 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260509 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mstrRegularExpression = value;
      }
      // RegularExpression(string) (Set)

    }
    // string RegularExpression()

    #endregion

    #region "Methods"

    #region "Overrides"

    protected override void Dispose(bool blnDisposing)
      //***
      // Action
      //   - Clean up instance of 'cpctlRegularExpressionTextBox'
      // Called by
      //   - User action (Closing the control)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260509 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260509 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      base.Dispose (blnDisposing);
    }
    // Dispose(bool)

    #endregion

    #region "Controls"

    private void cpctlRegularExpressionTextBox_Validated(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Remove the possible error message after validating
      //   - This is done to remove a possible previous error message
      // Called by
      //   - System action (TextBox is validated)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260509 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260509 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      merpError.SetError(this, "");
    }
    // cpctlRegularExpressionTextBox_Validated(System.Object, System.EventArgs) Handles MyBase.Validated

    private void cpctlRegularExpressionTextBox_Validating(System.Object theSender, System.ComponentModel.CancelEventArgs theCancelEventArguments)
      //***
      // Action
      //   - Validates the current content of the text box
      //   - Try to
      //     - If there is some text
      //       - If there is a regular expression
      //         - Create a regular expression based on the givn regular expression property
      //         - If there is a match
      //           - Do nothing
      //         - If not
      //           - Set an error thru an error providor
      //           - Cancel all the next events (so the focus is not lost)
      //           - Select the content of the textbox
      //       - If not
      //         - Do nothing
      //     - If not
      //       - Do nothing
      //   - On possible error
      //     - Cancel all the next events (so the focus is not lost)
      //     - Corresponding error message is written to console (not visible during run)
      // Called by
      //   - System action (TextBox is validating)
      // Calls
      //   - string RegularExpression (Get)
      // Created
      //   - CopyPaste � 20260509 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260509 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Regex theRegularExpression;

      try
      {
 
        if ((Text == null) || (Text == String.Empty))
        {
        }
        else
          // Not Text = null And Text <> String.Empty
        {
          
          if (RegularExpression == null)
          {
          }
          else
            // RegularExpression <> null
          {
            theRegularExpression = new Regex(RegularExpression, RegexOptions.IgnoreCase);
            
            if (theRegularExpression.IsMatch(Text))
            {
            }
            else
              // Not theRegularExpression.IsMatch(Text)
            {
              merpError.SetError(this, "Text does not match expression.");
              theCancelEventArguments.Cancel = true;
              this.Select(0, Text.Length);
            }
            // theRegularExpression.IsMatch(Text)

          }
          // RegularExpression = null

        }
        // Text = null Or Text = String.Empty

      }
      catch (Exception theExpression)
      {
        theCancelEventArguments.Cancel = true;
        Console.WriteLine(theExpression.ToString());
      }
      finally
      {
      }
    
    }
    // cpctlRegularExpressionTextBox_Validating(System.Object, System.ComponentModel.CancelEventArgs) Handles MyBase.Validating

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void InitializeComponent()
      //***
      // Action
      //   - Create a new error providor
      //   - Clear the data member of the error providor
      // Called by
      //   - User action (Creating the control)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260509 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260509 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      this.merpError = new System.Windows.Forms.ErrorProvider();
      this.merpError.DataMember = "";
      this.Validating += new System.ComponentModel.CancelEventHandler(this.cpctlRegularExpressionTextBox_Validating);
      this.Validated += new System.EventHandler(this.cpctlRegularExpressionTextBox_Validated);
    }
		// InitializeComponent()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpctlRegularExpressionTextBox

}
// CopyPaste.Learning