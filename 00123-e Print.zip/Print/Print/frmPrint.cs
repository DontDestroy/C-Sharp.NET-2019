//***
// Action
//   - Show some print properties
// Created
//   - CopyPaste � 20240717 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240717 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPrint: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtText;
    internal System.Windows.Forms.Button cmdPrint;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPrint));
      this.txtText = new System.Windows.Forms.TextBox();
      this.cmdPrint = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(21, 80);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(250, 150);
      this.txtText.TabIndex = 3;
      this.txtText.Text = "";
      // 
      // cmdPrint
      // 
      this.cmdPrint.Location = new System.Drawing.Point(105, 32);
      this.cmdPrint.Name = "cmdPrint";
      this.cmdPrint.TabIndex = 2;
      this.cmdPrint.Text = "Print Info";
      this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
      // 
      // frmPrint
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.txtText);
      this.Controls.Add(this.cmdPrint);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPrint";
      this.Text = "Print";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPrint'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPrint()
      //***
      // Action
      //   - Create instance of 'frmPrint'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPrint()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public PrintDialog mdlgPrint = new PrintDialog();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdPrint_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a print document
      //   - Show the print dialog
      //   - If OK is clicked
      //     - Define a string that a new line
      //     - Append PrinterName, FromPage, ToPage, PrintRange, Copies
      //     - Depending on the angle of the landscape, append "Landscape" or "Portrait"
      //     - Append AllowPrintToFile, AllowSelection, AllowSomePages, PrintToFile, ShowNetwork
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240717 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdlgPrint.Document = new PrintDocument();

      if (mdlgPrint.ShowDialog() == DialogResult.OK)
      {
        string strCrLf = Environment.NewLine;

        txtText.Text = "";
        txtText.AppendText("Printer: " + mdlgPrint.PrinterSettings.PrinterName);
        txtText.AppendText(strCrLf);
        txtText.AppendText("From Page: " + mdlgPrint.PrinterSettings.FromPage);
        txtText.AppendText(strCrLf);
        txtText.AppendText("To Page: " + mdlgPrint.PrinterSettings.ToPage);
        txtText.AppendText(strCrLf);
        txtText.AppendText("Print Range: " + mdlgPrint.PrinterSettings.PrintRange);
        txtText.AppendText(strCrLf);
        txtText.AppendText("Copies: " + mdlgPrint.PrinterSettings.Copies);
        txtText.AppendText(strCrLf);

        if (mdlgPrint.PrinterSettings.LandscapeAngle == 90)
        {
          txtText.AppendText("Landscape");
        }
        else
          // mdlgPrint.PrinterSettings.LandscapeAngle <> 90
        {
          txtText.AppendText("Portrait");
        }
        // mdlgPrint.PrinterSettings.LandscapeAngle = 90

        txtText.AppendText(strCrLf);
        txtText.AppendText("Allow Print to File: " + mdlgPrint.AllowPrintToFile);
        txtText.AppendText(strCrLf);
        txtText.AppendText("AllowSelection: " + mdlgPrint.AllowSelection);
        txtText.AppendText(strCrLf);
        txtText.AppendText("Allow Some Pages: " + mdlgPrint.AllowSomePages);
        txtText.AppendText(strCrLf);
        txtText.AppendText("Print to File: " + mdlgPrint.PrintToFile);
        txtText.AppendText(strCrLf);
        txtText.AppendText("Show Network: " + mdlgPrint.ShowNetwork);
        txtText.AppendText(strCrLf);
      }
      else
        // mdlgPrint.ShowDialog() <> DialogResult.OK
      {
      }
      // mdlgPrint.ShowDialog() = DialogResult.OK
    
    }
    // cmdPrint_Click(System.Object, System.EventArgs) Handles cmdPrint.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPrint
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmPrint()
      // Created
      //   - CopyPaste � 20240717 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240717 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPrint());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPrint

}
// CopyPaste.Learning