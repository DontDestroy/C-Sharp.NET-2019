﻿//***
// Action
//   - Basic connection to SQL Server Database
//   - Basic data command to SQL Server table
// Created
//   - CopyPaste – 20260826 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260826 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmData: System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.ID = "wfrmData";
      this.cnncpClient = new System.Data.SqlClient.SqlConnection();
      this.cnncpClient.ConnectionString = "Data Source=COPYPASTEPOWER\\COPYPASTE; Initial Catalog = cpClient; Integrated Security = True;";
      this.cmmClient = new System.Data.SqlClient.SqlCommand();
      this.cmmClient.CommandText = "SELECT tblClient.* FROM tblClient";
      this.cmmClient.Connection = this.cnncpClient;
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when the page is initialized
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - The connection is defined and initialized
    //   - The command is defined and created
    //   - The connection string is coded
    //   - The command text is coded
    //   - The connection is opened (Make sure that IIS_WPG has access to the database)
    //   - A data reader is setup with the SQL Command of the webform
    //   - Loop thru the records (Make sure that IIS_WPG can read information from the table tblClient
    //     - An item is added to the listbox
    //   - Data reader is closed
    //   - Connection is closed
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - Open the SQL Server Connection
    // Created
    //   - CopyPaste – 20260826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      cnncpClient.Open();

      System.Data.SqlClient.SqlDataReader drdClient = cmmClient.ExecuteReader();

      while (drdClient.Read())
      {
        lstClient.Items.Add(drdClient["strName"].ToString() + " (" + drdClient["lngIdClient"].ToString() + ")");
      }
      // drdClient.Read()

      drdClient.Close();
      cnncpClient.Close();
    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmData

}
// CopyPaste.Learning