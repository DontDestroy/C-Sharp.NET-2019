﻿//***
// Action
//   - A definition of a point (structure)
// Created
//   - CopyPaste – 20260530 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260530 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public struct structPoint
  {

    #region "Constructors / Destructors"

    public structPoint(double dblX, double dblY)
    //***
    // Action
    //   - Basic constructor
    //   - A given X and Y coordinate
    // Called by
    //   - cpProgram.DemoStructContainer()
    //   - cpProgram.Main()
    // Calls
    //   - double X (Get)
    //   - double Y (Get)
    // Created
    //   - CopyPaste – 20260530 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260530 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      X = dblX;
      Y = dblY;
    }
    // structPoint(double, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public double X { get; set; }
    // cpProgram.DemoStructContainer()
    // double structCountainer.Distance()
    // double structCountainer.Distance(structPoint)
    // structPoint(double, double)

    public double Y { get; set; }
    // cpProgram.DemoStructContainer()
    // double structCountainer.Distance()
    // double structCountainer.Distance(structPoint)
    // structPoint(double, double)

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // structPoint

}
// CopyPaste.Learning