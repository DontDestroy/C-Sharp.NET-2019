//***
// Action
//   - Definition of a cpCommissionWorker
// Created
//   - CopyPaste � 20230817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230817 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Company
{

  public class cpCommissionWorker : cpEmployee
  {

    #region "Constructors / Destructors"

    public cpCommissionWorker(string strFirstName, string strLastName, decimal decSalary, decimal decCommission, int lngQuantity) : base(strFirstName, strLastName)
      //***
      // Action
      //   - Set the FirstName to strFirstName
      //   - Set the LastName to strLastName
      //   - Set the Salary to decSalary
      //   - Set the Commission to decCommission
      //   - Set the Quantity to lngQuantity
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - Commission(decimal) (Set)
      //   - cpEmployee(string, string)
      //   - Quantity(int) (Set)
      //   - Salary(decimal) (Set)
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Salary = decSalary;
      Commission = decCommission;
      Quantity = lngQuantity;
    }
    // cpCommissionWorker(string, string, decimal, decimal, int)
  
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private decimal mdecCommission;
    private decimal mdecSalary;
    private int mlngQuantity;

    #endregion

    #region "Properties"

    public decimal Commission
    {

      get
        //***
        // Action
        //   - Return the commission
        // Called by
        //   - decimal Earnings()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecCommission;
      }
      // decimal Commission (Get)

      set
        //***
        // Action
        //   - Set the commission to value
        //   - If commission is negative, 0 becomes the value
        // Called by
        //   - cpCommissionWorker(string, string, decimal, decimal, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value > 0)
        {
          mdecCommission = value;
        }
        else
          // value <= 0
        {
          mdecCommission = 0;
        }
        // value > 0

      }
      // Commission(decimal) (Set)

    }
    // decimal Commission

    public int Quantity
    {

      get
        //***
        // Action
        //   - Return the quantity
        // Called by
        //   - decimal Earnings()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngQuantity;
      }
      // decimal Quantity (Get)

      set
        //***
        // Action
        //   - Set the quantity to value
        //   - If commission is negative, 0 becomes the value
        // Called by
        //   - cpCommissionWorker(string, string, decimal, decimal, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value > 0)
        {
          mlngQuantity = value;
        }
        else
          // value <= 0
        {
          mlngQuantity = 0;
        }
        // value > 0

      }
      // Quantity(int) (Set)

    }
    // int Quantity

    public decimal Salary
    {

      get
        //***
        // Action
        //   - Return the week salary
        // Called by
        //   - decimal Earnings()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecSalary;
      }
      // decimal Salary (Get)

      set
        //***
        // Action
        //   - Set the week salary to value
        //   - If week salary is negative, 0 becomes the value
        // Called by
        //   - cpCommissionWorker(string, string, decimal, decimal, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value > 0)
        {
          mdecSalary = value;
        }
        else
          // value <= 0
        {
          mdecSalary = 0;
        }
        // value > 0

      }
      // Salary(decimal) (Set)

    }
    // decimal Salary

    #endregion

    #region "Methods"

    #region "Overrides"
    
    public override decimal Earnings()
      //***
      // Action
      //   - Calculate and return the earnings
      //   - Calculation is the weekly salary added with the commission multiplied by the quantity
      // Called by
      //   - 
      // Calls
      //   - Commission() As Decimal (Get)
      //   - Quantity() As Int32 (Get)
      //   - Salary() As Decimal (Get)
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Salary + Commission * Quantity;
    }
    // decimal Earnings()

    public override string ToString()
      //***
      // Action
      //   - Return description of a cpCommissionWorker
      // Called by
      //   - 
      // Calls
      //   - string cpEmployee.ToString()
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "cpCommissionWorker: " + base.ToString();
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCommissionWorker

}
// CopyPaste.Learning.Company