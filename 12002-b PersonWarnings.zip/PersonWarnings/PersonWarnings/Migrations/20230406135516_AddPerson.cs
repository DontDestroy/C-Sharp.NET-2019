﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace PersonWarnings.Migrations
{
    public partial class AddPerson : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "cpPersonId",
                table: "cpWarning",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "cpPerson",
                columns: table => new
                {
                    cpPersonId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    strName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_cpPerson", x => x.cpPersonId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_cpWarning_cpPersonId",
                table: "cpWarning",
                column: "cpPersonId");

            migrationBuilder.AddForeignKey(
                name: "FK_cpWarning_cpPerson_cpPersonId",
                table: "cpWarning",
                column: "cpPersonId",
                principalTable: "cpPerson",
                principalColumn: "cpPersonId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_cpWarning_cpPerson_cpPersonId",
                table: "cpWarning");

            migrationBuilder.DropTable(
                name: "cpPerson");

            migrationBuilder.DropIndex(
                name: "IX_cpWarning_cpPersonId",
                table: "cpWarning");

            migrationBuilder.DropColumn(
                name: "cpPersonId",
                table: "cpWarning");
        }
    }
}
