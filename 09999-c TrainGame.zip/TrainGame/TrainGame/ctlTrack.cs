//***
// Action
//   - Implementation of the cpctlTrack
//   - There is a visualisation of a railroadtrack (OnPaint)
//     - 2 horizontal bars
//     - 1 vertical bar (depending on the length of the control)
//       
//     ��   ��
//     ���� ���� (Height is 1/5 of the track height)
//     ��   ��   (Widht is 1/5 of the track height)
//     ���� ���� (Space between vertical bars is 1/5 of the track height) 
//     ��   ��
//
//   - Property FireFrequency is the speed the fire changes of location in seconds
//     - This is used in a timer control on the cpctlTrack
//   - There is an event cpRepositionFire
//     - This signals to the listeners that the fire next to the track is on changed location
//     - The sender is the instance of control itself (cpctlTrack)
//     - The information is given thru with a cpCaughtOnFireEventArguments
//   - There is no length of the track
//     - This is inherited from the custom control (width)
// Created
//   - CopyPaste � 20240228 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240228 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace CopyPaste.Learning.Games
{

  // This attribute makes that doubleclick on the control will add the eventmethod in the code
  [DefaultEventAttribute("cpRepositionFire")]
  public class cpctlTrack : System.Windows.Forms.UserControl
	{

    #region Component Designer generated code
    private System.ComponentModel.IContainer components;
    private System.Windows.Forms.Timer tmrFire;

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.tmrFire = new System.Windows.Forms.Timer(this.components);
      // 
      // tmrFire
      // 
      this.tmrFire.Enabled = true;
      this.tmrFire.Interval = 1000;
      this.tmrFire.Tick += new System.EventHandler(this.tmrFire_Tick);
      // 
      // cpctlTrack
      // 
      this.Name = "cpctlTrack";
      this.Load += new System.EventHandler(this.cpctlTrack_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpctlTrack'
      // Called by
      //   - User action (Closing the control)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpctlTrack()
      //***
      // Action
      //   - Create instance of 'cpctlTrack'
      // Called by
      //   - User action (Starting the control)
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // cpctlTrack()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    // Height of the track (must be divisible by 5)
    private const int mclngTrackHeight = 15;
    // The width of a bar is 1/5 of the height of the track
    private const int mclngBarWidth = mclngTrackHeight / 5;
    // The space between bars is the same width of a bar
    // Spacing between left side of the bars is 2/5 of the height of the track 
    private const int mclngBarSpacing = mclngBarWidth * 2;
    // The declaration of an eventhandler
    public delegate void cpRepositionFireEventHandler(System.Object theSender, cpCaughtOnFireEventArguments thecpCaughtOnFireEventArguments);
    // The frenquency of the change of the fire next to the track is by default 1 second
    private int mlngFireFrequency = 1;

    #endregion

    #region "Properties"

    public int FireFrequency
    {

      get
        //***
        // Action Get
        //   - Returns the frequency of the fire (the change of position in seconds)
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240228 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240228 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mlngFireFrequency;
      }
      // int FireFrequency

      set
        //***
        // Action Set
        //   - If value is smaller than 1
        //     - mlngFireFrequency becomes 0 (position does not change anymore)
        //     - Timer stops
        //   - If Not
        //     - mlngFireFrequency becomes value
        //     - Interval of the timer becomes mlngFireFrequency * 1000 (milliseconds)
        //     - Timer starts
        // Called by
        //   - cpctlTrain_cpDistanceChanged(System.Object, cpDistanceChangedEventArguments) Handles cpctlTrain.cpDistanceChanged
        //   - frmTrainGame.cmdRestart_Click(System.Object, System.EventArgs) Handles cmdRestart.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240228 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240228 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {

        if (value >= 1)
        {
          mlngFireFrequency = value;
          tmrFire.Interval = mlngFireFrequency * 1000;
          tmrFire.Start();
        }
        else
          // value < 1
        {
          mlngFireFrequency = 0;
          tmrFire.Stop();
        }
        // value >= 1

      }
      // FireFrequency(int) (Set)

    }
    // int FireFrequency

    #endregion

    #region "Methods"

    #region "Overrides"

    protected override void OnPaint(System.Windows.Forms.PaintEventArgs thePaintEventArguments)
    {
      base.OnPaint (thePaintEventArguments);

      int lngBarCounter;
      int lngBars = this.Width / mclngBarSpacing;
      int lngHeight = mclngTrackHeight / 5;
      GraphicsPath theGraphicsPath = new GraphicsPath();

      theGraphicsPath.FillMode = FillMode.Winding;
      
      for (lngBarCounter = 0; lngBarCounter <= lngBars - 1; lngBarCounter++)
      {
        Rectangle recFirstHorizontal;
        Rectangle recSecondHorizontal;
        Rectangle recVertical;
      
        recFirstHorizontal = new Rectangle(lngBarCounter * mclngBarSpacing, lngHeight, mclngBarSpacing, lngHeight);
        // X and Y coordinate of the left top position, width and height
        recSecondHorizontal = new Rectangle(lngBarCounter * mclngBarSpacing, lngHeight * 3, mclngBarSpacing, lngHeight);
        // X and Y coordinate of the left top position, width and height
        recVertical = new Rectangle(lngBarCounter * mclngBarSpacing, 0, mclngBarWidth, mclngTrackHeight);
        // X and Y coordinate of the left top position, width and height

        // Draw the rectangles
        theGraphicsPath.AddRectangle(recFirstHorizontal);
        theGraphicsPath.AddRectangle(recSecondHorizontal);
        theGraphicsPath.AddRectangle(recVertical);
      }
      // lngBarCounter = lngBars

      // Fill the rectangles with a brown color
      thePaintEventArguments.Graphics.FillPath(Brushes.SaddleBrown, theGraphicsPath);
    }
    // OnPaint(System.Windows.Forms.PaintEventArgs)

    protected override void OnSizeChanged(System.EventArgs theEventArguments)
      //***
      // Action
      //   - When the size of the control is changed
      //     - The size is adapted to have a nice track with complete bars and space in between
      //     - So the size must be divisible by 2 times the width of a bar
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngBars = this.Width / mclngBarSpacing;

      this.Height = mclngTrackHeight;
      this.Width = lngBars * mclngBarSpacing;
    }
    // OnSizeChanged(System.EventArgs)

    #endregion

    #region "Controls"

    private void cpctlTrack_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Height becomes mclngTrackHeight pixels
      // Called by
      //   - User action (Loading the control)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Height = mclngTrackHeight;
    }
    // cpctlTrack_Load(System.Object theSender, System.EventArgs theEventArguments) Handles this.Load

    private void tmrFire_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - A randomizer is defined
      //   - A random number is taken between 0 (included) and the width of the control (excluded)
      //   - An event is raised (signal is send)
      //     - Sender is the control
      //     - Arguments are the location of the fire
      // Called by
      //   - System action (Tick of a timer)
      // Calls
      //   - cpCaughtOnFireEventArguments(int)
      //   - cpRepositionFire(System.Object, cpCaughtOnFireEventArguments)
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngPosition;
      Random rndNumber = new Random();
      cpCaughtOnFireEventArguments thecpCaughtOnFireEventArguments;

      lngPosition = rndNumber.Next(0, this.Width);
      thecpCaughtOnFireEventArguments = new cpCaughtOnFireEventArguments(lngPosition);
      cpRepositionFire(this, thecpCaughtOnFireEventArguments);
    }
    // tmrFire_Tick(System.Object theSender, System.EventArgs theEventArguments) Handles tmrFire.Tick

    #endregion

    #region "Functionality"

    #region "Event"

    public event cpRepositionFireEventHandler cpRepositionFire;
    // tmrFire_Tick(System.Object, System.EventArgs) Handles tmrFire.Tick

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpctlTrack

}
// CopyPaste.Learning.Games