﻿//***
// Action
//   - Starting up the application will create the database when needed
//     - Do not execute the "update-database" command in "Package Manager Console"
//     - If you do, a wrong database name will be created in the LocalDB SQL Server and seeding will fail
//   - This part is done with a library
//     - The console application, the Windows Form and the WPF Form is using the same library
//   - Create a database based on the class cpInfo using Entity Framework (version 6.4.4)
//   - Data will be seeded into it (but not when you first created the database)
//   - Query the table
// Created
//   - CopyPaste – 20230406 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230406 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FormEntityFrameWork_WPF
{

  public partial class wpfWarnings : Window
  {

    #region "Constructors / Destructors"

    public wpfWarnings()
    //***
    // Action
    //   - Create instance of 'wpfWarnings'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230406 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230406 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfWarnings()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void wndStartup_Initialized(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Show that the application starts in Immediate Window
    //   - Reads all the warnings
    //   - AsNoTracking() says this is a read-only access
    //   - Loop thru all the warnings in Immediate Window
    //   - Show that the application stops in Immediate Window
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20230406 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230406 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Debug.WriteLine("The application starts\n");

      using (cpApplicationDatabaseContext theDatabaseContext = new cpApplicationDatabaseContext())
      {

        foreach (cpWarning theWarning in theDatabaseContext.cpWarning.AsNoTracking())
        {
          Debug.WriteLine($"\n{theWarning.strName}");
          Debug.WriteLine($"  More info: {theWarning.strDescription}");
        }
        // in theDatabaseContext.cpWarning.AsNoTracking()

        dgrWarnings.ItemsSource = theDatabaseContext.cpWarning.ToList();
      }
      // cpApplicationDatabaseContext theDatabaseContext

      Debug.WriteLine("\nThe application stops");
    }
    // wndStartup_Initialized(System.Object theSender, System.EventArgs theEventArguments) Handles wpfWarnings.Initialized

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfWarnings 

}
// FormEntityFrameWork_WPF