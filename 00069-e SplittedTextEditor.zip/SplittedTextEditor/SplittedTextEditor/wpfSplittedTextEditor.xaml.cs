﻿//***
// Action
//   - A simple Text editor with a splitter between the text and the fonts
//   - Type some text
//   - Set Bold and Italic
//   - Choose a font and a size
// Created
//   - CopyPaste – 20230301 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230301 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace SplittedTextEditor
{

  #region "Constructors / Destructors"

  public partial class wpfSplittedTextEditor : Window
  {
    public wpfSplittedTextEditor()
    //***
    // Action
    //   - Create an instance of 'wpfSplittedTextEditor'
    //   - Fill lstFonts with the available fonts (the fonts itself, not the texts)
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230301 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230301 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();

      foreach (FontFamily theFont in Fonts.SystemFontFamilies)
      {
        ListBoxItem theItem = new ListBoxItem();

        theItem.Content = theFont.ToString();
        theItem.FontFamily = theFont;
        lstFonts.Items.Add(theItem);
      }
      // in Fonts.SystemFontFamilies

    }
    // wpfSplittedTextEditor()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdBold_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - The selected text of the rich textbox becomes bold.
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230301 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230301 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      rtxtEditor.Selection.ApplyPropertyValue(FontWeightProperty, FontWeights.Bold);
    }
    // cmdBold_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdBold.Click

    private void cmdItalic_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - The selected text of the rich textbox becomes italic.
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230301 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230301 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      rtxtEditor.Selection.ApplyPropertyValue(FontStyleProperty, FontStyles.Italic);
    }
    // cmdItalic_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdItalic.Click

    private void lstFonts_SelectionChanged(System.Object theSender, System.Windows.Controls.SelectionChangedEventArgs theSelectChangedEventArguments)
    //***
    // Action
    //   - The selected text of the rich textbox becomes the chosen font.
    //   - The listbox items are fonts, they are not texts.
    // Called by
    //   - User action (Selecting an option in a ListBox)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230301 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230301 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      rtxtEditor.Selection.ApplyPropertyValue(FontFamilyProperty, ((ListBoxItem)lstFonts.SelectedItem).FontFamily);
    }
    // cmbFonts_SelectionChanged(System.Object, System.Windows.Controls.SelectionChangedEventArgs) Handles cmbFonts.SelectionChanged

    private void sldSize_ValueChanged(System.Object theSender, RoutedPropertyChangedEventArgs<double> theRoutedPropertyChangedEventArguments)
    //***
    // Action
    //   - The selected text of the rich textbox becomes the size chosen in the slider.
    // Called by
    //   - User action (Changing the value of a slider)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230301 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230301 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      try
      {

        if (rtxtEditor == null)
        {
        }
        else
        // rtxtEditor <> null
        {
          rtxtEditor.Selection.ApplyPropertyValue(FontSizeProperty, sldSize.Value.ToString());
        }
        // rtxtEditor = null

      }
      catch
      {
        Console.WriteLine();
      }

    }
    // sldSize_ValueChanged(System.Object, RoutedPropertyChangedEventArgs<double>) Handles sldSize.ValueChanged

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfSimpleTextEditor

}
// SimpleTextEditor