//***
// Action
//   - Testroutine for cpDemo
// Created
//   - CopyPaste � 20240708 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240708 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Reflection;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create an instance of cpDemo
      //   - Define a method info
      //   - Loop thru all the methods
      //     - Define a parameter info
      //     - Show the method name and the method return type
      //     - If there are parameters
      //       - Loop thru all the parameters
      //         - Show the parameter name and parameter type
      //     - If not
      //       - Nothing happens
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpDemo()
      // Created
      //   - CopyPaste � 20240708 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240708 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpDemo theDemo = new cpDemo();

      Console.WriteLine();
      Console.WriteLine("Methods:");

      foreach (MethodInfo theMethod in theDemo.GetType().GetMethods())
      {
        Console.WriteLine(" - " + theMethod.Name + ": " + theMethod.ReturnType.ToString());

        if (theMethod.GetParameters().Length > 0)
        {
          Console.WriteLine("   Parameter:");
        
          foreach (ParameterInfo theParameterInfo in theMethod.GetParameters())
          {
            Console.WriteLine("    - " + theParameterInfo.Name + ": " + theParameterInfo.ParameterType.ToString());
          }
          // in theMethod.GetParameters()
        
        }
        else
          // theMethod.GetParameters().Length <= 0
        {
        }
        // theMethod.GetParameters().Length > 0

        Console.WriteLine();
      }
      // in theDemo.GetType.GetMethods()

      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning