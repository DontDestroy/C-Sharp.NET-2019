﻿//***
// Action
//   - Implementation of a Roofer
// Created
//   - CopyPaste – 20251104 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251104 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpRoofer : cpCopyPasteRobot, cpinfWorker
	{

    #region "Constructors / Destructors"

    public cpRoofer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpRoofer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpRoofer(int, int, Directions.Direction, int)
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRoofer(int, int, Directions.Direction, int, Color) 

    public cpRoofer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpRoofer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpContractor.BuildHouse()
    // Calls
    //   - cpRoofer(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRoofer(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void BuildRoof()
    //***
    // Action
    //   - Face to the North
    //   - Repeat 5 times
    //     - Put beeper
    //     - Move diagonal right
    //   - Face to the East
    //   - Repeat 6 times
    //     - Put beeper
    //     - Move diagonal right
    // Called by
    //   - GetToWork()
    // Calls
    //   - cpCopyPasteRobot.DiagonalRight()
    //   - cpCopyPasteRobot.FaceEast()
    //   - cpCopyPasteRobot.FaceNorth()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FaceNorth();

      for (int counter = 0; counter < 5; counter++)
      {
        putBeeper();
        DiagonalRight();
      }
      // counter = 5

      FaceEast();

      for (int counter = 0; counter < 6; counter++)
      {
        putBeeper();
        DiagonalRight();
      }
      // counter = 6
    }
    // BuildRoof()

    public void GetToWork()
    //***
    // Action
    //   - Implementation of GetToWork
    //   - Go to the position for the roof
    //   - Build the roof
    //   - Go back to the origin
    // Called by
    //   -
    // Calls
    //   - BuildRoof()
    //   - cpCopyPasteRobot.GoToStartPosition()
    //   - GoToStartRoof()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      GoToStartRoof();
      BuildRoof();
      GoToStartPosition();
    }
    // GetToWork()

    private void GoToStartRoof()
    //***
    // Action
    //   - Face North
    //   - Move four forward
    // Called by
    //   - GetToWork()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FaceNorth();

      for (int counter = 0; counter < 4; counter++)
      {
        move();
      }
      // counter = 4

    }
    // GoToStartRoof()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpRoofer

}
// cpKarelTheRobot