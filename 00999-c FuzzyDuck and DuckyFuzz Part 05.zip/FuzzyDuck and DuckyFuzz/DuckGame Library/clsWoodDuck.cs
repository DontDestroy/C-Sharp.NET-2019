﻿//***
// Action
//   - Implementation of a cpWoodDuck
//     - Inherits from cpDuck, where Display (how do I look like) is an abstract method
//       - All class that inherit from cpDuck must implement the Display method
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
//   - The way a cpWoodDuck moves on water is inherited
//     - All cpDuck and child classes moves on water the same way
//   - The sound that a cpWoodDuck makes is thru an interface
//   - The way a cpWoodDuck moves on land is thru an interface
//   - The way a cpWoodDuck moves in the air is thru an interface
// Created
//   - CopyPaste – 20240718 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240718 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Game.Duck.Library
{

	public class cpWoodDuck : cpDuck, cpiFlyable, cpiQuackable, cpiWalkable
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpWoodDuck
		/// </summary>
		public cpWoodDuck() : base()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - User action (Creating an instance)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpWoodDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		#region "Overrides"

		/// <summary>
		/// The visualization (displaying) of a cpWoodDuck
		/// </summary>
		public override void Display()
		//***
		// Action
		//   - Define how a cpWoodDuck looks like
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Representation of a cpWoodDuck");
		}
		// Display()

		#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how the cpWoodDuck moves in the air
		/// </summary>
		public void Fly()
		//***
		// Action
		//   - Define how the cpWoodDuck if flying
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("cpWoodDuck is moving around in the air");
		}
		// Fly()

		/// <summary>
		/// What noise is the cpWoodDuck making 
		/// </summary>
		public void Quack()
		//***
		// Action
		//   - Define the noise that the cpWoodDuck makes
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Represent the sound of a cpWoodDuck");
		}
		// Quack()

		/// <summary>
		/// How is a cpWoodDuck moving on land
		/// </summary>
		public void Walk()
		//***
		// Action
		//   - Define how the cpWoodDuck moves on land
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240718 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240718 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("cpWoodDuck is moving around on land");
		}
		// Walk()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpWoodDuck

}
// CopyPaste.Game.Duck.Library