//***
// Action
//   - Sorting an array
// Created
//   - CopyPaste � 20220214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220214 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace SortArray
{

  class cpSortArray
	{

    static void Main()
      //***
      // Action
      //   - Fill an array with 5 numbers
      //   - Show the content of the array
      //   - Sort the array
      //   - Show the content of the array
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Array.Sort(Array)
      //   - Console.WriteLine()
      //   - Console.WriteLine(string)
      //   - int Array.GetUpperBound(int)
      //   - int Console.Read() 
      //   - string Microsoft.VisualBasic.InputBox(string, string)
      // Created
      //   - CopyPaste � 20220214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220214 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int intInteger;
      int[] arrInteger = new int[] {9, 8, 12, 4, 5};
      
      Console.WriteLine("Not Sorted:");
      
      for (intInteger = 0 ; intInteger <= arrInteger.GetUpperBound(0); intInteger++)
      {
        Console.WriteLine(arrInteger[intInteger]);
      }
      // intInteger = arrInteger.GetUpperBound(0) + 1
      
      Array.Sort(arrInteger);
      Console.WriteLine();
      Console.WriteLine("Sorted:");
      
      for (intInteger = 0 ; intInteger <= arrInteger.GetUpperBound(0); intInteger++)
      {
        Console.WriteLine(arrInteger[intInteger]);
      }
      // intInteger = arrInteger.GetUpperBound(0) + 1
      
      Console.Read();
    }
    // Main()

  }
  // SortArray

}
// cpSortArray