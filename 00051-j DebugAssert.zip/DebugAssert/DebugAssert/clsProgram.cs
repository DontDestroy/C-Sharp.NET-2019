//***
// Action
//   - Demo of Debug.Assert
// Created
//   - CopyPaste � 20240508 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240508 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Diagnostics;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Testroutine for Debug.Assert
      //   - Test if strWriter is nothing
      //     - It is the case, nothing happens
      //   - Test if temp directory does not exist
      //     - A message is shown
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      StreamWriter strWriter = null;
      // StreamWriter strWriter = new StreamWriter("C:\\Stream.txt");

      Debug.Assert(strWriter == null, "strWriter is Not Nothing");
      Debug.Assert(Directory.Exists("\\Temp"), "\\Temp does not exist");

      Console.Write("Press Enter to continue...");
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning