﻿//***
// Action
//   - Interface for the behaviour (method) SendMessage
// Created
//   - CopyPaste – 20241227 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20241227 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.MorseCode.Library;

namespace CopyPaste.MorseCode.Library
{

	public interface cpiMessageMorse
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		///  Define how a list of signal items is send
		/// </summary>
		/// <param name="lstMessage"></param>
		/// <returns>A list of cpSignalItem</returns>
		public void SendMessage(List<cpSignalItem> lstMessage);
		// SendMessage(List<cpSignalItem>)

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpiMessageMorse

}
// CopyPaste.MorseCode.Library