﻿//***
// Action
//   - Implementation of Interface cpiValidationRestriction to validate a textbox on letters and digits
// Created
//   - CopyPaste – 20250718 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250718 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpValidationRestrictionAlphaNumeric: cpiValidationRestriction
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public bool Validate(cpctlValidationTextbox theSender, System.Windows.Forms.KeyPressEventArgs theKeyPressEventArgs )
      //***
      // Action
      //   - Test of a character typed is a letter or a digit
      //   - If correct
      //     - Return True
      //   - If not
      //     - Return False
      // Called by
      //   - cpctlValidationTextbox.OnKeyPress(KeyPressEventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250718 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250718 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Char.IsLetterOrDigit(theKeyPressEventArgs.KeyChar);
    }
    // Validate(cpctlValidationTextbox, System.Windows.Forms.KeyPressEventArgs) As Boolean Implements cpiValidationRestriction.Validate

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpValidationRestrictionAlphaNumeric

}
// CopyPaste.Learning