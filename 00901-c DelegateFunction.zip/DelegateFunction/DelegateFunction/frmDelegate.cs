//***
// Action
//   - Execute a sort routine decided from outside the class cpSort using delegates
// Created
//   - CopyPaste � 20250712 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250712 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Learning;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDelegate: System.Windows.Forms.Form
  {
    internal System.Windows.Forms.Button cmdDelegate;

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDelegate));
      this.cmdDelegate = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdDelegate
      // 
      this.cmdDelegate.Location = new System.Drawing.Point(24, 16);
      this.cmdDelegate.Name = "cmdDelegate";
      this.cmdDelegate.Size = new System.Drawing.Size(128, 32);
      this.cmdDelegate.TabIndex = 1;
      this.cmdDelegate.Text = "Use Delegate";
      this.cmdDelegate.Click += new System.EventHandler(this.cmdDelegate_Click);
      // 
      // frmDelegate
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdDelegate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDelegate";
      this.Text = "Delegate a Function Pointer";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDelegate'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDelegate()
      //***
      // Action
      //   - Create instance of 'frmDelegate'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDelegate()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdDelegate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define an array of integer (subject to sort)
      //   - Define a counter
      //   - Create an instance of cpSort
      //   - Sort the array using one of the possible sortroutines (Ascending)
      //   - Show the result in the debug window
      //   - Sort the array using one of the possible sortroutines (Descending)
      //   - Show the result in the debug window
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool cpSort.CompareFunctionAscending(int, int)
      //   - bool cpSort.CompareFunctionDescending(int, int)
      //   - cpSort()
      //   - cpSort.KindOfBubbleSort(CompareFunction, int[])
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpSort thecpSort = new cpSort();
      cpSort.CompareFunction theCompareFunction;
      int lngCounter;
      int lngCounterTill;
      int[] arrInteger = new Int32[] {6, 2, 4, 9, 1, 5, 0, 8};
    
      lngCounterTill = arrInteger.GetUpperBound(0);
      theCompareFunction = new cpSort.CompareFunction(thecpSort.CompareFunctionAscending);
      thecpSort.KindOfBubbleSort(theCompareFunction, arrInteger);

      for (lngCounter = 0; lngCounter <= lngCounterTill; lngCounter++)
      {
        Debug.WriteLine(arrInteger[lngCounter].ToString());
      }
      // lngCounter = lngCounterTill + 1

      Debug.WriteLine("");
      theCompareFunction = new cpSort.CompareFunction(thecpSort.CompareFunctionDescending);
      thecpSort.KindOfBubbleSort(theCompareFunction, arrInteger);

      for (lngCounter = 0; lngCounter <= lngCounterTill; lngCounter++)
      {
        Debug.WriteLine(arrInteger[lngCounter].ToString());
      }
      // lngCounter = lngCounterTill + 1

    }
    // cmdDelegate_Click(System.Object, System.EventArgs) Handles cmdDelegate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDelegate
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDelegate()
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDelegate());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDelegate

}
// CopyPaste.Learning