﻿//***
// Action
//   - Working with an array of variable length
//   - There is an error in the application
//     - Can you find it?
// Created
//   - CopyPaste – 20220823 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220823 – VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ArrayDynamic_WPF
{

  public partial class wpfArrayDynamic : Window
  {

    //region "Constructors / Destructors"

    public wpfArrayDynamic()
    //***
    // Action
    //   - Create instance of 'wpfArrayDynamic'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfArrayDynamic()

    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    decimal[] marrdecTemperatures;
    short mshtDays;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdInput_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Ask a number, for how many days
    //   - Ask for every day the average temperature
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - decimal Convert.ToDecimal(string) 
    //   - int Array.GetUpperBound(int)
    //   - int Convert.ToInt32(string)
    //   - string Microsoft.VisualBasic.Interaction.InputBox(string, string, string, int , int)
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      long lngCounter;
      string strCaption;
      string strMessage;

      mshtDays = Convert.ToInt16(Interaction.InputBox("How many days?", "Make array", "", -1, -1));

      if (mshtDays > 0)
      {
        marrdecTemperatures = new decimal[mshtDays];
        strMessage = "What was the average temperature?";

        for (lngCounter = 0; lngCounter <= marrdecTemperatures.GetUpperBound(0); lngCounter++)
        {
          strCaption = "Day " + (lngCounter + 1);
          marrdecTemperatures[lngCounter] = Convert.ToDecimal(Interaction.InputBox(strMessage, strCaption, "", -1, -1));
        }
        // lngCounter = marrdecTemperatures.GetUpperBound(0) + 1

      }
      else
      // mshtDays <= 0
      {
      }
      // mshtDays > 0

    }
    // cmdInput_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdInput.Click

    private void cmdOutput_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Show the average temperatures of the days
    //   - Calculate the average
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - int Array.GetUpperBound(int)
    //   - Environment.NewLine
    // Created
    //   - CopyPaste – 20220823 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220823 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //  -
    //***
    {
      decimal decTotal = 0;
      long lngCounter;
      string strResult;

      strResult = "Average temperatures:" + Environment.NewLine + Environment.NewLine;

      try
      {
        for (lngCounter = 0; lngCounter <= marrdecTemperatures.GetUpperBound(0); lngCounter++)
        {
          strResult += "Day " + (lngCounter + 1) + "\t" + marrdecTemperatures[lngCounter] + Environment.NewLine;
          decTotal += marrdecTemperatures[lngCounter];
        }
        // lngCounter = marrdecTemperatures.GetUpperBound(0) + 1

        strResult += Environment.NewLine + "Average temperature:  " + (decTotal / mshtDays).ToString("0.00");
      }

      catch (Exception theException)
      {
      }
      finally
      {
        txtResult.Text = strResult;
      }

    }
    // cmdOutput_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdOutput.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#Region "Not used"
    //#endregion

  }
  // cpDefault

}
// ArrayDynamic_WPF