﻿// VVDW - Automatically generated code by pasting the XML file to this location
// VVDW - I've added also the correct namespace

namespace CopyPaste.Learning
{

  // NOTE: Generated code may require at least .NET Framework 4.5 or .NET Core/Standard 2.0.
  /// <remarks/>
  [System.SerializableAttribute()]
  [System.ComponentModel.DesignerCategoryAttribute("code")]
  [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
  [System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
  public partial class Restaurant
  {

    private RestaurantFood[] foodField;

    /// <remarks/>
    [System.Xml.Serialization.XmlElementAttribute("Food")]
    public RestaurantFood[] Food
    {
      get
      {
        return this.foodField;
      }
      set
      {
        this.foodField = value;
      }
    }
  }

  /// <remarks/>
  [System.SerializableAttribute()]
  [System.ComponentModel.DesignerCategoryAttribute("code")]
  [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
  public partial class RestaurantFood
  {

    private string nameField;

    private decimal priceField;

    private string descriptionField;

    private ushort caloriesField;

    /// <remarks/>
    public string Name
    {
      get
      {
        return this.nameField;
      }
      set
      {
        this.nameField = value;
      }
    }

    /// <remarks/>
    public decimal Price
    {
      get
      {
        return this.priceField;
      }
      set
      {
        this.priceField = value;
      }
    }

    /// <remarks/>
    public string Description
    {
      get
      {
        return this.descriptionField;
      }
      set
      {
        this.descriptionField = value;
      }
    }

    /// <remarks/>
    public ushort Calories
    {
      get
      {
        return this.caloriesField;
      }
      set
      {
        this.caloriesField = value;
      }
    }
  }
}