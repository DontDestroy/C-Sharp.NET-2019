//***
// Action
//   - Implemenation of cpBook
// Created
//   - CopyPaste � 20240704 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240704 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpBook
  {

    #region "Constructors / Destructors"

    public cpBook(string strTitle, string strAuthor, double dblPrice)
      //***
      // Action
      //   - Create an instance of cpBook with Title, Author and Price
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrTitle = strTitle;
      mstrAuthor = strAuthor;
      mdblPrice = dblPrice;
    }
    // cpBook(string, string, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public double mdblPrice;
    public string mstrAuthor;
    public string mstrTitle;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ShowBook()
      //***
      // Action
      //   - Show the information of the book
      // Called by
      //   - 
      // Calls
      //   - ShowTitle()
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      ShowTitle();
      Console.WriteLine("Author: " + mstrAuthor);
      Console.WriteLine("Price: " + mdblPrice);
    }
    // ShowTitle()

    public void ShowTitle()
      //***
      // Action
      //   - Show the title of the book
      // Called by
      //   - ShowBook()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Title: " + mstrTitle);
    }
    // ShowTitle()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBook

}
// CopyPaste.Learning