//***
// Action
//   - Demo the Opacity (being transparent) of a form
// Created
//   - CopyPaste � 20240227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240227 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTransparent: System.Windows.Forms.Form
  {
    internal System.Windows.Forms.Timer tmrStartup;
    internal System.Windows.Forms.Button cmdNotTransparent;
    internal System.Windows.Forms.Button cmdTransparent;
    private System.ComponentModel.IContainer components;

    #region Windows Form Designer generated code


    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTransparent));
      this.tmrStartup = new System.Windows.Forms.Timer(this.components);
      this.cmdNotTransparent = new System.Windows.Forms.Button();
      this.cmdTransparent = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // tmrStartup
      // 
      this.tmrStartup.Enabled = true;
      this.tmrStartup.Interval = 50;
      this.tmrStartup.Tick += new System.EventHandler(this.tmrStartup_Tick);
      // 
      // cmdNotTransparent
      // 
      this.cmdNotTransparent.Enabled = false;
      this.cmdNotTransparent.Location = new System.Drawing.Point(24, 88);
      this.cmdNotTransparent.Name = "cmdNotTransparent";
      this.cmdNotTransparent.Size = new System.Drawing.Size(104, 40);
      this.cmdNotTransparent.TabIndex = 3;
      this.cmdNotTransparent.Text = "&Repair form";
      this.cmdNotTransparent.Click += new System.EventHandler(this.cmdNotTransparent_Click);
      // 
      // cmdTransparent
      // 
      this.cmdTransparent.Enabled = false;
      this.cmdTransparent.Location = new System.Drawing.Point(24, 32);
      this.cmdTransparent.Name = "cmdTransparent";
      this.cmdTransparent.Size = new System.Drawing.Size(104, 40);
      this.cmdTransparent.TabIndex = 2;
      this.cmdTransparent.Text = "&Make invisible";
      this.cmdTransparent.Click += new System.EventHandler(this.cmdTransparent_Click);
      // 
      // frmTransparent
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdTransparent);
      this.Controls.Add(this.cmdNotTransparent);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTransparent";
      this.Opacity = 0;
      this.Text = "Transparent form";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTransparent'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTransparent()
      //***
      // Action
      //   - Create instance of 'frmTransparent'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTransparent()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdNotTransparent_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The form becomes not transparent anymore
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Opacity = 1;
    }
    // cmdNotTransparent_Click(System.Object, System.EventArgs) Handles cmdNotTransparent.Click

    private void cmdTransparent_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The form becomes 50% transparent
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Opacity = 0.5;
    }
    // cmdTransparent_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdTransparent.Click

    private void tmrStartup_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If transparent
      //     - Add 1% to the Opacity property
      //     - Stop the timer
      //   - If Not
      //     - Enable the 2 buttons
      //     - Stop the timer
      // Called by
      //   - System action (tick of a timer)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (this.Opacity == 1)
      {
        cmdNotTransparent.Enabled = true;
        cmdTransparent.Enabled = true;
        tmrStartup.Enabled = false;
      }
      else
      {
        this.Opacity += 0.01;
      }
      // this.Opacity = 1

    }
    // tmrStartup_Tick(System.Object, System.EventArgs) Handles tmrStartup.Tick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTransparent
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTransparent());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTransparent

}
// CopyPaste.Learning