//***
// Action
//   - Implementation of an abstract cpEmployee
// Created
//   - CopyPaste � 20240405 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240405 � VVDW
// Proposal (To Do)
//   - There is an exercise where you can add a property that must be inherited
//   - There is an exercise where you can give a cpDirector another class to inherit from
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public abstract class cpEmployee
  {

    #region "Constructors / Destructors"

    public cpEmployee(string strName)
      //***
      // Action
      //   - Constructor with Name
      // Called by
      //   - cpHandWorker(string)
      //   - cpOfficeWorker(string)
      // Calls
      //   - Name(string) (Set)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Name = strName;
    }
    // cpEmployee(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrName;

    #endregion

    #region "Properties"

    // public abstract decimal Extra
    // {
    //   get;
    //   set;
    // }

    public string Name
    {

      get
        //***
        // Action Get
        //   - Returns mstrName
        // Called by
        //   - cpDirector.ShowInfo()
        //   - cpHandWorker.ShowInfo()
        //   - cpOfficeWorker.ShowInfo()
        //   - cpManager.ShowInfo()
        //   - ShowInfo()
        //   - string cpDirector.ToString()
        //   - string cpHandWorker.ToString()
        //   - string cpOfficeWorker.ToString()
        //   - string cpManager.ToString()
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

      set
        //***
        // Action Set
        //   - mstrName becomes value
        // Called by
        //   - cpEmployee(string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Returns the Name and that the person is an employee
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - string Name (Get)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Name + " is an employee.";
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public virtual void ShowInfo()
      //***
      // Action
      //   - Shows information to the console
      //     - Employee + Name
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - string Name (Get)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Employee - Name: {0}", Name);
    }
    // ShowInfo()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpEmployee

}
// CopyPaste.Learning.Employee