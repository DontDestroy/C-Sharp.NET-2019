//***
// Action
//   - Demo of some code on System.IO
//   - WinCV tool is used to get documentation
// Created
//   - CopyPaste � 20260130 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260130 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTryoutWinCVTool: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdReadDirectoryInfo;
    internal System.Windows.Forms.Button cmdDirectoryInfo;
    internal System.Windows.Forms.Button cmdCreateWithFileInfo;
    internal System.Windows.Forms.Button cmdInfo;
    internal System.Windows.Forms.Button cmdCopyText;
    internal System.Windows.Forms.Button cmdOpenText;
    internal System.Windows.Forms.Button cmdCreateText;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTryoutWinCVTool));
      this.cmdReadDirectoryInfo = new System.Windows.Forms.Button();
      this.cmdDirectoryInfo = new System.Windows.Forms.Button();
      this.cmdCreateWithFileInfo = new System.Windows.Forms.Button();
      this.cmdInfo = new System.Windows.Forms.Button();
      this.cmdCopyText = new System.Windows.Forms.Button();
      this.cmdOpenText = new System.Windows.Forms.Button();
      this.cmdCreateText = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdReadDirectoryInfo
      // 
      this.cmdReadDirectoryInfo.Location = new System.Drawing.Point(18, 328);
      this.cmdReadDirectoryInfo.Name = "cmdReadDirectoryInfo";
      this.cmdReadDirectoryInfo.Size = new System.Drawing.Size(256, 32);
      this.cmdReadDirectoryInfo.TabIndex = 13;
      this.cmdReadDirectoryInfo.Text = "&Read Directory Info";
      this.cmdReadDirectoryInfo.Click += new System.EventHandler(this.cmdReadDirectoryInfo_Click);
      // 
      // cmdDirectoryInfo
      // 
      this.cmdDirectoryInfo.Location = new System.Drawing.Point(18, 288);
      this.cmdDirectoryInfo.Name = "cmdDirectoryInfo";
      this.cmdDirectoryInfo.Size = new System.Drawing.Size(256, 32);
      this.cmdDirectoryInfo.TabIndex = 12;
      this.cmdDirectoryInfo.Text = "&Directory Info";
      this.cmdDirectoryInfo.Click += new System.EventHandler(this.cmdDirectoryInfo_Click);
      // 
      // cmdCreateWithFileInfo
      // 
      this.cmdCreateWithFileInfo.Location = new System.Drawing.Point(18, 224);
      this.cmdCreateWithFileInfo.Name = "cmdCreateWithFileInfo";
      this.cmdCreateWithFileInfo.Size = new System.Drawing.Size(256, 32);
      this.cmdCreateWithFileInfo.TabIndex = 11;
      this.cmdCreateWithFileInfo.Text = "&Create T:\\TextInfo.txt with FileInfo";
      this.cmdCreateWithFileInfo.Click += new System.EventHandler(this.cmdCreateWithFileInfo_Click);
      // 
      // cmdInfo
      // 
      this.cmdInfo.Location = new System.Drawing.Point(18, 184);
      this.cmdInfo.Name = "cmdInfo";
      this.cmdInfo.Size = new System.Drawing.Size(256, 32);
      this.cmdInfo.TabIndex = 10;
      this.cmdInfo.Text = "&Info of T:\\TextCopy.txt";
      this.cmdInfo.Click += new System.EventHandler(this.cmdInfo_Click);
      // 
      // cmdCopyText
      // 
      this.cmdCopyText.Location = new System.Drawing.Point(18, 120);
      this.cmdCopyText.Name = "cmdCopyText";
      this.cmdCopyText.Size = new System.Drawing.Size(256, 32);
      this.cmdCopyText.TabIndex = 9;
      this.cmdCopyText.Text = "C&opy T:\\Text.txt to T:\\TextCopy.txt";
      this.cmdCopyText.Click += new System.EventHandler(this.cmdCopyText_Click);
      // 
      // cmdOpenText
      // 
      this.cmdOpenText.Location = new System.Drawing.Point(18, 72);
      this.cmdOpenText.Name = "cmdOpenText";
      this.cmdOpenText.Size = new System.Drawing.Size(256, 32);
      this.cmdOpenText.TabIndex = 8;
      this.cmdOpenText.Text = "&Open T:\\Text.txt";
      this.cmdOpenText.Click += new System.EventHandler(this.cmdOpenText_Click);
      // 
      // cmdCreateText
      // 
      this.cmdCreateText.Location = new System.Drawing.Point(18, 24);
      this.cmdCreateText.Name = "cmdCreateText";
      this.cmdCreateText.Size = new System.Drawing.Size(256, 32);
      this.cmdCreateText.TabIndex = 7;
      this.cmdCreateText.Text = "&Create T:\\Text.txt";
      this.cmdCreateText.Click += new System.EventHandler(this.cmdCreateText_Click);
      // 
      // frmTryoutWinCVTool
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 397);
      this.Controls.Add(this.cmdReadDirectoryInfo);
      this.Controls.Add(this.cmdDirectoryInfo);
      this.Controls.Add(this.cmdCreateWithFileInfo);
      this.Controls.Add(this.cmdInfo);
      this.Controls.Add(this.cmdCopyText);
      this.Controls.Add(this.cmdOpenText);
      this.Controls.Add(this.cmdCreateText);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTryoutWinCVTool";
      this.Text = "Tryout WinCV Tool";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTryoutWinCVTool'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTryoutWinCVTool()
      //***
      // Action
      //   - Create instance of 'frmTryoutWinCVTool'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTryoutWinCVTool()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    
    private void cmdCopyText_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Copy a text file
      //   - Check if the copy was successful
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strFileName = @"T:\Text.txt";
      string strFileNameCopy = @"T:\TextCopy.txt";

      File.Copy(strFileName, strFileNameCopy, true);

      if (File.Exists(strFileNameCopy))
      {
        MessageBox.Show("Copy was successful", "Copy Paste Tryout");
      }
      else
        // Not File.Exists(strFileNameCopy)
      {
        MessageBox.Show("Copy was unsuccessful", "Copy Paste Tryout");
      }
      // File.Exists(strFileNameCopy)
    
    }
    // cmdCopyText_Click(System.Object, System.EventArgs) Handles cmdCopyText.Click

    private void cmdCreateText_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and initialize a filename
      //   - Define a streamwriter based on the file name (text will be appended)
      //   - Write 2 lines of text to the file
      //   - Flush the file (make sure you don't forget info)
      //   - Close the file
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strFileName = @"T:\Text.txt";
      StreamWriter theStreamWriter = File.AppendText(strFileName);

      theStreamWriter.WriteLine("This is the first line of our file.");
      theStreamWriter.WriteLine("The second line of important information.");
      theStreamWriter.Flush();
      theStreamWriter.Close();
    }
    // cmdCreateText_Click(System.Object, System.EventArgs) Handles cmdCreateText.Click

    private void cmdCreateWithFileInfo_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and initialize a filename
      //   - Define and initialize file info about the filename
      //   - Define a streamwriter based on the file info (text will be appended)
      //   - Write 1 line of text to the file
      //   - Flush the file (make sure you don't forget info)
      //   - Close the file
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strFileName = @"T:\TextInfo.txt";
      FileInfo theFileInfo = new FileInfo(strFileName);
      StreamWriter theStreamWriter = theFileInfo.AppendText();

      theStreamWriter.WriteLine("Using the FileInfo Class");
      theStreamWriter.Flush();
      theStreamWriter.Close();
    }
    // cmdCreateWithFileInfo_Click(System.Object, System.EventArgs) Handles cmdCreateWithFileInfo.Click

    private void cmdDirectoryInfo_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and initialize a filename
      //   - Define and initialize file information
      //   - Define and initialize directory info about the filename
      //   - Define and initialize the attributes of that directory info
      //   - Generate the file information text
      //     - File name
      //     - Is the file a normal file
      //     - Is the file archived
      //     - Is the file hidden
      //     - Is the file a directory
      //   - Show the file information text
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strFileName = @"T:\Text.txt";
      string strFileInformation = "";
      DirectoryInfo theDirectoryInfo = new DirectoryInfo(strFileName);
      FileAttributes theFileAttributes = theDirectoryInfo.Attributes;

      strFileInformation += "File Name: " + strFileName + Environment.NewLine;

      if (theFileAttributes == FileAttributes.Normal)
      {
        strFileInformation += "The file is normal" + Environment.NewLine;
      }
      else
        // theFileAttributes <> FileAttributes.Normal
      {
      }
      // theFileAttributes = FileAttributes.Normal

      if (theFileAttributes == FileAttributes.Archive)
      {
        strFileInformation += "The file is archived" + Environment.NewLine;
      }
      else
        // theFileAttributes <> FileAttributes.Archive
      {
        strFileInformation += "The file is not archived" + Environment.NewLine;
      }
      // theFileAttributes = FileAttributes.Archive

      if (theFileAttributes == FileAttributes.Hidden)
      {
        strFileInformation += "The file is hidden" + Environment.NewLine;
      }
      else
        // theFileAttributes <> FileAttributes.Hidden
      {
        strFileInformation += "The file is not hidden" + Environment.NewLine;
      }
      // theFileAttributes = FileAttributes.Hidden

      if (theFileAttributes == FileAttributes.Directory)
      {
        strFileInformation += "The entry is a directory" + Environment.NewLine;
      }
      else
        // theFileAttributes <> FileAttributes.Directory
      {
        strFileInformation += "The entry is a file" + Environment.NewLine;
      }
      // theFileAttributes = FileAttributes.Directory

      MessageBox.Show(strFileInformation, "Copy Paste Tryout", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // cmdDirectoryInfo_Click(System.Object, System.EventArgs) Handles cmdDirectoryInfo.Click

    private void cmdInfo_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and initialize a filename
      //   - Define and initialize file info about the filename
      //   - If file exists
      //     - Generate information about the file
      //     - Show the information in a messagebox
      //   - If not
      //     - Show that the file does not exists
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strFileData = "";
      string strFileNameCopy = @"T:\TextCopy.txt";
      FileInfo theFileInfo = new FileInfo(strFileNameCopy);
    
      if (theFileInfo.Exists)
      {
        strFileData += "Creation time: " + theFileInfo.CreationTime.ToShortTimeString() + Environment.NewLine;
        strFileData += "File directory: " + theFileInfo.Directory.ToString() + Environment.NewLine;
        strFileData += "Full name: " + theFileInfo.FullName + Environment.NewLine;
        strFileData += "File size (bytes): " + theFileInfo.Length.ToString() + Environment.NewLine;
        MessageBox.Show(strFileData, "Copy Paste Tryout");
      }
      else
        // Not theFileInfo.Exists
      {
        MessageBox.Show("TextCopy.txt does not exist !", "Copy Paste Tryout");
      }
      // theFileInfo.Exists

    }
    // cmdInfo_Click(System.Object, System.EventArgs) Handles cmdInfo.Click

    private void cmdOpenText_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and initialize a filename
      //   - Define a streamreader based on the file name (text will be appended)
      //   - Read the file till the end and store the info in a string
      //   - Close the file
      //   - Show a messagebox with the content of the file
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strFileContent;
      string strFileName = @"T:\Text.txt";
      StreamReader theStreamReader = File.OpenText(strFileName);

      strFileContent = theStreamReader.ReadToEnd();
      theStreamReader.Close();

      MessageBox.Show(strFileContent, "Copy Paste Tryout");
    }
    // cmdOpenText_Click(System.Object, System.EventArgs) Handles cmdOpenText.Click

    private void cmdReadDirectoryInfo_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and initialize a message
      //   - Define and initialize directory info about the current location
      //   - Define file info
      //   - Loop thru all the files in the directory
      //     - Get full name
      //     - Get length (size)
      //     - Get creation time
      //     - Add info to the message
      //   - Show the message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strMessage = "";
      DirectoryInfo theDirectory = new DirectoryInfo(".");

      foreach (FileInfo theFileInfo in theDirectory.GetFiles("*.*"))
      {
        string strFileName = theFileInfo.FullName;
        string strFileSize = theFileInfo.Length.ToString();
        DateTime strCreationTime = theFileInfo.CreationTime;

        strMessage += strFileSize + "\t" + strCreationTime + "\t" + strFileName + Environment.NewLine;
      }
      // in theDirectory.GetFiles("*.*")

      MessageBox.Show(strMessage, "Copy Paste Tryout", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // cmdReadDirectoryInfo_Click(System.Object, System.EventArgs) Handles cmdReadDirectoryInfo.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTryoutWinCVTool
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDefault()
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTryoutWinCVTool());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTryoutWinCVTool

}
// CopyPaste.Learning