﻿//***
// Action
//   - Location for managing Product object
// Created
//   - CopyPaste – 20210819 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210819 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//   - Later will it be only executed when databinding is used for that component
//***

using System.Data;
using System.Data.SqlClient;

namespace WPFDataReader.cpclsManager
{

  public class cpProductManager
  {
 
    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    public const string mcstrProductSQL = "SELECT intIdProduct, strProductName, dtmIntroduction, strUrl, decPrice, dtmRetire, intProductCategoryId FROM tblCPProduct";
    public const string mcstrProductCategorySQL = "SELECT intIdProductCategory, strCategoryName FROM tblCPProductCategory";
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public DataTable GetProductsAsDataTableTest()
    //***
    // Action
    //   - Style exercise to compare
    //   - Define a Data Table to store the result
    //   - Create SQL Connection object (cnnSQL) based on application settings inside a nested using block
    //   - Open Connection
    //   - Create SQL Command object (cmdSQL) inside a nested using block
    //   - Create SQL Data Adapter (dtaSQL) inside a nested using block
    //   - Define a new Data Table
    //   - Fill Data Table with Data from Data Adapter
    //   - Return Data Table
    // Called by
    //   - 
    // Calls
    //   - string cpApplicationSetting.ConnectionString (Get)
    // Created
    //   - CopyPaste – 20210819 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //    - List of actions that can be added to the functionality
    //***
    {
      DataTable dtReturn = null;

      using (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))
      {
        cnnSQL.Open();

        using (SqlCommand CommandObject = new SqlCommand(mcstrProductSQL, cnnSQL))
        {

          using (SqlDataAdapter dtaSQL = new SqlDataAdapter(CommandObject))
          {
            dtReturn = new DataTable();
            dtaSQL.Fill(dtReturn);
          }
          // (SqlDataAdapter dtaSQL = new SqlDataAdapter(CommandObject))

        }
        // (SqlCommand CommandObject = new SqlCommand(mcstrProductSQL, cnnSQL))

      }
      // (SqlConnection cnnSQL = new SqlConnection(cpApplicationSetting.ConnectionString))

      return dtReturn;
    }
    // DataTable GetProductsAsDataTable()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProductManager

}
// WPFDataReader.cpclsManager