//***
// Action
//   - Defining a variable array
// Created
//   - CopyPaste � 20220216 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220216 � VVDW
// Proposal (To Do)
//   - Leap years are not taken into account
//***

using System;

namespace VariableArray
{

  class cpVariableArray
	{

    static void Main()
      //***
      // Action
      //   - Asking a number of bankaccounts
      //   - For every number of bankaccounts
      //     - Ask the accountnumber
      //   - Show them on the console
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Console.Write(string)
      //   - Console.Write(string, int)
      //   - Console.WriteLine()
      //   - Console.WriteLine(string)
      //   - int Convert.ToInt32(string)
      //   - string Console.ReadLine()
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int intCounter;
      int intNumberOfBankAccounts;

      Console.Write("Enter number of bankaccounts: ");
      intNumberOfBankAccounts = Convert.ToInt32(Console.ReadLine());

      int[] arrintBankAccount = new int[intNumberOfBankAccounts];
      
      for (intCounter = 0; intCounter < intNumberOfBankAccounts; intCounter++)
      {
        Console.Write("Number of {0}� bankaccount: ", intCounter + 1);
        arrintBankAccount[intCounter] = Convert.ToInt32(Console.ReadLine());
      }
      // lngCounter = lngNumberOfBankAccounts
      
      Console.WriteLine();
      Console.WriteLine("You have following bankaccounts:");

      foreach (int aBankAccount in arrintBankAccount)
      {
        Console.WriteLine(aBankAccount);
      }
      //' in arrlngBankAccount
      
      Console.ReadLine();
    }
    // Main()

  }
  // cpVariableArray

}
// VariableArray