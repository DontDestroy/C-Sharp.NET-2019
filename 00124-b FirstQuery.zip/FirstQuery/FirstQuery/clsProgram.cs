//***
// Action
//   - Show some info about data types
//   - Late binding (Polymorphism is used
// Created
//   - CopyPaste � 20070403 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20070403 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Show information about the data types
      //     - Boolean
      //     - Byte
      //     - DateTime
      //     - Double
      //     - Int32
      //     - Integer
      //     - Short
      //     - String
      // Called by
      //   - 
      // Calls
      //   - ShowTypeInfo(string, System.Object)
      // Created
      //   - CopyPaste � 20070403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnValue = true;
      byte bytValue = 0;
      double dblValue = 0.0D;
      DateTime dtmValue = new DateTime(DateTime.Now.Ticks);
      int intValue = 0;
      long lngValue = 0; 
      short shtValue = 0;
      string strValue = "Hello, world";

      Console.WriteLine("Type Codes:");
      ShowTypeInfo("bool: ", blnValue.GetTypeCode(), blnValue);
      ShowTypeInfo("byte: ", bytValue.GetTypeCode(), bytValue);
      ShowTypeInfo("double: ", dblValue.GetTypeCode(), dblValue);
      ShowTypeInfo("DateTime: ", dtmValue.GetTypeCode(), dtmValue);
      ShowTypeInfo("int: ", intValue.GetTypeCode(), intValue);
      ShowTypeInfo("long: ", lngValue.GetTypeCode(), lngValue);
      ShowTypeInfo("short: ", shtValue.GetTypeCode(), shtValue);
      ShowTypeInfo("string: ", strValue.GetTypeCode(), strValue);
      Console.ReadLine();
    }
		// Main()

    private static void ShowTypeInfo(string strText, System.TypeCode theTypeCode, System.Object theObject)
      //***
      // Action
      //   - Show detailed information about the given paramter
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20070403 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070403 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine(strText + theTypeCode + " - " +
          theObject.GetType().Name + " - " +
          theObject.GetType().UnderlyingSystemType.ToString());
   }
    // ShowTypeInfo(string, System.Object)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning