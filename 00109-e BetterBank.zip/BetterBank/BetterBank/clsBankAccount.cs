//***
// Action
//   - Implementation of cpBankAccount
// Created
//   - CopyPaste � 20240227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240227 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public abstract class cpBankAccount
  {

    #region "Constructors / Destructors"

    public cpBankAccount()
      //***
      // Action
      //   - Empty constructor of a cpBankAccount
      // Called by
      //   - cpCheckingAccount(string)
      //   - cpSavingsAccount(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpBankAccount(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private decimal mdecBalance = 0M;
    private decimal mdecTotalDeposits = 0M;
    private decimal mdecTotalWithDrawals = 0M;

    #endregion

    #region "Properties"

    public decimal Balance
    {

      get
        //***
        // Action Get
        //   - Returns the balance of a cpBankAccount
        // Called by
        //   - decimal cpCheckingAccount.Withdraw(decimal) 
        //   - decimal cpSavingsAccount.AddInterest
        //   - decimal Deposit(decimal)
        //   - decimal Withdraw(decimal)
        //   - string cpCheckingAccount.PrintStatement()
        //   - string cpSavingsAccount.PrintStatement()
        //   - frmBetterBank.cmdAddInterest_Click(System.Object, System.EventArgs) Handles cmdAddInterest.Click
        //   - frmBetterBank.cmdSubmit_Click(System.Object, System.EventArgs) Handles cmdSubmit.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240227 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240227 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecBalance;
      }
      // decimal Balance (Get)

    }
    // decimal Balance

    public abstract string Id
    {

      get;
      //   - frmBetterBank.cmdSubmit_Click(System.Object, System.EventArgs) Handles cmdSubmit.Click
    
    }
    // string Id

    public decimal TotalDeposits
    {

      get
        //***
        // Action Get
        //   - Returns the total of deposits of a cpBankAccount
        // Called by
        //   - string cpCheckingAccount.PrintStatement()
        //   - string cpSavingsAccount.PrintStatement()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240227 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240227 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecTotalDeposits;
      }
      // decimal TotalDeposits (Get)

    }
    // decimal TotalDeposits

    public decimal TotalWithDrawals
    {

      get
        //***
        // Action Get
        //   - Returns the total of withDrawals of a cpBankAccount
        // Called by
        //   - string cpCheckingAccount.PrintStatement()
        //   - string cpSavingsAccount.PrintStatement()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240227 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240227 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecTotalWithDrawals;
      }
      // decimal TotalWithDrawals (Get)

    }
    // decimal TotalWithDrawals

    #endregion

    #region "Methods"

    #region "Overrides"

    public abstract string PrintStatement();
    // frmBetterBank.cmdPrint_Click(System.Object, System.EventArgs) Handles cmdPrint.Click

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public decimal Deposit(decimal decAmount)
      //***
      // Action
      //   - A certain amount (decAmount) is added to the balance of the cpBankAccount
      //   - The same amount is added to total deposits
      //   - The actual balance is returned
      // Called by
      //   - decimal cpSavingsAccount.AddInterest()
      //   - frmBetterBank.cmdSubmit_Click(System.Object, System.EventArgs) Handles cmdSubmit.Click
      // Calls
      //   - decimal Balance (Get)
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mdecBalance += decAmount;
      mdecTotalDeposits += decAmount;
      return Balance;
    }
    // decimal Deposit(decimal)
		
    public virtual decimal Withdraw(decimal decAmount)
      //***
      // Action
      //   - A certain amount (decAmount) is removed from the balance of the cpBankAccount
      //   - The same amount is added to total withdrawals
      //   - The actual balance is returned
      // Called by
      //   - decimal cpCheckingAccount.WithDraw(decimal)
      //   - frmBetterBank.cmdSubmit_Click(System.Object, System.EventArgs) Handles cmdSubmit.Click
      // Calls
      //   - decimal Balance (Get)
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mdecBalance -= decAmount;
      mdecTotalWithDrawals += decAmount;
      return Balance;
    }
    // decimal Withdraw(decimal)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBankAccount

}
// CopyPaste.Learning