//***
// Action
//   - Demo of some string actions
// Created
//   - CopyPaste � 20240414 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240414 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define an array
      //   - Define the alphabet
      //   - Define a text with separator "/"
      //   - Use Chars, Compare, Concat, EndsWith, IndexOf, Length, PadLeft, Split, StartsWith, Substring, ToUpper
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240414 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240414 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string[] arrstrSplit;
      string strAlphabet = "abcdefghijklmnopqrstuvwxyz";
      string strText = ".NET/VB/C#/ASP.NET/ADO.NET";

      Console.WriteLine("String: " + strAlphabet);
      Console.WriteLine("Char at 5 is: '" + strAlphabet[5] + "'");
      Console.WriteLine("Length: " + strAlphabet.Length);
      Console.WriteLine("Compare 'ABC' & 'abc': " + String.Compare("ABC", "abc"));

      Console.WriteLine("'Hello' + 'world!' produces: '" + String.Concat("Hello ", "world!") + "'");
      Console.WriteLine("Index of 'efg': " + strAlphabet.IndexOf("efg"));
      Console.WriteLine("'" + strAlphabet + "' ends with 'efg' " + " " + strAlphabet.EndsWith("efg"));

      Console.WriteLine("'" + strAlphabet + "' starts with 'abc' " + " " + strAlphabet.StartsWith("abc"));
      Console.WriteLine("Padding with 5 A's: " + strAlphabet.PadLeft(31, 'A'));

      Console.WriteLine(strAlphabet.ToUpper());
      Console.WriteLine("Get 'efg' substring: " + strAlphabet.Substring(4, 3));
      
      Console.WriteLine("Going to split: '" + strText + "'");
      arrstrSplit = strText.Split('/');

      foreach (string strPart in arrstrSplit)
      {
        Console.WriteLine(strPart);
      }
      // In arrstrSplit

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning