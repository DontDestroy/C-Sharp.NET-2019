//***
// Action
//   - Create a point and click query tool for users using a Windows Form
//   - Select an item from a list of tables
//   - Select an item from a list of fields
//   - Show the information in a data grid
// Created
//   - CopyPaste � 20251211 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251211 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPointAndClickQueryTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblData;
    internal System.Windows.Forms.DataGrid dgrData;
    internal System.Windows.Forms.Label lblSQLString;
    internal System.Windows.Forms.Label lblColumn;
    internal System.Windows.Forms.Label lblTable;
    internal System.Windows.Forms.ListBox lstColumn;
    internal System.Windows.Forms.ListBox lstTable;
    internal System.Windows.Forms.TextBox txtSQLString;
    internal System.Windows.Forms.Button cmdView;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPointAndClickQueryTryout));
      this.lblData = new System.Windows.Forms.Label();
      this.dgrData = new System.Windows.Forms.DataGrid();
      this.lblSQLString = new System.Windows.Forms.Label();
      this.lblColumn = new System.Windows.Forms.Label();
      this.lblTable = new System.Windows.Forms.Label();
      this.lstColumn = new System.Windows.Forms.ListBox();
      this.lstTable = new System.Windows.Forms.ListBox();
      this.txtSQLString = new System.Windows.Forms.TextBox();
      this.cmdView = new System.Windows.Forms.Button();
      ((System.ComponentModel.ISupportInitialize)(this.dgrData)).BeginInit();
      this.SuspendLayout();
      // 
      // lblData
      // 
      this.lblData.Location = new System.Drawing.Point(16, 186);
      this.lblData.Name = "lblData";
      this.lblData.Size = new System.Drawing.Size(72, 16);
      this.lblData.TabIndex = 16;
      this.lblData.Text = "Data Display";
      // 
      // dgrData
      // 
      this.dgrData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrData.DataMember = "";
      this.dgrData.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrData.Location = new System.Drawing.Point(8, 210);
      this.dgrData.Name = "dgrData";
      this.dgrData.Size = new System.Drawing.Size(568, 128);
      this.dgrData.TabIndex = 17;
      // 
      // lblSQLString
      // 
      this.lblSQLString.Location = new System.Drawing.Point(312, 18);
      this.lblSQLString.Name = "lblSQLString";
      this.lblSQLString.Size = new System.Drawing.Size(96, 16);
      this.lblSQLString.TabIndex = 13;
      this.lblSQLString.Text = "SQL String";
      // 
      // lblColumn
      // 
      this.lblColumn.Location = new System.Drawing.Point(184, 10);
      this.lblColumn.Name = "lblColumn";
      this.lblColumn.Size = new System.Drawing.Size(96, 16);
      this.lblColumn.TabIndex = 11;
      this.lblColumn.Text = "Columns";
      // 
      // lblTable
      // 
      this.lblTable.Location = new System.Drawing.Point(8, 10);
      this.lblTable.Name = "lblTable";
      this.lblTable.Size = new System.Drawing.Size(96, 16);
      this.lblTable.TabIndex = 9;
      this.lblTable.Text = "Tables";
      // 
      // lstColumn
      // 
      this.lstColumn.Location = new System.Drawing.Point(184, 26);
      this.lstColumn.Name = "lstColumn";
      this.lstColumn.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
      this.lstColumn.Size = new System.Drawing.Size(120, 147);
      this.lstColumn.TabIndex = 12;
      this.lstColumn.SelectedIndexChanged += new System.EventHandler(this.lstColumn_SelectedIndexChanged);
      // 
      // lstTable
      // 
      this.lstTable.Location = new System.Drawing.Point(8, 26);
      this.lstTable.Name = "lstTable";
      this.lstTable.Size = new System.Drawing.Size(168, 147);
      this.lstTable.TabIndex = 10;
      this.lstTable.SelectedIndexChanged += new System.EventHandler(this.lstTable_SelectedIndexChanged);
      // 
      // txtSQLString
      // 
      this.txtSQLString.Location = new System.Drawing.Point(312, 45);
      this.txtSQLString.Multiline = true;
      this.txtSQLString.Name = "txtSQLString";
      this.txtSQLString.Size = new System.Drawing.Size(264, 128);
      this.txtSQLString.TabIndex = 14;
      this.txtSQLString.Text = "";
      // 
      // cmdView
      // 
      this.cmdView.Location = new System.Drawing.Point(480, 10);
      this.cmdView.Name = "cmdView";
      this.cmdView.Size = new System.Drawing.Size(96, 24);
      this.cmdView.TabIndex = 15;
      this.cmdView.Text = "&View";
      this.cmdView.Click += new System.EventHandler(this.cmdView_Click);
      // 
      // frmPointAndClickQueryTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(584, 349);
      this.Controls.Add(this.lblData);
      this.Controls.Add(this.dgrData);
      this.Controls.Add(this.lblSQLString);
      this.Controls.Add(this.lblColumn);
      this.Controls.Add(this.lblTable);
      this.Controls.Add(this.lstColumn);
      this.Controls.Add(this.lstTable);
      this.Controls.Add(this.txtSQLString);
      this.Controls.Add(this.cmdView);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPointAndClickQueryTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Create a Point and Click Query Tool For Users Using a Windows Form Tryout";
      this.Load += new System.EventHandler(this.frmPointAndClickQuery_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrData)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPointAndClickQueryTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPointAndClickQueryTryout()
      //***
      // Action
      //   - Create instance of 'frmPointAndClickQuery'
      // Called by
      //   - frmMainTryout.cmdPointAndClickQuery_Click(System.Object, System.EventArgs) Handles cmdPointAndClickQuery.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPointAndClickQueryTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdView_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a data adapter
      //   - Define and create a data table
      //   - Try to
      //     - Create a data adapter using the SQL statement and the connection
      //     - Fill the data table using the data adapter
      //     - The data table becomes the data source of the data grid
      //   - On error
      //     - Show exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdView_Click(System.Object, System.EventArgs) Handles cmdView.Click

    private void frmPointAndClickQuery_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a command
      //   - Define a data reader
      //   - Try to
      //     - Get the connection
      //     - Create a command that gets the list of tables from the database (Stored procedure "sp_Tables" in SQL Server), using the connection
      //     - Set the command to a stored procedure
      //     - Open the connection
      //     - Execute the command into the data reader
      //     - Loop thru the records
      //       - If the record defines a table
      //         - Filter out some not used tables
      //           - Add the table name to the list
      //       - If not
      //         - Do nothing
      //   - On error
      //     - Show the exception message
      //   - Close the connection
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - cpGeneralRoutines()
      //   - SqlConnection cpGeneralRoutines.GetConnection()
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmPointAndClickQuery_Load(System.Object, System.EventArgs) Handles this.Load

    private void lstColumn_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define two strings
      //   - Loop thru the selected columns (you can select more than one)
      //     - Generate a list of selected fields
      //   - If there is a field selected 
      //     - Create a SQL statement with the selected fields from the selected table
      //   - If not
      //     - Do nothing
      //   - Show the SQL statement
      // Called by
      //   - User action (Selecting an item from a list box)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // lstColumn_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstColumn.SelectedIndexChanged

    private void lstTable_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - When you select a table, show a list of the fields of that table
      //   - Define a command
      //   - Define a data reader
      //   - Try to
      //     - Create a command that gets the list of fields from the selected table (Stored procedure "sp_Columns" in SQL Server), using the connection
      //     - Set the command to a stored procedure
      //     - Add a parameter (the selected table)
      //     - Open the connection
      //     - Execute the command into the data reader
      //     - Loop thru the records
      //       - Add the field name to the list
      //   - On error
      //     - Show the exception message
      //   - Close the connection
      // Called by
      //   - User action (Selecting an item from a list box)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251211 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251211 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // lstTable_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstTable.SelectedIndexChanged

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPointAndClickQueryTryout

}
// CopyPaste.Learning