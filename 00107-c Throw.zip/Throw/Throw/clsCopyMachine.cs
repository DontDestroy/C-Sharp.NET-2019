//***
// Action
//   -  Definition of cpCopyMachine
// Created
//   - CopyPaste � 20230821 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230821 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Company
{

  namespace Material
  {

    public class cpCopyMachine
    {

      #region "Constructors / Destructors"

      public cpCopyMachine()
        //***
        // Action
        //   - Empty constructor of cpCopyMachine
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230821 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230821 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
      }
      // cpCopyMachine()

      #endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      #region "Fields"

      private decimal mdecPageCost;
      private int mlngNumberOfPages;

      #endregion

      #region "Properties"

      public decimal PageCost
      {

        get
          //***
          // Action Get
          //   - Return the cost of a page of a cpCopyMachine
          // Called by
          //   - 
          // Calls
          //   - 
          // Created
          //   - CopyPaste � 20230821 � VVDW
          // Changed
          //   - CopyPaste � yyyymmdd � VVDW � What changed
          // Tested
          //   - CopyPaste � 20230821 � VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {
          return mdecPageCost;
        }
        // decimal PageCost (Get)

        set
          //***
          // Action Set
          //   - If value larger than zero
          //     - The cost of a page of a cpCopyMachine becomes value
          //   - If Not
          //     - Throw error
          // Called by
          //   - cpProgram.Main()
          // Calls
          //   - 
          // Created
          //   - CopyPaste � 20230821 � VVDW
          // Changed
          //   - CopyPaste � yyyymmdd � VVDW � What changed
          // Tested
          //   - CopyPaste � 20230821 � VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {

          if (value > 0)
          {
            mdecPageCost = value;
          }
          else
            // value <= 0
          {
            throw new Exception("Cost per page must be larger than 0.");
          }
          // value > 0

        }
        // PageCost(decimal) (Set)

      }
      // decimal PageCost

      public int NumberOfPages
      {

        get
          //***
          // Action Get
          //   - Return the number of pages of a cpCopyMachine
          // Called by
          //   - 
          // Calls
          //   - 
          // Created
          //   - CopyPaste � 20230821 � VVDW
          // Changed
          //   - CopyPaste � yyyymmdd � VVDW � What changed
          // Tested
          //   - CopyPaste � 20230821 � VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {
          return mlngNumberOfPages;
        }
        // int NumberOfPages (Get)

        set
          //***
          // Action Set
          //   - If value larger or equal than zero
          //     - The number of pages of a cpCopyMachine becomes value
          //   - If Not
          //     - Throw error
          // Called by
          //   - cpProgram.Main()
          // Calls
          //   - 
          // Created
          //   - CopyPaste � 20230821 � VVDW
          // Changed
          //   - CopyPaste � yyyymmdd � VVDW � What changed
          // Tested
          //   - CopyPaste � 20230821 � VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {

          if (value >= 0)
          {
            mlngNumberOfPages = value;
          }
          else
            // value < 0
          {
            throw new Exception("Number of pages can't be negative.");
          }
          // value >= 0

        }
        // NumberOfPages(int) (Set)

      }
      // int NumberOfPages

      #endregion

      //#region "Methods"

      //#region "Overrides"
      //#endregion

      //#region "Controls"
      //#endregion

      //#region "Functionality"

      //#region "Event"
      //#endregion

      //#region "Sub / Function"
      //#endregion

      //#endregion

      //#endregion

      //#region "Not used"
      //#endregion

    }
    // cpCopyMachine

  }
  // Material

}
// Company
