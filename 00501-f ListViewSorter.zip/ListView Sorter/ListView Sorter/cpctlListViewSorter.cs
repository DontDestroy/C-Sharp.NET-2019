//***
// Action
//   - Define how items in a list are sorted, taking into account a data type
// Created
//   - CopyPaste � 20250722 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250722 � VVDW
// Proposal (To Do)
//   - Pay attention here, the comparing is here using data types (so alphabetically or numeric)
//***

using System;
using System.Collections;
using System.Windows.Forms;

namespace CopyPaste.Learning.UserInterface
{

  public class cpctlListViewSorter: IComparer
  {

    #region "Constructors / Destructors"

    public cpctlListViewSorter()
      //***
      // Action
      //   - Empty constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250722 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpctlListViewSorter()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private ListView mListView;
    private int mlngSortColumn = 0;
    private Type mtypSort = Type.GetType("System.String"); 

    #endregion

    #region "Properties"

    public ListView List
    {

      get
        //***
        // Action Get
        //   - Returns mListView
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250722 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250722 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mListView;
      }
      // ListView List (Get)

      set
        //***
        // Action Set
        //   - mListView becomes lsvValue
        //   - ListViewItemSorter becomes the current object
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250722 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250722 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mListView = value;
        mListView.ListViewItemSorter = this;
      }
      // List(ListView) (Set)

    }
    // ListView List

    public int SortColumn
    {

      get
        //***
        // Action Get
        //   - Returns mlngSortColumn
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250722 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250722 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mlngSortColumn;
      }
      // int SortColumn (Get)

      set
        //***
        // Action Set
        //   - If value is positive or zero
        //     - If value is smaller than the number of columns in the listview
        //       - blnError becomes False
        //     - If not
        //       - blnError becomes True
        //   - If not
        //     - blnError becomes True
        //   - If there is an error
        //     - Throw an argument out of range exception
        //   - If not
        //     - mlngSortColumn becomes value
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250722 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250722 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        bool blnError;

        if (value >= 0)
        {

          if (value < mListView.Columns.Count)
          {
            blnError = false;
          }
            // value >= mListView.Columns.Count
          else
          {
            blnError = true;
          }
          // value < mListView.Columns.Count

        }
        else
          // value < 0
        {
          blnError = true;
        }
        // value >= 0

        if (blnError)
        {
          throw new ArgumentOutOfRangeException();
        }
        else
          // Not blnError
        {
          mlngSortColumn = value;
        }
        // blnError

      }
      // SortColumn(int) (Set)

    }
    // int SortColumn

    public Type SortType
    {

      get
        //***
        // Action Get
        //   - Returns mtypSort
        // Called by
        //   - int Compare(System.Object, System.Object) Implements IComparer.Compare
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250722 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250722 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mtypSort;
      }
      // Type SortType (Get)

      set
        //***
        // Action Set
        //   - mtypSort becomes typValue
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250722 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250722 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mtypSort = value;
      }
      // SortType(Type) (Set)

    }
    // Type SortType

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int Compare(System.Object objX, System.Object objY)
      //***
      // Action
      //   - Two list view items are defined (to compare them)
      //   - Two objects are defined (to compare them, the starting point)
      //   - If objX is a list view item
      //     - lsvItem1 becomes objX in the correct data type
      //     - If objY is a list view item
      //       - lsvItem2 becomes objY in the correct data type
      //       - Try to
      //         - Create an instance of the mtypSort type
      //         - Convert the text of the first list view item into that type
      //         - Create an instance of the mtypSort type
      //         - Convert the text of the second list view item into that type
      //       - On error (missing method exception)
      //         - Create a new array of characters of the text fo the first list view item
      //         - Create a new array of characters of the text fo the second list view item
      //       - On other error
      //         - Decision that the items are in order
      //       - blnError becomes False
      //       - Depending on the compared values
      //         - In order, intReturnValue becomes -1
      //         - Not in order, intReturnValue becomes 1
      //         - Equal, intReturnValue becomes 0
      //     - If not
      //       - blnError becomes true
      //   - If not
      //     - blnError becomes true
      //   - If there was an error
      //     - Throw an argument exception 
      //   - If not
      //     - Return intReturnValue
      // Called by
      //   - 
      // Calls
      //   - Type SortType (Get)
      // Created
      //   - CopyPaste � 20250722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250722 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnError = false;
      int intReturnValue = 0;
      ListViewItem lsvItem1;
      ListViewItem lsvItem2;
      System.Object obj1 = null;
      System.Object obj2 = null;

      if (objX is ListViewItem)
      {
        lsvItem1 = (ListViewItem)objX;

        if (objY is ListViewItem)
        {
          lsvItem2 = (ListViewItem)objY;
        
          try
          {
            // Will work for date and number, but not for string
            obj1 = Activator.CreateInstance(SortType);
            obj1 = Convert.ChangeType(lsvItem1.SubItems[mlngSortColumn].Text, SortType);
            obj2 = Activator.CreateInstance(SortType);
            obj2 = Convert.ChangeType(lsvItem2.SubItems[mlngSortColumn].Text, SortType);
          }
          catch (MissingMethodException theMissingMethodException)
          {  // The fallback scenario for string
            obj1 = new String(lsvItem1.SubItems[mlngSortColumn].Text.ToCharArray());
            obj2 = new String(lsvItem2.SubItems[mlngSortColumn].Text.ToCharArray());
          }
          catch (Exception theException)
          {
            intReturnValue = -1;
          }
          finally
          {
            blnError = false;
          }
        
          if (obj1 is string)
          {
            string string1 = obj1.ToString();
            string string2 = obj2.ToString();

            intReturnValue = string1.CompareTo(string2);
          }
          else if (obj1 is int)
            // Not (obj1 is string)
          {
            int int1 = (int)obj1;
            int int2 = (int)obj2;

            intReturnValue = int1.CompareTo(int2);
          }
          else if (obj1 is DateTime)
            // Not (obj1 is int)
          {
            DateTime dtm1 = (DateTime)obj1;
            DateTime dtm2 = (DateTime)obj2;

            intReturnValue = dtm1.CompareTo(dtm2);
          }
          else
            // Not (obj1 is DateTime)
          {
            blnError = true;
          }
          // (obj1 is string)
          // (obj1 is int)
          // (obj1 is DateTime)

        }        
        else
          // Not (objY is ListViewItem)
        {
          blnError = true;
        }
        // objY is ListViewItem

      }
      else
        // Not (objX is ListViewItem)
      {
        blnError = true;
      }
      // objX Is ListViewItem

      if (blnError)
      {
        throw new ArgumentException();
      }
      else
        // Not blnError 
      {
        return intReturnValue;
      }
      // blnError 

    }
    // int Compare(System.Object, System.Object) Implements IComparer.Compare

    #endregion
    #endregion

    #endregion

    //#region "Not used"
    //#endregion
  }
  // cpctlListViewSorter

}
// CopyPaste.Learning.UserInterface