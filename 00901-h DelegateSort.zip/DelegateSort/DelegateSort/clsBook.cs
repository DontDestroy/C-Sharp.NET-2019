﻿//***
// Action
//   - Define a cpBook
//     - A publisher, a title, an author and a price
// Created
//   - CopyPaste – 20250715 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250715 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpBook
  {

    #region "Constructors / Destructors"

    public cpBook(string strTitle, string strPublisher, string strAuthor, double dblPrice)
      //***
      // Action
      //   - Define a new book with a given title, publisher, author and price
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250715 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250715 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrPublisher = strPublisher;
      mstrTitle = strTitle;
      mstrAuthor = strAuthor;
      mdblPrice = dblPrice;
    }
    // cpBook(string, string, string, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public double mdblPrice;
    public string mstrAuthor;
    public string mstrPublisher;
    public string mstrTitle;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
		//#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpBook

}
// CopyPaste.Learning