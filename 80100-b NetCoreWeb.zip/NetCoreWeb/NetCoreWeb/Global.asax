﻿<%@ Application Codebehind="Global.asax.cs" Inherits="NetCoreWeb.MvcApplication" Language="C#" %>
