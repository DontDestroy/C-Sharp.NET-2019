﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmSeattleDowntown.aspx.cs" Inherits="CopyPaste.Learning.wfrmSeattleDowntown" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>myPod: iPod</title>
  <style type="text/css">
    body {
      background-color: #eaf3da;
    }
  </style>
</head>
<body>
  <form id="wfrmSeattleDowntown" runat="server">
    <h1>iPod Downtown</h1>
    <p>
      <img src="../Resources/Seattle_Downtown.jpg" alt="An iPod downtown in Seattle" />
    </p>
  </form>
</body>
</html>
