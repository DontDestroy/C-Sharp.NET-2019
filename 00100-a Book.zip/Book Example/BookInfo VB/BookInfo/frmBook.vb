'***
' Action
'   - Demo of cpBook
' Created
'   - CopyPaste � 20220224 � VVDW
' Changed
'   - CopyPaste � yyyymmdd � VVDW � What changed
' Tested
'   - CopyPaste � 20220224 � VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On 

Imports CopyPaste.Learning

Public Class frmBook
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "
  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmBook))
    '
    'frmBook
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(292, 273)
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Name = "frmBook"
    Me.Text = "Book test"

  End Sub

#End Region

#Region "Constructors / Destructors"

  Protected Overloads Overrides Sub Dispose(ByVal blnDisposing As Boolean)
    '***
    ' Action
    '   - Clean up instance of 'frmBook'
    ' Called by
    '   - User action (Closing the form)
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20220224 � VVDW
    ' Changed
    '   - CopyPaste � yyyymmdd � VVDW � What changed
    ' Tested
    '   - CopyPaste � 20220224 � VVDW
    ' Keyboard key
    '   -
    ' Proposal (To Do)
    '   -
    '***

    If blnDisposing Then

      If components Is Nothing Then
      Else
        ' Not components Is Nothing
        components.Dispose()
      End If
      ' components Is Nothing

    Else
      ' Not blnDisposing
    End If
    ' blnDisposing

    MyBase.Dispose(blnDisposing)
  End Sub
  ' Dispose(Boolean)

  Public Sub New()
    '***
    ' Action
    '   - Create new instance of 'frmBook'
    ' Called by
    '   - User action (Starting the form)
    ' Calls
    '   - InitializeComponent()
    ' Created
    '   - CopyPaste � 20220224 � VVDW
    ' Changed
    '   - CopyPaste � yyyymmdd � VVDW � What changed
    ' Tested
    '   - CopyPaste � 20220224 � VVDW
    ' Keyboard key
    '   -
    ' Proposal (To Do)
    '   -
    '***

    MyBase.New()
    InitializeComponent()
  End Sub
  ' New()

#End Region

  '#Region "Designer"
  '#End Region

  '#Region "Structures"
  '#End Region

  '#Region "Fields"
  '#End Region

  '#Region "Properties"
  '#End Region

#Region "Methods"

  '#Region "Overrides"
  '#End Region

#Region "Controls"

  Private Sub frmBook_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Load
    '***
    ' Action
    '   - Create a cpBook with 4 parameters
    '   - Show the information of that book
    ' Called by
    '   - User action (Loading the form)
    ' Calls
    '   - cpBook.New(String, String, String, Double)
    '   - cpBook.ShowBook()
    ' Created
    '   - CopyPaste � 20220224 � VVDW
    ' Changed
    '   - CopyPaste � yyyymmdd � VVDW � What changed
    ' Tested
    '   - CopyPaste � 20220224 � VVDW
    ' Keyboard key
    '   -
    ' Proposal (To Do)
    '   -
    '***

    Dim thecpBook As New cpBook("C# .Net Programming Tips & Techniques", "Jamsa", "McGraw-Hill/Osborne", 49.99)

    thecpBook.ShowBook()
    Me.Close()
  End Sub
  ' frmBook_Load(System.Object, System.EventArgs) Handles MyBase.Load

#End Region

  '#Region "Functionality"

  '#Region "Event"
  '#End Region

  '#Region "Sub / Function"
  '#End Region

  '#End Region

#End Region

  '#Region "Not used"
  '#End Region

End Class
' frmBook