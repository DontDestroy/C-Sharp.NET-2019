﻿//***
// Action
//   - A definition of an AccompliceRobot
// Created
//   - CopyPaste – 20251028 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251028 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpAccompliceRobot : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpAccompliceRobot(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor, cpinfStrategy theInitialStrategy) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpAccompliceRobot starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Assignment of the strategy by theInitialStrategy
    // Called by
    //   - cpAccompliceRobot(int, int, Directions.Direction, int, cpinfStrategy) 
    //   - cpProgram.Decorator()
    //   - cpProgram.Enumeration()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      myStrategy = theInitialStrategy;
    }
    // cpAccompliceRobot(int, int, Directions.Direction, int, Color, cpinfStrategy) 

    public cpAccompliceRobot(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, cpinfStrategy theInitialStrategy) : this(intStreet, intAvenue, theDirection, intBeepers, null, theInitialStrategy)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpAccompliceRobot starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpAccompliceRobot(int, int, Directions.Direction, int, Color, cpinfStrategy) 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpAccompliceRobot(int, int, Directions.Direction, int, cpinfStrategy) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpinfStrategy myStrategy = new cpNullStrategy();

    #endregion

    #region "Properties"

    public cpinfStrategy Strategy
    {

      get
      //***
      // Action get
      //   - return myStrategy
      // Called by
      //   - cpSpyRobot.GetNextClue()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251028 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251028 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return myStrategy;
      }
      // cpinfStrategy Strategy (Get)

    }
    // cpinfStrategy Strategy


    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpAccompliceRobot

}
// cpKarelTheRobot