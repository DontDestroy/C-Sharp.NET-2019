﻿//***
// Action
//   - Binding data to controls on a form
// Created
//   - CopyPaste – 20210628 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210628 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

namespace DataBoundWizard
{
  partial class frmEmployeeWizard
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.TextBox txtNotes;
    internal System.Windows.Forms.TextBox txtPosition;
    internal System.Windows.Forms.TextBox txtHireDate;
    internal System.Windows.Forms.TextBox txtSurname;
    internal System.Windows.Forms.TextBox txtGivenName;
    internal System.Windows.Forms.Label lblNotes;
    internal System.Windows.Forms.Label lblHireDate;
    internal System.Windows.Forms.Label lblSurname;
    internal System.Windows.Forms.Label lblGivenName;
    internal System.Windows.Forms.Label lblTitle;
    internal System.Windows.Forms.TextBox txtTitle;
    internal System.Windows.Forms.Label lblPosition;
    internal System.Windows.Forms.Label lblEmployeeKey;
    private dsEmployee dsEmployee;
    private System.Windows.Forms.BindingSource bdsrcEmployee;
    private dsEmployeeTableAdapters.tbaEmployee tbaEmployee;
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEmployeeWizard));
      this.txtNotes = new System.Windows.Forms.TextBox();
      this.bdsrcEmployee = new System.Windows.Forms.BindingSource();
      this.dsEmployee = new DataBoundWizard.dsEmployee();
      this.txtPosition = new System.Windows.Forms.TextBox();
      this.txtHireDate = new System.Windows.Forms.TextBox();
      this.txtSurname = new System.Windows.Forms.TextBox();
      this.txtGivenName = new System.Windows.Forms.TextBox();
      this.lblNotes = new System.Windows.Forms.Label();
      this.lblHireDate = new System.Windows.Forms.Label();
      this.lblSurname = new System.Windows.Forms.Label();
      this.lblGivenName = new System.Windows.Forms.Label();
      this.lblTitle = new System.Windows.Forms.Label();
      this.txtTitle = new System.Windows.Forms.TextBox();
      this.lblPosition = new System.Windows.Forms.Label();
      this.lblEmployeeKey = new System.Windows.Forms.Label();
      this.tbaEmployee = new DataBoundWizard.dsEmployeeTableAdapters.tbaEmployee();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcEmployee)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsEmployee)).BeginInit();
      this.SuspendLayout();
      // 
      // txtNotes
      // 
      this.txtNotes.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcEmployee, "memNotes", true));
      this.txtNotes.Location = new System.Drawing.Point(14, 132);
      this.txtNotes.Multiline = true;
      this.txtNotes.Name = "txtNotes";
      this.txtNotes.Size = new System.Drawing.Size(412, 70);
      this.txtNotes.TabIndex = 12;
      this.txtNotes.Text = "Notes";
      // 
      // bdsrcEmployee
      // 
      this.bdsrcEmployee.DataMember = "tblCPEmployee";
      this.bdsrcEmployee.DataSource = this.dsEmployee;
      // 
      // dsEmployee
      // 
      this.dsEmployee.DataSetName = "dsEmployee";
      this.dsEmployee.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // txtPosition
      // 
      this.txtPosition.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcEmployee, "strTitle", true));
      this.txtPosition.Location = new System.Drawing.Point(247, 94);
      this.txtPosition.Name = "txtPosition";
      this.txtPosition.Size = new System.Drawing.Size(179, 20);
      this.txtPosition.TabIndex = 10;
      this.txtPosition.Text = "Position";
      // 
      // txtHireDate
      // 
      this.txtHireDate.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcEmployee, "dtmHireDate", true));
      this.txtHireDate.Location = new System.Drawing.Point(82, 94);
      this.txtHireDate.Name = "txtHireDate";
      this.txtHireDate.Size = new System.Drawing.Size(103, 20);
      this.txtHireDate.TabIndex = 8;
      this.txtHireDate.Text = "Hire Date";
      // 
      // txtSurname
      // 
      this.txtSurname.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcEmployee, "strFirstName", true));
      this.txtSurname.Location = new System.Drawing.Point(82, 66);
      this.txtSurname.Name = "txtSurname";
      this.txtSurname.Size = new System.Drawing.Size(124, 20);
      this.txtSurname.TabIndex = 6;
      this.txtSurname.Text = "Surname";
      // 
      // txtGivenName
      // 
      this.txtGivenName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcEmployee, "strLastName", true));
      this.txtGivenName.Location = new System.Drawing.Point(82, 38);
      this.txtGivenName.Name = "txtGivenName";
      this.txtGivenName.Size = new System.Drawing.Size(124, 20);
      this.txtGivenName.TabIndex = 4;
      this.txtGivenName.Text = "Given Name";
      // 
      // lblNotes
      // 
      this.lblNotes.AutoSize = true;
      this.lblNotes.Location = new System.Drawing.Point(14, 118);
      this.lblNotes.Name = "lblNotes";
      this.lblNotes.Size = new System.Drawing.Size(38, 13);
      this.lblNotes.TabIndex = 11;
      this.lblNotes.Text = "&Notes:";
      // 
      // lblHireDate
      // 
      this.lblHireDate.AutoSize = true;
      this.lblHireDate.Location = new System.Drawing.Point(14, 96);
      this.lblHireDate.Name = "lblHireDate";
      this.lblHireDate.Size = new System.Drawing.Size(52, 13);
      this.lblHireDate.TabIndex = 7;
      this.lblHireDate.Text = "&Hire Date";
      // 
      // lblSurname
      // 
      this.lblSurname.AutoSize = true;
      this.lblSurname.Location = new System.Drawing.Point(14, 68);
      this.lblSurname.Name = "lblSurname";
      this.lblSurname.Size = new System.Drawing.Size(52, 13);
      this.lblSurname.TabIndex = 5;
      this.lblSurname.Text = "&Surname:";
      // 
      // lblGivenName
      // 
      this.lblGivenName.AutoSize = true;
      this.lblGivenName.Location = new System.Drawing.Point(14, 41);
      this.lblGivenName.Name = "lblGivenName";
      this.lblGivenName.Size = new System.Drawing.Size(69, 13);
      this.lblGivenName.TabIndex = 3;
      this.lblGivenName.Text = "&Given Name:";
      // 
      // lblTitle
      // 
      this.lblTitle.AutoSize = true;
      this.lblTitle.Location = new System.Drawing.Point(14, 10);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(30, 13);
      this.lblTitle.TabIndex = 1;
      this.lblTitle.Text = "&Title:";
      // 
      // txtTitle
      // 
      this.txtTitle.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcEmployee, "strTitleOfCourtesy", true));
      this.txtTitle.Location = new System.Drawing.Point(82, 10);
      this.txtTitle.Name = "txtTitle";
      this.txtTitle.Size = new System.Drawing.Size(42, 20);
      this.txtTitle.TabIndex = 2;
      this.txtTitle.Text = "Title";
      // 
      // lblPosition
      // 
      this.lblPosition.AutoSize = true;
      this.lblPosition.Location = new System.Drawing.Point(192, 96);
      this.lblPosition.Name = "lblPosition";
      this.lblPosition.Size = new System.Drawing.Size(47, 13);
      this.lblPosition.TabIndex = 9;
      this.lblPosition.Text = "&Position:";
      // 
      // lblEmployeeKey
      // 
      this.lblEmployeeKey.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcEmployee, "intIdEmployee", true));
      this.lblEmployeeKey.Location = new System.Drawing.Point(384, 7);
      this.lblEmployeeKey.Name = "lblEmployeeKey";
      this.lblEmployeeKey.Size = new System.Drawing.Size(55, 14);
      this.lblEmployeeKey.TabIndex = 0;
      this.lblEmployeeKey.Text = "ID";
      // 
      // tbaEmployee
      // 
      this.tbaEmployee.ClearBeforeFill = true;
      // 
      // frmEmployeeWizard
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(439, 237);
      this.Controls.Add(this.txtNotes);
      this.Controls.Add(this.txtPosition);
      this.Controls.Add(this.txtHireDate);
      this.Controls.Add(this.txtSurname);
      this.Controls.Add(this.txtGivenName);
      this.Controls.Add(this.lblNotes);
      this.Controls.Add(this.lblHireDate);
      this.Controls.Add(this.lblSurname);
      this.Controls.Add(this.lblGivenName);
      this.Controls.Add(this.lblTitle);
      this.Controls.Add(this.txtTitle);
      this.Controls.Add(this.lblPosition);
      this.Controls.Add(this.lblEmployeeKey);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmEmployeeWizard";
      this.Text = "Employees Wizard";
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcEmployee)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsEmployee)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //  - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210628 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210628 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing && (components != null))
      {
        components.Dispose();
      }
      // (disposing && (components != null))

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmEmployeeWizard

}
// DataBoundWizard