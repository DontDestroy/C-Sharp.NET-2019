﻿//***
// Action
//   - Implementation of a cpMute
//		 - The way a thing does not make a sound
// Created
//   - CopyPaste – 20240721 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240721 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Animal.Library
{

	public class cpMute : cpiMakeNoise
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpMute
		/// </summary>
		public cpMute() 
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240721 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240721 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpMute()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing can't make a sound
		/// </summary>
		public void MakeNoise()
		//***
		// Action
		//   - Define how something is not able to make a sound
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240721 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240721 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Something is not making a sound");
		}
		// MakeNoise()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpMute

}
// CopyPaste.Game.Animal.Library