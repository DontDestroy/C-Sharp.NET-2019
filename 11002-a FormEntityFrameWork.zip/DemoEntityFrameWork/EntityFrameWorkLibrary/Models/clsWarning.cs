﻿//***
// Action
//   - The class cpWarning
//   - Will be used to create a table in a SQL Server database
//   - The primary key is by default setting in Entity FrameWork the <classname>Id notification
//     - This is not according to Copy Paste naming conventions (it should be intIdTask)
// Created
//   - CopyPaste – 20230405 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230405 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpWarning
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public int cpWarningId { get; set; }
    public string strName{ get; set; }
    public string strDescription { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpWarning

}
//  CopyPaste.Learning