﻿//***
// Action
//   - Demo of how to communicate with a server
//   - This is the answer form
// Created
//   - CopyPaste – 20260808 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260808 – VVDW
// Proposal (To Do)
//   - The server is not live at the moment
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmCopyPasteCoffeeOrderAnswer : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when initializing the page
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260808 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260808 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - If form is started the first time
    //       - Get the values out of the request form and put them in the corresponding answer
    //       - Not all options are described in the comments.
    //         - Beans, type of beans, number of bags, arrive date, extras and ship to can be filled in or partially filled in
    //         - The typed comments are not in the response
    //     - If not
    //       - Show corresponding error message
    //   - On possible error
    //     - Show corresponding error message
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260808 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260808 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      try
      {

        if (IsPostBack || Request.Form["name"] == null)
        {
          lblAnswer.Text = "Page not correctly loaded";
        }
        else
        // Not IsPostBack And Request.Form["name"] <> null
        {

          if (string.IsNullOrWhiteSpace(Request.Form["name"]))
          {
            lblAnswer.Text = "Thanks, but to be able to prepare your order, we need your name or nickname.";
          }
          else
          // Not string.IsNullOrWhiteSpace(Request.Form["name"])
          {
            lblAnswer.Text = "Thanks, <strong>" + Request.Form["name"] + "</strong>, for your order.<br>";

            if (string.IsNullOrWhiteSpace(Request.Form["beans"]))
            {
              lblAnswer.Text += "But we didn't get your choice of beans or whether they are whole or ground.<br>" +
                "You might want to click the back button to go back and try again, otherwise, we won't be able to make " +
                "your Copy Paste Coffee order, and that would suck.";
            }
            else if (string.IsNullOrWhiteSpace(Request.Form["beantype"]))
            // Not string.IsNullOrWhiteSpace(Request.Form["beans"])
            {
              lblAnswer.Text = "Thanks, <strong>" + Request.Form["name"] + "</strong>, for your order.<br>" +
                "But we didn't get your choice of whole or ground.<br>" +
                "You might want to click the back button to go back and try again, otherwise, we won't be able to make " +
                "your Copy Paste Coffee order, and that would suck.";
              lblAnswer.Text += "<br><br>Here's what we received you so far:<br><br>";
              lblAnswer.Text += "<strong>Name: </strong>" + Request.Form["name"];
              lblAnswer.Text += "<br><strong>Number of Bags :</strong>";

              if (string.IsNullOrWhiteSpace(Request.Form["bags"]))
              {
                lblAnswer.Text += "1";
              }
              else
              // Not string.IsNullOrWhiteSpace(Request.Form["bags"])
              {
                lblAnswer.Text += Request.Form["bags"];
              }
              // string.IsNullOrWhiteSpace(Request.Form["bags"])

              lblAnswer.Text += "<br><strong>Beans: </strong>" + Request.Form["beans"];
              lblAnswer.Text += "<br><strong>Type: </strong>" + Request.Form["beantype"];
              lblAnswer.Text += "<br><strong>Address: </strong>" + Request.Form["address"];
              lblAnswer.Text += "<br><strong>Date: </strong>" + Request.Form["date"];
              lblAnswer.Text += "<br><strong>City: </strong>" + Request.Form["city"];
              lblAnswer.Text += "<br><strong>State: </strong>" + Request.Form["state"];
              lblAnswer.Text += "<br><strong>Zip: </strong>" + Request.Form["zip"];
              lblAnswer.Text += "<br><strong>Phone: </strong>" + Request.Form["phone"];
            }
            else
            // Not string.IsNullOrWhiteSpace(Request.Form["beantype"])
            {
              lblAnswer.Text += "<br><br>Your order of ";

              if (string.IsNullOrWhiteSpace(Request.Form["bags"]))
              {
                lblAnswer.Text += "1";
              }
              else
              // Not string.IsNullOrWhiteSpace(Request.Form["bags"])
              {
                lblAnswer.Text += Request.Form["bags"];
              }
              // string.IsNullOrWhiteSpace(Request.Form["bags"])

              lblAnswer.Text += " bags of ";
              lblAnswer.Text += Request.Form["beantype"] + " ";
              lblAnswer.Text += Request.Form["beans"];

              if (Request.Form["catalog"] == "on")
              {
                lblAnswer.Text += ", catalog included";
              }
              else
              // Request.Form["catalog"] <> "on"
              {
              }
              // Request.Form["catalog"] = "on"

              if (Request.Form["giftwrap"] == "on")
              {
                lblAnswer.Text += ", wrapped as a gift";
              }
              else
              // Request.Form["giftwrap"] <> "on"
              {
              }
              // Request.Form["giftwrap"] = "on"

              lblAnswer.Text += " has been sent to:<br><br>";
              lblAnswer.Text += "<strong>Name: </strong><em>" + Request.Form["name"] + "</em>";
              lblAnswer.Text += "<br><strong>Address: </strong><em>" + Request.Form["address"] + "</em>";
              lblAnswer.Text += "<br><strong>City: </strong><em>" + Request.Form["city"] + "</em>";
              lblAnswer.Text += "<br><strong>State: </strong><em>" + Request.Form["state"] + "</em>";
              lblAnswer.Text += "<br><strong>Zip: </strong><em>" + Request.Form["zip"] + "</em>";
              lblAnswer.Text += "<br><strong>Phone: </strong><em>" + Request.Form["phone"] + "</em>";

              if (string.IsNullOrWhiteSpace(Request.Form["date"]))
              {
                lblAnswer.Text += "<br><strong>Estimated arrive date: </strong><em>" + DateTime.Now.AddDays(1).ToString("dd/MM/yyyy") + "</em>";
              }
              else
              // Not string.IsNullOrWhiteSpace(Request.Form["date"])
              {
                lblAnswer.Text += "<br><strong>Estimated arrive date: </strong><em>" + Convert.ToDateTime(Request.Form["date"]).ToString("dd/MM/yyyy") + "</em>";
              }
              // string.IsNullOrWhiteSpace(Request.Form["date"])

            }
            // string.IsNullOrWhiteSpace(Request.Form["beans"])
            // string.IsNullOrWhiteSpace(Request.Form["beantype"])

          }
          // string.IsNullOrWhiteSpace(Request.Form["name"])

        }
        // IsPostBack Or Request.Form["name"] = null

      }
      catch
      {
        lblAnswer.Text = "Page not correctly loaded";
      }

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmCopyPasteCoffeeOrderAnswer

}
// CopyPaste.Learning