//***
// Action
//   - Testroutine for cpEmployee
// Created
//   - CopyPaste � 20220308 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220308 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Toolkit;
using System;

namespace Properties
{

  class cpProgram
	{

    static void Main()
      //***
      // Action
      //   - Create an instance of cpEmployee
      //   - Give a Name
      //   - Define the wage constants
      //   - Show the values of the properties
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpEmployee.Name(string) (Set)
      //   - cpEmployee.New()
      //   - cpEmployee.Wage(decimal) (Set)
      //   - decimal cpEmployee.Wage(WageConstant) (Get)
      //   - string cpEmployee.Name (Get)
      // Created
      //   - CopyPaste � 20220308 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220308 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      
      cpEmployee thecpEmployee = new cpEmployee();
      
      thecpEmployee.Name = "Vincent";
      thecpEmployee[WageConstant.Rate] = Convert.ToDecimal(75.0);
      thecpEmployee[WageConstant.OverTime] = Convert.ToDecimal(75.0 * 1.5);
      thecpEmployee[WageConstant.Weekend] = Convert.ToDecimal(75.0 * 1.75);
      thecpEmployee[WageConstant.WeekendOverTime] = Convert.ToDecimal(75.0 * 2.25);

      Console.WriteLine("Name: " + thecpEmployee.Name);
      Console.WriteLine("Rate: " + thecpEmployee[WageConstant.Rate]);
      Console.WriteLine("OverTime: " + thecpEmployee[WageConstant.OverTime]);
      Console.WriteLine("Weekend: " + thecpEmployee[WageConstant.Weekend]);
      Console.WriteLine("Weekend OverTime: " + thecpEmployee[WageConstant.WeekendOverTime]);
      thecpEmployee = null;
      
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

	}
  // cpProgram

}
// Properties