Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Book")>
<Assembly: AssemblyDescription("Copy Paste Example Visual Basic .NET 2019")>
<Assembly: AssemblyCompany("Copy Paste")> 
<Assembly: AssemblyProduct("Example DLL")> 
<Assembly: AssemblyCopyright("Copy Paste Classroom")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: CLSCompliant(True)> 
<Assembly: AssemblyKeyFile("")> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("DA36FEE0-7CD6-4FEA-9009-8380AA21D272")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.0.0")> 
