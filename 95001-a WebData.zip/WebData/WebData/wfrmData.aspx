﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmData.aspx.cs" Inherits="CopyPaste.Learning.wfrmDataProgram" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Data from SQL Server cpClient</title>
</head>
<body>
  <form id="wfrmDataProgram" method="post" runat="server">
    <asp:ListBox ID="lstClient" Style="z-index: 103; position: absolute; top: 88px; left: 48px" runat="server"
      Width="128px" Height="280px"></asp:ListBox>
    <asp:Label ID="lblTitle" Style="z-index: 102; position: absolute; top: 24px; left: 24px" runat="server"
      Font-Size="X-Large">Clients</asp:Label>
  </form>
</body>
</html>
