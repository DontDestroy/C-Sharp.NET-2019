﻿//***
// Action
//   - 
// Created
//   - CopyPaste – 20220824 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220824 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Controls;

namespace ProductCategory_WPF_MVVM.Views
{

  public partial class ctrlProductCategory : UserControl
  {

    #region "Constructors / Destructors"

    public ctrlProductCategory()
    //***
    // Action
    //   - Create an instance of ctrlProductCategory
    // Called by
    //   - wpfStartupScreen
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220824 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220824 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***

    {
      InitializeComponent();
    }
    // ctrlProductCategory()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // ctrlProductCategory

}
// ProductCategory_WPF_MVVM.Views