//***
// Action
//   - Class definition of cpEmployee
// Created
//   - CopyPaste � 20230419 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230419 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpEmployee
  {

    #region "Constructors / Destructors"
    
    public cpEmployee()
    //'***
    //' Action
    //'   - Empty constructor of cpEmployee
    //' Called by
    //'   - 
    //' Calls
    //'   - 
    //' Created
    //'   - CopyPaste � 20230419 � VVDW
    //' Changed
    //'   - CopyPaste � yyyymmdd � VVDW � What changed
    //' Tested
    //'   - CopyPaste � 20230419 � VVDW
    //' Keyboard key
    //'   - 
    //' Proposal (To Do)
    //'   - 
    //'***
    {
    }
    // cpEmployee()

    #endregion

    #region "Designer"

    public enum aSex
    {
      Male,
      Female
    }
    // aSex

    #endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private aSex theSex;
    private DateTime dtmStart;
    private readonly DateTime dtmStartCompany = new DateTime(2000, 10, 15);
    private string strName;

    #endregion

    #region "Properties"

    public string Name
    {

      get
      //***
      // Action Get
      //   - Returns strName
      // Called by
      //   - cpProgram.Main()
      //   - cpProgram.TestIsNothing()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230419 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230419 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return strName;
      }
      // string Name (Get)

      set
        //***
        // Action Set
        //   - strName becomes value
        // Called by
        //   - cpProgram.Main()
        //   - cpProgram.TestIsNothing()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20070205 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20070205 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        strName = value;
      }
      // strName(string) (Set)

    }
    // string Name

    public aSex Sex
    {

      get
      //***
      // Action Get
      //   - Returns theSex
      // Called by
      //   - cpProgram.Main()
      //   - cpProgram.TestIsNothing()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230419 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230419 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return theSex;
      }
      // aSex Sex (Get)

      set
      //***
      // Action Set
      //   - theSex becomes theValue
      // Called by
      //   - cpProgram.Main()
      //   - cpProgram.TestIsNothing()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230419 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230419 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        theSex = value;
      }
      // Sex(aSex) (Set)

    }
    // aSex Sex

    public DateTime StartDate
    {

      get
      //***
      // Action Get
      //   - Returns dtmStart
      // Called by
      //   - cpProgram.Main()
      //   - cpProgram.TestIsNothing()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230419 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230419 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return dtmStart;
      }
      // DateTime StartDate (Get)

      set
      //***
      // Action Get
      //   - If dtmValue is before dtmStartCompany
      //     - dtmStart becomes dtmStartCompany
      //   - If Not
      //     - dtmStart becomes dtmValue
      // Called by
      //   - cpProgram.Main()
      //   - cpProgram.TestIsNothing()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230419 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230419 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if (value >= dtmStartCompany)
        {
          dtmStart = value;
        }
        else
          // value < dtmStartCompany
        {
          dtmStart = dtmStartCompany;
        }
        // value >= dtmStartCompany

      }
      // StartDate(DateTime) (Set)

    }
    // DateTime StartDate

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpEmployee

}
// CopyPaste.Learning