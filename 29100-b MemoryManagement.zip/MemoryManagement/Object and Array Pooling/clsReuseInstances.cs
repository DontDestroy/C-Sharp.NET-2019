﻿//***
// Action
//   - Demo Object Array
//   - Demo Object Pooling
//   - Demo Array Pooling
// Created
//   - CopyPaste – 20260607 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260607 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Buffers;
using System.Collections.Generic;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpReuseInstances
  {

    #region "Constructors / Destructors"

    public cpReuseInstances()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - Main()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260607 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260607 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpReuseInstances()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [BenchmarkAttribute]
    public void MessageParserArray()
    //***
    // Action
    //   - Define and assign a length
    //   - Define and assign a random generator
    //   - Loop 10000 times
    //     - Define and assign an array of bytes with length
    //     - Define and assign an array of integers
    //     - Fill array of bytes with random numbers
    //     - Define and assign a cpMessageParser
    //     - Parse the message
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - cpMessageParser(byte[])
    //   - int[] cpMessageParser.Parse()
    // Created
    //   - CopyPaste – 20260607 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260607 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      byte[] arrBuffer;
      cpMessageParser theParser;
      int intLength = 1_024;
      int[] arrResult = null;
      Random rndByte = new Random();

      for (int intCounter = 0; intCounter < 10_000; intCounter++)
      {
        arrBuffer = new byte[intLength];

        rndByte.NextBytes(arrBuffer);

        theParser = new cpMessageParser(arrBuffer);
        arrResult = theParser.Parse();
      }
      // intCounter = 10_000

    }
    // MessageParserArray()

    [BenchmarkAttribute]
    public void MessageParserArrayPool()
    //***
    // Action
    //   - Define, assign and share an array pool
    //   - Define an array of bytes
    //   - Define a cpMessageParser
    //   - Define an array of integers
    //   - Define and assign a length
    //   - Define and assign a random generator
    //   - Loop 10000 times
    //     - Assign an array of bytes with length by renting it from the pool
    //     - Fill array of bytes with random numbers
    //     - Try to
    //       - Assign an array of integers
    //       - Define and assign a cpMessageParser
    //       - Parse the message
    //     - Return the buffer back to the pool that was previously rent
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - cpMessageParser(byte[])
    //   - int[] cpMessageParser.Parse()
    // Created
    //   - CopyPaste – 20260607 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260607 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ArrayPool<byte> theArrayPool = ArrayPool<byte>.Shared;
      byte[] arrBuffer;
      cpMessageParser theParser;
      int intLength = 1_024;
      int[] arrResult;
      
      Random rndByte = new Random();

      for (int intCounter = 0; intCounter < 10_000; intCounter++)
      {
        arrBuffer = new byte[intLength];
        rndByte.NextBytes(arrBuffer);

        try
        {
          theParser = new cpMessageParser(arrBuffer);
          arrResult = theParser.Parse();
        }
        finally
        {
          theArrayPool.Return(arrBuffer);
        }

      }
      // intCounter = 10_000

    }
    // MessageParserArrayPool()

    [BenchmarkAttribute]
    public void MessageParserObjectPool()
    //***
    // Action
    //   - Define, assign and share an array pool
    //   - Define and assign an object pool of cpMessageParser
    //   - Define an array of bytes
    //   - Define an array of integers
    //   - Define and assign a length
    //   - Define and assign a random generator
    //   - Loop 10000 times
    //     - Define and assign an array of bytes with length by renting it from the pool
    //     - Define and assign an array of integers
    //     - Try to
    //       - Rent from the ParserPool
    //       - Reset the ParserPool
    //       - Assign the array of bytes
    //       - Parse the message
    //     - Return the buffer back to the pool that was previously rent
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - cpMessageParser(byte[])
    //   - cpMessageParser.Buffer(byte[]) (Set)
    //   - cpMessageParser.Reset()
    //   - int[] cpMessageParser.Parse()
    // Created
    //   - CopyPaste – 20260608 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260608 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ArrayPool<byte> theArrayPool = ArrayPool<byte>.Shared;
      cpObjectPool<cpMessageParser> theParserPool = new cpObjectPool<cpMessageParser>();
      byte[] arrBuffer;
      int intLength = 1_024;
      int[] arrResult;

      Random rndByte = new Random();

      for (int intCounter = 0; intCounter < 10_000; intCounter++)
      {
        arrBuffer = theArrayPool.Rent(intLength);
        rndByte.NextBytes(arrBuffer);

        try
        {
          cpMessageParser theParser = theParserPool.Rent();
          theParser.Reset();
          theParser.Buffer = arrBuffer;
          arrResult = theParser.Parse();
          theParserPool.Return(theParser);
        }
        finally
        {
          theArrayPool.Return(arrBuffer);
        }

      }
      // intCounter = 10_000

    }
    // MessageParserObjectPool()

    [BenchmarkAttribute]
    public void MessageParserObjectPoolAdvanced()
    //***
    // Action
    //   - Define, assign and share an array pool
    //   - Define and assign an object pool of cpMessageParser
    //   - Define an array of bytes
    //   - Define an array of integers
    //   - Define and assign a length
    //   - Define and assign a random generator
    //   - Loop 10000 times
    //     - Define and assign an array of bytes with length by renting it from the pool
    //     - Define and assign an array of integers
    //     - Try to
    //       - Rent from the ParserPool
    //       - Reset the ParserPool
    //       - Assign the array of bytes
    //       - Parse the message
    //     - Return the buffer back to the pool that was previously rent
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - cpMessageParserAdvanced(byte[])
    //   - cpMessageParserAdvanced.Buffer(byte[]) (Set)
    //   - cpMessageParserAdvanced.Reset()
    //   - int[] cpMessageParserAdvanced.Parse()
    // Created
    //   - CopyPaste – 20260608 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260608 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpObjectPool<cpMessageParserAdvanced> theParserPool = new cpObjectPool<cpMessageParserAdvanced>();
      int intLength = 1_024;
      IMemoryOwner<byte> theArrayPoolInput = MemoryPool<byte>.Shared.Rent(intLength);
      IMemoryOwner<int> theArrayPoolOutput = MemoryPool<int>.Shared.Rent(intLength / 8);
      Memory<byte> memBuffer;
      Memory<int> memResult;

      Random rndByte = new Random();
      memBuffer = theArrayPoolInput.Memory;
      memResult = theArrayPoolOutput.Memory;

      for (int intCounter = 0; intCounter < 10_000; intCounter++)
      {
        rndByte.NextBytes(memBuffer.Span);

        try
        {
          cpMessageParserAdvanced theParser = theParserPool.Rent();
          theParser.Reset();
          theParser.Buffer = memBuffer;
          theParser.Result = memResult;
          theParser.Parse();
          theParserPool.Return(theParser);
        }
        finally
        {
        }

      }
      // intCounter = 10_000

    }
    // MessageParserObjectPoolAdvanced()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpReuseInstances

}
// CopyPaste.Learning