//***
// Action
//   - TestRoutine for cpBase and cpDerived
// Created
//   - CopyPaste � 20240531 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240531 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define an instance of cpBase
      //   - Define an instance of cpDerived
      //   - Define an instance of mixed classes (polymorphism)
      //     - All cases are there, 3 of them are in comments
      //   - Show base members of cpBase
      //   - Show base members of cpDerived
      //   - Show derived members of cpDerived
      //   - Show base members of cpMixed
      //   - Show derived members of cpMixed
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpBase(string, int, string)
      //   - cpBase.ShowBaseMembers()
      //   - cpDerived(string, int, string)
      //   - cpDerived.ShowDerivedMembers()
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBase thecpBase = new cpBase("Vincent", 1000, "Base Message");
      cpDerived thecpDerived = new cpDerived("Hilde", 750, "Derived Message");
      cpBase thecpMixed = new cpDerived("Martijn", 500, "Mixed Message");
      // cpDerived thecpMixed = new cpDerived("Martijn", 500, "Mixed Message");
      // cpDerived thecpMixed = new cpBase("Martijn", 500, "Mixed Message");
      // cpBase thecpMixed = new cpBase("Martijn", 500, "Mixed Message");

      Console.WriteLine("Base Members");
      thecpBase.ShowBaseMembers();
      Console.WriteLine();
      thecpDerived.ShowBaseMembers();
      Console.WriteLine();
      Console.WriteLine("Derived Members");
      thecpDerived.ShowDerivedMembers();
      Console.WriteLine();
      Console.WriteLine("Mixed zone");
      thecpMixed.ShowBaseMembers();
      Console.WriteLine();
      // thecpMixed.ShowDerivedMembers();
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning