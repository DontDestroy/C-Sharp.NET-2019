﻿//***
// Action
//   - A definition of a ThiefRobotFail
// Created
//   - CopyPaste – 20251106 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251106 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using java.lang;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpThiefRobotFail : cpCopyPasteRobot, Runnable
	{

		#region "Constructors / Destructors"

		public cpThiefRobotFail(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpThiefRobotFail starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - A new thread of the cpThiefRobotFail is defined
    //   - The thread is started
    // Called by
    //   - cpProgram.ThiefRobotFail()
    //   - cpThiefRobotFail(int, int, Directions.Direction, int) 
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Thread theRobotRunnerThread = new Thread(this);

      theRobotRunnerThread.start();
    }
    // cpThiefRobotFail(int, int, Directions.Direction, int, Color) 

    public cpThiefRobotFail(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpThiefRobotFail starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpThiefRobotFail(int, int, Directions.Direction, int, Color) (int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpThiefRobotFail(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override void run()
    //***
    // Action
    //   - Define what must be runned
    //   - Move one forward
    //   - Repeat 10000 times
    //     - Turn around
    //     - If next to a beeper
    //       - Pick it
    //     - If not
    //       - Put one
    //     - Move one forward
    //     - Turn around
    //     - Move one forward
    //   - Move one forward
    //   - Robot switch off
    // Called by
    //   - cpThiefRobotFail(int, int, Directions.Direction, int, Color) 
    // Calls
    //   - cpCopyPasteRobot.TurnAround()
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      pickBeeper();
      move();

      for (int counter = 0; counter < 10000; counter++)
      {
        TurnAround();

        if (nextToABeeper())
        {
          pickBeeper();
        }
        else
        // Not nextToABeeper()
        {
          putBeeper();
        }
        // nextToABeeper()

        move();
        TurnAround();
        move();
      }
      // counter = 10000

      move();
      turnOff();
    }
    // run()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpThiefRobotFail

}
// cpKarelTheRobot