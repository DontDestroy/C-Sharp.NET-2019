//***
// Action
//   - A pet store, the definition of a parakeet (base class, but inherits from cpBird)
//   - Working with properties (Get and Set) and methods in several classes, that can be reused
// Created
//   - CopyPaste � 20230407 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW
// Tested
//   - CopyPaste � 20230407 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace CopyPaste.Pet.Bird
{

  public class cpParakeet : cpBird
  {

    #region "Constructors / Destructors"

    public cpParakeet() : base ()
    //***
    // Action
    //   - Creating an instance of cpParakeet with default parameters
    //   - Breed becomes "Parakeet"
    //   - Cost becomes 75
    //   - Write a line "cpParakeet default constructor"
    // Called by
    //   - 
    // Calls
    //   - base()
    //   - CopyPaste.Pet.cpAnimal.Breed(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Cost(decimal) (Set)
    // Created
    //   - CopyPaste � 20230407 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20230407 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Breed = "Parakeet";
      Cost = 75;
      Console.WriteLine("cpParakeet default constructor");
    }
    // cpParakeet()

    public cpParakeet(string strName, string strColor) : base (strName)
    //***
    // Action
    //   - Creating an instance of cpParakeet with default parameters and strName
    //   - Breed becomes "Parakeet"
    //   - Cost becomes 75
    //   - Coloration becomes strColor
    //   - Write a line "cpParakeet overloaded constructor"
    // Called by
    //   - wpfPetStore.FillArray()
    // Calls
    //   - base(string)
    //   - CopyPaste.Pet.cpAnimal.Breed(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Coloration(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Cost(decimal) (Set)
    // Created
    //   - CopyPaste � 20230407 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20230407 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Breed = "Parakeet";
      Cost = 75;
      Coloration = strColor;
      Console.WriteLine("cpParakeet overloaded constructor");
    }
    // cpParakeet(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override string Speak()
    //***
    // Action
    //   - Write a line to the console with "CopyPaste.Pet.Bird.cpParakeet.Speak"
    //   - Return "(Name) says 'Pee-dee-deet, peet.'"
    // Called by
    //   - wpfPetStore.cmdSpeak_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdSpeak.Click
    // Calls
    //   - Overrides string CopyPaste.Pet.cpAnimal.Speak()
    //   - string CopyPaste.Pet.cpAnimal.Name (Get)
    // Created
    //   - CopyPaste � 20230407 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20230407 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Console.WriteLine("CopyPaste.Pet.Bird.cpParakeet.Speak");
      return Name + " says 'Pee-dee-deet, peet.'";
    }
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpParakeet

}
// CopyPaste.Pet.Bird