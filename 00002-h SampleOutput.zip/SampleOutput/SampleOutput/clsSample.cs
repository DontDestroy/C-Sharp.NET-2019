//***
// Action
//   - Show some messages
// Created
//   - CopyPaste � 20211018 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20211018 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace SampleOutput
{

  class cpSample
	{

    static void Main()
    //***
    // Action
    //   - Show messages on the console screen
    //   - Wait for user interaction
    // Called by
    //   - 
    // Calls
    //   - System.Console.ReadLine()
    //   - System.Console.WriteLine(String)
    // Created
    //   - CopyPaste � 20211018 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20211018 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Hello, User");
      Console.WriteLine("Console applications write output to the console window!");
      Console.WriteLine("Press any key to continue");
      Console.ReadLine();
    }
    // Main()
    
  }
  // cpSample

}
// SampleOutput