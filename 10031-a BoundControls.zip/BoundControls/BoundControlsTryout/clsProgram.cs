﻿//***
// Action
//   - Starting point of the example
// Created
//   - CopyPaste – 20251231 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251231 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251231 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251231 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmBoundControlsMainTryout
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmBoundControlsMainTryout()
      // Created
      //   - CopyPaste – 20251231 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251231 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmBoundControlsMainTryout());
    }
    // Main() 

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning