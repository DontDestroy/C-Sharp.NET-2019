//***
// Action
//   - Class needed because BackgroundWorker.RunWorkerAsync can have only one parameter
//   - There are 2 input parameters, so they needed to be combined in one object
// Created
//   - CopyPaste � 20220818 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220818 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Multithreading
{

  public class cpFindPrimesInput
  {

    #region "Constructors / Destructors"

    public cpFindPrimesInput(uint intFrom, uint intTo)
    //***
    // Action
    //   - Constructor to group From and To value into one object
    // Called by
    //   - cmdFind_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdFind.Click
    // Calls
    //   - From(int) (Set)
    //   - To(int) (Set)
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      To = intTo;
      From = intFrom;
    }
    // cpFindPrimesInput(int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private uint intFrom;
    private uint intTo;

    #endregion

    #region "Properties"

    public uint From
    {

      get
      //***
      // Action Get
      //   - Returns the intFrom value
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return intFrom;
      }
      // uint From (Get)

      set
      //***
      // Action Set
      //   - Sets the intFrom value
      // Called by
      //   - cpFindPrimesInput(uint, uint)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        intFrom = value;
      }
      // From(uint) (Set)

    }
    // uint From

    public uint To
    {

      get
      //***
      // Action Get
      //   - Returns the intTo value
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return intTo;
      }
      // uint To (Get)

      set
      //***
      // Action Set
      //   - Sets the intTo value
      // Called by
      //   - cpFindPrimesInput(uint, uint)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220818 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220818 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        intTo = value;
      }
      // To(uint) (Set)

    }
    // int To

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpFindPrimesInput

}
// Multithreading