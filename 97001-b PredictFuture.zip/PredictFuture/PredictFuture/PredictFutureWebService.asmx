﻿<%@ WebService Language="C#" CodeBehind="PredictFutureWebService.asmx.cs" Class="CopyPaste.Learning.cpPredictFutureWebService" %>
