﻿//***
// Action
//   - Having DataSets in the application
// Created
//   - CopyPaste – 20210709 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210709 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Data;
using System.Windows.Forms;

namespace DataSetsWizard
{

  public partial class frmDataSetsWizard : Form
  {

    #region "Constructors / Destructors"

    public frmDataSetsWizard()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Define a connection
    //   - Set the connection to the select command of dtaEmployee
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210709 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210709 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
      mcnncpNorthWindScript2019 = new System.Data.SqlClient.SqlConnection();
      mcnncpNorthWindScript2019.ConnectionString = DataSetsWizard.Properties.Settings.Default.cnncpNorthWindScript2019;
      dtaEmployee.SelectCommand.Connection = mcnncpNorthWindScript2019;
    }
    // frmDataSetsWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    private System.Data.SqlClient.SqlConnection mcnncpNorthWindScript2019;
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdClone_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - Fill tbaCustomer
    //     - Clone dsData (dsClone)
    //     - Show message with the number of tables and the number of records in tblCPCustomer in the clone
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210709 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210709 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      DataSet dsClone;
      string strMessage;

      try
      {
        dsData.Clear();
        tbaCustomer.Fill(dsData.tblCPCustomer);
        dsClone = dsData.Clone();
        strMessage = "The cloned dataset has " + dsClone.Tables.Count.ToString() + " Tables. ";
        strMessage += "The cloned dataset has " + dsClone.Tables["tblCPCustomer"].Rows.Count.ToString() + " rows in the Customer Table.";
        MessageBox.Show(strMessage);
      }
      catch (System.Exception theException)
      {
      }
      finally
      {
      }

    }
    // cmdClone_Click(System.Object, System.EventArgs)

    private void cmdCopy_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - Fill dtaCustomer
    //     - Clone dsData (dsClone)
    //     - Show message with the number of tables and the number of records in tblCPCustomer in the clone
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210709 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210709 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      DataSet dsCopy;
      string strMessage;

      try
      {
        dsData.Clear();
        tbaCustomer.Fill(dsData.tblCPCustomer);
        dsCopy = dsData.Copy();
        strMessage = "The copied dataset has " + dsCopy.Tables.Count.ToString() + " Tables. ";
        strMessage += "The copied dataset has " + dsCopy.Tables["tblCPCustomer"].Rows.Count.ToString() + " rows in the Customer Table.";
        MessageBox.Show(strMessage);
      }
      catch (System.Exception theException)
      {
      }
      finally
      {
      }

    }
    // cmdCopy_Click(System.Object, System.EventArgs)

    private void cmdRelation_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - Add a relation with name "CustomerOrder" between tblCPCustomer and tblCPOrder (unique identifier of Customer is used)
    //     - Show the name of the relation
    //     - Fill tbaCustomer
    //     - Fill tbaOrder
    //     - Set DataSource and DataMember of dgrOrder
    //   - Catch Exception
    //     - Show message that the relation already exists  
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210709 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210709 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      string strMessage;

      try
      {
        dsData.Relations.Add("CustomerOrder", dsData.tblCPCustomer.strIdCustomerColumn, dsData.tblCPOrder.strCustomerIdColumn);
        strMessage = "The name of the dataRelation is " + dsData.Relations[0].RelationName.ToString();
        MessageBox.Show(strMessage);
        tbaCustomer.Fill(dsData.tblCPCustomer);
        tbaOrder.Fill(dsData.tblCPOrder);
        dgrOrder.DataSource = bdsrcCustomer;
        dgrOrder.DataMember = "CustomerOrder";
      }
      catch (System.Exception theException)
      {
        MessageBox.Show("The relation already exists!");
      }
      finally
      {
      }

    }
    // cmdRelation_Click(System.Object, System.EventArgs)

    private void cmdTable_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - Add Table "tblCPEmployee" (dtEmployee)
    //     - Add Column "intIdEmployee" to "dtEmployee"
    //     - Add Column "strFirstName" to "dtEmployee"
    //     - Add Column "strLastName" to "dtEmployee"
    //     - Fill dtaEmployee
    //     - Show message with the first employee
    //     - Fill lstEmployee with DataSource, DisplayMember and ValueMember
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210709 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210709 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      System.Data.DataTable dtEmployee;
      string strMessage;

      try
      {
        dtEmployee = dsEmployee.Tables.Add("tblCPEmployee");
        dtEmployee.Columns.Add("intIdEmployee", Type.GetType("System.Int32"));
        dtEmployee.Columns.Add("strFirstName", Type.GetType("System.String"));
        dtEmployee.Columns.Add("strLastName", Type.GetType("System.String"));
        dtaEmployee.Fill(dsEmployee.Tables["tblCPEmployee"]);
        strMessage = "The first employee is ";
        strMessage += dsEmployee.Tables["tblCPEmployee"].Rows[0]["strLastName"];
        MessageBox.Show(strMessage);

        lstEmployee.DataSource = dsEmployee.Tables["tblCPEmployee"];
        lstEmployee.DisplayMember = dsEmployee.Tables["tblCPEmployee"].Columns["strLastName"].ToString();
        lstEmployee.ValueMember = dsEmployee.Tables["tblCPEmployee"].Columns["intIdEmployee"].ToString();
      }
      catch (System.Exception theException)
      {
      }
      finally
      {
      }

    }
    // cmdTable_Click(System.Object, System.EventArgs)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataSetsWizard

}
// DataSetsWizard