//***
// Action
//   - Testroutine for cpEmployee, cpWorker, cpOffice and cpManager
// Created
//   - CopyPaste � 20240405 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240405 � VVDW
// Proposal (To Do)
//   - Not all getters and setters are tested, but the usual stuff is
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Instantiation of a cpWorker
      //   - Instantiation of a cpEmployee
      //   - Instantiation of a cpManager
      //   - Instantiation of a cpOffice
      //   - Set the companyParty to a specific date
      //   - Show information of a cpEmployee
      //   - Show information of a cpWorker
      //   - Show information of another cpWorker
      //   - Show information of a cpOffice
      //   - Show information of a cpManager
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpEmployee.CompanyParty(DateTime) (Set)
      //   - cpEmployee()
      //   - cpEmployee.ShowInfo()
      //   - cpOffice(string, cpSex, DateTime, decimal)
      //   - cpOffice.ShowInfo()
      //   - cpManager(string, cpSex, DateTime, decimal, decimal)
      //   - cpManager.ShowInfo()
      //   - cpWorker(string, cpSex, DateTime, decimal, byte)
      //   - cpWorker()
      //   - cpWorker.ShowInfo()
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpWorker thecpAnotherWorker = new cpWorker("Gertrude", cpEmployee.cpSex.Female, new DateTime(2001, 1, 1), 15, 2);
      cpEmployee thecpEmployee = new cpEmployee();
      cpManager thecpManager = new cpManager("Vincent", cpEmployee.cpSex.Male, new DateTime (1990, 1, 1), 3500, 250);
      cpOffice thecpOfficeWorker = new cpOffice("Hilde", cpEmployee.cpSex.Female, new DateTime(2002, 1, 1), 2250);
      cpWorker thecpWorker = new cpWorker();
      
      // cpEmployee.CompanyParty = new DateTime(2007, 2, 28);
      thecpEmployee.ShowInfo();
      thecpWorker.ShowInfo();
      thecpAnotherWorker.ShowInfo();
      thecpOfficeWorker.ShowInfo();
      thecpManager.ShowInfo();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning.Employee