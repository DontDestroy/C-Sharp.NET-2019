//***
// Action
//   - Define a cpDivision (Division and MonthsInDivision)
//   - Two constructors
// Created
//   - CopyPaste � 20220411 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220411 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpDivision : cpEmployee
	{

    #region "Constructors / Destructors"

    public cpDivision() : base()
      //***
      // Action
      //   - Create a new instance of cpDivision
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee()
      // Created
      //   - CopyPaste � 20220411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpDivision()

    public cpDivision(string strFirstName, string strLastName) : base(strFirstName, strLastName)
      //***
      // Action
      //   - Create a new instance of cpDivision with strFirstName and strLastName
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee(string, string)
      // Created
      //   - CopyPaste � 20220411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpDivision(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    private int mintMonthsInDivision = 0;
    private string mstrDivision = "";

    #endregion

    #region "Properties"
    
    public string Division 
    {

      get
        //***
        // Action Get
        //   - Return mstrDivision
        // Called by
        //   - cpProgram.ShowEmployee(cpDivision)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220411 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220411 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrDivision;
      }
      // string Division (Get)

      set
        //***
        // Action Set
        //   - Define mstrDivision
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220411 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220411 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrDivision = value;
      }
      // Division(string) (Set)

    }
    // string Division

    public int MonthsInDivision
    {

      get
        //***
        // Action Get
        //   - Return mintMonthsInDivision
        // Called by
        //   - cpProgram.ShowEmployee(cpDivision)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220411 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220411 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mintMonthsInDivision;
      }
      // int MonthsInDivision (Get)

      set
        //***
        // Action Set
        //   - Define mlngMonthsInDivision
        // Called by
        //   - modEmployeeTest.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220411 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220411 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mintMonthsInDivision = value;
      }
      // MonthsInDivision(int) (Set)

    }
    // int MonthsInDivision

    #endregion

    #region "Methods"

    #region "Overrides"

    public override bool Serialize()
      //***
      // Action
      //   - If mstrDivision is empty string or mlngMonthsInDivision is zero
      //     - Return False
      //   - If Not
      //     - If cpEmployee.Serialize
      //       - Return True
      //     - If Not
      //       - Return False
      // Called by
      //   - modEmployeeTest.Main()
      // Calls
      //   - cpEmployee.Serialize() As Boolean
      // Created
      //   - CopyPaste � 20220411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      
      if (mstrDivision == "" || mintMonthsInDivision == 0)
      {
        return false;
      }
      else
        // (mstrDivision != "" && mintMonthsInDivision != 0)
      {

        if (base.Serialize())
        {
          return true;
        }
        else
          // Not base.Serialize()
        {
          return false;
        }
        // base.Serialize
      
      }
      // (mstrDivision = "" || mintMonthsInDivision = 0)

    }
    // bool Serialize()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDivision

}
// CopyPaste.Learning