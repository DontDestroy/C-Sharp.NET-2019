﻿//***
// Action
//   - Interface for the behaviour (method) Walk
// Created
//   - CopyPaste – 20240721 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240721 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Game.Animal.Library
{

	internal interface cpiWalk
	{

		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a thing can move on the ground
		/// </summary>
		public void Walk();
		// Walk()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpiWalk

}
// CopyPaste.Game.Animal.Library