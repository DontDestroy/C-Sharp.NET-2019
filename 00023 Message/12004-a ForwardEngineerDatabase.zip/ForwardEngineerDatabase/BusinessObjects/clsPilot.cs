﻿//***
// Action
//   - Definition of a Pilot
// Created
//   - CopyPaste – 20230711 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230711 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CopyPaste.BusinessObjects
{

  public enum PilotLicenseType
  {
    Student,
    Sport,
    Recreational,
    Private,
    Commercial,
    FlightInstructor,
    ATP
  }
  // PilotLicenseType

  [SerializableAttribute]
  public class Pilot : Employee
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    // There is no Primary key, but it is inherited from Employee
    // The Pilot information will be inside the table Employee

    // There are 2 relations to the same entity Pilot, see OnModelCreating for solution
    public virtual ICollection<Flight> FlightAsCoPilot { get; set; }
    public virtual ICollection<Flight> FlightAsPilot { get; set; }
    public virtual Nullable<int> FlightHours { get; set; }

    [StringLengthAttribute(50)]
    public virtual string FlightSchool { get; set; }
    public virtual DateTime LicenseDate { get; set; }
    public virtual PilotLicenseType PilotLicenseType { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // Pilot

}
// CopyPaste.BusinessObjects 