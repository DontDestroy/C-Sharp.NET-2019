//***
// Action
//   - TestRoutine for cpCircleConstants
// Created
//   - CopyPaste � 20220308 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220308 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Toolkit;
using System;
using System.Windows.Forms;

namespace UsingConstAndReadonly
{

  class cpProgram
	{

    static void Main()
    //***
    // Action
    //   - Create an instance of cpCircleConstants
    //   - Set a random radius between 1 and 19 (borders included)
    //   - Use it to calculate the circumference
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpCircleConstants.cdblPI()
    //   - cpCircleConstants.New(int)
    //   - cpCircleConstants.rointRadius()
    // Created
    //   - CopyPaste � 20220308 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220308 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Random rndNumber = new Random();
      cpCircleConstants thecpCircle = new cpCircleConstants(rndNumber.Next(1, 20));
      string strRadius = Convert.ToString(thecpCircle.rointRadius);
      string strOutput = "Radius = " + strRadius + "\nCircumference = " + String.Format("{0:N3}", thecpCircle.rointRadius * 2 * cpCircleConstants.cdblPI);

      MessageBox.Show(strOutput, "Circumference", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // Main()

	}
  // cpProgram

}
// UsingConstAndReadonly