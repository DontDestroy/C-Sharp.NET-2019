//***
// Action
//   - The definition of a cpEmployee
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   - Abstract means that you have to override it again in classes that inherit, this class can't be used to construct objects
//   - Sealed means that you can't inherit it again
//***

using System;

namespace CopyPaste.Organigram
{

  public class cpEmployee
  // public abstract class cpEmployee
  // public sealed class cpEmployee
  {

    #region "Constructors / Destructors"
    
    public cpEmployee()
      //***
      // Action
      //   - Empty constructor of cpEmployee
      // Called by
      //   - cpExecutive()
      //   - cpSecretary()
      //   - frmInheritance.cmdEmployee_Click(System.Object, System.EventArgs) Handles cmdEmployee.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpEmployee()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private decimal mdecSalary;

    #endregion

    #region "Properties"

    public decimal Salary
    {

      get
        //***
        // Action Get
        //   - Returns mdecSalary
        // Called by
        //   - cpExecutive.IncrementSalary(System.Single)
        //   - cpSecretary.IncrementSalary(System.Single)
        //   - frmInheritance.cmdCEO_Click(System.Object, System.EventArgs) Handles cmdCEO.Click
        //   - frmInheritance.cmdEmployee_Click(System.Object, System.EventArgs) Handles cmdEmployee.Click
        //   - frmInheritance.cmdSecretary_Click(System.Object, System.EventArgs) Handles cmdSecretary.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230804 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230804 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecSalary;
      }
      // decimal Salary (Get)

      set
        //***
        // Action Get
        //   - mdecSalary becomes value
        // Called by
        //   - cpExecutive.IncrementSalary(System.Single)
        //   - cpSecretary.IncrementSalary(System.Single)
        //   - frmInheritance.cmdCEO_Click(System.Object, System.EventArgs) Handles cmdCEO.Click
        //   - frmInheritance.cmdEmployee_Click(System.Object, System.EventArgs) Handles cmdEmployee.Click
        //   - frmInheritance.cmdSecretary_Click(System.Object, System.EventArgs) Handles cmdSecretary.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230804 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230804 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mdecSalary = value;
      }
      // Salary(decimal) (Set)

    }
    // decimal Salary

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public virtual void IncrementSalary(System.Single sngPercent)
      // public abstract void IncrementSalary(System.Single sngPercent)
      // public sealed override void IncrementSalary(System.Single sngPercent)
      //***
      // Action
      //   - The current salary of the employee is changed with a certain sngPercent
      // Called by
      //   - frmInheritance.cmdEmployee_Click(System.Object, System.EventArgs) Handles cmdEmployee.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - Abstract means that you have to override it again in classes that inherit, there can't be a body to this code
      //   - Sealed means that you can't override it again in classes that inherit, it does not make sense in this example, because it must also override a virtual method
      //***
    {
      mdecSalary = mdecSalary * (1 + Convert.ToDecimal(sngPercent));
    }
    // IncrementSalary(System.Single)

    #endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpEmployee

}
// CopyPaste.Organigram