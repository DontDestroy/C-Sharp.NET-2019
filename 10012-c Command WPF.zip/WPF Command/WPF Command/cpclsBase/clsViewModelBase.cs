﻿//***
// Action
//   - Class implements the View Model Base
//   - Triggers the changes of properties
//   - Returns the rows affected
// Created
//   - CopyPaste – 20210809 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210809 – VVDW
// Proposal(To Do)
//   -List of actions that can be added to the functionality
//***

namespace WPFCommand
{
  public class cpViewModelBase : cpCommon
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    private int _intRowsAffected;
    private string _strResultText;
    #endregion

    #region "Properties"

    public string ResultText
    {
      get
      //***
      // Action Get
      //   - Returns _strResultText
      // Called by
      //   -
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20210809 – VVDW
      // Changed
      //   - Organisation – yyyymmdd – Initials of programmer – What changed
      // Tested
      //   - CopyPaste – 20210809 – VVDW
      // Keyboard Key
      //   -
      // Proposal(To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _strResultText;
      }
      // string ResultText() (Get)

      set
      //***
      // Action Set
      //   - _strResultText becomes strValue
      //   - RaisePropertyChanged is triggered
      // Called by
      //   - int cpCommandViewModel.GetProductsCountScalar()
      //   - int cpCommandViewModel.GetProductsCountScalarUsingParameters()
      //   - int cpCommandViewModel.InsertProduct()
      //   - int cpCommandViewModel.InsertProductOutputParameters()
      //   - int cpCommandViewModel.InsertProductUsingParameters()
      //   - int cpCommandViewModel.TransactionProcessing()
      // Calls
      //   - cpCommon.RaisePropertyChanged(String)
      // Created
      //   - CopyPaste – 20210809 – VVDW
      // Changed
      //   - Organisation – yyyymmdd – Initials of programmer – What changed
      // Tested
      //   - CopyPaste – 20210809 – VVDW
      // Keyboard Key
      //   -
      // Proposal(To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        _strResultText = value;
        RaisePropertyChanged("ResultText");
      }
      // ResultText(string) (Set)
    }
    // string ResultText

    public int RowsAffected
    {
      get
      //***
      // Action Get
      //   - Returns _intRowsAffected
      // Called by
      //   - int cpCommandViewModel.GetProductsCountScalar()
      //   - int cpCommandViewModel.GetProductsCountScalarUsingParameters()
      //   - int cpCommandViewModel.InsertProduct()
      //   - int cpCommandViewModel.InsertProductOutputParameters()
      //   - int cpCommandViewModel.InsertProductUsingParameters()
      //   - int cpCommandViewModel.TransactionProcessing()
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20210809 – VVDW
      // Changed
      //   - Organisation – yyyymmdd – Initials of programmer – What changed
      // Tested
      //   - CopyPaste – 20210809 – VVDW
      // Keyboard Key
      //   -
      // Proposal(To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _intRowsAffected;
      }
      // int RowsAffected (Get)

      set
      //***
      // Action Set
      //   - _intRowsAffected becomes intValue
      //   - RaisePropertyChanged is triggered
      // Called by
      //   - int cpCommandViewModel.GetProductsCountScalar()
      //   - int cpCommandViewModel.GetProductsCountScalarUsingParameters()
      //   - int cpCommandViewModel.InsertProduct()
      //   - int cpCommandViewModel.InsertProductOutputParameters()
      //   - int cpCommandViewModel.InsertProductUsingParameters()
      //   - int cpCommandViewModel.TransactionProcessing()
      // Calls
      //   - cpCommon.RaisePropertyChanged(String)
      // Created
      //   - CopyPaste – 20210809 – VVDW
      // Changed
      //   - Organisation – yyyymmdd – Initials of programmer – What changed
      // Tested
      //   - CopyPaste – 20210809 – VVDW
      // Keyboard Key
      //   -
      // Proposal(To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        _intRowsAffected = value;
        RaisePropertyChanged("RowsAffected");
      }
      // RowsAffected(int) (Set)

    }
    // string RowsAffected

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpViewModelBase 

}
// WPFCommand