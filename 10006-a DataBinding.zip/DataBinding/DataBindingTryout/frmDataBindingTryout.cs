//***
// Action
//   - Bind the data set information to controls on the form
// Created
//   - CopyPaste � 20251119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251119 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDataBindingTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.DataGrid dgrDataGrid;
    internal System.Windows.Forms.TextBox txtIdEmployee;
    internal System.Windows.Forms.TextBox txtTitle;
    internal System.Windows.Forms.ComboBox cmbEmployee;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataBindingTryout));
      this.dgrDataGrid = new System.Windows.Forms.DataGrid();
      this.txtIdEmployee = new System.Windows.Forms.TextBox();
      this.txtTitle = new System.Windows.Forms.TextBox();
      this.cmbEmployee = new System.Windows.Forms.ComboBox();
      ((System.ComponentModel.ISupportInitialize)(this.dgrDataGrid)).BeginInit();
      this.SuspendLayout();
      // 
      // dgrDataGrid
      // 
      this.dgrDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrDataGrid.DataMember = "";
      this.dgrDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrDataGrid.Location = new System.Drawing.Point(21, 124);
      this.dgrDataGrid.Name = "dgrDataGrid";
      this.dgrDataGrid.Size = new System.Drawing.Size(366, 118);
      this.dgrDataGrid.TabIndex = 7;
      // 
      // txtIdEmployee
      // 
      this.txtIdEmployee.Location = new System.Drawing.Point(874, 29);
      this.txtIdEmployee.Name = "txtIdEmployee";
      this.txtIdEmployee.Size = new System.Drawing.Size(166, 38);
      this.txtIdEmployee.TabIndex = 6;
      this.txtIdEmployee.TextChanged += new System.EventHandler(this.txtIdEmployee_TextChanged);
      // 
      // txtTitle
      // 
      this.txtTitle.Location = new System.Drawing.Point(437, 29);
      this.txtTitle.Name = "txtTitle";
      this.txtTitle.Size = new System.Drawing.Size(416, 38);
      this.txtTitle.TabIndex = 5;
      // 
      // cmbEmployee
      // 
      this.cmbEmployee.Location = new System.Drawing.Point(21, 29);
      this.cmbEmployee.Name = "cmbEmployee";
      this.cmbEmployee.Size = new System.Drawing.Size(395, 39);
      this.cmbEmployee.TabIndex = 4;
      // 
      // frmDataBindingTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(13, 31);
      this.ClientSize = new System.Drawing.Size(408, 273);
      this.Controls.Add(this.cmbEmployee);
      this.Controls.Add(this.dgrDataGrid);
      this.Controls.Add(this.txtIdEmployee);
      this.Controls.Add(this.txtTitle);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataBindingTryout";
      this.Text = "ADO Binding Example Tryout";
      this.Activated += new System.EventHandler(this.frmDataBinding_Activated);
      ((System.ComponentModel.ISupportInitialize)(this.dgrDataGrid)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDataBinding'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDataBindingTryout()
      //***
      // Action
      //   - Create instance of 'frmDataBindingTryout'
      //   - Setup the data
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      //   - SetUpData
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDataBinding()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmDataBinding_Activated(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The setup of the grid is executed
      // Called by
      //   - User action (The form is activated)
      // Calls
      //   - SetUpGrid()
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmDataBinding_Activated(System.Object, System.EventArgs) Handles frmDataBinding.Activated

    private void txtIdEmployee_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The setup of the grid is executed
      // Called by
      //   - User action or system action (Text of the key of the employee is changed)
      // Calls
      //   - SetUpGrid()
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // txtIdEmployee_TextChanged(System.Object, System.EventArgs) Handles txtIdEmployee.TextChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDataBinding
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDataBinding()
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDataBindingTryout());
    }
    // Main() 
    
    private void SetUpData()
      //***
      // Action
      //   - Define two data tables (one for employees, one for orders
      //   - Define a relation
      //   - Define two data columns (one for the master (one), one for the child (many)
      //   - Fill the information of tblCPEmployee in the data set
      //   - Fill the information of tblCPOrder in the data set
      //   - Initialize the table for the employees
      //   - Initialize the table for the orders
      //   - Initialize the master column
      //   - Initialize the child column
      //   - Create the relation between the two tables using the master and child column
      //   - Add the relation to the data set
      //   - Bind the employee table to the combobox of employees
      //   - Show the last name
      //   - Bind the title of the employee to the textbox txtTitle
      //   - Bind the key of the employee to the textbox txtIdEmployee
      //   - Create a new data view on orders
      // Called by
      //   - frmDataBinding()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // SetUpData()

    private void SetUpGrid()
      //***
      // Action
      //   - A rowfilter on the data view is triggered
      //     - Filter is the key of the employee
      //   - The data source of the data grid becomes the filtered data
      // Called by
      //   - frmDataBinding_Activated(System.Object, System.EventArgs) Handles MyBase.Activated
      //   - txtIdEmployee_TextChanged(System.Object, System.EventArgs) Handles txtIdEmployee.TextChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251119 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // SetUpGrid()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataBindingTryout

}
// CopyPaste.Learning