//***
// Action
//   - Implementation of cpEmployee
// Created
//   - CopyPaste � 20240608 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240608 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning.Employee
{

  public class cpEmployee
  {

    #region "Constructors / Destructors"

    public cpEmployee() : base()
      //***
      // Action
      //   - Basic constructor
      //   - Create an Object
      //   - Add one to the number of employees
      //   - Use the result to determine the employee number
      // Called by
      //   - cpDivision()
      //   - cpEmployee(string, string)
      // Calls
      //   - Object()
      // Created
      //   - CopyPaste � 20240608 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240608 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      gintTotalEmployees += 1;
      mintEmployeeNumber = gintTotalEmployees;
    }
    // cpEmployee()

    public cpEmployee(string strFirstName, string strLastName) : this()
      //***
      // Action
      //   - Basic constructor with 2 parameters
      //   - Use the basic constructor
      //     - Add one to the number of employees
      //     - Use the result to determine the employee number
      //   - Set the first name
      //   - Set the last name
      // Called by
      //   - cpDivision(string, string)
      // Calls
      //   - cpEmployee()
      //   - FirstName(string) (Set)
      //   - LastName(string) (Set)
      // Created
      //   - CopyPaste � 20240608 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240608 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      FirstName = strFirstName;
      LastName = strLastName;
    }
    // cpEmployee(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static int gintTotalEmployees = 0;
    private bool mblnCSharpNETTrained = false;
    private int mintEmployeeNumber = 0;
    private string mstrFirstName = "";
    private string mstrLastName = "";

    #endregion

    #region "Properties"

    public bool CSharpNet
    {

      get
        //***
        // Action Get
        //   - Returns if C# NET is trained
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240608 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240608 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mblnCSharpNETTrained;
      }
      // bool CSharpNet (Get)

      set
        //***
        // Action Set
        //   - C# NET Trained becomes value
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240608 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240608 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mblnCSharpNETTrained = value;
      }
      // CSharpNet(bool) (Set)

    }
    // bool CSharpNet

    public int EmployeeNumber
    {

      get
        //***
        // Action Get
        //   - Returns the employee number
        // Called by
        //   - cpProgram.ShowEmployee(cpDivision)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240608 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240608 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mintEmployeeNumber;
      }
      // int EmployeeNumber (Get)

    }
    // int EmployeeNumber

    public string FirstName
    {

      get
        //***
        // Action Get
        //   - Returns the first name
        // Called by
        //   - bool Serialize()
        //   - cpProgram.ShowEmployee(cpDivision)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240608 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240608 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrFirstName;
      }
      // string FirstName (Get)

      set
        //***
        // Action Set
        //   - First name becomes value
        // Called by
        //   - cpProgram.Main()
        //   - cpEmployee(string, string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240608 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240608 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrFirstName = value;
      }
      // FirstName(string) (Set)

    }
    // string FirstName

    public string LastName
    {

      get
        //***
        // Action Get
        //   - Returns the last name
        // Called by
        //   - bool Serialize()
        //   - cpProgram.ShowEmployee(cpDivision)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240608 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240608 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrLastName;
      }
      // string LastName (Get)

      set
        //***
        // Action Set
        //   - Last name becomes value
        // Called by
        //   - cpProgram.Main()
        //   - cpEmployee(string, string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240608 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240608 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrLastName = value;
        }
      // LastName(string) (Set)

    }
    // string LastName

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public virtual bool Serialize()
      //***
      // Action
      //   - Checks if the object (cpEmployee) is serializable or not
      // Called by
      //   - bool cpEmployee.Serialize()
      // Calls
      //   - string FirstName (Get)
      //   - string LastName (Get)
      // Created
      //   - CopyPaste � 20240608 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240608 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;

      if ((FirstName == "") || (LastName == ""))
      {
        blnResult = false;
      }
      else
        // ((FirstName <> "") && (LastName <> ""))
      {
        blnResult = true;
      }
      // ((FirstName = "") || (LastName = ""))

      return blnResult;
    }
    // bool Serialize()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpEmployee

}
// CopyPaste.Learning.Employee