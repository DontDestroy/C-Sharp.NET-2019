﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmElixirs.aspx.cs" Inherits="CopyPaste.Learning.wfrmElixirs" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Copy Paste Elixirs</title>
</head>
<body>
  <form id="wfrmElixirs" runat="server">
    <h1>Our Elixirs</h1>

    <h2>Green Tea Cooler</h2>
    <img src="resources/Green.jpg">
    <p>
      Chock full of vitamins and minerals, this elixir combines the healthful benefits of green tea with a twist of chamomile blossoms and ginger root.
    </p>
    <h2>Raspberry Ice Concentration</h2>
    <img src="resources/LightBlue.jpg">
    <p>
      Combining raspberry juice with lemon grass, citrus peel and rosehips, this icy drink will make your mind feel clear and crisp.
    </p>
    <h2>Blueberry Bliss Elixir</h2>
    <img src="resources/Blue.jpg">
    <p>
      Blueberries and cherry essence mixed into a base of elderflower herb tea will put you in a relaxed state of bliss in no time.
    </p>
    <h2>Cranberry Antioxidant Blast</h2>
    <p>
    <img src="resources/Red.jpg">
      Wake up to the flavors of cranberry and hibiscus in this vitamin C rich elixir. Did you notice the difference of this image?
    </p>
    <p>
      Go back to <a href="wfrmHomePage.aspx">Home</a>
    </p>
  </form>
</body>
</html>
