//***
// Action
//   - Implementation of cpTeacher
// Created
//   - CopyPaste � 20240525 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240525 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpTeacher : cpPerson
  {

    #region "Constructors / Destructors"

    public cpTeacher() : base()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - frmEmployee.cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click
      // Calls
      //   - cpPerson()
      // Created
      //   - CopyPaste � 20240525 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240525 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpTeacher()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private short mshtLevel;

    #endregion

    #region "Properties"

    public short Grade
    {

      get
        //***
        // Action Get
        //   - Returns mshtLevel
        // Called by
        //   - frmEmployee.cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240525 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240525 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mshtLevel;
      }
      // short Grade (Get)

      set
        //***
        // Action Set
        //   - mshtLevel becomes value
        // Called by
        //   - frmEmployee.cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240525 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240525 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mshtLevel = value;
      }
      // Grade(short) (Set)

    }
    // short Grade

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpTeacher

}
// CopyPaste.Learning