﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCalendar.aspx.cs" Inherits="CopyPaste.Learning.wfrmCalendar" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Calendar</title>
</head>
<body MS_POSITIONING="GridLayout">
  <form id="wfrmCalendar" method="post" runat="server">
    <asp:Calendar id="calSelectDay" style="Z-INDEX: 101; POSITION: absolute; TOP: 16px; LEFT: 24px"
      runat="server" Width="464px" DayNameFormat="Full"></asp:Calendar>
    <asp:Label id="lblSelectedDay" style="Z-INDEX: 102; POSITION: absolute; TOP: 216px; LEFT: 24px"
      runat="server" Width="464px"></asp:Label>
  </form>
</body>
</html>
