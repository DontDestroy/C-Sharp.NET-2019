//***
// Action
//   - Example of functions
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Function
{

  class cpFunction
	{

    static void Main()
    //***
    // Action
    //   - Fill some variables with functions
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - double GetBookPrice()
    //   - string GetBookTitle()
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(double)
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      double dblPrice;
      string strTitle;
      
      dblPrice = GetBookPrice();
      strTitle = GetBookTitle();
      
      Console.WriteLine(dblPrice);
      Console.WriteLine(strTitle);
      
      Console.WriteLine(GetBookPrice());
      Console.WriteLine(GetBookTitle());
      
      if (GetBookPrice() == 49.99)
      {
        Console.WriteLine("The book is 49.99");
      }
      else
        // GetBookPrice() <> 49.99
      {
      }
      // GetBookPrice() = 49.99
      
      Console.ReadLine();
    }
    // Main()

    static double GetBookPrice()
    //***
    // Action
    //   - Get a book price
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return 49.99;
    }
    // double GetBookPrice()

    static string GetBookTitle()
    //***
    // Action
    //   - Get a book title
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return "C# .Net Programming Tips & Techniques";
    }
    // string GetBookTitle()

  }
  // cpFunction

}
// Function