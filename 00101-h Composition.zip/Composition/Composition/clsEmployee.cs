//***
// Action
//   - Define a cpEmployee (FirstName, LastName, BirthDate and HireDate)
//   - A constructor and a presentation
// Created
//   - CopyPaste � 20220308 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220308 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Toolkit;
using System;

namespace Composition
{

  public class cpEmployee
	{

    #region "Constructors / Destructors"

    public cpEmployee(string strFirstName, string strLastName, 
      int intBirthDay, int intBirthMonth, int intBirthYear,
      int intHireDay, int intHireMonth, int intHireYear)
    //***
    // Action
    //   - Create a new instance of cpEmployee
    //   - Define the FirstName and LastName
    //   - Create a BirthDay (cpDay)
    //   - Create a HireDay (cpDay)
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - cpDay(int, int, int)
    // Created
    //   - CopyPaste � 20220308 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220308 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      mstrFirstName = strFirstName;
      mstrLastName = strLastName;
      
      mcpBirthDate = new cpDay(intBirthDay, intBirthMonth, intBirthYear);
      mcpHireDate = new cpDay(intHireDay, intHireMonth, intHireYear);
    }
    // cpEmployee(string, string, int, int, int, int, int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpDay mcpBirthDate;
    private cpDay mcpHireDate;
    private string mstrFirstName;
    private string mstrLastName;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string ToStandardString()
    //***
    // Action
    //   - Return a string that defines the value of cpEmployee
    // Called by
    //   - 
    // Calls
    //   - string cpDay.ToStandardString()
    // Created
    //   - CopyPaste � 20220308 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220308 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //  - 
    //***
    {
      return mstrLastName + ", " + mstrFirstName + 
        " Hired: " + mcpHireDate.ToStandardString() +
        " Birthday: " + mcpBirthDate.ToStandardString();
    }
    // string ToStandardString()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpEmployee

}
// Composition