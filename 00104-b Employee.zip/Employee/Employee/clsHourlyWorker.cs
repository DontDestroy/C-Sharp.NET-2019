//***
// Action
//   - Definition of a cpHourlyWorker
// Created
//   - CopyPaste � 20230817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230817 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Company
{

  public class cpHourlyWorker : cpEmployee
  {

    #region "Constructors / Destructors"

    public cpHourlyWorker(string strFirstName, string strLastName, decimal decWage, double dblHour) : base(strFirstName, strLastName)
      //***
      // Action
      //   - Creates an employee with strFirstName and strLastName
      //   - Set the hourly wage to decWage
      //   - Set the hours to dblHour
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee(string, string)
      //   - HourlyWage(decimal) (Set)
      //   - Hours(double) (Set)
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      HourlyWage = decWage;
      Hours = dblHour;
    }
    // cpHourlyWorker(string, string, decimal, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private double mdblHoursWorked;
    private decimal mdecWage;

    #endregion

    #region "Properties"

    public decimal HourlyWage
    {

      get
        //***
        // Action
        //   - Return the hourly wage
        // Called by
        //   - decimal Earnings()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecWage;
      }
      // decimal HourlyWage (Get)

      set
        //***
        // Action
        //   - Set the hourly wage to value
        //   - If hourly wage is negative, 0 becomes the value
        // Called by
        //   - cpHourlyWorker(string, string, decimal, double)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value > 0)
        {
          mdecWage = value;
        }
        else
          // value <= 0
        {
          mdecWage = 0;
        }
        // value > 0

      }
      // HourlyWage(decimal) (Set)

    }
    // decimal HourlyWage
    
    public double Hours
    {

      get
        //***
        // Action
        //   - Return the hours
        // Called by
        //   - decimal Earnings()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdblHoursWorked;
      }
      // double Hours (Get)

      set
        //***
        // Action
        //   - Set the hours to value
        //   - If hours is negative, 0 becomes the value
        // Called by
        //   - cpHourlyWorker(string, string, decimal, double)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value > 0)
        {
          mdblHoursWorked = value;
        }
        else
          // value <= 0
        {
          mdblHoursWorked = 0;
        }
        // value > 0

      }
      // Hours(double) (Set)

    }
    // double Hours
    
    #endregion

    #region "Methods"

    #region "Overrides"

    public override decimal Earnings()
      //***
      // Action
      //   - Calculate and return the earnings
      //   - If less or equal than 40 hours worked
      //     - Calculation is the hourly wage multiplied by the hours
      //   - If not
      //     - Calculation is the hourly wage multiplied by the hours added with the rest of the hours multiplied with 150%
      // Called by
      //   - 
      // Calls
      //   - decimal HourlyWage() (Get)
      //   - double Hours() (Get)
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (Hours <= 40)
      {
        return HourlyWage * Convert.ToDecimal(Hours);
      }
      else
        // Hours > 40
      {
        return (HourlyWage * Convert.ToDecimal(Hours)) + Convert.ToDecimal((Hours - 40)) * 1.5M * HourlyWage;
      }
      // Hours <= 40

    }
    // decimal Earnings()

    public override string ToString()
      //***
      // Action
      //   - Return description of a cpHourlyWorker
      // Called by
      //   - 
      // Calls
      //   - string cpEmployee.ToString()
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return "cpHourlyWorker: " + base.ToString();
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpHourlyWorker

}
// CopyPaste.Learning.Company