﻿//***
// Action
//   - Having DataAdapters and Commands towards a database
// Created
//   - CopyPaste – 20210706 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210706 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System.Windows.Forms;

namespace DataAdapters
{

  public partial class frmDataAdapters : Form
  {

    #region "Constructors / Destructors"

    public frmDataAdapters()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Setting commands (Delete, Insert, Update and Select) for Supplier
    //   - Set properties for mcmmSelectSupplier
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210706 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210706 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
      mdtaSupplier = new System.Data.SqlClient.SqlDataAdapter();
      mcmmDeleteSuppliers = new System.Data.SqlClient.SqlCommand();
      mcmmInsertSuppliers = new System.Data.SqlClient.SqlCommand();
      mcmmUpdateSuppliers = new System.Data.SqlClient.SqlCommand();
      mcmmSelectSuppliers = new System.Data.SqlClient.SqlCommand();

      mdtaSupplier.DeleteCommand = mcmmDeleteSuppliers;
      mdtaSupplier.InsertCommand = mcmmInsertSuppliers;
      mdtaSupplier.UpdateCommand = mcmmUpdateSuppliers;
      mdtaSupplier.SelectCommand = mcmmSelectSuppliers;
      mcmmSelectSuppliers.CommandText = "SELECT * FROM tblCPSupplier";
      mcmmSelectSuppliers.Connection = cnncpNorthwindScript;
    }
    // frmDataAdapters()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    internal System.Data.SqlClient.SqlCommand mcmmDeleteSuppliers;
    internal System.Data.SqlClient.SqlCommand mcmmInsertSuppliers;
    internal System.Data.SqlClient.SqlCommand mcmmSelectSuppliers;
    internal System.Data.SqlClient.SqlCommand mcmmUpdateSuppliers;
    internal System.Data.SqlClient.SqlDataAdapter mdtaSupplier;
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFillAll_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Clear Category Dataset
    //   - Clear Product Dataset
    //   - Fill Category Dataset with DataAdapter Category
    //   - Fill Product Dataset with DataAdapter Product
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210706 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210706 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.dsCategory.Clear();
      this.dsProduct.Clear();

      this.dtaCategory.Fill(this.dsCategory.tblCPCategory);
      this.dtaProduct.Fill(this.dsProduct.tblCPProduct);
    }
    // cmdFillAll_Click(System.Object, System.EventArgs)

    private void cmdUpdateCategory_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Clear message text
    //   - Update Category Dataset with DataAdapter Category
    // Called by
    //   - User action (Clicking a button) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210706 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210706 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.txtMessages.Text = "";
      this.dtaCategory.Update(dsCategory.tblCPCategory);
    }
    // cmdUpdateCategory_Click(System.Object, System.EventArgs)

    private void dtaCategory_RowUpdated(System.Object theSender, System.Data.SqlClient.SqlRowUpdatedEventArgs theSqlRowUpdatedEventArguments)
    //***
    // Action
    //   - Adapt message for every row updated in Dataset Category (Finished)
    // Called by
    //   - SQL action (Finished updating a Category Row) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210706 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210706 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.txtMessages.Text += "Update completed";
      this.txtMessages.Text += ", " + theSqlRowUpdatedEventArguments.RecordsAffected.ToString() + " record(s) updated.\r\n\r\n";
    }
    // dtaCategory_RowUpdated(System.Object, System.Data.SqlClient.SqlRowUpdatedEventArgs)

    private void dtaCategory_RowUpdating(System.Object theSender, System.Data.SqlClient.SqlRowUpdatingEventArgs theSqlRowUpdatingEventArguments)
    //***
    // Action
    //   - Adapt message for every row updated in Dataset Category (Started)
    // Called by
    //   - SQL action (Starting updating a Category Row) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210706 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210706 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      this.txtMessages.Text += "Beginning Update ...";
      this.txtMessages.Text += "\r\nExecuting a command of type " + theSqlRowUpdatingEventArguments.StatementType.ToString() + "\r\n";
    }
    // dtaCategory_RowUpdating(System.Object, System.Data.SqlClient.SqlRowUpdatingEventArgs)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataAdapters

}
// DataAdapters