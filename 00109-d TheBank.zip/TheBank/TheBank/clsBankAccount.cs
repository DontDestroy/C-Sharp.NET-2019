//***
// Action
//   - Implementation of cpBankAccount
// Created
//   - CopyPaste � 20240221 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240221 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpBankAccount
  {

    #region "Constructors / Destructors"

    public cpBankAccount(string strOwner)
      //***
      // Action
      //   - Constructor of a cpBankAccount that defines an owner
      // Called by
      //   - cpCheckingAccount(string)
      //   - cpSavingsAccount(string)
      //   - frmBankAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mstrOwner = strOwner;
      mdecBalance = 0M;
    }
    // cpBankAccount(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    protected string mstrOwner;
    private decimal mdecBalance;

    #endregion

    #region "Properties"

    public decimal Balance
    {

      get
        //***
        // Action Get
        //   - Returns the balance of a cpBankAccount
        // Called by
        //   - cpSavingsAccount.AddInterest()
        //   - frmBankAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
        //   - frmCheckingAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
        //   - frmSavingsAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
        //   - frmTheBank.cmdAddInterest_Click(System.Object, System.EventArgs) Handles cmdAddInterest.Click
        //   - frmTheBank.cmdSubmit_Click(System.Object, System.EventArgs) Handles cmdSubmit.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240221 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240221 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecBalance;
      }
      // decimal Balance (Get)

    }
    // decimal Balance

    public virtual string Id
    {
      
      get
        //***
        // Action Get
        //   - Returns the Id (owner) of a cpBankAccount
        // Called by
        //   - frmBankAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
        //   - frmTheBank.cmdAddInterest_Click(System.Object, System.EventArgs) Handles cmdAddInterest.Click
        //   - frmTheBank.cmdSubmit_Click(System.Object, System.EventArgs) Handles cmdSubmit.Click
        //   - string cpCheckingAccount.Id (Get)
        //   - string cpSavingsAccount.Id (Get)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240221 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240221 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrOwner;
      }
      // string Id (Get)

    }
    // string Id

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Deposit(decimal decAmount)
      //***
      // Action
      //   - A certain amount (decAmount) is added to the balance of the cpBankAccount
      // Called by
      //   - cpSavingsAccount.AddInterest()
      //   - frmBankAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmCheckingAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmSavingsAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmTheBank.cmdSubmit_Click(System.Object, System.EventArgs) Handles cmdSubmit.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mdecBalance += decAmount;
    }
    // Deposit(decimal)
		
    public virtual void Withdraw(decimal decAmount)
      //***
      // Action
      //   - A certain amount (decAmount) is removed from the balance of the cpBankAccount
      // Called by
      //   - cpCheckingAccount.Withdraw(decimal)
      //   - frmBankAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmSavingsAccountTest_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmTheBank.cmdSubmit_Click(System.Object, System.EventArgs) Handles cmdSubmit.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240221 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240221 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mdecBalance -= decAmount;
    }
    // Withdraw(decimal)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBankAccount

}
// CopyPaste.Learning