//***
// Action
//   - Start a form and show some info about the application
// Created
//   - CopyPaste � 20250624 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250624 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmApplication: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    internal System.Windows.Forms.Button cmdStop;
    internal System.Windows.Forms.Button cmdStart;
    internal System.Windows.Forms.Label lblProductInfo;
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmApplication));
      this.cmdStop = new System.Windows.Forms.Button();
      this.cmdStart = new System.Windows.Forms.Button();
      this.lblProductInfo = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdStop
      // 
      this.cmdStop.Location = new System.Drawing.Point(311, 240);
      this.cmdStop.Name = "cmdStop";
      this.cmdStop.TabIndex = 5;
      this.cmdStop.Text = "S&top";
      this.cmdStop.Click += new System.EventHandler(this.cmdStop_Click);
      // 
      // cmdStart
      // 
      this.cmdStart.Location = new System.Drawing.Point(311, 168);
      this.cmdStart.Name = "cmdStart";
      this.cmdStart.TabIndex = 4;
      this.cmdStart.Text = "&Start";
      this.cmdStart.Click += new System.EventHandler(this.cmdStart_Click);
      // 
      // lblProductInfo
      // 
      this.lblProductInfo.Location = new System.Drawing.Point(15, 176);
      this.lblProductInfo.Name = "lblProductInfo";
      this.lblProductInfo.Size = new System.Drawing.Size(280, 88);
      this.lblProductInfo.TabIndex = 3;
      // 
      // frmApplication
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(400, 273);
      this.Controls.Add(this.cmdStop);
      this.Controls.Add(this.cmdStart);
      this.Controls.Add(this.lblProductInfo);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmApplication";
      this.Text = "The Application";
      this.Load += new System.EventHandler(this.frmApplication_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmApplication'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250624 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250624 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmApplication()
      //***
      // Action
      //   - Create instance of 'frmApplication'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250624 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250624 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmApplication()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private bool mblnRun = false;
    private int mlngCounter = 0;
    private string mstrPath = Application.ExecutablePath;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmApplication_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Get the location where the executable is saved
      //   - Set the title of the form to that location
      //   - Get the product name and show it on the screen 
      //   - Get the product version and show it on the screen 
      //   - Get the company name and show it on the screen 
      // Called by
      //   - User action (Starting a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250624 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250624 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strMessage;
      string strSamePath = Application.ExecutablePath;
      
      this.Text = mstrPath;
      strMessage = "Product : " + Application.ProductName + Environment.NewLine;
      strMessage += "Version : " + Application.ProductVersion + Environment.NewLine;
      strMessage += "Company : " + Application.CompanyName;
      lblProductInfo.Text = strMessage;
    }
    // frmApplication_Load(System.Object, System.EventArgs) Handles MyBase.Load

    private void cmdStart_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - A boolean is set to True (mblnRun)
      //   - cmdStart is disabled
      //   - cmdStop gets the focus
      //   - dtmStart is the current moment
      //   - Loop as long mblnRun is true
      //     - A counter is incremented by one
      //     - A text of the form is adapted
      //     - The system waits it it is executed
      //   - dtmStop is the current moment
      //   - Calculate the time between dtmStop and dtmStart
      //   - Set the text to the screen with the number reached and the seconds elapsed
      //   - Set the counter back to zero
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250624 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250624 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DateTime dtmStart;
      DateTime dtmStop;
      TimeSpan theTimeSpan;

      mblnRun = true;
      cmdStart.Enabled = false;
      cmdStop.Focus();
      
      dtmStart = DateTime.Now;

      while (mblnRun)
      {
        mlngCounter += 1;
        this.Text = mlngCounter + " " + mstrPath;
        Application.DoEvents();
      }
      // Not mblnRun

      // for (lngCounter = 0; lngCounter <= 1000000; lngCounter++)
      // {
      // }
      // // lngCounter = 1000001

      // for (lngCounter = 0; lngCounter <= 1000000; lngCounter++)
      // {
      //   Application.DoEvents()
      // }
      // // lngCounter = 1000001
      
      dtmStop = DateTime.Now;
      theTimeSpan = dtmStop - dtmStart;
      
      this.Text = "Loop interrupted after " + mlngCounter + " iterations. " + theTimeSpan.TotalSeconds + " seconds.";
      mlngCounter = 0;
    }
    // cmdStart_Click(System.Object, System.EventArgs) Handles cmdStart.Click

    private void cmdStop_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - cmdStart is enabled
      //   - mdblRun becomes false
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250624 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250624 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cmdStart.Enabled = true;
      mblnRun = false;    
    }
    // cmdStop_Click(System.Object, System.EventArgs) Handles cmdStop.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmApplication
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDefault()
      // Created
      //   - CopyPaste � 20250624 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250624 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmApplication());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmApplication

}
// CopyPaste.Learning