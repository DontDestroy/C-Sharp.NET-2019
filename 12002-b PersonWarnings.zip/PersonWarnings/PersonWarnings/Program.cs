﻿//***
// Action
//   - Create a database based on the class cpWarning using Entity Framework Core (version 5.0.17) (when needed)
//   - Later a migration is done, a cpPerson is added to the warning
//   - Fill two tables with data
//   - Query the two tables 
// Created
//   - CopyPaste – 20230406 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230406 – VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace PersonWarnings
{

  public class cpProgram
  {

    public static void Main()
    //***
    // Action
    //   - Create a cpApplicationDatabaseContext
    //   - Read data from the database
    //   - Cleaning up the cpApplicationDatabaseContext
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - ReadTestData(cpApplicationDatabaseContext)
    // Created
    //   - CopyPaste – 20230406 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230406 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      using (cpApplicationDatabaseContext theDatabaseContext = new cpApplicationDatabaseContext())
      {
        ReadTestData(theDatabaseContext);
        // Read data from first from onlye one table thru the context
        // Read data from the two tables thru the context
        Console.ReadLine();
      }
      // cpApplicationDatabaseContext theDatabaseContext

    }
    // Main()

    public static void ReadTestData(cpApplicationDatabaseContext theDatabaseContext)
    //***
    // Action
    //   - Reads all the warnings
    //   - AsNoTracking() says this is a read-only access
    //   - After the second migration
    //   -   The include causes the cpAuthor information to be loaded with each cpWarning
    //   - Loop thru all the books
    // Called by
    //   - Main()
    // Calls
    //   - cpApplicationDatabaseContext.DbSet<cpWarning> cpWarning (Get)
    //   - cpPerson cpWarning.Person (Get)
    //   - string cpPerson.strName (Get)
    //   - string cpWarning.strName (Get)
    // Created
    //   - CopyPaste – 20230406 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230406 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      // After first migration (when there is some data)
      //foreach (cpWarning aWarning in theDatabaseContext.cpWarning.AsNoTracking())
      //{
      //  Console.WriteLine($"{aWarning.strName}");
      //  Console.WriteLine($"  More info: {aWarning.strDescription}");
      //}
      //// in theDatabaseContext.cpWarning.AsNoTracking()

      // After second migration (when there is some data)
      foreach (cpWarning aWarning in theDatabaseContext.cpWarning.AsNoTracking().Include(theWarning => theWarning.Person))
      {

        if (aWarning.Person == null)
        {
        }
        else
        // aWarning.Person <> null
        {
        }
        // aWarning.Person = null

        if (aWarning.Person == null)
        {
          Console.WriteLine($"{aWarning.strName} for an unknown person");
          Console.WriteLine($"  More info: {aWarning.strDescription}");
        }
        else
        // aWarning.Person <> null
        {
          Console.WriteLine($"{aWarning.strName} by {aWarning.Person.strName}");
          Console.WriteLine($"  More info: {aWarning.strDescription}");
        }
        // aWarning.Person = null

        Console.WriteLine();
      }
      // in theDatabaseContext.cpWarning.AsNoTracking().Include(theWarning => theWarning.Person)

    }
    // ReadTestData(cpApplicationDatabaseContext)

  }
  // cpProgram

}
// PersonWarnings
