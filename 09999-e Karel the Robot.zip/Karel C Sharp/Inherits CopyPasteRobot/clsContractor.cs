﻿//***
// Action
//   - A definition of a Contractor
// Created
//   - CopyPaste – 20251104 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251104 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpContractor : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpContractor(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpContractor starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpContractor(int, int, Directions.Direction, int) 
    //   - cpProgram.Contractor()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpContractor(int, int, Directions.Direction, int, Color) 

    public cpContractor(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpContractor starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpContractor(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpContractor(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpMason bobTheBuilder = new cpMason(1, 1, Directions.East, Directions.infinity, Color.red);
    private cpCarpenter josephTheCarpenter = new cpCarpenter(1, 1, Directions.East, Directions.infinity, Color.yellow);
    private cpRoofer fidlerTheRoofer = new cpRoofer(1, 1, Directions.East, Directions.infinity, Color.blue);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void BuildHouse()
    //***
    // Action
    //   - Robot will make sure a house is build
    //   - All helpers are started to get to work
    //   - All helpers are switched off
    // Called by
    //   - cpProgram.Contractor()
    // Calls
    //   - cpCarpenter.GetToWork()
    //   - cpMason.GetToWork()
    //   - cpRoofer.GetToWork()
    //   - GatherTeam()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      GatherTeam();
      bobTheBuilder.GetToWork();
      bobTheBuilder.turnOff();
      josephTheCarpenter.GetToWork();
      josephTheCarpenter.turnOff();
      fidlerTheRoofer.GetToWork();
      fidlerTheRoofer.turnOff();
    }
    // BuildHouse()

    public void GatherTeam()
    //***
    // Action
    //   - Robot and the helpers will be placed at the origin to start work
    // Called by
    //   - BuildHouse()
    // Calls
    //   - cpCopyPasteRobot.GoToStartPosition()
    // Created
    //   - CopyPaste – 20251104 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251104 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bobTheBuilder.GoToStartPosition();
      josephTheCarpenter.GoToStartPosition();
      fidlerTheRoofer.GoToStartPosition();
    }
    // GatherTeam()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpContractor

}
// cpKarelTheRobot