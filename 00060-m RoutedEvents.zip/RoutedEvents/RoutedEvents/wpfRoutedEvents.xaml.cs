﻿//***
// Action
//   - A demo for routed events
//   - Option buttons are used to stop bubbling up
// Created
//   - CopyPaste – 20220902 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220902 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace RoutedEvents
{

  public partial class wpfRoutedEvents : Window
  {

    #region "Constructors / Destructors"

    public wpfRoutedEvents()
    //***
    // Action
    //   - Create instance of 'wpfRoutedEvents'
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220902 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220902 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfRoutedEvents()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void grdWindow_TextChanged(System.Object theSender, System.Windows.Controls.TextChangedEventArgs theTextChangedEventArguments)
    //***
    // Action
    //   - Show messagebox to prove that event is handled
    //   - Stop bubbling (up) in the hierarchy, depending if the option is chosen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220902 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220902 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      MessageBox.Show("Event raised by Grid");
      theTextChangedEventArguments.Handled = (bool)optGrid.IsChecked;
    }
    // grdWindow_TextChanged(System.Object, System.Windows.Controls.TextChangedEventArgs) Handles TextBoxBase.TextChanged

    private void txtInput_TextChanged(System.Object theSender, System.Windows.Controls.TextChangedEventArgs theTextChangedEventArguments)
    //***
    // Action
    //   - Show messagebox to prove that event is handled
    //   - Stop bubbling (up) in the hierarchy, depending if the option is chosen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220902 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220902 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      MessageBox.Show("Event raised by TextBox");
      theTextChangedEventArguments.Handled = (bool)optTextBox.IsChecked;
    }
    // txtInput_TextChanged(System.Object, System.Windows.Controls.TextChangedEventArgs) Handles txtInput.TextChanged

    private void wndStartup_TextChanged(System.Object theSender, System.Windows.Controls.TextChangedEventArgs theTextChangedEventArguments)
    //***
    // Action
    //   - Show messagebox to prove that event is handled
    //   - Stop bubbling (up) in the hierarchy, depending if the option is chosen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220902 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220902 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      MessageBox.Show("Event raised by Window");
      theTextChangedEventArguments.Handled = (bool)optWindow.IsChecked;
    }
    // wndStartup_TextChanged(System.Object, System.Windows.Controls.TextChangedEventArgs) Handles TextBoxBase.TextChanged

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfRoutedEvents 

}
// RoutedEvents