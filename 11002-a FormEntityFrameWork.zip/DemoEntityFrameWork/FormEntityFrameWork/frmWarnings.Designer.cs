﻿//***
// Action
//   - Initialisation of a frmWarning
// Created
//   - CopyPaste – yyyymmdd – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – yyyymmdd – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

namespace FormEntityFrameWork
{

  partial class frmWarnings
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.IContainer components = null;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmWarnings));
      this.dgrWarnings = new System.Windows.Forms.DataGridView();
      this.bdsrcWarnings = new System.Windows.Forms.BindingSource(this.components);
      ((System.ComponentModel.ISupportInitialize)(this.dgrWarnings)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcWarnings)).BeginInit();
      this.SuspendLayout();
      // 
      // dgrWarnings
      // 
      this.dgrWarnings.AllowUserToOrderColumns = true;
      this.dgrWarnings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
      this.dgrWarnings.Location = new System.Drawing.Point(3, 3);
      this.dgrWarnings.Margin = new System.Windows.Forms.Padding(6);
      this.dgrWarnings.Name = "dgrWarnings";
      this.dgrWarnings.RowHeadersWidth = 82;
      this.dgrWarnings.RowTemplate.Height = 25;
      this.dgrWarnings.Size = new System.Drawing.Size(792, 444);
      this.dgrWarnings.TabIndex = 1;
      // 
      // bdsrcWarnings
      // 
      this.bdsrcWarnings.AllowNew = true;
      // 
      // frmWarnings
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(800, 450);
      this.Controls.Add(this.dgrWarnings);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmWarnings";
      this.Text = "List of warnings (Changes are not saved to database)";
      this.Load += new System.EventHandler(this.frmWarnings_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrWarnings)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcWarnings)).EndInit();
      this.ResumeLayout(false);

    }
    // InitializeComponent()

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmDefault'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – yyyymmdd – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – yyyymmdd – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing)
      {

        if (components == null)
        {
        }
        else
        // (components != null)
        {
          components.Dispose();
        }
        // (components == null)

      }
      else
      // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    public System.Windows.Forms.BindingSource bdsrcWarnings;
    public System.Windows.Forms.DataGridView dgrWarnings;
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmWarnings

}
// FormEntityFrameWork