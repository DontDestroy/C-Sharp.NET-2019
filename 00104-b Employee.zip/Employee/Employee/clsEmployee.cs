//***
// Action
//   - Definition of a cpEmployee
// Created
//   - CopyPaste � 20230817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230817 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Company
{

  public abstract class cpEmployee
	{

    #region "Constructors / Destructors"

    public cpEmployee(string strFirstName, string strLastName)
      //***
      // Action
      //   - Set the FirstName to strFirstName
      //   - Set the LastName to strLastName
      // Called by
      //   - cpBoss(string, string, decimal)
      //   - cpCommissionWorker(string, string, decimal, decimal, int)
      //   - cpHourlyWorker(string, string, decimal, double)
      //   - cpPieceWorker(string, string, decimal, int)
      // Calls
      //   - FirstName(string) (Set)
      //   - LastName(string) (Set)
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      FirstName = strFirstName;
      LastName = strLastName;
    }
    // cpEmployee(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrFirstName;
    private string mstrLastName;

    #endregion

    #region "Properties"

    public string FirstName
    {

      get
        //***
        // Action
        //   - Returns mstrFirstName
        // Called by
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrFirstName;
      }
      // string FirstName (Get)

      set
        //***
        // Action
        //   - mstrFirstName becomes value
        // Called by
        //   - cpEmployee(string, string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrFirstName = value;
      }
      // FirstName(string) (Set)

    }
    // string FirstName

    public string LastName
    {

      get
        //***
        // Action
        //   - Returns mstrLastName
        // Called by
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrLastName;
      }
      // string LastName (Get)

      set
        //***
        // Action
        //   - mstrLastName becomes value
        // Called by
        //   - cpEmployee(string, string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20230817 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20230817 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrLastName = value;
      }
      // LastName(string) (Set)

    }
    // string LastName

    #endregion

    #region "Methods"

    #region "Overrides"

    public abstract decimal Earnings();

    public override string ToString()
      //***
      // Action
      //   - Returns FirstName, a space and LastName
      // Called by
      //   - string cpBoss.ToString()
      //   - string cpCommissionWorker.ToString()
      //   - string cpHourlyWorker.ToString()
      //   - string cpPieceWorker.ToString()
      //   - string cpProgram.GetString(cpEmployee)
      // Calls
      //   - string FirstName (Get)
      //   - string LastName (Get)
      // Created
      //   - CopyPaste � 20230817 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230817 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return FirstName + " " + LastName;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpEmployee

}
// CopyPaste.Learning.Company