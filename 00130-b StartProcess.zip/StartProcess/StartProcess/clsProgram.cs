//***
// Action
//   - Start another process (Word application)
// Created
//   - CopyPaste � 20250628 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250628 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Diagnostics;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250628 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Define a new process
      //   - Set the filename of startinfo correct
      //   - Start a Word document based on a template
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250628 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Process theProcess = new Process();

      theProcess.StartInfo.FileName = "D:\\Templates\\cpKnowledge.dotm";
      theProcess.Start();

      // VVDW - Alternative
      // Process.Start("D:\\Templates\\cpKnowledge.dotm");
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning