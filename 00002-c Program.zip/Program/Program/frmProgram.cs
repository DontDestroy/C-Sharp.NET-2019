//***
// Action
//   - A screen with four controls on it
// Created
//   - CopyPaste � 20211018 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20211018 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Windows.Forms;

namespace Program
{

  public class frmProgram : System.Windows.Forms.Form
	{

    #region Windows Form Designer generated code
    internal System.Windows.Forms.Button cmdButton;
    internal System.Windows.Forms.RadioButton optOption;
    internal System.Windows.Forms.TextBox txtText;
    internal System.Windows.Forms.Label lblHello;

    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmProgram));
      this.cmdButton = new System.Windows.Forms.Button();
      this.optOption = new System.Windows.Forms.RadioButton();
      this.txtText = new System.Windows.Forms.TextBox();
      this.lblHello = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdButton
      // 
      this.cmdButton.Location = new System.Drawing.Point(96, 190);
      this.cmdButton.Name = "cmdButton";
      this.cmdButton.TabIndex = 7;
      this.cmdButton.Text = "Button1";
      // 
      // optOption
      // 
      this.optOption.Location = new System.Drawing.Point(40, 118);
      this.optOption.Name = "optOption";
      this.optOption.TabIndex = 6;
      this.optOption.Text = "RadioButton1";
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(160, 54);
      this.txtText.Name = "txtText";
      this.txtText.TabIndex = 5;
      this.txtText.Text = "TextBox1";
      // 
      // lblHello
      // 
      this.lblHello.Location = new System.Drawing.Point(32, 54);
      this.lblHello.Name = "lblHello";
      this.lblHello.TabIndex = 4;
      this.lblHello.Text = "Hello, user";
      // 
      // frmProgram
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdButton);
      this.Controls.Add(this.optOption);
      this.Controls.Add(this.txtText);
      this.Controls.Add(this.lblHello);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmProgram";
      this.Text = "Program";
      this.ResumeLayout(false);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmProgram'
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20211018 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20211018 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmProgram()
    //***
    // Action
    //   - Create instance of 'frmProgram'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20211018 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20211018 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmProgram
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20211018 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20211018 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmProgram());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmProgram

}
// Program