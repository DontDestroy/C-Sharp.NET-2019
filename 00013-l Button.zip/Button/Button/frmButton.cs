//***
// Action
//   - Demo of a button
//   - Reading a series of textfiles
// Created
//   - CopyPaste � 20240119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240119 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmButton: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.RichTextBox rtxtText;
    internal System.Windows.Forms.Button cmdButton;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmButton));
      this.rtxtText = new System.Windows.Forms.RichTextBox();
      this.cmdButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // rtxtText
      // 
      this.rtxtText.Location = new System.Drawing.Point(32, 24);
      this.rtxtText.Name = "rtxtText";
      this.rtxtText.Size = new System.Drawing.Size(264, 232);
      this.rtxtText.TabIndex = 2;
      this.rtxtText.Text = "";
      // 
      // cmdButton
      // 
      this.cmdButton.Location = new System.Drawing.Point(120, 272);
      this.cmdButton.Name = "cmdButton";
      this.cmdButton.TabIndex = 3;
      this.cmdButton.Text = "Button1";
      this.cmdButton.Click += new System.EventHandler(this.cmdButton_Click);
      // 
      // frmButton
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(328, 309);
      this.Controls.Add(this.rtxtText);
      this.Controls.Add(this.cmdButton);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmButton";
      this.Text = "Button";
      this.Load += new System.EventHandler(this.frmButton_Load);
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmButton'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240119 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240119 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmButton()
			//***
			// Action
			//   - Create instance of 'frmButton'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240119 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240119 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmButton()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

    public FileInfo[] marrFiles;
    public int mlngFileIndex;

		#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"

    
    private void cmdButton_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - 'mlngFileIndex' is added by one
      //   - If 'marrFiles'.'Length' = 'mlngFileIndex
      //     - Stop program
      //   - If Not
      //     - If 'marrFiles'.'Length' - 1 = mlngFileIndex
      //       - 'cmdButton'.'Text' becomes "Done"
      //     - If Not
      //       - 'cmdButton'.'Text' becomes "Done"
      //       - Load 'mlngFileIndex'th file and place it in textbox
      //       - Caption becomes first filename
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - RichTextBox.LoadFile(String, RichTextBoxStreamType)
      // Created
      //   - CopyPaste � 20240119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240119 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mlngFileIndex += 1;

      if (mlngFileIndex == marrFiles.Length)
      {
        this.Close();
      }
      else
        // mlngFileIndex <> marrFiles.Length
      {
        if (mlngFileIndex == marrFiles.Length - 1)
        {
          cmdButton.Text = "Done";
        }
        else
          //  mlngFileIndex <> marrFiles.Length - 1
        {
        }
        // mlngFileIndex = marrFiles.Length - 1

        rtxtText.LoadFile(marrFiles[mlngFileIndex].FullName, RichTextBoxStreamType.PlainText);
        this.Text = marrFiles[mlngFileIndex].FullName;
      }
      // mlngFileIndex = marrFiles.Length 
   
    }
    // cmdButton_Click(System.Object, System.EventArgs) Handles cmdButton.Click

    private void frmButton_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - 'marrFiles' is filled with ".txt" filenames of 'C:\'
      //   - If 'marrFiles'.'Length' = 0
      //     - Show message
      //     - Stop program
      //   - If Not
      //     - If 'marrFiles'.'Length' = 1
      //       - 'cmdButton'.'Text' becomes "Done"
      //     - If Not
      //       - 'cmdButton'.'Text' becomes "Done"
      //       - Load first file and place it in textbox
      //       - Caption becomes first filename
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - RichTextBox.LoadFile(String, RichTextBoxStreamType)
      //   - System.IO.FileInfo[] System.IO.DirectoryInfo(string).GetFiles(string)
      //   - System.Windows.Forms.DialogResult System.Windows.Forms.MessageBox.Show(string)
      // Created
      //   - CopyPaste � 20240119 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240119 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DirectoryInfo theDirectory = new DirectoryInfo("C:\\");

      marrFiles = theDirectory.GetFiles("*.txt");

      if (marrFiles.Length == 0)
      {
        MessageBox.Show("There is no text document at C:\\");
        this.Close();
      }
      else
        // marrFiles.Length <> 0
      {

        if (marrFiles.Length == 1)
        {
          cmdButton.Text = "Done";
        }
        else
          // marrFiles.Length <> 1
        {
          cmdButton.Text = "Next";
        }
        // marrFiles.Length = 1

        mlngFileIndex = 0;
        rtxtText.LoadFile(marrFiles[mlngFileIndex].FullName, RichTextBoxStreamType.PlainText);
        this.Text = marrFiles[mlngFileIndex].FullName;
      }
      // marrFiles.Length = 0
    
    }
    // frmButton_Load(System.Object, System.EventArgs) Handles frmButton.Load

		#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmButton
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmButton()
			// Created
			//   - CopyPaste � 20240119 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240119 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmButton());
		}
		// Main()
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmButton

}
// CopyPaste.Learning