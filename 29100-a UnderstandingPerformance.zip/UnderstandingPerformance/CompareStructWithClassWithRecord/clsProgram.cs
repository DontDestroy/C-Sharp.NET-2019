﻿//***
// Action
//   - A demo of benchmarking
//     - Used BenchMarkDotNet.Attributes
//       - BenchMarkDotNET and Microsoft.VisualStudio.DiagnosticksHub.BenchmarkDotNetDiagnosers are NuGet packages
//   - Comparing class, with struct, with record
//   - A demo of stopwatch
// Created
//   - CopyPaste – 20260525 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260525 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static cpPoint[] arrClass;
    private static int intNumberOfItems = 1_000_000;
    private static rcdPoint[] arrRecord;
    private static structPoint[] arrStruct;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private double ComputeLengthClass(in cpPoint thePoint)
      => Math.Sqrt(thePoint.X * thePoint.X + thePoint.Y * thePoint.Y);
    // RunSomeCodeWithBenchmarkPointClass()

    private double ComputeLengthRecord(in rcdPoint thePoint)
      => Math.Sqrt(thePoint.X * thePoint.X + thePoint.Y * thePoint.Y);
    // RunSomeCodeWithBenchmarkPointRecord()

    private double ComputeLengthStruct(in structPoint thePoint)
  => Math.Sqrt(thePoint.X * thePoint.X + thePoint.Y * thePoint.Y);
    // RunSomeCodeWithBenchmarkPointStruct()

    public static void Main()
    //***
    // Action
    //   - A demo of benchmarking (Time and Memory)
    //   - A demo of stopwatch
    //   - Using the cpTypeComparison class to compare class, struct and record
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpTypeComparison()
    //   - RunSomeCodeWithBenchmarkPointClass
    //   - RunSomeCodeWithStopWatch()
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      // BenchmarkRunner.Run<cpTypeComparison>();
      BenchmarkRunner.Run<cpProgram>();

      // RunSomeCodeWithStopWatch();

      // cpTypeComparison cpTypeComparison = new cpTypeComparison();

      // cpProgram myProgram = new cpProgram();
      // Console.WriteLine("Result of Class length {0:#,##0}", myProgram.RunSomeCodeWithBenchmarkPointClass());
      // Console.WriteLine();

      // Console.WriteLine("Result of Record length {0:#,##0}", myProgram.RunSomeCodeWithBenchmarkPointRecord());
      // Console.WriteLine();

      // Console.WriteLine("Result of Struct length {0:#,##0}", myProgram.RunSomeCodeWithBenchmarkPointStruct());
      // Console.WriteLine();

      Console.WriteLine("Hit any key");
      Console.ReadKey();
    }
    // Main()

    [BenchmarkAttribute]
    public double RunSomeCodeWithBenchmarkPointClass()
    //***
    // Action
    //   - Run the actual code with a benchmark
    //     - This will give you exact numbers
    // Called by
    //   - Main()
    // Calls
    //   - cpPoint(double, double)
    //   - double ComputeLengthClass(cpPoint)
    // Created
    //   - CopyPaste – 20260526 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260526 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      double dblLengthClassResult = 0;

      arrClass = Enumerable.Range(0, intNumberOfItems).Select(intNumber => new cpPoint(intNumber, intNumber)).ToArray();

      foreach (cpPoint thePoint in arrClass)
      {
        dblLengthClassResult += ComputeLengthClass(in thePoint);
      }
      // in arrClass

      return dblLengthClassResult;
    }
    // RunSomeCodeWithBenchmarkPointClass()

    [BenchmarkAttribute]
    public double RunSomeCodeWithBenchmarkPointRecord()
    //***
    // Action
    //   - Run the actual code with a benchmark
    //     - This will give you exact numbers
    // Called by
    //   - Main()
    // Calls
    //   - double ComputeLengthRecord(rcdPoint)
    //   - rcdPoint(double, double)
    // Created
    //   - CopyPaste – 20260526 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260526 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      double dblLengthRecordResult = 0;

      arrRecord = Enumerable.Range(0, intNumberOfItems).Select(intNumber => new rcdPoint(intNumber, intNumber)).ToArray();

      foreach (rcdPoint thePoint in arrRecord)
      {
        dblLengthRecordResult += ComputeLengthRecord(in thePoint);
      }
      // in arrRecord

      return dblLengthRecordResult;
    }
    // RunSomeCodeWithBenchmarkPointRecord()

    [BenchmarkAttribute]
    public double RunSomeCodeWithBenchmarkPointStruct()
    //***
    // Action
    //   - Run the actual code with a benchmark
    //     - This will give you exact numbers
    // Called by
    //   - Main()
    // Calls
    //   - double ComputeLengthStruct(structPoint)
    //   - structPoint(double, double)
    // Created
    //   - CopyPaste – 20260526 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260526 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      double dblLengthStructResult = 0;

      arrStruct = Enumerable.Range(0, intNumberOfItems).Select(intNumber => new structPoint(intNumber, intNumber)).ToArray();

      foreach (structPoint thePoint in arrStruct)
      {
        dblLengthStructResult += ComputeLengthStruct(in thePoint);
      }
      // in arrStruct

      return dblLengthStructResult;
    }
    // RunSomeCodeWithBenchmarkPointStruct()

    public static void RunSomeCodeWithStopWatch()
    //***
    // Action
    //   - Run the actual code with a stopwatch
    //     - This will give you an impression, not exact numbers
    // Called by
    //   - Main()
    // Calls
    //   - cpPoint(double, double)
    //   - double cpPoint.Length()
    //   - double cpPoint.Sum()
    //   - double rcdPoint.Length()
    //   - double rcdPoint.Sum()
    //   - double structPoint.Length()
    //   - double structPoint.Sum()
    //   - rcdPoint(double, double)
    //   - structPoint(double, double)
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      double dblLengthClassResult = 0;
      double dblLengthRecordResult = 0;
      double dblLengthStructResult = 0;
      double dblSumClassResult = 0;
      double dblSumRecordResult = 0;
      double dblSumStructResult = 0;

      Console.WriteLine("Class run with {0:#,##0} elements", intNumberOfItems);

      Stopwatch stwClassRun = Stopwatch.StartNew();

      arrClass = Enumerable.Range(0, intNumberOfItems).Select(intNumber => new cpPoint(intNumber, intNumber)).ToArray();

      foreach (cpPoint thePoint in arrClass)
      {
        dblSumClassResult += thePoint.Sum();
      }
      // in arrClass

      foreach (cpPoint thePoint in arrClass)
      {
        dblLengthClassResult += thePoint.Length();
      }
      // in arrClass

      stwClassRun.Stop();

      Console.WriteLine("Result of Class sum {0:#,##0}", dblSumClassResult);
      Console.WriteLine("Result of Class length {0:#,##0}", dblLengthClassResult);
      Console.WriteLine($"Class run took {stwClassRun.ElapsedMilliseconds} ms");
      Console.WriteLine();
      Console.WriteLine("Struct run with {0:#,##0} elements", intNumberOfItems);

      Stopwatch stwStructRun = Stopwatch.StartNew();

      arrStruct = Enumerable.Range(0, intNumberOfItems).Select(intNumber => new structPoint(intNumber, intNumber)).ToArray();

      foreach (structPoint thePoint in arrStruct)
      {
        dblSumStructResult += thePoint.Sum();
      }
      // in arrStruct

      foreach (structPoint thePoint in arrStruct)
      {
        dblLengthStructResult += thePoint.Length();
      }
      // in arrStruct

      stwStructRun.Stop();

      Console.WriteLine("Result of Struct sum {0:#,##0}", dblSumStructResult);
      Console.WriteLine("Result of Struct length {0:#,##0}", dblLengthStructResult);
      Console.WriteLine($"Struct run took {stwStructRun.ElapsedMilliseconds} ms");
      Console.WriteLine();
      Console.WriteLine("Record run with {0:#,##0} elements", intNumberOfItems);

      Stopwatch stwRecordRun = Stopwatch.StartNew();

      arrRecord = Enumerable.Range(0, intNumberOfItems).Select(intNumber => new rcdPoint(intNumber, intNumber)).ToArray();

      foreach (rcdPoint thePoint in arrRecord)
      {
        dblSumRecordResult += thePoint.Sum();
      }
      // in arrRecord

      foreach (rcdPoint thePoint in arrRecord)
      {
        dblLengthRecordResult += thePoint.Length();
      }
      // in arrRecord

      stwRecordRun.Stop();

      Console.WriteLine("Result of Record sum {0:#,##0}", dblSumRecordResult);
      Console.WriteLine("Result of Record length {0:#,##0}", dblLengthRecordResult);
      Console.WriteLine($"Record run took {stwRecordRun.ElapsedMilliseconds} ms");
    }
    // RunSomeCodeWithStopWatch()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning