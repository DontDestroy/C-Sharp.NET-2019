﻿//***
// Action
//   - Testroutine for cpPerson
// Created
//   - CopyPaste – 20230324 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230324 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows;

namespace CopyPaste.Learning.Toolkit
{ 

  public partial class wpfEmployee : Window
  {

    #region "Constructors / Destructors"

    public wpfEmployee()
    //***
    // Action
    //   - Create instance of 'wpfEmployee'
    // Called by
    //   - User action (Starting the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230324 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230324 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfEmployee()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdDisplay_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Reading the information from the form controls
    //   - Defining a cpPerson
    //   - Using the method / function to show the age
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - cpPerson.FirstName(string) (Set)
    //   - cpPerson.LastName(string) (Set)
    //   - int cpPerson.Age()
    //   - string cpPerson.FirstName() (Get)
    //   - string cpPerson.LastName() (Get)
    // Created
    //   - CopyPaste – 20220308 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220308 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      DateTime dtmDateOfBirth;
      cpPerson theEmployee = new cpPerson();

      theEmployee.FirstName = txtFirstName.Text;
      theEmployee.LastName = txtName.Text;

      if (dtpBirthDay.SelectedDate == null)
      {
      }
      else
      {
        dtmDateOfBirth = (DateTime) dtpBirthDay.SelectedDate;

        MessageBox.Show(theEmployee.FirstName + " " + theEmployee.LastName +
          " is " + theEmployee.Age(dtmDateOfBirth) + " years old.", "Copy Paste");
      }

    }
    // cmdDisplay_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdDisplay.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // wpfEmployee

}
// CopyPaste.Learning.Toolkit