﻿//***
// Action
//   - Two different routines are compared to each other
//     - Allocation inside a loop and let the garbage collector do its work
//     - Allocation outside a loop and reuse the allocated memory
//   - Benchmarking the memory and the time consumption of both routines
// Created
//   - CopyPaste – 20260525 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260525 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpAllocationBenchMarks
  {

    #region "Constructors / Destructors"

    public cpAllocationBenchMarks()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpAllocationBenchMarks()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private const int intNumberOfItems = 1_024;
    private const int intNumberOfLoops = 10_000;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [BenchmarkAttribute]
    public void AllocationInsideLoop()
    //***
    // Action
    //   - Loop intNumberOfLoops times
    //     - Allocate an array of bytes with intNumberOfItems items
    //     - Fill the array with values (0, 1, 2, ..., 255, 0, 1, ...)
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      for (int intCounterOuter = 0 ; intCounterOuter < intNumberOfLoops; intCounterOuter++)
      {
        byte[] arrBytes = new byte[intNumberOfItems];

        for (int intCounterInner = 0; intCounterInner < intNumberOfItems; intCounterInner++)
        {
          arrBytes[intCounterInner] = (byte)(intCounterInner % 256);
        }
        // intCounterInner = intNumberOfItems

      }
      // intCounterOuter = intNumberOfLoops

    }
    // AllocationInsideLoop()

    [BenchmarkAttribute]
    public void AllocationOutsideLoop()
    //***
    // Action
    //   - Allocate an array of bytes with intNumberOfItems items
    //   - Loop intNumberOfLoops times
    //     - Fill the array with values (0, 1, 2, ..., 255, 0, 1, ...)
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      byte[] arrBytes = new byte[intNumberOfItems];

      for (int intCounterOuter = 0; intCounterOuter < intNumberOfLoops; intCounterOuter++)
      {

        for (int intCounterInner = 0; intCounterInner < intNumberOfItems; intCounterInner++)
        {
          arrBytes[intCounterInner] = (byte)(intCounterInner % 256);
        }
        // intCounterInner = intNumberOfItems

      }
      // intCounterOuter = intNumberOfLoops

    }
    // AllocationOutsideLoop()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpAllocationBenchMarks

}
// CopyPaste.Learning