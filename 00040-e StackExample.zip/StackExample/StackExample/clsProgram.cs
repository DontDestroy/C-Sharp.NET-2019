//***
// Action
//   - An example of a stack
// Created
//   - CopyPaste � 20240228 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240228 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.Windows.Forms;
using System.Diagnostics;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Add 3 items in a stack
      //   - Check if an item is in it
      //   - Remove the first item
      //   - Peek to the first item
      //   - Put the stakc into an array
      //   - Loop thru the items of the array
      //     - Show the items in the debug window (not on the console)
      //   - Make the stack empty
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngCounter;
      Stack theStack = new Stack();

      theStack.Push("Chopin");
      theStack.Push("Mozart");
      theStack.Push("Beethoven");

      MessageBox.Show("Beethoven in stack: " + theStack.Contains("Beethoven").ToString());
      MessageBox.Show("First item in stack (and pick it): " + theStack.Pop().ToString());
      MessageBox.Show("First item in stack (only peek): " + theStack.Peek().ToString());

      Object[] arrObjects = theStack.ToArray();

      for (lngCounter = 0; lngCounter < arrObjects.Length; lngCounter++)
      {
        Debug.WriteLine(arrObjects[lngCounter].ToString());
      }
      // lngCounter = arrObjects.Length

      theStack.Clear();
      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning