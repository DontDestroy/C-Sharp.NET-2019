//***
// Action
//   - Demo of resources in the from of a soundwave
// Created
//   - CopyPaste � 20260702 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260702 � VVDW
// Proposal (To Do)
//   - 
//***

using Resources;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Media;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmResources: System.Windows.Forms.Form
  {
    private Button cmdPlay;

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmResources));
      this.cmdPlay = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdPlay
      // 
      this.cmdPlay.Location = new System.Drawing.Point(12, 12);
      this.cmdPlay.Name = "cmdPlay";
      this.cmdPlay.Size = new System.Drawing.Size(134, 33);
      this.cmdPlay.TabIndex = 0;
      this.cmdPlay.Text = "Play Windows TaDa";
      this.cmdPlay.UseVisualStyleBackColor = true;
      this.cmdPlay.Click += new System.EventHandler(this.cmdPlay_Click);
      // 
      // frmResources
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdPlay);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmResources";
      this.Text = "Play the sound wave";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmResources'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260702 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260702 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmResources()
    //***
    // Action
    //   - Create instance of 'frmResources'
    // Called by
    //   - Main()
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste � 20260702 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260702 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmResources()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    SoundPlayer theTaDa = new SoundPlayer(ImportedSoundWaves.Windows_Tada);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdPlay_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Play the sound given into the resource files
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20260702 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260702 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theTaDa.Play();
    }
    // cmdPlay_Click(System.Object, System.EventArgs) Handles cmdPlay.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmDefault
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmResources()
    // Created
    //   - CopyPaste � 20260702 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260702 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmResources());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmResources

}
// CopyPaste.Learning