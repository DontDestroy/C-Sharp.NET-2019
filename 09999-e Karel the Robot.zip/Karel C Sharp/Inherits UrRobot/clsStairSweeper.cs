﻿//***
// Action
//   - Definition of a green robot at origin looking to the East
//   - Add functionality to climb a stair and sweep the beepers
// Created
//   - CopyPaste – 20251012 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251012 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpStairSweeper : UrRobot
	{

		#region "Constructors / Destructors"

		public cpStairSweeper(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Robot becomes a theColor cpStairClimber starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
		//   - Nothing else happens
		// Called by
		//   - cpProgram.StairSweeper()
		//   - cpStairSweeper(int, int, Directions.Direction, int)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251012 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251012 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
		}
		// cpStairSweeper(int, int, Directions.Direction, int, Color)

		public cpStairSweeper(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Robot becomes a theColor cpStairClimber starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
		//   - Nothing else happens
		// Called by
		//   - 
		// Calls
		//   - cpStairSweeper(int, int, Directions.Direction, int, Color)
		// Created
		//   - CopyPaste – 20251012 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251012 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
		}
		// cpStairSweeper(int, int, Directions.Direction, int)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public void GetBeeper()
		//***
		// Action
		//   - Robot will move up the stairs
		//   - Pick the beeper
		//   - Switch off the robot
		// Called by
		//   - cpProgram.StairSweeper()
		// Calls
		//   - SweepThreeStairs()
		// Created
		//   - CopyPaste – 20251012 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251012 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			SweepThreeStairs();
			pickBeeper(); // Don't forget the last one
			turnLeft(); // Making the robot standing up
			turnOff();
		}
		// GetBeeper()

		private void SweepOneStair()
		//***
		// Action
		//   - Pick a beeper
		//   - Turn to the left
		//   - Move one forward (in this case to the North)
		//   - Turn to the right
		//   - Move one forward (in this case to the East)
		// Called by
		//   - SweepThreeStairs()
		// Calls
		//   - TurnRight()
		// Created
		//   - CopyPaste – 20251012 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251012 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			pickBeeper();
			turnLeft();
			move();
			TurnRight();
			move();
		}
		// ClimbOneStair()

		private void SweepThreeStairs()
		//***
		// Action
		//   - Robot will move up the stairs
		//   - Repeat 3 times the climb one stair and sweep
		// Called by
		//   - GetBeeper()
		// Calls
		//   - SweepOneStair()
		// Created
		//   - CopyPaste – 20251012 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251012 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			SweepOneStair();
			SweepOneStair();
			SweepOneStair();
		}
		// SweepThreeStairs()

		private void TurnRight()
		//***
		// Action
		//   - Turn to the right by turning 3 times to the left
		// Called by
		//   - SweepOneStair()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251012 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251012 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			turnLeft();
			turnLeft();
			turnLeft();
		}
		// TurnRight()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpStairSweeper

}
// cpKarelTheRobot