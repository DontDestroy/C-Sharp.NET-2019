﻿//***
// Action
//   - Using textfiles to fill listboxes
//   - Single select and Multi select
// Created
//   - CopyPaste – 20260710 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260710 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmTextFiles: System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cmdOrder.Click += new System.EventHandler(this.cmdOrder_Click);
      this.ID = "wfrmTextFiles";
    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when initializing the page
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdOrder_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a list item
    //   - Clear the list
    //   - Add the selected item of the french fries
    //   - Loop thru the item of the meat
    //     - If selected
    //       - Add the item of the meat
    //     - If not
    //       - Do nothing
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lstOrdered.Items.Clear();
      lstOrdered.Items.Add(lstFrenchFries.SelectedItem.Text);

      foreach (ListItem theMeat in lstMeat.Items)
      {

        if (theMeat.Selected)
        {
          lstOrdered.Items.Add(theMeat.Text);
        }
        else
        // Not theMeat.Selected
        {
        }
        // theMeat.Selected

      }
      // in lstMeat.Items

    }
    // cmdOrder_Click(System.Object, System.EventArgs) Handles cmdOrder.Click

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - If first time that page is opened
    //     - Define and initialize a streamreader for the french fries
    //     - Define and initialize a streamreader for the meat
    //     - Loop thru the french fries file
    //       - Add the item (a line) to the list box
    //     - Close the streamreader of the french fries
    //     - Loop thru the meat file
    //       - Add the item (a line) to the list box
    //     - Close the streamreader of the meat
    //   - If not
    //     - Do nothing
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260710 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260710 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (IsPostBack)
      {
      }
      else
      // Not IsPostBack
      {
        string strLine;
        System.IO.StreamReader strReaderFrenchFries = new System.IO.StreamReader(Server.MapPath("TextData\\FrenchFries.txt"));
        System.IO.StreamReader strReaderMeat = new System.IO.StreamReader(Server.MapPath("TextData\\Meat.txt"));

        //while (strReaderFrenchFries.Peek() != -1)
        //{
        //  lstFrenchFries.Items.Add(strReaderFrenchFries.ReadLine());
        //}
        //// strReaderFrenchFries.Peek() <> -1

        strLine = strReaderFrenchFries.ReadLine();

        while (strLine != null)
        {
          lstFrenchFries.Items.Add(strLine);
          strLine = strReaderFrenchFries.ReadLine();
        }
        // strLine <> null

        strReaderFrenchFries.Close();

        //while (strReaderMeat.Peek() != -1)
        //{
        //  lstMeat.Items.Add(strReaderMeat.ReadLine());
        //}
        //// strReaderMeat.Peek() <> -1

        strLine = strReaderMeat.ReadLine();

        while (strLine != null)
        {
          lstMeat.Items.Add(strLine);
          strLine = strReaderMeat.ReadLine();
        }
        // strLine <> null

        strReaderMeat.Close();
      }
      // IsPostBack

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmTextFiles

}
// CopyPaste.Learning