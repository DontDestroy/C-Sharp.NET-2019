//***
// Action
//   - Choose the green or red button
// Created
//   - CopyPaste � 20240227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240227 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmModeless: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdRed;
    internal System.Windows.Forms.Button cmdGreen;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmModeless));
      this.cmdRed = new System.Windows.Forms.Button();
      this.cmdGreen = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdRed
      // 
      this.cmdRed.Location = new System.Drawing.Point(122, 24);
      this.cmdRed.Name = "cmdRed";
      this.cmdRed.TabIndex = 3;
      this.cmdRed.Text = "Red";
      this.cmdRed.Click += new System.EventHandler(this.cmdRed_Click);
      // 
      // cmdGreen
      // 
      this.cmdGreen.Location = new System.Drawing.Point(18, 24);
      this.cmdGreen.Name = "cmdGreen";
      this.cmdGreen.TabIndex = 2;
      this.cmdGreen.Text = "Green";
      this.cmdGreen.Click += new System.EventHandler(this.cmdGreen_Click);
      // 
      // frmModeless
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(214, 99);
      this.Controls.Add(this.cmdRed);
      this.Controls.Add(this.cmdGreen);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.Name = "frmModeless";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Modeless";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmModeless'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmModeless()
      //***
      // Action
      //   - Create instance of 'frmModeless'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmModeless()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private frmGreen mtheFormGreen;
    private frmRed mtheFormRed;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdGreen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there is no frmGreen (or it is disposed)
      //     - Define a new frmGreen
      //     - Show it (not as a dialog)
      //   - If Not
      //     - Activate the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmGreen()
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    { 

      if ((mtheFormGreen == null) || mtheFormGreen.IsDisposed)
      {
        mtheFormGreen = new frmGreen();
        mtheFormGreen.Show();
      }
      else
        // (mtheFormGreen <> null) And Not mtheFormGreen.IsDisposed
      {
        mtheFormGreen.Activate();
      }
      // (mtheFormGreen == null) Or (mtheFormGreen.IsDisposed
    
    }
    // cmdGreen_Click(System.Object, System.EventArgs) Handles cmdGreen.Click

    private void cmdRed_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there is no frmRed (or it is disposed)
      //     - Define a new frmRed
      //     - Show it (not as a dialog)
      //   - If Not
      //     - Activate the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmRed()
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    { 

      if ((mtheFormRed == null) || mtheFormRed.IsDisposed)
      {
        mtheFormRed = new frmRed();
        mtheFormRed.Show();
      }
      else
        // (mtheFormRed <> null) And Not mtheFormRed.IsDisposed
      {
        mtheFormRed.Activate();
      }
      // (mtheFormRed == null) Or (mtheFormRed.IsDisposed
    
    }
    // cmdRed_Click(System.Object, System.EventArgs) Handles cmdRed.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmModeless
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmModeless());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmModeless

}
// CopyPaste.Learning