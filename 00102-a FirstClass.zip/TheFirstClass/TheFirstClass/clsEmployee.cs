// Action
//   - Define a cpEmployee (Total employees, CSharpNETTrained, EmployeeNumber, FirstName, LastName)
//   - Two constructors
// Created
//   - CopyPaste � 20220411 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220411 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpEmployee
	{

    #region "Constructors / Destructors"
    
    public cpEmployee() :  base()
      //***
      // Action
      //   - Create a new instance of cpEmployee
      // Called by
      //   - 
      // Calls
      //   - Object()
      // Created
      //   - CopyPaste � 20220411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      gintTotalEmployees += 1;
      mintEmployeeNumber = gintTotalEmployees;
    }
    // cpEmployee()

    public cpEmployee(string strFirstName, string strLastName) : this()
      //'***
      //' Action
      //'   - Create a new instance of cpEmployee with strFirstName and strLastName
      //' Called by
      //'   - cpDivision.New(String, String)
      //' Calls
      //'   - Object()
      //'   - FirstName(string) (Set)
      //'   - LastName(string) (Set)
      //' Created
      //'   - CopyPaste � 20220411 � VVDW
      //' Changed
      //'   - CopyPaste � yyyymmdd � VVDW � What changed
      //' Tested
      //'   - CopyPaste � 20220411 � VVDW
      //' Keyboard key
      //'   - 
      //' Proposal (To Do)
      //'   - 
      //'***
    {
      FirstName = strFirstName;
      LastName = strLastName;
    }
    // cpEmployee(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    private bool mblnCSharpNETTrained = false;
    static int gintTotalEmployees = 0;
    private int mintEmployeeNumber = 0;
    private string mstrFirstName = "";
    private string mstrLastName = "";

    #endregion

    #region "Properties"

    public bool CSharpNET
    {
    
      get
        //***
        // Action Get
        //   - Return mblnCSharpNETTrained
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220411 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220411 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mblnCSharpNETTrained;
      }
      // bool CSharpNET (Get)

      set
        //***
        // Action Set
        //   - Define mblnCSharpNETTrained
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220411 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220411 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mblnCSharpNETTrained = value;
      }
      // CSharpNET(bool) (Set)

    }
    // bool CSharpNET

    public int EmployeeNumber
    {

      get
        //***
        // Action Get
        //   - Return mintEmployeeNumber
        // Called by
        //   - cpProgram.ShowEmployee(cpDivision)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220411 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220411 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mintEmployeeNumber;
      }
      // int EmployeeNumber (Get)

    }
    // int EmployeeNumber

    public string FirstName
    {

      get
        //***
        // Action Get
        //   - Return mstrFirstName
        // Called by
        //   - cpProgram.ShowEmployee(cpDivision)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220411 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220411 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrFirstName;
      }
      // string FirstName (Get)

      set
        //***
        // Action Set
        //   - Define mstrFirstName
        // Called by
        //   - cpEmployee(string, string)
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220411 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220411 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrFirstName = value;
      }
      // FirstName(string) (Set)

    }
    // string FirstName 

    public string LastName
    {

      get
        //***
        // Action Get
        //   - Return mstrLastName
        // Called by
        //   - cpProgram.ShowEmployee(cpDivision)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220411 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220411 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrLastName;
      }
      // string LastName (Get)

      set
        //***
        // Action Set
        //   - Define mstrLastName
        // Called by
        //   - cpEmployee(string, string)
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220411 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220411 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrLastName = value;
      }
      // LastName(string) (Set)

    }
    // string LastName 

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public virtual bool Serialize()
      //***
      // Action
      //   - If mstrFirstName is empty string or mstrFirstName is empty string
      //     - Return False
      //   - If Not
      //     - Return True
      // Called by
      //   - cpDivision.Serialize() As Boolean
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (mstrFirstName == "" || mstrLastName == "")
      {
        return false;
      }
      else
        // (mstrFirstName != "") && (mstrLastName != "")
      {
        return true;
      }
      // (mstrFirstName == "" || mstrLastName == "")

    }
    // bool Serialize()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpEmployee

}
// CopyPaste.Learning