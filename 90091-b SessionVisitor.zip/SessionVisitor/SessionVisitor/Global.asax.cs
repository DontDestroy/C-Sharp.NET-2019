﻿//***
// Action
//   - Execute some routines when application starts
//   - Execute some routines when session starts
// Created
//   - CopyPaste – 20260721 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260721 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;

namespace CopyPaste.Learning
{

  public class Global : System.Web.HttpApplication
  {

    #region Web Form Designer generated code

    private System.ComponentModel.IContainer components = null;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
    }

    #endregion

    #region "Constructors / Destructors"

    public Global()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - xxxx
    // Created
    //   - CopyPaste – 20260721 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260721 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      InitializeComponent();
    }
    // Global

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    protected void Application_AuthenticateRequest(System.Object theSender, System.EventArgs theEventArguments)
    {

    }

    protected void Application_BeginRequest(System.Object theSender, System.EventArgs theEventArguments)
    {

    }

    protected void Application_End(System.Object theSender, System.EventArgs theEventArguments)
    {

    }

    protected void Application_EndRequest(System.Object theSender, System.EventArgs theEventArguments)
    {

    }

    protected void Application_Error(System.Object theSender, System.EventArgs theEventArguments)
    {

    }

    protected void Application_Start(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Add 2 cookies to the application with value 0
    //     - NumberOfVisitors
    //     - NumberOfVisitorsAtThisMoment
    // Called by
    //   - User action (Application is started)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260721 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260721 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Add("NumberOfVisitors", 0);
      Application.Add("NumberOfVisitorsAtThisMoment", 0);
    }
    // Application_Start(System.Object, System.EventArgs)

    protected void Session_End(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Decrement the value of 1 cookie
    //     - NumberOfVisitorsAtThisMoment
    //   - Session is timed out in 1 minute
    // Called by
    //   - User action (Session is ended)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260721 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260721 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***      
    {

      if (Convert.ToInt32(Application["NumberOfVisitorsAtThisMoment"]) > 0)
      {
        Application["NumberOfVisitorsAtThisMoment"] = Convert.ToInt32(Application["NumberOfVisitorsAtThisMoment"]) - 1;
      }
      else
      // Convert.ToInt32(Application["NumberOfVisitorsAtThisMoment"]) <= 0 
      {
      }
      // Convert.ToInt32(Application["NumberOfVisitorsAtThisMoment"]) > 0 

    }
    // Session_End(System.Object, System.EventArgs)

    protected void Session_Start(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Increment the value of 2 cookies 
    //     - NumberOfVisitors
    //     - NumberOfVisitorsAtThisMoment
    //   - Session is timed out in 1 minute
    // Called by
    //   - User action (Session is started)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260721 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260721 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application["NumberOfVisitors"] = Convert.ToInt32(Application["NumberOfVisitors"]) + 1;
      Application["NumberOfVisitorsAtThisMoment"] = Convert.ToInt32(Application["NumberOfVisitorsAtThisMoment"]) + 1;
      Session.Timeout = 1;
    }
    // Session_Start(System.Object, System.EventArgs)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Global

}
// CopyPaste.Learning
