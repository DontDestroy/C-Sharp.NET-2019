﻿//***
// Action
//   - Reading Application Settings
// Created
//   - CopyPaste – 20210809 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210809 – VVDW
// Proposal(To Do)
//   -
//***

using System.Configuration;

namespace WPFCommand
{

  public static class cpApplicationSetting
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public static string ConnectionString
    {
      get
      //***
      // Action Get
      //   - Look up the connection string in the Application Configuration(App.config)
      // Called by
      //   - int cpCommandViewModel.GetProductsCountScalar()
      //   - int cpCommandViewModel.GetProductsCountScalarUsingParameters()
      //   - int cpCommandViewModel.InsertProduct()
      //   - int cpCommandViewModel.InsertProductOutputParameters()
      //   - int cpCommandViewModel.InsertProductUsingParameters()
      //   - int cpCommandViewModel.TransactionProcessing()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20210809 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20210809 – VVDW
      // Keyboard Key
      //   - 
      // Proposal(To Do)
      //   -
      //***
      {
        return ConfigurationManager.ConnectionStrings["WPFConnection"].ConnectionString;
      }
      // string ConnectionString (Get)

    }
    // string ConnectionString 

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpApplicationSetting

}
// WPFCommand