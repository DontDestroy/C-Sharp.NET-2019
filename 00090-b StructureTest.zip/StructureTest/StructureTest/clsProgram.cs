//***
// Action
//   - Example of structure
// Created
//   - CopyPaste � 20240216 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240216 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  class cpProgram
  {

    #region "Constructors / Destructors"

    static cpProgram()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    #region "Structures"

    struct cpTest
    {
      string strProperty;
      
      public void cpMethod()
      {
        MessageBox.Show("Structure method. Property value is " + cpProperty);
      }
      // cpMethod()

      public string cpProperty
      {
        
        get
        {
          return strProperty;
        }
        // cpProperty() As String (Get)

        set
        {
          strProperty = value;
        }
        // cpProperty(String) (Set)

      }
      // cpProperty() As String

    }
    // cpTest

    #endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Define a variable of the data type defined by the structure
      //   - Set a property of a structure
      //   - Run a method of a structure
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240216 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpTest theTest = new cpTest();
      
      theTest.cpProperty = "Donna";
      theTest.cpMethod();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning