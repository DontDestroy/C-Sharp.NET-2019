//***
// Action
//   - Testroutine for cpCountry and cpContinent
// Created
//   - CopyPaste � 20240701 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240701 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDocking: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Splitter splHorizontal01;
    internal System.Windows.Forms.Panel pnlInfo;
    internal System.Windows.Forms.Label lblFlag;
    internal System.Windows.Forms.TextBox txtSize;
    internal System.Windows.Forms.TextBox txtCapital;
    internal System.Windows.Forms.TextBox txtCountry;
    internal System.Windows.Forms.Panel pnlCountryCapital;
    internal System.Windows.Forms.Splitter splVertical02;
    internal System.Windows.Forms.ListBox lstCapital;
    internal System.Windows.Forms.ListBox lstCountry;
    internal System.Windows.Forms.Splitter splVertical01;
    internal System.Windows.Forms.ListBox lstContinents;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDocking));
      this.splHorizontal01 = new System.Windows.Forms.Splitter();
      this.pnlInfo = new System.Windows.Forms.Panel();
      this.lblFlag = new System.Windows.Forms.Label();
      this.txtSize = new System.Windows.Forms.TextBox();
      this.txtCapital = new System.Windows.Forms.TextBox();
      this.txtCountry = new System.Windows.Forms.TextBox();
      this.pnlCountryCapital = new System.Windows.Forms.Panel();
      this.splVertical02 = new System.Windows.Forms.Splitter();
      this.lstCapital = new System.Windows.Forms.ListBox();
      this.lstCountry = new System.Windows.Forms.ListBox();
      this.splVertical01 = new System.Windows.Forms.Splitter();
      this.lstContinents = new System.Windows.Forms.ListBox();
      this.pnlInfo.SuspendLayout();
      this.pnlCountryCapital.SuspendLayout();
      this.SuspendLayout();
      // 
      // splHorizontal01
      // 
      this.splHorizontal01.Dock = System.Windows.Forms.DockStyle.Top;
      this.splHorizontal01.Location = new System.Drawing.Point(123, 80);
      this.splHorizontal01.Name = "splHorizontal01";
      this.splHorizontal01.Size = new System.Drawing.Size(429, 4);
      this.splHorizontal01.TabIndex = 6;
      this.splHorizontal01.TabStop = false;
      // 
      // pnlInfo
      // 
      this.pnlInfo.AutoScroll = true;
      this.pnlInfo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.pnlInfo.Controls.Add(this.lblFlag);
      this.pnlInfo.Controls.Add(this.txtSize);
      this.pnlInfo.Controls.Add(this.txtCapital);
      this.pnlInfo.Controls.Add(this.txtCountry);
      this.pnlInfo.Dock = System.Windows.Forms.DockStyle.Fill;
      this.pnlInfo.Location = new System.Drawing.Point(123, 80);
      this.pnlInfo.Name = "pnlInfo";
      this.pnlInfo.Size = new System.Drawing.Size(429, 413);
      this.pnlInfo.TabIndex = 7;
      // 
      // lblFlag
      // 
      this.lblFlag.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
      this.lblFlag.Location = new System.Drawing.Point(16, 128);
      this.lblFlag.Name = "lblFlag";
      this.lblFlag.Size = new System.Drawing.Size(100, 88);
      this.lblFlag.TabIndex = 3;
      // 
      // txtSize
      // 
      this.txtSize.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.txtSize.Location = new System.Drawing.Point(16, 88);
      this.txtSize.Name = "txtSize";
      this.txtSize.ReadOnly = true;
      this.txtSize.TabIndex = 2;
      this.txtSize.Text = "";
      // 
      // txtCapital
      // 
      this.txtCapital.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.txtCapital.Location = new System.Drawing.Point(16, 56);
      this.txtCapital.Name = "txtCapital";
      this.txtCapital.ReadOnly = true;
      this.txtCapital.TabIndex = 1;
      this.txtCapital.Text = "";
      // 
      // txtCountry
      // 
      this.txtCountry.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.txtCountry.Location = new System.Drawing.Point(16, 24);
      this.txtCountry.Name = "txtCountry";
      this.txtCountry.ReadOnly = true;
      this.txtCountry.TabIndex = 0;
      this.txtCountry.Text = "";
      // 
      // pnlCountryCapital
      // 
      this.pnlCountryCapital.Controls.Add(this.splVertical02);
      this.pnlCountryCapital.Controls.Add(this.lstCapital);
      this.pnlCountryCapital.Controls.Add(this.lstCountry);
      this.pnlCountryCapital.Dock = System.Windows.Forms.DockStyle.Top;
      this.pnlCountryCapital.Location = new System.Drawing.Point(123, 0);
      this.pnlCountryCapital.Name = "pnlCountryCapital";
      this.pnlCountryCapital.Size = new System.Drawing.Size(429, 80);
      this.pnlCountryCapital.TabIndex = 5;
      // 
      // splVertical02
      // 
      this.splVertical02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.splVertical02.Location = new System.Drawing.Point(208, 0);
      this.splVertical02.Name = "splVertical02";
      this.splVertical02.Size = new System.Drawing.Size(3, 80);
      this.splVertical02.TabIndex = 1;
      this.splVertical02.TabStop = false;
      // 
      // lstCapital
      // 
      this.lstCapital.DisplayMember = "Capital";
      this.lstCapital.Dock = System.Windows.Forms.DockStyle.Fill;
      this.lstCapital.IntegralHeight = false;
      this.lstCapital.Location = new System.Drawing.Point(208, 0);
      this.lstCapital.Name = "lstCapital";
      this.lstCapital.Size = new System.Drawing.Size(221, 80);
      this.lstCapital.Sorted = true;
      this.lstCapital.TabIndex = 1;
      this.lstCapital.SelectedIndexChanged += new System.EventHandler(this.ListBox_SelectedIndexChanged);
      // 
      // lstCountry
      // 
      this.lstCountry.Dock = System.Windows.Forms.DockStyle.Left;
      this.lstCountry.IntegralHeight = false;
      this.lstCountry.Location = new System.Drawing.Point(0, 0);
      this.lstCountry.Name = "lstCountry";
      this.lstCountry.Size = new System.Drawing.Size(208, 80);
      this.lstCountry.Sorted = true;
      this.lstCountry.TabIndex = 0;
      this.lstCountry.SelectedIndexChanged += new System.EventHandler(this.ListBox_SelectedIndexChanged);
      // 
      // splVertical01
      // 
      this.splVertical01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.splVertical01.Location = new System.Drawing.Point(120, 0);
      this.splVertical01.Name = "splVertical01";
      this.splVertical01.Size = new System.Drawing.Size(3, 493);
      this.splVertical01.TabIndex = 3;
      this.splVertical01.TabStop = false;
      // 
      // lstContinents
      // 
      this.lstContinents.Dock = System.Windows.Forms.DockStyle.Left;
      this.lstContinents.HorizontalScrollbar = true;
      this.lstContinents.IntegralHeight = false;
      this.lstContinents.Location = new System.Drawing.Point(0, 0);
      this.lstContinents.Name = "lstContinents";
      this.lstContinents.Size = new System.Drawing.Size(120, 493);
      this.lstContinents.TabIndex = 4;
      this.lstContinents.SelectedIndexChanged += new System.EventHandler(this.lstContinents_SelectedIndexChanged);
      // 
      // frmDocking
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(552, 493);
      this.Controls.Add(this.splHorizontal01);
      this.Controls.Add(this.pnlInfo);
      this.Controls.Add(this.pnlCountryCapital);
      this.Controls.Add(this.splVertical01);
      this.Controls.Add(this.lstContinents);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDocking";
      this.Text = "Docking";
      this.pnlInfo.ResumeLayout(false);
      this.pnlCountryCapital.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDocking'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240701 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDocking()
      //***
      // Action
      //   - Create new instance of 'frmDocking'
      //   - Create six instances of cpCountry
      //   - Create an array of 4 European countries
      //   - Create an array of 2 South American countries
      //   - Create two instances of cpContinent
      //   - Add cpContinent instances to the listbox
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpContinent(string, cpCountry[])
      //   - cpCountry(string, string, Image, int)
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240701 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();

      cpCountry cpCountry01 = new cpCountry("Belgium", "Brussels", new Bitmap("Belgium.bmp"), 30258);
      cpCountry cpCountry02 = new cpCountry("Netherlands", "Amsterdam", new Bitmap("Netherlands.bmp"), 41547);
      cpCountry cpCountry03 = new cpCountry("Germany", "Berlin", new Bitmap("Germany.bmp"), 356970);
      cpCountry cpCountry04 = new cpCountry("France", "Paris", new Bitmap("France.bmp"), 544000);
      cpCountry cpCountry05 = new cpCountry("Mexico", "Mexico", new Bitmap("Mexico.bmp"), 1972550);
      cpCountry cpCountry06 = new cpCountry("Brazil", "Brasilia", new Bitmap("Brasil.bmp"), 8511965);

      cpCountry[] arrcpCountryEurope = {cpCountry01, cpCountry02, cpCountry03, cpCountry04};
      cpCountry[] arrcpCountrySouthAmerica = {cpCountry05, cpCountry06};

      cpContinent cpEurope = new cpContinent("Europe", arrcpCountryEurope);
      cpContinent cpSouthAmerica = new cpContinent("South America", arrcpCountrySouthAmerica);

      lstContinents.Items.Add(cpEurope);
      lstContinents.Items.Add(cpSouthAmerica);
      lstContinents.DisplayMember = "Name";
    }
    // frmDocking()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void ListBox_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Look what listbox is selected
      //   - Look what country (or capital) is selected and make it a country
      //   - Add the Name, Capital, Size and Flag of that country to the corresponding controls
      // Called by
      //   - User action (Selecting a list item)
      // Calls
      //   - Image cpCountry.Flag (Get)
      //   - int cpCountry.Size (Get)
      //   - string cpCountry.Capital (Get)
      //   - string cpCountry.Name (Get)
      // Created
      //   - CopyPaste � 20240701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240701 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ListBox lstCountry = (ListBox)theSender;
      cpCountry thecpCountry = (cpCountry)lstCountry.SelectedItem;

      txtCountry.Text = thecpCountry.Name;
      txtCapital.Text = thecpCountry.Capital;
      txtSize.Text = thecpCountry.Size.ToString();
      lblFlag.Image = thecpCountry.Flag;
    }
    // ListBox_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstCapital.SelectedIndexChanged, lstCountry.SelectedIndexChanged

    private void lstContinents_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Look what continent is selected
      //   - Clear the two listboxes of countries and capitals
      //   - Add the cpCountry of selected continent to the list of capitals
      //   - Add the cpCountry of selected continent to the list of countries
      // Called by
      //   - User action (Selecting a list item)
      // Calls
      //   - cpContinent.Countries() As cpCountry() (Get)
      // Created
      //   - CopyPaste � 20240701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240701 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpContinent SelectedContinent = (cpContinent)lstContinents.SelectedItem;

      lstCountry.Items.Clear();
      lstCapital.Items.Clear();
      lstCountry.Items.AddRange(SelectedContinent.Countries);
      lstCapital.Items.AddRange(SelectedContinent.Countries);
      lstCountry.DisplayMember = "Name";
    }
    // lstContinents_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstContinents.SelectedIndexChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDocking
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDocking()
      // Created
      //   - CopyPaste � 20240701 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240701 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDocking());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDocking

}
// CopyPaste.Learning