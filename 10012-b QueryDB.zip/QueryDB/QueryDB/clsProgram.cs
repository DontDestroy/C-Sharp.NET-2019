﻿//***
// Action
//   - Use a data reader to loop thru some information
// Created
//   - CopyPaste – 20250806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250806 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Try to
      //     - Define a connection string
      //     - Use that string to create a connection
      //     - Open the connection
      //     - Show some information about the connection
      //     - Create a command to execute
      //     - Define a reader that executes the command (and will close the connection after the last read record)
      //     - Loop till end
      //       - Show the information on the second column
      //   - On any issue
      //     - Show the exception message
      //     - Show the exception to string information
      //   - Wait for user input
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250806 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250806 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      try
      {
        string strConnection = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integrated Security=True";
        SqlConnection theConnection = new SqlConnection(strConnection);
        
        theConnection.Open();
        Console.WriteLine("Database: " + theConnection.Database);
        Console.WriteLine("Server version: " + theConnection.ServerVersion);
        Console.WriteLine("DataSource: " + theConnection.DataSource);
        Console.WriteLine();
        
        SqlCommand cmmCommand = new SqlCommand("SELECT * From tblCPEmployee", theConnection);
        SqlDataReader drdReader = cmmCommand.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
        
        while (drdReader.Read())
        {
          Console.WriteLine(drdReader.GetSqlValue(1));
        }
        // Not drdReader.Read()

      }
      catch (Exception theException)
      {
        Console.WriteLine("Exception: " + theException.Message);
        Console.WriteLine(theException.ToString());
      }
      finally
      {
        Console.ReadLine();
      }

    }
    // Main()

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning