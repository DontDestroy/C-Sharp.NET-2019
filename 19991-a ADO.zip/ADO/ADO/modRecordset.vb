'***
' Action
'   - ADO code about recordsets
' Created
'   - CopyPaste � 20260331 � VVDW
' Changed
'   - CopyPaste � yyyymmdd � VVDW � What changed
' Tested
'   - CopyPaste � 20260331 � VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On 
Option Strict On

Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.ControlChars
Imports System.Windows.Forms

Namespace CopyPaste.Learning

  Public Module modRecordset

    '#Region "Constructors / Destructors"
    '#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

    '#Region "Fields"
    '#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

    '#Region "Controls"
    '#End Region

#Region "Functionality"

    '#Region "Event"
    '#End Region

#Region "Sub / Function"

    Public Sub OpenRecordsetWithEditing(ByVal txtResult As TextBox)
      '***
      ' Action
      '   - Create a new instance of a connection
      '   - Define a field
      '   - Create a new instance of a recordset
      '   - Open the connection
      '   - Open a recordset using a SQL statement and the cursortype
      '   - Loop thru the recordset
      '     - Show a value
      '     - Update a field
      '     - Show the value again
      '     - Update a field back to the original
      '     - Go to next record
      '   - Show the result
      '   - Close the recordset
      '   - Close the connection
      ' Called by
      '   - frmMain.cmdEditingARecordset_Click(System.Object, System.EventArgs) Handles cmdEditingARecordset.Click
      ' Calls
      '   - modConnection.OpencpNorthwindScriptADOConnection(�ADODB.Connection)
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      Dim strText As String
      Dim theConnection As New ADODB.Connection
      Dim theField As ADODB.Field
      Dim theRecordset As New ADODB.Recordset

      OpencpNorthwindScriptADOConnection(theConnection)
      theRecordset.Open("SELECT * FROM tblCPOrder WHERE dtmOrderDate = '06/12/2007'", theConnection, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockOptimistic)

      With theRecordset

        While Not .EOF
          strText &= " Old Field Value: " & .Fields("dtmShippedDate").Value.ToString
          .Fields("dtmShippedDate").Value = DateAdd(DateInterval.Day, 5, Convert.ToDateTime(.Fields("dtmShippedDate").Value))
          .Update()
          strText &= " New Field Value: " & .Fields("dtmShippedDate").Value.ToString & CrLf
          .Fields("dtmShippedDate").Value = DateAdd(DateInterval.Day, -5, Convert.ToDateTime(.Fields("dtmShippedDate").Value))
          .Update()
          .MoveNext()
        End While
        ' .EOF

      End With
      ' theRecordset

      txtResult.Text = strText
      theRecordset.Close()
      theConnection.Close()
    End Sub
    ' OpenRecordsetWithEditing(TextBox)

    Public Sub OpenRecordsetWithGetStringDisplay(ByVal txtResult As TextBox)
      '***
      ' Action
      '   - Create a new instance of a connection
      '   - Create a new instance of a recordset
      '   - Initialize and open the connection
      '   - Open a recordset using a SQL statement and the cursortype
      '   - Show the string of the recordset
      '   - Close the recordset
      '   - Close the connection
      ' Called by
      '   - frmMain.cmdGetStringDisplay_Click(System.Object, System.EventArgs) Handles cmdGetStringDisplay.Click
      ' Calls
      '   - modConnection.OpencpNorthwindScriptADOConnection(�ADODB.Connection)
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      Dim theConnection As New ADODB.Connection
      Dim theRecordset As New ADODB.Recordset

      OpencpNorthwindScriptADOConnection(theConnection)
      theRecordset.Open("SELECT * FROM tblCPOrder WHERE dtmOrderDate = '06/12/2007'", theConnection, ADODB.CursorTypeEnum.adOpenForwardOnly)
      txtResult.Text = theRecordset.GetString
      theRecordset.Close()
      theConnection.Close()
    End Sub
    ' OpenRecordsetWithGetStringDisplay(TextBox)

    Public Sub PersistingARecordset(ByVal txtResult As TextBox)
      '***
      ' Action
      '   - Create two new instances of a recordset
      '   - Create a new instance of a connection
      '   - Open a recordset
      '   - Show the original records
      '   - Try to
      '     - Delete the file of the previous run
      '   - Persist the recordset by writing it to a file
      '   - Close the recordset
      '   - Open a recordset using the persisted file
      '   - Show the result of the persisted file
      '   - Close the recordset
      '   - Close the connection
      ' Called by
      '   - frmMain.cmdPersistingARecordset_Click(System.Object, System.EventArgs) Handles cmdPersistingARecordset.Click
      ' Calls
      '   - modConnection.OpencpNorthwindScriptADOConnection(�ADODB.Connection)
      ' Created
      '   - CopyPaste � 20260331 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20260331 � VVDW
      ' Keyboard key
      '   -
      ' Proposal (To Do)
      '   -
      '***

      Const lngCmdFile As Long = 256
      Dim rstOriginal As New ADODB.Recordset
      Dim rstPersist As New ADODB.Recordset
      Dim theConnection As New ADODB.Connection

      OpencpNorthwindScriptADOConnection(theConnection)
      rstOriginal.Open("SELECT * FROM tblCPOrder WHERE dtmOrderDate = '06/12/2007'", theConnection, ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockOptimistic)
      txtResult.Text = "Orginal Records : " & CrLf & rstOriginal.GetString

      Try
        Kill("T:\OrdersForDate.rst")
      Catch theException As Exception
      Finally
      End Try

      rstOriginal.Save("T:\OrdersForDate.rst", ADODB.PersistFormatEnum.adPersistADTG)
      ' rstOriginal.Save("T:\OrdersForDate.rst", ADODB.PersistFormatEnum.adPersistXML)

      rstOriginal.Close()
      rstOriginal = Nothing

      rstPersist.Open("T:\OrdersForDate.rst", Options:=lngCmdFile)
      txtResult.Text &= CrLf & CrLf & "Persisted File : " & CrLf & rstPersist.GetString
      rstPersist.Close()
      theConnection.Close()
    End Sub
    ' PersistingARecordset(TextBox)

#End Region

#End Region

#End Region

    '#Region "Not used"
    '#End Region

  End Module
  ' modRecordset

End Namespace
' CopyPaste.Learning