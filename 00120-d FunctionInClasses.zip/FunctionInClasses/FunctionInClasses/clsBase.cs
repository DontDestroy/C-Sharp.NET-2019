//***
// Action
//   - Implementation of cpBase
// Created
//   - CopyPaste � 20240618 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240618 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpBase
  // public abstract class cpBase
  {

    #region "Constructors / Destructors"

    public cpBase()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpDerived()
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpBase()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    // public abstract bool SubMustOverride();

    // public sealed bool SubNotOverridable()
    // {
    //   Console.WriteLine("Sub Not Overridable in Base");
    //   return true;
    // }
    // // SubNotOverridable()

    public bool FunctionOverLoad()
      //***
      // Action
      //   - Show that the subroutine is overloaded
      //   - Return true
      // Called by
      //   - cpDerived.FunctionTestDerived()
      //   - cpProgram.Main()
      //   - FunctionTestBase()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Function Overload in Base");
      return true;
    }
    // bool FunctionOverLoad()

    public bool FunctionOverLoad(string strString)
      //***
      // Action
      //   - Show that the subroutine is overloaded
      //   - Return true
      // Called by
      //   - cpDerived.FunctionTestDerived()
      //   - cpProgram.Main()
      //   - FunctionTestBase()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Function Overload in Base with string: " + strString);
      return true;
    }
    // bool FunctionOverLoad(string)

    public virtual bool FunctionOverridable()
      //***
      // Action
      //   - Show that the subroutine is overridable
      //   - Return true
      // Called by
      //   - cpProgram.Main()
      //   - FunctionTestBase()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Function Overridable in Base");
      return true;
    }
    // bool FunctionOverridable()

    public bool FunctionShadows()
      //***
      // Action
      //   - Show that the subroutine is shadowed
      // Called by
      //   - modFunction.Main()
      //   - FunctionTestBase()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Function Shadows in Base");
      return true;
    }
    // bool FunctionShadows()

    public static bool FunctionStatic()
      //***
      // Action
      //   - Show that the subroutine is shared
      //   - Return true
      // Called by
      //   - cpDerived.FunctionTestDerived()
      //   - cpProgram.Main()
      //   - FunctionTestBase()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Function Static in Base");
      return true;
    }
    // bool FunctionStatic()

    public void FunctionTestBase()
      //***
      // Action
      //   - Execute all subroutines
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - bool FunctionMustOverride()
      //   - bool FunctionNotOverridable()
      //   - bool FunctionOverLoad()
      //   - bool FunctionOverLoad(String)
      //   - bool FunctionOverridable()
      //   - bool FunctionShadows()
      //   - bool FunctionStatic()
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnResult;

      blnResult = FunctionOverLoad();
      Console.WriteLine("Result is {0}", blnResult);
      blnResult = FunctionOverLoad("This is overloaded");
      Console.WriteLine("Result is {0}", blnResult);
      blnResult = FunctionOverridable();
      Console.WriteLine("Result is {0}", blnResult);
      // blnResult = FunctionNotOverridable();
      // Console.WriteLine("Result is {0}", blnResult);
      // blnResult = FunctionMustOverride();
      // Console.WriteLine("Result is {0}", blnResult);
      blnResult = FunctionShadows();
      Console.WriteLine("Result is {0}", blnResult);
      blnResult = FunctionStatic();
      Console.WriteLine("Result is {0}", blnResult);
    }
    // FunctionTestBase()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBase

}
// CopyPaste.Learning