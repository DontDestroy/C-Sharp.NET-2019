//***
// Action
//   - Testroutine for cpDemo
// Created
//   - CopyPaste � 20240709 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240709 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Reflection;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define a double, long and string variable
      //   - Create an instance of cpDemo
      //   - Define a method info
      //   - Define a parameter info
      //   - Loop thru all the methods
      //     - Define an array of parameters
      //     - Define a boolean to call the method (set to true)
      //     - Define a counter for looping thru the parameters
      //     - Loop thru all the parameters
      //       - Depending on the type of the parameter, the correct value is set into the array
      //         - When there is a parameter type that is not double, integer or string, the boolean becomes false
      //     - If boolean to call the method is true
      //       - Show the method name
      //       - If there are no parameters
      //         - Show the result of executing (invoking) the method with no parameters
      //       - If not
      //         - Show the result of executing (invoking) the method with the array of parameters
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpDemo()
      // Created
      //   - CopyPaste � 20240709 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240709 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      double dblVariable = 100.0;
      int lngVariable = 1;
      string strVariable = "Hello, is it me you're looking for?";
      cpDemo thecpDemo = new cpDemo();

      foreach (MethodInfo theMethodInfo in thecpDemo.GetType().GetMethods())
      {
        bool blnCallMethod = true;
        int lngNumber = 0;
        System.Object[] arrParameter = new System.Object[theMethodInfo.GetParameters().Length];

        foreach (ParameterInfo theParameterInfo in theMethodInfo.GetParameters())
        {

          if (Equals(theParameterInfo.ParameterType, lngVariable.GetType()))
          {
            arrParameter[lngNumber] = lngVariable;
          }
          else if (Equals(theParameterInfo.ParameterType, dblVariable.GetType()))
            // Not Equals(theParameterInfo.ParameterType, lngVariable.GetType())
          {
            arrParameter[lngNumber] = dblVariable;
          }
          else if (Equals(theParameterInfo.ParameterType, strVariable.GetType()))
            // Not Equals(theParameterInfo.ParameterType, dblVariable.GetType())
          {
            arrParameter[lngNumber] = strVariable;
          }
          else
            // Not Equals(theParameterInfo.ParameterType, strVariable.GetType())
          {
            blnCallMethod = false;
          }
          // Equals(theParameterInfo.ParameterType, lngVariable.GetType())
          // Equals(theParameterInfo.ParameterType, dblVariable.GetType())
          // Equals(theParameterInfo.ParameterType, strVariable.GetType())

          lngNumber++;
        }
        // theMethodInfo.GetParameters()

        if (blnCallMethod)
        {
          Console.WriteLine("Calling: " + theMethodInfo.Name);

          if (theMethodInfo.GetParameters().Length == 0)
          {
            Console.WriteLine(theMethodInfo.Invoke(thecpDemo, null));
          }
          else
            // theMethodInfo.GetParameters().Length <> 0
          {
            Console.WriteLine(theMethodInfo.Invoke(thecpDemo, arrParameter));
          }
          // theMethodInfo.GetParameters().Length = 0

          Console.WriteLine();
        }
        else
          // Not blnCallMethod
        {
        }
        // blnCallMethod

      }
      // in theDemo.GetType().GetMethods()

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning