//***
// Action
//   - A pet store, the definition of a cockatiel (base class, but inherits from cpBird)
//   - Working with properties (Get and Set) and methods in several classes, that can be reused
// Created
//   - CopyPaste � 20230407 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW
// Tested
//   - CopyPaste � 20230407 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace CopyPaste.Pet.Bird
{

  public class cpCockatiel : cpBird
  {

    #region "Constructors / Destructors"

    public cpCockatiel() : base ()
    //***
    // Action
    //   - Creating an instance of cpCockatiel with default parameters
    //   - Breed becomes "Cockatiel"
    //   - Cost becomes 250
    //   - Write a line "cpCockatiel default constructor"
    // Called by
    //   - 
    // Calls
    //   - base()
    //   - CopyPaste.Pet.cpAnimal.Breed(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Cost(decimal) (Set)
    // Created
    //   - CopyPaste � 20230407 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20230407 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Breed = "Cockatiel";
      Cost = 250;
      Console.WriteLine("cpCockatiel default constructor");
    }
    // cpCockatiel()

    public cpCockatiel(string strName, string strColor) : base (strName)
    //***
    // Action
    //   - Creating an instance of cpCockatiel with default parameters and strName
    //   - Breed becomes "Cockatiel"
    //   - Cost becomes 250
    //   - Coloration becomes strColor
    //   - Write a line "cpCockatiel overloaded constructor"
    // Called by
    //   - cpProgram.FillArray()
    // Calls
    //   - base(string)
    //   - CopyPaste.Pet.cpAnimal.Breed(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Coloration(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Cost(decimal) (Set)
    // Created
    //   - CopyPaste � 20230407 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20230407 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Breed = "Cockatiel";
      Cost = 250;
      Coloration = strColor;
      Console.WriteLine("cpCockatiel overloaded constructor");
    }
    // cpCockatiel(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override string Speak()
    //***
    // Action
    //   - Write a line to the console with "CopyPaste.Pet.Bird.cpCockatiel.Speak"
    //   - Return "(Name) says 'Squawkkk, (Name) want a cracker!'"
    // Called by
    //   - wpfPetStore.cmdSpeak_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdSpeak.Click
    // Calls
    //   - Overrides string CopyPaste.Pet.cpAnimal.Speak()
    //   - string CopyPaste.Pet.cpAnimal.Name (Get)
    // Created
    //   - CopyPaste � 20230407 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20230407 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Console.WriteLine("CopyPaste.Pet.Bird.cpCockatiel.Speak");
      return Name + " says 'Squawkkk, " + Name + " want a cracker!'";
    }
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCockatiel

}
// CopyPaste.Pet.Bird