//***
// Action
//   - Variables and assignment in one line
// Created
//   - CopyPaste � 20210825 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210825 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Proposal (To Do)
//   -
//***

using System;

namespace VariableObjects
{

  class cpVariableObjects
	{

    static void Main()
    //***
    // Action
    //   - Initialise some variables
    //   - Show the type minimum value and maximum value on the console screen
    //     - Two exceptions: Boolean and String does not have a minimum and maximum value
    //   - Wait for user action
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - byte byte.MaxValue
    //   - byte byte.MinValue
    //   - double double.MaxValue
    //   - double double.MinValue
    //   - decimal decimal.MaxValue
    //   - decimal decimal.MinValue
    //   - DateTime DateTime.MaxValue
    //   - DateTime DateTime.MinValue
    //   - float float.MinValue
    //   - float float.MaxValue
    //   - int int.MaxValue
    //   - int int.MinValue
    //   - long long.MaxValue
    //   - long long.MinValue
    //   - short short.MaxValue
    //   - short short.MinValue
    //   - string bool.FalseString()
    //   - string bool.TrueString()
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    //   - System.Console.WriteLine(string, System.Object)
    //   - System.Console.WriteLine(string, System.Object, System.Object, System.Object)
    //   - Type object.GetType()
    // Created
    //   - CopyPaste � 20210825 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210825 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      bool blnMarried = true;
      byte bytAsciiCode = 17;
      char chrMiddleInitial = 'V';
      double dblCarLoan = 23752.65;
      decimal decHomeLoan = 137240.25M;
      DateTime dtmBirthDate = new DateTime(1970, 5, 6);
      int intShoeSize = 42;
      long lngWeight = 179;
      object objSomething = "A nice message";
      short shtAge = 50;
      float sngAnnualIncome = 12345.67F;
      string strAddress = "C. Ameyestraat";

      Console.WriteLine("THE VARIABLE OBJECTS PROGRAM");
      Console.WriteLine("----------------------------");
      Console.WriteLine("Married = {0}, ({1} to {2}).",
        blnMarried.GetType(), bool.TrueString, bool.FalseString);
      Console.WriteLine("AsciiCode = {0}, ({1} to {2}).",
        bytAsciiCode.GetType(), byte.MinValue, byte.MaxValue);
      Console.WriteLine("MiddleInitial = {0}.", chrMiddleInitial.GetType());
      Console.WriteLine("CarLoan = {0}, ({1} to {2}).",
        dblCarLoan.GetType(), double.MinValue, double.MaxValue);
      Console.WriteLine("HomeLoan = {0}, ({1} to {2}).",
        decHomeLoan.GetType(), decimal.MinValue, decimal.MaxValue);
      Console.WriteLine("BirthDate = {0}, ({1} to {2}).",
        dtmBirthDate.GetType(), DateTime.MinValue, DateTime.MaxValue);
      Console.WriteLine("ShoeSize = {0}, ({1} to {2}).",
        intShoeSize.GetType(), int.MinValue, int.MaxValue);
      Console.WriteLine("Weight = {0}, ({1} to {2}).",
        lngWeight.GetType(), long.MinValue, long.MaxValue);
      Console.WriteLine("Something = {0}.", objSomething.GetType());
      Console.WriteLine("Age = {0}, ({1} to {2}).",
         shtAge.GetType(), short.MinValue, short.MaxValue);
      Console.WriteLine("AnnualIncome = {0}, ({1} to {2}).",
        sngAnnualIncome.GetType(), float.MinValue, float.MaxValue);
      Console.WriteLine("Address = {0}.", strAddress.GetType());
      Console.WriteLine("");
      Console.WriteLine("Press Enter...");
      Console.ReadLine();
    }
    // Main()

  }
  // cpVariableObjects

}
// VariableObjects