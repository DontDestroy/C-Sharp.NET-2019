//***
// Action
//   - A form to show pets from a pet store.
//   - Working with properties (Get and Set) and methods of the class cpPet and derived classes
// Created
//   - CopyPaste � 20220316 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW
// Tested
//   - CopyPaste � 20220316 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Pet
{

  public class frmPetStore : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    internal System.Windows.Forms.Label lblFood;
    internal System.Windows.Forms.TextBox txtFood;
    internal System.Windows.Forms.Label lblColor;
    internal System.Windows.Forms.Label lblCost;
    internal System.Windows.Forms.Label lblGender;
    internal System.Windows.Forms.Label lblSpecies;
    internal System.Windows.Forms.Label lblLeg;
    internal System.Windows.Forms.Label lblName;
    internal System.Windows.Forms.Button cmdPlay;
    internal System.Windows.Forms.TextBox txtName;
    internal System.Windows.Forms.TextBox txtCost;
    internal System.Windows.Forms.TextBox txtLeg;
    internal System.Windows.Forms.TextBox txtGender;
    internal System.Windows.Forms.TextBox txtBreed;
    internal System.Windows.Forms.Label lblBreed;
    internal System.Windows.Forms.TextBox txtSpecies;
    internal System.Windows.Forms.TextBox txtColor;
    internal System.Windows.Forms.Button cmdSpeak;
    internal System.Windows.Forms.Label lblAnimalList;
    internal System.Windows.Forms.ListBox lstAnimal;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPetStore));
      this.lblFood = new System.Windows.Forms.Label();
      this.txtFood = new System.Windows.Forms.TextBox();
      this.lblColor = new System.Windows.Forms.Label();
      this.lblCost = new System.Windows.Forms.Label();
      this.lblGender = new System.Windows.Forms.Label();
      this.lblSpecies = new System.Windows.Forms.Label();
      this.lblLeg = new System.Windows.Forms.Label();
      this.lblName = new System.Windows.Forms.Label();
      this.cmdPlay = new System.Windows.Forms.Button();
      this.txtName = new System.Windows.Forms.TextBox();
      this.txtCost = new System.Windows.Forms.TextBox();
      this.txtLeg = new System.Windows.Forms.TextBox();
      this.txtGender = new System.Windows.Forms.TextBox();
      this.txtBreed = new System.Windows.Forms.TextBox();
      this.lblBreed = new System.Windows.Forms.Label();
      this.txtSpecies = new System.Windows.Forms.TextBox();
      this.txtColor = new System.Windows.Forms.TextBox();
      this.cmdSpeak = new System.Windows.Forms.Button();
      this.lblAnimalList = new System.Windows.Forms.Label();
      this.lstAnimal = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // lblFood
      // 
      this.lblFood.Location = new System.Drawing.Point(199, 248);
      this.lblFood.Name = "lblFood";
      this.lblFood.Size = new System.Drawing.Size(56, 16);
      this.lblFood.TabIndex = 36;
      this.lblFood.Text = "Food:";
      // 
      // txtFood
      // 
      this.txtFood.Location = new System.Drawing.Point(263, 248);
      this.txtFood.Name = "txtFood";
      this.txtFood.Size = new System.Drawing.Size(176, 20);
      this.txtFood.TabIndex = 37;
      this.txtFood.Text = "";
      // 
      // lblColor
      // 
      this.lblColor.Location = new System.Drawing.Point(199, 152);
      this.lblColor.Name = "lblColor";
      this.lblColor.Size = new System.Drawing.Size(56, 16);
      this.lblColor.TabIndex = 30;
      this.lblColor.Text = "Colors:";
      // 
      // lblCost
      // 
      this.lblCost.Location = new System.Drawing.Point(199, 216);
      this.lblCost.Name = "lblCost";
      this.lblCost.Size = new System.Drawing.Size(56, 16);
      this.lblCost.TabIndex = 34;
      this.lblCost.Text = "Cost:";
      // 
      // lblGender
      // 
      this.lblGender.Location = new System.Drawing.Point(199, 120);
      this.lblGender.Name = "lblGender";
      this.lblGender.Size = new System.Drawing.Size(56, 16);
      this.lblGender.TabIndex = 28;
      this.lblGender.Text = "Gender:";
      // 
      // lblSpecies
      // 
      this.lblSpecies.Location = new System.Drawing.Point(199, 56);
      this.lblSpecies.Name = "lblSpecies";
      this.lblSpecies.Size = new System.Drawing.Size(56, 16);
      this.lblSpecies.TabIndex = 24;
      this.lblSpecies.Text = "Species:";
      // 
      // lblLeg
      // 
      this.lblLeg.Location = new System.Drawing.Point(199, 184);
      this.lblLeg.Name = "lblLeg";
      this.lblLeg.Size = new System.Drawing.Size(56, 16);
      this.lblLeg.TabIndex = 32;
      this.lblLeg.Text = "Legs:";
      // 
      // lblName
      // 
      this.lblName.Location = new System.Drawing.Point(199, 24);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(56, 16);
      this.lblName.TabIndex = 22;
      this.lblName.Text = "Name:";
      // 
      // cmdPlay
      // 
      this.cmdPlay.Location = new System.Drawing.Point(287, 288);
      this.cmdPlay.Name = "cmdPlay";
      this.cmdPlay.Size = new System.Drawing.Size(104, 32);
      this.cmdPlay.TabIndex = 39;
      this.cmdPlay.Text = "Play";
      this.cmdPlay.Click += new System.EventHandler(this.cmdPlay_Click);
      // 
      // txtName
      // 
      this.txtName.Location = new System.Drawing.Point(263, 24);
      this.txtName.Name = "txtName";
      this.txtName.Size = new System.Drawing.Size(176, 20);
      this.txtName.TabIndex = 23;
      this.txtName.Text = "";
      // 
      // txtCost
      // 
      this.txtCost.Location = new System.Drawing.Point(263, 216);
      this.txtCost.Name = "txtCost";
      this.txtCost.Size = new System.Drawing.Size(176, 20);
      this.txtCost.TabIndex = 35;
      this.txtCost.Text = "";
      // 
      // txtLeg
      // 
      this.txtLeg.Location = new System.Drawing.Point(263, 184);
      this.txtLeg.Name = "txtLeg";
      this.txtLeg.Size = new System.Drawing.Size(176, 20);
      this.txtLeg.TabIndex = 33;
      this.txtLeg.Text = "";
      // 
      // txtGender
      // 
      this.txtGender.Location = new System.Drawing.Point(263, 120);
      this.txtGender.Name = "txtGender";
      this.txtGender.Size = new System.Drawing.Size(176, 20);
      this.txtGender.TabIndex = 29;
      this.txtGender.Text = "";
      // 
      // txtBreed
      // 
      this.txtBreed.Location = new System.Drawing.Point(263, 88);
      this.txtBreed.Name = "txtBreed";
      this.txtBreed.Size = new System.Drawing.Size(176, 20);
      this.txtBreed.TabIndex = 27;
      this.txtBreed.Text = "";
      // 
      // lblBreed
      // 
      this.lblBreed.Location = new System.Drawing.Point(199, 88);
      this.lblBreed.Name = "lblBreed";
      this.lblBreed.Size = new System.Drawing.Size(56, 16);
      this.lblBreed.TabIndex = 26;
      this.lblBreed.Text = "Breed:";
      // 
      // txtSpecies
      // 
      this.txtSpecies.Location = new System.Drawing.Point(263, 56);
      this.txtSpecies.Name = "txtSpecies";
      this.txtSpecies.Size = new System.Drawing.Size(176, 20);
      this.txtSpecies.TabIndex = 25;
      this.txtSpecies.Text = "";
      // 
      // txtColor
      // 
      this.txtColor.Location = new System.Drawing.Point(263, 152);
      this.txtColor.Name = "txtColor";
      this.txtColor.Size = new System.Drawing.Size(176, 20);
      this.txtColor.TabIndex = 31;
      this.txtColor.Text = "";
      // 
      // cmdSpeak
      // 
      this.cmdSpeak.Location = new System.Drawing.Point(55, 288);
      this.cmdSpeak.Name = "cmdSpeak";
      this.cmdSpeak.Size = new System.Drawing.Size(104, 32);
      this.cmdSpeak.TabIndex = 38;
      this.cmdSpeak.Text = "Speak";
      this.cmdSpeak.Click += new System.EventHandler(this.cmdSpeak_Click);
      // 
      // lblAnimalList
      // 
      this.lblAnimalList.Location = new System.Drawing.Point(7, 8);
      this.lblAnimalList.Name = "lblAnimalList";
      this.lblAnimalList.Size = new System.Drawing.Size(144, 16);
      this.lblAnimalList.TabIndex = 20;
      this.lblAnimalList.Text = "List of animals:";
      // 
      // lstAnimal
      // 
      this.lstAnimal.Location = new System.Drawing.Point(7, 24);
      this.lstAnimal.Name = "lstAnimal";
      this.lstAnimal.Size = new System.Drawing.Size(168, 212);
      this.lstAnimal.TabIndex = 21;
      this.lstAnimal.SelectedIndexChanged += new System.EventHandler(this.lstAnimal_SelectedIndexChanged);
      // 
      // frmPetStore
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(446, 363);
      this.Controls.Add(this.lblFood);
      this.Controls.Add(this.txtFood);
      this.Controls.Add(this.lblColor);
      this.Controls.Add(this.lblCost);
      this.Controls.Add(this.lblGender);
      this.Controls.Add(this.lblSpecies);
      this.Controls.Add(this.lblLeg);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.cmdPlay);
      this.Controls.Add(this.txtName);
      this.Controls.Add(this.txtCost);
      this.Controls.Add(this.txtLeg);
      this.Controls.Add(this.txtGender);
      this.Controls.Add(this.txtBreed);
      this.Controls.Add(this.lblBreed);
      this.Controls.Add(this.txtSpecies);
      this.Controls.Add(this.txtColor);
      this.Controls.Add(this.cmdSpeak);
      this.Controls.Add(this.lblAnimalList);
      this.Controls.Add(this.lstAnimal);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPetStore";
      this.Text = "Pet Store";
      this.Load += new System.EventHandler(this.frmPetStore_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPetStore'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPetStore()
      //***
      // Action
      //   - Create instance of 'frmPetStore'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPetStore()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    int mintCounter;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdSpeak_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Shows a messagebox with the sound of the animal selected
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - string CopyPaste.Pet.cpAnimal.Speak()
      // Created
      //   - CopyPaste � 20220316 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW
      // Tested
      //   - CopyPaste � 20220316 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      MessageBox.Show(cpProgram.arrcpPets[lstAnimal.SelectedIndex].Speak());
    }
    // cmdSpeak_Click(System.Object, System.EventArgs) Handles cmdSpeak.Click

    private void cmdPlay_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Shows a messagebox how the animal selected plays
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - CopyPaste.Pet.cpAnimal.Play() As String
    // Created
    //   - CopyPaste � 20220316 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20220316 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      MessageBox.Show(cpProgram.arrcpPets[lstAnimal.SelectedIndex].Play());
    }
    // cmdPlay_Click(System.Object, System.EventArgs) Handles cmdPlay.Click

    private void frmPetStore_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Loop thru the arrcpPets
    //     - Put the breed in the listbox
    // Called by
    //   - Loading / Showing the form
    // Calls
    //   - string CopyPaste.Pet.cpAnimal.cpPet.Breed (Get)
    // Created
    //   - CopyPaste � 20220316 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20220316 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      for (mintCounter = 0; mintCounter < cpProgram.arrcpPets.Length; mintCounter++)
      {
        lstAnimal.Items.Add(cpProgram.arrcpPets[mintCounter].Breed);
      }
      // mintCounter = arrcpPets.Length

    }
    // frmPetStore_Load(System.Object, System.EventArgs) Handles this.Load

    private void lstAnimal_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Display the information of the selected pet in the listbox
    // Called by
    //   - Use action (Clicked another pet in the listbox)
    // Calls
    //   - Display(CopyPaste.Pet.cpPet)
    // Created
    //   - CopyPaste � 20220316 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20220316 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Display(cpProgram.arrcpPets[lstAnimal.SelectedIndex]);
    }
    // lstAnimal_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstAnimal.SelectedIndexChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"
        
    private void Display(CopyPaste.Pet.cpPet thePet)
    //***
    // Action
    //   - Display the information of the selected pet in the listbox
    //   - Fill a textbox with the name of the pet
    //   - Fill a textbox with the species of the pet
    //   - Fill a textbox with the breed of the pet
    //   - Fill a textbox with the gender of the pet
    //   - Fill a textbox with the color of the pet
    //   - Fill a textbox with the leg of the pet
    //   - Fill a textbox with the cost of the pet
    //   - Fill a textbox with the food of the pet
    // Called by
    //   - lstAnimal_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstAnimal.SelectedIndexChanged
    // Calls
    //   - decimal CopyPaste.Pet.cpAnimal.Cost (Get)
    //   - int CopyPaste.Pet.cpAnimal.Legs (Get)
    //   - string CopyPaste.Pet.cpAnimal.Breed (Get)
    //   - string CopyPaste.Pet.cpAnimal.Coloration (Get)
    //   - string CopyPaste.Pet.cpAnimal.Gender (Get)
    //   - string CopyPaste.Pet.cpAnimal.Name (Get)
    //   - string CopyPaste.Pet.cpAnimal.Species (Get)
    //   - string CopyPaste.Pet.cpPet.Food (Get)
    // Created
    //   - CopyPaste � 20220316 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20220316 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      txtName.Text = thePet.Name;
      txtSpecies.Text = thePet.Species;
      txtBreed.Text = thePet.Breed;
      txtGender.Text = thePet.Gender;
      txtColor.Text = thePet.Coloration;
      txtLeg.Text = thePet.Legs.ToString();
      txtCost.Text = thePet.Cost.ToString();
      txtFood.Text = thePet.Food;
    }
    // Display(CopyPaste.Pet.cpPet)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmPetStore

}
// CopyPaste.Pet