//***
// Action
//   - Basic functionalities on arrays
// Created
//   - CopyPaste � 20220216 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220216 � VVDW
// Proposal (To Do)
//   - 
//***

using System;

namespace ArrayExample
{

  class cpArray
	{

    static void Main()
      //***
      // Action
      //   - Define an array of 3 items (prices)
      //   - Define a array to copy to (copy)
      //   - Define an array of 5 items (values)
      //   - Loop thru the array of values
      //   - Copy array values to copy array
      //   - Loop thru the array of copy
      //   - Reverse the values
      //   - Loop thru the array of values
      //   - Show some info
      //   - Loop thru the array of prices
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Array.CopyTo(Array, int)
      //   - Array.Reverse(Array) 
      //   - Console.Write(string)
      //   - Console.WriteLine()
      //   - Console.WriteLine(string)
      //   - int Array.GetLowerBound(int)
      //   - int Array.GetUpperBound(int)
      //   - int Array.Length()
      //   - string Console.ReadLine()
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      double[] arrdblPrice = new double[] {25.5, 4.95, 33.4};
      long[] arrlngCopy = new long[5];
      long[] arrlngValue = new long[] {100, 200, 300, 400, 500};
      long lngCount;

      for (lngCount = 0; lngCount < 5; lngCount++)
      {
        Console.Write(arrlngValue[lngCount] + " ");
      }
      // lngCount = 5

      Console.WriteLine();

      arrlngValue.CopyTo(arrlngCopy, 0);

      for (lngCount = 0; lngCount < 5; lngCount++)
      {
        Console.Write(arrlngCopy[lngCount] + " ");
      }
      // lngCount = 5

      Console.WriteLine();
      
      Array.Reverse(arrlngValue);
      
      for (lngCount = 0; lngCount < 5; lngCount++)
      {
        Console.Write(arrlngValue[lngCount] + " ");
      }
      // lngCount = 5

      Console.WriteLine();
      Console.WriteLine("Array length: " + arrlngValue.Length);
      Console.WriteLine("Array lowerbound: " + arrlngValue.GetLowerBound(0));
      Console.WriteLine("Array upperbound: " + arrlngValue.GetUpperBound(0));
      
      for (lngCount = 0; lngCount <= arrdblPrice.GetUpperBound(0); lngCount++)
      {
        Console.Write(arrdblPrice[lngCount] + " ");
      }
      // lngCount = arrdblPrice.GetUpperBound(0) + 1 

      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

  }
  // cpArray

}
// ArrayExample