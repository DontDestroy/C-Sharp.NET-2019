﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmTextFiles.aspx.cs" Inherits="CopyPaste.Learning.wfrmTextFiles" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Text Files</title>
</head>
<body>
  <form id="wfrmTextFiles" method="post" runat="server">
    <asp:Button ID="cmdOrder" Style="z-index: 107; position: absolute; top: 176px; left: 240px"
      runat="server" Width="82px" Text="Order" TabIndex="3"></asp:Button>
    <asp:Label ID="lblMeat" Style="z-index: 104; position: absolute; top: 16px; left: 192px" runat="server">Meat</asp:Label>
    <asp:Label ID="lblFrenchFries" Style="z-index: 103; position: absolute; top: 16px; left: 24px"
      runat="server">French Fries</asp:Label>
    <asp:ListBox ID="lstFrenchFries" Style="z-index: 101; position: absolute; top: 40px; left: 24px"
      runat="server" Width="128px" Height="128px"></asp:ListBox>
    <asp:ListBox ID="lstMeat" Style="z-index: 102; position: absolute; top: 40px; left: 192px" runat="server"
      Width="128px" Height="128px" SelectionMode="Multiple" TabIndex="1"></asp:ListBox>
    <asp:Label ID="lblOrdered" Style="z-index: 106; position: absolute; top: 16px; left: 360px"
      runat="server">Ordered</asp:Label>
    <asp:ListBox ID="lstOrdered" Style="z-index: 105; position: absolute; top: 40px; left: 360px"
      runat="server" Height="120px" Width="128px" TabIndex="2"></asp:ListBox>
  </form>
</body>
</html>
