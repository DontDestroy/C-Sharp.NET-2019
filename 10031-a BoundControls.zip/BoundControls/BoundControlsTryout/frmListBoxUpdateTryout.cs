//***
// Action
//   - Edit and update data using bound controls
// Created
//   - CopyPaste � 20251231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251231 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmListBoxUpdateTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.GroupBox fraAction;
    internal System.Windows.Forms.Button cmdSave;
    internal System.Windows.Forms.Button cmdCancel;
    internal System.Windows.Forms.Button cmdEdit;
    internal System.Windows.Forms.GroupBox grpInfoCustomer;
    internal System.Windows.Forms.TextBox txtFax;
    internal System.Windows.Forms.TextBox txtCompanyName;
    internal System.Windows.Forms.TextBox txtAddress;
    internal System.Windows.Forms.TextBox txtContactTitle;
    internal System.Windows.Forms.TextBox txtIdCustomer;
    internal System.Windows.Forms.TextBox txtContact;
    internal System.Windows.Forms.TextBox txtCountry;
    internal System.Windows.Forms.TextBox txtCity;
    internal System.Windows.Forms.TextBox txtPostalCode;
    internal System.Windows.Forms.TextBox txtRegion;
    internal System.Windows.Forms.TextBox txtPhone;
    internal System.Windows.Forms.Label lblContactTitle;
    internal System.Windows.Forms.Label lblFax;
    internal System.Windows.Forms.Label lblRegion;
    internal System.Windows.Forms.Label lblCountry;
    internal System.Windows.Forms.Label lblPostalCode;
    internal System.Windows.Forms.Label lblCity;
    internal System.Windows.Forms.Label lblAddress;
    internal System.Windows.Forms.Label lblCustomerName;
    internal System.Windows.Forms.Label lblContact;
    internal System.Windows.Forms.Label lblIdCustomer;
    internal System.Windows.Forms.Label lblPhone;
    internal System.Windows.Forms.Label lblCustomer;
    internal System.Windows.Forms.Button cmdLoadList;
    internal System.Windows.Forms.TextBox txtCustomerLimit;
    internal System.Windows.Forms.ListBox lstCustomer;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmListBoxUpdateTryout));
      this.fraAction = new System.Windows.Forms.GroupBox();
      this.cmdSave = new System.Windows.Forms.Button();
      this.cmdCancel = new System.Windows.Forms.Button();
      this.cmdEdit = new System.Windows.Forms.Button();
      this.grpInfoCustomer = new System.Windows.Forms.GroupBox();
      this.txtFax = new System.Windows.Forms.TextBox();
      this.txtCompanyName = new System.Windows.Forms.TextBox();
      this.txtAddress = new System.Windows.Forms.TextBox();
      this.txtContactTitle = new System.Windows.Forms.TextBox();
      this.txtIdCustomer = new System.Windows.Forms.TextBox();
      this.txtContact = new System.Windows.Forms.TextBox();
      this.txtCountry = new System.Windows.Forms.TextBox();
      this.txtCity = new System.Windows.Forms.TextBox();
      this.txtPostalCode = new System.Windows.Forms.TextBox();
      this.txtRegion = new System.Windows.Forms.TextBox();
      this.txtPhone = new System.Windows.Forms.TextBox();
      this.lblContactTitle = new System.Windows.Forms.Label();
      this.lblFax = new System.Windows.Forms.Label();
      this.lblRegion = new System.Windows.Forms.Label();
      this.lblCountry = new System.Windows.Forms.Label();
      this.lblPostalCode = new System.Windows.Forms.Label();
      this.lblCity = new System.Windows.Forms.Label();
      this.lblAddress = new System.Windows.Forms.Label();
      this.lblCustomerName = new System.Windows.Forms.Label();
      this.lblContact = new System.Windows.Forms.Label();
      this.lblIdCustomer = new System.Windows.Forms.Label();
      this.lblPhone = new System.Windows.Forms.Label();
      this.lblCustomer = new System.Windows.Forms.Label();
      this.cmdLoadList = new System.Windows.Forms.Button();
      this.txtCustomerLimit = new System.Windows.Forms.TextBox();
      this.lstCustomer = new System.Windows.Forms.ListBox();
      this.fraAction.SuspendLayout();
      this.grpInfoCustomer.SuspendLayout();
      this.SuspendLayout();
      // 
      // fraAction
      // 
      this.fraAction.Controls.Add(this.cmdSave);
      this.fraAction.Controls.Add(this.cmdCancel);
      this.fraAction.Controls.Add(this.cmdEdit);
      this.fraAction.Location = new System.Drawing.Point(688, 30);
      this.fraAction.Name = "fraAction";
      this.fraAction.Size = new System.Drawing.Size(112, 304);
      this.fraAction.TabIndex = 11;
      this.fraAction.TabStop = false;
      this.fraAction.Text = "Actions";
      // 
      // cmdSave
      // 
      this.cmdSave.Enabled = false;
      this.cmdSave.Location = new System.Drawing.Point(16, 72);
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.Size = new System.Drawing.Size(88, 32);
      this.cmdSave.TabIndex = 1;
      this.cmdSave.Text = "&Save";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // cmdCancel
      // 
      this.cmdCancel.Enabled = false;
      this.cmdCancel.Location = new System.Drawing.Point(16, 264);
      this.cmdCancel.Name = "cmdCancel";
      this.cmdCancel.Size = new System.Drawing.Size(88, 32);
      this.cmdCancel.TabIndex = 2;
      this.cmdCancel.Text = "C&ancel";
      this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
      // 
      // cmdEdit
      // 
      this.cmdEdit.Location = new System.Drawing.Point(16, 24);
      this.cmdEdit.Name = "cmdEdit";
      this.cmdEdit.Size = new System.Drawing.Size(88, 32);
      this.cmdEdit.TabIndex = 0;
      this.cmdEdit.Text = "&Edit";
      this.cmdEdit.Click += new System.EventHandler(this.cmdEdit_Click);
      // 
      // grpInfoCustomer
      // 
      this.grpInfoCustomer.Controls.Add(this.txtFax);
      this.grpInfoCustomer.Controls.Add(this.txtCompanyName);
      this.grpInfoCustomer.Controls.Add(this.txtAddress);
      this.grpInfoCustomer.Controls.Add(this.txtContactTitle);
      this.grpInfoCustomer.Controls.Add(this.txtIdCustomer);
      this.grpInfoCustomer.Controls.Add(this.txtContact);
      this.grpInfoCustomer.Controls.Add(this.txtCountry);
      this.grpInfoCustomer.Controls.Add(this.txtCity);
      this.grpInfoCustomer.Controls.Add(this.txtPostalCode);
      this.grpInfoCustomer.Controls.Add(this.txtRegion);
      this.grpInfoCustomer.Controls.Add(this.txtPhone);
      this.grpInfoCustomer.Controls.Add(this.lblContactTitle);
      this.grpInfoCustomer.Controls.Add(this.lblFax);
      this.grpInfoCustomer.Controls.Add(this.lblRegion);
      this.grpInfoCustomer.Controls.Add(this.lblCountry);
      this.grpInfoCustomer.Controls.Add(this.lblPostalCode);
      this.grpInfoCustomer.Controls.Add(this.lblCity);
      this.grpInfoCustomer.Controls.Add(this.lblAddress);
      this.grpInfoCustomer.Controls.Add(this.lblCustomerName);
      this.grpInfoCustomer.Controls.Add(this.lblContact);
      this.grpInfoCustomer.Controls.Add(this.lblIdCustomer);
      this.grpInfoCustomer.Controls.Add(this.lblPhone);
      this.grpInfoCustomer.Location = new System.Drawing.Point(384, 30);
      this.grpInfoCustomer.Name = "grpInfoCustomer";
      this.grpInfoCustomer.Size = new System.Drawing.Size(296, 304);
      this.grpInfoCustomer.TabIndex = 10;
      this.grpInfoCustomer.TabStop = false;
      this.grpInfoCustomer.Text = "Info customer";
      // 
      // txtFax
      // 
      this.txtFax.BackColor = System.Drawing.SystemColors.Control;
      this.txtFax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtFax.Enabled = false;
      this.txtFax.Location = new System.Drawing.Point(120, 272);
      this.txtFax.Name = "txtFax";
      this.txtFax.Size = new System.Drawing.Size(160, 20);
      this.txtFax.TabIndex = 21;
      this.txtFax.Text = "";
      // 
      // txtCompanyName
      // 
      this.txtCompanyName.BackColor = System.Drawing.SystemColors.Control;
      this.txtCompanyName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCompanyName.Enabled = false;
      this.txtCompanyName.Location = new System.Drawing.Point(120, 56);
      this.txtCompanyName.Name = "txtCompanyName";
      this.txtCompanyName.Size = new System.Drawing.Size(160, 20);
      this.txtCompanyName.TabIndex = 3;
      this.txtCompanyName.Text = "";
      // 
      // txtAddress
      // 
      this.txtAddress.BackColor = System.Drawing.SystemColors.Control;
      this.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtAddress.Enabled = false;
      this.txtAddress.Location = new System.Drawing.Point(120, 128);
      this.txtAddress.Name = "txtAddress";
      this.txtAddress.Size = new System.Drawing.Size(160, 20);
      this.txtAddress.TabIndex = 9;
      this.txtAddress.Text = "";
      // 
      // txtContactTitle
      // 
      this.txtContactTitle.BackColor = System.Drawing.SystemColors.Control;
      this.txtContactTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtContactTitle.Enabled = false;
      this.txtContactTitle.Location = new System.Drawing.Point(120, 104);
      this.txtContactTitle.Name = "txtContactTitle";
      this.txtContactTitle.Size = new System.Drawing.Size(160, 20);
      this.txtContactTitle.TabIndex = 7;
      this.txtContactTitle.Text = "";
      // 
      // txtIdCustomer
      // 
      this.txtIdCustomer.BackColor = System.Drawing.SystemColors.Control;
      this.txtIdCustomer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtIdCustomer.Enabled = false;
      this.txtIdCustomer.Location = new System.Drawing.Point(120, 32);
      this.txtIdCustomer.Name = "txtIdCustomer";
      this.txtIdCustomer.Size = new System.Drawing.Size(160, 20);
      this.txtIdCustomer.TabIndex = 1;
      this.txtIdCustomer.Text = "";
      // 
      // txtContact
      // 
      this.txtContact.BackColor = System.Drawing.SystemColors.Control;
      this.txtContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtContact.Enabled = false;
      this.txtContact.Location = new System.Drawing.Point(120, 80);
      this.txtContact.Name = "txtContact";
      this.txtContact.Size = new System.Drawing.Size(160, 20);
      this.txtContact.TabIndex = 5;
      this.txtContact.Text = "";
      // 
      // txtCountry
      // 
      this.txtCountry.BackColor = System.Drawing.SystemColors.Control;
      this.txtCountry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCountry.Enabled = false;
      this.txtCountry.Location = new System.Drawing.Point(120, 224);
      this.txtCountry.Name = "txtCountry";
      this.txtCountry.Size = new System.Drawing.Size(160, 20);
      this.txtCountry.TabIndex = 17;
      this.txtCountry.Text = "";
      // 
      // txtCity
      // 
      this.txtCity.BackColor = System.Drawing.SystemColors.Control;
      this.txtCity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCity.Enabled = false;
      this.txtCity.Location = new System.Drawing.Point(120, 152);
      this.txtCity.Name = "txtCity";
      this.txtCity.Size = new System.Drawing.Size(160, 20);
      this.txtCity.TabIndex = 11;
      this.txtCity.Text = "";
      // 
      // txtPostalCode
      // 
      this.txtPostalCode.BackColor = System.Drawing.SystemColors.Control;
      this.txtPostalCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtPostalCode.Enabled = false;
      this.txtPostalCode.Location = new System.Drawing.Point(120, 200);
      this.txtPostalCode.Name = "txtPostalCode";
      this.txtPostalCode.Size = new System.Drawing.Size(160, 20);
      this.txtPostalCode.TabIndex = 15;
      this.txtPostalCode.Text = "";
      // 
      // txtRegion
      // 
      this.txtRegion.BackColor = System.Drawing.SystemColors.Control;
      this.txtRegion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtRegion.Enabled = false;
      this.txtRegion.Location = new System.Drawing.Point(120, 176);
      this.txtRegion.Name = "txtRegion";
      this.txtRegion.Size = new System.Drawing.Size(160, 20);
      this.txtRegion.TabIndex = 13;
      this.txtRegion.Text = "";
      // 
      // txtPhone
      // 
      this.txtPhone.BackColor = System.Drawing.SystemColors.Control;
      this.txtPhone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtPhone.Enabled = false;
      this.txtPhone.Location = new System.Drawing.Point(120, 248);
      this.txtPhone.Name = "txtPhone";
      this.txtPhone.Size = new System.Drawing.Size(160, 20);
      this.txtPhone.TabIndex = 19;
      this.txtPhone.Text = "";
      // 
      // lblContactTitle
      // 
      this.lblContactTitle.Location = new System.Drawing.Point(16, 104);
      this.lblContactTitle.Name = "lblContactTitle";
      this.lblContactTitle.Size = new System.Drawing.Size(88, 16);
      this.lblContactTitle.TabIndex = 6;
      this.lblContactTitle.Text = "Contact Title";
      // 
      // lblFax
      // 
      this.lblFax.Location = new System.Drawing.Point(16, 272);
      this.lblFax.Name = "lblFax";
      this.lblFax.Size = new System.Drawing.Size(88, 16);
      this.lblFax.TabIndex = 20;
      this.lblFax.Text = "Fax";
      // 
      // lblRegion
      // 
      this.lblRegion.Location = new System.Drawing.Point(16, 176);
      this.lblRegion.Name = "lblRegion";
      this.lblRegion.Size = new System.Drawing.Size(88, 16);
      this.lblRegion.TabIndex = 12;
      this.lblRegion.Text = "Region";
      // 
      // lblCountry
      // 
      this.lblCountry.Location = new System.Drawing.Point(16, 224);
      this.lblCountry.Name = "lblCountry";
      this.lblCountry.Size = new System.Drawing.Size(88, 16);
      this.lblCountry.TabIndex = 16;
      this.lblCountry.Text = "Country";
      // 
      // lblPostalCode
      // 
      this.lblPostalCode.Location = new System.Drawing.Point(16, 200);
      this.lblPostalCode.Name = "lblPostalCode";
      this.lblPostalCode.Size = new System.Drawing.Size(88, 16);
      this.lblPostalCode.TabIndex = 14;
      this.lblPostalCode.Text = "Postal Code";
      // 
      // lblCity
      // 
      this.lblCity.Location = new System.Drawing.Point(16, 152);
      this.lblCity.Name = "lblCity";
      this.lblCity.Size = new System.Drawing.Size(88, 16);
      this.lblCity.TabIndex = 10;
      this.lblCity.Text = "City";
      // 
      // lblAddress
      // 
      this.lblAddress.Location = new System.Drawing.Point(16, 128);
      this.lblAddress.Name = "lblAddress";
      this.lblAddress.Size = new System.Drawing.Size(88, 16);
      this.lblAddress.TabIndex = 8;
      this.lblAddress.Text = "Address";
      // 
      // lblCustomerName
      // 
      this.lblCustomerName.Location = new System.Drawing.Point(16, 56);
      this.lblCustomerName.Name = "lblCustomerName";
      this.lblCustomerName.Size = new System.Drawing.Size(88, 16);
      this.lblCustomerName.TabIndex = 2;
      this.lblCustomerName.Text = "Company Name";
      // 
      // lblContact
      // 
      this.lblContact.Location = new System.Drawing.Point(16, 80);
      this.lblContact.Name = "lblContact";
      this.lblContact.Size = new System.Drawing.Size(88, 16);
      this.lblContact.TabIndex = 4;
      this.lblContact.Text = "Contact";
      // 
      // lblIdCustomer
      // 
      this.lblIdCustomer.Location = new System.Drawing.Point(16, 32);
      this.lblIdCustomer.Name = "lblIdCustomer";
      this.lblIdCustomer.Size = new System.Drawing.Size(88, 16);
      this.lblIdCustomer.TabIndex = 0;
      this.lblIdCustomer.Text = "Customer Key";
      // 
      // lblPhone
      // 
      this.lblPhone.Location = new System.Drawing.Point(16, 248);
      this.lblPhone.Name = "lblPhone";
      this.lblPhone.Size = new System.Drawing.Size(88, 16);
      this.lblPhone.TabIndex = 18;
      this.lblPhone.Text = "Phone";
      // 
      // lblCustomer
      // 
      this.lblCustomer.Location = new System.Drawing.Point(8, 6);
      this.lblCustomer.Name = "lblCustomer";
      this.lblCustomer.Size = new System.Drawing.Size(56, 16);
      this.lblCustomer.TabIndex = 6;
      this.lblCustomer.Text = "Customer";
      // 
      // cmdLoadList
      // 
      this.cmdLoadList.Location = new System.Drawing.Point(288, 6);
      this.cmdLoadList.Name = "cmdLoadList";
      this.cmdLoadList.Size = new System.Drawing.Size(88, 24);
      this.cmdLoadList.TabIndex = 8;
      this.cmdLoadList.Text = "Load List";
      this.cmdLoadList.Click += new System.EventHandler(this.cmdLoadList_Click);
      // 
      // txtCustomerLimit
      // 
      this.txtCustomerLimit.Location = new System.Drawing.Point(72, 6);
      this.txtCustomerLimit.Name = "txtCustomerLimit";
      this.txtCustomerLimit.Size = new System.Drawing.Size(208, 20);
      this.txtCustomerLimit.TabIndex = 7;
      this.txtCustomerLimit.Text = "A";
      // 
      // lstCustomer
      // 
      this.lstCustomer.DisplayMember = "tblCPCustomer.strCompanyName";
      this.lstCustomer.Location = new System.Drawing.Point(8, 38);
      this.lstCustomer.Name = "lstCustomer";
      this.lstCustomer.Size = new System.Drawing.Size(368, 290);
      this.lstCustomer.TabIndex = 9;
      this.lstCustomer.ValueMember = "tblCPCustomer.strIdCustomer";
      this.lstCustomer.SelectedIndexChanged += new System.EventHandler(this.lstCustomer_SelectedIndexChanged);
      // 
      // frmListBoxUpdateTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(808, 341);
      this.Controls.Add(this.cmdLoadList);
      this.Controls.Add(this.txtCustomerLimit);
      this.Controls.Add(this.lstCustomer);
      this.Controls.Add(this.fraAction);
      this.Controls.Add(this.grpInfoCustomer);
      this.Controls.Add(this.lblCustomer);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmListBoxUpdateTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Edit and Update Data Using Bound Controls Tryout";
      this.Load += new System.EventHandler(this.frmListBoxUpdateTryout_Load);
      this.fraAction.ResumeLayout(false);
      this.grpInfoCustomer.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmListBoxUpdateTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmListBoxUpdateTryout()
      //***
      // Action
      //   - Create instance of 'frmListBoxUpdateTryout'
      // Called by
      //   - frmBoundControlsMainTryout.cmdListBoxUpdate_Click(System.Object, System.EventArgs) Handles cmdListBoxUpdate.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmListBoxUpdateTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCancel_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Cancel the current edits of the context
      //   - Disable the editing of the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ActivateEditing(Boolean)
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdCancel_Click(System.Object, System.EventArgs) Handles cmdCancel.Click

    private void cmdEdit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If a record is selected in the list box
      //     - Activate the editing
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ActivateEditing(Boolean)
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdEdit_Click(System.Object, System.EventArgs) Handles cmdEdit.Click

    private void cmdLoadList_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Load the list
      //   - Show the currently selected record in detail
      // Called by
      //   - frmListBoxUpdateTryout_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - LoadList()
      //   - RefreshIndividual()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click

    private void cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Save the record
      //   - Disable the editing of the form
      //   - Load the list (because data can be changed)
      //   - Refresh the detailed information (because record can be changed)
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ActivateEditing(Boolean)
      //   - LoadList()
      //   - RefreshIndividual()
      //   - SaveRecord()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click

    private void frmListBoxUpdateTryout_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Run the code that is executed when you click the LoadList button 
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click   
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // frmListBoxUpdateTryout_Load(System.Object, System.EventArgs) Handles this.Load

    private void lstCustomer_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Refresh the detailed information
      // Called by
      //   - User action (Selecting an item in the list box)
      // Calls
      //   - RefreshIndividual()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // lstCustomer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstCustomer.SelectedIndexChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void ActivateEditing(bool blnEnable)
      //***
      // Action
      //   - Define two controls
      //   - Loop thru the controls of the form
      //     - If the control is a groupbox
      //       - Loop thru the controls of the groupbox
      //         - If the control is a textbox
      //           - Define a new textbox
      //           - Assign the textbox
      //           - If boolean enabled
      //             - Change borderstyle to Fixed3D and colour to white
      //           - If not
      //             - Change borderstyle to FixedSingle and colour to the backcolor of the form
      //           - Set enabled of textbox to the boolean
      //         - If not
      //           - Do nothing
      //     - If not
      //       - Do nothing
      //   - Change the enabled of cmdCancel to boolean
      //   - Change the enabled of cmdSave to boolean
      // Called by
      //   - cmdCancel_Click(System.Object, System.EventArgs) Handles cmdCancel.Click
      //   - cmdEdit_Click(System.Object, System.EventArgs) Handles cmdEdit.Click
      //   - cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // ActivateEditing(bool)

    private void LoadList()
      //***
      // Action
      //   - Set the parameter of the select command to the text on the form
      //   - Clear the data set
      //   - Fill the data set using the data adapter
      // Called by
      //   - cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click
      //   - cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // LoadList()

    private void RefreshIndividual()
      //***
      // Action
      //   - Clear the data set with detailed information
      //   - If an item is selected in the listbox
      //     - Define and set a data row view with the currently selected item
      //     - Set the parameter to the data table select command to select the correct customer
      //     - Fill the data set using the data adapter
      //   - If not
      //     - Do nothing
      // Called by
      //   - cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click
      //   - cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      //   - lstCustomer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstCustomer.SelectedIndexChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // RefreshIndividual()

    private void SaveRecord()
      //***
      // Action
      //   - Stop editing the context
      //   - Update the data set using the data adapter
      //   - Accept the changes
      // Called by
      //   - cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // SaveRecord()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmListBoxUpdateTryout

}
// CopyPaste.Learning