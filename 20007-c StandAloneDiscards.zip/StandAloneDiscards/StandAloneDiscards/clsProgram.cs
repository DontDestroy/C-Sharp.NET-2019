﻿//***
// Action
//   - Example of stand alone discards
// Created
//   - CopyPaste – 20251222 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251222 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251222 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251222 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - When executing an update command, the number of records affected is returned
    //   - In several cases you are not interested in the result, so you discard the result value
    //   - Three examples to update a recordset
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - int ExecuteCommand(string, string)
    // Created
    //   - CopyPaste – 20251222 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251222 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intNumberOfRecordsAffected;
      string strConnectionString;
      string strSQLStatement;

      strConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integrated Security=True";
      strSQLStatement = "UPDATE tblCPCategory SET [strCategoryName] = [strCategoryName]";
      // VVDW - All records are updated, but nothing is changed

      // VVDW - I'm interested in the result
      intNumberOfRecordsAffected = ExecuteCommand(strSQLStatement, strConnectionString);
      Console.WriteLine($"{intNumberOfRecordsAffected} records are affected");

      // VVDW - I'm not interested in the result
      _ = ExecuteCommand(strSQLStatement, strConnectionString);
      // VVDW - The line below is a mistake, the _ variable is not usable because it is discarded
      // Console.WriteLine($"{_} records are affected");

      // VVDW - Alternative way
      ExecuteCommand(strSQLStatement, strConnectionString);

      Console.WriteLine();
      Console.WriteLine("Hit any key");
      _ = Console.ReadLine();
    }
    // Main()

    private static int ExecuteCommand(string strSQLStatement, string strConnectionString)
    //***
    // Action
    //   - Create a SQL connection using a given strConnectionString
    //   - Create a SQL command using the given strSQLStatement and the connection
    //   - Open the connection
    //   - Return the number of records affected
    //   - Clean up the connection
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251222 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251222 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      using (SqlConnection theConnection = new SqlConnection(strConnectionString))
      {
        SqlCommand cmd = new SqlCommand(strSQLStatement, theConnection);
        cmd.Connection.Open();
        return cmd.ExecuteNonQuery();
      }
      // Clean theConnection

    }
    // int ExecuteCommand(string, string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx