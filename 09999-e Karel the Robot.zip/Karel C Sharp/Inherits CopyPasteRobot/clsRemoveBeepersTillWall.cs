﻿//***
// Action
//   - A definition of a RemoveBeepersTillWall
// Created
//   - CopyPaste – 20251022 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251022 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpRemoveBeepersTillWall : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpRemoveBeepersTillWall(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpRemoveBeepersTillWall starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpProgram.RemoveBeepersTillWall()
    //   - cpRemoveBeepersTillWall(int, int, Directions.Direction, int)
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251022 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251022 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRemoveBeepersTillWall(int, int, Directions.Direction, int, Color) 

    public cpRemoveBeepersTillWall(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpRemoveBeepersTillWall starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpRemoveBeepersTillWall(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251022 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251022 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRemoveBeepersTillWall(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void RemoveBeepersTillWall()
    //***
    // Action
    //   - A row of beepers will be removes
    //   - As long the front is clear
    //     - Move
    //     - Pick beeper
    // Called by
    //   - cpProgram.RemoveBeepersTillWall()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251022 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251022 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (frontIsClear())
      {
        move();
        pickBeeper();
      }
      // frontIsClear()

    }
    // RemoveBeepersTillWall()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpRemoveBeepersTillWall

}
// cpKarelTheRobot