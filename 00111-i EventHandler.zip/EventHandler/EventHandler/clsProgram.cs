//***
// Action
//   - Testroutines for cpAlarmGroup
// Created
//   - CopyPaste � 20240524 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240524 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Alarm;
using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    private static cpAlarmGroup mcpAlarm;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private static void Burglar()
      //***
      // Action
      //   - Show a message that the burglar alarm is triggered
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Burglar alarm occured");
    }
    // Burglar() Handles mcpAlarm.BurglarAlarm

    private static void Fire(int lngTemperature)
      //***
      // Action
      //   - Show a message that the fire alarm is triggered with a certain temperature
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Fire alarm occurred: Temp: " + lngTemperature);
    }
    // Fire(int) Handles mcpAlarm.FireAlarm

    private static void Motion(string strRoom, int lngDuration)
      //***
      // Action
      //   - Show a message that the fire alarm is triggered with a certain temperature
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Motion alarm occurred: Temp: " + strRoom + " " + lngDuration);
    }
    // Motion(string, int) Handles mcpAlarm.MotionAlarm

    #endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Generate the events of mcpAlarm
      //   - Wait for user action
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Burglar() Handles mcpAlarm.BurglarAlarm
      //   - cpAlarmGroup()
      //   - cpAlarmGroup.BurglarAlarm()
      //   - cpAlarmGroup.GenerateEvents()
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mcpAlarm = new cpAlarmGroup();

      if (mcpAlarm == null)
      {
      }
      else
        // mcpAlarm <> null
      {
        mcpAlarm.BurglarAlarm += new cpAlarmGroup.cpBurglarAlarm(Burglar);
        mcpAlarm.FireAlarm += new cpAlarmGroup.cpFireAlarm(Fire);
        mcpAlarm.MotionAlarm += new cpAlarmGroup.cpMotionAlarm(Motion);

        mcpAlarm.GenerateEvents();
      }
      // mcpAlarm == null

      Console.WriteLine("");
      Console.WriteLine("Hit enter to stop program");
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning