//***
// Action
//   - Check the lock status of a file
// Created
//   - CopyPaste � 20240902 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240902 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFileLock: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblFileContents;
    internal System.Windows.Forms.Label lblStatus;
    internal System.Windows.Forms.TextBox txtFileContents;
    internal System.Windows.Forms.Button cmdUpdate;
    internal System.Windows.Forms.TextBox txtStatus;
    internal System.Windows.Forms.Button cmdUnlock;
    internal System.Windows.Forms.Button cmdLock;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFileLock));
      this.lblFileContents = new System.Windows.Forms.Label();
      this.lblStatus = new System.Windows.Forms.Label();
      this.txtFileContents = new System.Windows.Forms.TextBox();
      this.cmdUpdate = new System.Windows.Forms.Button();
      this.txtStatus = new System.Windows.Forms.TextBox();
      this.cmdUnlock = new System.Windows.Forms.Button();
      this.cmdLock = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // lblFileContents
      // 
      this.lblFileContents.Location = new System.Drawing.Point(24, 176);
      this.lblFileContents.Name = "lblFileContents";
      this.lblFileContents.TabIndex = 12;
      this.lblFileContents.Text = "File Contents";
      // 
      // lblStatus
      // 
      this.lblStatus.Location = new System.Drawing.Point(24, 64);
      this.lblStatus.Name = "lblStatus";
      this.lblStatus.TabIndex = 10;
      this.lblStatus.Text = "Status";
      // 
      // txtFileContents
      // 
      this.txtFileContents.Location = new System.Drawing.Point(24, 208);
      this.txtFileContents.Multiline = true;
      this.txtFileContents.Name = "txtFileContents";
      this.txtFileContents.Size = new System.Drawing.Size(248, 64);
      this.txtFileContents.TabIndex = 13;
      this.txtFileContents.Text = "";
      // 
      // cmdUpdate
      // 
      this.cmdUpdate.Location = new System.Drawing.Point(200, 20);
      this.cmdUpdate.Name = "cmdUpdate";
      this.cmdUpdate.TabIndex = 9;
      this.cmdUpdate.Text = "Update";
      this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
      // 
      // txtStatus
      // 
      this.txtStatus.Location = new System.Drawing.Point(24, 96);
      this.txtStatus.Multiline = true;
      this.txtStatus.Name = "txtStatus";
      this.txtStatus.Size = new System.Drawing.Size(248, 64);
      this.txtStatus.TabIndex = 11;
      this.txtStatus.Text = "";
      // 
      // cmdUnlock
      // 
      this.cmdUnlock.Location = new System.Drawing.Point(112, 20);
      this.cmdUnlock.Name = "cmdUnlock";
      this.cmdUnlock.TabIndex = 8;
      this.cmdUnlock.Text = "Unlock";
      this.cmdUnlock.Click += new System.EventHandler(this.cmdUnlock_Click);
      // 
      // cmdLock
      // 
      this.cmdLock.Location = new System.Drawing.Point(24, 20);
      this.cmdLock.Name = "cmdLock";
      this.cmdLock.TabIndex = 7;
      this.cmdLock.Text = "Lock";
      this.cmdLock.Click += new System.EventHandler(this.cmdLock_Click);
      // 
      // frmFileLock
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(312, 293);
      this.Controls.Add(this.lblFileContents);
      this.Controls.Add(this.lblStatus);
      this.Controls.Add(this.txtFileContents);
      this.Controls.Add(this.cmdUpdate);
      this.Controls.Add(this.txtStatus);
      this.Controls.Add(this.cmdUnlock);
      this.Controls.Add(this.cmdLock);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFileLock";
      this.Text = "File Lock";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFileLock'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFileLock()
      //***
      // Action
      //   - Create instance of 'frmFileLock'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFileLock()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public FileStream mfilstrText = new FileStream("T:\\Data.dat", FileMode.Create, FileAccess.Write, FileShare.Write);
    public string mstrCrLf = Environment.NewLine;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdLock_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try
      //     - Lock the file stream
      //     - Append a text to the form that it was locked
      //   - On error
      //     - Append a text to the form with the exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        mfilstrText.Lock(0, 100);
        txtFileContents.Text = "Locked";
      }
      catch (Exception theException)
      {
        txtStatus.AppendText(theException.Message + mstrCrLf);
      }
      finally
      {
      }
    
    }
    // cmdLock_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdLock.Click

    private void cmdUnlock_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try
      //     - Unlock the file stream
      //     - Append a text to the form that it was unlocked
      //   - On error
      //     - Append a text to the form with the exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        mfilstrText.Unlock(0, 100);
        txtFileContents.Text = "Unlocked";
      }
      catch (Exception theException)
      {
        txtStatus.AppendText(theException.Message + mstrCrLf);
      }
      finally
      {
      }

    }
    // cmdUnlock_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdUnLock.Click

    private void cmdUpdate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a byte array containing 1 till 5
      //   - Try
      //     - Seek the beginning of the file stream
      //     - Write the byte array to the file
      //     - Append a text to the form that it was succesful
      //   - On error
      //     - Append a text to the form with the exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      byte[] arrbytValue;
 
      arrbytValue = new byte[] {1, 2, 3, 4, 5};

      try
      {
        mfilstrText.Seek(0, SeekOrigin.Begin);
        mfilstrText.Write(arrbytValue, 0, 5);
        txtFileContents.AppendText(mstrCrLf + "Successfully updated file" + mstrCrLf);
      }
      catch (Exception theException)
      {
        txtStatus.AppendText(theException.Message + mstrCrLf);
      }
      finally
      {
      }
    
    }
    // cmdUpdate_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdUpdate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFileLock
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmFileLock()
      // Created
      //   - CopyPaste � 20240902 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240902 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFileLock());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmFileLock

}
// CopyPaste.Learning