//***
// Action
//   - Beep (not working on some machine)
// Created
//   - CopyPaste � 20211018 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20211018 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using Microsoft.VisualBasic;

namespace BeepMeUpScotty
{

  class cpBeep
	{

    static void Main()
    //***
    // Action
    //   - Loop 'lngCounter'
    //   - Beep a sound
    // Called by
    //   - 
    // Calls
    //   - Microsoft.VisualBasic.Beep()
    // Created
    //   - CopyPaste � 20211018 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20211018 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      long lngCounter;

      for (lngCounter = 1; lngCounter <= 5000000; lngCounter++)
      {
      }
      // lngCounter = 5000001

      Interaction.Beep();
    }
    // Main()

  }
  // cpBeep

}
// BeepMeUpScotty
