﻿//***
// Action
//   - Demo of .NET Core application (Console)
// Created
//   - CopyPaste – 20260428 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260428 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Security.Cryptography;
using System.Text;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"

    public static string Decrypt(byte[] arrbytKey, byte[] arrbytNonce, byte[] arrbytTag, byte[] arrbytDataToDecrypt)
    //***
    // Action
    //   - Decrypt a given array into a result
    //   - There is one output with four inputs
    //     - The Decrypted text
    //     - The key (input parameter)
    //     - The nonce (input parameter)
    //     - The tag (input parameter)
    //     - The encryption (input parameter)
    //   - Decrypt the array with the encryption
    //   - Convert the result into a string
    //   - Return the string
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260428 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260428 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      byte[] arrbytDecryptedData = new byte[arrbytDataToDecrypt.Length];
      string strDecryption;

      using (AesGcm theAdvancedEncryptionStandard = new AesGcm(arrbytKey))
      {
        theAdvancedEncryptionStandard.Decrypt(arrbytNonce, arrbytDataToDecrypt, arrbytTag, arrbytDecryptedData);
      }
      // AesGcm theAdvancedEncryptionStandard 

      // using (AesCcm theAdvancedEncryptionStandard = new AesCcm(arrbytKey))
      // {
      //   theAdvancedEncryptionStandard.Decrypt(arrbytNonce, arrbytDataToDecrypt, arrbytTag, arrbytDecryptedData);
      // }
      // // AesCcm theAdvancedEncryptionStandard 

      strDecryption = Encoding.UTF8.GetString(arrbytDecryptedData);
      return strDecryption;
    }
    // string Decrypt(byte[], byte[], byte[], byte[])

    public static byte[] Encrypt(out byte[] arrbytKey, out byte[] arrbytNonce, out byte[] arrbytTag, byte[] arrbytDataToEncrypt)
    //***
    // Action
    //   - Encrypt a given text into a result
    //   - There are four outputs
    //     - The encrypted text
    //     - The key (output parameter)
    //     - The nonce (output parameter)
    //     - The tag (output parameter)
    //   - Create a key of 16 bytes 
    //   - Create a nonce of 12 bytes 
    //   - Create a tag of 16 bytes 
    //   - Fill key with random information
    //   - Fill nonce with random information
    //   - Get the length of the text to encrypt
    //   - Encrypt the text
    //   - Return the result
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260428 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260428 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      byte[] arrbytCipherText;

      arrbytKey = new byte[16];
      arrbytNonce = new byte[12];
      arrbytTag = new byte[16];

      RandomNumberGenerator.Fill(arrbytKey);
      RandomNumberGenerator.Fill(arrbytNonce);

      arrbytCipherText = new byte[arrbytDataToEncrypt.Length];

      using (AesGcm theAdvancedEncryptionStandard = new AesGcm(arrbytKey))
      {
        theAdvancedEncryptionStandard.Encrypt(arrbytNonce, arrbytDataToEncrypt, arrbytCipherText, arrbytTag);
      }
      // AesGcm theAdvancedEncryptionStandard 

      // using (AesCcm theAdvancedEncryptionStandard = new AesCcm(arrbytKey))
      // {
      //   theAdvancedEncryptionStandard.Encrypt(arrbytNonce, arrbytDataToEncrypt, arrbytCipherText, arrbytTag);
      // }
      // // AesCcm theAdvancedEncryptionStandard 

      return arrbytCipherText;
    }
    // byte[] Encrypt(byte[], byte[], byte[], byte[])

    public static void Main()
    //***
    // Action
    //   - Starting point of the application
    //   - Define a text to encrypt
    //   - Convert the text into an array of bytes
    //   - Encrypt the array of a certain text into a result
    //   - Decrypt the result of the encryption into a result
    //   - Show the result (it should be the original text)
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - byte[] Encrypt(byte[], byte[], byte[], byte[])
    //   - string GetHexBytes(byte[])
    // Created
    //   - CopyPaste – 20260428 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260428 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strDecryption;
      string strEncryption;
      string strGivenText = "A certain text to encrypt and decrypt. The result should be exactly the same.";
      string strKey;
      string strNonce;
      string strTag;

      Console.WriteLine($"Text to encrypt: {0}", strGivenText);
      Console.WriteLine();

      byte[] arrbytDataToEncrypt = Encoding.UTF8.GetBytes(strGivenText);
      byte[] arrbytEncryptedData = Encrypt(out byte[] arrbytKey, out byte[] arrbytNonce, out byte[] arrbytTag, arrbytDataToEncrypt);

      strEncryption = GetHexBytes(arrbytEncryptedData);
      strKey = GetHexBytes(arrbytKey);
      strNonce = GetHexBytes(arrbytNonce);
      strTag = GetHexBytes(arrbytTag);

      Console.WriteLine("Given text: {0}", strGivenText);
      Console.WriteLine("Encrypted text: {0}", strEncryption);
      Console.WriteLine("Used key: {0}", strKey);
      Console.WriteLine("Used nonce: {0}", strNonce);
      Console.WriteLine("Used tag: {0}", strTag);

      strDecryption = Decrypt(arrbytKey, arrbytNonce, arrbytTag, arrbytEncryptedData);

      Console.WriteLine();
      Console.WriteLine("Decrypted text: {0}", strDecryption);

      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadLine();
    }
    // Main()

    public static string GetHexBytes(byte[] arrbytGiven)
    //***
    // Action
    //   - You receive a given array of bytes
    //   - Show the hex code of the bytes
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260428 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260428 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strResult = "";
      int intLength = arrbytGiven.Length;

      if ((arrbytGiven == null) || (arrbytGiven.Length == 0))
      {
      }
      else
      // (arrbytGiven <> null) And (arrbytGiven.Length <> 0)
      {

        for (int intCounter = 0; intCounter < intLength; intCounter++)
        {
          strResult += string.Format("{0:X2} ", arrbytGiven[intCounter]);
        }
        // intCounter = intLength

      }
      // ((arrbytGiven == null) Or (arrbytGiven.Length == 0))

      return strResult;
    }
    // string GetHexBytes(byte[])

    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning