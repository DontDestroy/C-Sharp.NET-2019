﻿//***
// Action
//   - Definition of a Person
// Created
//   - CopyPaste – 20230713 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230713 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Text;

namespace CopyPaste.BusinessObjects
{

  [SerializableAttribute]
  public class Person
  {

    #region "Constructors / Destructors"

    public Person()
    //***
    // Action
    //   - Default constructor for Person
    //   - The relation towards PersonDetail is set up
    // Called by
    //   - 
    // Calls
    //   - Detail(PersonDetail) (Set)
    // Created
    //   - CopyPaste – 20230713 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230713 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Detail = new PersonDetail();
    }
    // Person()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public Nullable<DateTime> BirthDay { get; set; }
    public virtual string Email { get; set; }

    // This property does not have a set in the property
    // This property becomes not a column in the table Person
    public string FullName => GivenName + " " + Surname;

    public string GivenName { get; set; }

    // A relation towards entity class PersonDetail
    // Mandatory and not foreign key property
    // The field DetailId will be created in the table Person
    public virtual PersonDetail Detail { get; set; }
    
    // This is by convention <<classname>>Id -> PersonId or PersonID
    public int PersonId { get; set; } 
    public string Surname { get; set; }

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
    //***
    // Action
    //   - Returns the person primary key and the full name
    // Called by
    //   - 
    // Calls
    //   - int PersonId (Get)
    //   - string FullName (Get)
    // Created
    //   - CopyPaste – 20230713 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230713 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return "#" + PersonId + ": " + FullName;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Person

}
// CopyPaste.BusinessObjects 