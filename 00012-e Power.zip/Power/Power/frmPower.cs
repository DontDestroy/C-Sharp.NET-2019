//***
// Action
//   - Calculate power
// Created
//   - CopyPaste � 20230620 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230620 � VVDW
// Proposal (To Do)
//   - There are a lot of error in this form
//   - The exercise it to add errorroutines to it
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Power
{

  public class frmPower : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    internal System.Windows.Forms.TextBox txtPower;
    internal System.Windows.Forms.Label lblPower;
    internal System.Windows.Forms.Label lblBase;
    internal System.Windows.Forms.Button cmdCalculate;
    internal System.Windows.Forms.TextBox txtBase;
    internal System.Windows.Forms.Label lblOutput;
    internal System.Windows.Forms.GroupBox grpInput;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPower));
      this.txtPower = new System.Windows.Forms.TextBox();
      this.lblPower = new System.Windows.Forms.Label();
      this.lblBase = new System.Windows.Forms.Label();
      this.cmdCalculate = new System.Windows.Forms.Button();
      this.txtBase = new System.Windows.Forms.TextBox();
      this.lblOutput = new System.Windows.Forms.Label();
      this.grpInput = new System.Windows.Forms.GroupBox();
      this.SuspendLayout();
      // 
      // txtPower
      // 
      this.txtPower.Location = new System.Drawing.Point(96, 46);
      this.txtPower.Name = "txtPower";
      this.txtPower.Size = new System.Drawing.Size(56, 20);
      this.txtPower.TabIndex = 11;
      this.txtPower.Text = "";
      // 
      // lblPower
      // 
      this.lblPower.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblPower.Location = new System.Drawing.Point(96, 22);
      this.lblPower.Name = "lblPower";
      this.lblPower.Size = new System.Drawing.Size(64, 16);
      this.lblPower.TabIndex = 9;
      this.lblPower.Text = "Power";
      // 
      // lblBase
      // 
      this.lblBase.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblBase.Location = new System.Drawing.Point(32, 22);
      this.lblBase.Name = "lblBase";
      this.lblBase.Size = new System.Drawing.Size(48, 24);
      this.lblBase.TabIndex = 8;
      this.lblBase.Text = "Base";
      // 
      // cmdCalculate
      // 
      this.cmdCalculate.Location = new System.Drawing.Point(176, 46);
      this.cmdCalculate.Name = "cmdCalculate";
      this.cmdCalculate.Size = new System.Drawing.Size(120, 32);
      this.cmdCalculate.TabIndex = 13;
      this.cmdCalculate.Text = "Calculate Power";
      this.cmdCalculate.Click += new System.EventHandler(this.cmdCalculate_Click);
      // 
      // txtBase
      // 
      this.txtBase.Location = new System.Drawing.Point(24, 46);
      this.txtBase.Name = "txtBase";
      this.txtBase.Size = new System.Drawing.Size(56, 20);
      this.txtBase.TabIndex = 10;
      this.txtBase.Text = "";
      // 
      // lblOutput
      // 
      this.lblOutput.Location = new System.Drawing.Point(184, 14);
      this.lblOutput.Name = "lblOutput";
      this.lblOutput.Size = new System.Drawing.Size(112, 24);
      this.lblOutput.TabIndex = 12;
      this.lblOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // grpInput
      // 
      this.grpInput.Location = new System.Drawing.Point(8, 6);
      this.grpInput.Name = "grpInput";
      this.grpInput.Size = new System.Drawing.Size(160, 72);
      this.grpInput.TabIndex = 7;
      this.grpInput.TabStop = false;
      // 
      // frmPower
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(304, 85);
      this.Controls.Add(this.txtPower);
      this.Controls.Add(this.lblPower);
      this.Controls.Add(this.lblBase);
      this.Controls.Add(this.cmdCalculate);
      this.Controls.Add(this.txtBase);
      this.Controls.Add(this.lblOutput);
      this.Controls.Add(this.grpInput);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPower";
      this.Text = "Power";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmPower'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPower()
    //***
    // Action
    //   - Create instance of 'frmPower'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmPower()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCalculate_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Reads input and displays result
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - int Power(int, int)
    //   - int System.Convert.ToInt32(string)
    //   - string System.Convert.ToString(int)
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      int lngValue;

      if (txtPower.Text == "")
      {
        lngValue = Power(Convert.ToInt32(txtBase.Text), 2);
      }
      else
      // txtPower.Text <> "" 
      {
        lngValue = Power(Convert.ToInt32(txtBase.Text), Convert.ToInt32(txtPower.Text));
      }
      // txtPower.Text = "" 

      lblOutput.Text = Convert.ToString(lngValue);
    }
    // cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click

    private void frmPower_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Starting the form
    // Called by
    //   - User action (Loading a form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // frmPower_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmPower
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmPower());
    }
    // Main() 
    
    private int Power(int lngBase, int lngExponent)
    //***
    // Action
    //   - Use iteration to calculate power
    //   - Loop from 1 to lngExponent (lngCounter)
    //     - 'lngTotal' becomes 'lngTotal' * 'lngBase'
    //   - Return lngTotal
    // Called by
    //   - cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230620 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230620 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      int lngCounter;
      int lngTotal = 1;

      for (lngCounter = 1; lngCounter <= lngExponent; lngCounter++)
      {
        lngTotal *= lngBase;
      }
      // lngCounter = lngExponent + 1

      return lngTotal;
    }
    // int Power(int, int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmPower

}
// CopyPaste.Power