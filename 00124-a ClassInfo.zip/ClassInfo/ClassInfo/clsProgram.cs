//***
// Action
//   - Testroutine for cpBook
// Created
//   - CopyPaste � 20240704 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240704 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Reflection;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create an instance of a cpBook
      //   - Show information for method names
      //   - Loop trhu all the methods of the instance of a cpBook
      //   - Show information for member names
      //   - Loop trhu all the members of the instance of a cpBook
      //     - Pay attention, methods are also members
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpBook(string, string, double)
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpBook theDotNetBook = new cpBook("C Sharp .Net Programming Tips & Techniques", "Jamsa", 49.99);

      Console.WriteLine("Method Names");

      foreach (MemberInfo theMethodInfo in theDotNetBook.GetType().GetMethods())
      {
        Console.WriteLine(theMethodInfo.Name);
      }
      // in theDotNetBook.GetType().GetMethods()

      Console.WriteLine();
      Console.WriteLine("Member Names");

      foreach (MemberInfo theMemberInfo in theDotNetBook.GetType().GetMembers())
      {
        Console.WriteLine(theMemberInfo.Name);
      }
      // in theDotNetBook.GetType().GetMembers()

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning