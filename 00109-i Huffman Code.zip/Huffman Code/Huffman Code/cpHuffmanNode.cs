﻿//***
// Action
//   - Defines a Huffman tree node
//   - It can be a Top node with branches (or leaves) under it (node)
//   - It can be a Parent node that has a Parent with Childs (branch or leaf) under it (node)
//   - At the bottom of the tree you have the leaves (Parent but no Childs) (node)
// Created
//   - CopyPaste – 20220719 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220719 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Text;

namespace CopyPaste.Huffman_Code
{
  public class cpHuffmanNode : IComparable
  {

    #region "Constructors / Destructors"

    public cpHuffmanNode(cpHuffmanNode leftBranch, cpHuffmanNode rightBranch)
    //***
    // Action
    //   - Constructor of a Node t (cpHuffmanNode) with a given text and a count
    // Called by
    //   - cpHuffmanTree(string)
    // Calls
    //   - Count(Int32) (Set)
    //   - Int32 Count() (Get)
    //   - IsLeaf(bool) (Set)
    //   - IsZero(bool) (Set)
    //   - LeftBranch(cpHuffmanNode) (Set)
    //   - Parent(cpHuffmanNode) (Set)
    //   - RightBranch(cpHuffmanNode) (Set)
    //   - string Value() (Get)
    //   - Value(string) (Set)
    // Created
    //   - CopyPaste – 20220719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Count = leftBranch.Count + rightBranch.Count;
      IsLeaf = false;
      leftBranch.IsZero = true;
      leftBranch.Parent = this;
      rightBranch.IsZero = false;
      rightBranch.Parent = this;
      LeftBranch = leftBranch;
      RightBranch = rightBranch;
      Value = leftBranch.Value + rightBranch.Value;
    }
    // cpHuffmanNode(cpHuffmanNode, cpHuffmanNode)

    public cpHuffmanNode(Int32 intCount, string strValue)
    //***
    // Action
    //   - Constructor of a leaf (cpHuffmanNode) with a given text and a count
    // Called by
    //   - cpHuffmanTree(string)
    // Calls
    //   - Count(Int32) (Set)
    //   - IsLeaf(bool) (Set)
    //   - LeftBranch(cpHuffmanNode) (Set)
    //   - Parent(cpHuffmanNode) (Set)
    //   - RightBranch(cpHuffmanNode) (Set)
    //   - Value(string) (Set)
    // Created
    //   - CopyPaste – 20220719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Count = intCount;
      IsLeaf = true;
      LeftBranch = null;
      Parent = null;
      RightBranch = null;
      Value = strValue;
    }
    // cpHuffmanNode(Int32, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"
    internal Int32 Count { get; set; }
    internal string HuffmanCode { get; set; }
    internal bool IsLeaf { get; set; }

    internal bool IsRoot
    {

      get
      //***
      // Action Get
      //   - Is the node the root node
      // Called by
      //   - Encode(cpHuffmanNode)
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220719 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220719 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return Parent == null;
      }
      // bool IsRoot (Get)

    }
    // bool IsRoot

    internal bool IsZero { get; set; }
    internal cpHuffmanNode LeftBranch { get; set; }
    internal cpHuffmanNode Parent { get; set; }
    internal cpHuffmanNode RightBranch { get; set; }
    internal string Value { get; set; }
    #endregion

    #region "Methods"

    // #region "Overrides"
    // #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int CompareTo(object anObject)
    //***
    // Action
    //   - Compare two objects with each other on the Count value
    //   - Object is compared to current object
    //     - If equal return 0
    //     - If bigger return -1
    //     - If smaller return 1
    // Called by
    //   - cpHuffmanQueue.Sort()
    // Calls
    //   - Count(Int32) (Set)
    //   - IsLeaf(bool) (Set)
    //   - LeftBranch(cpHuffmanNode) (Set)
    //   - Parent(cpHuffmanNode) (Set)
    //   - RightBranch(cpHuffmanNode) (Set)
    //   - Value(string) (Set)
    // Created
    //   - CopyPaste – 20220719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      cpHuffmanNode aHuffmanNode = (cpHuffmanNode)anObject;

      if (aHuffmanNode.Count >= Count)
      {

        if (aHuffmanNode.Count == Count)
        {
          return 0;
        }
        else
        // aHuffmanNode.Count <> Count
        {
          return -1;
        }
        // aHuffmanNode.Count = Count

      }
      else
      // aHuffmanNode.Count < Count
      {
        return 1;
      }
      // aHuffmanNode.Count >= Count

    }
    // int CompareTo(object)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpHuffmanNode

}
// CopyPaste.Huffman_Code
