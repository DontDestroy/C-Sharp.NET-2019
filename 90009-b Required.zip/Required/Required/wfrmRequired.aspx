﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmRequired.aspx.cs" Inherits="CopyPaste.Learning.wfrmRequired" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Required fields</title>
</head>
  <body ms_positioning="GridLayout">
    <form id="wfrmRequired" method="post" runat="server">
      <asp:dropdownlist id="cmbChoose" style="Z-INDEX: 101; POSITION: absolute; TOP: 24px; LEFT: 32px" runat="server"
        Width="136px">
        <asp:ListItem Value="Enter your choice">Enter your choice</asp:ListItem>
        <asp:ListItem Value="Mister">Mister</asp:ListItem>
        <asp:ListItem Value="Miss">Miss</asp:ListItem>
        <asp:ListItem Value="Misses">Misses</asp:ListItem>
      </asp:dropdownlist>
      <asp:validationsummary id="valsumRequired" style="Z-INDEX: 127; POSITION: absolute; TOP: 128px; LEFT: 384px"
        runat="server" ShowMessageBox="True"></asp:validationsummary>
      <asp:comparevalidator id="cmpvRepeatPassword" style="Z-INDEX: 126; POSITION: absolute; TOP: 192px; LEFT: 320px"
        runat="server" ErrorMessage="The entered passwords must be equal" ControlToValidate="txtRepeatPassword"
        ControlToCompare="txtPassword">*</asp:comparevalidator>
      <asp:comparevalidator id="cmpvBirthday" style="Z-INDEX: 125; POSITION: absolute; TOP: 224px; LEFT: 208px"
        runat="server" ErrorMessage="This date is not valid" ControlToValidate="txtBirthday" Type="Date" Operator="DataTypeCheck">*</asp:comparevalidator>
      <asp:label id="lblBirthDay" style="Z-INDEX: 120; POSITION: absolute; TOP: 224px; LEFT: 40px"
        runat="server">Birthday</asp:label>
      <asp:textbox id="txtBirthday" style="Z-INDEX: 119; POSITION: absolute; TOP: 224px; LEFT: 104px"
        runat="server" Width="96px" tabIndex="6"></asp:textbox>
      <asp:label id="lblRepeatPassword" style="Z-INDEX: 116; POSITION: absolute; TOP: 192px; LEFT: 40px"
        runat="server">Repeat Password</asp:label>
      <asp:textbox id="txtRepeatPassword" style="Z-INDEX: 114; POSITION: absolute; TOP: 192px; LEFT: 152px"
        runat="server" Width="160px" TextMode="Password" tabIndex="5"></asp:textbox>
      <asp:customvalidator id="cstvPassword" style="Z-INDEX: 118; POSITION: absolute; TOP: 160px; LEFT: 320px"
        runat="server" ErrorMessage="Password must be at least 8 characters long" ControlToValidate="txtPassword">*</asp:customvalidator>
      <asp:requiredfieldvalidator id="rfvPassword" style="Z-INDEX: 117; POSITION: absolute; TOP: 160px; LEFT: 320px"
        runat="server" ErrorMessage="Password must be entered" ControlToValidate="txtPassword">*</asp:requiredfieldvalidator>
      <asp:label id="lblPassword" style="Z-INDEX: 115; POSITION: absolute; TOP: 160px; LEFT: 40px"
        runat="server">Password</asp:label>
      <asp:textbox id="txtPassword" style="Z-INDEX: 113; POSITION: absolute; TOP: 160px; LEFT: 152px"
        runat="server" Width="160px" TextMode="Password" tabIndex="4"></asp:textbox>
      <asp:regularexpressionvalidator id="revEmail" style="Z-INDEX: 112; POSITION: absolute; TOP: 128px; LEFT: 320px"
        runat="server" ErrorMessage="This is not a valid email address" ControlToValidate="txtEmail" ValidationExpression="(\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)">*</asp:regularexpressionvalidator>
      <asp:label id="lblEmail" style="Z-INDEX: 111; POSITION: absolute; TOP: 128px; LEFT: 40px" runat="server">Email</asp:label>
      <asp:textbox id="txtEmail" style="Z-INDEX: 110; POSITION: absolute; TOP: 128px; LEFT: 96px" runat="server"
        Width="216px" tabIndex="3"></asp:textbox>
      <asp:comparevalidator id="cmpvNumberOfChildren" style="Z-INDEX: 109; POSITION: absolute; TOP: 96px; LEFT: 208px"
        runat="server" ErrorMessage="Number must be greater than or equal to 0" ControlToValidate="txtNumberOfChildren"
        ValueToCompare="0" Type="Integer" Operator="GreaterThanEqual">*</asp:comparevalidator>
      <asp:requiredfieldvalidator id="rfvNumberOfChildren" style="Z-INDEX: 108; POSITION: absolute; TOP: 96px; LEFT: 208px"
        runat="server" ErrorMessage="The entered value must be a number" ControlToValidate="txtNumberOfChildren">*</asp:requiredfieldvalidator>
      <asp:label id="lblNumberOfChildren" style="Z-INDEX: 107; POSITION: absolute; TOP: 96px; LEFT: 40px"
        runat="server">Number of children</asp:label>
      <asp:textbox id="txtNumberOfChildren" style="Z-INDEX: 105; POSITION: absolute; TOP: 96px; LEFT: 168px"
        runat="server" Width="32px" tabIndex="2"></asp:textbox>
      <asp:label id="lblSuggest" style="Z-INDEX: 124; POSITION: absolute; TOP: 256px; LEFT: 40px"
        runat="server">Suggestions</asp:label>
      <asp:textbox id="txtSuggest" style="Z-INDEX: 121; POSITION: absolute; TOP: 256px; LEFT: 120px"
        runat="server" Width="192px" TextMode="MultiLine" Rows="4" tabIndex="7"></asp:textbox>
      <asp:label id="lblName" style="Z-INDEX: 106; POSITION: absolute; TOP: 64px; LEFT: 40px" runat="server">Name</asp:label>
      <asp:requiredfieldvalidator id="rfvName" style="Z-INDEX: 104; POSITION: absolute; TOP: 64px; LEFT: 256px" runat="server"
        Width="8px" ErrorMessage="Name must be filled in" ControlToValidate="txtName">*</asp:requiredfieldvalidator>
      <asp:textbox id="txtName" style="Z-INDEX: 103; POSITION: absolute; TOP: 64px; LEFT: 96px; width: 142px;" runat="server"
        tabIndex="1"></asp:textbox>
      <asp:label id="lblResult" style="Z-INDEX: 123; POSITION: absolute; TOP: 24px; LEFT: 384px"
        runat="server" Width="320px"></asp:label>
      <asp:button id="cmdMakeMember" style="Z-INDEX: 122; POSITION: absolute; TOP: 352px; LEFT: 40px"
        runat="server" Text="Make member" tabIndex="8"></asp:button>
      <asp:RequiredFieldValidator id="rfvChoose" style="Z-INDEX: 102; POSITION: absolute; TOP: 24px; LEFT: 176px"
        runat="server" ErrorMessage="You have to make a choice" ControlToValidate="cmbChoose" InitialValue="Enter your choice">*</asp:RequiredFieldValidator>
    </form>
  </body>
</html>
