//***
// Action
//   - Show stack trace when an error happens
// Created
//   - CopyPaste � 20240515 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240515 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmStack: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdGenerate;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmStack));
      this.cmdGenerate = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdGenerate
      // 
      this.cmdGenerate.Location = new System.Drawing.Point(64, 56);
      this.cmdGenerate.Name = "cmdGenerate";
      this.cmdGenerate.Size = new System.Drawing.Size(152, 40);
      this.cmdGenerate.TabIndex = 1;
      this.cmdGenerate.Text = "Generate Exception";
      this.cmdGenerate.Click += new System.EventHandler(this.cmdGenerate_Click);
      // 
      // frmStack
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(280, 165);
      this.Controls.Add(this.cmdGenerate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmStack";
      this.Text = "Show Stack Trace";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmStack'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmStack()
      //***
      // Action
      //   - Create instance of 'frmStack'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmStack()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdGenerate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try
      //     - To show the result of method First
      //   - When it fails
      //     - Show the stack trace
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - int First()
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        Console.WriteLine("Result: {0}", First());
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.StackTrace, "StackTrace", MessageBoxButtons.OK, MessageBoxIcon.Warning);
      }
    
    }
    // cmdGenerate_Click(System.Object, System.EventArgs) Handles cmdGenerate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private int First()
      //***
      // Action
      //   - Return the result of method Second
      // Called by
      //   - cmdGenerate_Click(System.Object, System.EventArgs) Handles cmdGenerate.Click
      // Calls
      //   - int Second()
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return Second();
    }
    // int First()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmStack
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmStack()
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmStack());
    }
    // Main() 
    
    private int Second()
      //***
      // Action
      //   - Return the result of method Third
      // Called by
      //   - int First()
      // Calls
      //   - int Third()
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      return Third();
    }
    // int Second()

    private int Third()
      //***
      // Action
      //   - Divide 100 by 0
      // Called by
      //   - int Second()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngThird = 0;

      return 100 % lngThird;
    }
    // int Third()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmStack

}
// CopyPaste.Learning