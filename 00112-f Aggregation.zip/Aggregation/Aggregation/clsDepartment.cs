//***
// Action
//   - Implementation of a department
// Created
//   - CopyPaste � 20240409 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240409 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpDepartment
  {

    #region "Constructors / Destructors"

    public cpDepartment(string strName)
      //***
      // Action
      //   - Constructor with Name
      // Called by
      //   - 
      // Calls
      //   - Name(string) (Set)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Name = strName;
    }
    // cpDepartment()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrName;

    #endregion

    #region "Properties"

    public string Name
    {

      get
        //***
        // Action Get
        //   - Returns mstrName
        // Called by
        //   - ShowInfo()
        //   - string cpDirector.ToString()
        //   - string cpEmployee.ToString()
        //   - string cpHandWorker.ToString()
        //   - string cpManager.ToString()
        //   - string cpOfficeWorker.ToString()
        //   - string ToString() As String
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

      set
        //***
        // Action Set
        //   - mstrName becomes strValue
        // Called by
        //   - cpDepartment(string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - Returns the Name
      // Called by
      //   - 
      // Calls
      //   - string Name (Get)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Name;
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ShowInfo()
      //***
      // Action
      //   - Shows information to the console
      //     - Name
      // Called by
      //   - cpDirector.ShowInfo()
      //   - cpEmployee.ShowInfo()
      //   - cpHandWorker.ShowInfo()
      //   - cpManager.ShowInfo()
      //   - cpOfficeWorker.ShowInfo()
      // Calls
      //   - string Name (Get)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Department: {0}", Name);
    }
    // ShowInfo()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDepartment

}
// CopyPaste.Learning.Employee