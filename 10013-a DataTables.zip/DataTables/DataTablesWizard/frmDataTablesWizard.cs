﻿//***
// Action
//   - Having datatables in the application
// Created
//   - CopyPaste – 20210714 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210714 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataTablesWizard
{
  public partial class frmDataTablesWizard : Form
  {
    #region "Constructors / Destructors"

    public frmDataTablesWizard()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Fill TableAdapter Customer
    //   - Fill TableAdapter Order
    // Called by
    //   - User Action (Starting form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210714 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
      this.tbaOrder.Fill(this.dsData.tblCPOrder);
      this.tbaCustomer.Fill(this.dsData.tblCPCustomer);
      this.tbaEmployee.Fill(this.dsData.tblCPEmployee);
      this.mdsEmployee = new System.Data.DataSet("mdsEmployee");
    }
    // frmDataTablesWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    private System.Data.DataSet mdsEmployee;
    #endregion

    #region "Properties"
    #endregion

    #region "Methods"

    #region "Overrides"
    #endregion

    #region "Controls"

    private void cmdAddRow_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - Add a Row to the Table "tblCPCustomer" in DataSet "dsData"
    //     - Identify the key "strIdCustomer"
    //     - Identify the name "strCompanyName"
    //     - Add the row
    //     - Refresh the list of clients
    //   - Catch
    //     - You tried to add the unique key twice
    //     - Messagebox that the key is not unique
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210714 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      try
      {
        System.Data.DataRow drwNew;

        drwNew = this.dsData.tblCPCustomer.NewRow();
        drwNew["strIdCustomer"] = "ANEWR";
        drwNew["strCompanyName"] = "A New Row";
        this.dsData.tblCPCustomer.Rows.Add(drwNew);
        this.lstClient.Refresh();
      }
      catch (Exception theException)
      {
        MessageBox.Show("This record is already added, key must be unique");
      }
      finally
      {
      }

    }
    // cmdAddRow_Click(System.Object, System.EventArgs)

    private void cmdCalculate_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - Remove Table "tblCPEmployee" from mdsEmployee
    //   - Try to
    //     - Add Table "tblCPEmployee" to mdsEmployee
    //     - Fill the new created table (coming from dtaEmployee)
    //     - Add a calculated column to the table (strName)
    //     - Define DataSource of lstEmployee
    //     - Define DisplayMember of lstEmployee
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210714 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      System.Data.DataColumn dclName;

      try
      {
        this.mdsEmployee.Tables.Remove("tblCPEmployee");
      }
      catch (System.Exception theException)
      {
      }
      finally
      {
      }

      try
      {
        this.mdsEmployee.Tables.Add("tblCPEmployee");
        this.tbaEmployee.Adapter.Fill(this.mdsEmployee.Tables["tblCPEmployee"]);
        dclName = new System.Data.DataColumn("strName");
        dclName.DataType = System.Type.GetType("System.String");
        dclName.Expression = "strFirstName + ' ' + strLastName";
        this.mdsEmployee.Tables["tblCPEmployee"].Columns.Add(dclName);
        this.lstEmployee.DataSource = this.mdsEmployee.Tables["tblCPEmployee"];
        this.lstEmployee.DisplayMember = "strName";
      }
      catch (System.Exception theException)
      {
      }
      finally
      {
      }

    }
    // cmdCalculate_Click(System.Object, System.EventArgs)

    private void cmdDataSet_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Add a table to a DataSet
    //   - Show the name of the added table
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210714 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      string strMessage;
      this.mdsEmployee.Tables.Add();
      strMessage = "The table name is " + this.mdsEmployee.Tables[this.mdsEmployee.Tables.Count - 1].TableName.ToString() + " (" + this.mdsEmployee.Tables.Count.ToString() + ")";
      MessageBox.Show(strMessage);
    }
    // cmdDataSet_Click(System.Object, System.EventArgs)

    private void cmdForeign_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - Define a new ForeignKey (fkcNew)
    //     - Add the constrainst to the Table "dtChild"
    //     - Define the message with the name of the new constraint (but you know it at that moment)
    //     - Show the message
    //   - Catch
    //     - Show message that the constraint already exists
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210714 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      System.Data.ForeignKeyConstraint fkcNew;
      string strMessage;
      System.Data.DataSet theDataSet = this.dsUntyped;

      try
      {
        fkcNew = new System.Data.ForeignKeyConstraint("NewFK", theDataSet.Tables["dtMaster"].Columns["intIdMaster"], theDataSet.Tables["dtChild"].Columns["intMasterId"]);
        theDataSet.Tables["dtChild"].Constraints.Add(fkcNew);

        strMessage = "The new constraint is called ";
        strMessage += theDataSet.Tables["dtChild"].Constraints[theDataSet.Tables["dtChild"].Constraints.Count - 1].ConstraintName.ToString();
        MessageBox.Show(strMessage);
      }
      catch (System.Exception theException)
      {
        MessageBox.Show("Constraint already exists!");
      }
      finally
      {
      }

    }
    // cmdForeign_Click(System.Object, System.EventArgs)


    private void cmdSchema_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - Remove Table "tblCPEmployee" from mdsEmployee
    //   - Try to
    //     - Add Table "tblCPEmployee" to mdsEmployee
    //     - Fill the schema of the new created table (coming from dtaEmployee)
    //     - Show message with Primary Key and number of constraints
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210714 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      try
      {
        this.mdsEmployee.Tables.Remove("tblCPEmployee");
      }
      catch (System.Exception theException)
      {
      }
      finally
      {
      }

      try
      {
        string strMessage;

        this.mdsEmployee.Tables.Add("tblCPEmployee");
        this.tbaEmployee.Adapter.FillSchema(this.mdsEmployee.Tables["tblCPEmployee"], SchemaType.Source);

        strMessage = "Primary Key:  ";
        strMessage += this.mdsEmployee.Tables["tblCPEmployee"].PrimaryKey[0].ColumnName.ToString() + "\n\r";
        strMessage += "Constraint Count: ";
        strMessage += this.mdsEmployee.Tables["tblCPEmployee"].Constraints[0].ConstraintName.ToString();
        MessageBox.Show(strMessage);
      }
      catch (System.Exception theException)
      {
      }
      finally
      {
      }

    }
    // cmdSchema_Click(System.Object, System.EventArgs)

    private void cmdSelect_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - drwFound() becomes the result of a filtering of "tblCPCustomer"
    //   - Remove DataSource of the List "lstClient"
    //   - Clear the List "lstClient"
    //   - Add items to the List
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210714 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - When this is done, the link towards orders does not work anymore
    //   - Use the code below instad
    //   - bdscrCustomer.Filter = "strIdCustomer LIKE 'A*'"
    //***
    {
      System.Data.DataRow[] arrdrwFound;

      arrdrwFound = this.dsData.tblCPCustomer.Select("strIdCustomer LIKE 'A*'");

      this.lstClient.DataSource = null;
      this.lstClient.Items.Clear();

      foreach (System.Data.DataRow theDataRow in arrdrwFound)
      {
        this.lstClient.Items.Add(theDataRow["strCompanyName"]);
      }
      // in arrdrwFound

      this.lstClient.Refresh();
    }
    // cmdSelect_Click(System.Object, System.EventArgs)

    private void cmdTable_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Create a new DataTable "tblCPEmployee"
    //   - Show messaqge with the name of the created DataTable
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210714 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      System.Data.DataTable dtEmployee;
      string strMessage;

      dtEmployee = new System.Data.DataTable("tblCPEmployee");
      strMessage = "The table name is " + dtEmployee.TableName.ToString();
      MessageBox.Show(strMessage);
    }
    // cmdTable_Click(System.Object, System.EventArgs)

    private void cmdVersion_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change the name of the first customer in the Table "tblCPCustomer"
    //   - Show a message with the RowState, the original vlaue and the new value
    //   - In comment, I have tried to do the same thing with the key of the record
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210714 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - What is the result of the code that is put in comment?
    //***
    {
      string strMessage;
      System.Data.DataRow drwChange;

      drwChange = this.dsData.tblCPCustomer.Rows[0];
      drwChange["strCompanyName"] = "New Name";
      strMessage = "The RowState is " + drwChange.RowState.ToString() + "\n\r";
      strMessage += "The original value was " + drwChange["strCompanyName", DataRowVersion.Original] + "\n\r";
      strMessage += "The new value is " + drwChange["strCompanyName", DataRowVersion.Current];
      MessageBox.Show(strMessage);

      // drwChange["strIdCustomer"] = "NewVa";
      // strMessage = "The RowState is " + drwChange.RowState.ToString() + "\n\r";
      // strMessage += "The original value was " + drwChange["strIdCustomer", DataRowVersion.Original] + "\n\r";
      // strMessage += "The new value is " + drwChange["strIdCustomer", DataRowVersion.Current];
      // MessageBox.Show(strMessage);
    }
    // cmdVersion_Click(System.Object, System.EventArgs)

    private void cmdUnique_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Try to
    //     - Define a new unique constraint (uncNew)
    //     - Add the constraint to the table "dtMaster"
    //     - Define a message with the name of the constraint
    //     - Show message
    //   - Catch
    //     - Show message that the constraint already exists.
    // Called by
    //   - User Action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210714 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      string strMessage;
      System.Data.UniqueConstraint uncNew;

      try
      {
        System.Data.DataTable theDataTable = this.dsUntyped.Tables["dtMaster"];
        uncNew = new System.Data.UniqueConstraint("NewUnique", theDataTable.Columns["strMasterValue"]);
        theDataTable.Constraints.Add(uncNew);
        strMessage = "The new constraint is called ";
        strMessage += theDataTable.Constraints["NewUnique"].ConstraintName.ToString();
        MessageBox.Show(strMessage);
      }
      catch (System.Exception theException)
      {
        MessageBox.Show("Constraint already exists!");
      }
      finally
      {
      }

    }
    // cmdUnique_Click(System.Object, System.EventArgs)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataTables
}
// DataTablesWizard