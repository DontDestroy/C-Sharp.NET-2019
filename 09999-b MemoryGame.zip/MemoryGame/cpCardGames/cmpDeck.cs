//***
// Action
//   - Implementation of a normal deck of cards
//   - Some comments are in Dutch for clarification
//   - Some comments are in West-Flemish for clarification
//   - 2 constructor for creating a deck
//   - Make deck (mix the Face Values with the Suits, but now it is done with information from the form)
//   - Indexer / Default property to get a card from the deck
//   - Counter of the number of cards in the deck
//   - Shuffle the cards (from the deck)
// Created
//   - CopyPaste � 20240310 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240310 � VVDW
// Proposal (To Do)
//   - Only references between cpctlCard, cpctlDeck, cpctlMemory, cpDeckGirdIncompatibilityException and cpGameOverEvent are documented
//***

using System;
using System.ComponentModel;
using System.Collections;
using System.Diagnostics;

namespace CopyPaste.CardGames
{

  public class cpcmpDeck : System.ComponentModel.Component
	{

    #region Component Designer generated code

    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      components = new System.ComponentModel.Container();
    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpcmpDeck'
      // Called by
      //   - User action (Closing the component)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpcmpDeck()
      //***
      // Action
      //   - Create new instance of 'cpcmpDeck'
      // Called by
      //   - User action (Starting the component)
      //   - cpcmpDeck(System.ComponentModel.IContainer)
      // Calls
      //   - InitializeComponent()
      //   - MakeDeck()
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
      MakeDeck();
    }
    // cpcmpDeck()

    public cpcmpDeck(System.ComponentModel.IContainer container) : this()
      //***
      // Action
      //   - Create new instance of 'cpcmpDeck' using a container
      // Called by
      //   - User action (Starting the component)
      // Calls
      //   - cpcmpDeck()
      //   - MakeDeck()
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      container.Add(this);
      MakeDeck();
    }
    // cmpDeck(System.ComponentModel.IContainer)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpctlCard.cpFaceValue[] marrFaceValues = { cpctlCard.cpFaceValue.Ace,
                                                       cpctlCard.cpFaceValue.Two,
                                                       cpctlCard.cpFaceValue.Three,
                                                       cpctlCard.cpFaceValue.Four,
                                                       cpctlCard.cpFaceValue.Five,
                                                       cpctlCard.cpFaceValue.Six,
                                                       cpctlCard.cpFaceValue.Seven,
                                                       cpctlCard.cpFaceValue.Eight,
                                                       cpctlCard.cpFaceValue.Nine,
                                                       cpctlCard.cpFaceValue.Ten,
                                                       cpctlCard.cpFaceValue.Jack,
                                                       cpctlCard.cpFaceValue.Queen,
                                                       cpctlCard.cpFaceValue.King
                                                     };
    private cpctlCard.cpSuit[] marrSuits = {
                                             cpctlCard.cpSuit.Clubs,
                                             cpctlCard.cpSuit.Diamonds,
                                             cpctlCard.cpSuit.Hearts,
                                             cpctlCard.cpSuit.Spades
                                           };

    private System.Collections.ArrayList marrCards = new System.Collections.ArrayList();

    #endregion

    #region "Properties"

    [CategoryAttribute("Game"), DescriptionAttribute("Number of the cards in the deck.")]
    public int Count
    {

      get
        //***
        // Action Get
        //   - Returns a the number of Cards in the Deck
        // Called by
        //   - cpctlCard this[int] (Get)
        //   - MakeDeck()
        //   - Shuffle()
        //   - User action (as property of a component)
        // Calls
        //   - cpctlMemory.Play()
        // Created
        //   - CopyPaste � 20240310 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240310 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return marrCards.Count;
      }
      // int Count (Get)

    }
    // int Count

    [CategoryAttribute("Game"), DescriptionAttribute("The face values in the deck.")]
    public cpctlCard.cpFaceValue[] FaceValues
    {

      get
        //***
        // Action Get
        //   - Returns the possible cpFaceValues
        // Called by
        //   - MakeDeck()
        //   - User action (as property of a component)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240310 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240310 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return marrFaceValues;
      }
      // cpctlCard.cpFaceValue[] FaceValues (Get)

      set
        //***
        // Action Set
        //   - The possible cpFaceValues are given by value
        // Called by
        //   - User action (as property of a component)
        // Calls
        //   - MakeDeck()
        // Created
        //   - CopyPaste � 20240310 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240310 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        marrFaceValues = value;
        MakeDeck();
      }
      // FaceValues(cpctlCard.cpFaceValue[]) (Set)

    }
    // cpctlCard.cpFaceValue[] FaceValues

    [CategoryAttribute("Game"), DescriptionAttribute("The suits in the deck.")]
    public cpctlCard.cpSuit[] Suits
    {

      get
        //***
        // Action Get
        //   - Returns the possible cpSuits
        // Called by
        //   - MakeDeck()
        //   - User action (as property of a component)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240310 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240310 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return marrSuits;
      }
      // cpctlCard.cpSuit[] Suits (Get)

      set
        //***
        // Action Set
        //   - The possible cpSuits are given by value
        // Called by
        //   - User action (as property of a component)
        // Calls
        //   - MakeDeck()
        // Created
        //   - CopyPaste � 20240310 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240310 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        marrSuits = value;
        MakeDeck();
      }
      // Suits(cpctlCard.cpSuit[]) (Set)

    }
    // cpctlCard.cpSuit[] Suits

    public cpctlCard this[int intIndex]
    {

      get
        //***
        // Action Get
        //   - If the index is accepted (possible)
        //     - Returns a specific Card from the Deck
        //   - If Not
        //     - An error is thrown
        // Called by
        //   - cpctlMemory.Play()
        //   - int Count() (Get)
        //   - MakeDeck()
        //   - Shuffle()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240310 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240310 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if ((intIndex >= 0) && (intIndex < Count))
        {
          return (cpctlCard) marrCards[intIndex];
        }
        else
          // (lngIndex < 0 OrElse lngIndex >= Count)
        {
          throw new ArgumentOutOfRangeException("You ask an x-th card that is not part of the deck.");
        }
        // (lngIndex >= 0 AndAlso lngIndex < Count)

      }
      // cpctlCard this[int] (Get)

    }
    // cpctlCard this[int]

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void MakeDeck()
      //***
      // Action
      //   - Loop thru all the existing cards
      //     - Dispose them (destroy them)
      //   - Clear the array of cards
      //   - Loop thru all the given Suits
      //     - Loop thru all the given FaceValues
      //       - Create a Card of that Suit and FaceValue
      //       - Add it to the list of Cards
      // Called by
      //   - cpcmpDeck()
      //   - cpcmpDeckNew(System.ComponentModel.IContainer)
      //   - FaceValues(cpctlCard.cpFaceValue[]) (Set)
      //   - Suits(cpctlCard.cpSuit[]) (Set)
      // Calls
      //   - cpctlCard this[int] (Get)
      //   - cpctlCard(cpSuit, cpFaceValue)
      //   - cpctlCard.cpFaceValue[] FaceValues (Get)
      //   - cpctlCard.cpSuit[] Suits (Get)
      //   - int Count (Get)
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int intCounter;
      int intFaceValue;
      int intSuit;

      for (intCounter = 0; intCounter < Count; intCounter++)
      {
        this[intCounter].Dispose();
      }
      // intCounter = Count

      marrCards.Clear();

      for (intSuit = 0; intSuit < Suits.Length; intSuit++)
      {

        for (intFaceValue = 0; intFaceValue < FaceValues.Length; intFaceValue++)
        {
          marrCards.Add(new cpctlCard(Suits[intSuit], FaceValues[intFaceValue]));
        }
        // intFaceValue = FaceValues.Length

      }
      // intSuit = Suits.Length

    }
    // MakeDeck()

    public void Shuffle()
      //***
      // Action
      //   - A new Deck is defined
      //   - You take the current Deck
      //   - As long there are Cards in the Deck
      //     - Take randomly a Card (one of the possible)
      //     - Remove it from the current Deck
      //     - Add it to the new Deck
      //   - The current Deck becomes the new Deck
      // Called by
      //   - cpctlMemory.Play()
      // Calls
      //   - cpctlCard this[int] (Get)
      //   - int Count (Get)
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - A lot of different solutions are possible
      //***
    {
      ArrayList newDeck = new ArrayList();
      Random rndGenerate = new System.Random();

      while (Count > 0)
      {
        // Choose one card at random to remove
        int lngRemoveIndex = rndGenerate.Next(0, Count);
        System.Object objRemove = this[lngRemoveIndex];

        marrCards.RemoveAt(lngRemoveIndex);
        // Add the removed card to the new deck.
        newDeck.Add(objRemove);
      }
      // Count <= 0

      // Replace the old deck with the new deck
      marrCards = newDeck;
    }
    // Shuffle()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpcmpDeck

}
// CopyPaste.CardGames