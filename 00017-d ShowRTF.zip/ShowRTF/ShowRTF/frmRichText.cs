//***
// Action
//   - Show an open file dialog
//   - Show the content of a rich text file (RTF) in a rich textbox
// Created
//   - CopyPaste � 20240229 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240229 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmRichText: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdOpen;
    internal System.Windows.Forms.RichTextBox rtxtResult;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmRichText));
      this.cmdOpen = new System.Windows.Forms.Button();
      this.rtxtResult = new System.Windows.Forms.RichTextBox();
      this.SuspendLayout();
      // 
      // cmdOpen
      // 
      this.cmdOpen.Location = new System.Drawing.Point(192, 407);
      this.cmdOpen.Name = "cmdOpen";
      this.cmdOpen.Size = new System.Drawing.Size(104, 23);
      this.cmdOpen.TabIndex = 3;
      this.cmdOpen.Text = "Open File";
      this.cmdOpen.Click += new System.EventHandler(this.cmdOpen_Click);
      // 
      // rtxtResult
      // 
      this.rtxtResult.Location = new System.Drawing.Point(16, 23);
      this.rtxtResult.Name = "rtxtResult";
      this.rtxtResult.Size = new System.Drawing.Size(456, 368);
      this.rtxtResult.TabIndex = 2;
      this.rtxtResult.Text = "";
      // 
      // frmRichText
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(488, 453);
      this.Controls.Add(this.cmdOpen);
      this.Controls.Add(this.rtxtResult);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmRichText";
      this.Text = "Show Rich Text";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmRichText'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240229 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240229 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmRichText()
      //***
      // Action
      //   - Create instance of 'frmRichText'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240229 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240229 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show an open dialog screen
      //   - If user hits OK button
      //     - Try to open the file into the rich textbox
      //       - When it fails, show an error message
      //   - If not
      //     - user hits cancel or closed the window
      // Called by
      //   - User action (Clicing a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240229 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240229 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      OpenFileDialog dlgFileOpen = new OpenFileDialog();
      
      dlgFileOpen.Filter = "All files|*.*|RTF files|*.rtf";
      dlgFileOpen.FilterIndex = 2;
      dlgFileOpen.InitialDirectory = "C:\\Temp";

      if (dlgFileOpen.ShowDialog() == DialogResult.OK)
      {
        
        try
        {
          rtxtResult.LoadFile(dlgFileOpen.FileName);
        }
        catch
        {
          MessageBox.Show("Error reading file");
        }

      }
      else
        // dlgFileOpen.ShowDialog() <> DialogResult.OK
      {
        MessageBox.Show("User selected Cancel");
      }
      // dlgFileOpen.ShowDialog() = DialogResult.OK
    
    }
    // cmdOpen_Click(System.Object, System.EventArgs) Handles cmdOpen.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmRichText
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240229 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240229 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmRichText());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmRichText

}
// CopyPaste.Learning