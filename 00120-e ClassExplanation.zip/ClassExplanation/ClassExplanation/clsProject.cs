//***
// Action
//   - Implementation of cpProject
// Created
//   - CopyPaste � 20240618 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240618 � VVDW
// Proposal (To Do)
//   - 
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProject
  {

    //#region "Constructors / Destructors"
    //#endregion

    #region "Designer"

    internal class ClassInternal
    {

      #region "Fields"
      
      public string strClassInternal = "In Class Internal";
      
      #endregion

    }
    // ClassInternal

    private class ClassPrivate
    {

      #region "Fields"
      
      public string strClassPrivate = "In Class Private";
    
      #endregion

    }
    // ClassPrivate

    protected class ClassProtected
    {

      #region "Fields"
      
      public string strClassProtected = "In Class Protected";

      #endregion

    }
    // ClassProtected

    protected internal class ClassProtectedInternal
    {

      #region "Fields"
      
      public string strClassProtectedInternal = "In Class Protected Internal";

      #endregion

    }
    // ClassProtectedInternal

    public class ClassPublic
    {

      #region "Fields"
      
      public string strClassPublic = "In Class Public";

      #endregion
    
    }
    // ClassPublic

    #endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Test()
      //***
      // Action
      //   - Show the fields of the created classes
      // Called by
      //   - frmClassExplanation_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      ClassInternal theClassInternal = new ClassInternal();
      ClassPrivate theClassPrivate = new ClassPrivate();
      ClassProtected theClassProtected = new ClassProtected();
      ClassProtectedInternal theClassProtectedInternal = new ClassProtectedInternal();
      ClassPublic theClassPublic = new ClassPublic();

      Console.WriteLine(theClassPublic.strClassPublic);
      Console.WriteLine(theClassInternal.strClassInternal);
      Console.WriteLine(theClassPrivate.strClassPrivate);
      Console.WriteLine(theClassProtected.strClassProtected);
      Console.WriteLine(theClassProtectedInternal.strClassProtectedInternal);
      Console.ReadLine();
    }
    // Test()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProject

}
// CopyPaste.Learning