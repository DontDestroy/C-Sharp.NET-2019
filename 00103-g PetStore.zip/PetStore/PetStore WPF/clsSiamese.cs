//'***
//' Action
//'   - A pet store, the definition of a siamese (base class, but inherits from cpCat)
//'   - Working with properties (Get and Set) and methods in several classes, that can be reused
//' Created
//'   - CopyPaste � 20230407 � VVDW
//' Changed
//   - CopyPaste � yyyymmdd � VVDW
//' Tested
//'   - CopyPaste � 20230407 � VVDW
//' Proposal (To Do)
//'   - List of actions that can be added to the functionality
//'***

using System;

namespace CopyPaste.Pet.Cat
{

  public class cpSiamese : cpCat
  {

    #region "Constructors / Destructors"

    public cpSiamese() : base ()
    //***
    // Action
    //   - Creating an instance of cpSiamese with default parameters
    //   - Breed becomes "Siamese"
    //   - Cost becomes 250
    //   - Write a line "cpSiamese default constructor"
    // Called by
    //   - 
    // Calls
    //   - base()
    //   - CopyPaste.Pet.cpAnimal.Breed(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Cost(decimal) (Set)
    // Created
    //   - CopyPaste � 20230407 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20230407 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Breed = "Siamese";
      Cost = 250;
      Console.WriteLine("cpSiamese default constructor");
    }
    // cpSiamese()

    public cpSiamese(string strName, string strColor) : base (strName)
    //***
    // Action
    //   - Creating an instance of cpSiamese with default parameters and strName
    //   - Breed becomes "Siamese"
    //   - Cost becomes 250
    //   - Coloration becomes strColor
    //   - Write a line "cpSiamese overloaded constructor"
    // Called by
    //   - wpfPetStore.FillArray()
    // Calls
    //   - base(string)
    //   - CopyPaste.Pet.cpAnimal.Breed(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Coloration(string) (Set)
    //   - CopyPaste.Pet.cpAnimal.Cost(decimal) (Set)
    // Created
    //   - CopyPaste � 20230407 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20230407 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Breed = "Siamese";
      Cost = 250;
      Coloration = strColor;
      Console.WriteLine("cpSiamese overloaded constructor");
    }
    // cpSiamese(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    public override string Speak()
    //***
    // Action
    //   - Write a line to the console with "CopyPaste.Pet.Cat.cpSiamese.Speak"
    //   - Return "(Name) says 'Rrrrowwll!'"
    // Called by
    //   - wpfPetStore.cmdSpeak_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdSpeak.Click
    // Calls
    //   - string CopyPaste.Pet.cpAnimal.Name (Get)
    //   - string Overrides CopyPaste.Pet.cpAnimal.Speak()
    // Created
    //   - CopyPaste � 20230407 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW
    // Tested
    //   - CopyPaste � 20230407 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Console.WriteLine("CopyPaste.Pet.Cat.cpSiamese.Speak");
      return Name + " says 'Rrrrowwll!'";
    }

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpSiamese

}
// CopyPaste.Pet.Cat