﻿//***
// Action
//   - Product class (in Models)
// Created
//   - CopyPaste – 20220824 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220824 – VVDW
// Proposal (To Do)
//   -
//***

using ProductCategory_WPF_MVVM.Utilities;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProductCategory_WPF_MVVM.Models
{
  public class Product : ObservableObject
  {

    #region "Constructors / Destructors"

    public Product()
    //***
    // Action
    //   - Create an instance of 'Product'
    // Called by
    //   - 
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    { 
    }
    // Product()

    public Product(int intIdProduct, string strProductName, DateTime dtmIntroduction, string strUrl, decimal decPrice, DateTime? dtmRetire, ProductCategory? cpProductCategory)
    //***
    // Action
    //   - Create an instance of 'Product'
    //     - Fill the property Key
    //     - Fill the property Name
    //     - Fill the property IntroductionDate
    //     - Fill the property Url
    //     - Fill the property Price
    //     - Fill the property RetireDate
    //     - Fill the property Category
    // Called by
    //   - MockDataService.FillProduct()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20220907 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220907 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Key = intIdProduct;
      Name = strProductName;
      IntroductionDate = dtmIntroduction;
      Url = strUrl;
      Price = decPrice;
      RetireDate = dtmRetire;
      Category = cpProductCategory;
    }
    // Product(int, string, DateTime, string, decimal, DateTime?, ProductCategory?)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int _intIdProduct;
    private string _strProductName;
    private DateTime _dtmIntroduction;
    private string _strUrl;
    private decimal _decPrice;
    private DateTime? _dtmRetire;
    private ProductCategory? _ProductCategory;

    #endregion

    #region "Properties"

    public ProductCategory? Category
    {

      get
      //***
      // Action Get
      //   - Return _ProductCategory
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _ProductCategory;
      }
      // ProductCategory? Category (Get)

      set
      //***
      // Action Set
      //   - Sets _ProductCategory with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - 
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        OnPropertyChanged(ref _ProductCategory, value);
      }
      // Category(ProductCategory?) (Set)

    }
    // ProductCategory? Category

    public DateTime IntroductionDate
    {

      get
      //***
      // Action Get
      //   - Return _strProductName
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _dtmIntroduction;
      }
      // DateTime IntroductionDate (Get)

      set
      //***
      // Action Set
      //   - Sets _dtmIntroduction with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - 
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        OnPropertyChanged(ref _dtmIntroduction, value);
      }
      // IntroductionDate(DateTime) (Set)

    }
    // DateTime IntroductionDate

    public int Key
    {

      get
      //***
      // Action Get
      //   - Return _intIdProduct
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _intIdProduct;
      }
      // int Key (Get)

      set
      //***
      // Action Set
      //   - Sets _intIdProduct with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - 
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        OnPropertyChanged(ref _intIdProduct, value);
      }
      // Key(int) (Set)

    }
    // int Key

    public string Name
    {

      get
      //***
      // Action Get
      //   - Return _strProductName
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _strProductName;
      }
      // string Name (Get)

      set
      //***
      // Action Set
      //   - Sets _strProductName with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - 
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        OnPropertyChanged(ref _strProductName, value);
      }
      // Name(string) (Set)

    }
    // string Name

    public decimal Price
    {

      get
      //***
      // Action Get
      //   - Return _decPrice
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _decPrice;
      }
      // decimal Price (Get)

      set
      //***
      // Action Set
      //   - Sets _decPrice with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - 
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        OnPropertyChanged(ref _decPrice, value);
      }
      // Price(decimal) (Set)

    }
    // decimal Price

    public DateTime? RetireDate
    {

      get
      //***
      // Action Get
      //   - Return _dtmRetire
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _dtmRetire;
      }
      // DateTime? RetireDate (Get)

      set
      //***
      // Action Set
      //   - Sets _dtmRetire with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - 
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        OnPropertyChanged(ref _dtmRetire, value);
      }
      // RetireDate(DateTime?) (Set)

    }
    // DateTime? RetireDate

    public string Url
    {

      get
      //***
      // Action Get
      //   - Return _strUrl
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _strUrl;
      }
      // string Url (Get)

      set
      //***
      // Action Set
      //   - Sets _strProductName with a given value
      //   - OnPropertyChanged is called to set up a 2-way binding
      // Called by
      //   - 
      // Calls
      //   - bool OnPropertyChanged<T>(°T, T, string)
      // Created
      //   - CopyPaste – 20220906 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220906 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        OnPropertyChanged(ref _strUrl, value);
      }
      // Url(string) (Set)

    }
    // string Url

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // Product

}
// ProductCategory_WPF_MVVM.Models