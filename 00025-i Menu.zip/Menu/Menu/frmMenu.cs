//***
// Action
//   - Example of a menu
// Created
//   - CopyPaste � 20240514 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240514 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMenu: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.MenuItem mnuFile;
    internal System.Windows.Forms.MainMenu mnuMain;
    internal System.Windows.Forms.MenuItem mnuEdit;
    internal System.Windows.Forms.MenuItem mnuHelp;
    internal System.Windows.Forms.MenuItem mnuHelpAbout;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMenu));
      this.mnuFile = new System.Windows.Forms.MenuItem();
      this.mnuMain = new System.Windows.Forms.MainMenu();
      this.mnuEdit = new System.Windows.Forms.MenuItem();
      this.mnuHelp = new System.Windows.Forms.MenuItem();
      this.mnuHelpAbout = new System.Windows.Forms.MenuItem();
      // 
      // mnuFile
      // 
      this.mnuFile.Index = 0;
      this.mnuFile.Text = "File";
      this.mnuFile.Click += new System.EventHandler(this.mnuFile_Click);
      // 
      // mnuMain
      // 
      this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFile,
                                                                            this.mnuEdit,
                                                                            this.mnuHelp});
      // 
      // mnuEdit
      // 
      this.mnuEdit.Index = 1;
      this.mnuEdit.Text = "Edit";
      this.mnuEdit.Click += new System.EventHandler(this.mnuEdit_Click);
      // 
      // mnuHelp
      // 
      this.mnuHelp.Index = 2;
      this.mnuHelp.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuHelpAbout});
      this.mnuHelp.Text = "Help";
      // 
      // mnuHelpAbout
      // 
      this.mnuHelpAbout.Index = 0;
      this.mnuHelpAbout.Text = "About";
      this.mnuHelpAbout.Click += new System.EventHandler(this.mnuHelpAbout_Click);
      // 
      // frmMenu
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 49);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mnuMain;
      this.Name = "frmMenu";
      this.Text = "Menu";

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMenu'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMenu()
      //***
      // Action
      //   - Create instance of 'frmMenu'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMenu()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void mnuEdit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show reaction on clicking a menu item
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show("Edit menu");
    }
    // mnuEdit_Click(System.Object, System.EventArgs) Handles mnuEdit.Click

    private void mnuFile_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show reaction on clicking a menu item
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show("File Menu");  
    }
    // mnuFile_Click(System.Object, System.EventArgs) Handles mnuFile.Click

    private void mnuHelpAbout_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show reaction on clicking a submenu item
      // Called by
      //   - User action (Clicking a submenu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show("Help menu about option");
    }
    // mnuHelpAbout_Click(System.Object, System.EventArgs) Handles mnuHelpAbout.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDefault
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmMenu()
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMenu());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMenu

}
// CopyPaste.Learning