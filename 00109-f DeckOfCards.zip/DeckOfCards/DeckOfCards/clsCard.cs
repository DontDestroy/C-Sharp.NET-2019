//***
// Action
//   - Implementation of a playing card in a normal card game
//   - Some comments are in Dutch for clarification
//   - Some comments are in  West-Flemish for clarification
// Created
//   - CopyPaste � 20240128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240128 � VVDW
// Proposal (To Do)
//   - Only references between cpCard, cpDeck, cpHand and modDeckOfCardsTests are documented
//***

namespace CopyPaste.Learning.Games
{

  #region "Designer"

  public enum cpFaceValue
  {
    Ace,        // Aas
    Two,        // Twee
    Three,      // Drie
    Four,       // Vier
    Five,       // Vijf
    Six,        // Zes
    Seven,      // Zeven
    Eight,      // Acht
    Nine,       // Negen
    Ten,        // Tien
    Jack,       // Boer
    Queen,      // Vrouw
    King        // Heer
  }
  // cpFaceValue

  public enum cpSuit
  {
    Hearts,     // Harten (Hertns)
    Diamonds,   // Ruiten (Koekns)
    Clubs,      // Klaver (Klavers)
    Spades      // Schoppen (Piekns)
  }
  // cpSuit

  #endregion

  public class cpCard
  {

    #region "Constructors / Destructors"

    public cpCard(cpSuit thecpSuit, cpFaceValue thecpFaceValue)
      //***
      // Action
      //   - Constructor of a playing card
      //     - You set the suit (cpSuit)
      //     - You set the face value (cpFaceValue)
      // Called by
      //   - cpDeck.MakeDeck(cpSuit[], cpFaceValue[])
      //   - cpProgram.Main()
      // Calls
      //   - FaceValue(cpFaceValue) (Set)
      //   - Suit(cpSuit) (Set)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Suit = thecpSuit;
      FaceValue = thecpFaceValue;
    }
    // cpCard(cpSuit, cpFaceValue)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpSuit mcpSuit;
    private cpFaceValue mcpFaceValue;

    #endregion

    #region "Properties"

    public cpFaceValue FaceValue
    {

      get
        //***
        // Action Get
        //   - Returns the face value of the playing card (cpCard)
        //   - It returns one of the 13 possible values
        //     - 1 --> 10, Jack, Queen, King
        // Called by
        //   - cpHand.Contains(cpSuit, cpFaceValue)
        //   - cpHand.Remove(cpSuit, cpFaceValue)
        //   - cpHand.RemovePairs()
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240128 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240128 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mcpFaceValue;
      }
      // cpFaceValue FaceValue (Get)

      set
        //***
        // Action Set
        //   - The face value of the playing card (cpCard) becomes value
        //   - It becomes one of the 13 possible values
        //     - 1 --> 10, Jack, Queen, King
        // Called by
        //   - cpCard(cpSuit, cpFaceValue)
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240128 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240128 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mcpFaceValue = value;
      }
      // FaceValue(cpFaceValue) (Set)

    }
    // cpFaceValue FaceValue 

    public cpSuit Suit
    {
    
      get
        //***
        // Action Get
        //   - Returns the face value of the playing card (cpCard)
        //   - It returns one of the 4 possible values
        //     - Hertns, Koekns, Klavers, Piekns
        // Called by
        //   - cpHand.Contains(cpSuit, cpFaceValue)
        //   - cpHand.Remove(cpSuit, cpFaceValue)
        //   - cpHand.RemovePairs()
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240128 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240128 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mcpSuit;
      }
      // cpSuit Suit (Get)

      set
        //***
        // Action Set
        //   - The suit of the playing card (cpCard) becomes value
        //   - It becomes one of the 4 possible values
        //     - Hertns, Koekns, Klavers, Piekns
        // Called by
        //   - cpCard(cpSuit, cpFaceValue)
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240128 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240128 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mcpSuit = value;
      }
      // Suit(cpSuit) (Set)
    
    }
    // cpSuit Suit

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpCard

}
// CopyPaste.Learning.Games