﻿//***
// Action
//   - Class implements the View Model Base
//   - Triggers the changes of properties
// Created
//   - CopyPaste – 20210806 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210806 – VVDW
// Proposal(To Do)
//   -List of actions that can be added to the functionality
//***

namespace WPFConnection
{
  public class cpViewModelBase : cpCommon
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    private string _strResultText;
    #endregion

    #region "Properties"

    public string ResultText
    {
      get
      //***
      // Action Get
      //   - Returns _strResultText
      // Called by
      //   -
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20210806 – VVDW
      // Changed
      //   - Organisation – yyyymmdd – Initials of programmer – What changed
      // Tested
      //   - CopyPaste – 20210806 – VVDW
      // Keyboard Key
      //   -
      // Proposal(To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return _strResultText;
      }
      // string ResultText() (Get)

      set
      //***
      // Action Set
      //   - _strResultText becomes strValue
      //   - RaisePropertyChanged is triggered
      // Called by
      //   - cpConnectionViewModel.Connect(String)
      //   - cpConnectionViewModel.ConnectUsingBlock()
      //   - cpConnectionViewModel.ConnectWithErrors()
      // Calls
      //   - cpCommon.RaisePropertyChanged(String)
      // Created
      //   - CopyPaste – 20210806 – VVDW
      // Changed
      //   - Organisation – yyyymmdd – Initials of programmer – What changed
      // Tested
      //   - CopyPaste – 20210806 – VVDW
      // Keyboard Key
      //   -
      // Proposal(To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        _strResultText = value;
        RaisePropertyChanged("ResultText");
      }
      // ResultText(string) (Set)
    }
    // string ResultText()

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpViewModelBase 

}
// WPFConnection