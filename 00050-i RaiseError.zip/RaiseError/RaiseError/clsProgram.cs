//***
// Action
//   - Example of raising an error
//   - There is in C# not a corresponding command for raising an error
//     - Throwing an error is the best option here
// Created
//   - CopyPaste � 20230808 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230808 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Asking for a number
      //   - If a number
      //     - Show a message "Thanks"
      //   - If not
      //     - Raise an error
      //   - If there is ajn error number
      //     - Show the corresponding error message
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

    string strInput;

      try
      {
        strInput = Interaction.InputBox("Enter a number", "Copy Paste", "", 0, 0);

        if (Information.IsNumeric(strInput))
        {
          Interaction.MsgBox("Thanks", MsgBoxStyle.OkOnly, "Copy Paste");
        }
        else
          // Not Information.IsNumeric(strInput)
        {
          throw new Exception(strInput + " is not a number.");
        }
        // Information.IsNumeric(strInput)

      }
      catch (Exception theException)
      {
        Interaction.MsgBox(theException.Message, MsgBoxStyle.OkOnly, "Copy Paste");
      }

    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// CopyPaste.Learning