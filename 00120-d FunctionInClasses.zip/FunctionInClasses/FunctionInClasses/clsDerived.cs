//***
// Action
//   - Implementation of cpDerived
// Created
//   - CopyPaste � 20240618 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240618 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpDerived : cpBase
  {

    #region "Constructors / Destructors"

    public cpDerived() : base()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpBase()
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDerived()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    // public override bool FunctionMustOverride()
    // {
    //   Console.WriteLine("Function Must Override in Derived");
    //   return true;
    // }
    // // bool FunctionMustOverride()

    // public override bool FunctionNotOverridable()
    // {
    //   Console.WriteLine("Function Not Overridable in Derived");
    //   return true;
    // }
    // // bool FunctionNotOverridable()

    public override bool FunctionOverridable()
      //***
      // Action
      //   - Show that the subroutine is overridden
      // Called by
      //   - cpProgram.Main()
      //   - FunctionTestDerived()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Function Overridable in Derived");
      return true;
    }
    // bool FunctionOverridable()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public new bool FunctionShadows()
      //***
      // Action
      //   - Show that the subroutine is shadowed
      //   - Return true
      // Called by
      //   - cpProgram.Main()
      //   - FunctionTestTest()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Console.WriteLine("Function Shadows in Derived");
      return true;
    }
    // bool FunctionShadows()

    public void FunctionTestDerived()
      //***
      // Action
      //   - Execute all subroutines
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - bool FunctionMustOverride()
      //   - bool FunctionNotOverridable()
      //   - bool FunctionOverLoad()
      //   - bool FunctionOverLoad(string)
      //   - bool FunctionOverridable()
      //   - bool FunctionShadows()
      //   - bool FunctionStatic()
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bool blnResult;

      blnResult = FunctionOverLoad();
      Console.WriteLine("Result is {0}", blnResult);
      blnResult = FunctionOverLoad("This is overloaded");
      Console.WriteLine("Result is {0}", blnResult);
      blnResult = FunctionOverridable();
      Console.WriteLine("Result is {0}", blnResult);
      // blnResult = FunctionNotOverridable();
      // Console.WriteLine("Result is {0}", blnResult);
      // blnResult = FunctionMustOverride();
      // Console.WriteLine("Result is {0}", blnResult);
      blnResult = FunctionShadows();
      Console.WriteLine("Result is {0}", blnResult);
      blnResult = FunctionStatic();
      Console.WriteLine("Result is {0}", blnResult);
    }
    // FunctionTestDerived()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDerived

}
// CopyPaste.Learning