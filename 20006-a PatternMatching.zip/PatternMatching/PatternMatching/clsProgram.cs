﻿//***
// Action
//   - An example of Pattern Matching
// Created
//   - CopyPaste – 20251211 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251211 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - xxxx
    // Created
    //   - CopyPaste – 20251211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    #region "Designer"

    public enum cpUniversityCourses
    {
      Maths,
      Chemistry,
      Anatomy,
      LifeSkills
    }
    // enum cpUniversityCourses

    public enum cpUniversityDegree
    {
      Bachelor,
      Master,
      Doctorate
    }
    // enum cpUniversityDegree

    #endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Starting point
    //   - Define and create a cpPatternMatching instance
    //   - Create an instance of cpStudent
    //   - Create an instance of cpLecturer
    //   - Create two instances of cpAlumnus
    //   - Create an instance of cpExchangeStudent
    //   - Create a null value
    //   - Create a unknown type value (one that is not in the checks)
    //   - Use the Is Type Pattern method (before C# 7.0) to get the details of each person
    //   - Use the Is Type Pattern method (after C# 7.0) to get the details of each person
    //   - Use the Switch Case Pattern method (after C# 7.0) to get the details of each person
    //   - Use the Switch Case When Pattern method (after C# 7.0) to get the details of each person
    //   - Use the Switch Case When Pattern method (after C# 7.0) to get the details of each person with exclusion of some
    //   - Use the Switch Case Pattern method with null values (after C# 7.0) to get the details of each person
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpAlumnus((string, string, int), int, cpProgram.cpUniversityDegree)
    //   - cpExchangeStudent((string, string, int), cpProgram.cpUniversityCourses, DateTime)
    //   - cpLecturer((string, string, int), string, cpProgram.cpUniversityCourses, DateTime)
    //   - cpPatternMatching()
    //   - cpPatternMatching.GetPersonCourseBeforeCSharp07(System.Object)
    //   - cpPatternMatching.GetPersonCourseIsTypePattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchPattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchPatternNull(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchWhenPattern(System.Object)
    //   - cpPatternMatching.GetPersonCourseSwitchWhenPatternExclusion(System.Object)
    //   - cpPerson()
    //   - cpStudent((string, string, int), string, cpProgram.cpUniversityCourses)
    // Created
    //   - CopyPaste – 20251211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251211 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpPatternMatching thePatternMatching = new cpPatternMatching();
      string strResult = "";

      cpStudent theStudent = new cpStudent(("Dick", "Turpin", 20), "DT001", cpUniversityCourses.LifeSkills);
      cpLecturer theLecture = new cpLecturer(("Hilde", "Saelens", 57), "HS001", cpUniversityCourses.Anatomy, DateTime.Now.AddYears(-5));
      cpAlumnus theAlumnus = new cpAlumnus(("Ivan", "Hoe", 25), 2020, cpUniversityDegree.Bachelor);
      cpAlumnus theSeniorAlumnus = new cpAlumnus(("Vincent", "Van De Walle", 55), 1995, cpUniversityDegree.Doctorate);
      cpExchangeStudent theExchangeStudent = new cpExchangeStudent(("Anne", "Rice", 2003), cpUniversityCourses.LifeSkills, DateTime.Now.AddMonths(6));
      cpStudent theNullStudent = null;
      cpPerson theUnknownPerson = new cpPerson();

      Console.WriteLine("Before C# 7.0");
      Console.WriteLine("-------------");

      try
      {
        strResult = thePatternMatching.GetPersonCourseBeforeCSharp07(theStudent);
        Console.WriteLine("Student Before C# 7: " + strResult);

        strResult = thePatternMatching.GetPersonCourseBeforeCSharp07(theLecture);
        Console.WriteLine("Lecturer Before C# 7: " + strResult);

        strResult = thePatternMatching.GetPersonCourseBeforeCSharp07(theAlumnus);
        Console.WriteLine("Alumnus Before C# 7: " + strResult);

        strResult = thePatternMatching.GetPersonCourseBeforeCSharp07(theSeniorAlumnus);
        Console.WriteLine("Alumnus Before C# 7: " + strResult);

        strResult = thePatternMatching.GetPersonCourseBeforeCSharp07(theExchangeStudent);
        Console.WriteLine("ExchangeStudent Before C# 7: " + strResult);

        strResult = thePatternMatching.GetPersonCourseBeforeCSharp07(theNullStudent);
        Console.WriteLine("Null student Before C# 7: " + strResult);

        strResult = thePatternMatching.GetPersonCourseBeforeCSharp07(theUnknownPerson);
        Console.WriteLine("Unknown Person Before C# 7: " + strResult);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error: " + theException.Message);
      }
      finally
      {
      }

      Console.WriteLine();
      Console.WriteLine("Is Type Pattern (C# 7.0 and later)");
      Console.WriteLine("----------------------------------");

      try
      {
        strResult = thePatternMatching.GetPersonCourseIsTypePattern(theStudent);
        Console.WriteLine("Student is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseIsTypePattern(theLecture);
        Console.WriteLine("Lecturer is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseIsTypePattern(theAlumnus);
        Console.WriteLine("Alumnus is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseIsTypePattern(theSeniorAlumnus);
        Console.WriteLine("Alumnus is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseIsTypePattern(theExchangeStudent);
        Console.WriteLine("ExchangeStudent is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseIsTypePattern(theNullStudent);
        Console.WriteLine("Null student Before C# 7: " + strResult);

        strResult = thePatternMatching.GetPersonCourseIsTypePattern(theUnknownPerson);
        Console.WriteLine("Unknown Person is Type Pattern: " + strResult);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error: " + theException.Message);
      }
      finally
      {
      }

      Console.WriteLine();
      Console.WriteLine("Switch Pattern (C# 7.0 and later)");
      Console.WriteLine("---------------------------------");

      try
      {
        strResult = thePatternMatching.GetPersonCourseSwitchPattern(theStudent);
        Console.WriteLine("Student is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchPattern(theLecture);
        Console.WriteLine("Lecturer is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchPattern(theAlumnus);
        Console.WriteLine("Alumnus is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchPattern(theSeniorAlumnus);
        Console.WriteLine("Alumnus is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchPattern(theExchangeStudent);
        Console.WriteLine("ExchangeStudent is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchPattern(theNullStudent);
        Console.WriteLine("Unknown Person is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchPattern(theUnknownPerson);
        Console.WriteLine("Unknown Person is Type Pattern: " + strResult);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error: " + theException.Message);
      }
      finally
      {
      }

      Console.WriteLine();
      Console.WriteLine("Switch When Pattern (C# 7.0 and later)");
      Console.WriteLine("--------------------------------------");

      try
      {
        strResult = thePatternMatching.GetPersonCourseSwitchWhenPattern(theStudent);
        Console.WriteLine("Student is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchWhenPattern(theLecture);
        Console.WriteLine("Lecturer is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchWhenPattern(theAlumnus);
        Console.WriteLine("Alumnus is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchWhenPattern(theSeniorAlumnus);
        Console.WriteLine("Alumnus is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchWhenPattern(theExchangeStudent);
        Console.WriteLine("ExchangeStudent is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchWhenPattern(theNullStudent);
        Console.WriteLine("Unknown Person is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchWhenPattern(theUnknownPerson);
        Console.WriteLine("Unknown Person is Type Pattern: " + strResult);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error: " + theException.Message);
      }
      finally
      {
      }

      Console.WriteLine();
      Console.WriteLine("Switch When Pattern with exclusion (C# 7.0 and later)");
      Console.WriteLine("-----------------------------------------------------");

      try
      {
        strResult = thePatternMatching.GetPersonCourseSwitchWhenPatternExclusion(theStudent);
        Console.WriteLine("Student is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchWhenPatternExclusion(theLecture);
        Console.WriteLine("Lecturer is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchWhenPatternExclusion(theAlumnus);
        Console.WriteLine("Alumnus is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchWhenPatternExclusion(theSeniorAlumnus);
        Console.WriteLine("Alumnus is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchWhenPatternExclusion(theExchangeStudent);
        Console.WriteLine("ExchangeStudent is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchWhenPatternExclusion(theNullStudent);
        Console.WriteLine("Unknown Person is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchWhenPatternExclusion(theUnknownPerson);
        Console.WriteLine("Unknown Person is Type Pattern: " + strResult);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error: " + theException.Message);
      }
      finally
      {
      }

      Console.WriteLine();
      Console.WriteLine("Switch When Pattern with null values (C# 7.0 and later)");
      Console.WriteLine("-------------------------------------------------------");

      try
      {
        strResult = thePatternMatching.GetPersonCourseSwitchPatternNull(theStudent);
        Console.WriteLine("Student is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchPatternNull(theLecture);
        Console.WriteLine("Lecturer is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchPatternNull(theAlumnus);
        Console.WriteLine("Alumnus is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchPatternNull(theSeniorAlumnus);
        Console.WriteLine("Alumnus is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchPatternNull(theExchangeStudent);
        Console.WriteLine("ExchangeStudent is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchPatternNull(theNullStudent);
        Console.WriteLine("Unknown Person is Type Pattern: " + strResult);

        strResult = thePatternMatching.GetPersonCourseSwitchPatternNull(theUnknownPerson);
        Console.WriteLine("Unknown Person is Type Pattern: " + strResult);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error: " + theException.Message);
      }
      finally
      {
      }

      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning