//***
// Action
//   - Show some lines on the screen
// Created
//   - CopyPaste � 20230614 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230614 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace Lines
{

  public class frmLines : System.Windows.Forms.Form
	{
    internal System.Windows.Forms.Timer tmrTimer;
    private System.ComponentModel.IContainer components;
    #region Windows Form Designer generated code


    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmLines));
      this.tmrTimer = new System.Windows.Forms.Timer(this.components);
      // 
      // tmrTimer
      // 
      this.tmrTimer.Interval = 10;
      this.tmrTimer.Tick += new System.EventHandler(this.tmrTimer_Tick);
      // 
      // frmLines
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(492, 373);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmLines";
      this.Text = "Lines";
      this.Load += new System.EventHandler(this.frmLines_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmLines'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmLines()
      //***
      // Action
      //   - Create instance of 'frmLines'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmLines()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    Graphics mtheGraphic;
    int mlngCounter = 0;
    int mlngX1;
    int mlngX2;
    int mlngY1;
    int mlngY2;
    Random mrndRandom = new Random(DateTime.Now.Millisecond);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmLines_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Define a graphic tool
    //   - Start a timer with an interval of 50 milliseconds
    // Called by
    //   - System action (Starting the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      mtheGraphic = CreateGraphics();
      tmrTimer.Interval = 50;
      tmrTimer.Enabled = true;
    }
    // frmLines_Load(System.Object, System.EventArgs) Handles this.Load

    private void tmrTimer_Tick(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - An X and Y coordinate are calculated for one point
    //   - An X and Y coordinate are calculated for another point
    //   - With both points a line is drawn
    //   - The number of lines is added by 1
    //   - The number of lines is shown in the title of the form
    // Called by
    //   - System action (Timer Tick)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    mlngX1 = Convert.ToInt32(mrndRandom.Next(Width));
    mlngY1 = Convert.ToInt32(mrndRandom.Next(Height));
    mlngX2 = Convert.ToInt32(mrndRandom.Next(Width));
    mlngY2 = Convert.ToInt32(mrndRandom.Next(Height));
    mtheGraphic.DrawLine(Pens.RoyalBlue, mlngX1, mlngY1, mlngX2, mlngY2);
    mlngCounter += 1;
    this.Text = "Number of lines: " + mlngCounter.ToString();
    }
    // tmrTimer_Tick(System.Object theSender, System.EventArgs theEventArguments) Handles tmrTimer.Tick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmLines
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmLines());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmLines

}
// Lines