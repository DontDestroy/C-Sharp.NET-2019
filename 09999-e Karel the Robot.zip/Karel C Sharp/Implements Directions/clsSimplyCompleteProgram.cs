﻿//***
// Action
//   - Create a class cpSimplyCompleteProgram that uses the interface Directions
// Created
//   - CopyPaste – 20251011 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251011 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpSimplyCompleteProgram : Directions
	{

		#region "Constructors / Destructors"

		public cpSimplyCompleteProgram()
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Reset the world
		//   - Build the world according to the One Beeper specifications
		//   - Make the world visible
		//   - Karel becomes a green robot starting at position(1, 1), looking to the right with no beepers in the bag
		//   - Karel will move two forward
		//   - Karel will pick the beeper at that position
		//   - Karel will move one forward
		//   - Karel will turn left
		//   - Karel will move two forward
		//   - Karel will put the beeper at that position
		//   - Karel will move one forward
		//   - Karel shuts down
		// Called by
		//   - cpProgram.SimplyCompleteProgram()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251011 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251011 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			World.reset(); // World is resetted
			World.readWorld("Worlds\\02.06 One Beeper.kwld"); // World is created with specifications
			World.setVisible(true); // World is made visible
			UrRobot karel = new UrRobot(1, 1, Directions.East, 0, Color.green); // A UrRobot with name karel is put on the World
																									// At Street 1, Avenue 1, looking East, no Beepers in the bag
			karel.move(); // karel (the created UrRobot) is moved one forward
										// Moving one to the East (position Street 1, Avenue 2)
			karel.move(); // Moving one to the East (position Street 1, Avenue 3)
			karel.pickBeeper(); // Pick the Beeper at that position
			karel.move(); // Moving one to the East (position Street 1, Avenue 4)
			karel.turnLeft(); // Turn to the left (Looking to the North)
			karel.move(); // Moving one to the North (position Street 2, Avenue 4)
			karel.move(); // Moving one to the North (position Street 3, Avenue 4)
			karel.putBeeper(); // Put the Beeper at that position
			karel.move(); // Moving one to the North (position Street 4, Avenue 4)
			karel.turnOff(); // Robot karel has done its duty and is switched off
		}
		// cpSimplyCompleteProgram()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// cpSimplyCompleteProgram

}
// cpKarelTheRobot