//***
// Action
//   - Create a small text editor
//   - Effect on text: Size, Bold, Italic, Underline and Strikethrough
//   - Effect on color background: White, Yellow, Light Green
//   - Effect on color foreground: Black, Blue and Green
// Created
//   - CopyPaste � 20250702 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250702 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFormatText: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.GroupBox grpEffect;
    internal System.Windows.Forms.CheckBox chkEffectStrikethrough;
    internal System.Windows.Forms.CheckBox chkEffectUnderline;
    internal System.Windows.Forms.CheckBox chkEffectItalic;
    internal System.Windows.Forms.CheckBox chkEffectBold;
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.TextBox txtText;
    internal System.Windows.Forms.GroupBox grpSize;
    internal System.Windows.Forms.Button cmdSmall;
    internal System.Windows.Forms.Label lblSize;
    internal System.Windows.Forms.Button cmdBig;
    internal System.Windows.Forms.GroupBox grpBackGroundColor;
    internal System.Windows.Forms.RadioButton optBackGroundColorLightGreen;
    internal System.Windows.Forms.RadioButton optBackGroundColorYellow;
    internal System.Windows.Forms.RadioButton optBackGroundColorWhite;
    internal System.Windows.Forms.GroupBox grpTextColor;
    internal System.Windows.Forms.RadioButton optTextColorGreen;
    internal System.Windows.Forms.RadioButton optTextColorBlue;
    internal System.Windows.Forms.RadioButton optTextColorBlack;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFormatText));
      this.grpEffect = new System.Windows.Forms.GroupBox();
      this.chkEffectStrikethrough = new System.Windows.Forms.CheckBox();
      this.chkEffectUnderline = new System.Windows.Forms.CheckBox();
      this.chkEffectItalic = new System.Windows.Forms.CheckBox();
      this.chkEffectBold = new System.Windows.Forms.CheckBox();
      this.cmdExit = new System.Windows.Forms.Button();
      this.txtText = new System.Windows.Forms.TextBox();
      this.grpSize = new System.Windows.Forms.GroupBox();
      this.cmdSmall = new System.Windows.Forms.Button();
      this.lblSize = new System.Windows.Forms.Label();
      this.cmdBig = new System.Windows.Forms.Button();
      this.grpBackGroundColor = new System.Windows.Forms.GroupBox();
      this.optBackGroundColorLightGreen = new System.Windows.Forms.RadioButton();
      this.optBackGroundColorYellow = new System.Windows.Forms.RadioButton();
      this.optBackGroundColorWhite = new System.Windows.Forms.RadioButton();
      this.grpTextColor = new System.Windows.Forms.GroupBox();
      this.optTextColorGreen = new System.Windows.Forms.RadioButton();
      this.optTextColorBlue = new System.Windows.Forms.RadioButton();
      this.optTextColorBlack = new System.Windows.Forms.RadioButton();
      this.grpEffect.SuspendLayout();
      this.grpSize.SuspendLayout();
      this.grpBackGroundColor.SuspendLayout();
      this.grpTextColor.SuspendLayout();
      this.SuspendLayout();
      // 
      // grpEffect
      // 
      this.grpEffect.Controls.Add(this.chkEffectStrikethrough);
      this.grpEffect.Controls.Add(this.chkEffectUnderline);
      this.grpEffect.Controls.Add(this.chkEffectItalic);
      this.grpEffect.Controls.Add(this.chkEffectBold);
      this.grpEffect.Location = new System.Drawing.Point(367, 8);
      this.grpEffect.Name = "grpEffect";
      this.grpEffect.Size = new System.Drawing.Size(120, 120);
      this.grpEffect.TabIndex = 7;
      this.grpEffect.TabStop = false;
      this.grpEffect.Text = "&Effect";
      // 
      // chkEffectStrikethrough
      // 
      this.chkEffectStrikethrough.Location = new System.Drawing.Point(16, 88);
      this.chkEffectStrikethrough.Name = "chkEffectStrikethrough";
      this.chkEffectStrikethrough.Size = new System.Drawing.Size(96, 24);
      this.chkEffectStrikethrough.TabIndex = 3;
      this.chkEffectStrikethrough.Text = "&Strikethrough";
      this.chkEffectStrikethrough.CheckedChanged += new System.EventHandler(this.chkEffectStrikethrough_CheckedChanged);
      // 
      // chkEffectUnderline
      // 
      this.chkEffectUnderline.Location = new System.Drawing.Point(16, 64);
      this.chkEffectUnderline.Name = "chkEffectUnderline";
      this.chkEffectUnderline.Size = new System.Drawing.Size(85, 24);
      this.chkEffectUnderline.TabIndex = 2;
      this.chkEffectUnderline.Text = "&Underline";
      this.chkEffectUnderline.CheckedChanged += new System.EventHandler(this.chkEffectUnderline_CheckedChanged);
      // 
      // chkEffectItalic
      // 
      this.chkEffectItalic.Location = new System.Drawing.Point(16, 40);
      this.chkEffectItalic.Name = "chkEffectItalic";
      this.chkEffectItalic.Size = new System.Drawing.Size(85, 24);
      this.chkEffectItalic.TabIndex = 1;
      this.chkEffectItalic.Text = "&Italic";
      this.chkEffectItalic.CheckedChanged += new System.EventHandler(this.chkEffectItalic_CheckedChanged);
      // 
      // chkEffectBold
      // 
      this.chkEffectBold.Location = new System.Drawing.Point(16, 16);
      this.chkEffectBold.Name = "chkEffectBold";
      this.chkEffectBold.Size = new System.Drawing.Size(85, 24);
      this.chkEffectBold.TabIndex = 0;
      this.chkEffectBold.Text = "&Bold";
      this.chkEffectBold.CheckedChanged += new System.EventHandler(this.chkEffectBold_CheckedChanged);
      // 
      // cmdExit
      // 
      this.cmdExit.Location = new System.Drawing.Point(7, 416);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.TabIndex = 11;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // txtText
      // 
      this.txtText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
      this.txtText.Location = new System.Drawing.Point(7, 8);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtText.Size = new System.Drawing.Size(352, 400);
      this.txtText.TabIndex = 6;
      this.txtText.Text = "";
      // 
      // grpSize
      // 
      this.grpSize.Controls.Add(this.cmdSmall);
      this.grpSize.Controls.Add(this.lblSize);
      this.grpSize.Controls.Add(this.cmdBig);
      this.grpSize.Location = new System.Drawing.Point(367, 344);
      this.grpSize.Name = "grpSize";
      this.grpSize.Size = new System.Drawing.Size(120, 64);
      this.grpSize.TabIndex = 10;
      this.grpSize.TabStop = false;
      this.grpSize.Text = "Si&ze";
      // 
      // cmdSmall
      // 
      this.cmdSmall.Enabled = false;
      this.cmdSmall.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmdSmall.Location = new System.Drawing.Point(80, 24);
      this.cmdSmall.Name = "cmdSmall";
      this.cmdSmall.Size = new System.Drawing.Size(32, 23);
      this.cmdSmall.TabIndex = 2;
      this.cmdSmall.Text = "A";
      this.cmdSmall.Click += new System.EventHandler(this.cmdSmall_Click);
      // 
      // lblSize
      // 
      this.lblSize.Location = new System.Drawing.Point(8, 24);
      this.lblSize.Name = "lblSize";
      this.lblSize.Size = new System.Drawing.Size(24, 23);
      this.lblSize.TabIndex = 0;
      this.lblSize.Text = "9";
      this.lblSize.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cmdBig
      // 
      this.cmdBig.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.cmdBig.Location = new System.Drawing.Point(40, 24);
      this.cmdBig.Name = "cmdBig";
      this.cmdBig.Size = new System.Drawing.Size(32, 23);
      this.cmdBig.TabIndex = 1;
      this.cmdBig.Text = "A";
      this.cmdBig.Click += new System.EventHandler(this.cmdBig_Click);
      // 
      // grpBackGroundColor
      // 
      this.grpBackGroundColor.Controls.Add(this.optBackGroundColorLightGreen);
      this.grpBackGroundColor.Controls.Add(this.optBackGroundColorYellow);
      this.grpBackGroundColor.Controls.Add(this.optBackGroundColorWhite);
      this.grpBackGroundColor.Location = new System.Drawing.Point(367, 240);
      this.grpBackGroundColor.Name = "grpBackGroundColor";
      this.grpBackGroundColor.Size = new System.Drawing.Size(120, 96);
      this.grpBackGroundColor.TabIndex = 9;
      this.grpBackGroundColor.TabStop = false;
      this.grpBackGroundColor.Text = "BackGround &Color";
      // 
      // optBackGroundColorLightGreen
      // 
      this.optBackGroundColorLightGreen.Location = new System.Drawing.Point(16, 64);
      this.optBackGroundColorLightGreen.Name = "optBackGroundColorLightGreen";
      this.optBackGroundColorLightGreen.Size = new System.Drawing.Size(96, 24);
      this.optBackGroundColorLightGreen.TabIndex = 2;
      this.optBackGroundColorLightGreen.Text = "Lig&ht Green";
      this.optBackGroundColorLightGreen.CheckedChanged += new System.EventHandler(this.optBackGroundColorLightGreen_CheckedChanged);
      // 
      // optBackGroundColorYellow
      // 
      this.optBackGroundColorYellow.Location = new System.Drawing.Point(16, 40);
      this.optBackGroundColorYellow.Name = "optBackGroundColorYellow";
      this.optBackGroundColorYellow.Size = new System.Drawing.Size(96, 24);
      this.optBackGroundColorYellow.TabIndex = 1;
      this.optBackGroundColorYellow.Text = "&Yellow";
      this.optBackGroundColorYellow.CheckedChanged += new System.EventHandler(this.optBackGroundColorYellow_CheckedChanged);
      // 
      // optBackGroundColorWhite
      // 
      this.optBackGroundColorWhite.Checked = true;
      this.optBackGroundColorWhite.Location = new System.Drawing.Point(16, 16);
      this.optBackGroundColorWhite.Name = "optBackGroundColorWhite";
      this.optBackGroundColorWhite.Size = new System.Drawing.Size(96, 24);
      this.optBackGroundColorWhite.TabIndex = 0;
      this.optBackGroundColorWhite.TabStop = true;
      this.optBackGroundColorWhite.Text = "&White";
      this.optBackGroundColorWhite.CheckedChanged += new System.EventHandler(this.optBackGroundColorWhite_CheckedChanged);
      // 
      // grpTextColor
      // 
      this.grpTextColor.Controls.Add(this.optTextColorGreen);
      this.grpTextColor.Controls.Add(this.optTextColorBlue);
      this.grpTextColor.Controls.Add(this.optTextColorBlack);
      this.grpTextColor.Location = new System.Drawing.Point(367, 136);
      this.grpTextColor.Name = "grpTextColor";
      this.grpTextColor.Size = new System.Drawing.Size(120, 96);
      this.grpTextColor.TabIndex = 8;
      this.grpTextColor.TabStop = false;
      this.grpTextColor.Text = "&Text Color";
      // 
      // optTextColorGreen
      // 
      this.optTextColorGreen.Location = new System.Drawing.Point(16, 64);
      this.optTextColorGreen.Name = "optTextColorGreen";
      this.optTextColorGreen.Size = new System.Drawing.Size(96, 24);
      this.optTextColorGreen.TabIndex = 2;
      this.optTextColorGreen.Text = "&Green";
      this.optTextColorGreen.CheckedChanged += new System.EventHandler(this.optTextColorGreen_CheckedChanged);
      // 
      // optTextColorBlue
      // 
      this.optTextColorBlue.Location = new System.Drawing.Point(16, 40);
      this.optTextColorBlue.Name = "optTextColorBlue";
      this.optTextColorBlue.Size = new System.Drawing.Size(96, 24);
      this.optTextColorBlue.TabIndex = 1;
      this.optTextColorBlue.Text = "Bl&ue";
      this.optTextColorBlue.CheckedChanged += new System.EventHandler(this.optTextColorBlue_CheckedChanged);
      // 
      // optTextColorBlack
      // 
      this.optTextColorBlack.Checked = true;
      this.optTextColorBlack.Location = new System.Drawing.Point(16, 16);
      this.optTextColorBlack.Name = "optTextColorBlack";
      this.optTextColorBlack.Size = new System.Drawing.Size(96, 24);
      this.optTextColorBlack.TabIndex = 0;
      this.optTextColorBlack.TabStop = true;
      this.optTextColorBlack.Text = "B&lack";
      this.optTextColorBlack.CheckedChanged += new System.EventHandler(this.optTextColorBlack_CheckedChanged);
      // 
      // frmFormatText
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(494, 455);
      this.Controls.Add(this.grpEffect);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.txtText);
      this.Controls.Add(this.grpSize);
      this.Controls.Add(this.grpBackGroundColor);
      this.Controls.Add(this.grpTextColor);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.Name = "frmFormatText";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Format Text";
      this.grpEffect.ResumeLayout(false);
      this.grpSize.ResumeLayout(false);
      this.grpBackGroundColor.ResumeLayout(false);
      this.grpTextColor.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFormatText'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFormatText()
      //***
      // Action
      //   - Create instance of 'frmFormatText'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFormatText()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void chkEffectBold_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the effect fontstyle bold
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeEffect(FontStyle)
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeEffect(FontStyle.Bold);
    }
    // chkEffectBold_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectBold.CheckedChanged

    private void chkEffectItalic_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the effect fontstyle italic
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeEffect(FontStyle)
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeEffect(FontStyle.Italic);
    }
    // chkEffectItalic_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectItalic.CheckedChanged

    private void chkEffectStrikethrough_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the effect fontstyle strikeout
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeEffect(FontStyle)
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeEffect(FontStyle.Strikeout);
    }
    // chkEffectStrikethrough_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectStrikethrough.CheckedChanged

    private void chkEffectUnderline_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the effect fontstyle underline
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeEffect(FontStyle)
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeEffect(FontStyle.Underline);
    }
    // chkEffectUnderline_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectUnderline.CheckedChanged

    
    private void cmdBig_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Make the size of the font one bigger
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ChangeSize(Single)
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeSize(1);
    }
    // cmdBig_Click(System.Object, System.EventArgs) Handles cmdBig.Click

    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop the application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit.Click

    private void cmdSmall_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Make the size of the font one smaller
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - ChangeSize(Single)
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeSize(-1);
    }
    // cmdSmall_Click(System.Object, System.EventArgs) Handles cmdSmall.Click
    
    private void optBackGroundColorLightGreen_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the back color of the text to light green
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeBackColor(Color)
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeBackColor(Color.LightGreen);
    }
    // optBackGroundColorLightGreen_CheckedChanged(System.Object, System.EventArgs) Handles optBackGroundColorLightGreen.CheckedChanged

    private void optBackGroundColorWhite_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the back color of the text to white
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeBackColor(Color)
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeBackColor(Color.White);
    }
    // optBackGroundColorWhite_CheckedChanged(System.Object, .EventArgs) Handles optBackGroundColorWhite.CheckedChanged

    private void optBackGroundColorYellow_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the back color of the text to yellow
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeBackColor(Color)
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeBackColor(Color.Yellow);
    }
    // optBackGroundColorYellow_CheckedChanged(System.Object, System.EventArgs) Handles optBackGroundColorYellow.CheckedChanged

    private void optTextColorBlack_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the text color of the text to black
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeForeColor(Color)
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeForeColor(Color.Black);
    }
    // optTextColorBlack_CheckedChanged(System.Object, System.EventArgs) Handles optTextColorBlack.CheckedChanged

    private void optTextColorBlue_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the text color of the text to blue
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeForeColor(Color)
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeForeColor(Color.Blue);
    }

    private void optTextColorGreen_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Change the text color of the text to green
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - ChangeForeColor(Color)
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ChangeForeColor(Color.Green);
    }

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void ChangeBackColor(Color theColor)
      //***
      // Action
      //   - Get the size of the font (sngSize)
      //   - Back color of the text becomes theColor
      // Called by
      //   - optBackGroundColorLightGreen_CheckedChanged(System.Object, System.EventArgs) Handles optBackGroundColorLightGreen.CheckedChanged
      //   - optBackGroundColorWhite_CheckedChanged(System.Object, .EventArgs) Handles optBackGroundColorWhite.CheckedChanged
      //   - optBackGroundColorYellow_CheckedChanged(System.Object, .EventArgs) Handles optBackGroundColorYellow.CheckedChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Single sngSize = txtText.Font.Size;

      txtText.BackColor = theColor;
    }
    // ChangeBackColor(Color)

    private void ChangeEffect(FontStyle theEffect)
      //***
      // Action
      //   - Extra info
      //     - Fontstyle regular = 0
      //     - Fontstyle bold = 1
      //     - Fontstyle italic = 2
      //     - Fontstyle underline = 4
      //     - Fontstyle striketrough = 8
      //   - Get the size of the font (sngSize)
      //   - Depending on the effect
      //     - Fontstyle bold
      //       - Redraw with txtText.Font.Style (0000 till 1111) Xor theEffect (0001)
      //         - Xor (bitwise operator): If both values are the same, the result is false
      //           - If the last bits of the two operands (most right) are different, the last bit becomes 1
      //           - Font.Style is bold (true) and bold checkbox is changed (true), bold is switched off
      //           - Font.Style is bold (false) and bold checkbox is changed (true), bold is switched on
      //           - Font.Style is bold (false) and bold checkbox is changed (false), bold is switched off
      //           - Font.Style is bold (true) and bold checkbox is changed (false), bold is switched on
      //     - Fontstyle italic
      //       - Redraw with txtText.Font.Style (0000 till 1111) Xor theEffect (0010)
      //         - Xor (bitwise operator): If both values are the same, the result is false
      //           - If the second to last bits of the two operands (most right) are different, the second last bit becomes 1
      //     - Fontstyle strikeout
      //       - Redraw with txtText.Font.Style (0000 till 1111) Xor theEffect (1000)
      //         - Xor (bitwise operator): If both values are the same, the result is false
      //           - If the first bits of the two operands (most left) are different, the first bit becomes 1
      //     - Fontstyle underline
      //       - Redraw with txtText.Font.Style (0000 till 1111) Xor theEffect (0100)
      //         - Xor (bitwise operator): If both values are the same, the result is false
      //           - If the second bits of the two operands (most left) are different, the second bit becomes 1
      // Called by
      //   - chkEffectBold_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectBold.CheckedChanged
      //   - chkEffectItalic_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectItalic.CheckedChanged
      //   - chkEffectStrikethrough_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectStrikethrough.CheckedChanged
      //   - chkEffectUnderline_CheckedChanged(System.Object, System.EventArgs) Handles chkEffectUnderline.CheckedChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Single sngSize = txtText.Font.Size;

      switch (theEffect)
      {
        case FontStyle.Bold:
          txtText.Font = new System.Drawing.Font(txtText.Font.FontFamily, sngSize, txtText.Font.Style ^ theEffect);
          break;
        case FontStyle.Italic:
          txtText.Font = new System.Drawing.Font(txtText.Font.FontFamily, sngSize, txtText.Font.Style ^ theEffect);
          break;
        case FontStyle.Strikeout:
          txtText.Font = new System.Drawing.Font(txtText.Font.FontFamily, sngSize, txtText.Font.Style ^ theEffect);
          break;
        case FontStyle.Underline:
          txtText.Font = new System.Drawing.Font(txtText.Font.FontFamily, sngSize, txtText.Font.Style ^ theEffect);
          break;
       }
      // theEffect

    }
    // ChangeEffect(FontStyle)

    private void ChangeForeColor(Color theColor)
      //***
      // Action
      //   - Get the size of the font (sngSize)
      //   - Fore color of the text becomes theColor
      // Called by
      //   - optTextColorBlack_CheckedChanged(System.Object, System.EventArgs) Handles optTextColorBlack.CheckedChanged
      //   - optTextColorBlue_CheckedChanged(System.Object, System.EventArgs) Handles optTextColorBlack.CheckedChanged
      //   - optTextColorGreen_CheckedChanged(System.Object, System.EventArgs) Handles optTextColorBlack.CheckedChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Single sngSize = txtText.Font.Size;

      txtText.ForeColor = theColor;
    }
    // ChangeForeColor(Color)

    private void ChangeSize(Single sngChange)
      //***
      // Action
      //   - Get the size of the font (sngSize)
      //   - Add sngChange to sngSize
      //   - Redraw with the new value of sngSize
      //   - If sngSize is different from 9
      //     - cmdSmall becomes enabled
      //   - If not
      //     - cmdSmall becomes disabled
      // Called by
      //   - cmdBig_Click(System.Object, System.EventArgs) Handles cmdBig.Click
      //   - cmdSmall_Click(System.Object, System.EventArgs) Handles cmdSmall.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Single sngSize = txtText.Font.Size;

      sngSize += sngChange;
      txtText.Font = new System.Drawing.Font(txtText.Font.FontFamily, sngSize, txtText.Font.Style);
      lblSize.Text = sngSize.ToString();
      cmdSmall.Enabled = (sngSize != 9);
    }
    // ChangeSize(Single)

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFormatText
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmFormatText()
      // Created
      //   - CopyPaste � 20250702 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250702 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFormatText());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmFormatText

}
// CopyPaste.Learning