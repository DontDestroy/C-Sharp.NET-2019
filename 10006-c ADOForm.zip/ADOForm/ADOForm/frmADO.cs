//***
// Action
//   - Connect to a SQL Server
//     - cpNorthWindScript2019
//   - Create a Data Set
//   - Create a Table Adapter
//   - Create a Binding Source
//   - Show information on the screen
//   - Change the current position (record)
// Created
//   - CopyPaste � 20240613 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240613 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.Data
{

  public class frmAdo: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdFirst;
    internal System.Windows.Forms.Label lblCount;
    internal System.Windows.Forms.TextBox txtCategory;
    internal System.Data.OleDb.OleDbDataAdapter dtaCategory;
    internal System.Data.OleDb.OleDbCommand cmmSelectCategory;
    internal System.Data.OleDb.OleDbConnection cnncpNorthwindScript;
    internal System.Windows.Forms.Button cmdLast;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Button cmdPrevious;
    internal System.Windows.Forms.Button cmdLoad;
    private ADOForm.dsCategory dsCategory;
    internal System.Windows.Forms.Label lblCategory;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAdo));
      this.cmdFirst = new System.Windows.Forms.Button();
      this.lblCount = new System.Windows.Forms.Label();
      this.txtCategory = new System.Windows.Forms.TextBox();
      this.dtaCategory = new System.Data.OleDb.OleDbDataAdapter();
      this.cmmSelectCategory = new System.Data.OleDb.OleDbCommand();
      this.cnncpNorthwindScript = new System.Data.OleDb.OleDbConnection();
      this.cmdLast = new System.Windows.Forms.Button();
      this.cmdNext = new System.Windows.Forms.Button();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.cmdLoad = new System.Windows.Forms.Button();
      this.lblCategory = new System.Windows.Forms.Label();
      this.dsCategory = new ADOForm.dsCategory();
      ((System.ComponentModel.ISupportInitialize)(this.dsCategory)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdFirst
      // 
      this.cmdFirst.Location = new System.Drawing.Point(190, 86);
      this.cmdFirst.Name = "cmdFirst";
      this.cmdFirst.Size = new System.Drawing.Size(72, 32);
      this.cmdFirst.TabIndex = 12;
      this.cmdFirst.Text = "&First";
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      // 
      // lblCount
      // 
      this.lblCount.Location = new System.Drawing.Point(118, 46);
      this.lblCount.Name = "lblCount";
      this.lblCount.Size = new System.Drawing.Size(128, 24);
      this.lblCount.TabIndex = 10;
      this.lblCount.Text = "Record 0 of 0";
      // 
      // txtCategory
      // 
      this.txtCategory.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsCategory, "tblCPCategory.strCategoryName", true));
      this.txtCategory.Location = new System.Drawing.Point(118, 22);
      this.txtCategory.Name = "txtCategory";
      this.txtCategory.Size = new System.Drawing.Size(152, 20);
      this.txtCategory.TabIndex = 9;
      // 
      // dtaCategory
      // 
      this.dtaCategory.SelectCommand = this.cmmSelectCategory;
      this.dtaCategory.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCategory", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("lngIdCategory", "lngIdCategory"),
                        new System.Data.Common.DataColumnMapping("memDescription", "memDescription"),
                        new System.Data.Common.DataColumnMapping("olePicture", "olePicture"),
                        new System.Data.Common.DataColumnMapping("strCategoryName", "strCategoryName")})});
      // 
      // cmmSelectCategory
      // 
      this.cmmSelectCategory.CommandText = "SELECT strCategoryName FROM tblCPCategory";
      this.cmmSelectCategory.Connection = this.cnncpNorthwindScript;
      // 
      // cnncpNorthwindScript
      // 
      this.cnncpNorthwindScript.ConnectionString = "Provider=SQLNCLI11;Data Source=COPYPASTEPOWER\\COPYPASTE;Integrated Security=SSPI;" +
    "Initial Catalog=cpNorthWindScript2019";
      // 
      // cmdLast
      // 
      this.cmdLast.Location = new System.Drawing.Point(190, 230);
      this.cmdLast.Name = "cmdLast";
      this.cmdLast.Size = new System.Drawing.Size(72, 32);
      this.cmdLast.TabIndex = 15;
      this.cmdLast.Text = "&Last";
      this.cmdLast.Click += new System.EventHandler(this.cmdLast_Click);
      // 
      // cmdNext
      // 
      this.cmdNext.Location = new System.Drawing.Point(190, 182);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(72, 32);
      this.cmdNext.TabIndex = 14;
      this.cmdNext.Text = "&Next";
      this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Location = new System.Drawing.Point(190, 134);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(72, 32);
      this.cmdPrevious.TabIndex = 13;
      this.cmdPrevious.Text = "&Previous";
      this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
      // 
      // cmdLoad
      // 
      this.cmdLoad.Location = new System.Drawing.Point(62, 86);
      this.cmdLoad.Name = "cmdLoad";
      this.cmdLoad.Size = new System.Drawing.Size(80, 32);
      this.cmdLoad.TabIndex = 11;
      this.cmdLoad.Text = "Load Data";
      this.cmdLoad.Click += new System.EventHandler(this.cmdLoad_Click);
      // 
      // lblCategory
      // 
      this.lblCategory.Location = new System.Drawing.Point(22, 22);
      this.lblCategory.Name = "lblCategory";
      this.lblCategory.Size = new System.Drawing.Size(88, 16);
      this.lblCategory.TabIndex = 8;
      this.lblCategory.Text = "Category";
      this.lblCategory.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // dsCategory
      // 
      this.dsCategory.DataSetName = "dsCategory";
      this.dsCategory.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsCategory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // frmAdo
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 285);
      this.Controls.Add(this.txtCategory);
      this.Controls.Add(this.cmdLast);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.cmdLoad);
      this.Controls.Add(this.lblCategory);
      this.Controls.Add(this.cmdFirst);
      this.Controls.Add(this.lblCount);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmAdo";
      this.Text = "ADO Form";
      ((System.ComponentModel.ISupportInitialize)(this.dsCategory)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmAdo'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmAdo()
      //***
      // Action
      //   - Create instance of 'frmAdo'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmAdo()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdFirst_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the first position in a table in the data set
      //   - Show record information
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - Count()
      // Created
      //   - CopyPaste � 20240614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240614 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsCategory, "tblCPCategory"].Position = 0;
      Count();
    }
    // cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click

    private void cmdLast_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the last position in a table in the data set
      //   - Show record information
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - Count()
      // Created
      //   - CopyPaste � 20240614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240614 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsCategory, "tblCPCategory"].Position = BindingContext[dsCategory, "tblCPCategory"].Count - 1;
      Count();
    }
    // cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click

    private void cmdLoad_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Clear the data set
      //   - Fill the data set using a data adapter
      //   - Show record information
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - Count()
      // Created
      //   - CopyPaste � 20240614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240614 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsCategory.Clear();
      dtaCategory.Fill(dsCategory);
      Count();
    }
    // cmdLoad_Click(System.Object, System.EventArgs) Handles this.Load

    private void cmdNext_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the next position in a table in the data set
      //   - Show record information
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - Count()
      // Created
      //   - CopyPaste � 20240614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240614 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsCategory, "tblCPCategory"].Position += 1;
      Count();
    }
    // cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click

    private void cmdPrevious_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the previous position in a table in the data set
      //   - Show record information
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - Count()
      // Created
      //   - CopyPaste � 20240614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240614 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsCategory, "tblCPCategory"].Position -= 1;
      Count();
    }
    // cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void Count()
      //***
      // Action
      //   - Count the number of records that are in the dataset in a specific table
      //   - The position is zero based, so add 1
      //   - Show the information on the current position
      // Called by
      //   - cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click
      //   - cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click
      //   - cmdLoad_Click(System.Object, System.EventArgs) Handles cmdLoad.Click
      //   - cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click
      //   - cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240614 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngCurrent;
      int lngRecordCount;

      lngRecordCount = BindingContext[dsCategory, "tblCPCategory"].Count;
      lngCurrent = BindingContext[dsCategory, "tblCPCategory"].Position + 1;
      lblCount.Text = "Record " + lngCurrent.ToString() + " of " + lngRecordCount.ToString();
    }
    // Count()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmAdo
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmAdoTryout()
      // Created
      //   - CopyPaste � 20240614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmAdo());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmAdo

}
// CopyPaste.Learning.Data