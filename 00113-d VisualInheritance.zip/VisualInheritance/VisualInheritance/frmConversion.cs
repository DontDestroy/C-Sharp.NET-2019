//***
// Action
//   - Base form doing the conversion from Euro to Belgian Frank 
// Created
//   - CopyPaste � 20240219 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240219 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.VDAB.Learning
{

  public class frmConversion: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtBef;
    internal System.Windows.Forms.Label lblBef;
    internal System.Windows.Forms.Button cmdOK;
    internal System.Windows.Forms.TextBox txtEuro;
    internal System.Windows.Forms.Label lblEuro;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmConversion));
      this.txtBef = new System.Windows.Forms.TextBox();
      this.lblBef = new System.Windows.Forms.Label();
      this.cmdOK = new System.Windows.Forms.Button();
      this.txtEuro = new System.Windows.Forms.TextBox();
      this.lblEuro = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // txtBef
      // 
      this.txtBef.Location = new System.Drawing.Point(107, 91);
      this.txtBef.Name = "txtBef";
      this.txtBef.ReadOnly = true;
      this.txtBef.TabIndex = 9;
      this.txtBef.Text = "";
      // 
      // lblBef
      // 
      this.lblBef.Location = new System.Drawing.Point(11, 91);
      this.lblBef.Name = "lblBef";
      this.lblBef.Size = new System.Drawing.Size(88, 23);
      this.lblBef.TabIndex = 8;
      this.lblBef.Text = "&Belgian Frank:";
      // 
      // cmdOK
      // 
      this.cmdOK.Location = new System.Drawing.Point(107, 51);
      this.cmdOK.Name = "cmdOK";
      this.cmdOK.TabIndex = 7;
      this.cmdOK.Text = "OK";
      this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
      // 
      // txtEuro
      // 
      this.txtEuro.Location = new System.Drawing.Point(107, 11);
      this.txtEuro.Name = "txtEuro";
      this.txtEuro.TabIndex = 6;
      this.txtEuro.Text = "";
      // 
      // lblEuro
      // 
      this.lblEuro.Location = new System.Drawing.Point(11, 11);
      this.lblEuro.Name = "lblEuro";
      this.lblEuro.Size = new System.Drawing.Size(88, 23);
      this.lblEuro.TabIndex = 5;
      this.lblEuro.Text = "&Euro:";
      // 
      // frmConversion
      // 
      this.AcceptButton = this.cmdOK;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(218, 125);
      this.Controls.Add(this.txtBef);
      this.Controls.Add(this.lblBef);
      this.Controls.Add(this.cmdOK);
      this.Controls.Add(this.txtEuro);
      this.Controls.Add(this.lblEuro);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.Name = "frmConversion";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Euro to Belgian Frank";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmConversion'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240219 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240219 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmConversion()
      //***
      // Action
      //   - Create instance of 'frmConversion'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240219 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240219 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmConversion()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    protected virtual void cmdOK_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The entered value in textbox is converted to a number (if possible)
      //   - It is multiplied by 40.3399
      //   - It is rounded to no decimals
      //   - It is converted to a string
      //   - It is show in another textbox
      //   - If something fails
      //     - A message is shown
      // Called by
      //   - frmConversion.cmdOK_Click(theSender, theEventArguments) Handles cmdOK.Click
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240219 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240219 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        txtBef.Text = Math.Round(Convert.ToDecimal(txtEuro.Text) * 40.3399M).ToString();
      }
      catch
      {
        MessageBox.Show("Euro contains no value", this.Text);
      }
      finally
      {
      }
    
    }
    // cmdOK_Click(System.Object, System.EventArgs) Handles cmdOK.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmConversion
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240219 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240219 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmConversion());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmConversion

}
// CopyPaste.VDAB.Learning