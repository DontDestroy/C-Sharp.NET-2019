//***
// Action
//   - Demo of a button array
// Created
//   - CopyPaste � 20240524 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240524 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Learning.Toolkit;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmButtonArray: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblResult;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmButtonArray));
      this.lblResult = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // lblResult
      // 
      this.lblResult.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblResult.Location = new System.Drawing.Point(8, 8);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(136, 23);
      this.lblResult.TabIndex = 1;
      this.lblResult.TextAlign = System.Drawing.ContentAlignment.TopRight;
      // 
      // frmButtonArray
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(152, 273);
      this.Controls.Add(this.lblResult);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmButtonArray";
      this.Text = "Test ButtonArray";
      this.Load += new System.EventHandler(this.frmButtonArray_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmButtonArray'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmButtonArray()
      //***
      // Action
      //   - Create instance of 'frmButtonArray'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmButtonArray()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    cpControlArray mcpControlArray;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmButtonArray_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Add 5 commandbuttons to the control array
      //   - Remove the last one (for demo the functionality
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpControlArray(Form)
      //   - cpControlArray.AddCommandButton(int)
      //   - cpControlArray.RemoveLastCommandButton()
      // Created
      //   - CopyPaste � 20240524 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240524 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mcpControlArray = new cpControlArray(this);

      mcpControlArray.AddCommandButton(1);
      mcpControlArray.AddCommandButton(2);
      mcpControlArray.AddCommandButton(3);
      mcpControlArray.AddCommandButton(4);
      mcpControlArray.AddCommandButton(5);
      mcpControlArray.RemoveLastCommandButton();
    }
    // frmButtonArray_Load(System.Object, System.EventArgs) Handling this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmButtonArray
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmButtonArray()
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmButtonArray());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmButtonArray

}
// CopyPaste.Learning