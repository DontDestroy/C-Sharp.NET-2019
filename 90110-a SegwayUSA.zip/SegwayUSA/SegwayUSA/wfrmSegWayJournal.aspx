﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmSegWayJournal.aspx.cs" Inherits="CopyPaste.Learning.wfrmSegWayJournal" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>My Trip Around the USA on a Segway</title>
  <link type="text/css" rel="stylesheet" href="cssJournal.css">
</head>
<body>
  <form id="wfrmSegWayJournal">
    <h1>Segway'n USA</h1>
    <p>
      Documenting my trip around the US on my very own Segway!
    </p>
    <h2>August 20, 2012</h2>
    <p>
      <img src="Resources/segway2.jpg" alt="Picture can't be found">
    </p>
    <p>
      Well I made it 1200 miles already, and I passed
      through some interesting places on the way: 
    </p>
    <ol>
      <li>Walla Walla, WA</li>
      <li>Magic City, ID</li>
      <li>Bountiful, UT</li>
      <li>Last Chance, CO</li>
      <li>Truth or Consequences, NM</li>
      <li>Why, AZ</li>
    </ol>
    <h2>July 14, 2012</h2>
    <p>
      I saw some Burma Shave style signs on the side of the
      road today:
    </p>
    <blockquote>
      Passing cars,
      <br>
      When you can't see,
      <br>
      May get you,
      <br>
      A glimpse,
      <br>
      Of eternity.
      <br>
    </blockquote>
    <p>
      I definitely won't be passing any cars.
    </p>
    <h2>June 2, 2012</h2>
    <p>
      <img src="Resources/segway1.jpg" alt="Picture can't be found">
    </p>
    <p>
      My first day of the trip!  I can't believe I finally got
      everything packed and ready to go.  Because I'm on a Segway,
      I wasn't able to bring a whole lot with me:
    </p>
    <ul>
      <li>cellphone</li>
      <li>iPod</li>
      <li>digital camera</li>
      <li>and a protein bar</li>
    </ul>
    <p>
      Just the essentials.  As
      Lao Tzu would have said, <q>A journey of a 
      thousand miles begins with one Segway.</q>
    </p>
  </form>
</body>
</html>
