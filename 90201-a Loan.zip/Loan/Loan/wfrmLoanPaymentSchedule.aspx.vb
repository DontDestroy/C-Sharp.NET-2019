﻿'***
' Action
'   - Show a table with the monthly payments
'   - There are some labels
'   - There is a data grid
' Created
'   - CopyPaste – 20260417 – VVDW
' Changed
'   - CopyPaste – yyyymmdd – VVDW – What changed
' Tested
'   - CopyPaste – 20260417 – VVDW
' Proposal (To Do)
'   -
'***


Option Explicit On
Option Strict On

Imports System.Globalization
Imports System.Web.Caching

Namespace CopyPaste.Learning

  Public Class wfrmLoanPaymentSchedule
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Init
      InitializeComponent()
    End Sub

#End Region

    '#Region "Constructors"
    '#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

#Region "Fields"
    Protected WithEvents dtgSchedule As System.Web.UI.WebControls.DataGrid
    Protected WithEvents lblTitle As System.Web.UI.WebControls.Label
    Protected WithEvents lblDetails As System.Web.UI.WebControls.Label

    Dim dclColumn1 As DataColumn
    Dim dclColumn2 As DataColumn
    Dim dclColumn3 As DataColumn
    Dim dclColumn4 As DataColumn
    Dim dclColumn5 As DataColumn
    Dim dclColumn6 As DataColumn

    Dim dsSchedule As DataSet
    Dim dtTable As DataTable
    Dim intLoanAmount As Int32
    Dim intTerm As Int32
    Dim sngPayment As Single
    Dim sngRate As Single
#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

#Region "Controls"

    Private Sub Page_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Load
      '***
      ' Action
      '   - Define and initialize a Belgian culture info
      '   - Define and initialize the wanted number format
      '   - Initialize the loan amount (getting from the cache)
      '   - Initialize the number of terms (getting from the cache)
      '   - Initialize the monthly payment (getting from the cache)
      '   - Initialize the interest rate (getting from the cache)
      '   - Show the details on the form in the correct format (Belgian)
      '   - Construct the table
      '   - Calculated the schedule
      ' Called by
      '   - User action (Loading the page)
      ' Calls
      '   - CalculateSchedule()
      '   - ConstructTable()
      ' Created
      '   - CopyPaste – 20260417 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260417 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      Dim culinfBelgium As New CultureInfo("fr-BE", False)
      Dim nfiBelgium As NumberFormatInfo = culinfBelgium.NumberFormat

      intLoanAmount = Convert.ToInt32(Cache("cpLoanAmount"))
      intTerm = Convert.ToInt32(Cache("cpTerm"))
      sngPayment = Convert.ToSingle(Cache("cpPayment"))
      sngRate = Convert.ToSingle(Cache("cpRate"))
      lblDetails.Text = "Loan Amount: " & intLoanAmount.ToString("€ #,##0.00", nfiBelgium) &
        "    Rate:  " & sngRate.ToString("#,##0.00%", nfiBelgium) &
        "    Term:  " & intTerm.ToString & " months."

      ConstructTable()
      CalculateSchedule()
    End Sub
    ' Page_Load(System.Object, System.EventArgs) Handles MyBase.Load

#End Region

#Region "Functionality"

    '#Region "Event"
    '#End Region

#Region "Sub / Function"

    Private Sub CalculateSchedule()
      '***
      ' Action
      '   - Define and initialize a Belgian culture info
      '   - Define a data row and some other variables for intermediate results
      '   - Loop thru the number of terms (months)
      '     - Add a new row using the the table "Schedule" definition from the dataset
      '     - Data row becomes the new row
      '     - Add the data row to the table "Schedule"
      '     - Calculate the paid to date
      '     - Calculate the principal
      '     - Calculate the total principal
      '     - Fill the data row with the correct numbers in the correct format (Belgian)
      '       - Inside that fill there is a calculation (showed the technique, but I prefer a variable)
      '       - Accept the changes in the dataset
      '   - Bind the data set result to the data grid on the form using a data view
      ' Called by
      '   - Page_Load(System.Object, System.EventArgs) Handles MyBase.Load
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20260417 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260417 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      Dim culinfBelgium As New CultureInfo("fr-BE", False)
      Dim drDataRow As DataRow
      Dim intInstallment As Int32
      Dim nfiBelgium As NumberFormatInfo = culinfBelgium.NumberFormat
      Dim sngPaidToDate As Single = 0
      Dim sngPrincipal As Single
      Dim sngTotalPrincipal As Single = intLoanAmount

      For intInstallment = 1 To intTerm
        drDataRow = dsSchedule.Tables("Schedule").NewRow
        dsSchedule.Tables("Schedule").Rows.Add(drDataRow)
        sngPaidToDate += sngPayment
        sngPrincipal = Convert.ToSingle(PPmt(sngRate / 12, intInstallment, intTerm, -intLoanAmount, 0, DueDate.EndOfPeriod))
        sngTotalPrincipal -= sngPrincipal

        drDataRow("Installment") = intInstallment
        drDataRow("Payment") = sngPayment.ToString("€ #,##0.00", nfiBelgium)
        drDataRow("Principal") = Math.Round(sngPrincipal, 2).ToString("€ #,##0.00", nfiBelgium)
        drDataRow("Interest") = (sngPayment - sngPrincipal).ToString("€ #,##0.00", nfiBelgium)
        drDataRow("PrincipalRemaining") = sngTotalPrincipal.ToString("€ #,##0.00", nfiBelgium)
        drDataRow("PaidToDate") = sngPaidToDate.ToString("€ #,##0.00", nfiBelgium)
        dsSchedule.AcceptChanges()
      Next intInstallment

      With dtgSchedule
        .PageSize = intTerm
        .DataSource = New DataView(dsSchedule.Tables("Schedule"))
        .DataBind()
      End With
      ' dtgSchedule

    End Sub
    ' CalculateSchedule()

    Private Sub ConstructTable()
      '***
      ' Action
      '   - Initialize a new data set
      '   - Initialize a new data table
      '   - Add the data table to the data set
      '   - Create 6 new columns with the correct data type
      '   - Add the 6 columns to the data table
      ' Called by
      '   - Page_Load(System.Object, System.EventArgs) Handles MyBase.Load
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20260417 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260417 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      dsSchedule = New DataSet("PaymentSchedule")
      dtTable = New DataTable("Schedule")

      dsSchedule.Tables.Add(dtTable)

      dclColumn1 = New DataColumn("Installment")
      dclColumn1.DataType = System.Type.GetType("System.Int32")
      dclColumn2 = New DataColumn("Payment")
      dclColumn2.DataType = System.Type.GetType("System.String")
      dclColumn3 = New DataColumn("Principal")
      dclColumn3.DataType = System.Type.GetType("System.String")
      dclColumn4 = New DataColumn("Interest")
      dclColumn4.DataType = System.Type.GetType("System.String")
      dclColumn5 = New DataColumn("PrincipalRemaining")
      dclColumn5.DataType = System.Type.GetType("System.String")
      dclColumn6 = New DataColumn("PaidToDate")
      dclColumn6.DataType = System.Type.GetType("System.String")

      With dtTable.Columns
        .Add(dclColumn1)
        .Add(dclColumn2)
        .Add(dclColumn3)
        .Add(dclColumn4)
        .Add(dclColumn5)
        .Add(dclColumn6)
      End With
      ' dtTable.Columns

    End Sub
    ' ConstructTable()

#End Region

#End Region

#End Region

    '#Region "Not used"
    '#End Region

  End Class
  ' wfrmLoanPaymentSchedule

End Namespace
' CopyPaste.Learning