//***
// Action
//   - Definition of a cpClient
// Created
//   - CopyPaste � 20240105 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240105 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;

namespace CopyPaste.Learning
{

	public class cpClient
	{
		
		#region "Constructors / Destructors"

		public cpClient(string strFirstName, string strLastName)
			//***
			// Action
			//   - Constructor with 2 arguments
			//   - An first name and a last name
			//   - Set the 2 properties
			// Called by
			//   - 
			// Calls
			//   - FirstName(string) (Set)
			//   - LastName(string) (Set)
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
	  {
			FirstName = strFirstName;
			LastName = strLastName;
		}
		// cpClient(string, string)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private string mstrFirstName;
		private string mstrLastName;

		#endregion

		#region "Properties"

		public string FirstName
		{
			
			get
				//***
				// Action Get
				//   - Returns mstrFirstName
				// Called by
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mstrFirstName;
			}
			// string FirstName (Get)

			set
				//***
				// Action Set
				//   - mstrFirstName becomes value
				// Called by
				//   - cpClient(string, string)
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				mstrFirstName = value;
			}
			// FirstName(string) (Set)

		}
		// string FirstName

		public string LastName
		{
			
			get
				//***
				// Action Get
				//   - Returns mstrLastName
				// Called by
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mstrLastName;
			}
			// string LastName (Get)

			set
				//***
				// Action Set
				//   - mstrLastName becomes value
				// Called by
				//   - cpClient(string, string)
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				mstrLastName = value;
			}
			// LastName(string) (Set)

		}
		// string LastName

		#endregion

		#region "Methods"

		#region "Overrides"

		public override string ToString()
			//***
			// Action
			//   - Return the FirstName and the LastName
			// Called by
			//   - string cpAccount.ToString()
			//   - cpProgram.Main()
			// Calls
			//   - string FirstName (Get)
			//   - string LastName (Get)
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
	  {
			return "Firstname: " + FirstName + ControlChars.CrLf + "Lastname: " + LastName;
		}
		// string ToString()

		#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
  // cpClient

}
// CopyPaste.Learning