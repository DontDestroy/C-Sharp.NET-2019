﻿'***
' Action
'   - Showing a welcome screen started from HTML page
' Created
'   - CopyPaste – 20260414 – VVDW
' Changed
'   - CopyPaste – yyyymmdd – VVDW – What changed
' Tested
'   - CopyPaste – 20260414 – VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On
Option Strict On

Namespace CopyPaste.Learning

  Public Class wfrmWelcome
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

#End Region

    '#Region "Constructors"
    '#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

#Region "Fields"
    Protected WithEvents lblToday As System.Web.UI.WebControls.Label
    Protected WithEvents lblInfo As System.Web.UI.WebControls.Label
    Protected WithEvents lblName As System.Web.UI.WebControls.Label
    Protected WithEvents cmdOK As System.Web.UI.WebControls.Button
    Protected WithEvents lblWelcome As System.Web.UI.WebControls.Label
    Protected WithEvents txtName As System.Web.UI.WebControls.TextBox
#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

#Region "Controls"

    Private Sub cmdOK_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdOK.Click
      '***
      ' Action
      '   - Change the label of the form
      ' Called by
      '   - User action (Clicking a button)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20260414 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260414 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      lblWelcome.Text = "Welcome, " & txtName.Text
    End Sub
    ' cmdOK_Click(System.Object, System.EventArgs) Handles cmdOK.Click

    Private Sub Page_Init(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Init
      '***
      ' Action
      '   - Initalize the page
      ' Called by
      '   - User action (Starting the page)
      ' Calls
      '   - InitializeComponent()
      ' Created
      '   - CopyPaste – 20260414 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260414 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      InitializeComponent()
    End Sub
    ' Page_Init(System.Object, System.EventArgs) Handles MyBase.Init

    Private Sub Page_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Load
      '***
      ' Action
      '   - Set the culture info of a certain page into the user language of the request
      '   - Set that information in the today label as text
      '   - Set that user language in the info label as text
      '   - If the form is a postback (recalled)
      '     - Do nothing
      '   - If not
      '     - Set the text box text to the given name of the request
      ' Called by
      '   - User action (Starting the page)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20260414 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260414 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      System.Threading.Thread.CurrentThread.CurrentCulture = New Globalization.CultureInfo(Request.UserLanguages(0))

      lblToday.Text = Date.Today.ToLongDateString
      lblInfo.Text = Request.UserLanguages(0)

      If IsPostBack Then
      Else
        ' Not IsPostBack 
        txtName.Text = Request.Form("name")
      End If
      ' IsPostBack 

    End Sub
    ' Page_Load(System.Object, System.EventArgs) Handles MyBase.Load

#End Region

    '#Region "Functionality"

    '#Region "Event"
    '#End Region

    '#Region "Sub / Function"
    '#End Region

    '#End Region

#End Region

    '#Region "Not used"
    '#End Region

  End Class
  ' wfrmWelcome

End Namespace
' CopyPaste.Learning