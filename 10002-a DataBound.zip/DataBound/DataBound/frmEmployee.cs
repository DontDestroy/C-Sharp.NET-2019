﻿//***
// Action
//   - Binding data to controls on a form
// Created
//   - CopyPaste – 20210628 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210628 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataBound
{

  public partial class frmEmployee : Form
  {

    #region "Constructors / Destructors"

    public frmEmployee()
    //***
    // Action
    //   - Creating an instance of the form
    //   - Initialize the components of that form
    //   - Fill DataAdapter with DataSet information
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210628 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210628 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
      dtaEmployee.Fill(dsEmployee.tblCPEmployee);
    }
    // frmEmployee()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmEmployee

}
// DataBound