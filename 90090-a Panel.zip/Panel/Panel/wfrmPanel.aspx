﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmPanel.aspx.cs" Inherits="CopyPaste.Learning.wfrmPanel" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Panel</title>
</head>
<body>
  <form id="wfrmPanel" method="post" runat="server">
    <asp:Panel ID="panAlphabet" Style="z-index: 101; position: absolute; top: 8px; left: 8px" runat="server"></asp:Panel>
    <asp:Label ID="lblCountCountries" Style="z-index: 109; position: absolute; top: 208px; left: 224px"
      runat="server" Height="11px"></asp:Label>
    <asp:Label ID="lblPath" Style="z-index: 108; position: absolute; top: 176px; left: 224px" runat="server"
      Height="11px"></asp:Label>
    <asp:Label ID="lblStatus" Style="z-index: 107; position: absolute; top: 144px; left: 224px"
      runat="server" Height="11px"></asp:Label>
    <asp:Button ID="cmdHere" Style="z-index: 106; position: absolute; top: 344px; left: 72px" runat="server"
      Text="I live here"></asp:Button>
    <asp:ListBox ID="lstCountries" Style="z-index: 102; position: absolute; top: 40px; left: 24px"
      runat="server" Width="168px" Height="280px" AutoPostBack="True"></asp:ListBox>
    <asp:Label ID="lblCountry" Style="z-index: 103; position: absolute; top: 80px; left: 224px"
      runat="server"></asp:Label>
    <asp:Label ID="lblClickLetter" Style="z-index: 104; position: absolute; top: 48px; left: 224px"
      runat="server"></asp:Label>
    <asp:Label ID="lblSelected" Style="z-index: 105; position: absolute; top: 112px; left: 224px"
      runat="server"></asp:Label>
  </form>
</body>
</html>
