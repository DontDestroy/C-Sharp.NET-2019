//***
// Action
//   - Showing a messagebox
// Created
//   - CopyPaste � 20210831 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20210831 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;

namespace MsgBox
{

  class cpMsgBox
	{

    static void Main()
    //***
    // Action
    //   - Show a message
    //   - Show a message with a title and 3 buttons
    // Called by
    //   - 
    // Calls
    //   - Microsoft.VisualBasic.Interaction.MsgBox(string, Int32, string)
    // Created
    //   - CopyPaste � 20210831 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20210831 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Interaction.MsgBox("Message", MsgBoxStyle.OkOnly, "Copy Paste");
      Interaction.MsgBox("Message", MsgBoxStyle.AbortRetryIgnore, "Copy Paste");
    }
    // Main()

  }
  // cpMsgBox

}
// MsgBox