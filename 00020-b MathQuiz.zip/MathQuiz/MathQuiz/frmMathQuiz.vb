'***
' Action
'   - Creating a math quiz. This is a form as startpoint of the exercise
' Created
'   - CopyPaste � 20210830 � VVDW
' Changed
'   - Organisation � yyyymmdd � Initials of programmer � What changed
' Tested
'   - CopyPaste � 20210830 � VVDW
' Proposal (To Do)
'   - List of actions that can be added to the functionality
'***

Option Explicit On 
Option Strict On

Imports System.Windows.Forms

Public Class frmMathQuiz
  Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "
  'Required by the Windows Form Designer
  Private components As System.ComponentModel.IContainer

  'NOTE: The following procedure is required by the Windows Form Designer
  'It can be modified using the Windows Form Designer.  
  'Do not modify it using the code editor.
  Friend WithEvents cmdQuit As System.Windows.Forms.Button
  Friend WithEvents cmdAnswer As System.Windows.Forms.Button
  Friend WithEvents lblNumber01 As System.Windows.Forms.Label
  Friend WithEvents lblEqual As System.Windows.Forms.Label
  Friend WithEvents lblOperator As System.Windows.Forms.Label
  Friend WithEvents lblNumber02 As System.Windows.Forms.Label
  Friend WithEvents txtResult As System.Windows.Forms.TextBox
  Friend WithEvents lblTitle As System.Windows.Forms.Label
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMathQuiz))
    Me.cmdQuit = New System.Windows.Forms.Button
    Me.cmdAnswer = New System.Windows.Forms.Button
    Me.lblNumber01 = New System.Windows.Forms.Label
    Me.lblEqual = New System.Windows.Forms.Label
    Me.lblOperator = New System.Windows.Forms.Label
    Me.lblNumber02 = New System.Windows.Forms.Label
    Me.txtResult = New System.Windows.Forms.TextBox
    Me.lblTitle = New System.Windows.Forms.Label
    Me.SuspendLayout()
    '
    'cmdQuit
    '
    Me.cmdQuit.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdQuit.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
    Me.cmdQuit.Location = New System.Drawing.Point(235, 205)
    Me.cmdQuit.Name = "cmdQuit"
    Me.cmdQuit.Size = New System.Drawing.Size(96, 35)
    Me.cmdQuit.TabIndex = 7
    Me.cmdQuit.Text = "Quit"
    '
    'cmdAnswer
    '
    Me.cmdAnswer.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.cmdAnswer.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
    Me.cmdAnswer.Location = New System.Drawing.Point(60, 205)
    Me.cmdAnswer.Name = "cmdAnswer"
    Me.cmdAnswer.Size = New System.Drawing.Size(96, 35)
    Me.cmdAnswer.TabIndex = 6
    Me.cmdAnswer.Text = "Answer"
    '
    'lblNumber01
    '
    Me.lblNumber01.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.lblNumber01.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lblNumber01.Location = New System.Drawing.Point(15, 95)
    Me.lblNumber01.Name = "lblNumber01"
    Me.lblNumber01.Size = New System.Drawing.Size(90, 35)
    Me.lblNumber01.TabIndex = 1
    Me.lblNumber01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'lblEqual
    '
    Me.lblEqual.AutoSize = True
    Me.lblEqual.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lblEqual.Location = New System.Drawing.Point(250, 100)
    Me.lblEqual.Name = "lblEqual"
    Me.lblEqual.Size = New System.Drawing.Size(23, 31)
    Me.lblEqual.TabIndex = 4
    Me.lblEqual.Text = "="
    '
    'lblOperator
    '
    Me.lblOperator.AutoSize = True
    Me.lblOperator.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lblOperator.Location = New System.Drawing.Point(115, 100)
    Me.lblOperator.Name = "lblOperator"
    Me.lblOperator.Size = New System.Drawing.Size(23, 31)
    Me.lblOperator.TabIndex = 2
    Me.lblOperator.Text = "+"
    Me.lblOperator.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'lblNumber02
    '
    Me.lblNumber02.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
    Me.lblNumber02.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lblNumber02.Location = New System.Drawing.Point(150, 95)
    Me.lblNumber02.Name = "lblNumber02"
    Me.lblNumber02.Size = New System.Drawing.Size(90, 35)
    Me.lblNumber02.TabIndex = 3
    Me.lblNumber02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'txtResult
    '
    Me.txtResult.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.txtResult.Location = New System.Drawing.Point(285, 95)
    Me.txtResult.Name = "txtResult"
    Me.txtResult.Size = New System.Drawing.Size(90, 35)
    Me.txtResult.TabIndex = 5
    Me.txtResult.Text = ""
    Me.txtResult.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
    '
    'lblTitle
    '
    Me.lblTitle.Font = New System.Drawing.Font("Times New Roman", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
    Me.lblTitle.ForeColor = System.Drawing.Color.Navy
    Me.lblTitle.Location = New System.Drawing.Point(10, 5)
    Me.lblTitle.Name = "lblTitle"
    Me.lblTitle.Size = New System.Drawing.Size(370, 35)
    Me.lblTitle.TabIndex = 0
    Me.lblTitle.Text = "Math Quiz"
    Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
    '
    'frmMathQuiz
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(387, 298)
    Me.Controls.Add(Me.lblTitle)
    Me.Controls.Add(Me.txtResult)
    Me.Controls.Add(Me.lblNumber02)
    Me.Controls.Add(Me.cmdQuit)
    Me.Controls.Add(Me.cmdAnswer)
    Me.Controls.Add(Me.lblNumber01)
    Me.Controls.Add(Me.lblEqual)
    Me.Controls.Add(Me.lblOperator)
    Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
    Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
    Me.Name = "frmMathQuiz"
    Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
    Me.Text = "Math Quiz"
    Me.ResumeLayout(False)

  End Sub

#End Region

#Region "Constructors / Destructors"

  Protected Overloads Overrides Sub Dispose(ByVal blnDisposing As Boolean)
    '***
    ' Action
    '   - Cleanup after closing the form
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210830 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210830 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    If blnDisposing Then

      If components Is Nothing Then
      Else
        ' Not components Is Nothing
        components.Dispose()
      End If
      ' components Is Nothing

    Else
      ' Not blnDisposing
    End If
    ' blnDisposing

    MyBase.Dispose(blnDisposing)
  End Sub
  ' Dispose(Boolean)

  Public Sub New()
    '***
    ' Action
    '   - Creating an instance of the form
    '   - Initialize the components of that form
    ' Called by
    '   - 
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210830 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210830 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    MyBase.New()
    InitializeComponent()
  End Sub
  ' New()

#End Region

  '#Region "Designer"
  '#End Region

  '#Region "Structures"
  '#End Region

#Region "Fields"
  Dim mintAnswer As Int32
  Dim mrndRandom As New Random(Date.Now.Millisecond)
#End Region

  '#Region "Properties"
  '#End Region

#Region "Methods"

  '#Region "Overrides"
  '#End Region

#Region "Controls"

  Private Sub cmdAnswer_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdAnswer.Click
    '***
    ' Action
    '   - Try
    '     - If mintAnswer equals txtResult (converted to integer)
    '       - Show message "You got the answer right!".
    '     - If Not
    '       - Show message "Oh no, you missed that one!".
    '   - On Error
    '     - Show message "Please enter a number."
    '   - Create a new math problem
    '   - Clear txtResult
    ' Called by
    '   - User action (clicking a button)
    ' Calls
    '   - CreateMathProblem()
    ' Created
    '   - CopyPaste � 20210830 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210830 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    Try

      If mintAnswer = Convert.ToInt32(txtResult.Text) Then
        MessageBox.Show("You got the answer right!", "Correct")
      Else
        ' Not mintAnswer = Convert.ToInt32(txtResult.Text)
        MessageBox.Show("Oh no, you missed that one!", "Wrong")
      End If
      ' mintAnswer = Convert.ToInt32(txtResult.Text)

    Catch theException As Exception
      MessageBox.Show("Please enter a number.")
    End Try

    CreateMathProblem()
    txtResult.Text = ""
  End Sub
  ' cmdAnswer_Click(System.Object, System.EventArgs) Handles cmdAnswer.Click

  Private Sub cmdQuit_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdQuit.Click
    '***
    ' Action
    '   - End application
    ' Called by
    '   - User action (clicking a button)
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210830 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210830 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    End
  End Sub
  ' cmdQuit_Click(System.Object, System.EventArgs) Handles cmdQuit.Click

  Private Sub frmMathQuiz_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Load
    '***
    ' Action
    '   - Create a new math problem
    ' Called by
    '   - User action (loading the form)
    ' Calls
    '   - CreateMathProblem()
    ' Created
    '   - CopyPaste � 20210830 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210830 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    CreateMathProblem()
  End Sub
  ' frmMathQuiz_Load(System.Object, System.EventArgs) Handles MyBase.Load

#End Region

#Region "Functionality"

  '#Region "Event"
  '#End Region

#Region "Sub / Function"

  Private Sub CreateMathProblem()
    '***
    ' Action
    '   - Define a random first number (intFirst)
    '   - Define a random second number (intSecond)
    '   - Define a random operator
    '     - When 0
    '       - Correct answer is intFirst + intSecond
    '     - When 1
    '       - Correct answer is intFirst - intSecond
    '     - When 2
    '       - Correct answer is intFirst * intSecond
    ' Called by
    '   - cmdAnswer_Click(System.Object, System.EventArgs) Handles cmdAnswer.Click
    '   - frmMathQuiz_Load(System.Object, System.EventArgs) Handles MyBase.Load
    ' Calls
    '   - 
    ' Created
    '   - CopyPaste � 20210830 � VVDW
    ' Changed
    '   - Organisation � yyyymmdd � Initials of programmer � What changed
    ' Tested
    '   - CopyPaste � 20210830 � VVDW
    ' Keyboard key
    '   - 
    ' Proposal (To Do)
    '   - List of actions that can be added to the functionality
    '***

    Dim intFirst As Int32
    Dim intSecond As Int32

    intFirst = mrndRandom.Next(11)
    lblNumber01.Text = intFirst.ToString
    intSecond = mrndRandom.Next(11)
    lblNumber02.Text = intSecond.ToString

    Select Case mrndRandom.Next(3)
      Case 0
        lblOperator.Text = "+"
        mintAnswer = intFirst + intSecond
      Case 1
        lblOperator.Text = "-"
        mintAnswer = intFirst - intSecond
      Case 2
        lblOperator.Text = "*"
        mintAnswer = intFirst * intSecond
      Case Else
        ' Not 0, 1, 2
    End Select
    ' mrndRandom.Next(3)

  End Sub
  ' CreateMathProblem()

#End Region

#End Region

#End Region

  '#Region "Not used"
  '#End Region

End Class
' frmMathQuiz