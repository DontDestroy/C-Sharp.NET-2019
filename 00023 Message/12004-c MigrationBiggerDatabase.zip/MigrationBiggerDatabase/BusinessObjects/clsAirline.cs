﻿//***
// Action
//   - Definition of an AircraftType
// Created
//   - CopyPaste – 20230714 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230714 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CopyPaste.BusinessObjects
{

  public class Airline
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    [StringLengthAttribute(3)]
    [KeyAttribute]
    public string Code { get; set; }

    [StringLengthAttribute(100)]
    public virtual string Name { get; set; }

    // A relation towards entity class Flight (the many part)
    public virtual List<Flight> Flight { get; set; }

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override string ToString()
    //***
    // Action
    //   - Returns the Airline name and code
    // Called by
    //   - 
    // Calls
    //   - string Code (Get)
    //   - string Name (Get)
    // Created
    //   - CopyPaste – 20230714 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return "Airline " + Name + " (" + Code + ")";
    }
    // string ToString()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Airline

}
// CopyPaste.BusinessObjects 