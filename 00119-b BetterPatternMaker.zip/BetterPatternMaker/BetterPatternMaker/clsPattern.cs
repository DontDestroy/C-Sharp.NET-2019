//***
// Action
//   - Implementation of a cpPattern
//   - It is an abstract class
//     - Define a clone functionality (a pattern can be copied)
//     - Define a draw functionality (a pattern can be drawn)
//     - Define an editor for drawing the pattern (bitmap or drawing)
//       - The pattern can get its corresponding editor to draw and save thru polymorphism
// Created
//   - CopyPaste � 20240409 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240409 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public abstract class cpPattern
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public abstract cpPattern cpClone();
    public abstract void cpDraw(System.Object theSender, System.Windows.Forms.PaintEventArgs thePaintEventArguments);
    public abstract cpctlPatternEditor cpGetEditor(); 

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPattern

}
// CopyPaste.Learning