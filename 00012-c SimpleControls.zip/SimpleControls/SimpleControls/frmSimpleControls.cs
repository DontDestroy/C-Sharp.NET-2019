//***
// Action
//   - Some controls in a form
// Created
//   - CopyPaste � 20210827 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210827 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System.Windows.Forms;

namespace SimpleControls
{

  public class frmSimpleControls : System.Windows.Forms.Form
	{

    #region Windows Form Designer generated code
    internal System.Windows.Forms.Label lblLarge;
    internal System.Windows.Forms.TextBox txtTextBox;
    internal System.Windows.Forms.Label lblTextBox;
    internal System.Windows.Forms.Button cmdButton;
    internal System.Windows.Forms.Label lblButton;

    private System.ComponentModel.Container components = null;
   
    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSimpleControls));
      this.lblLarge = new System.Windows.Forms.Label();
      this.txtTextBox = new System.Windows.Forms.TextBox();
      this.lblTextBox = new System.Windows.Forms.Label();
      this.cmdButton = new System.Windows.Forms.Button();
      this.lblButton = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // lblLarge
      // 
      this.lblLarge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblLarge.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblLarge.Location = new System.Drawing.Point(64, 224);
      this.lblLarge.Name = "lblLarge";
      this.lblLarge.Size = new System.Drawing.Size(344, 80);
      this.lblLarge.TabIndex = 9;
      this.lblLarge.Text = "This is a Label with a large font and a border.";
      this.lblLarge.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // txtTextBox
      // 
      this.txtTextBox.Location = new System.Drawing.Point(200, 112);
      this.txtTextBox.Multiline = true;
      this.txtTextBox.Name = "txtTextBox";
      this.txtTextBox.Size = new System.Drawing.Size(248, 56);
      this.txtTextBox.TabIndex = 8;
      this.txtTextBox.Text = "TextBox1";
      // 
      // lblTextBox
      // 
      this.lblTextBox.AutoSize = true;
      this.lblTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblTextBox.Location = new System.Drawing.Point(24, 128);
      this.lblTextBox.Name = "lblTextBox";
      this.lblTextBox.Size = new System.Drawing.Size(142, 22);
      this.lblTextBox.TabIndex = 7;
      this.lblTextBox.Text = "This is a TextBox:";
      // 
      // cmdButton
      // 
      this.cmdButton.Location = new System.Drawing.Point(200, 24);
      this.cmdButton.Name = "cmdButton";
      this.cmdButton.Size = new System.Drawing.Size(248, 48);
      this.cmdButton.TabIndex = 6;
      this.cmdButton.Text = "Button1";
      // 
      // lblButton
      // 
      this.lblButton.AutoSize = true;
      this.lblButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblButton.Location = new System.Drawing.Point(24, 40);
      this.lblButton.Name = "lblButton";
      this.lblButton.Size = new System.Drawing.Size(129, 22);
      this.lblButton.TabIndex = 5;
      this.lblButton.Text = "This is a Button:";
      // 
      // frmSimpleControls
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(472, 381);
      this.Controls.Add(this.lblLarge);
      this.Controls.Add(this.txtTextBox);
      this.Controls.Add(this.lblTextBox);
      this.Controls.Add(this.cmdButton);
      this.Controls.Add(this.lblButton);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSimpleControls";
      this.Text = "Simple Controls";
      this.ResumeLayout(false);

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose( bool disposing )
      //***
      // Action
      //   - Cleanup after closing the form
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20210827 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20210827 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {

      if( disposing )
      {

        if (components == null) 
        {
        }
        else
          // (components != null) 
        {
          components.Dispose();
        }
        // (components == null) 

      }
      else
        // Not ( disposing )
      {
      }
      // ( disposing )

    base.Dispose( disposing );
    }
    // Dispose( bool )

    public frmSimpleControls()
      // Action
      //   - Creating an instance of the form
      //   - Initialize the components of that form
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20210827 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20210827 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      InitializeComponent();
    }
    // frmSimpleControls()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      // Action
      //   - Start of the application
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSimpleControls()
      // Created
      //   - CopyPaste � 20210827 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20210827 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      Application.Run(new frmSimpleControls());
    }
    // Main() 

    #endregion

    #endregion

    #endregion

  }
  // frmSimpleControls

}
// SimpleControls