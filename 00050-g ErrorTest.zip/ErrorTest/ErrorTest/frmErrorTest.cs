//***
// Action
//   - Structured error handling
// Created
//   - CopyPaste � 20230807 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230807 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmErrorTest : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmErrorTest));
      // 
      // frmErrorTest
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmErrorTest";
      this.Text = "ErrorTest";
      this.Click += new System.EventHandler(this.frmErrorTest_Click);
      this.Load += new System.EventHandler(this.frmErrorTest_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmErrorTest'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmErrorTest()
      //***
      // Action
      //   - Create instance of 'frmErrorTest'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmErrorTest()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    long mlngClickCount;
    decimal mdecFirst = 1;
    decimal mdecSecond = 0;
    decimal mdecThird;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmErrorTest_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Increment mlngClickCount
      //   - Show message with the number of clicks
      // Called by
      //   - User action (Clicking in the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mlngClickCount += 1;
      MessageBox.Show("Click count: " + mlngClickCount);
    }
    // frmErrorTest_Click(System.Object, System.EventArgs) Handles frmErrorTest.Click

    private void frmErrorTest_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Application tries
      //     - Show a message
      //     - Divide by 0
      //   - Error is catched
      //     - Show an error message
      //   - End with
      //     - Show an error message
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      
      try
      {
        MessageBox.Show("Preparing to divide by zero...");
        mdecThird = mdecFirst / mdecSecond;
      }
      catch (Exception theExeption)
      {
        MessageBox.Show("Error " + theExeption.Message);
      }
      finally
      {
        MessageBox.Show("Whew, that was a close one!");
      }

    }
    // frmErrorTest_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmErrorTest
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmErrorTest());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmErrorTest

}
// CopyPaste.Learning