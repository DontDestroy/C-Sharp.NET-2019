//***
// Action
//   - Implementation of a cpCounter
//   - There is a number
//   - You can increment, decrement and show the value
// Created
//   - CopyPaste � 20240305 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240305 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning;
using System;

namespace CopyPaste.Learning
{

  public class cpCounter
  {

    #region "Constructors / Destructors"

    public cpCounter()
      //***
      // Action
      //   - Empty constructor
      // Called by
      //   - modCounterTest.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240305 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240305 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpCounter()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mlngCounter = 0;

    #endregion

    #region "Properties"

    public int Counter
    {

      get
        //***
        // Action Get
        //   - Return the value of the counter
        // Called by
        //   - Object cpProgram.ShowObjectValue(cpCounter)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240305 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240305 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngCounter;
      }
      // int Counter (Get)

    }
    // int Counter

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Decrement()
      //***
      // Action
      //   - Subtract one from the counter
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240305 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240305 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mlngCounter -= 1;
    }
    // Decrement()
		
    public void Increment()
      //***
      // Action
      //   - Add one from the counter
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240305 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240305 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mlngCounter += 1;
    }
    // Increment()

    public int ShowCounter()
      //***
      // Action
      //   - Show the value of the counter
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - Object cpProgram.ShowObjectValue(cpCounter)
      // Created
      //   - CopyPaste � 20240305 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240305 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return Convert.ToInt32(cpProgram.ShowObjectValue(this));
    }
    // int ShowCounter()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCounter

}
// CopyPaste.Learning