﻿//***
// Action
//   - Definition of a clsButtonWithTextNotClickable
// Created
//   - CopyPaste – 20260805 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260805 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Web;
using System.Windows.Forms;

namespace CopyPaste.Toolkit.UserInterface
{

  public class cpPictureBoxWithText: cpTextImage
  {

    #region "Constructors / Destructors"

    public cpPictureBoxWithText(int intLeft, int intTop): base(intLeft, intTop)
    //***
    // Action
    //   - Set the Left and Top properties to the given values of the constructor
    // Called by
    //   - frmExample.frmExample_Load(System.Object, System.EventArgs) Handles this.Load
    // Calls
    //   - cpTextImage(int, int) 
    // Created
    //   - CopyPaste – 20260805 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260805 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Left = intLeft;
      Top = intTop;
    }
    // cpTextImage(int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"
    
    public override void DrawImage(int intImageWidth, int intImageHeight, Color clrImageFore, Color clrImageBack)
    //***
    // Action
    //   - Define a bitmap
    //   - Define a brush for the foreground and background
    //   - Define a drawing graphics
    //   - Define a pen
    //   - Define and initialize a new form
    //   - Initialize a new bitmap with a width and a height
    //   - Set the graphics based on the bitmap
    //   - Initialize a brush with the color white
    //   - Fill the rectangle of the graphics with white
    //   - Initialize a brush with the image back color
    //   - Initialize a brush with the default back color
    //   - Initialize a pen with a color black and width 1
    //   - Fill a rectangle with image back color
    //   - Fill a rectangle with default back color
    //   - Fill a rectangle with default back color
    //   - Draw two lines
    //   - Fill a pie
    //   - Draw an arc
    //   - Fill a pie
    //   - Draw an arc
    //   - Set the image with the bitmap
    //   - Dispose the form
    // Called by
    //   - frmExample_Load(System.Object, System.EventArgs) Handles MyBase.Load
    // Calls
    //   - Image(Bitmap) (Set)
    //   - Left() As Int32 (Get)
    //   - Top() As Int32 (Get)
    // Created
    //   - CopyPaste – 20260805 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260805 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Bitmap bitPicture;
      Brush theBrush;
      Brush theBackBrush;
      Graphics theGraphics;
      Pen theBlackPen;
      Form theForm = new Form();
      
      bitPicture = new Bitmap(intImageWidth, intImageHeight);
      theGraphics = Graphics.FromImage(bitPicture);
      theBrush = new SolidBrush(Color.White);
      theGraphics.FillRectangle(theBrush, Left, Top, intImageWidth, intImageHeight);
      theBrush = new SolidBrush(clrImageBack);
      theBackBrush = new SolidBrush(Form.DefaultBackColor);
      theBlackPen = new Pen(Color.Black, 1);
      
      theGraphics.FillRectangle(theBrush, Left + 10, Top, Left + intImageWidth - 20, Top + intImageHeight);
      theGraphics.FillRectangle(theBackBrush, Left, Top, 10, Top + intImageHeight);
      theGraphics.FillRectangle(theBackBrush, Left + intImageWidth - 10, Top, 10, Top + intImageHeight);
      theGraphics.DrawLine(theBlackPen, Left + 10, Top, Left + intImageWidth - 10, Top);
      theGraphics.DrawLine(theBlackPen, Left + 10, Top + intImageHeight - 1, Left + intImageWidth - 10, Top + intImageHeight - 1);
      theGraphics.FillPie(theBrush, Left, Top, Left + 20, Top + intImageHeight - 1, 90, 180);
      theGraphics.DrawArc(theBlackPen, Left, Top, Left + 20, Top + intImageHeight - 1, 90, 180);
      theGraphics.FillPie(theBrush, Left + intImageWidth - 21, Top, Left + 20, Top + intImageHeight - 1, 270, 180);
      theGraphics.DrawArc(theBlackPen, Left + intImageWidth - 21, Top, Left + 20, Top + intImageHeight - 1, 270, 180);
      base.Image = bitPicture;
      theForm.Dispose();
    }
    // DrawImage(int, int, Color, Color)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
		//#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPictureBoxWithText

}
// CopyPaste.Toolkit.UserInterface