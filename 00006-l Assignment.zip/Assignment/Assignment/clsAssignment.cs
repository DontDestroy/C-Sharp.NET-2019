//***
// Action
//   - Assignment
// Created
//   - CopyPaste � 20220111 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220111 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Assignment
{

  class cpAssignment
	{

    static void Main()
    //***
    // Action
    //   - Assign values to variable
    //   - Show calculation results at the console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - double System.Math.Pow(double, double)
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      double dblNumber;
      long lngNumber;

      lngNumber = 0;
      Console.WriteLine("Number = " + lngNumber);

      lngNumber += 10;
      Console.WriteLine("Number += 10 yields " + lngNumber);

      lngNumber -= 5;
      Console.WriteLine("Number -=5 yields " + lngNumber);
      
      lngNumber *= 3;
      Console.WriteLine("Number *= 3 yields " + lngNumber);
      
      dblNumber = lngNumber / 5;
      Console.WriteLine("Number /= 5 yields " + dblNumber);
      
      dblNumber = Math.Pow(dblNumber, 2);
      Console.WriteLine("Number ^= 2 yields " + dblNumber);
      
      Console.ReadLine();
    }
    // Main

  }
  // cpAssignment

}
// Assignment