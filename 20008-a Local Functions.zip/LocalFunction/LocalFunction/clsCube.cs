﻿//***
// Action
//   - Definition of a cpCube
// Created
//   - CopyPaste – 20251218 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251218 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpCube
  {

    #region "Constructors / Destructors"

    public cpCube(double dblSize)
    //***
    // Action
    //   - Basic constructor of cpCube with size parameter
    // Called by
    //   - cpProgram().Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251218 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251218 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Size = dblSize;
    }
    // cpCube()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public double Size { get; private set; }
    // cpLocalFunction().CalculateObjectVolume(System.Object)

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpCube

}
// CopyPaste.Learning