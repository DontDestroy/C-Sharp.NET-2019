//***
// Action
//   - Update a customer with validation
//   - Retrieved with a given key
// Created
//   - CopyPaste � 20050508 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20050508 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmCustomerValidationBetterTryout: ifrmCustomerTryout
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCustomerValidationBetterTryout));
      // 
      // cmdNew
      // 
      this.cmdNew.Enabled = true;
      this.cmdNew.Name = "cmdNew";
      this.cmdNew.Click += new System.EventHandler(this.cmdNew_Click);
      // 
      // cmdDelete
      // 
      this.cmdDelete.Enabled = true;
      this.cmdDelete.Name = "cmdDelete";
      this.cmdDelete.Click += new System.EventHandler(this.cmdDelete_Click);
      // 
      // cmdSave
      // 
      this.cmdSave.Enabled = true;
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // cmdRetrieve
      // 
      this.cmdRetrieve.Enabled = true;
      this.cmdRetrieve.Name = "cmdRetrieve";
      this.cmdRetrieve.Click += new System.EventHandler(this.cmdRetrieve_Click);
      // 
      // txtFax
      // 
      this.txtFax.Name = "txtFax";
      // 
      // txtPhone
      // 
      this.txtPhone.Name = "txtPhone";
      // 
      // txtRegion
      // 
      this.txtRegion.Name = "txtRegion";
      // 
      // txtCountry
      // 
      this.txtCountry.Name = "txtCountry";
      // 
      // txtZip
      // 
      this.txtZip.Name = "txtZip";
      // 
      // txtCity
      // 
      this.txtCity.Name = "txtCity";
      // 
      // txtAddress
      // 
      this.txtAddress.Name = "txtAddress";
      // 
      // txtContactTitle
      // 
      this.txtContactTitle.Name = "txtContactTitle";
      // 
      // txtIdCustomer
      // 
      this.txtIdCustomer.Name = "txtIdCustomer";
      // 
      // txtContactName
      // 
      this.txtContactName.Name = "txtContactName";
      // 
      // txtCompanyName
      // 
      this.txtCompanyName.Name = "txtCompanyName";
      // 
      // frmCustomerValidationBetter
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(688, 325);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmCustomerValidationBetter";

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmCustomerValidationBetterTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - ifrmCustomer.Dispose(bool)
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmCustomerValidationBetterTryout() : base()
      //***
      // Action
      //   - Create new instance of 'frmCustomerValidationBetterTryout'
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCustomerTryout()
      //   - cpCustomerTryout.Validation(bool) (Set)
      //   - ifrmCustomerTryout()
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
    }
    // frmCustomerValidationBetterTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void TextBoxChange(string strProperty, string strValue)
      //***
      // Action
      //   - Try to
      //     - Depending on the textbox (property)
      //       - Fill the corresponding property of the customer instance (linked to the form)
      //     - Fill the rich text box with the customer info (ToString())
      //   - When there is no cpCustomer instance
      //     - Do nothing
      //   - When other exception
      //     - Show exception message
      // Called by (thru inheritance)
      //   - txtAddress_TextChanged(System.Object, System.EventArgs) Handles txtAddress.TextChanged
      //   - txtCity_TextChanged(System.Object, System.EventArgs) Handles txtCity.TextChanged
      //   - txtCompanyName_TextChanged(System.Object, System.EventArgs) Handles txtCompanyName.TextChanged
      //   - txtContactName_TextChanged(System.Object, System.EventArgs) Handles txtContactName.TextChanged
      //   - txtContactTitle_TextChanged(System.Object, System.EventArgs) Handles txtContactTitle.TextChanged
      //   - txtCountry_TextChanged(System.Object, System.EventArgs) Handles txtCountry.TextChanged
      //   - txtFax_TextChanged(System.Object, System.EventArgs) Handles txtFax.TextChanged
      //   - txtPhone_TextChanged(System.Object, System.EventArgs) Handles txtPhone.TextChanged
      //   - txtRegion_TextChanged(System.Object, System.EventArgs) Handles txtRegion.TextChanged
      //   - txtZip_TextChanged(System.Object, System.EventArgs) Handles txtZip.TextChanged
      // Calls
      //   - cpCheckPhoneNumber cpCustomer.Fax (Get)
      //   - cpCheckPhoneNumber cpCustomer.Phone (Get)
      //   - cpCheckPhoneNumber.StringValue(string) (Set)
      //   - cpCustomer.Address(string) (Set)
      //   - cpCustomer.City(string) (Set)
      //   - cpCustomer.CompanyName(string) (Set)
      //   - cpCustomer.ContactName(string) (Set)
      //   - cpCustomer.ContactTitle(string) (Set)
      //   - cpCustomer.Country(string) (Set)
      //   - cpCustomer.Region(string) (Set)
      //   - cpCustomer.PostalCode(string) (Set)
      //   - string cpCustomer.ToString() 
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // TextBoxChange(string, string)

    #endregion

    #region "Controls"

    private void cmdDelete_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Delete the instance of cpCustomer
      //     - If successful
      //       - Show message that delete was successful
      //       - Set instance of cpCustomer to nothing
      //       - Clear the textboxes
      //     - If not
      //       - Show message that delete was unsuccessful
      //   - When exception occurs
      //     - Show exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool cpCustomerTryout.Delete() Implements cpiCustomerTryout.Delete
      //   - ifrmCustomerTryout.ClearAllTextBoxes()
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // mdDelete_Click(System.Object, System.EventArgs)

    private void cmdNew_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - If there is a value in the customer key
      //       - If there is a value in the customer name
      //         - Create a new instance of cpCustomer with key and name
      //       - If not
      //         - Show message that a customer name is obligatory
      //     - If not
      //       - Show message that a unique key is obligatory, ask to create one by the program
      //       - If yes
      //         - A default customer is created
      //       - If no
      //         - All textboxes are cleared
      //   - When exception occurs
      //     - Show exception message
      //     - All textboxes are cleared
      // Called by
      //   - User action (Clicking a button)
      //   - cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      // Calls
      //   - ifrmCustomerTryout.ClearAllTextBoxes()
      //   - cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      //   - cpCheckPhoneNumber cpCustomerTryout.Fax (Get)
      //   - cpCheckPhoneNumber cpCustomerTryout.Phone (Get)
      //   - cpCheckPhoneNumber.StringValue(string) (Set)
      //   - cpCustomerTryout(cpKeyCustomerTryout, string)
      //   - cpCustomerTryout.Address(string) (Set)
      //   - cpCustomerTryout.City(string) (Set)
      //   - cpCustomerTryout.ContactName(string) (Set)
      //   - cpCustomerTryout.ContactTitle(string) (Set)
      //   - cpCustomerTryout.Country(string) (Set)
      //   - cpCustomerTryout.PostalCode(string) (Set)
      //   - cpCustomerTryout.Region(string) (Set)
      //   - cpKeyCustomerTryout(string)
      //   - CustomerProperties()
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdNew_Click(System.Object, System.EventArgs)

    private void cmdRetrieve_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Create a new cpCustomer instance with a given key
      //     - Fill the textboxes with customer properties
      //   - When error occurs
      //     - Show exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpCustomerTryout(string)
      //   - cpCustomerTryout.Validation(bool) (Set)
      //   - ifrmCustomerTryout.CustomerProperties()
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdRetrieve_Click(System.Object, System.EventArgs)

    private void cmdSave_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to
      //     - Save the cpCustomer instance
      //     - If successfull
      //       - Show message
      //     - If not
      //       - Show message
      //   - When error occurs
      //     - Show exception message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - bool cpCustomerTryout.Save() Implements cpiCustomerTryout.Save
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void CustomerProperties()
      //***
      // Action
      //   - Fill all textboxes with the corresponding property
      // Called by
      //   - cmdNew_Click(System.Object, System.EventArgs) Handles cmdNew.Click
      //   - cmdRetrieve_Click(System.Object, System.EventArgs) Handles cmdRetrieve.Click
      // Calls
      //   - cpCheckPhoneNumber cpCustomerTryout.Fax (Get)
      //   - cpCheckPhoneNumber cpCustomerTryout.Phone (Get)
      //   - string cpCheckPhoneNumber.StringValue (Get)
      //   - string cpCustomerTryout.Address (Get)
      //   - string cpCustomerTryout.City (Get)
      //   - string cpCustomerTryout.CompanyName (Get)
      //   - string cpCustomerTryout.ContactName (Get)
      //   - string cpCustomerTryout.ContactTitle (Get)
      //   - string cpCustomerTryout.Countryc(Get)
      //   - string cpCustomerTryout.Region (Get)
      //   - string cpCustomerTryout.PostalCode (Get)
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // CustomerProperties()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmCustomerValidationBetterTryout
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmCustomerValidationBetterTryout()
      // Created
      //   - CopyPaste � 20050508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20050508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmCustomerValidationBetterTryout());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmCustomerValidationBetterTryout

}
// CopyPaste.Learning