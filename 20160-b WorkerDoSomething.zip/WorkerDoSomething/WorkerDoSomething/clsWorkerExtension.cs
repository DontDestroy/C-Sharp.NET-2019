﻿//***
// Action
//   - Extension of a cpWorker
// Created
//   - CopyPaste – 20260130 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260130 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public static class cpWorkerExtension
  {

    #region "Constructors / Destructors"

    static cpWorkerExtension()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260130 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpWorkerExtension()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void DoSomething(this cpWorker theWorker)
    //***
    // Action
    //   - Show a message that the Worker is doing something as extension
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260130 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - This is not callable, because it has the same signature as an existing method
    //***
    {
      string strMessage = "I am an extension method of the class cpWorker.";

      Console.WriteLine(strMessage);
    }
    // DoSomething(cpWorker)

    public static void DoSomething(this cpWorker theWorker, int intNumberOfTimes)
    //***
    // Action
    //   - Show a message that the Worker is doing something as extension a number of times
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260130 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260130 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intCounter;
      string strMessage = $"I am an extension method of the class cpWorker executed {intNumberOfTimes} times.";

      for (intCounter = 1; intCounter < intNumberOfTimes; intCounter++)
      {
        Console.WriteLine(strMessage);
      }
      // intCounter = intNumberOfTimes

      Console.WriteLine(strMessage);
    }
    // DoSomething(cpWorker)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpWorkerExtension

}
// CopyPaste.Learning