<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="wfrmCarLoan.aspx.vb" Inherits="WebCarLoan.CopyPaste.Learning.wfrmCarLoan" %>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
  <title>Car Loan Calculation</title>
  <meta content="Microsoft Visual Studio .NET 7.1" name="GENERATOR">
  <meta content="Visual Basic .NET 7.1" name="CODE_LANGUAGE">
  <meta content="JavaScript" name="vs_defaultClientScript">
  <meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
</head>
<body ms_positioning="GridLayout">
  <form id="wfrmCarLoan" method="post" runat="server">
    <p>
      <font size="6">Car loan calculation</font>
      <asp:TextBox ID="txtAmount" runat="server" Style="z-index: 101; left: 16px; position: absolute; top: 112px; width: 124px;" TabIndex="1"></asp:TextBox>
      <asp:TextBox ID="txtInterest" runat="server" Style="z-index: 102; left: 16px; position: absolute; top: 152px; width: 124px;" TabIndex="2"></asp:TextBox>
      <asp:TextBox ID="txtPayment" runat="server" Style="z-index: 103; left: 16px; position: absolute; top: 192px; width: 124px;" TabIndex="3"></asp:TextBox>
      <asp:Label ID="lblAmount" runat="server" Font-Size="X-Small" Style="z-index: 104; left: 184px; position: absolute; top: 112px" Width="136px">Borrowed amount</asp:Label>
      <asp:Label ID="lblInterest" runat="server" Font-Size="X-Small" Style="z-index: 105; left: 184px; position: absolute; top: 152px" Width="192px">Interest (for example: 0,09)</asp:Label>
      <asp:Label ID="lblPayment" runat="server" Font-Size="X-Small" Style="z-index: 106; left: 184px; position: absolute; top: 200px" Width="240px">Monthly payment for a period of 48 months</asp:Label>
      <asp:Button ID="cmdCalculate" runat="server" Style="z-index: 107; left: 16px; position: absolute; top: 240px" TabIndex="4" Text="Calculate!" Width="96px"/>
      <asp:HyperLink ID="hypHelpDutch" runat="server" Font-Size="X-Small" NavigateUrl="WebCarLoanHelpDutch.htm" Style="z-index: 108; left: 184px; position: absolute; top: 240px">Show help (in Dutch)</asp:HyperLink>
      <asp:HyperLink ID="hypHelpEnglish" runat="server" Font-Size="X-Small" NavigateUrl="WebCarLoanHelpEnglish.htm" Style="z-index: 109; left: 184px; position: absolute; top: 264px">Show help (in English)</asp:HyperLink>
    </p>
    <p>Enter information and click "Calculate!"</p>
  </form>
</body>
</html>
