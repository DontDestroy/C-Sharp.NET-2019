//***
// Action
//   - Demo the position of a screen
// Created
//   - CopyPaste � 20240227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240227 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPosition: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdMinimize;
    internal System.Windows.Forms.Button cmdNewForm;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPosition));
      this.cmdMinimize = new System.Windows.Forms.Button();
      this.cmdNewForm = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdMinimize
      // 
      this.cmdMinimize.Location = new System.Drawing.Point(174, 24);
      this.cmdMinimize.Name = "cmdMinimize";
      this.cmdMinimize.Size = new System.Drawing.Size(96, 40);
      this.cmdMinimize.TabIndex = 3;
      this.cmdMinimize.Text = "Minimize to &Taskbar";
      this.cmdMinimize.Click += new System.EventHandler(this.cmdMinimize_Click);
      // 
      // cmdNewForm
      // 
      this.cmdNewForm.Location = new System.Drawing.Point(22, 24);
      this.cmdNewForm.Name = "cmdNewForm";
      this.cmdNewForm.Size = new System.Drawing.Size(96, 40);
      this.cmdNewForm.TabIndex = 2;
      this.cmdNewForm.Text = "&Create Form";
      this.cmdNewForm.Click += new System.EventHandler(this.cmdNewForm_Click);
      // 
      // frmPosition
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdMinimize);
      this.Controls.Add(this.cmdNewForm);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Location = new System.Drawing.Point(100, 50);
      this.MaximizeBox = false;
      this.Name = "frmPosition";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Position";
      this.Load += new System.EventHandler(this.frmPosition_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPosition'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPosition()
      //***
      // Action
      //   - Create instance of 'frmPosition'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPosition()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdMinimize_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Minimize the current screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      WindowState = FormWindowState.Minimized;
    }
    // cmdMinimize_Click(System.Object, System.EventArgs) Handles cmdMinimize.Click

    private void cmdNewForm_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a new form
      //   - Define a rectangle (The screen position)
      //   - Set the title of the form
      //   - Set the border style of the form to a fixed dialog box
      //   - Set the startposition to manual
      //   - Set the position of the form to the rectangle
      //   - Show the form as a dialog box
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Form frmNew = new Form();
      Rectangle rctScreen = new Rectangle(200, 100, 300, 250);

      frmNew.Text = "New Form";
      frmNew.FormBorderStyle = FormBorderStyle.FixedDialog;
      frmNew.StartPosition = FormStartPosition.Manual;
      frmNew.DesktopBounds = rctScreen;
      frmNew.ShowDialog();    
    }
    // cmdNewForm_Click(System.Object, System.EventArgs) Handles cmdNewForm.Click

    
    private void frmPosition_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a size (used as maximum size)
      //   - Set the form to that maximum size
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Size theFormSize = new Size(400, 400);
 
      MaximumSize = theFormSize;
    }
    // frmPosition_Load(System.Object, System.EventArgs) Handles frmPosition.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPosition
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPosition());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPosition

}
// CopyPaste.Learning