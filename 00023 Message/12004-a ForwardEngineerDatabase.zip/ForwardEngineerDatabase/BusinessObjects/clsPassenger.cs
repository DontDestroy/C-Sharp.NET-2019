﻿//***
// Action
//   - Definition of a Passenger
// Created
//   - CopyPaste – 20230711 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230711 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CopyPaste.BusinessObjects
{

  [SerializableAttribute]
  public class Passenger : Person
  {

    #region "Constructors / Destructors"

    public Passenger()
    //***
    // Action
    //   - Constructor of Passenger
    //   - Creates an empty list of Booking
    // Called by
    //   - 
    // Calls
    //   - Booking(ICollection<Booking>) (Set)
    // Created
    //   - CopyPaste – 20230712 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230712 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      this.Booking = new List<Booking>();
    }
    // Passenger()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    // Missing Primary Key, see OnModelCreating for solution

    public virtual ICollection<Booking> Booking { get; set; }
    public virtual Nullable<DateTime> CustomerSince { get; set; }
    
    [StringLengthAttribute(1), MinLengthAttribute(1), RegularExpressionAttribute("[ABC]")]
    public virtual string Status{ get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // Passenger

}
// CopyPaste.BusinessObjects 