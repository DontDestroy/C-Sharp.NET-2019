﻿//***
// Action
//   - Demo of a the use of a cpLargeObject
// Created
//   - CopyPaste – 20260618 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260618 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Threading;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  public class cpUsingLargeObject
  {

    #region "Constructors / Destructors"

    public cpUsingLargeObject()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   -
    // Calls
    //   - ProcessAsync()
    //   - ProcessAsyncBetter()
    // Created
    //   - CopyPaste – 20260618 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260618 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      ProcessAsync();
      ProcessAsyncBetter();
    }
    // cpUsingLargeObject()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    async Task ProcessAsync()
    //***
    // Action
    //   - 
    // Called by
    //   - cpUsingLargeObject()
    // Calls
    //   - cpLargeObject()
    // Created
    //   - CopyPaste – 20260618 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260618 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      cpLargeObject theData = new cpLargeObject();
      await Task.Delay(1000);
      Console.WriteLine(theData.ToString());
    }
    // ProcessAsync()

    async Task ProcessAsyncBetter()
    //***
    // Action
    //   - 
    // Called by
    //   - cpUsingLargeObject()
    // Calls
    //   - cpLargeObject()
    // Created
    //   - CopyPaste – 20260618 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260618 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      using cpLargeObject theData = new cpLargeObject();
      await Task.Delay(1000);
      Console.WriteLine(theData.ToString());
    }
    // ProcessAsyncBetter()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpUsingLargeObject

}
// CopyPaste.Learning