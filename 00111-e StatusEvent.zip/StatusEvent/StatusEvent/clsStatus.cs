//***
// Action
//   - Implementation of cpStatus
//   - Empty constructor
//   - An event
//   - A method "TryThis", that can trigger the event in certain cases
// Created
//   - CopyPaste � 20240522 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240522 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Event
{

  public class cpStatus
  {

    #region "Constructors / Destructors"

    public cpStatus()
      //***
      // Action
      //   - Empty constructor
      // Called by
      //   - cpProgramStatusEventFirstUse.Main()
      //   - cpProgramStatusEventSecondUse.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpStatus()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public event cpAction DoSomething;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate void cpAction(string strMessage, ref bool blnCancel);
    // bool TryThis(string, string, int, int)

    #endregion

    #region "Sub / Function"

    public void TryThis(string strQuestion, string strMessage, int lngValue, int lngMaxValue)
      //***
      // Action
      //   - If lngValue is bigger than lngMaxValue
      //     - Execute the event DoSomething (you let the programmer decide what this action is)
      //     - If blnCancel
      //       - Show an error message
      //     - If Not
      //       - lngValue becomes lngMaxValue
      //   - If Not
      //     - Do nothing
      //   - If blnCancel
      //     - Do nothing
      //   - If Not
      //     - Show lngValue
      // Called by
      //   - cpProgramStatusEventFirstUse.Main()
      //   - cpProgramStatusEventSecondUse.Main()
      // Calls
      //   - cpProgramStatusEventFirstUse.UpdateRecord(String, �Boolean) Handles mcpTryout.DoSomething
      //   - cpProgramStatusEventSecondUse.CountDown(String, �Boolean) Handles mcpTryout.DoSomething
      //   - DoSomething(String, �Boolean)
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnCancel = false;

      if (lngValue > lngMaxValue)
      {

        if (DoSomething == null)
        {
          blnCancel = false;
        }
        else
          // DoSomething <> null
        {
          DoSomething(strQuestion, ref blnCancel);
        }
        // DoSomething == null

        if (blnCancel)
        {
          Console.WriteLine(strMessage);
        }
        else
          // Not blnCancel
        {
          lngValue = lngMaxValue;
        }
        // blnCancel

      }
      else
        // lngValue <= lngMaxValue
      {
      }
      // lngValue > lngMaxValue

      if (blnCancel)
      {
      }
      else
        // Not blnCancel
      {
        Console.WriteLine(lngValue);
      }
      // blnCancel

    }
    // TryThis(string, string, int, int)
  	
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpStatus

}
// CopyPaste.Learning.Event