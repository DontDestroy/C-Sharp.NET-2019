﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="wfrmLoanPaymentSchedule.aspx.vb" Inherits="Loan.CopyPaste.Learning.wfrmLoanPaymentSchedule" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>The Payment Schedule</title>
</head>
<body ms_positioning="GridLayout">
  <form id="frmLoadPaymentSchedule" method="post" runat="server">
    <asp:Label ID="lblTitle" Style="z-index: 101; position: absolute; top: 21px; left: 60px" runat="server"
      Font-Size="Larger">Loan Payment Schedule</asp:Label>
    <asp:Label ID="lblDetails" Style="z-index: 102; position: absolute; top: 50px; left: 60px; width: 862px;"
      runat="server"></asp:Label>
    <asp:DataGrid ID="dtgSchedule" Style="z-index: 103; position: absolute; top: 83px; left: 26px"
      runat="server" BorderColor="Tan" BorderWidth="1px" BackColor="LightGoldenrodYellow" CellPadding="5"
      GridLines="None" ForeColor="Black" CellSpacing="2">
      <SelectedItemStyle ForeColor="GhostWhite" BackColor="DarkSlateBlue"></SelectedItemStyle>
      <AlternatingItemStyle BackColor="PaleGoldenrod"></AlternatingItemStyle>
      <HeaderStyle Font-Bold="True" BackColor="Tan"></HeaderStyle>
      <FooterStyle BackColor="Tan"></FooterStyle>
      <PagerStyle HorizontalAlign="Center" ForeColor="DarkSlateBlue" BackColor="PaleGoldenrod"></PagerStyle>
    </asp:DataGrid>
  </form>
</body>
</html>
