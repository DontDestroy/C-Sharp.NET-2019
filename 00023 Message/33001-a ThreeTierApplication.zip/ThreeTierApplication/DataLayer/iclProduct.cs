﻿//***
// Action
//   - Interface Data Layer Product
// Created
//   - CopyPaste – 20220826 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220826 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Text;

namespace CopyPaste.BackEndApplication
{

  public interface IdtsProduct
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    IDictionary<int, string> AllProducts();
    // AllProducts()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // IdtsProduct

}
// CopyPaste.BackEndApplication