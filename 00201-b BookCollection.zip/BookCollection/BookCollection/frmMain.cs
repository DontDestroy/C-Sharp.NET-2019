//***
// Action
//   - Master window in the MDI application
//   - There is a File New, File Op�n, File Close, File Save As and File Exit menu
//   - Windows can be organised by icon, cascade, horizontal and vertical
//   - Selecting a child window changes the title of the master window
// Created
//   - CopyPaste � 20250707 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250707 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMain: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.OpenFileDialog dlgFileOpen;
    internal System.Windows.Forms.MenuItem mnuFileExit;
    internal System.Windows.Forms.MenuItem mnuFileNew;
    internal System.Windows.Forms.MenuItem mnuWindowTileVertically;
    internal System.Windows.Forms.MenuItem mnuFileClose;
    internal System.Windows.Forms.MenuItem mnuFileOpen;
    internal System.Windows.Forms.MenuItem mnuFileSaveAs;
    internal System.Windows.Forms.MenuItem mnuFile;
    internal System.Windows.Forms.MenuItem MenuItem12;
    internal System.Windows.Forms.MenuItem MenuItem13;
    internal System.Windows.Forms.MainMenu mnuMain;
    internal System.Windows.Forms.MenuItem mnuWindow;
    internal System.Windows.Forms.MenuItem mnuWindowTileHorizontally;
    internal System.Windows.Forms.MenuItem mnuWindowCascade;
    internal System.Windows.Forms.MenuItem mnuWindowArrangeIcons;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMain));
      this.dlgFileOpen = new System.Windows.Forms.OpenFileDialog();
      this.mnuFileExit = new System.Windows.Forms.MenuItem();
      this.mnuFileNew = new System.Windows.Forms.MenuItem();
      this.mnuWindowTileVertically = new System.Windows.Forms.MenuItem();
      this.mnuFileClose = new System.Windows.Forms.MenuItem();
      this.mnuFileOpen = new System.Windows.Forms.MenuItem();
      this.mnuFileSaveAs = new System.Windows.Forms.MenuItem();
      this.mnuFile = new System.Windows.Forms.MenuItem();
      this.MenuItem12 = new System.Windows.Forms.MenuItem();
      this.MenuItem13 = new System.Windows.Forms.MenuItem();
      this.mnuMain = new System.Windows.Forms.MainMenu();
      this.mnuWindow = new System.Windows.Forms.MenuItem();
      this.mnuWindowTileHorizontally = new System.Windows.Forms.MenuItem();
      this.mnuWindowCascade = new System.Windows.Forms.MenuItem();
      this.mnuWindowArrangeIcons = new System.Windows.Forms.MenuItem();
      // 
      // dlgFileOpen
      // 
      this.dlgFileOpen.Filter = "Books | *.bk";
      // 
      // mnuFileExit
      // 
      this.mnuFileExit.Index = 6;
      this.mnuFileExit.Text = "Exit";
      this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
      // 
      // mnuFileNew
      // 
      this.mnuFileNew.Index = 0;
      this.mnuFileNew.Text = "&New";
      this.mnuFileNew.Click += new System.EventHandler(this.mnuFileNew_Click);
      // 
      // mnuWindowTileVertically
      // 
      this.mnuWindowTileVertically.Index = 0;
      this.mnuWindowTileVertically.Text = "Tile &Vertically";
      this.mnuWindowTileVertically.Click += new System.EventHandler(this.mnuWindowTileVertically_Click);
      // 
      // mnuFileClose
      // 
      this.mnuFileClose.Index = 2;
      this.mnuFileClose.Text = "&Close";
      this.mnuFileClose.Click += new System.EventHandler(this.mnuFileClose_Click);
      // 
      // mnuFileOpen
      // 
      this.mnuFileOpen.Index = 1;
      this.mnuFileOpen.Text = "&Open";
      this.mnuFileOpen.Click += new System.EventHandler(this.mnuFileOpen_Click);
      // 
      // mnuFileSaveAs
      // 
      this.mnuFileSaveAs.Index = 4;
      this.mnuFileSaveAs.Text = "Save &As ...";
      this.mnuFileSaveAs.Click += new System.EventHandler(this.mnuFileSaveAs_Click);
      // 
      // mnuFile
      // 
      this.mnuFile.Index = 0;
      this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFileNew,
                                                                            this.mnuFileOpen,
                                                                            this.mnuFileClose,
                                                                            this.MenuItem12,
                                                                            this.mnuFileSaveAs,
                                                                            this.MenuItem13,
                                                                            this.mnuFileExit});
      this.mnuFile.Text = "&File";
      // 
      // MenuItem12
      // 
      this.MenuItem12.Index = 3;
      this.MenuItem12.Text = "-";
      // 
      // MenuItem13
      // 
      this.MenuItem13.Index = 5;
      this.MenuItem13.Text = "-";
      // 
      // mnuMain
      // 
      this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFile,
                                                                            this.mnuWindow});
      // 
      // mnuWindow
      // 
      this.mnuWindow.Enabled = false;
      this.mnuWindow.Index = 1;
      this.mnuWindow.MdiList = true;
      this.mnuWindow.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.mnuWindowTileVertically,
                                                                              this.mnuWindowTileHorizontally,
                                                                              this.mnuWindowCascade,
                                                                              this.mnuWindowArrangeIcons});
      this.mnuWindow.Text = "&Window";
      // 
      // mnuWindowTileHorizontally
      // 
      this.mnuWindowTileHorizontally.Index = 1;
      this.mnuWindowTileHorizontally.Text = "Tile &Horizontally";
      this.mnuWindowTileHorizontally.Click += new System.EventHandler(this.mnuWindowTileHorizontally_Click);
      // 
      // mnuWindowCascade
      // 
      this.mnuWindowCascade.Index = 2;
      this.mnuWindowCascade.Text = "&Cascade";
      this.mnuWindowCascade.Click += new System.EventHandler(this.mnuWindowCascade_Click);
      // 
      // mnuWindowArrangeIcons
      // 
      this.mnuWindowArrangeIcons.Index = 3;
      this.mnuWindowArrangeIcons.Text = "&Arrange Icons";
      this.mnuWindowArrangeIcons.Click += new System.EventHandler(this.mnuWindowArrangeIcons_Click);
      // 
      // frmMain
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.IsMdiContainer = true;
      this.Menu = this.mnuMain;
      this.Name = "frmMain";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Book Collection";
      this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
      this.Closing += new System.ComponentModel.CancelEventHandler(this.frmMain_Closing);
      this.MdiChildActivate += new System.EventHandler(this.frmMain_MdiChildActivate);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMain'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMain()
      //***
      // Action
      //   - Create instance of 'frmMain'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMain()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
        
    private void frmMain_Closing(System.Object theSender, System.ComponentModel.CancelEventArgs theCancelEventArguments)
      //***
      // Action
      //   - Define a frmBook
      //   - Loop thru all the childern (childs of main form)
      //     - If not saved since last backup
      //       - Save the child form
      //     - If not
      //       - Do nothing
      //     - Close the child
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - bool frmBook.Archive (Get)
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      
      foreach (frmBook frmChild in MdiChildren)
      {

        if (frmChild.Archive)
        {
          frmChild.Save(frmChild);
        }
        else
          // Not frmChild.Archive
        {
        }
        // frmChild.Archive

        frmChild.Close();
      }
      // in MdiChildren
    
    }
    // frmMain_Closing(System.Object, System.ComponentModel.CancelEventArgs) Handles this.Closing

    private void frmMain_MdiChildActivate(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there is a child window
      //     - Menu Windows is available
      //     - The active child becomes a frmBook
      //     - Change the title of the child window
      //     - Title of master window is changed into title of child window
      //   - If not
      //     - Define a frmBook
      //     - Menu(Windows Is Not available)
      //     - Title of master window is changed into default title
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - frmBook.ChangeTitle()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (ActiveMdiChild == null)
      {
        mnuWindow.Enabled = false;
        this.Text = "Book Collection";
      }
      else
        // ActiveMdiChild <> null
      {
        frmBook frmChild;

        mnuWindow.Enabled = true;
        frmChild = (frmBook)ActiveMdiChild;
        frmChild.ChangeTitle();
      }
      // ActiveMdiChild = null
    
    }
    // frmMain_MdiChildActivate(System.Object, System.EventArgs) Handles this.MdiChildActivate

    private void mnuFileClose_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there is a child window
      //     - The active child is closed
      //   - If not
      //     - Define a frmBook
      //     - Menu(Windows Is Not available)
      //     - Title of master window is changed into default title
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (ActiveMdiChild == null) 
      {
      }
      else
        // ActiveMdiChild <> null
      {
        ActiveMdiChild.Close();
      }
      // ActiveMdiChild = null
    
    }
    // mnuFileClose_Click(System.Object, System.EventArgs) Handles mnuFileClose.Click

    private void mnuFileExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Close application
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // mnuFileExit_Click(System.Object, System.EventArgs) Handles mnuFileExit.Click

    private void mnuFileNew_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new child window
      //   - The master window becomes the parent of the child window
      //   - Show the child window
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - NewBook()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      NewBook();
    }
    // mnuFileNew_Click(System.Object, System.EventArgs) Handles mnuFileNew.Click

    private void mnuFileOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new child window
      //   - The master window becomes the parent of the child window
      //   - Read a text file to get some information
      //   - Show the child window
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - Open()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Open();
    }
    // mnuFileOpen_Click(System.Object, System.EventArgs) Handles mnuFileOpen.Click

    private void mnuFileSaveAs_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there is a child window
      //     - Define a frmBook
      //     - Cast the active child into a frmBook
      //     - Save the content of the active child
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - frmBook.Save()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (ActiveMdiChild == null)
      {
      }
      else
        // ActiveMdiChild <> null
      {
        frmBook frmChild;

        frmChild = (frmBook)ActiveMdiChild;
        frmChild.Save(frmChild);
      }
      // ActiveMdiChild = null
   
    }
    // mnuFileSaveAs_Click(System.Object, System.EventArgs) Handles mnuFileSaveAs.Click

    private void mnuWindowArrangeIcons_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Arrange all the child windows that are icons at the bottom of the master window
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      LayoutMdi(MdiLayout.ArrangeIcons);
    }
    // mnuWindowArrangeIcons_Click(System.Object, System.EventArgs) Handles mnuWindowArrangeIcons.Click

    private void mnuWindowCascade_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Arrange all the child windows that are not icons in cascasde in the master window
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      LayoutMdi(MdiLayout.Cascade);
    }
    // mnuWindowCascade_Click(System.Object, System.EventArgs) Handles mnuWindowCascade.Click

    private void mnuWindowTileHorizontally_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Arrange all the child windows that are not icons in horizontal view in the master window
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      LayoutMdi(MdiLayout.TileHorizontal);
    }
    // mnuWindowTileHorizontally_Click(System.Object, System.EventArgs) Handles mnuWindowTileHorizontally.Click

    private void mnuWindowTileVertically_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Arrange all the child windows that are not icons in horizontal view in the master window
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      LayoutMdi(MdiLayout.TileVertical);    
    }
    // mnuWindowTileVertically_Click(System.Object, System.EventArgs) Handles mnuWindowTileVertically.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMain
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmMain()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMain());
    }
    // Main() 
    
    public void NewBook()
      //***
      // Action
      //   - Create a new child window (frmBook)
      //   - The master window becomes the parent of the child window
      //   - Show the child window
      //   - Change the title
      // Called by
      //   - mnuFileNew_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles mnuFileNew.Click
      //   - User action (Clicking a menu item)
      // Calls
      //   - frmBook()
      //   - frmBook.ChangeTitle()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmBook frmNewBook = new frmBook();

      frmNewBook.MdiParent = this;
      frmNewBook.Archive = false;
      frmNewBook.Show();
      frmNewBook.ChangeTitle();
    }
    // NewBook()

    public void Open()
      //***
      // Action
      //   - Show file open dialog
      //   - If OK button (save) is clicked
      //     - A streamreader is created with the chosen filename
      //     - The first line is read
      //     - From the first line, the author text, a dot comma, and the title text are found
      //     - The rest of the file is read as the description text of the book
      //     - The form is marked as saved
      //     - The form is shown
      //     - The form title is changed
      //     - The streamreader is closed
      //   - If not
      //     - Do nothing
      // Called by
      //   - mnuFileOpen_Click(System.Object, System.EventArgs) Handles mnuFileOpen.Click
      //   - User action (Clicking a menu item)
      // Calls
      //   - frmBook()
      //   - frmBook.ChangeTitle()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - We assume that there is no ; in the authors name
      //   - The NewBook method could be used here
      //***
    {

      if (dlgFileOpen.ShowDialog() == DialogResult.OK)
      {
        frmBook frmChild = new frmBook();
        StreamReader theReader = new StreamReader(dlgFileOpen.OpenFile());
        string strLine = theReader.ReadLine();
        int lngPosition = strLine.IndexOf(';');
            
        frmChild.MdiParent = this;
        frmChild.txtAuthor.Text = strLine.Substring(0, lngPosition);
        frmChild.txtTitle.Text = strLine.Substring(lngPosition + 1);
        strLine = theReader.ReadToEnd();
        frmChild.txtDescription.Text = strLine;
        frmChild.Archive = true;
        frmChild.Show();
        frmChild.ChangeTitle();
        theReader.Close();
      }
      else
        // dlgFileOpen.ShowDialog() <> DialogResult.OK
      {
      }
      // dlgFileOpen.ShowDialog() = DialogResult.OK

    }
    // Open()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMain

}
// CopyPaste.Learning