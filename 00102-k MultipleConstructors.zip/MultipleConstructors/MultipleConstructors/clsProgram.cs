//***
// Action
//   - Testroutine of the cpBookDetails
// Created
//   - CopyPaste � 20230420 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230420 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Define three new cpBookDetail3 using different constructors
    //   - Show the information on the screen of the three books
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpBookDetails(string, double)
    //   - cpBookDetails(string, string, string, double)
    //   - cpBookDetails(string, string, string, double, long, string)
    //   - cpBookDetails.ShowInfo()
    // Created
    //   - CopyPaste � 20230420 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230420 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpBookDetails theBookCSharp = new cpBookDetails("C# Programming Tips & Techniques", "Wright", "McGraw-Hill/Osborne", 49.99);
      cpBookDetails theBookPalm = new cpBookDetails("Instant Palm OS Applications", 49.99);
      cpBookDetails theBookVB = new cpBookDetails("VB.Net Programming Tips & Techniques", "Jamsa", "McGraw-Hill/Osborne", 49.99, 18, "April 2002");

      theBookCSharp.ShowInfo();
      Console.WriteLine();
      theBookPalm.ShowInfo();
      Console.WriteLine();
      theBookVB.ShowInfo();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// CopyPaste.Learning