﻿//***
// Action
//   - Connect to a SQL Server
//     - cpNorthWindScript2019
//   - Create a Data Set
//   - Create a Table Adapter
//   - Create a Binding Source
//   - Show information on the screen
//   - Change the current position (record)
// Created
//   - CopyPaste – 20240613 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240613 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning.Data
{

  public partial class frmADOWizard : Form
  {

    #region "Constructors / Destructors"

    public frmADOWizard()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Starting the form)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20240613 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20240613 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      InitializeComponent();
    }
    // frmADOWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdFirst_Click(System.Object theSender, EventArgs theEventArguments)
    //***
    // Action
    //   - Go to the first position in a table in the data set
    //   - Show record information
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20240613 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20240613 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      bdsrcCategory.Position = 0;
      Count();
    }
    // cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click

    private void cmdLast_Click(System.Object theSender, EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the last position in a table in the data set
      //   - Show record information
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - Count()
      // Created
      //   - CopyPaste – 20240613 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20240613 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcCategory.Position = tbaCategory.GetData().Count - 1;
      Count();
    }
    // cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click

    private void cmdLoad_Click(System.Object theSender, EventArgs theEventArguments)
      //***
      // Action
      //   - Clear the data set
      //   - Fill the data set using a data adapter
      //   - Show record information
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - Count()
      // Created
      //   - CopyPaste – 20240613 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20240613 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsCategory.Clear();
      tbaCategory.Fill(dsCategory.tblCPCategory);
      Count();
    }
    //  cmdLoad_Click(System.Object, System.EventArgs) Handles cmdLoad.Click

    private void cmdNext_Click(System.Object theSender, EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the next position in a table in the data set
      //   - Show record information
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - Count()
      // Created
      //   - CopyPaste – 20240613 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20240613 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcCategory.Position += 1;
      Count();
    }
    // cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click

    private void cmdPrevious_Click(System.Object theSender, EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the previous position in a table in the data set
      //   - Show record information
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - Count()
      // Created
      //   - CopyPaste – 20240613 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20240613 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      bdsrcCategory.Position -= 1;
      Count();
    }
    // cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void Count()
      //***
      // Action
      //   - Count the number of records that are in the dataset in a specific table
      //   - The position is zero based, so add 1
      //   - Show the information on the current position
      // Called by
      //   - cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click
      //   - cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click
      //   - cmdLoad_Click(System.Object, System.EventArgs) Handles cmdLoad.Click
      //   - cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click
      //   - cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20240613 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20240613 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngCurrent;
      int lngRecordCount;

      lngRecordCount = tbaCategory.GetData().Count;
      lngCurrent = bdsrcCategory.Position + 1;
      lblCount.Text = "Record " + lngCurrent.ToString() + " of " + lngRecordCount.ToString();
    }
    // Count()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmADOWizard

}
// CopyPaste.Learning.Data