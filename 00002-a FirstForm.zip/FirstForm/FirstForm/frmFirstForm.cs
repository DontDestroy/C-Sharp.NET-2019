//***
// Action
//   - Explanation of the code in this module or class
// Created
//   - Organisation � 20211013 � Initials of programmer
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - Organisation � 20211013 � Initials of programmer
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Drawing;
using System.Windows.Forms;

namespace FirstForm
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmFirstForm : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmFirstForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFirstForm));
      // 
      // frmFirstForm
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(424, 273);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFirstForm";
      this.Text = "The First Form in C# .NET";

    }
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmFirstForm());
		}
	}
}
