﻿//***
// Action
//   - Having DataViews in database actions
// Created
//   - CopyPaste – 20210818 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210818 – VVDW
// Proposal (To Do)
//   -
//***

namespace Editing
{

  partial class frmEditing
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdFill;
    internal System.Windows.Forms.Button cmdCommand;
    internal System.Windows.Forms.Button cmdDefer;
    internal System.Windows.Forms.Button cmdEdit;
    internal System.Windows.Forms.Button cmdDelete;
    internal System.Windows.Forms.Button cmdUpdate;
    internal System.Windows.Forms.TextBox txtOriginalKey;
    internal System.Windows.Forms.Button cmdAccept;
    internal System.Windows.Forms.TextBox txtCurrentFirstName;
    internal System.Windows.Forms.TextBox txtCurrentKey;
    public System.Windows.Forms.RadioButton optUnchanged;
    internal System.Windows.Forms.GroupBox grpRowStatus;
    internal System.Windows.Forms.RadioButton optChanged;
    internal System.Windows.Forms.RadioButton optNew;
    internal System.Windows.Forms.RadioButton optDeleted;
    internal System.Windows.Forms.Button cmdReject;
    internal System.Windows.Forms.Button cmdAdd;
    internal System.Windows.Forms.Label lblLastName;
    internal System.Windows.Forms.Label lblIdEmployee;
    internal System.Windows.Forms.Button cmdSave;
    internal System.Windows.Forms.TextBox txtPosition;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Label lblFirstName;
    internal System.Windows.Forms.TextBox txtOriginalLastName;
    internal System.Windows.Forms.Button cmdLast;
    internal System.Windows.Forms.TextBox txtOriginalFirstName;
    internal System.Windows.Forms.Label lblOriginal;
    internal System.Windows.Forms.Button cmdPrevious;
    internal System.Windows.Forms.TextBox txtEmployeeKey;
    internal System.Windows.Forms.Label lblCurrent;
    internal System.Windows.Forms.TextBox txtLastName;
    internal System.Windows.Forms.GroupBox panRowVersions;
    internal System.Windows.Forms.TextBox txtCurrentLastName;
    internal System.Windows.Forms.TextBox txtFirstName;
    internal System.Windows.Forms.Button cmdFirst;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwindScript;
    internal System.Data.SqlClient.SqlDataAdapter dtaEmployee;
    internal System.Data.SqlClient.SqlCommand cmmDeleteEmployee;
    internal System.Data.SqlClient.SqlCommand cmmInsertEmployee;
    internal System.Data.SqlClient.SqlCommand cmmSelectEmployee;
    internal System.Data.SqlClient.SqlCommand cmmUpdateEmployee;
    private Editing.dsEmployee dsEmployee;
    private System.ComponentModel.IContainer components = null;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEditing));
      this.cmdFill = new System.Windows.Forms.Button();
      this.cmdCommand = new System.Windows.Forms.Button();
      this.cmdDefer = new System.Windows.Forms.Button();
      this.cmdEdit = new System.Windows.Forms.Button();
      this.cmdDelete = new System.Windows.Forms.Button();
      this.cmdUpdate = new System.Windows.Forms.Button();
      this.txtOriginalKey = new System.Windows.Forms.TextBox();
      this.cmdAccept = new System.Windows.Forms.Button();
      this.txtCurrentFirstName = new System.Windows.Forms.TextBox();
      this.txtCurrentKey = new System.Windows.Forms.TextBox();
      this.optUnchanged = new System.Windows.Forms.RadioButton();
      this.grpRowStatus = new System.Windows.Forms.GroupBox();
      this.optChanged = new System.Windows.Forms.RadioButton();
      this.optNew = new System.Windows.Forms.RadioButton();
      this.optDeleted = new System.Windows.Forms.RadioButton();
      this.cmdReject = new System.Windows.Forms.Button();
      this.cmdAdd = new System.Windows.Forms.Button();
      this.lblLastName = new System.Windows.Forms.Label();
      this.lblIdEmployee = new System.Windows.Forms.Label();
      this.cmdSave = new System.Windows.Forms.Button();
      this.txtPosition = new System.Windows.Forms.TextBox();
      this.cmdNext = new System.Windows.Forms.Button();
      this.lblFirstName = new System.Windows.Forms.Label();
      this.txtOriginalLastName = new System.Windows.Forms.TextBox();
      this.cmdLast = new System.Windows.Forms.Button();
      this.txtOriginalFirstName = new System.Windows.Forms.TextBox();
      this.lblOriginal = new System.Windows.Forms.Label();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.txtEmployeeKey = new System.Windows.Forms.TextBox();
      this.dsEmployee = new Editing.dsEmployee();
      this.lblCurrent = new System.Windows.Forms.Label();
      this.txtLastName = new System.Windows.Forms.TextBox();
      this.panRowVersions = new System.Windows.Forms.GroupBox();
      this.txtCurrentLastName = new System.Windows.Forms.TextBox();
      this.txtFirstName = new System.Windows.Forms.TextBox();
      this.cmdFirst = new System.Windows.Forms.Button();
      this.cnncpNorthwindScript = new System.Data.SqlClient.SqlConnection();
      this.dtaEmployee = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmDeleteEmployee = new System.Data.SqlClient.SqlCommand();
      this.cmmInsertEmployee = new System.Data.SqlClient.SqlCommand();
      this.cmmSelectEmployee = new System.Data.SqlClient.SqlCommand();
      this.cmmUpdateEmployee = new System.Data.SqlClient.SqlCommand();
      this.grpRowStatus.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dsEmployee)).BeginInit();
      this.panRowVersions.SuspendLayout();
      this.SuspendLayout();
      // 
      // cmdFill
      // 
      this.cmdFill.Location = new System.Drawing.Point(360, 215);
      this.cmdFill.Name = "cmdFill";
      this.cmdFill.Size = new System.Drawing.Size(75, 23);
      this.cmdFill.TabIndex = 41;
      this.cmdFill.Text = "Fill";
      this.cmdFill.Click += new System.EventHandler(this.cmdFill_Click);
      // 
      // cmdCommand
      // 
      this.cmdCommand.Location = new System.Drawing.Point(360, 185);
      this.cmdCommand.Name = "cmdCommand";
      this.cmdCommand.Size = new System.Drawing.Size(75, 23);
      this.cmdCommand.TabIndex = 40;
      this.cmdCommand.Text = "Command";
      this.cmdCommand.Click += new System.EventHandler(this.cmdCommand_Click);
      // 
      // cmdDefer
      // 
      this.cmdDefer.Location = new System.Drawing.Point(360, 125);
      this.cmdDefer.Name = "cmdDefer";
      this.cmdDefer.Size = new System.Drawing.Size(75, 23);
      this.cmdDefer.TabIndex = 38;
      this.cmdDefer.Text = "Defer";
      this.cmdDefer.Click += new System.EventHandler(this.cmdDefer_Click);
      // 
      // cmdEdit
      // 
      this.cmdEdit.Location = new System.Drawing.Point(360, 95);
      this.cmdEdit.Name = "cmdEdit";
      this.cmdEdit.Size = new System.Drawing.Size(75, 23);
      this.cmdEdit.TabIndex = 37;
      this.cmdEdit.Text = "Edit";
      this.cmdEdit.Click += new System.EventHandler(this.cmdEdit_Click);
      // 
      // cmdDelete
      // 
      this.cmdDelete.Location = new System.Drawing.Point(360, 65);
      this.cmdDelete.Name = "cmdDelete";
      this.cmdDelete.Size = new System.Drawing.Size(75, 23);
      this.cmdDelete.TabIndex = 36;
      this.cmdDelete.Text = "Delete";
      this.cmdDelete.Click += new System.EventHandler(this.cmdDelete_Click);
      // 
      // cmdUpdate
      // 
      this.cmdUpdate.Location = new System.Drawing.Point(360, 155);
      this.cmdUpdate.Name = "cmdUpdate";
      this.cmdUpdate.Size = new System.Drawing.Size(75, 23);
      this.cmdUpdate.TabIndex = 39;
      this.cmdUpdate.Text = "Update";
      this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
      // 
      // txtOriginalKey
      // 
      this.txtOriginalKey.Location = new System.Drawing.Point(64, 24);
      this.txtOriginalKey.Name = "txtOriginalKey";
      this.txtOriginalKey.ReadOnly = true;
      this.txtOriginalKey.Size = new System.Drawing.Size(32, 20);
      this.txtOriginalKey.TabIndex = 1;
      this.txtOriginalKey.TabStop = false;
      this.txtOriginalKey.Text = "Key";
      // 
      // cmdAccept
      // 
      this.cmdAccept.Location = new System.Drawing.Point(360, 245);
      this.cmdAccept.Name = "cmdAccept";
      this.cmdAccept.Size = new System.Drawing.Size(75, 23);
      this.cmdAccept.TabIndex = 42;
      this.cmdAccept.Text = "Accept";
      this.cmdAccept.Click += new System.EventHandler(this.cmdAccept_Click);
      // 
      // txtCurrentFirstName
      // 
      this.txtCurrentFirstName.Location = new System.Drawing.Point(104, 48);
      this.txtCurrentFirstName.Name = "txtCurrentFirstName";
      this.txtCurrentFirstName.ReadOnly = true;
      this.txtCurrentFirstName.Size = new System.Drawing.Size(100, 20);
      this.txtCurrentFirstName.TabIndex = 6;
      this.txtCurrentFirstName.TabStop = false;
      this.txtCurrentFirstName.Text = "Current First Name";
      // 
      // txtCurrentKey
      // 
      this.txtCurrentKey.Location = new System.Drawing.Point(64, 48);
      this.txtCurrentKey.Name = "txtCurrentKey";
      this.txtCurrentKey.ReadOnly = true;
      this.txtCurrentKey.Size = new System.Drawing.Size(32, 20);
      this.txtCurrentKey.TabIndex = 5;
      this.txtCurrentKey.TabStop = false;
      this.txtCurrentKey.Text = "Key";
      // 
      // optUnchanged
      // 
      this.optUnchanged.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.optUnchanged.Location = new System.Drawing.Point(12, 24);
      this.optUnchanged.Name = "optUnchanged";
      this.optUnchanged.Size = new System.Drawing.Size(85, 16);
      this.optUnchanged.TabIndex = 0;
      this.optUnchanged.Text = "Unchanged";
      // 
      // grpRowStatus
      // 
      this.grpRowStatus.Controls.Add(this.optChanged);
      this.grpRowStatus.Controls.Add(this.optUnchanged);
      this.grpRowStatus.Controls.Add(this.optNew);
      this.grpRowStatus.Controls.Add(this.optDeleted);
      this.grpRowStatus.Enabled = false;
      this.grpRowStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.grpRowStatus.Location = new System.Drawing.Point(16, 80);
      this.grpRowStatus.Name = "grpRowStatus";
      this.grpRowStatus.Size = new System.Drawing.Size(306, 48);
      this.grpRowStatus.TabIndex = 8;
      this.grpRowStatus.TabStop = false;
      this.grpRowStatus.Text = "RowStatus";
      // 
      // optChanged
      // 
      this.optChanged.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.optChanged.Location = new System.Drawing.Point(226, 24);
      this.optChanged.Name = "optChanged";
      this.optChanged.Size = new System.Drawing.Size(72, 16);
      this.optChanged.TabIndex = 3;
      this.optChanged.Text = "Modified";
      // 
      // optNew
      // 
      this.optNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.optNew.Location = new System.Drawing.Point(101, 24);
      this.optNew.Name = "optNew";
      this.optNew.Size = new System.Drawing.Size(48, 16);
      this.optNew.TabIndex = 1;
      this.optNew.Text = "New";
      // 
      // optDeleted
      // 
      this.optDeleted.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.optDeleted.Location = new System.Drawing.Point(156, 24);
      this.optDeleted.Name = "optDeleted";
      this.optDeleted.Size = new System.Drawing.Size(76, 16);
      this.optDeleted.TabIndex = 2;
      this.optDeleted.Text = "Deleted";
      // 
      // cmdReject
      // 
      this.cmdReject.Location = new System.Drawing.Point(360, 275);
      this.cmdReject.Name = "cmdReject";
      this.cmdReject.Size = new System.Drawing.Size(75, 23);
      this.cmdReject.TabIndex = 43;
      this.cmdReject.Text = "Reject";
      this.cmdReject.Click += new System.EventHandler(this.cmdReject_Click);
      // 
      // cmdAdd
      // 
      this.cmdAdd.Location = new System.Drawing.Point(360, 35);
      this.cmdAdd.Name = "cmdAdd";
      this.cmdAdd.Size = new System.Drawing.Size(75, 23);
      this.cmdAdd.TabIndex = 35;
      this.cmdAdd.Text = "Add";
      this.cmdAdd.Click += new System.EventHandler(this.cmdAdd_Click);
      // 
      // lblLastName
      // 
      this.lblLastName.AutoSize = true;
      this.lblLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblLastName.Location = new System.Drawing.Point(8, 83);
      this.lblLastName.Name = "lblLastName";
      this.lblLastName.Size = new System.Drawing.Size(71, 13);
      this.lblLastName.TabIndex = 26;
      this.lblLastName.Text = "Last Name:";
      // 
      // lblIdEmployee
      // 
      this.lblIdEmployee.AutoSize = true;
      this.lblIdEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblIdEmployee.Location = new System.Drawing.Point(8, 19);
      this.lblIdEmployee.Name = "lblIdEmployee";
      this.lblIdEmployee.Size = new System.Drawing.Size(89, 13);
      this.lblIdEmployee.TabIndex = 22;
      this.lblIdEmployee.Text = "Employee key:";
      // 
      // cmdSave
      // 
      this.cmdSave.Location = new System.Drawing.Point(360, 5);
      this.cmdSave.Name = "cmdSave";
      this.cmdSave.Size = new System.Drawing.Size(75, 23);
      this.cmdSave.TabIndex = 34;
      this.cmdSave.Text = "Save";
      this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
      // 
      // txtPosition
      // 
      this.txtPosition.Location = new System.Drawing.Point(88, 272);
      this.txtPosition.Name = "txtPosition";
      this.txtPosition.Size = new System.Drawing.Size(168, 20);
      this.txtPosition.TabIndex = 31;
      this.txtPosition.TabStop = false;
      this.txtPosition.Text = "Position";
      // 
      // cmdNext
      // 
      this.cmdNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmdNext.Location = new System.Drawing.Point(264, 271);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(32, 23);
      this.cmdNext.TabIndex = 32;
      this.cmdNext.TabStop = false;
      this.cmdNext.Text = ">";
      this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
      // 
      // lblFirstName
      // 
      this.lblFirstName.AutoSize = true;
      this.lblFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblFirstName.Location = new System.Drawing.Point(8, 51);
      this.lblFirstName.Name = "lblFirstName";
      this.lblFirstName.Size = new System.Drawing.Size(71, 13);
      this.lblFirstName.TabIndex = 24;
      this.lblFirstName.Text = "First Name:";
      // 
      // txtOriginalLastName
      // 
      this.txtOriginalLastName.Location = new System.Drawing.Point(208, 24);
      this.txtOriginalLastName.Name = "txtOriginalLastName";
      this.txtOriginalLastName.ReadOnly = true;
      this.txtOriginalLastName.Size = new System.Drawing.Size(100, 20);
      this.txtOriginalLastName.TabIndex = 3;
      this.txtOriginalLastName.TabStop = false;
      this.txtOriginalLastName.Text = "Original Last Name";
      // 
      // cmdLast
      // 
      this.cmdLast.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmdLast.Location = new System.Drawing.Point(304, 271);
      this.cmdLast.Name = "cmdLast";
      this.cmdLast.Size = new System.Drawing.Size(32, 23);
      this.cmdLast.TabIndex = 33;
      this.cmdLast.TabStop = false;
      this.cmdLast.Text = ">>";
      this.cmdLast.Click += new System.EventHandler(this.cmdLast_Click);
      // 
      // txtOriginalFirstName
      // 
      this.txtOriginalFirstName.Location = new System.Drawing.Point(104, 24);
      this.txtOriginalFirstName.Name = "txtOriginalFirstName";
      this.txtOriginalFirstName.ReadOnly = true;
      this.txtOriginalFirstName.Size = new System.Drawing.Size(100, 20);
      this.txtOriginalFirstName.TabIndex = 2;
      this.txtOriginalFirstName.TabStop = false;
      this.txtOriginalFirstName.Text = "Original First Name";
      // 
      // lblOriginal
      // 
      this.lblOriginal.AutoSize = true;
      this.lblOriginal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOriginal.Location = new System.Drawing.Point(8, 28);
      this.lblOriginal.Name = "lblOriginal";
      this.lblOriginal.Size = new System.Drawing.Size(54, 13);
      this.lblOriginal.TabIndex = 0;
      this.lblOriginal.Text = "Original:";
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmdPrevious.Location = new System.Drawing.Point(48, 271);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(32, 23);
      this.cmdPrevious.TabIndex = 30;
      this.cmdPrevious.TabStop = false;
      this.cmdPrevious.Text = "<";
      this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
      // 
      // txtEmployeeKey
      // 
      this.txtEmployeeKey.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsEmployee, "tblCPEmployee.intIdEmployee", true));
      this.txtEmployeeKey.Location = new System.Drawing.Point(99, 15);
      this.txtEmployeeKey.Name = "txtEmployeeKey";
      this.txtEmployeeKey.ReadOnly = true;
      this.txtEmployeeKey.Size = new System.Drawing.Size(32, 20);
      this.txtEmployeeKey.TabIndex = 23;
      this.txtEmployeeKey.TabStop = false;
      this.txtEmployeeKey.Text = "Key";
      // 
      // dsEmployee
      // 
      this.dsEmployee.DataSetName = "dsEmployee";
      this.dsEmployee.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // lblCurrent
      // 
      this.lblCurrent.AutoSize = true;
      this.lblCurrent.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblCurrent.Location = new System.Drawing.Point(8, 52);
      this.lblCurrent.Name = "lblCurrent";
      this.lblCurrent.Size = new System.Drawing.Size(52, 13);
      this.lblCurrent.TabIndex = 4;
      this.lblCurrent.Text = "Current:";
      // 
      // txtLastName
      // 
      this.txtLastName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsEmployee, "tblCPEmployee.strLastName", true));
      this.txtLastName.Location = new System.Drawing.Point(99, 79);
      this.txtLastName.Name = "txtLastName";
      this.txtLastName.Size = new System.Drawing.Size(100, 20);
      this.txtLastName.TabIndex = 27;
      this.txtLastName.Text = "Last Name";
      // 
      // panRowVersions
      // 
      this.panRowVersions.Controls.Add(this.grpRowStatus);
      this.panRowVersions.Controls.Add(this.txtCurrentLastName);
      this.panRowVersions.Controls.Add(this.txtOriginalLastName);
      this.panRowVersions.Controls.Add(this.txtCurrentFirstName);
      this.panRowVersions.Controls.Add(this.txtOriginalFirstName);
      this.panRowVersions.Controls.Add(this.txtCurrentKey);
      this.panRowVersions.Controls.Add(this.txtOriginalKey);
      this.panRowVersions.Controls.Add(this.lblCurrent);
      this.panRowVersions.Controls.Add(this.lblOriginal);
      this.panRowVersions.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.panRowVersions.Location = new System.Drawing.Point(8, 111);
      this.panRowVersions.Name = "panRowVersions";
      this.panRowVersions.Size = new System.Drawing.Size(328, 144);
      this.panRowVersions.TabIndex = 28;
      this.panRowVersions.TabStop = false;
      this.panRowVersions.Text = "Row Versions";
      // 
      // txtCurrentLastName
      // 
      this.txtCurrentLastName.Location = new System.Drawing.Point(208, 48);
      this.txtCurrentLastName.Name = "txtCurrentLastName";
      this.txtCurrentLastName.ReadOnly = true;
      this.txtCurrentLastName.Size = new System.Drawing.Size(100, 20);
      this.txtCurrentLastName.TabIndex = 7;
      this.txtCurrentLastName.TabStop = false;
      this.txtCurrentLastName.Text = "Current Last Name";
      // 
      // txtFirstName
      // 
      this.txtFirstName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsEmployee, "tblCPEmployee.strFirstName", true));
      this.txtFirstName.Location = new System.Drawing.Point(99, 47);
      this.txtFirstName.Name = "txtFirstName";
      this.txtFirstName.Size = new System.Drawing.Size(100, 20);
      this.txtFirstName.TabIndex = 25;
      this.txtFirstName.Text = "First Name";
      // 
      // cmdFirst
      // 
      this.cmdFirst.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.cmdFirst.Location = new System.Drawing.Point(8, 271);
      this.cmdFirst.Name = "cmdFirst";
      this.cmdFirst.Size = new System.Drawing.Size(32, 23);
      this.cmdFirst.TabIndex = 29;
      this.cmdFirst.TabStop = false;
      this.cmdFirst.Text = "<<";
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      // 
      // cnncpNorthwindScript
      // 
      this.cnncpNorthwindScript.ConnectionString = "Data Source=COPYPASTEPOWER\\COPYPASTE;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthwindScript.FireInfoMessageEventOnUserErrors = false;
      // 
      // dtaEmployee
      // 
      this.dtaEmployee.DeleteCommand = this.cmmDeleteEmployee;
      this.dtaEmployee.InsertCommand = this.cmmInsertEmployee;
      this.dtaEmployee.SelectCommand = this.cmmSelectEmployee;
      this.dtaEmployee.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPEmployee", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdEmployee", "intIdEmployee"),
                        new System.Data.Common.DataColumnMapping("strFirstName", "strFirstName"),
                        new System.Data.Common.DataColumnMapping("strLastName", "strLastName")})});
      this.dtaEmployee.UpdateCommand = this.cmmUpdateEmployee;
      // 
      // cmmDeleteEmployee
      // 
      this.cmmDeleteEmployee.CommandText = "DELETE FROM tblCPEmployee WHERE (intIdEmployee = @Original_intIdEmployee) AND (st" +
    "rFirstName = @Original_strFirstName) AND (strLastName = @Original_strLastName)";
      this.cmmDeleteEmployee.Connection = this.cnncpNorthwindScript;
      this.cmmDeleteEmployee.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_intIdEmployee", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdEmployee", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strFirstName", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strFirstName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strLastName", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strLastName", System.Data.DataRowVersion.Original, null)});
      // 
      // cmmInsertEmployee
      // 
      this.cmmInsertEmployee.CommandText = resources.GetString("cmmInsertEmployee.CommandText");
      this.cmmInsertEmployee.Connection = this.cnncpNorthwindScript;
      this.cmmInsertEmployee.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@strFirstName", System.Data.SqlDbType.VarChar, 10, "strFirstName"),
            new System.Data.SqlClient.SqlParameter("@strLastName", System.Data.SqlDbType.VarChar, 20, "strLastName")});
      // 
      // cmmSelectEmployee
      // 
      this.cmmSelectEmployee.CommandText = "SELECT intIdEmployee, strFirstName, strLastName FROM tblCPEmployee ORDER BY strLa" +
    "stName";
      this.cmmSelectEmployee.Connection = this.cnncpNorthwindScript;
      // 
      // cmmUpdateEmployee
      // 
      this.cmmUpdateEmployee.CommandText = resources.GetString("cmmUpdateEmployee.CommandText");
      this.cmmUpdateEmployee.Connection = this.cnncpNorthwindScript;
      this.cmmUpdateEmployee.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@strFirstName", System.Data.SqlDbType.VarChar, 10, "strFirstName"),
            new System.Data.SqlClient.SqlParameter("@strLastName", System.Data.SqlDbType.VarChar, 20, "strLastName"),
            new System.Data.SqlClient.SqlParameter("@Original_intIdEmployee", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdEmployee", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strFirstName", System.Data.SqlDbType.VarChar, 10, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strFirstName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strLastName", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strLastName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@intIdEmployee", System.Data.SqlDbType.Int, 4, "intIdEmployee")});
      // 
      // frmEditing
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(442, 303);
      this.Controls.Add(this.cmdFill);
      this.Controls.Add(this.cmdCommand);
      this.Controls.Add(this.cmdDefer);
      this.Controls.Add(this.cmdEdit);
      this.Controls.Add(this.cmdDelete);
      this.Controls.Add(this.cmdUpdate);
      this.Controls.Add(this.cmdAccept);
      this.Controls.Add(this.cmdReject);
      this.Controls.Add(this.cmdAdd);
      this.Controls.Add(this.lblLastName);
      this.Controls.Add(this.lblIdEmployee);
      this.Controls.Add(this.cmdSave);
      this.Controls.Add(this.txtPosition);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.lblFirstName);
      this.Controls.Add(this.cmdLast);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.txtEmployeeKey);
      this.Controls.Add(this.txtLastName);
      this.Controls.Add(this.panRowVersions);
      this.Controls.Add(this.txtFirstName);
      this.Controls.Add(this.cmdFirst);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmEditing";
      this.Text = "Editing";
      this.grpRowStatus.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dsEmployee)).EndInit();
      this.panRowVersions.ResumeLayout(false);
      this.panRowVersions.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210818 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20210818 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      if (disposing)
      {

        if (components != null)
        {
          components.Dispose();
        }
        // (components != null)

      }
      // (disposing)

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmEditing

}
// Editing