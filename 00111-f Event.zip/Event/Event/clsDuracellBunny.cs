//***
// Action
//   - Implementation of cpDuracellBunny
// Created
//   - CopyPaste � 20240522 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240522 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning.Event
{

  public class cpDuracellBunny
  {

    #region "Constructors / Destructors"

    public cpDuracellBunny(string strName)
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - Name(String) (Set)
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Name = strName;
    }
    // cpDuracellBunny(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public event cpActionNoPower Park;
    public event cpActionWithPower DoSomething;
    private int mlngPower;
    private string mstrName;

    #endregion

    #region "Properties"

    public string Name
    {

      get
        //***
        // Action Get
        //   - Returning mstrName
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240522 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240522 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

      set
        //***
        // Action Set
        //   - mstrName becomes value
        // Called by
        //   - cpDuracellBunny(string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240522 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240522 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    public int Power
    {

      get
        //***
        // Action Get
        //   - Returning mlngPower
        // Called by
        //   - cpProgram.thecpBunny_DoSomething() Handles thecpBunny.DoSomething
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240522 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240522 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngPower;
      }
      // int Power (Get)

      set
        //***
        // Action Set
        //   - Value can't be bigger than 100
        //     - If so, value is changed into 100
        //   - Value can't be lower than 0
        //     - If so, value is change into 0
        //   - mlngPower becomes value
        //   - If mlngPower is bigger than 0
        //     - cpDuracellBunny can do something
        //   - If not
        //     - cpDuracellBunny must park somewhere (to charge)
        // Called by
        //   - cpProgram.Main()
        //   - cpProgram.thecpBunny_DoSomething() Handles thecpBunny.DoSomething
        // Calls
        //   - DoSomething()
        //   - Park()
        // Created
        //   - CopyPaste � 20240522 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240522 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value > 100)
        {
          mlngPower = 100;
        }
        else if (value < 0)
          // value <= 100
        {
          mlngPower = 0;
        }
        else
          // value > 0
        {
          mlngPower = value;
        }
        // value > 100
        // value < 0

        if (mlngPower > 0)
        {

          if (DoSomething == null)
          {
          }
          else
            // DoSomething <> null
          {
            DoSomething();
          }
          // DoSomething = null

        }
        else
          // mlngPower <= 0
        {

          if (Park == null)
          {
          }
          else
            // Park <> null
          {
            Park();
          }
          // Park = null

        }
        // mlngPower > 0

      }
      // Power(int) (Set)

    }
    // int Power

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate void cpActionWithPower();
    // Power(int) (Set)
    public delegate void cpActionNoPower();
    // Power(int) (Set)

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDuracellBunny

}
// CopyPaste.Learning.Event