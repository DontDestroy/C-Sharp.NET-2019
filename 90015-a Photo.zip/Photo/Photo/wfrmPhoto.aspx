﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmPhoto.aspx.cs" Inherits="CopyPaste.Learning.wfrmPhoto" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Photo</title>
</head>
<body>
  <form id="wfrmPhoto" method="post" runat="server">
    <asp:Panel ID="panPhoto" runat="server"></asp:Panel>
    <asp:Image ID="picBig" runat="server"></asp:Image>
  </form>
</body>
</html>
