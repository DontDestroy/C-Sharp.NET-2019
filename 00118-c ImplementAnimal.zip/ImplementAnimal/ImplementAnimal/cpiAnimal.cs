//***
// Action
//   - Definition of the interface cpiAnimal
// Created
//   - CopyPaste � 20240628 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240628 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public interface cpiAnimal
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    string Name{ get; }

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    string Eat();
    string NoiseSound();
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpiAnimal

}
// CopyPaste.Learning