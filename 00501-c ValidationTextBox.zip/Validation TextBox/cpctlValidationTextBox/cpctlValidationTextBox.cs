//***
// Action
//   - A control based on a textbox with possible validation
// Created
//   - CopyPaste � 20250718 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250718 � VVDW
// Proposal (To Do)
//   - The textbox does not work 100% correct
//   - The conditions should also be checked when you exit the control
//***

using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpctlValidationTextbox : TextBox
	{

    #region "Constructors / Destructors"

    public cpctlValidationTextbox() : base()
      //***
      // Action
      //   - Empty constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250718 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpctlValidationTextbox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private bool mblnTextSelection;
    private cpiValidationRestriction mcpiValidationRestriction;

    #endregion

    #region "Properties"

    public cpiValidationRestriction Restrict
    {

      get
        //***
        // Action Get
        //   - Return mcpiValidationRestriction
        // Called by
        //   - cpctlValidationTextbox_KeyPress(System.Object, KeyPressEventArgs) Handles MyBase.KeyPress
        // Calls
        //   - Editable in the property screen when the control is selected
        // Created
        //   - CopyPaste � 20250718 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250718 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mcpiValidationRestriction;
      }
      // cpiValidationRestriction Restrict (Get)

      set
        //***
        // Action Set
        //   - mcpiValidationRestriction becomes value
        // Called by
        //   - Editable in the property screen when the control is selected
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250718 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250718 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mcpiValidationRestriction = value;
      }
      // Restrict(cpiValidationRestriction) (Set)

    }
    // cpiValidationRestriction Restrict

    public bool SelectAllText
    {

      get
        //***
        // Action Get
        //   - Return mblnTextSelection
        // Called by
        //   - OnEnter(EventArgs)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250718 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250718 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mblnTextSelection;
      }
      // bool SelectAllText (Get)

      set
        //***
        // Action Set
        //   - mblnTextSelection becomes value
        // Called by
        //   - Editable in the property screen when the control is selected
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20250718 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20250718 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mblnTextSelection = value;
      }
      // SelectAllText(bool) (Set)

    }
    // bool SelectAllText

    #endregion

    #region "Methods"

    #region "Overrides"

    protected override void OnEnter(EventArgs theEventArguments)
      //***
      // Action
      //   - If SelectAllText is True
      //     - Select the content of the textbox
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Entering a textbox)
      // Calls
      //   - bool SelectAllText (Get)
      // Created
      //   - CopyPaste � 20250718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (SelectAllText)
      {
        SelectionStart = 0;
        SelectionLength = Text.Length;
        base.OnEnter (theEventArguments);
      }
      else
        // Not SelectAllText
      {
      }
      // SelectAllText

    }
    // OnEnter(EventArgs)

    protected override void OnKeyPress(KeyPressEventArgs theKeyPressEventArguments)
      //***
      // Action
      //   - Try to
      //     - If there is no restriction
      //       - Do nothing
      //     - If not
      //       - If the key is the back key
      //         - Do not handle the event
      //       - If not
      //         - Check if the validation is correct, negate it and put that to handle the event or not
      //   - On Error
      //     - The handling of the event stopped
      //     - An error message is thrown
      // Called by
      //   - User action (Pressing a key)
      // Calls
      //   - cpiValidationRestriction.Validate(cpctlValidationTextbox, System.Windows.Forms.KeyPressEventArgs) As Boolean
      //   - cpiValidationRestriction Restrict (Get)
      // Created
      //   - CopyPaste � 20250718 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250718 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {

        if (Restrict == null)
        {
        }
        else
          // Restrict <> null
        {
          
          if (theKeyPressEventArguments.KeyChar == Convert.ToChar(Keys.Back))
          {
            theKeyPressEventArguments.Handled = false;
          }
          else
            // theKeyPressEventArguments.KeyChar <> Convert.ToChar(Keys.Back)
          {
            theKeyPressEventArguments.Handled = !Restrict.Validate(this, theKeyPressEventArguments);
          }
          // theKeyPressEventArguments.KeyChar = Convert.ToChar(Keys.Back)

          base.OnKeyPress (theKeyPressEventArguments);
        }
        // Restrict = null
      
      }
      catch (Exception theException)
      {
        theKeyPressEventArguments.Handled = true;
        throw new System.Exception(theException.ToString());
      }

    }
    // OnKeyPress(KeyPressEventArgs)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpctlValidationTextbox 

}
// CopyPaste.Learning