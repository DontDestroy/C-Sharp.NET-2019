﻿//***
// Action
//   - A definition of a RemoveAllBeepersTillWall
// Created
//   - CopyPaste – 20251025 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251025 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpRemoveAllBeepersTillWall : cpCopyPasteRobot
	{

    #region "Constructors / Destructors"

    public cpRemoveAllBeepersTillWall(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpRemoveAllBeepersTillWall starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpRemoveAllBeepersTillWall(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRemoveAllBeepersTillWall(int, int, Directions.Direction, int) 

    public cpRemoveAllBeepersTillWall(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpRemoveAllBeepersTillWall starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpProgram.RemoveAllBeepersTillWall()
    //   - cpRemoveAllBeepersTillWall(int, int, Directions.Direction, int)
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRemoveAllBeepersTillWall(int, int, Directions.Direction, int, Color) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void RemoveAllBeepersTillWall()
    //***
    // Action
    //   - A row of beepers will be removed
    //   - Pick all beepers
    //   - As long the front is clear
    //     - Move
    //     - Pick all beepers
    // Called by
    //   - cpProgram.RemoveAllBeepersTillWall()
    // Calls
    //   - cpCopyPasteRobot.PickAllBeepers()
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      PickAllBeepers();

      while (frontIsClear())
      {
        move();
        PickAllBeepers();
      }
      // frontIsClear()

    }
    // RemoveAllBeepersTillWall()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpRemoveAllBeepersTillWall

}
// cpKarelTheRobot