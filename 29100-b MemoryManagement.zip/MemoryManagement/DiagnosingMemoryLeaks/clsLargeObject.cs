﻿//***
// Action
//   - Definition of a cpLargeObject
// Created
//   - CopyPaste – 20260618 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260618 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpLargeObject : IDisposable
  {

    #region "Constructors / Destructors"

    public cpLargeObject()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpUsingLargeObject.ProcessAsync()
    //   - cpUsingLargeObject.ProcessAsyncBetter()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260618 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260618 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpLargeObject()

    public void Dispose()
    //***
    // Action
    //   - Basic destructor
    // Called by
    //   -
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260618 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260618 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // Dispose()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpLargeObject

}
// CopyPaste.Learning