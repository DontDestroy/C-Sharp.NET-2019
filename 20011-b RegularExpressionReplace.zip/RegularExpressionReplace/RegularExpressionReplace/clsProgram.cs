//***
// Action
//   - Check if an email address has the correct format
// Created
//   - CopyPaste � 20260503 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260503 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Text.RegularExpressions;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260503 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define a string
      //   - Define a match
      //   - Define a regular expression
      //   - Create a new instance of a regular expression
      //     - Ignore the capitals and whitespace
      //     - An email address exists of an username@hostname
      //     - Hostname must end with either be, com, edu, eu or info
      //   - Read a certain text thru the console
      //   - If there is a match
      //     - Replace the typed emailadress into the given header
      //   - If not
      //     - Return the entered text
      //   - Wait for user input
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260503 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Match theMatch;
      Regex theRegex;
      string strCopy;

      theRegex = new Regex 
         (@"\b                                                          " +
          @"                     (?# Capture the address to $1 . . . )  " +
          @"(                                                           " +
          @"  \w[-.\w]*                                (?# username)  " +
          @"  @                                                         " +
          @"  [-\w]+(\.[-\w]+)*\.(be|com|edu|eu|info)(?# hostname)  " +
          @")                                                           " +
          @"\b                                                          ", 
          RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace);

      Console.WriteLine("Type a emailadres like: 'Vincent@CopyPaste.be'");
      strCopy = theRegex.Replace(Console.ReadLine(), "<a href=\"mailto:${1}\">${1}</a>");
      Console.WriteLine(strCopy);
      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning