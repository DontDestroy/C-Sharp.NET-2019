﻿//***
// Action
//   - A definition of a RelayRacer
// Created
//   - CopyPaste – 20251106 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251106 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using java.lang;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpRelayRacer : cpCopyPasteRobot, Runnable
	{

    #region "Constructors / Destructors"

    public cpRelayRacer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpRelayRacer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpRelayRacer(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRelayRacer(int, int, Directions.Direction, int) 

    public cpRelayRacer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpRelayRacer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - A new thread of the cpRelayRacer is defined
    //   - The thread is started
    // Called by
    //   - cpProgram.RelayRacer()
    //   - cpRelayRacer(int, int, Directions.Direction, int) 
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Thread theRobotRunnerThread = new Thread(this);

      theRobotRunnerThread.start();
    }
    // cpRelayRacer(int, int, Directions.Direction, int, Color) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override void run()
    //***
    // Action
    //   - Define what must be runned
    //   - Spin the robot as long there is not beeper at that location
    //     - Other robots will bring one
    //   - Pick beeper
    //   - Move one forward
    //   - Move to another robot (till encountering a robot or hitting a wall)
    //   - Put beeper
    //   - Turn left
    //   - Move one forward
    //   - Robot is switched off
    // Called by
    //   - cpRelayRacer(int, int, Directions.Direction, int, Color) 
    // Calls
    //   - cpCopyPasteRobot.MoveToRobot()
    //   - cpCopyPasteRobot.Spin()
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (!nextToABeeper())
      {
        Spin();
      }
      // !nextToABeeper()

      pickBeeper();
      move();
      MoveToRobot();
      putBeeper();
      turnLeft();
      move();
      turnOff();
    }
    // run()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpThreadRobot

}
// cpKarelTheRobot