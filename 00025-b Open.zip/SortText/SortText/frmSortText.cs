//***
// Action
//   - Using a menu in a form
//   - Reads a text
//   - Closes a text
//   - Sorts the paragraphs in the text
// Created
//   - CopyPaste � 20240503 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240503 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSortText: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.MenuItem mnuFileInsertDate;
    internal System.Windows.Forms.MenuItem mnuFileSortText;
    internal System.Windows.Forms.TextBox txtNote;
    internal System.Windows.Forms.MenuItem mnuFile;
    internal System.Windows.Forms.MenuItem mnuFileOpen;
    internal System.Windows.Forms.MenuItem mnuFileClose;
    internal System.Windows.Forms.MenuItem mnuFileSaveAs;
    internal System.Windows.Forms.MenuItem mnuFileExit;
    internal System.Windows.Forms.MainMenu mnuSort;
    internal System.Windows.Forms.Label lblNote;
    internal System.Windows.Forms.SaveFileDialog dlgFileSave;
    internal System.Windows.Forms.OpenFileDialog dlgFileOpen;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSortText));
      this.mnuFileInsertDate = new System.Windows.Forms.MenuItem();
      this.mnuFileSortText = new System.Windows.Forms.MenuItem();
      this.txtNote = new System.Windows.Forms.TextBox();
      this.mnuFile = new System.Windows.Forms.MenuItem();
      this.mnuFileOpen = new System.Windows.Forms.MenuItem();
      this.mnuFileClose = new System.Windows.Forms.MenuItem();
      this.mnuFileSaveAs = new System.Windows.Forms.MenuItem();
      this.mnuFileExit = new System.Windows.Forms.MenuItem();
      this.mnuSort = new System.Windows.Forms.MainMenu();
      this.lblNote = new System.Windows.Forms.Label();
      this.dlgFileSave = new System.Windows.Forms.SaveFileDialog();
      this.dlgFileOpen = new System.Windows.Forms.OpenFileDialog();
      this.SuspendLayout();
      // 
      // mnuFileInsertDate
      // 
      this.mnuFileInsertDate.Index = 3;
      this.mnuFileInsertDate.Text = "&Insert Date";
      this.mnuFileInsertDate.Click += new System.EventHandler(this.mnuFileInsertDate_Click);
      // 
      // mnuFileSortText
      // 
      this.mnuFileSortText.Index = 4;
      this.mnuFileSortText.Text = "&Sort Text";
      this.mnuFileSortText.Click += new System.EventHandler(this.mnuFileSortText_Click);
      // 
      // txtNote
      // 
      this.txtNote.Location = new System.Drawing.Point(16, 48);
      this.txtNote.Multiline = true;
      this.txtNote.Name = "txtNote";
      this.txtNote.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtNote.Size = new System.Drawing.Size(360, 184);
      this.txtNote.TabIndex = 3;
      this.txtNote.Text = "";
      // 
      // mnuFile
      // 
      this.mnuFile.Index = 0;
      this.mnuFile.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFileOpen,
                                                                            this.mnuFileClose,
                                                                            this.mnuFileSaveAs,
                                                                            this.mnuFileInsertDate,
                                                                            this.mnuFileSortText,
                                                                            this.mnuFileExit});
      this.mnuFile.Text = "&File";
      // 
      // mnuFileOpen
      // 
      this.mnuFileOpen.Index = 0;
      this.mnuFileOpen.Text = "&Open ...";
      this.mnuFileOpen.Click += new System.EventHandler(this.mnuFileOpen_Click);
      // 
      // mnuFileClose
      // 
      this.mnuFileClose.Enabled = false;
      this.mnuFileClose.Index = 1;
      this.mnuFileClose.Text = "&Close";
      this.mnuFileClose.Click += new System.EventHandler(this.mnuFileClose_Click);
      // 
      // mnuFileSaveAs
      // 
      this.mnuFileSaveAs.Index = 2;
      this.mnuFileSaveAs.Text = "&Save As...";
      this.mnuFileSaveAs.Click += new System.EventHandler(this.mnuFileSaveAs_Click);
      // 
      // mnuFileExit
      // 
      this.mnuFileExit.Index = 5;
      this.mnuFileExit.Text = "&Exit";
      this.mnuFileExit.Click += new System.EventHandler(this.mnuFileExit_Click);
      // 
      // mnuSort
      // 
      this.mnuSort.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuFile});
      // 
      // lblNote
      // 
      this.lblNote.Location = new System.Drawing.Point(16, 8);
      this.lblNote.Name = "lblNote";
      this.lblNote.Size = new System.Drawing.Size(360, 24);
      this.lblNote.TabIndex = 2;
      this.lblNote.Text = "Type or open text to sort.";
      // 
      // dlgFileSave
      // 
      this.dlgFileSave.FileName = "doc1";
      // 
      // frmSortText
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(392, 277);
      this.Controls.Add(this.txtNote);
      this.Controls.Add(this.lblNote);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mnuSort;
      this.Name = "frmSortText";
      this.Text = "Sort Text";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSortText'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSortText()
      //***
      // Action
      //   - Create instance of 'frmSortText'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSortText()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void mnuFileClose_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Closes a file
      //   - Set the state of the screen at the beginning
      //   - Enable opening a file
      //   - Disable closing a file
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtNote.Text = "";
      lblNote.Text = "Type or open text to sort.";
      mnuFileClose.Enabled = false;
      mnuFileOpen.Enabled = true;
    }
    // mnuFileClose_Click(System.Object theSender, System.EventArgs theEventArguments) Handles mnuFileClose.Click

    private void mnuFileExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stops the application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // mnuFileExit_Click(System.Object theSender, System.EventArgs theEventArguments) Handles mnuFileExit.Click

    private void mnuFileInsertDate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the current date at the beginning of the text
      //   - Put the cursor in front of the text
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtNote.Text = DateTime.Now.ToString("dd/MM/yyyy") + Environment.NewLine + txtNote.Text;
      txtNote.Select(0, 0);
    }
    // mnuFileInsertDate_Click(System.Object theSender, System.EventArgs theEventArguments) Handles mnuFileInsertDate.Click

    private void mnuFileOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Configure the file open screen
      //     - Filter on textfiles
      //     - Set the current directory
      //   - Open the screen
      //   - If there is a filename selected (to open)
      //     - Open the file
      //     - Read every line seperately
      //     - Remember the filename, show on screen
      //     - Show the text
      //     - Put cursor at top
      //     - Enable close menu
      //     - Disable open menu
      //   - If not
      //     - Do nothing
      //   - Show error message on errors
      //   - Close the file
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      StreamReader theFile = null;
      string strAllText = "";
      string strLineOfText;

      dlgFileOpen.Filter = "Text Files (*.txt)|*.txt";
      dlgFileOpen.InitialDirectory = Environment.CurrentDirectory;
      dlgFileOpen.ShowDialog();

      if (dlgFileOpen.FileName == "")
      {
      }
      else
        // dlgFileOpen.FileName <> ""
      {

        try
        {
          theFile = new StreamReader(dlgFileOpen.FileName);
        }
        catch
        {
          MessageBox.Show("File can not be opened.");
        }

        try
        {

          while (theFile.Peek() > 0)
          {
            strLineOfText = theFile.ReadLine();
            strAllText = strAllText + strLineOfText + Environment.NewLine;
          }
          // theFile.Peek() > 0

          lblNote.Text = dlgFileOpen.FileName;
          txtNote.Text = strAllText;
          txtNote.Select(0, 0);
          txtNote.Enabled = true;
          mnuFileClose.Enabled = true;
          mnuFileOpen.Enabled = false;
        }
        catch
        {
          MessageBox.Show("Something went wrong");
        }
        finally
        {
          theFile.Close();
        }

      }
      // dlgFileOpen.FileName = ""

    }
    // mnuFileOpen_Click(System.Object theSender, System.EventArgs theEventArguments) Handles mnuFileOpen.Click

    private void mnuFileSaveAs_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Configure the file save screen
      //     - Filter on textfiles
      //     - Set the current directory
      //   - Open the screen
      //   - If button OK is clicked
      //     - Open the file
      //     - Save the text
      //     - Close the file
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dlgFileSave.Filter = "Text Files (*.txt)|*.txt";
      dlgFileSave.InitialDirectory = Environment.CurrentDirectory;

      if (dlgFileSave.ShowDialog() == DialogResult.OK)
      {

        if (dlgFileSave.FileName == "")
        {
        }
        else
          // dlgFileSave.FileName <> "" 
        {
          StreamWriter theFile = new StreamWriter(dlgFileSave.FileName);
          theFile.Write(txtNote.Text);
          theFile.Flush();
          theFile.Close();
        }
        // dlgFileSave.FileName = "" 
                                                 }
      else
        // dlgFileSave.ShowDialog() <> DialogResult.OK
      {
      }
      // dlgFileSave.ShowDialog() = DialogResult.OK
    
    }
    // mnuFileSaveAs_Click(System.Object theSender, System.EventArgs theEventArguments) Handles mnuFileSaveAs.Click

    private void mnuFileSortText_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Count the enters (chr(13) in the text
      //     - This counts the paragraphs in the text (to sort)
      //   - Redefine the array
      //   - Loop the text again and fil the array
      //   - Sort the array using Shell sort
      //   - Show the sorted text on the screen
      //   - Put cursor at top
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpSort.ShellSort(string[], int)
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngCharactersInFile;
      int lngCounter;
      int lngCurrentLine = 0;
      int lngLineCounter = 0;

      string strLetter;
      string strLine;
      string strEnter = ((char)13).ToString();

      lngCharactersInFile = txtNote.Text.Length;

      for (lngCounter = 0; lngCounter < lngCharactersInFile; lngCounter++)
      {
        strLetter = txtNote.Text.Substring(lngCounter, 1);

        if (strLetter == strEnter)
        {
          lngLineCounter += 1;
        }
        else
          // strLetter <> strEnter
        {
        }
        // strLetter = strEnter

      }
      // lngCounter = lngCharactersInFile

      cpSort.marrstrText = new string[lngLineCounter];
      strLine = "";

      for (lngCounter = 0; lngCounter < lngCharactersInFile; lngCounter++)
      {
        strLetter = txtNote.Text.Substring(lngCounter, 1);
        
        if (strLetter == strEnter)
        {
          lngCurrentLine += 1;
          lngCounter++;
          strLine = "";
        }
        else
          // strLetter <> strEnter
        {
          strLine = strLine + strLetter;
          cpSort.marrstrText[lngCurrentLine] = strLine;
        }
        // strLetter = Chr(13) 

      }
      // lngCounter = lngCharactersInFile
    
      cpSort.ShellSort(cpSort.marrstrText, lngLineCounter);

      txtNote.Text = "";

      for (lngCounter = 0; lngCounter < lngLineCounter; lngCounter++)
      {
        txtNote.Text = txtNote.Text + cpSort.marrstrText[lngCounter] + Environment.NewLine;
      }
      // lngCounter = lngLineCounter + 1

      txtNote.Select(0, 0);
    }
    // mnuFileSortText_Click(System.Object theSender, System.EventArgs theEventArguments) Handles mnuFileSortText.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSortText
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmSortText()
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSortText());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmSortText

}
// CopyPaste.Learning