//***
// Action
//   - Throw an error to test what happens when the error should occur
// Created
//   - CopyPaste � 20240515 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240515 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmThrow: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.Label lblSecond;
    internal System.Windows.Forms.Label lblFirst;
    internal System.Windows.Forms.TextBox txtResult;
    internal System.Windows.Forms.TextBox txtSecond;
    internal System.Windows.Forms.TextBox txtFirst;
    internal System.Windows.Forms.Button cmdCalculate;
    internal System.Windows.Forms.Button cmdAdd;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmThrow));
      this.lblResult = new System.Windows.Forms.Label();
      this.lblSecond = new System.Windows.Forms.Label();
      this.lblFirst = new System.Windows.Forms.Label();
      this.txtResult = new System.Windows.Forms.TextBox();
      this.txtSecond = new System.Windows.Forms.TextBox();
      this.txtFirst = new System.Windows.Forms.TextBox();
      this.cmdCalculate = new System.Windows.Forms.Button();
      this.cmdAdd = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // lblResult
      // 
      this.lblResult.Location = new System.Drawing.Point(16, 150);
      this.lblResult.Name = "lblResult";
      this.lblResult.TabIndex = 12;
      this.lblResult.Text = "Result";
      // 
      // lblSecond
      // 
      this.lblSecond.Location = new System.Drawing.Point(16, 80);
      this.lblSecond.Name = "lblSecond";
      this.lblSecond.TabIndex = 10;
      this.lblSecond.Text = "Second Number";
      // 
      // lblFirst
      // 
      this.lblFirst.Location = new System.Drawing.Point(16, 20);
      this.lblFirst.Name = "lblFirst";
      this.lblFirst.TabIndex = 8;
      this.lblFirst.Text = "First Number";
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(120, 150);
      this.txtResult.Name = "txtResult";
      this.txtResult.TabIndex = 13;
      this.txtResult.Text = "";
      // 
      // txtSecond
      // 
      this.txtSecond.Location = new System.Drawing.Point(120, 80);
      this.txtSecond.Name = "txtSecond";
      this.txtSecond.TabIndex = 11;
      this.txtSecond.Text = "";
      // 
      // txtFirst
      // 
      this.txtFirst.Location = new System.Drawing.Point(120, 20);
      this.txtFirst.Name = "txtFirst";
      this.txtFirst.TabIndex = 9;
      this.txtFirst.Text = "";
      // 
      // cmdCalculate
      // 
      this.cmdCalculate.Location = new System.Drawing.Point(56, 248);
      this.cmdCalculate.Name = "cmdCalculate";
      this.cmdCalculate.Size = new System.Drawing.Size(168, 32);
      this.cmdCalculate.TabIndex = 15;
      this.cmdCalculate.Text = "Calculate Remainder";
      this.cmdCalculate.Click += new System.EventHandler(this.cmdCalculate_Click);
      // 
      // cmdAdd
      // 
      this.cmdAdd.Location = new System.Drawing.Point(56, 200);
      this.cmdAdd.Name = "cmdAdd";
      this.cmdAdd.Size = new System.Drawing.Size(168, 32);
      this.cmdAdd.TabIndex = 14;
      this.cmdAdd.Text = "Add Numbers";
      this.cmdAdd.Click += new System.EventHandler(this.cmdAdd_Click);
      // 
      // frmThrow
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(288, 301);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.lblSecond);
      this.Controls.Add(this.lblFirst);
      this.Controls.Add(this.txtResult);
      this.Controls.Add(this.txtSecond);
      this.Controls.Add(this.txtFirst);
      this.Controls.Add(this.cmdCalculate);
      this.Controls.Add(this.cmdAdd);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmThrow";
      this.Text = "Throw Exception";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmThrow'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmThrow()
      //***
      // Action
      //   - Create instance of 'frmThrow'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAdd_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Result becomes empty
      //   - If the length of first text is 0
      //     - Show error
      //   - If not
      //     - If the length of second text is 0
      //       - Show error
      //     - If not
      //       - Try
      //         - Convert the both texts into integers
      //         - Add them
      //       - Show error when it fails
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - int AddNumbers(int, int)
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtResult.Text = "";

      if (txtFirst.Text.Length == 0)
      {
        MessageBox.Show("Must specify first value");
      }
      else if (txtSecond.Text.Length == 0)
        // txtFirst.Text.Length <> 0
      {
        MessageBox.Show("Must specify second value");
      }
      else
        // txtFirst.Text.Length <> 0
        // txtSecond.Text.Length <> 0
      {

        try
        {
          txtResult.Text = AddNumbers(Convert.ToInt32(txtFirst.Text), Convert.ToInt32(txtSecond.Text)).ToString();
        }
        catch (Exception theException)
        {
          MessageBox.Show("Call generated error: " + theException.Message);
        }

      }
      // txtFirst.Text.Length = 0
      // txtSecond.Text.Length = 0
          
    }
    // cmdAdd_Click(theSender, theEventArguments) Handles cmdAdd.Click

    private void cmdCalculate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Result becomes empty
      //   - If the length of first text is 0
      //     - Show error
      //   - If not
      //     - If the length of second text is 0
      //       - Show error
      //     - If not
      //       - Try
      //         - Convert the both texts into integers
      //         - Calculate the remainder
      //       - Show error when it fails
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - int DoMod(int, int)
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtResult.Text = "";

      if (txtFirst.Text.Length == 0)
      {
        MessageBox.Show("Must specify first value");
      }
      else if (txtSecond.Text.Length == 0)
        // txtFirst.Text.Length <> 0
      {
        MessageBox.Show("Must specify second value");
      }
      else
        // txtFirst.Text.Length <> 0
        // txtSecond.Text.Length <> 0
      {

        try
        {
          txtResult.Text = DoMod(Convert.ToInt32(txtFirst.Text), Convert.ToInt32(txtSecond.Text)).ToString();
        }
        catch (Exception theException)
        {
          MessageBox.Show("Call generated error: " + theException.Message);
        }

      }
      // txtFirst.Text.Length = 0
      // txtSecond.Text.Length = 0
    
    }
    // cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int AddNumbers(int lngFirst, int lngSecond)
      //***
      // Action
      //   - Try
      //     - Add the numbers
      //     - Forcing the error is put in comments
      //   - Show error when it fails
      // Called by
      //   - cmdAdd_Click(System.Object, System.EventArgs) Handles cmdAdd.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngResult = 0;

      try
      {
        lngResult = lngFirst + lngSecond;
        // throw new ArithmeticException();
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
        lngResult = 0;
      }

      return lngResult;
    }
    // int AddNumbers(int, int)

    public int DoMod(int lngFirst, int lngSecond)
      //***
      // Action
      //   - Try
      //     - Calculate the modulo of the numbers
      //     - Forcing the error is put in comments
      //   - Show error when it fails
      // Called by
      //   - cmdCalculate_Click(System.Object, .EventArgs) Handles cmdCalculate.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngResult = 0;

      try
      {
        lngResult = lngFirst % lngSecond;
        // throw new DivideByZeroException();
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
        lngResult = 0;
      }

      return lngResult;
    }
    // int DoMod(int, int)

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmThrow
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmThrow()
      // Created
      //   - CopyPaste � 20240515 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240515 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmThrow());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmThrow

}
// CopyPaste.Learning