﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmReadClient.aspx.cs" Inherits="CopyPaste.Learning.wfrmReadClient" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Read Data from cpClient</title>
</head>
<body>
  <form id="wfrmReadClient" method="post" runat="server">
    <asp:Label Style="z-index: 100; position: absolute; top: 16px; left: 24px" ID="lblTitle" runat="server"
      Font-Size="X-Large">Read Client</asp:Label>
    <asp:Label Style="z-index: 125; position: absolute; top: 272px; left: 424px" ID="lblAction"
      TabIndex="22" runat="server"></asp:Label>
    <asp:Label Style="z-index: 124; position: absolute; top: 88px; left: 72px" ID="lblFindNumber"
      runat="server" Enabled="False">Number</asp:Label>
    <asp:TextBox Style="z-index: 123; position: absolute; top: 88px; left: 144px" ID="txtFindNumber"
      TabIndex="1" runat="server" Enabled="False" Width="56px"></asp:TextBox>
    <asp:Label Style="z-index: 102; position: absolute; top: 128px; left: 72px" ID="lblNumber"
      TabIndex="3" runat="server">Number</asp:Label>
    <asp:Button Style="z-index: 122; position: absolute; top: 336px; left: 368px" ID="cmdClear"
      TabIndex="21" runat="server" Text="Clear"></asp:Button>
    <asp:Button Style="z-index: 121; position: absolute; top: 336px; left: 280px" ID="cmdDelete"
      TabIndex="20" runat="server" Enabled="False" Text="Delete"></asp:Button>
    <asp:Button Style="z-index: 120; position: absolute; top: 336px; left: 216px" ID="cmdNew" TabIndex="19"
      runat="server" Enabled="False" Text="New"></asp:Button>
    <asp:Button Style="z-index: 119; position: absolute; top: 336px; left: 152px" ID="cmdChange"
      TabIndex="18" runat="server" Enabled="False" Text="Edit"></asp:Button>
    <asp:Button Style="z-index: 118; position: absolute; top: 296px; left: 248px" ID="cmdLast" TabIndex="17"
      runat="server" Enabled="False" Text=">|"></asp:Button>
    <asp:Button Style="z-index: 117; position: absolute; top: 296px; left: 216px" ID="cmdNext" TabIndex="16"
      runat="server" Enabled="False" Text=">"></asp:Button>
    <asp:Button Style="z-index: 116; position: absolute; top: 296px; left: 184px" ID="cmdPrevious"
      TabIndex="15" runat="server" Enabled="False" Text="<"></asp:Button>
    <asp:Button Style="z-index: 115; position: absolute; top: 296px; left: 152px" ID="cmdFirst"
      TabIndex="14" runat="server" Enabled="False" Text="|<"></asp:Button>
    <asp:Button Style="z-index: 114; position: absolute; top: 88px; left: 216px" ID="cmdFindNameNumber"
      TabIndex="2" runat="server" Enabled="False" Width="278" Text="Enter number or name and click"
      Height="24"></asp:Button>
    <asp:Label Style="z-index: 113; position: absolute; top: 240px; left: 424px" ID="lblMessage"
      TabIndex="13" runat="server"></asp:Label>
    <asp:TextBox Style="z-index: 111; position: absolute; top: 240px; left: 216px" ID="txtCity" TabIndex="12"
      runat="server" Width="192px"></asp:TextBox>
    <asp:TextBox Style="z-index: 110; position: absolute; top: 240px; left: 160px" ID="txtZipCode"
      TabIndex="11" runat="server" Width="48px"></asp:TextBox>
    <asp:Label Style="z-index: 109; position: absolute; top: 240px; left: 72px" ID="lblCity" TabIndex="10"
      runat="server">City</asp:Label>
    <asp:TextBox Style="z-index: 108; position: absolute; top: 200px; left: 144px" ID="txtAddress"
      TabIndex="9" runat="server" Width="264px"></asp:TextBox>
    <asp:Label Style="z-index: 107; position: absolute; top: 208px; left: 72px" ID="lblAddress"
      TabIndex="8" runat="server">Address</asp:Label>
    <asp:TextBox Style="z-index: 106; position: absolute; top: 168px; left: 144px" ID="txtName" TabIndex="7"
      runat="server" Width="264px"></asp:TextBox>
    <asp:Label Style="z-index: 105; position: absolute; top: 168px; left: 72px" ID="lblName" TabIndex="6"
      runat="server">Name</asp:Label>
    <asp:Button Style="z-index: 104; position: absolute; top: 128px; left: 216px" ID="cmdFindNumber"
      TabIndex="5" runat="server" Width="278px" Text="Enter number and click" Height="24"></asp:Button>
    <asp:TextBox Style="z-index: 103; position: absolute; top: 128px; left: 144px" ID="txtNumber"
      TabIndex="4" runat="server" Width="56px"></asp:TextBox>
    <asp:Label Style="z-index: 101; position: absolute; top: 128px; left: 72px" ID="lblClientNumber"
      runat="server">Number</asp:Label>
  </form>
</body>
</html>
