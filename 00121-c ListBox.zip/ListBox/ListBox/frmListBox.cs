//***
// Action
//   - Testroutine for cpCountry
// Created
//   - CopyPaste � 20240628 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240628 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmListBox: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtSelected;
    internal System.Windows.Forms.Button cmdShowText;
    internal System.Windows.Forms.ListBox lstCountry;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmListBox));
      this.txtSelected = new System.Windows.Forms.TextBox();
      this.cmdShowText = new System.Windows.Forms.Button();
      this.lstCountry = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // txtSelected
      // 
      this.txtSelected.Location = new System.Drawing.Point(14, 216);
      this.txtSelected.Multiline = true;
      this.txtSelected.Name = "txtSelected";
      this.txtSelected.ReadOnly = true;
      this.txtSelected.Size = new System.Drawing.Size(264, 40);
      this.txtSelected.TabIndex = 5;
      this.txtSelected.Text = "";
      // 
      // cmdShowText
      // 
      this.cmdShowText.Location = new System.Drawing.Point(110, 184);
      this.cmdShowText.Name = "cmdShowText";
      this.cmdShowText.TabIndex = 4;
      this.cmdShowText.Text = "Show Text";
      this.cmdShowText.Click += new System.EventHandler(this.cmdShowText_Click);
      // 
      // lstCountry
      // 
      this.lstCountry.Location = new System.Drawing.Point(14, 16);
      this.lstCountry.Name = "lstCountry";
      this.lstCountry.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
      this.lstCountry.Size = new System.Drawing.Size(264, 160);
      this.lstCountry.Sorted = true;
      this.lstCountry.TabIndex = 3;
      // 
      // frmListBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.txtSelected);
      this.Controls.Add(this.cmdShowText);
      this.Controls.Add(this.lstCountry);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.Name = "frmListBox";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Select more than one destination";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmListBox'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmListBox()
      //***
      // Action
      //   - Create new instance of 'frmListBox'
      //   - Create four instances of cpCountry
      //   - Add them to the listbox
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cpCountry(string, string, int)
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();

      cpCountry cpCountry01 = new cpCountry("Belgium", "Brussels", 30258);
      cpCountry cpCountry02 = new cpCountry("Netherlands", "Amsterdam", 41547);
      cpCountry cpCountry03 = new cpCountry("Germany", "Berlin", 356970);
      cpCountry cpCountry04 = new cpCountry("France", "Paris", 544000);

      lstCountry.Items.Add(cpCountry01);
      lstCountry.Items.Add(cpCountry02);
      lstCountry.Items.Add(cpCountry03);
      lstCountry.Items.Add(cpCountry04);
    }
    // frmListBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdShowText_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Clear the textbox
      //   - Loop thru all the selected items
      //     - Add the text of the country to the textbox (and place a space behind it)
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpCountry.Name() As String (Get)
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {      
      txtSelected.Clear();

      foreach (cpCountry thecpCountry in lstCountry.SelectedItems)
      {
        txtSelected.AppendText(thecpCountry.Name + " ");
      }
      // in lstCountry.SelectedItems
    
    }
    // cmdShowText_Click(System.Object, System.EventArgs) Handles cmdShowText.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmListBox
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmListBox()
      // Created
      //   - CopyPaste � 20240628 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240628 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmListBox());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmListBox

}
// CopyPaste.Learning