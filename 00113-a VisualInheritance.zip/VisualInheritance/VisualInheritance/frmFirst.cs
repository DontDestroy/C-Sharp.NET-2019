//***
// Action
//   - Examples of visual inheritance
//   - Base class frmFirst
// Created
//   - CopyPaste � 20240218 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240218 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFirst: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdCancel;
    internal System.Windows.Forms.Button cmdOK;
    internal System.Windows.Forms.Label lblName;
    internal System.Windows.Forms.TextBox txtName;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFirst));
      this.cmdCancel = new System.Windows.Forms.Button();
      this.cmdOK = new System.Windows.Forms.Button();
      this.lblName = new System.Windows.Forms.Label();
      this.txtName = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdCancel
      // 
      this.cmdCancel.Location = new System.Drawing.Point(173, 197);
      this.cmdCancel.Name = "cmdCancel";
      this.cmdCancel.TabIndex = 7;
      this.cmdCancel.Text = "Cancel";
      this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
      // 
      // cmdOK
      // 
      this.cmdOK.Location = new System.Drawing.Point(45, 197);
      this.cmdOK.Name = "cmdOK";
      this.cmdOK.TabIndex = 6;
      this.cmdOK.Text = "OK";
      this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
      // 
      // lblName
      // 
      this.lblName.Location = new System.Drawing.Point(45, 53);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(100, 24);
      this.lblName.TabIndex = 5;
      this.lblName.Text = "Type your name:";
      // 
      // txtName
      // 
      this.txtName.Location = new System.Drawing.Point(45, 77);
      this.txtName.Name = "txtName";
      this.txtName.Size = new System.Drawing.Size(200, 20);
      this.txtName.TabIndex = 4;
      this.txtName.Text = "";
      // 
      // frmFirst
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdCancel);
      this.Controls.Add(this.cmdOK);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.txtName);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFirst";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "FirstScreen";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFirst'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFirst()
      //***
      // Action
      //   - Create instance of 'frmFirst'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFirst()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdOK_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there is something typed
      //     - Shows a messagebox with the typed name
      //   - If Not
      //     - Do Nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (txtName.Text.Length > 0)
      {
        MessageBox.Show("Hello, " + txtName.Text + "!");
      }
      else
        // txtName.Text.Length <= 0
      {
      }
      // txtName.Text.Length > 0
    
    }
    // cmdOK_Click(System.Object, System.EventArgs) Handles cmdOK.Click

    private void cmdCancel_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Ends the application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      this.Close();
    }
    // cmdCancel_Click(System.Object, System.EventArgs) Handles cmdCancel.Click
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFirst
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240218 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240218 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFirst());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmFirst

}
// CopyPaste.Learning