﻿//***
// Action
//   - Having a connection towards a database
//   - Defining the connection functionality
// Created
//   - CopyPaste – 20210806 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210806 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Data.SqlClient;
using System.Text;

namespace WPFConnection.ViewModel
{
  class cpConnectionViewModel : cpViewModelBase
  {

    #region "Constructors / Destructors"

    public cpConnectionViewModel()
    //***
    // Action
    //   - Creating an instance cpConnectionViewModel
    //   - Setting the Connection string
    // Called by
    //   - ctrlConnection.xaml
    // Calls
    //   - ConnectionString(string) (Set)
    //   - string cpApplicationSetting.ConnectionString() (Get)
    // Created
    //   - CopyPaste – 20210806 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210806 – VVDW
    // Keyboard Key
    //   - 
    // Proposal(To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      ConnectionString = cpApplicationSetting.ConnectionString;
    }
    // cpConnectionViewModel()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    //***
    // Action Get
    //   - Returns ConnectionString
    // Called by (Get)
    //   - ConnectUsingBlock()
    //   - ctrlConnection.cmdOpenConnectionSQLServerAuthorisation_Click(System.Object, System.Windows.RoutedEventArgs)
    //   - ctrlConnection.cmdOpenConnectionWindowsAuthorisation_Click(System.Object, System.Windows.RoutedEventArgs) 
    // Action Set
    //   - Sets ConnectionString
    // Called by (Set)
    //   - cpConnectionViewModel()
    //   - ctrlConnection.cmdOpenConnectionSQLServerAuthorisation_Click(System.Object, System.Windows.RoutedEventArgs) 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210806 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210806 – VVDW
    // Keyboard key
    //   - 
    // Proposal(To Do)
    //   - List of actions that can be added to the functionality
    //***

    public string ConnectionString { get; set; }
    // string ConnectionString() (Get)
    // ConnectionString(string) (Set)

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Connect(string strConnectionString)
    //***
    // Action
    //   - Create SQL Connection object (cnnSQL) based on strConnectionString
    //   - Open Connection
    //   - Find information of connection 
    //   - Close the connection
    //   - Dispose of the connection
    // Called by
    //   - ctrlConnection.cmdOpenConnectionSQLServerAuthorisation_Click(System.Object, System.Windows.RoutedEventArgs) 
    //   - ctrlConnection.cmdOpenConnectionWindowsAuthorisation_Click(System.Object, System.Windows.RoutedEventArgs) 
    // Calls
    //   - cpViewModelBase.ResultText(string) (Set)
    //   - GetConnectionInformation(SqlConnection)
    // Created
    //   - CopyPaste – 20210806 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210806 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //    - List of actions that can be added to the functionality
    //***
    {
      SqlConnection cnnSQL = new SqlConnection(strConnectionString);
      cnnSQL.Open();
      ResultText = GetConnectionInformation(cnnSQL);
      cnnSQL.Close();
      cnnSQL.Dispose();
    }
    // Connect(string)

    public void ConnectUsingBlock()
    //***
    // Action
    //   - Create SQL Connection object (cnnSQL) based on ConnectionString
    //   - Open Connection inside a using block
    //   - Find information of connection 
    // Called by
    //   - ctrlConnection.cmdOpenConnectionUsingBlock_Click(System.Object, System.Windows.RoutedEventArgs)
    // Calls
    //    - cpViewModelBase.ResultText(string) (Set)
    //    - GetConnectionInformation(SqlConnection)
    //    - string ConnectionString() (Get)
    // Created
    //    - CopyPaste – 20210806 – VVDW
    // Changed
    //    - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //    - CopyPaste – 20210806 – VVDW
    // Keyboard key
    //    - 
    // Proposal (To Do)
    //    - List of actions that can be added to the functionality
    //    - Study why there Is no paramater here compared with Connect
    //***
    {

      using (SqlConnection cnnSQL = new SqlConnection(ConnectionString))
      {
        cnnSQL.Open();
        ResultText = GetConnectionInformation(cnnSQL);
      }
      // cnnSQL

    }
    // ConnectUsingBlock()

    public void ConnectWithErrors()
    //***
    // Action
    //   - Create SQL Connection object (cnnSQL) based on ConnectionString
    //   - Try to 
    //     - Open Connection inside a using block
    //     - Find information of connection
    //   - Catch
    //     - show error information of connection
    // Called by
    //   - ctrlConnection.cmdOpenConnectionErrorHandling_Click(System.Object, System.Windows.RoutedEventArgs)
    // Calls
    //   - cpViewModelBase.ResultText(string) (Set)
    //   - GetConnectionInformation(SqlConnection)
    // Created
    //   - CopyPaste – 20210806 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210806 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //   - Study why there Is no paramater here compared with Connect
    //***
    {

      try
      {
        string cnnString = "Server=Error;Connection Timeout = 2;Initial Catalog=cpNorthWindScript2019;Integrated Security=True";

        using (SqlConnection cnnSQL = new SqlConnection(cnnString))
        {
          cnnSQL.Open();
          ResultText = GetConnectionInformation(cnnSQL);
        }
        // cnnSQL

      }
      catch (Exception theException)
      {
        ResultText = theException.ToString();
      }

    }
    // ConnectWithErrors()

    protected virtual string GetConnectionInformation(SqlConnection cnnInformation)
    //***
    // Action
    //   - Define a string builder
    //   - Append a line "Connection String: " + ConnectionString of cnnInformation
    //   - Append a line "State: " + State of cnnInformation
    //   - Append a line "Connection Timeout: " + ConnectionTimeout of cnnInformation
    //   - Append a line "Database: " + Database of cnnInformation
    //   - Append a line "Data Source: " + DataSource of cnnInformation
    //   - Append a line "Server Version: " + ServerVersion of cnnInformation
    //   - Append a line "Workstation ID: " + WorkstationId of cnnInformation
    //   - Return string builder
    // Called by
    //   - Connect(string)
    //   - ConnectUsingBlock()
    //   - ConnectWithErrors()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20210806 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210806 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***cnnInformation
    {
      StringBuilder strBuildConnection = new StringBuilder(1024);

      strBuildConnection.AppendLine("Connection String: " + cnnInformation.ConnectionString);
      strBuildConnection.AppendLine("State: " + cnnInformation.State.ToString());
      strBuildConnection.AppendLine("Connection Timeout: " + cnnInformation.ConnectionTimeout.ToString());
      strBuildConnection.AppendLine("Database: " + cnnInformation.Database);
      strBuildConnection.AppendLine("Data Source: " + cnnInformation.DataSource);
      strBuildConnection.AppendLine("Server Version: " + cnnInformation.ServerVersion);
      strBuildConnection.AppendLine("Workstation ID: " + cnnInformation.WorkstationId);

      return strBuildConnection.ToString();
    }
    // string GetConnectionInformation(SqlConnection)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpConnectionViewModel

}
// WPFConnection.ViewModel