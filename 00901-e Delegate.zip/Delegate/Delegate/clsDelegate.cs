﻿//***
// Action
//   - Set up a delegate that receives a text and returns a number
//   - The technique of a property is used
// Created
//   - CopyPaste – 20250713 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250713 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpDelegate
  {

    #region "Constructors / Destructors"

    public cpDelegate()
      //***
      // Action
      //   - Empty constructor
      // Called by
      //   - frmDelegateTryout.frmDelegateTryout_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250713 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250713 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDelegate()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpCallBack mcpCallBack;

    #endregion

    #region "Properties"

    public cpCallBack CallBack
    {
      
      get
        //***
        // Action Get
        //   - Returns delegate instance
        // Called by
        //   - TestDelegate()
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20250713 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250713 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***  
      {
        return mcpCallBack;
      }
      // cpCallBack CallBack (Get)

      set
        //***
        // Action Get
        //   - Delegate instance becomes value
        // Called by
        //   - frmDelegateTryout.frmDelegateTryout_Load(System.Object, System.EventArgs) Handles this.Load
        //   - SetDelegate(cpCallBack)
        // Calls
        //   - 
        // Created
        //   - CopyPaste – 20250713 – VVDW
        // Changed
        //   - CopyPaste – yyyymmdd – VVDW – What changed
        // Tested
        //   - CopyPaste – 20250713 – VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***  
      {
        mcpCallBack = value;
      }
      // CallBack(cpCallBack) (Set)

    }
    // cpCallBack CallBack

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate int cpCallBack(string strText);

    #endregion

    #region "Sub / Function"

    public void SetDelegate(cpCallBack thecpCallBack)
      //***
      // Action
      //   - The given argument becomes the callback
      // Called by
      //   - frmDelegateTryout.frmDelegateTryout_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - CallBack(cpCallBack) (Set)
      // Created
      //   - CopyPaste – 20250713 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250713 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - You can also use the property because it is public
      //***
    {
      CallBack = thecpCallBack;
    }
    // SetDelegate(cpCallBack)

    public void TestDelegate()
      //***
      // Action
      //   - A string is given to the delegate
      //   - A number is returned
      //   - The number is shown using a message box
      // Called by
      //   - frmDelegateTryout.frmDelegateTryout_Click(System.Object, System.EventArgs) Handles this.Click
      // Calls
      //   - CallBack() As cpCallBack (Get)
      // Created
      //   - CopyPaste – 20250713 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250713 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***  
    {
      int lngResult = CallBack("Test 123");

      MessageBox.Show(lngResult.ToString());
    }
    // TestDelegate()

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDelegate

}
// CopyPaste.Learning