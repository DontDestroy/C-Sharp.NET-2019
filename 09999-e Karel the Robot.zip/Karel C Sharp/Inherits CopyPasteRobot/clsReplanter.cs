﻿//***
// Action
//   - A definition of a Replanter
// Created
//   - CopyPaste – 20251016 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251016 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpReplanter: cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpReplanter(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpReplanter starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpReplanter(int, int, Directions.Direction, int)
    //   - cpReplantField(int, int, Directions.Direction, int, Color) 
    // Calls
    //   - cpReplanter(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251016 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251016 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpReplanter(int, int, Directions.Direction, int, Color) 

    public cpReplanter(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpReplanter starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpReplanter(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251015 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251015 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpReplanter(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void PositionForNextReplant()
    //***
    // Action
    //   - Turn to the left (looking North)
    //   - Go one forward (move up)
    //   - Turn to the left (looking West)
    // Called by
    //   - cpReplantFieldMultipleFiles.ReplantTheField()
    // Calls
    //   - cpCopyPasteRobot.TurnRight()
    // Created
    //   - CopyPaste – 20251016 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251016 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      TurnRight();
      move();
      TurnRight();
    }
    // PositionForNextReplant()

    private void PositionForNextRow()
    //***
    // Action
    //   - Turn to the left (looking North)
    //   - Go one forward (move up)
    //   - Turn to the left (looking West)
    // Called by
    //   - ReplantTwoRows()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251016 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251016 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      turnLeft();
      move();
      turnLeft();
    }
    // PositionForNextRow()

    public virtual void ReplantCorner()
    //***
    // Action
    //   - Pick the beeper at that position
    //   - Put beeper
    // Called by
    //   - ReplantOneRow()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251016 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251016 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      pickBeeper();
			putBeeper();
		}
    // ReplantCorner()

    private void ReplantOneRow()
    //***
    // Action
    //   - Replant corner
    //   - Move forward
    //   - Repeat this another 3 times
    //   - Replant corner
    // Called by
    //   - ReplantTwoRows()
    // Calls
    //   - ReplantCorner()
    // Created
    //   - CopyPaste – 20251016 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251016 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ReplantCorner();
      move();
      ReplantCorner();
      move();
      ReplantCorner();
      move();
      ReplantCorner();
      move();
      ReplantCorner();
    }
    // ReplantOneRow()

    public void ReplantTwoRows()
    //***
    // Action
    //   - Replant one row (going from left to right)
    //   - Position for the row above
    //     - Go one row up
    //     - Look to the other direction (look to the left)
    //   - Replant one row (going from right to left)
    // Called by
    //   - cpReplantFieldMultipleFiles.ReplantTheField()
    // Calls
    //   - PositionForNextRow()
    //   - ReplantOneRow()
    // Created
    //   - CopyPaste – 20251016 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251016 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ReplantOneRow();
      PositionForNextRow();
      ReplantOneRow();
    }
    // ReplantTwoRows()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpReplanter

}
// cpKarelTheRobot