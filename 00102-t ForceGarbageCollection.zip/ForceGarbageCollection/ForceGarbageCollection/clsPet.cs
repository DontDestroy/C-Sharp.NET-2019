//***
// Action
//   - Implementation of cpPet
// Created
//   - CopyPaste � 20230802 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230802 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpPet
	{

    #region "Constructors / Destructors"
 
    public cpPet(string strType, string strName, double dblPrice)
    //***
    // Action
    //   - Constructor of cpPet
    //   - Define a Type, Name and Price
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230802 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230802 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      mstrType = strType;
      mstrName = strName;
      mdblPrice = dblPrice;
    }
    // cpPet(string, string, double) 

    ~cpPet()
    //***
    // Action
    //   - Finalizer of cpPet
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230802 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230802 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***

    {

      try
      {
        Console.WriteLine("In Finalize for " + mstrType);
      }
      catch (Exception theException)
      {
      }

    }
    // ~cpPet()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public double mdblPrice;
    public string mstrName;
    public string mstrType;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

	}
  // cpPet

}
// CopyPaste.Learning