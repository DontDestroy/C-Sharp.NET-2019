//***
// Action
//   - Testroutine for cpStudent
// Created
//   - CopyPaste � 20230530 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230530 � VVDW
// Proposal (To Do)
//   - 
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"

    static void CreateSomeStudents()
    //***
    // Action
    //   - Create 300 instances of a cpStudent
    //   - Show in between the number of students there are
    //   - Destroy the 297 instances of cpStudent that became obsolete (because they are garbage)
    //   - Show in between the number of studens there are
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - ~cpStudent()
    //   - cpStudent(string, long)
    // Created
    //   - CopyPaste � 20230530 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230530 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpStudent theStudentBill;
      cpStudent theStudentJill;
      cpStudent theStudentJoe;

      for (int aCounter = 0; aCounter < 100; aCounter++)
      {
        theStudentJoe = new cpStudent("Joe Smith", 11);
      }
      // aCounter = 100

      Console.WriteLine("Student count {0}", cpStudent.mlngStudentCount);

      for (int aCounter = 0; aCounter < 100; aCounter++)
      {
        theStudentBill = new cpStudent("Bill Davis", 10);
      }
      // aCounter = 100

      Console.WriteLine("Student count {0}", cpStudent.mlngStudentCount);

      for (int aCounter = 0; aCounter < 100; aCounter++)
      {
        theStudentJill = new cpStudent("Jill Willis", 11);
      }
      // aCounter = 100

      Console.WriteLine("Student count {0}", cpStudent.mlngStudentCount);

      theStudentJill = null;
      theStudentBill = null;
      theStudentJoe = null;

      GC.Collect();
      GC.WaitForPendingFinalizers();

      Console.WriteLine("Student count {0}", cpStudent.mlngStudentCount);
    }
    // CreateSomeStudents()

    static void Main()
    //***
    // Action
    //   - Create some students
    //   - Clean up the memory
    //   - Show in between the number of studens there are
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - CreateSomeStudents()
    // Created
    //   - CopyPaste � 20230530 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230530 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      CreateSomeStudents();
      GC.Collect();
      GC.WaitForPendingFinalizers();

      Console.WriteLine("Student count {0}", cpStudent.mlngStudentCount);
      Console.ReadLine();
    }
    // Main()

    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// CopyPaste.Learning