﻿//***
// Action
//   - Working with a fixed connectionstring
// Created
//   - CopyPaste – 20251209 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251209 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpConnectionString
  {

    #region "Constructors / Destructors"

    public cpConnectionString()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - frmListBoxAddDeleteTryout.LoadList()
      //   - frmListBoxAddDeleteTryout.RefreshIndividual()
      //   - frmListBoxUpdateTryout.LoadList()
      //   - frmListBoxUpdateTryout.RefreshIndividual()
      //   - frmStoredProcedureTryout.cmdView_Click(System.Object, System.EventArgs) Handles cmdView.Click
      //   - frmUpdateOnTheFlyTryout.cmdExecute_Click(System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdExecute.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251209 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251209 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpConnectionString()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string BuildConnectionString()
      //***
      // Action
      //   - Returning a hardcoded connectionstring
      // Called by
      //   - frmListBoxAddDeleteTryout.LoadList()
      //   - frmListBoxAddDeleteTryout.RefreshIndividual()
      //   - frmListBoxUpdateTryout.LoadList()
      //   - frmListBoxUpdateTryout.RefreshIndividual()
      //   - frmStoredProcedureTryout.cmdView_Click(System.Object, System.EventArgs) Handles cmdView.Click
      //   - frmUpdateOnTheFlyTryout.cmdExecute_Click(System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdExecute.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251209 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251209 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {     
      return "workstation id=COPYPASTESERVER;packet size=4096;integrated security=SSPI;data source=COPYPASTESERVER\\COPYPASTESERVER;persist security info=False;initial catalog=cpNorthWindScript2005";
    }
    // string BuildConnectionString()
		
		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpConnectionString

}
// CopyPaste.Learning