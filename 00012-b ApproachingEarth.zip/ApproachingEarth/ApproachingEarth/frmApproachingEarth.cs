//***
// Action
//   - Simulate an approaching earth
// Created
//   - CopyPaste � 20230614 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230614 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmApproachingEarth : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    internal System.Windows.Forms.PictureBox picEarth;
    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmApproachingEarth));
      this.picEarth = new System.Windows.Forms.PictureBox();
      this.SuspendLayout();
      // 
      // picEarth
      // 
      this.picEarth.Image = ((System.Drawing.Image)(resources.GetObject("picEarth.Image")));
      this.picEarth.Location = new System.Drawing.Point(72, 48);
      this.picEarth.Name = "picEarth";
      this.picEarth.Size = new System.Drawing.Size(24, 24);
      this.picEarth.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picEarth.TabIndex = 1;
      this.picEarth.TabStop = false;
      this.picEarth.Click += new System.EventHandler(this.picEarth_Click);
      // 
      // frmApproachingEarth
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.picEarth);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmApproachingEarth";
      this.Text = "Approaching Earth";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmApproachingEarth'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmApproachingEarth()
    //***
    // Action
    //   - Create instance of 'frmApproachingEarth'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // frmApproachingEarth()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void picEarth_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change size of picture with 5 points
    // Called by
    //   - User action (Clicking a picture)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      picEarth.Height = picEarth.Height + 5;
      picEarth.Width = picEarth.Width + 5;
    }
    // picEarth_Click(System.Object, System.EventArgs) Handles picEarth.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmApproachingEarth
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230614 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230614 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmApproachingEarth());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmApproachingEarth

}
// CopyPaste.Learning