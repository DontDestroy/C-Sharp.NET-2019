﻿//***
// Action
//   - A definition of a BeeperFinder
// Created
//   - CopyPaste – 20251030 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251030 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpBeeperFinder : cpCopyPasteRobot
	{

    #region "Constructors / Destructors"

    public cpBeeperFinder(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpBeeperFinder starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpBeeperFinder(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpBeeperFinder(int, int, Directions.Direction, int) 

    public cpBeeperFinder(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpBeeperFinder starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpBeeperFinder(int, int, Directions.Direction, int) 
    //   - cpProgram.BeeperFinder()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpBeeperFinder(int, int, Directions.Direction, int, Color) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void FindBeeper()
    //***
    // Action
    //   - If next to a beeper
    //     - Do nothing (routine has this exit point)
    //   - If not
    //     - Move one forward
    //     - Restart routine
    // Called by
    //   - FindBeeper()
    //   - RetrieveBeeper()
    // Calls
    //   - FindBeeper()
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (nextToABeeper())
      {
      }
      else
      // Not nextToABeeper()
      {
        move();
        FindBeeper();
      }
      // nextToABeeper()

    }
    // FindBeeper()

    public void RetrieveBeeper()
    //***
    // Action
    //   - Find the beeper
    //   - Pick the beeper
    //   - Go back to the origin
    // Called by
    //   - cpProgram.Recursion()
    // Calls
    //   - cpCopyPasteRobot.GoToStartPosition()
    //   - FindBeeper()
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      FindBeeper();
      pickBeeper();
      GoToStartPosition();
    }
    // RetrieveBeeper()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBeeperFinder

}
// cpKarelTheRobot