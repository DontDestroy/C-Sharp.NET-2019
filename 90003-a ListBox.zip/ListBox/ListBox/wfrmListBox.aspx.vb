﻿'***
' Action
'   - Example of a listbox in a web page
' Created
'   - CopyPaste – 20260415 – VVDW
' Changed
'   - CopyPaste – yyyymmdd – VVDW – What changed
' Tested
'   - CopyPaste – 20260415 – VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On
Option Strict On

Namespace CopyPaste.Learning

  Public Class wfrmListBox
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      Me.ID = "wfrmListBox"

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Init
      'CODEGEN: This method call is required by the Web Form Designer
      'Do not modify it using the code editor.
      InitializeComponent()
    End Sub

#End Region

    '#Region "Constructors"
    '#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

    '#Region "Fields"
    '#End Region

    '#Region "Properties"
    '#End Region

#Region "Methods"

    '#Region "Overrides"
    '#End Region

#Region "Controls"

    Private Sub cmdOK_Click(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles cmdOK.Click
      '***
      ' Action
      '   - Try to
      '     - If there is something selected
      '       - Set label on form what value, what item and what text has been selected
      '     - If not
      '       - Set label on form that something must be selected
      '   - On possible error
      '     - Set label on form that something must be selected
      ' Called by
      '   - User action (Clicking a button)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20260415 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260415 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      Try

        If lstName.SelectedIndex = -1 Then
          lblResult.Text = "You have to select a name"
        Else
          lblResult.Text = "You have choosen: " & lstName.SelectedItem.Value & " (" &
            lstName.SelectedIndex + 1 & "°) item with name : " &
            lstName.SelectedItem.Text
        End If

      Catch theException As NullReferenceException
        lblResult.Text = "You have to select a name"
      End Try

    End Sub
    ' cmdOK_Click(System.Object, System.EventArgs) Handles cmdOK.Click

    Private Sub Page_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles MyBase.Load
      '***
      ' Action
      '   - 
      ' Called by
      '   - User action (Loading the page)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20260415 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260415 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

    End Sub
    ' Page_Load(System.Object, System.EventArgs) Handles MyBase.Load

    Private Sub lstName_SelectedIndexChanged(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles lstName.SelectedIndexChanged
      '***
      ' Action
      '   - Define a list item
      '   - Loop thru all the list items
      '     - Set all items with first letter as capital, and all other letters small
      '   - Selected item becomes full in capitals
      ' Called by
      '   - User action (Loading the page)
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste – 20260415 – VVDW
      ' Changed
      '   - CopyPaste – yyyymmdd – VVDW – What changed
      ' Tested
      '   - CopyPaste – 20260415 – VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      Dim theListItem As ListItem

      For Each theListItem In lstName.Items
        theListItem.Text = theListItem.Text.Substring(0, 1).ToUpper & theListItem.Text.Substring(1).ToLower
      Next theListItem
      ' In lstName.Items

      lstName.SelectedItem.Text = lstName.SelectedItem.Text.ToUpper
    End Sub
    ' lstName_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstName.SelectedIndexChanged

#End Region

    '#Region "Functionality"

    '#Region "Event"
    '#End Region

    '#Region "Sub / Function"
    '#End Region

    '#End Region

#End Region

    '#Region "Not used"
    '#End Region

  End Class
  ' wfrmListBox

End Namespace
' CopyPaste.Learning