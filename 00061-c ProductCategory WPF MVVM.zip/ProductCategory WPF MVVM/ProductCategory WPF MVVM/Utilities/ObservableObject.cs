﻿//***
// Action
//   - Class that handles the property changed code
// Created
//   - CopyPaste – 20220824 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220824 – VVDW
// Proposal (To Do)
//   -
//***

using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace ProductCategory_WPF_MVVM.Utilities
{

  public class ObservableObject : INotifyPropertyChanged
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public event PropertyChangedEventHandler PropertyChanged;

    #endregion

    #region "Sub / Function"

    protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = "")
    //***
    // Action
    //   - Code that runs when a property is changed
    //   - CallerMemberNameAttribute allow you to obtain the property or method name of the caller
    //   - Invoke the change of the property (synchronous)
    // Called by
    //   - 
    // Calls
    //   - CallerMemberNameAttribute
    // Created
    //   - CopyPaste – 20220824 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220824 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
    // OnPropertyChanged(string)

    protected virtual bool OnPropertyChanged<T>(ref T backingField, T value, [CallerMemberName] string propertyName = "")
    //***
    // Action
    //   - Code that runs when a property is changed
    //   - CallerMemberNameAttribute allow you to obtain the property or method name of the caller
    //   - Something changes into something else
    //   - If the change is not different
    //     - Return false
    //   - If Not
    //     - Remember the go back value
    //     - Execute the change
    //     - Return true
    // Called by
    //   - Product.Category?(ProductCategory) (Set)
    //   - Product.IntroductionDate(DateTime) (Set)
    //   - Product.Key(int) (Set)
    //   - Product.Name(string) (Set)
    //   - Product.Price(decimal) (Set)
    //   - Product.RetireDate?(DateTime) (Set)
    //   - Product.Url(string) (Set)
    //   - ProductCategory.Key(int) (Set)
    //   - ProductCategory.Name(string) (Set)
    //   - ProductCategoryViewModel.SelectedProductCategory(ProductCategory) (Set)
    //   - ProductCategoryViewModel.ProductCategoryCollection(ObservableCollection<ProductCategory>) (Set)
    //   - StartupViewModel.ProductCategoryViewModel(ProductCategoryViewModel) (Set)
    // Calls
    //   - CallerMemberNameAttribute
    //   - OnPropertyChanged(string)
    // Created
    //   - CopyPaste – 20220824 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220824 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      if (EqualityComparer<T>.Default.Equals(backingField, value))
      {
        return false;
      }
      // Not EqualityComparer<T>.Default.Equals(backingField, value)
      else
      {
        backingField = value;
        OnPropertyChanged(propertyName);
        return true;
      }
      // EqualityComparer<T>.Default.Equals(backingField, value)

    }
    // bool OnPropertyChanged<T>(°T, T, string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // ObservableObject

}
// ProductCategory_WPF_MVVM.Utilities