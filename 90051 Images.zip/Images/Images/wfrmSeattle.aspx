﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmSeattle.aspx.cs" Inherits="CopyPaste.Learning.wfrmSeattle" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>myPod: Seattle Ferry</title>
  <style type="text/css">
    body {
      background-color: #eaf3da;
    }
  </style>
</head>
<body>
  <form id="wfrmSeattle" runat="server">
    <h1>Video iPod on the Seattle Ferry</h1>
    <p>
      <img src="../Resources/Seattle_Medium.jpg" alt="The skyline of Seattle" />
    </p>
  </form>
</body>
</html>
