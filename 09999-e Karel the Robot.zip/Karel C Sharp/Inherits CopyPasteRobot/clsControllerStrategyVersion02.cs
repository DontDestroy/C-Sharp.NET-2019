﻿//***
// Action
//   - A definition of an ControllerStrategyVersion02
//     - Implementation of a NullControllerInside
//     - Implementation of a LeftTurnControllerInside
//     - Implementation of a RightTurnControllerInside
// Created
//   - CopyPaste – 20251030 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251030 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpControllerStrategyVersion02 : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpControllerStrategyVersion02(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpControllerStrategyVersion02 starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Define the current turn as a cpLeftTurnControllerInside
    //   - Define the other turn as a cpRightTurnControllerInside
    // Called by
    //   - cpProgram.ControllerStrategyVersion01()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      currentTurn = new cpLeftTurnControllerInside(this);
      otherTurn = new cpRightTurnControllerInside(this);
    }
    // cpControllerStrategyVersion01(int, int, Directions.Direction, int, Color) 

    public cpControllerStrategyVersion02(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpControllerStrategyVersion02 starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpControllerStrategyVersion02(int, int, Directions.Direction, int, Color, cpinfStrategy) 
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpControllerStrategyVersion02(int, int, Directions.Direction, int) 

    #endregion

    #region "Designer"

    public class cpLeftTurnControllerInside : cpinfController
    {

      #region "Constructors / Destructors"

      public cpLeftTurnControllerInside(cpCopyPasteRobot aRobot)
      //***
      // Action
      //   - Basic constructor (start situation)
      //   - If the given aRobot is null
      //     - The internal robot becomes a new default cpCopyPasteRobot will be created
      //   - If not
      //     - The internal robot becomes the given aRobot (when it is not null)
      //   - Nothing else happens
      // Called by
      //   - cpControllerStrategyVersion02(int, int, Directions.Direction, int, Color) 
      // Calls
      //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color) 
      // Created
      //   - CopyPaste – 20251030 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251030 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if (aRobot == null)
        {
          theInternalRobot = new cpCopyPasteRobot();
        }
        else
        // aRobot <> null
        {
          theInternalRobot = aRobot;
        }
        // aRobot = null

      }
      // cpLeftTurnControllerInside(cpCopyPasteRobot) 

      #endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      #region "Fields"

      private cpCopyPasteRobot theInternalRobot = null;

      #endregion

      //#region "Properties"
      //#endregion

      #region "Methods"

      //#region "Overrides"
      //#endregion

      //#region "Controls"
      //#endregion

      #region "Functionality"

      //#region "Event"
      //#endregion

      #region "Sub / Function"

      public void ControlIt()
      //***
      // Action
      //   - Implementation of ControlIT
      //     - Turn to the left
      //     - Move one forward
      //     - Turn to the left
      // Called by
      //   - cpControllerStrategyVersion02.Turn()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251030 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251030 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        theInternalRobot.turnLeft();
        theInternalRobot.move();
        theInternalRobot.turnLeft();
      }
      // ControlIt()

      #endregion

      #endregion

      #endregion

      //#region "Not used"
      //#endregion

    }
    // cpLeftTurnControllerInside

    public class cpNullControllerInside : cpinfController
    {

      //#region "Constructors / Destructors"
      //#endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      //#region "Fields"
      //#endregion

      //#region "Properties"
      //#endregion

      #region "Methods"

      //#region "Overrides"
      //#endregion

      //#region "Controls"
      //#endregion

      #region "Functionality"

      //#region "Event"
      //#endregion

      #region "Sub / Function"

      public void ControlIt()
      //***
      // Action
      //   - Implementation of ControlIT
      //     - Do nothing
      //   - No action will be executed by the Controller
      // Called by
      //   -
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251030 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251030 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
      }
      // ControlIt()

      #endregion

      #endregion

      #endregion

      //#region "Not used"
      //#endregion

    }
    // cpNullControllerInside

    public class cpRightTurnControllerInside : cpinfController
    {

      #region "Constructors / Destructors"

      public cpRightTurnControllerInside(cpCopyPasteRobot aRobot)
      //***
      // Action
      //   - Basic constructor (start situation)
      //   - If the given aRobot is null
      //     - The internal robot becomes a new default cpCopyPasteRobot will be created
      //   - If not
      //     - The internal robot becomes the given aRobot (when it is not null)
      //   - Nothing else happens
      // Called by
      //   - cpControllerStrategyVersion02(int, int, Directions.Direction, int, Color) 
      // Calls
      //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color) 
      // Created
      //   - CopyPaste – 20251030 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251030 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if (aRobot == null)
        {
          theInternalRobot = new cpCopyPasteRobot();
        }
        else
        // aRobot <> null
        {
          theInternalRobot = aRobot;
        }
        // aRobot = null

      }
      // cpRightTurnControllerInside(cpCopyPasteRobot)

      #endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      #region "Fields"

      private cpCopyPasteRobot theInternalRobot = null;

      #endregion

      //#region "Properties"
      //#endregion

      #region "Methods"

      //#region "Overrides"
      //#endregion

      //#region "Controls"
      //#endregion

      #region "Functionality"

      //#region "Event"
      //#endregion

      #region "Sub / Function"

      public void ControlIt()
      //***
      // Action
      //   - Implementation of ControlIT
      //     - Turn to the right
      //     - Move one forward
      //     - Turn to the right
      // Called by
      //   - cpControllerStrategyVersion02.Turn()
      // Calls
      //   - cpCopyPasteRobot.TurnRight()
      // Created
      //   - CopyPaste – 20251030 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251030 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        theInternalRobot.TurnRight();
        theInternalRobot.move();
        theInternalRobot.TurnRight();
      }
      // ControlIt()

      #endregion

      #endregion

      #endregion

      //#region "Not used"
      //#endregion

    }
    // cpRightTurnControllerInside

    #endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpinfController currentTurn;
    private cpinfController otherTurn;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void LayRow()
    //***
    // Action
    //   - Robot repeats this 4 times
    //     - Put beeper
    //     - Move one forward
    //   - Put last beeper
    // Called by
    //   - cpProgram.ControllerStrategyVersion02()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      for (int beeperCounter = 0; beeperCounter < 4; beeperCounter++)
      {
        putBeeper();
        move();
      }
      // beeperCounter = 4

      putBeeper();
    }
    // LayRow()

    public void Turn()
    //***
    // Action
    //   - Robot turns by executing the current turn controller
    //   - Current turn controller is swapped with other turn controller
    // Called by
    //   - cpProgram.ControllerStrategyVersion02()
    // Calls
    //   - cpLeftTurnControllerInside.ControlIt()
    //   - cpRightTurnControllerInside.ControlIt()
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpinfController temporaryController;

      currentTurn.ControlIt();
      temporaryController = currentTurn;
      currentTurn = otherTurn;
      otherTurn = temporaryController;
    }
    // Turn()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpControllerStrategyVersion02

}
// cpKarelTheRobot