//***
// Action
//   - Play around with XML information linked to a data set
// Created
//   - CopyPaste � 20251128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251128 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using System.Xml;

namespace CopyPaste.Learning
{

  public class frmXML: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Panel panHorizontalLine02;
    internal System.Windows.Forms.Panel panHorizontalLine01;
    internal System.Windows.Forms.Button cmdDocument;
    internal System.Windows.Forms.Button cmdAttributes;
    internal System.Windows.Forms.Button cmdWriteNested;
    internal System.Windows.Forms.Button cmdReadData;
    internal System.Windows.Forms.Button cmdInferSchema;
    internal System.Windows.Forms.Button cmdWriteData;
    internal System.Data.SqlClient.SqlCommand SqlInsertCommand1;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwind2005;
    internal System.Data.SqlClient.SqlCommand cmmUpdateProduct;
    internal System.Data.SqlClient.SqlCommand SqlSelectCommand1;
    internal System.Data.SqlClient.SqlCommand SqlDeleteCommand1;
    internal System.Data.SqlClient.SqlCommand SqlUpdateCommand1;
    internal System.Data.SqlClient.SqlCommand cmmSelectProduct;
    internal System.Data.SqlClient.SqlCommand cmmInsertProduct;
    internal System.Data.SqlClient.SqlCommand cmmDeleteProduct;
    internal System.Windows.Forms.Button cmdReadSchema;
    internal System.Windows.Forms.Button cmdGetXml;
    internal System.Windows.Forms.Button cmdWriteSchema;
    internal System.Windows.Forms.TextBox txtPosition;
    internal System.Windows.Forms.TextBox txtCategoryDescription;
    internal System.Windows.Forms.TextBox txtCategoryName;
    internal System.Windows.Forms.TextBox txtIdCategory;
    internal System.Windows.Forms.Label lblDescription;
    internal System.Windows.Forms.Label lblCategoryName;
    internal System.Windows.Forms.Label lblCategoryKey;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Button cmdLast;
    internal System.Windows.Forms.Button cmdPrevious;
    internal System.Windows.Forms.Button cmdFirst;
    internal System.Data.SqlClient.SqlDataAdapter dtaProduct;
    internal System.Windows.Forms.DataGrid dgrProducts;
    internal System.Data.SqlClient.SqlDataAdapter dtaCategory;
    private XML.dsData dsData;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmXML));
      this.panHorizontalLine02 = new System.Windows.Forms.Panel();
      this.panHorizontalLine01 = new System.Windows.Forms.Panel();
      this.cmdDocument = new System.Windows.Forms.Button();
      this.cmdAttributes = new System.Windows.Forms.Button();
      this.cmdWriteNested = new System.Windows.Forms.Button();
      this.cmdReadData = new System.Windows.Forms.Button();
      this.cmdInferSchema = new System.Windows.Forms.Button();
      this.cmdWriteData = new System.Windows.Forms.Button();
      this.SqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
      this.cnncpNorthwind2005 = new System.Data.SqlClient.SqlConnection();
      this.cmmUpdateProduct = new System.Data.SqlClient.SqlCommand();
      this.SqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
      this.SqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
      this.SqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
      this.cmmSelectProduct = new System.Data.SqlClient.SqlCommand();
      this.cmmInsertProduct = new System.Data.SqlClient.SqlCommand();
      this.cmmDeleteProduct = new System.Data.SqlClient.SqlCommand();
      this.cmdReadSchema = new System.Windows.Forms.Button();
      this.cmdGetXml = new System.Windows.Forms.Button();
      this.cmdWriteSchema = new System.Windows.Forms.Button();
      this.txtPosition = new System.Windows.Forms.TextBox();
      this.txtCategoryDescription = new System.Windows.Forms.TextBox();
      this.txtCategoryName = new System.Windows.Forms.TextBox();
      this.txtIdCategory = new System.Windows.Forms.TextBox();
      this.lblDescription = new System.Windows.Forms.Label();
      this.lblCategoryName = new System.Windows.Forms.Label();
      this.lblCategoryKey = new System.Windows.Forms.Label();
      this.cmdNext = new System.Windows.Forms.Button();
      this.cmdLast = new System.Windows.Forms.Button();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.cmdFirst = new System.Windows.Forms.Button();
      this.dtaProduct = new System.Data.SqlClient.SqlDataAdapter();
      this.dgrProducts = new System.Windows.Forms.DataGrid();
      this.dtaCategory = new System.Data.SqlClient.SqlDataAdapter();
      this.dsData = new XML.dsData();
      ((System.ComponentModel.ISupportInitialize)(this.dgrProducts)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.SuspendLayout();
      // 
      // panHorizontalLine02
      // 
      this.panHorizontalLine02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.panHorizontalLine02.Location = new System.Drawing.Point(348, 215);
      this.panHorizontalLine02.Name = "panHorizontalLine02";
      this.panHorizontalLine02.Size = new System.Drawing.Size(88, 1);
      this.panHorizontalLine02.TabIndex = 42;
      // 
      // panHorizontalLine01
      // 
      this.panHorizontalLine01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.panHorizontalLine01.Location = new System.Drawing.Point(348, 111);
      this.panHorizontalLine01.Name = "panHorizontalLine01";
      this.panHorizontalLine01.Size = new System.Drawing.Size(88, 1);
      this.panHorizontalLine01.TabIndex = 38;
      this.panHorizontalLine01.TabStop = true;
      // 
      // cmdDocument
      // 
      this.cmdDocument.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdDocument.Location = new System.Drawing.Point(348, 287);
      this.cmdDocument.Name = "cmdDocument";
      this.cmdDocument.Size = new System.Drawing.Size(88, 23);
      this.cmdDocument.TabIndex = 45;
      this.cmdDocument.Text = "Document";
      this.cmdDocument.Click += new System.EventHandler(this.cmdDocument_Click);
      // 
      // cmdAttributes
      // 
      this.cmdAttributes.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdAttributes.Location = new System.Drawing.Point(348, 255);
      this.cmdAttributes.Name = "cmdAttributes";
      this.cmdAttributes.Size = new System.Drawing.Size(88, 23);
      this.cmdAttributes.TabIndex = 44;
      this.cmdAttributes.Text = "Attributes";
      this.cmdAttributes.Click += new System.EventHandler(this.cmdAttributes_Click);
      // 
      // cmdWriteNested
      // 
      this.cmdWriteNested.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdWriteNested.Location = new System.Drawing.Point(348, 47);
      this.cmdWriteNested.Name = "cmdWriteNested";
      this.cmdWriteNested.Size = new System.Drawing.Size(88, 23);
      this.cmdWriteNested.TabIndex = 36;
      this.cmdWriteNested.Text = "Write Nested";
      this.cmdWriteNested.Click += new System.EventHandler(this.cmdWriteNested_Click);
      // 
      // cmdReadData
      // 
      this.cmdReadData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdReadData.Location = new System.Drawing.Point(348, 119);
      this.cmdReadData.Name = "cmdReadData";
      this.cmdReadData.Size = new System.Drawing.Size(88, 23);
      this.cmdReadData.TabIndex = 39;
      this.cmdReadData.Text = "Read Data";
      this.cmdReadData.Click += new System.EventHandler(this.cmdReadData_Click);
      // 
      // cmdInferSchema
      // 
      this.cmdInferSchema.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdInferSchema.Location = new System.Drawing.Point(348, 183);
      this.cmdInferSchema.Name = "cmdInferSchema";
      this.cmdInferSchema.Size = new System.Drawing.Size(88, 23);
      this.cmdInferSchema.TabIndex = 41;
      this.cmdInferSchema.Text = "Infer Schema";
      this.cmdInferSchema.Click += new System.EventHandler(this.cmdInferSchema_Click);
      // 
      // cmdWriteData
      // 
      this.cmdWriteData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdWriteData.Location = new System.Drawing.Point(348, 15);
      this.cmdWriteData.Name = "cmdWriteData";
      this.cmdWriteData.Size = new System.Drawing.Size(88, 23);
      this.cmdWriteData.TabIndex = 35;
      this.cmdWriteData.Text = "Write Data";
      this.cmdWriteData.Click += new System.EventHandler(this.cmdWriteData_Click);
      // 
      // SqlInsertCommand1
      // 
      this.SqlInsertCommand1.CommandText = resources.GetString("SqlInsertCommand1.CommandText");
      this.SqlInsertCommand1.Connection = this.cnncpNorthwind2005;
      this.SqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@intIdCategory", System.Data.SqlDbType.Int, 4, "intIdCategory"),
            new System.Data.SqlClient.SqlParameter("@strCategoryName", System.Data.SqlDbType.VarChar, 15, "strCategoryName"),
            new System.Data.SqlClient.SqlParameter("@memDescription", System.Data.SqlDbType.VarChar, 2147483647, "memDescription")});
      // 
      // cnncpNorthwind2005
      // 
      this.cnncpNorthwind2005.ConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthwind2005.FireInfoMessageEventOnUserErrors = false;
      // 
      // cmmUpdateProduct
      // 
      this.cmmUpdateProduct.CommandText = resources.GetString("cmmUpdateProduct.CommandText");
      this.cmmUpdateProduct.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@intIdProduct", System.Data.SqlDbType.Int, 4, "intIdProduct"),
            new System.Data.SqlClient.SqlParameter("@strProductName", System.Data.SqlDbType.VarChar, 40, "strProductName"),
            new System.Data.SqlClient.SqlParameter("@intSupplierId", System.Data.SqlDbType.Int, 4, "intSupplierId"),
            new System.Data.SqlClient.SqlParameter("@intCategoryId", System.Data.SqlDbType.Int, 4, "intCategoryId"),
            new System.Data.SqlClient.SqlParameter("@strQuantityPerUnit", System.Data.SqlDbType.VarChar, 20, "strQuantityPerUnit"),
            new System.Data.SqlClient.SqlParameter("@dblUnitPrice", System.Data.SqlDbType.Money, 8, "dblUnitPrice"),
            new System.Data.SqlClient.SqlParameter("@intUnitsInStock", System.Data.SqlDbType.SmallInt, 2, "intUnitsInStock"),
            new System.Data.SqlClient.SqlParameter("@intUnitsOnOrder", System.Data.SqlDbType.SmallInt, 2, "intUnitsOnOrder"),
            new System.Data.SqlClient.SqlParameter("@intReorderLevel", System.Data.SqlDbType.SmallInt, 2, "intReorderLevel"),
            new System.Data.SqlClient.SqlParameter("@blnDiscontinued", System.Data.SqlDbType.Bit, 1, "blnDiscontinued"),
            new System.Data.SqlClient.SqlParameter("@Original_intIdProduct", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdProduct", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_blnDiscontinued", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "blnDiscontinued", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dblUnitPrice", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblUnitPrice", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intCategoryId", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intReorderLevel", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReorderLevel", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intSupplierId", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intSupplierId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intUnitsInStock", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsInStock", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intUnitsOnOrder", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsOnOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strProductName", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strProductName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strQuantityPerUnit", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strQuantityPerUnit", System.Data.DataRowVersion.Original, null)});
      // 
      // SqlSelectCommand1
      // 
      this.SqlSelectCommand1.CommandText = "SELECT intIdCategory, strCategoryName, memDescription FROM tblCPCategory";
      this.SqlSelectCommand1.Connection = this.cnncpNorthwind2005;
      // 
      // SqlDeleteCommand1
      // 
      this.SqlDeleteCommand1.CommandText = "DELETE FROM tblCPCategory WHERE (intIdCategory = @Original_intIdCategory) AND (st" +
    "rCategoryName = @Original_strCategoryName)";
      this.SqlDeleteCommand1.Connection = this.cnncpNorthwind2005;
      this.SqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_intIdCategory", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdCategory", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCategoryName", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCategoryName", System.Data.DataRowVersion.Original, null)});
      // 
      // SqlUpdateCommand1
      // 
      this.SqlUpdateCommand1.CommandText = resources.GetString("SqlUpdateCommand1.CommandText");
      this.SqlUpdateCommand1.Connection = this.cnncpNorthwind2005;
      this.SqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@intIdCategory", System.Data.SqlDbType.Int, 4, "intIdCategory"),
            new System.Data.SqlClient.SqlParameter("@strCategoryName", System.Data.SqlDbType.VarChar, 15, "strCategoryName"),
            new System.Data.SqlClient.SqlParameter("@memDescription", System.Data.SqlDbType.VarChar, 2147483647, "memDescription"),
            new System.Data.SqlClient.SqlParameter("@Original_intIdCategory", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdCategory", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCategoryName", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCategoryName", System.Data.DataRowVersion.Original, null)});
      // 
      // cmmSelectProduct
      // 
      this.cmmSelectProduct.CommandText = "SELECT intIdProduct, strProductName, intSupplierId, intCategoryId, strQuantityPer" +
    "Unit, dblUnitPrice, intUnitsInStock, intUnitsOnOrder, intReorderLevel, blnDiscon" +
    "tinued FROM tblCPProduct";
      this.cmmSelectProduct.Connection = this.cnncpNorthwind2005;
      // 
      // cmmInsertProduct
      // 
      this.cmmInsertProduct.CommandText = resources.GetString("cmmInsertProduct.CommandText");
      this.cmmInsertProduct.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@intIdProduct", System.Data.SqlDbType.Int, 4, "intIdProduct"),
            new System.Data.SqlClient.SqlParameter("@strProductName", System.Data.SqlDbType.VarChar, 40, "strProductName"),
            new System.Data.SqlClient.SqlParameter("@intSupplierId", System.Data.SqlDbType.Int, 4, "intSupplierId"),
            new System.Data.SqlClient.SqlParameter("@intCategoryId", System.Data.SqlDbType.Int, 4, "intCategoryId"),
            new System.Data.SqlClient.SqlParameter("@strQuantityPerUnit", System.Data.SqlDbType.VarChar, 20, "strQuantityPerUnit"),
            new System.Data.SqlClient.SqlParameter("@dblUnitPrice", System.Data.SqlDbType.Money, 8, "dblUnitPrice"),
            new System.Data.SqlClient.SqlParameter("@intUnitsInStock", System.Data.SqlDbType.SmallInt, 2, "intUnitsInStock"),
            new System.Data.SqlClient.SqlParameter("@intUnitsOnOrder", System.Data.SqlDbType.SmallInt, 2, "intUnitsOnOrder"),
            new System.Data.SqlClient.SqlParameter("@intReorderLevel", System.Data.SqlDbType.SmallInt, 2, "intReorderLevel"),
            new System.Data.SqlClient.SqlParameter("@blnDiscontinued", System.Data.SqlDbType.Bit, 1, "blnDiscontinued")});
      // 
      // cmmDeleteProduct
      // 
      this.cmmDeleteProduct.CommandText = resources.GetString("cmmDeleteProduct.CommandText");
      this.cmmDeleteProduct.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_intIdProduct", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdProduct", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_blnDiscontinued", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "blnDiscontinued", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dblUnitPrice", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblUnitPrice", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intCategoryId", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intReorderLevel", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReorderLevel", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intSupplierId", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intSupplierId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intUnitsInStock", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsInStock", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intUnitsOnOrder", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsOnOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strProductName", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strProductName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strQuantityPerUnit", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strQuantityPerUnit", System.Data.DataRowVersion.Original, null)});
      // 
      // cmdReadSchema
      // 
      this.cmdReadSchema.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdReadSchema.Location = new System.Drawing.Point(348, 151);
      this.cmdReadSchema.Name = "cmdReadSchema";
      this.cmdReadSchema.Size = new System.Drawing.Size(88, 23);
      this.cmdReadSchema.TabIndex = 40;
      this.cmdReadSchema.Text = "Read Schema";
      this.cmdReadSchema.Click += new System.EventHandler(this.cmdReadSchema_Click);
      // 
      // cmdGetXml
      // 
      this.cmdGetXml.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdGetXml.Location = new System.Drawing.Point(348, 223);
      this.cmdGetXml.Name = "cmdGetXml";
      this.cmdGetXml.Size = new System.Drawing.Size(88, 23);
      this.cmdGetXml.TabIndex = 43;
      this.cmdGetXml.Text = "GetXml";
      this.cmdGetXml.Click += new System.EventHandler(this.cmdGetXml_Click);
      // 
      // cmdWriteSchema
      // 
      this.cmdWriteSchema.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdWriteSchema.Location = new System.Drawing.Point(348, 79);
      this.cmdWriteSchema.Name = "cmdWriteSchema";
      this.cmdWriteSchema.Size = new System.Drawing.Size(88, 23);
      this.cmdWriteSchema.TabIndex = 37;
      this.cmdWriteSchema.Text = "Write Schema";
      this.cmdWriteSchema.Click += new System.EventHandler(this.cmdWriteSchema_Click);
      // 
      // txtPosition
      // 
      this.txtPosition.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.txtPosition.Location = new System.Drawing.Point(84, 320);
      this.txtPosition.Name = "txtPosition";
      this.txtPosition.Size = new System.Drawing.Size(170, 20);
      this.txtPosition.TabIndex = 32;
      // 
      // txtCategoryDescription
      // 
      this.txtCategoryDescription.Location = new System.Drawing.Point(108, 55);
      this.txtCategoryDescription.Multiline = true;
      this.txtCategoryDescription.Name = "txtCategoryDescription";
      this.txtCategoryDescription.Size = new System.Drawing.Size(224, 40);
      this.txtCategoryDescription.TabIndex = 28;
      // 
      // txtCategoryName
      // 
      this.txtCategoryName.Location = new System.Drawing.Point(108, 31);
      this.txtCategoryName.Name = "txtCategoryName";
      this.txtCategoryName.Size = new System.Drawing.Size(224, 20);
      this.txtCategoryName.TabIndex = 26;
      // 
      // txtIdCategory
      // 
      this.txtIdCategory.Location = new System.Drawing.Point(108, 7);
      this.txtIdCategory.Name = "txtIdCategory";
      this.txtIdCategory.Size = new System.Drawing.Size(100, 20);
      this.txtIdCategory.TabIndex = 24;
      // 
      // lblDescription
      // 
      this.lblDescription.AutoSize = true;
      this.lblDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblDescription.Location = new System.Drawing.Point(12, 59);
      this.lblDescription.Name = "lblDescription";
      this.lblDescription.Size = new System.Drawing.Size(75, 13);
      this.lblDescription.TabIndex = 27;
      this.lblDescription.Text = "Description:";
      // 
      // lblCategoryName
      // 
      this.lblCategoryName.AutoSize = true;
      this.lblCategoryName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblCategoryName.Location = new System.Drawing.Point(12, 35);
      this.lblCategoryName.Name = "lblCategoryName";
      this.lblCategoryName.Size = new System.Drawing.Size(97, 13);
      this.lblCategoryName.TabIndex = 25;
      this.lblCategoryName.Text = "Category Name:";
      // 
      // lblCategoryKey
      // 
      this.lblCategoryKey.AutoSize = true;
      this.lblCategoryKey.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblCategoryKey.Location = new System.Drawing.Point(12, 11);
      this.lblCategoryKey.Name = "lblCategoryKey";
      this.lblCategoryKey.Size = new System.Drawing.Size(86, 13);
      this.lblCategoryKey.TabIndex = 23;
      this.lblCategoryKey.Text = "Category Key:";
      // 
      // cmdNext
      // 
      this.cmdNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdNext.Location = new System.Drawing.Point(260, 320);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(32, 23);
      this.cmdNext.TabIndex = 33;
      this.cmdNext.Text = ">";
      this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
      // 
      // cmdLast
      // 
      this.cmdLast.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdLast.Location = new System.Drawing.Point(300, 320);
      this.cmdLast.Name = "cmdLast";
      this.cmdLast.Size = new System.Drawing.Size(32, 23);
      this.cmdLast.TabIndex = 34;
      this.cmdLast.Text = ">>|";
      this.cmdLast.Click += new System.EventHandler(this.cmdLast_Click);
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdPrevious.Location = new System.Drawing.Point(44, 320);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(32, 23);
      this.cmdPrevious.TabIndex = 31;
      this.cmdPrevious.Text = "<";
      this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
      // 
      // cmdFirst
      // 
      this.cmdFirst.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.cmdFirst.Location = new System.Drawing.Point(4, 320);
      this.cmdFirst.Name = "cmdFirst";
      this.cmdFirst.Size = new System.Drawing.Size(32, 23);
      this.cmdFirst.TabIndex = 30;
      this.cmdFirst.Text = "|<<";
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      // 
      // dtaProduct
      // 
      this.dtaProduct.DeleteCommand = this.cmmDeleteProduct;
      this.dtaProduct.InsertCommand = this.cmmInsertProduct;
      this.dtaProduct.SelectCommand = this.cmmSelectProduct;
      this.dtaProduct.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPProduct", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdProduct", "intIdProduct"),
                        new System.Data.Common.DataColumnMapping("strProductName", "strProductName"),
                        new System.Data.Common.DataColumnMapping("intSupplierId", "intSupplierId"),
                        new System.Data.Common.DataColumnMapping("intCategoryId", "intCategoryId"),
                        new System.Data.Common.DataColumnMapping("strQuantityPerUnit", "strQuantityPerUnit"),
                        new System.Data.Common.DataColumnMapping("dblUnitPrice", "dblUnitPrice"),
                        new System.Data.Common.DataColumnMapping("intUnitsInStock", "intUnitsInStock"),
                        new System.Data.Common.DataColumnMapping("intUnitsOnOrder", "intUnitsOnOrder"),
                        new System.Data.Common.DataColumnMapping("intReorderLevel", "intReorderLevel"),
                        new System.Data.Common.DataColumnMapping("blnDiscontinued", "blnDiscontinued")})});
      this.dtaProduct.UpdateCommand = this.cmmUpdateProduct;
      // 
      // dgrProducts
      // 
      this.dgrProducts.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrProducts.DataMember = "";
      this.dgrProducts.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrProducts.Location = new System.Drawing.Point(12, 103);
      this.dgrProducts.Name = "dgrProducts";
      this.dgrProducts.Size = new System.Drawing.Size(320, 203);
      this.dgrProducts.TabIndex = 29;
      // 
      // dtaCategory
      // 
      this.dtaCategory.DeleteCommand = this.SqlDeleteCommand1;
      this.dtaCategory.InsertCommand = this.SqlInsertCommand1;
      this.dtaCategory.SelectCommand = this.SqlSelectCommand1;
      this.dtaCategory.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCategory", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdCategory", "intIdCategory"),
                        new System.Data.Common.DataColumnMapping("strCategoryName", "strCategoryName"),
                        new System.Data.Common.DataColumnMapping("memDescription", "memDescription")})});
      this.dtaCategory.UpdateCommand = this.SqlUpdateCommand1;
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // frmXML
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(440, 349);
      this.Controls.Add(this.cmdAttributes);
      this.Controls.Add(this.cmdWriteNested);
      this.Controls.Add(this.cmdReadData);
      this.Controls.Add(this.cmdInferSchema);
      this.Controls.Add(this.cmdWriteData);
      this.Controls.Add(this.cmdReadSchema);
      this.Controls.Add(this.cmdGetXml);
      this.Controls.Add(this.cmdWriteSchema);
      this.Controls.Add(this.txtPosition);
      this.Controls.Add(this.txtCategoryDescription);
      this.Controls.Add(this.txtCategoryName);
      this.Controls.Add(this.txtIdCategory);
      this.Controls.Add(this.lblDescription);
      this.Controls.Add(this.lblCategoryName);
      this.Controls.Add(this.lblCategoryKey);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.cmdLast);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.cmdFirst);
      this.Controls.Add(this.dgrProducts);
      this.Controls.Add(this.panHorizontalLine02);
      this.Controls.Add(this.panHorizontalLine01);
      this.Controls.Add(this.cmdDocument);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmXML";
      this.Text = "Reading and Writing XML";
      ((System.ComponentModel.ISupportInitialize)(this.dgrProducts)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmXML'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmXML()
      //***
      // Action
      //   - Create instance of 'frmXML'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      //   - SetBindings(DataSet)
      //   - UpdateDisplay(DataSet)
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      dtaCategory.Fill(dsData.tblCPCategory);
      dtaProduct.Fill(dsData.tblCPProduct);
      SetBindings(dsData);
      UpdateDisplay(dsData);
      mdsCurrent = dsData;
    }
    // frmXML()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    DataSet mdsCurrent;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAttributes_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Write an XML file with the attributes of the category columns (not the image)
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsData.tblCPCategory.Columns["intIdCategory"].ColumnMapping = MappingType.Attribute;
      dsData.tblCPCategory.Columns["strCategoryName"].ColumnMapping = MappingType.Attribute;
      dsData.tblCPCategory.Columns["memDescription"].ColumnMapping = MappingType.Attribute;
      dsData.WriteXml("T:\\Attributes.xml", XmlWriteMode.IgnoreSchema);
      MessageBox.Show("Finished", "Write Attributed");
    }
    // cmdAttributes_Click(System.Object, System.EventArgs) Handles cmdAttributes.Click

    private void cmdDocument_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define an XML data document
      //   - Try to
      //     - Clear the data set
      //     - Create a new XML data document bases on the data set
      //     - Load an XML file (with only the data)
      //     - Set the bindings towards the form
      //     - Set the data set into mdsCurrent
      //   - When there is an issue
      //     - Show error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - SetBindings(DataSet)
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      XmlDataDocument theXmlDataDocument;

      try
      {
        dsData.Clear();
        theXmlDataDocument = new XmlDataDocument(dsData);
        theXmlDataDocument.Load("T:\\DataOnly.xml");
        SetBindings(theXmlDataDocument.DataSet);
        mdsCurrent = theXmlDataDocument.DataSet;
      }
      catch (Exception theException)
      {
        MessageBox.Show("This function can only runned once.");
      }
      finally
      {
      }
      
    }
    // cmdDocument_Click(System.Object, System.EventArgs) Handles cmdDocument.Click

    private void cmdFirst_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the context to Category to the first position
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay(DataSet)
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[mdsCurrent, "tblCPCategory"].Position = 0;
      UpdateDisplay(mdsCurrent);
    }
    // cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click

    private void cmdGetXml_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of the form frmGetXml
      //   - Show the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmGetXml thefrmGetXml = new frmGetXml();
      thefrmGetXml.Show();
    }
    // cmdGetXml_Click(System.Object, System.EventArgs) Handles cmdGetXml.Click

    private void cmdInferSchema_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a new data set
      //   - Read the schema from a location towards the data set
      //   - Fill the data adapter category into the data set
      //   - Fill the data adapter product into the data set
      //   - Add the relation between the two tables
      //   - Set the bindings towards the new data set
      //   - mdsCurrent becomes the data set
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - SetBindings(DataSet)
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DataSet dsNew = new DataSet();
      string[] arrstrText = new string[0];

      dsNew.InferXmlSchema("T:\\DataOnly.xml", arrstrText);
      dtaCategory.Fill(dsNew.Tables["tblCPCategory"]);
      dtaProduct.Fill(dsNew.Tables["tblCPProduct"]);
      dsNew.Relations.Add("ProductCategory", dsNew.Tables["tblCPCategory"].Columns["intIdCategory"], dsNew.Tables["tblCPProduct"].Columns["intCategoryId"]);
      SetBindings(dsNew);
      mdsCurrent = dsNew;
    }
    // cmdInferSchema_Click(System.Object, System.EventArgs) Handles cmdInferSchema.Click

    private void cmdLast_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the context to Category to the last position
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay(DataSet)
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[mdsCurrent, "tblCPCategory"].Position = BindingContext[mdsCurrent, "tblCPCategory"].Count - 1;
      UpdateDisplay(mdsCurrent);
    }
    // cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click

    private void cmdNext_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Use the binding context towards Category
      //   - If you are on the last position
      //     - Do nothing
      //   - If not
      //     - Select the next position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay(DataSet)
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (BindingContext[mdsCurrent, "tblCPCategory"].Position == BindingContext[mdsCurrent, "tblCPCategory"].Count - 1)
      {
      }
      else
        //  BindingContext[mdsCurrent, "tblCPCategory"].Position <> BindingContext[mdsCurrent, "tblCPCategory"].Count - 1
      {
        BindingContext[mdsCurrent, "tblCPCategory"].Position += 1;
        UpdateDisplay(mdsCurrent);
      }
      // BindingContext[mdsCurrent, "tblCPCategory"].Position = BindingContext[mdsCurrent, "tblCPCategory"].Count - 1

    }
    // cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click
    
    private void cmdPrevious_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Use the binding context towards Category
      //   - If you are on the first position
      //     - Do nothing
      //   - If not
      //     - Select the previous position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay(DataSet)
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (BindingContext[mdsCurrent, "tblCPCategory"].Position == 0)
      {
      }
      else
        //  BindingContext[mdsCurrent, "tblCPCategory"].Position <> 0
      {
        BindingContext[mdsCurrent, "tblCPCategory"].Position -= 1;
        UpdateDisplay(mdsCurrent);
      }
      // BindingContext[mdsCurrent, "tblCPCategory"].Position = 0

    }
    // cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click

    private void cmdReadData_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a new data set
      //   - Read the data from a file into the data set
      //     - The file contains the schema
      //   - Set the bindings to the new data set
      //   - Set the mdsCurrent data set correct
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - SetBindings(DataSet)
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DataSet dsNew = new DataSet();

      dsNew.ReadXml("T:\\NewData.xml", XmlReadMode.ReadSchema);
      SetBindings(dsNew);
      mdsCurrent = dsNew;
    }
    // cmdReadData_Click(System.Object, System.EventArgs) Handles cmdReadData.Click

    private void cmdReadSchema_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a new data set
      //   - Read the schema from a location towards the data set
      //   - Fill the data adapter category into the data set
      //   - Fill the data adapter product into the data set
      //   - Set the bindings towards the new data set
      //   - mdsCurrent becomes the data set
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - SetBindings(DataSet)
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DataSet dsNew = new DataSet();

      dsNew.ReadXmlSchema("T:\\TestSchema.xsd");
      dtaCategory.Fill(dsNew.Tables["tblCPCategory"]);
      dtaProduct.Fill(dsNew.Tables["tblCPProduct"]);
      SetBindings(dsNew);
      mdsCurrent = dsNew;
    }
    // cmdReadSchema_Click(System.Object, System.EventArgs) Handles cmdReadSchema.Click

    private void cmdWriteData_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Write the data with schema to an XML file
      //   - Write the data without schema to an XML file
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsData.WriteXml("T:\\NewData.xml", XmlWriteMode.WriteSchema);
      dsData.WriteXml("T:\\DataOnly.xml", XmlWriteMode.IgnoreSchema);
      MessageBox.Show("Finished", "WriteXml");
    }
    // cmdWriteData_Click(System.Object, System.EventArgs) Handles cmdWriteData.Click

    private void cmdWriteNested_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Write the data with schema to an XML file using the nesting of data
      //   - Write the data without schema to an XML file
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsData.Relations["ProductCategory"].Nested = true;
      dsData.WriteXml("T:\\NestedData.xml", XmlWriteMode.IgnoreSchema);
      MessageBox.Show("Finished", "WriteXml Nested");
    }
    // cmdWriteNested_Click(System.Object, System.EventArgs) Handles cmdWriteNested.Click

    private void cmdWriteSchema_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Write the schema from the data set towards a file
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsData.WriteXmlSchema("T:\\TestSchema.xsd");
      MessageBox.Show("Finished", "WriteXmlSchema");
    }
    // cmdWriteSchema_Click(System.Object, System.EventArgs) Handles cmdWriteSchema.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmXML
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmGetXml()
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmXML());
    }
    // Main() 

    private void SetBindings(DataSet theDataset)
      //***
      // Action
      //   - Clear the binding for txtIdCategory
      //   - Clear the binding for txtCategoryName
      //   - Clear the binding for txtCategoryDescription
      //   - Add the binding for txtIdCategory
      //   - Add the binding for txtCategoryName
      //   - Add the binding for txtCategoryDescription
      //   - Set the binding for the datagrid of products
      //   - Update the display
      // Called by
      //   - cmdDocument_Click(System.Object, System.EventArgs) Handles cmdDocument.Click
      //   - cmdInferSchema_Click(System.Object, System.EventArgs) Handles cmdInferSchema.Click
      //   - cmdReadData_Click(System.Object, System.EventArgs) Handles cmdReadData.Click
      //   - cmdReadSchema_Click(System.Object, System.EventArgs) Handles cmdReadSchema.Click
      //   - New()
      // Calls
      //   - UpdateDisplay(DataSet)
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtIdCategory.DataBindings.Clear();
      txtCategoryName.DataBindings.Clear();
      txtCategoryDescription.DataBindings.Clear();
      txtIdCategory.DataBindings.Add("Text", theDataset, "tblCPCategory.intIdCategory");
      txtCategoryName.DataBindings.Add("Text", theDataset, "tblCPCategory.strCategoryName");
      txtCategoryDescription.DataBindings.Add("Text", theDataset, "tblCPCategory.memDescription");
      dgrProducts.SetDataBinding(theDataset, "tblCPCategory.ProductCategory");
      UpdateDisplay(theDataset);
    }
    // SetBindings(DataSet)

    private void UpdateDisplay(DataSet theDataset)
      //***
      // Action
      //   - Define a binding manager base
      //   - Set the binding manager base to the context of Category
      //   - Set the correct text for position
      // Called by
      //   - cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click
      //   - cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click
      //   - cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click
      //   - cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click
      //   - New()
      //   - SetBindings(DataSet)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingManagerBase bmbBindingManagerBase;

      bmbBindingManagerBase = BindingContext[theDataset, "tblCPCategory"];
      txtPosition.Text = "Category ";
      txtPosition.Text += (bmbBindingManagerBase.Position + 1).ToString();
      txtPosition.Text += " of ";
      txtPosition.Text += bmbBindingManagerBase.Count.ToString();
    }
    // UpdateDisplay(DataSet)
      
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmXML

}
// CopyPaste.Learning