﻿//***
// Action
//   - Creating a webpage to calculate a carloan
// Created
//   - CopyPaste – 20260128 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260128 – VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;  
using System;

namespace CopyPaste.Learning
{
  public partial class wfrmCarLoan: System.Web.UI.Page
  {

    #region "Constructors / Destructors"

    public wfrmCarLoan()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - xxxx
    // Created
    //   - CopyPaste – yyyymmdd – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – yyyymmdd – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpDefault()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    protected void cmdCalculate_Click(System.Object theSender, EventArgs theEventArguments)
      //***
      // Action
      //   - Define a result variable
      //   - Calculate the monthly payment of the typed amount with the yearly typed interest over 48 months
      //   - Assign the result
      //   - Show the result on the webpage
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260123 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260123 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Single sngLoanPayment;

      sngLoanPayment = Convert.ToSingle(Financial.Pmt(Convert.ToDouble(txtInterest.Text) / 12, 48, Convert.ToDouble(txtAmount.Text), 0, DueDate.EndOfPeriod));
      txtPayment.Text = (Math.Abs(sngLoanPayment)).ToString("€ 0.00");
    }
    // cmdCalculate_Click(System.Object, System.EventArgs) Handles cmdCalculate.Click

    protected void Page_Load(System.Object theSender, EventArgs theEventArguments)
      //***
      // Action
      //   - 
      // Called by
      //   - User action (Loading the page)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

    }
    // Page_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmCarLoan

}
// CopyPaste.Learning