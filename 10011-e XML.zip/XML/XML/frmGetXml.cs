//***
// Action
//   - Get the Schema, XML Data and XML Nested data
// Created
//   - CopyPaste � 20251128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251128 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmGetXml: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwind2005;
    internal System.Data.SqlClient.SqlDataAdapter dtaProduct;
    internal System.Data.SqlClient.SqlCommand cmmDeleteProduct;
    internal System.Data.SqlClient.SqlCommand cmmInsertProduct;
    internal System.Data.SqlClient.SqlCommand cmmSelectProduct;
    internal System.Data.SqlClient.SqlCommand cmmUpdateProduct;
    internal System.Data.SqlClient.SqlCommand SqlUpdateCommand1;
    internal System.Data.SqlClient.SqlDataAdapter dtaCategory;
    internal System.Data.SqlClient.SqlCommand SqlDeleteCommand1;
    internal System.Data.SqlClient.SqlCommand SqlInsertCommand1;
    internal System.Data.SqlClient.SqlCommand SqlSelectCommand1;
    internal System.Windows.Forms.TextBox txtResult;
    internal System.Windows.Forms.Button cmdDataNested;
    internal System.Windows.Forms.Button cmdData;
    private XML.dsData dsData;
    internal System.Windows.Forms.Button cmdSchema;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGetXml));
      this.cnncpNorthwind2005 = new System.Data.SqlClient.SqlConnection();
      this.dtaProduct = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmDeleteProduct = new System.Data.SqlClient.SqlCommand();
      this.cmmInsertProduct = new System.Data.SqlClient.SqlCommand();
      this.cmmSelectProduct = new System.Data.SqlClient.SqlCommand();
      this.cmmUpdateProduct = new System.Data.SqlClient.SqlCommand();
      this.SqlUpdateCommand1 = new System.Data.SqlClient.SqlCommand();
      this.dtaCategory = new System.Data.SqlClient.SqlDataAdapter();
      this.SqlDeleteCommand1 = new System.Data.SqlClient.SqlCommand();
      this.SqlInsertCommand1 = new System.Data.SqlClient.SqlCommand();
      this.SqlSelectCommand1 = new System.Data.SqlClient.SqlCommand();
      this.txtResult = new System.Windows.Forms.TextBox();
      this.cmdDataNested = new System.Windows.Forms.Button();
      this.cmdData = new System.Windows.Forms.Button();
      this.cmdSchema = new System.Windows.Forms.Button();
      this.dsData = new XML.dsData();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.SuspendLayout();
      // 
      // cnncpNorthwind2005
      // 
      this.cnncpNorthwind2005.ConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthwind2005.FireInfoMessageEventOnUserErrors = false;
      // 
      // dtaProduct
      // 
      this.dtaProduct.DeleteCommand = this.cmmDeleteProduct;
      this.dtaProduct.InsertCommand = this.cmmInsertProduct;
      this.dtaProduct.SelectCommand = this.cmmSelectProduct;
      this.dtaProduct.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPProduct", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdProduct", "intIdProduct"),
                        new System.Data.Common.DataColumnMapping("strProductName", "strProductName"),
                        new System.Data.Common.DataColumnMapping("intSupplierId", "intSupplierId"),
                        new System.Data.Common.DataColumnMapping("intCategoryId", "intCategoryId"),
                        new System.Data.Common.DataColumnMapping("strQuantityPerUnit", "strQuantityPerUnit"),
                        new System.Data.Common.DataColumnMapping("dblUnitPrice", "dblUnitPrice"),
                        new System.Data.Common.DataColumnMapping("intUnitsInStock", "intUnitsInStock"),
                        new System.Data.Common.DataColumnMapping("intUnitsOnOrder", "intUnitsOnOrder"),
                        new System.Data.Common.DataColumnMapping("intReorderLevel", "intReorderLevel"),
                        new System.Data.Common.DataColumnMapping("blnDiscontinued", "blnDiscontinued")})});
      this.dtaProduct.UpdateCommand = this.cmmUpdateProduct;
      // 
      // cmmDeleteProduct
      // 
      this.cmmDeleteProduct.CommandText = resources.GetString("cmmDeleteProduct.CommandText");
      this.cmmDeleteProduct.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_intIdProduct", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdProduct", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_blnDiscontinued", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "blnDiscontinued", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dblUnitPrice", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblUnitPrice", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intCategoryId", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intReorderLevel", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReorderLevel", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intSupplierId", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intSupplierId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intUnitsInStock", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsInStock", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intUnitsOnOrder", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsOnOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strProductName", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strProductName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strQuantityPerUnit", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strQuantityPerUnit", System.Data.DataRowVersion.Original, null)});
      // 
      // cmmInsertProduct
      // 
      this.cmmInsertProduct.CommandText = resources.GetString("cmmInsertProduct.CommandText");
      this.cmmInsertProduct.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@intIdProduct", System.Data.SqlDbType.Int, 4, "intIdProduct"),
            new System.Data.SqlClient.SqlParameter("@strProductName", System.Data.SqlDbType.VarChar, 40, "strProductName"),
            new System.Data.SqlClient.SqlParameter("@intSupplierId", System.Data.SqlDbType.Int, 4, "intSupplierId"),
            new System.Data.SqlClient.SqlParameter("@intCategoryId", System.Data.SqlDbType.Int, 4, "intCategoryId"),
            new System.Data.SqlClient.SqlParameter("@strQuantityPerUnit", System.Data.SqlDbType.VarChar, 20, "strQuantityPerUnit"),
            new System.Data.SqlClient.SqlParameter("@dblUnitPrice", System.Data.SqlDbType.Money, 8, "dblUnitPrice"),
            new System.Data.SqlClient.SqlParameter("@intUnitsInStock", System.Data.SqlDbType.SmallInt, 2, "intUnitsInStock"),
            new System.Data.SqlClient.SqlParameter("@intUnitsOnOrder", System.Data.SqlDbType.SmallInt, 2, "intUnitsOnOrder"),
            new System.Data.SqlClient.SqlParameter("@intReorderLevel", System.Data.SqlDbType.SmallInt, 2, "intReorderLevel"),
            new System.Data.SqlClient.SqlParameter("@blnDiscontinued", System.Data.SqlDbType.Bit, 1, "blnDiscontinued")});
      // 
      // cmmSelectProduct
      // 
      this.cmmSelectProduct.CommandText = "SELECT intIdProduct, strProductName, intSupplierId, intCategoryId, strQuantityPer" +
    "Unit, dblUnitPrice, intUnitsInStock, intUnitsOnOrder, intReorderLevel, blnDiscon" +
    "tinued FROM tblCPProduct";
      this.cmmSelectProduct.Connection = this.cnncpNorthwind2005;
      // 
      // cmmUpdateProduct
      // 
      this.cmmUpdateProduct.CommandText = resources.GetString("cmmUpdateProduct.CommandText");
      this.cmmUpdateProduct.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@intIdProduct", System.Data.SqlDbType.Int, 4, "intIdProduct"),
            new System.Data.SqlClient.SqlParameter("@strProductName", System.Data.SqlDbType.VarChar, 40, "strProductName"),
            new System.Data.SqlClient.SqlParameter("@intSupplierId", System.Data.SqlDbType.Int, 4, "intSupplierId"),
            new System.Data.SqlClient.SqlParameter("@intCategoryId", System.Data.SqlDbType.Int, 4, "intCategoryId"),
            new System.Data.SqlClient.SqlParameter("@strQuantityPerUnit", System.Data.SqlDbType.VarChar, 20, "strQuantityPerUnit"),
            new System.Data.SqlClient.SqlParameter("@dblUnitPrice", System.Data.SqlDbType.Money, 8, "dblUnitPrice"),
            new System.Data.SqlClient.SqlParameter("@intUnitsInStock", System.Data.SqlDbType.SmallInt, 2, "intUnitsInStock"),
            new System.Data.SqlClient.SqlParameter("@intUnitsOnOrder", System.Data.SqlDbType.SmallInt, 2, "intUnitsOnOrder"),
            new System.Data.SqlClient.SqlParameter("@intReorderLevel", System.Data.SqlDbType.SmallInt, 2, "intReorderLevel"),
            new System.Data.SqlClient.SqlParameter("@blnDiscontinued", System.Data.SqlDbType.Bit, 1, "blnDiscontinued"),
            new System.Data.SqlClient.SqlParameter("@Original_intIdProduct", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdProduct", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_blnDiscontinued", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "blnDiscontinued", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_dblUnitPrice", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "dblUnitPrice", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intCategoryId", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intReorderLevel", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intReorderLevel", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intSupplierId", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intSupplierId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intUnitsInStock", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsInStock", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intUnitsOnOrder", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intUnitsOnOrder", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strProductName", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strProductName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strQuantityPerUnit", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strQuantityPerUnit", System.Data.DataRowVersion.Original, null)});
      // 
      // SqlUpdateCommand1
      // 
      this.SqlUpdateCommand1.CommandText = resources.GetString("SqlUpdateCommand1.CommandText");
      this.SqlUpdateCommand1.Connection = this.cnncpNorthwind2005;
      this.SqlUpdateCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@intIdCategory", System.Data.SqlDbType.Int, 4, "intIdCategory"),
            new System.Data.SqlClient.SqlParameter("@strCategoryName", System.Data.SqlDbType.VarChar, 15, "strCategoryName"),
            new System.Data.SqlClient.SqlParameter("@memDescription", System.Data.SqlDbType.VarChar, 2147483647, "memDescription"),
            new System.Data.SqlClient.SqlParameter("@Original_intIdCategory", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdCategory", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCategoryName", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCategoryName", System.Data.DataRowVersion.Original, null)});
      // 
      // dtaCategory
      // 
      this.dtaCategory.DeleteCommand = this.SqlDeleteCommand1;
      this.dtaCategory.InsertCommand = this.SqlInsertCommand1;
      this.dtaCategory.SelectCommand = this.SqlSelectCommand1;
      this.dtaCategory.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCategory", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdCategory", "intIdCategory"),
                        new System.Data.Common.DataColumnMapping("strCategoryName", "strCategoryName"),
                        new System.Data.Common.DataColumnMapping("memDescription", "memDescription")})});
      this.dtaCategory.UpdateCommand = this.SqlUpdateCommand1;
      // 
      // SqlDeleteCommand1
      // 
      this.SqlDeleteCommand1.CommandText = "DELETE FROM tblCPCategory WHERE (intIdCategory = @Original_intIdCategory) AND (st" +
    "rCategoryName = @Original_strCategoryName)";
      this.SqlDeleteCommand1.Connection = this.cnncpNorthwind2005;
      this.SqlDeleteCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_intIdCategory", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdCategory", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCategoryName", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCategoryName", System.Data.DataRowVersion.Original, null)});
      // 
      // SqlInsertCommand1
      // 
      this.SqlInsertCommand1.CommandText = resources.GetString("SqlInsertCommand1.CommandText");
      this.SqlInsertCommand1.Connection = this.cnncpNorthwind2005;
      this.SqlInsertCommand1.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@intIdCategory", System.Data.SqlDbType.Int, 4, "intIdCategory"),
            new System.Data.SqlClient.SqlParameter("@strCategoryName", System.Data.SqlDbType.VarChar, 15, "strCategoryName"),
            new System.Data.SqlClient.SqlParameter("@memDescription", System.Data.SqlDbType.VarChar, 2147483647, "memDescription")});
      // 
      // SqlSelectCommand1
      // 
      this.SqlSelectCommand1.CommandText = "SELECT intIdCategory, strCategoryName, memDescription FROM tblCPCategory";
      this.SqlSelectCommand1.Connection = this.cnncpNorthwind2005;
      // 
      // txtResult
      // 
      this.txtResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.txtResult.Location = new System.Drawing.Point(8, 38);
      this.txtResult.Multiline = true;
      this.txtResult.Name = "txtResult";
      this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.txtResult.Size = new System.Drawing.Size(392, 360);
      this.txtResult.TabIndex = 7;
      this.txtResult.WordWrap = false;
      // 
      // cmdDataNested
      // 
      this.cmdDataNested.Location = new System.Drawing.Point(200, 6);
      this.cmdDataNested.Name = "cmdDataNested";
      this.cmdDataNested.Size = new System.Drawing.Size(128, 23);
      this.cmdDataNested.TabIndex = 6;
      this.cmdDataNested.Text = "Show Data Nested";
      this.cmdDataNested.Click += new System.EventHandler(this.cmdDataNested_Click);
      // 
      // cmdData
      // 
      this.cmdData.Location = new System.Drawing.Point(104, 6);
      this.cmdData.Name = "cmdData";
      this.cmdData.Size = new System.Drawing.Size(88, 23);
      this.cmdData.TabIndex = 5;
      this.cmdData.Text = "Show Data";
      this.cmdData.Click += new System.EventHandler(this.cmdData_Click);
      // 
      // cmdSchema
      // 
      this.cmdSchema.Location = new System.Drawing.Point(8, 6);
      this.cmdSchema.Name = "cmdSchema";
      this.cmdSchema.Size = new System.Drawing.Size(88, 23);
      this.cmdSchema.TabIndex = 4;
      this.cmdSchema.Text = "Show Schema";
      this.cmdSchema.Click += new System.EventHandler(this.cmdSchema_Click);
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // frmGetXml
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(408, 405);
      this.Controls.Add(this.cmdSchema);
      this.Controls.Add(this.txtResult);
      this.Controls.Add(this.cmdDataNested);
      this.Controls.Add(this.cmdData);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmGetXml";
      this.Text = "GetXml";
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmGetXml'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmGetXml()
      //***
      // Action
      //   - Create instance of 'frmGetXml'
      //   - Fill data set with Product and category information
      // Called by
      //   - 
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      dtaCategory.Fill(dsData.tblCPCategory);
      dtaProduct.Fill(dsData.tblCPProduct);
    }
    // frmGetXml()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdData_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the nested relation to false
      //   - Get data as XML
      //   - Put XML into textbox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strXML;

      dsData.Relations["ProductCategory"].Nested = false;
      strXML = dsData.GetXml();
      txtResult.Text = strXML;
    }
    // cmdData_Click(System.Object, System.EventArgs) Handling cmdData.Click

    private void cmdDataNested_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the nested relation to true
      //   - Get data as XML
      //   - Put XML into textbox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strXML;

      dsData.Relations["ProductCategory"].Nested = true;
      strXML = dsData.GetXml();
      txtResult.Text = strXML;
    }
    // cmdDataNested_Click(System.Object, System.EventArgs) Handles cmdDataNested.Click

    private void cmdSchema_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Get schema of data as XML
      //   - Put XML into textbox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251128 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strXML;

      strXML = dsData.GetXmlSchema();
      txtResult.Text = strXML;
    }
    // cmdSchema_Click(System.Object, System.EventArgs) Handles cmdSchema.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmGetXml

}
// CopyPaste.Learning