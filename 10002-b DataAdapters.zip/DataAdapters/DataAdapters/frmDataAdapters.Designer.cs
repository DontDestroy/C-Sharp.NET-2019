﻿//***
// Action
//   - Having DataAdapters and Commands towards a database
// Created
//   - CopyPaste – 20210630 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20210630 – VVDW
// Proposal (To Do)
//   -
//***

namespace DataAdapters
{

  partial class frmDataAdapters
  {

    #region Windows Form Designer generated code

    internal System.Data.SqlClient.SqlCommand cmmUpdateProduct;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwindScript;
    internal System.Data.SqlClient.SqlCommand cmmInsertProduct;
    internal System.Data.SqlClient.SqlCommand cmmDeleteProduct;
    internal System.Data.SqlClient.SqlDataAdapter dtaProduct;
    internal System.Data.SqlClient.SqlCommand cmmSelectProduct;
    internal System.Data.SqlClient.SqlCommand cmmUpdateCategory;
    internal System.Data.SqlClient.SqlCommand cmmSelectCategory;
    internal System.Data.SqlClient.SqlCommand cmmInsertCategory;
    internal System.Data.SqlClient.SqlCommand cmmDeleteCategory;
    internal System.Data.SqlClient.SqlDataAdapter dtaCategory;
    internal System.Windows.Forms.Button cmdUpdateCategory;
    internal System.Windows.Forms.Label lblMessage;
    internal System.Windows.Forms.DataGrid dgrProducts;
    internal System.Windows.Forms.TabPage pagProduct;
    internal System.Windows.Forms.Button cmdFillAll;
    internal System.Windows.Forms.TabControl tabTables;
    internal System.Windows.Forms.TabPage pagCategory;
    internal System.Windows.Forms.DataGrid dgrCategories;
    internal System.Windows.Forms.TextBox txtMessages;
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataAdapters));
      this.cmmUpdateProduct = new System.Data.SqlClient.SqlCommand();
      this.cnncpNorthwindScript = new System.Data.SqlClient.SqlConnection();
      this.cmmInsertProduct = new System.Data.SqlClient.SqlCommand();
      this.cmmDeleteProduct = new System.Data.SqlClient.SqlCommand();
      this.dtaProduct = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectProduct = new System.Data.SqlClient.SqlCommand();
      this.cmmUpdateCategory = new System.Data.SqlClient.SqlCommand();
      this.cmmSelectCategory = new System.Data.SqlClient.SqlCommand();
      this.cmmInsertCategory = new System.Data.SqlClient.SqlCommand();
      this.cmmDeleteCategory = new System.Data.SqlClient.SqlCommand();
      this.dtaCategory = new System.Data.SqlClient.SqlDataAdapter();
      this.cmdUpdateCategory = new System.Windows.Forms.Button();
      this.lblMessage = new System.Windows.Forms.Label();
      this.dgrProducts = new System.Windows.Forms.DataGrid();
      this.dsProduct = new DataAdapters.dsProduct();
      this.pagProduct = new System.Windows.Forms.TabPage();
      this.cmdFillAll = new System.Windows.Forms.Button();
      this.tabTables = new System.Windows.Forms.TabControl();
      this.pagCategory = new System.Windows.Forms.TabPage();
      this.dgrCategories = new System.Windows.Forms.DataGrid();
      this.dsCategory = new DataAdapters.dsCategory();
      this.txtMessages = new System.Windows.Forms.TextBox();
      ((System.ComponentModel.ISupportInitialize)(this.dgrProducts)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsProduct)).BeginInit();
      this.pagProduct.SuspendLayout();
      this.tabTables.SuspendLayout();
      this.pagCategory.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dgrCategories)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCategory)).BeginInit();
      this.SuspendLayout();
      // 
      // cmmUpdateProduct
      // 
      this.cmmUpdateProduct.CommandText = resources.GetString("cmmUpdateProduct.CommandText");
      this.cmmUpdateProduct.Connection = this.cnncpNorthwindScript;
      this.cmmUpdateProduct.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@intCategoryId", System.Data.SqlDbType.Int, 4, "intCategoryId"),
            new System.Data.SqlClient.SqlParameter("@strProductName", System.Data.SqlDbType.VarChar, 40, "strProductName"),
            new System.Data.SqlClient.SqlParameter("@Original_intIdProduct", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdProduct", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intCategoryId", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strProductName", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strProductName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@intIdProduct", System.Data.SqlDbType.Int, 4, "intIdProduct")});
      // 
      // cnncpNorthwindScript
      // 
      this.cnncpNorthwindScript.ConnectionString = "Data Source=COPYPASTEPOWER\\COPYPASTE;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthwindScript.FireInfoMessageEventOnUserErrors = false;
      // 
      // cmmInsertProduct
      // 
      this.cmmInsertProduct.CommandText = resources.GetString("cmmInsertProduct.CommandText");
      this.cmmInsertProduct.Connection = this.cnncpNorthwindScript;
      this.cmmInsertProduct.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@intCategoryId", System.Data.SqlDbType.Int, 4, "intCategoryId"),
            new System.Data.SqlClient.SqlParameter("@strProductName", System.Data.SqlDbType.VarChar, 40, "strProductName")});
      // 
      // cmmDeleteProduct
      // 
      this.cmmDeleteProduct.CommandText = resources.GetString("cmmDeleteProduct.CommandText");
      this.cmmDeleteProduct.Connection = this.cnncpNorthwindScript;
      this.cmmDeleteProduct.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_intIdProduct", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdProduct", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_intCategoryId", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intCategoryId", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strProductName", System.Data.SqlDbType.VarChar, 40, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strProductName", System.Data.DataRowVersion.Original, null)});
      // 
      // dtaProduct
      // 
      this.dtaProduct.DeleteCommand = this.cmmDeleteProduct;
      this.dtaProduct.InsertCommand = this.cmmInsertProduct;
      this.dtaProduct.SelectCommand = this.cmmSelectProduct;
      this.dtaProduct.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPProduct", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intCategoryId", "intCategoryId"),
                        new System.Data.Common.DataColumnMapping("intIdProduct", "intIdProduct"),
                        new System.Data.Common.DataColumnMapping("strProductName", "strProductName")})});
      this.dtaProduct.UpdateCommand = this.cmmUpdateProduct;
      // 
      // cmmSelectProduct
      // 
      this.cmmSelectProduct.CommandText = "SELECT intCategoryId, intIdProduct, strProductName FROM tblCPProduct";
      this.cmmSelectProduct.Connection = this.cnncpNorthwindScript;
      // 
      // cmmUpdateCategory
      // 
      this.cmmUpdateCategory.CommandText = resources.GetString("cmmUpdateCategory.CommandText");
      this.cmmUpdateCategory.Connection = this.cnncpNorthwindScript;
      this.cmmUpdateCategory.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@strCategoryName", System.Data.SqlDbType.VarChar, 15, "strCategoryName"),
            new System.Data.SqlClient.SqlParameter("@memDescription", System.Data.SqlDbType.VarChar, 2147483647, "memDescription"),
            new System.Data.SqlClient.SqlParameter("@Original_intIdCategory", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdCategory", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCategoryName", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCategoryName", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@intIdCategory", System.Data.SqlDbType.Int, 4, "intIdCategory")});
      // 
      // cmmSelectCategory
      // 
      this.cmmSelectCategory.CommandText = "SELECT intIdCategory, strCategoryName, memDescription FROM tblCPCategory";
      this.cmmSelectCategory.Connection = this.cnncpNorthwindScript;
      // 
      // cmmInsertCategory
      // 
      this.cmmInsertCategory.CommandText = resources.GetString("cmmInsertCategory.CommandText");
      this.cmmInsertCategory.Connection = this.cnncpNorthwindScript;
      this.cmmInsertCategory.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@strCategoryName", System.Data.SqlDbType.VarChar, 15, "strCategoryName"),
            new System.Data.SqlClient.SqlParameter("@memDescription", System.Data.SqlDbType.VarChar, 2147483647, "memDescription")});
      // 
      // cmmDeleteCategory
      // 
      this.cmmDeleteCategory.CommandText = "DELETE FROM tblCPCategory WHERE (intIdCategory = @Original_intIdCategory) AND (st" +
    "rCategoryName = @Original_strCategoryName)";
      this.cmmDeleteCategory.Connection = this.cnncpNorthwindScript;
      this.cmmDeleteCategory.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@Original_intIdCategory", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "intIdCategory", System.Data.DataRowVersion.Original, null),
            new System.Data.SqlClient.SqlParameter("@Original_strCategoryName", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, false, ((byte)(0)), ((byte)(0)), "strCategoryName", System.Data.DataRowVersion.Original, null)});
      // 
      // dtaCategory
      // 
      this.dtaCategory.DeleteCommand = this.cmmDeleteCategory;
      this.dtaCategory.InsertCommand = this.cmmInsertCategory;
      this.dtaCategory.SelectCommand = this.cmmSelectCategory;
      this.dtaCategory.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCategory", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdCategory", "intIdCategory"),
                        new System.Data.Common.DataColumnMapping("strCategoryName", "strCategoryName"),
                        new System.Data.Common.DataColumnMapping("memDescription", "memDescription")})});
      this.dtaCategory.UpdateCommand = this.cmmUpdateCategory;
      this.dtaCategory.RowUpdated += new System.Data.SqlClient.SqlRowUpdatedEventHandler(this.dtaCategory_RowUpdated);
      this.dtaCategory.RowUpdating += new System.Data.SqlClient.SqlRowUpdatingEventHandler(this.dtaCategory_RowUpdating);
      // 
      // cmdUpdateCategory
      // 
      this.cmdUpdateCategory.Location = new System.Drawing.Point(432, 70);
      this.cmdUpdateCategory.Name = "cmdUpdateCategory";
      this.cmdUpdateCategory.Size = new System.Drawing.Size(112, 23);
      this.cmdUpdateCategory.TabIndex = 9;
      this.cmdUpdateCategory.Text = "&Update Category";
      this.cmdUpdateCategory.Click += new System.EventHandler(this.cmdUpdateCategory_Click);
      // 
      // lblMessage
      // 
      this.lblMessage.AutoSize = true;
      this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblMessage.Location = new System.Drawing.Point(8, 278);
      this.lblMessage.Name = "lblMessage";
      this.lblMessage.Size = new System.Drawing.Size(67, 13);
      this.lblMessage.TabIndex = 6;
      this.lblMessage.Text = "Messages:";
      // 
      // dgrProducts
      // 
      this.dgrProducts.DataMember = "tblCPProduct";
      this.dgrProducts.DataSource = this.dsProduct;
      this.dgrProducts.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrProducts.Location = new System.Drawing.Point(8, 8);
      this.dgrProducts.Name = "dgrProducts";
      this.dgrProducts.Size = new System.Drawing.Size(384, 216);
      this.dgrProducts.TabIndex = 0;
      // 
      // dsProduct
      // 
      this.dsProduct.DataSetName = "dsProduct";
      this.dsProduct.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // pagProduct
      // 
      this.pagProduct.Controls.Add(this.dgrProducts);
      this.pagProduct.Location = new System.Drawing.Point(4, 22);
      this.pagProduct.Name = "pagProduct";
      this.pagProduct.Size = new System.Drawing.Size(400, 230);
      this.pagProduct.TabIndex = 1;
      this.pagProduct.Text = "Product";
      // 
      // cmdFillAll
      // 
      this.cmdFillAll.Location = new System.Drawing.Point(432, 38);
      this.cmdFillAll.Name = "cmdFillAll";
      this.cmdFillAll.Size = new System.Drawing.Size(112, 23);
      this.cmdFillAll.TabIndex = 8;
      this.cmdFillAll.Text = "&Fill All";
      this.cmdFillAll.Click += new System.EventHandler(this.cmdFillAll_Click);
      // 
      // tabTables
      // 
      this.tabTables.Controls.Add(this.pagCategory);
      this.tabTables.Controls.Add(this.pagProduct);
      this.tabTables.Location = new System.Drawing.Point(8, 14);
      this.tabTables.Name = "tabTables";
      this.tabTables.SelectedIndex = 0;
      this.tabTables.Size = new System.Drawing.Size(408, 256);
      this.tabTables.TabIndex = 5;
      // 
      // pagCategory
      // 
      this.pagCategory.Controls.Add(this.dgrCategories);
      this.pagCategory.Location = new System.Drawing.Point(4, 22);
      this.pagCategory.Name = "pagCategory";
      this.pagCategory.Size = new System.Drawing.Size(400, 230);
      this.pagCategory.TabIndex = 0;
      this.pagCategory.Text = "Category";
      // 
      // dgrCategories
      // 
      this.dgrCategories.DataMember = "tblCPCategory";
      this.dgrCategories.DataSource = this.dsCategory;
      this.dgrCategories.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrCategories.Location = new System.Drawing.Point(8, 8);
      this.dgrCategories.Name = "dgrCategories";
      this.dgrCategories.Size = new System.Drawing.Size(384, 216);
      this.dgrCategories.TabIndex = 0;
      // 
      // dsCategory
      // 
      this.dsCategory.DataSetName = "dsCategory";
      this.dsCategory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // txtMessages
      // 
      this.txtMessages.Location = new System.Drawing.Point(8, 294);
      this.txtMessages.Multiline = true;
      this.txtMessages.Name = "txtMessages";
      this.txtMessages.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtMessages.Size = new System.Drawing.Size(408, 80);
      this.txtMessages.TabIndex = 7;
      // 
      // frmDataAdapters
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(552, 389);
      this.Controls.Add(this.cmdUpdateCategory);
      this.Controls.Add(this.lblMessage);
      this.Controls.Add(this.cmdFillAll);
      this.Controls.Add(this.tabTables);
      this.Controls.Add(this.txtMessages);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataAdapters";
      this.Text = "Data Adapters";
      ((System.ComponentModel.ISupportInitialize)(this.dgrProducts)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsProduct)).EndInit();
      this.pagProduct.ResumeLayout(false);
      this.tabTables.ResumeLayout(false);
      this.pagCategory.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.dgrCategories)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCategory)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210630 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210630 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing && (components != null))
      {
        components.Dispose();
      }
      // (disposing and (components <> null))

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private dsCategory dsCategory;
    private dsProduct dsProduct;
    
    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataAdapters

}
// DataAdapters