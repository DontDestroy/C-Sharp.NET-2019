//***
// Action
//   - Get the directory and the parent directory
// Created
//   - CopyPaste � 20240722 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240722 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Try to
      //     - Get the current directory
      //     - Get the parent of the current directory
      //     - Write the current directory
      //     - Write the parent directory
      //   - On error
      //     - Show a message
      //     - Show the exception message
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240722 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240722 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strCurrent;
      DirectoryInfo theDirectory;

      try
      {
        strCurrent = Directory.GetCurrentDirectory();
        theDirectory = Directory.GetParent(strCurrent);

        Console.WriteLine("Current directory {0}", strCurrent);
        Console.WriteLine("Parent directory {0}", theDirectory.FullName);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Error determining parent directory");
        Console.WriteLine(theException.Message);
      }
      finally
      {
      }

      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning