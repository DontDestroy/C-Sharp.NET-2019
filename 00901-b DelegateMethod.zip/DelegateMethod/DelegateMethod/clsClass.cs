﻿//***
// Action
//   - Show a message in a message box
// Created
//   - CopyPaste – 20250712 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250712 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpClass
  {

    #region "Constructors / Destructors"

    public cpClass()
      //***
      // Action
      //   - Empty constructor
      // Called by
      //   - frmDelegate.cmdDelegate_Click(System.Object, System.EventArgs) Handles cmdDelegate.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250712 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250712 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpClass()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void cpMethod(string strString)
      //***
      // Action
      //   - Show a given text with title "Copy Paste"
      // Called by
      //   - frmDelegate.cmdDelegate_Click(System.Object, System.EventArgs) Handles cmdDelegate.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250712 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250712 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show(strString, "Copy Paste");
    }
    // cpMethod(string)

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpClass

}
// CopyPaste.Learning