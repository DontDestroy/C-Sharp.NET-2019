﻿//***
// Action
//   - A form where some fields are asked
//     - There are checks on the fields
//     - Some fields are required
//     - Some fields must be a specific data type
//     - Some fields must be equal (password)
// Created
//   - CopyPaste – 20260702 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260702 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CopyPaste.Learning
{

  public partial class wfrmRequired: System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cstvPassword.ServerValidate += new System.Web.UI.WebControls.ServerValidateEventHandler(this.cstvPassword_ServerValidate);
      this.cmdMakeMember.Click += new System.EventHandler(this.cmdMakeMember_Click);
      this.ID = "wfrmRequired";
      this.Load += new System.EventHandler(this.Page_Load);
    }
    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Actions when initializing the page
    // Called by
    //   - User action (Initializing the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260702 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260702 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdMakeMember_Click(System.Object sender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - A lot of checks are executed on the webpage (see HTML)
    //   - If all is valid
    //     - Show the typed info
    //   - If not
    //     - Do nothing
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260702 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260702 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (this.IsValid)
      {
        string vbCrLf = "<br>";
        string strResult = "";

        strResult = "Name: " + cmbChoose.SelectedValue + " " + txtName.Text + vbCrLf +
          "Number of children: " + txtNumberOfChildren.Text + vbCrLf +
          "Email: " + txtEmail.Text + vbCrLf +
          "Birthday: " + txtBirthday.Text + vbCrLf +
          "Suggestions: " + txtSuggest.Text;

        lblResult.Text = strResult;
      }
      else
      // Not this.IsValid 
      {
      }
      // this.IsValid 

    }
    // cmdMakeMember_Click(System.Object sender, System.EventArgs theEventArguments)

    private void cstvPassword_ServerValidate(System.Object theSender, System.Web.UI.WebControls.ServerValidateEventArgs theServerValidateEventArguments)
    //***
    // Action
    //   - Check if the length of the password is mimimum 8 long
    // Called by
    //   - User action (validating on server)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260702 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260702 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (theServerValidateEventArguments.Value.Length < 8)
      {
        theServerValidateEventArguments.IsValid = false;
      }
      else
      // theServerValidateEventArguments.Value.Length >= 8
      {
        theServerValidateEventArguments.IsValid = true;
      }
      // theServerValidateEventArguments.Value.Length < 8

    }
    // cstvPassword_ServerValidate(System.Object, System.Web.UI.WebControls.ServerValidateEventArgs) Handles cstvPassword.ServerValidate

    protected void Page_Load(System.Object theSender, System.EventArgs theEventArguments)

    //***
    // Action
    //   - Actions when the page is loaded
    //   - Get the first user language
    //   - Set the culture of the thread to the first user language
    // Called by
    //   - User action (Loading the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260702 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260702 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intPosition;
      string strCulture;

      strCulture = Request.UserLanguages[0];
      intPosition = strCulture.IndexOf(';');

      if (intPosition > -1)
      {
        strCulture = strCulture.Substring(0, intPosition);
      }
      else
      // intPosition <= -1
      {
      }
      // intPosition > -1

      System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo(strCulture);
    }
    // Page_Load(System.Object, System.EventArgs) Handles base.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
    // wfrmRequired

  }
// CopyPaste.Learning