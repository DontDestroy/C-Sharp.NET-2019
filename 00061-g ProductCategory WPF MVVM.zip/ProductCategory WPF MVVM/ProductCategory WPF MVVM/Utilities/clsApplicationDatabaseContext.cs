﻿//***
// Action
//   - The class that sets up the context towards a SQL Server database
// Created
//   - CopyPaste – 20260407 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260407 – VVDW
// Proposal (To Do)
//   -
//***

using System.Data;
using Microsoft.EntityFrameworkCore;
using ProductCategory_WPF_MVVM.Models;

namespace ProductCategory_WPF_MVVM.Utilities
{

  public class cpApplicationDatabaseContext : DbContext
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    // private const string strConnectionString =
    //   @"Server=(localdb)\mssqllocaldb;Database=DemocpADONET;Trusted_Connection=True";
    private const string strConnectionString =
      @"Server=CopyPastePower\CopyPaste;Database=DemocpADONET;Trusted_Connection=True";

    #endregion

    #region "Properties"

    //***
    // Action Get and Set
    //   - Entry point for the database context to create the model towards the database
    // Called by
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    public DbSet<Product> Product{ get; set; }
    public DbSet<ProductCategory> ProductCategory { get; set; }

    #endregion

    #region "Methods"

    #region "Overrides"

    protected override void OnConfiguring(DbContextOptionsBuilder theOptionsBuilder)
    //***
    // Action
    //   - While configuring the database context, we say it is a SQL Server database
    // Called by
    //   - System action (Configuring the database context)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theOptionsBuilder.UseSqlServer(strConnectionString);
    }
    // OnConfiguring(DbContextOptionsBuilder)

    protected override void OnModelCreating(ModelBuilder theModelBuilder)
    //***
    // Action
    //   - While configuring the database context, we set some properties
    //   - I do not want to use the automatic generation of the keys, because I will seed the database with default values 
    // Called by
    //   - System action (Configuring the database context)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260407 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260407 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theModelBuilder.Entity<Product>().Property(theProduct => theProduct.ProductId).ValueGeneratedNever();
      theModelBuilder.Entity<ProductCategory>().Property(theProductCategory => theProductCategory.ProductCategoryId).ValueGeneratedNever();
      base.OnModelCreating(theModelBuilder);
    }
    // OnModelCreating(ModelBuilder)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpApplicationDatabaseContext

}
// DemoEntityFrameWorkCore