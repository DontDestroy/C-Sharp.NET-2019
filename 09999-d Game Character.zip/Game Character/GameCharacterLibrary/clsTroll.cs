﻿//***
// Action
//   - Implementation of a cpTroll
//     - Inherits from cpGameCharacter
//   - The way a cpTroll can fight given thru a delegate and an event
// Created
//   - CopyPaste – 20240806 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240806 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Game.Weapon.Library;

namespace CopyPaste.Game.Character.Library
{

	public class cpTroll : cpGameCharacter
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpTroll
		/// </summary>
		public cpTroll() : base()
		//***
		// Action
		//   - Basic constructor
		//   - Define how a cpTroll fights (with a weapon)
		// Called by
		//   - CopyPaste.Game.Character.Test.cpProgram.Main()
		// Calls
		//   - CopyPaste.Game.Weapon.Library.cpAxe()
		//   - cpGameCharacter()
		//   - cpGameCharacter.HowToFight(cpiWeapon) (Set)
		// Created
		//   - CopyPaste – 20240806 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240806 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			HowToFight = new cpAxe();
		}
		// cpTroll()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// cpTroll

}
// CopyPaste.Game.Character.Library