//***
// Action
//   - If-Then-Else statement
// Created
//   - CopyPaste � 20220117 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220117 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace If
{

  class cpIf
	{

    static void Main()
    //***
    // Action
    //   - Ask for an age
    //   - Depending on age, show message at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - byte System.Convert.ToByte(string)
    //   - string System.Console.ReadLine()
    //   - System.Console.Write(string)
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220117 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220117 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      byte bytAge;
      
      Console.Write("Type your age: ");
      bytAge = Convert.ToByte(Console.ReadLine());
      
      if (bytAge < 18)
      {
        Console.WriteLine("Not accepted");
      }
      else
        // bytAge >= 18
      {
        Console.WriteLine("Welcome");
      }
      // bytAge < 18
      
      Console.ReadLine();
    }
    // Main()

  }
  // cpIf

}
// If