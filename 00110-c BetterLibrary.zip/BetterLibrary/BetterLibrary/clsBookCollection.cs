//***
// Action
//   - Implementation of cpBookCollection
//   - A collection of all the books
// Created
//   - CopyPaste � 20240227 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240227 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpBookCollection : System.Collections.DictionaryBase
  {

    #region "Constructors / Destructors"

    public cpBookCollection()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpLibrary()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpBookCollection()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public cpBook this[string strTitle]
    {

      get
        //***
        // Action Get
        //   - Test if dictionary contains an item with a certain title
        //   - If so
        //     - Return that cpBook (Object casted to cpBook)
        //   - If not
        //     - Return null
        // Called by
        //   - cpBook cpLibrary.CheckOut(string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240227 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240227 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (Dictionary.Contains(strTitle))
        {
          return (cpBook) Dictionary[strTitle];
        }
        else
        {
          return null;
        }

      }
      // cpBook this[string] (Get)

    }
    // cpBook this[string]

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Add(cpBook thecpBook)
      //***
      // Action 
      //   - Add a cpBook to the Dictionary
      //     - The key becomes the title
      //     - The item is the cpBook itself
      // Called by
      //   - cpLibrary.CheckIn(cpBook)
      // Calls
      //   - string cpBook.Title (Get)
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Dictionary.Add(thecpBook.Title, thecpBook);
    }
    // Add(cpBook)
		
    public void Remove(string strTitle)
      //***
      // Action 
      //   - Remove a cpBook from the Dictionary
      //     - Using the title (key)
      // Called by
      //   - cpLibrary.CheckOut(string)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240227 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240227 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Dictionary.Remove(strTitle);
    }
    // Remove(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBookCollection

}
// CopyPaste.Learning