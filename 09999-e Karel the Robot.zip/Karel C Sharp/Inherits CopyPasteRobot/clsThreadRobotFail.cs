﻿//***
// Action
//   - A definition of a ThreadRobotFail
// Created
//   - CopyPaste – 20251106 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251106 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using java.lang;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpThreadRobotFail : cpCopyPasteRobot, Runnable
	{

		#region "Constructors / Destructors"

		public cpThreadRobotFail(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpThreadRobotFail starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - A new thread of the cpThreadRobotFail is defined
    //   - The thread is started
    // Called by
    //   - cpProgram.ThreadRobotFail()
    //   - cpThreadRobotFail(int, int, Directions.Direction, int) 
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Thread theRobotRunnerThread = new Thread(this);

      theRobotRunnerThread.start();
    }
    // cpThreadRobotFail(int, int, Directions.Direction, int, Color) 

    public cpThreadRobotFail(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpThreadRobotFail starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpThreadRobotFail(int, int, Directions.Direction, int, Color) (int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpThreadRobotFail(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override void run()
    //***
    // Action
    //   - Define what must be runned
    //   - Robot moves to the next beeper
    //   - Pick beeper
    //   - Robot switch off
    // Called by
    //   - cpThreadRobotFail(int, int, Directions.Direction, int, Color) 
    // Calls
    //   - cpCopyPasteRobot.MoveToBeeper()
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      MoveToBeeper();
      pickBeeper();
      turnOff();
    }
    // run()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpThreadRobotFail

}
// cpKarelTheRobot