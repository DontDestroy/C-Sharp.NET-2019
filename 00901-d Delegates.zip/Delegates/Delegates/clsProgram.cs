//***
// Action
//   - Demo of a delegate with 2 methods of multiplying
// Created
//   - CopyPaste � 20250712 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250712 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate long DoMultiply(long[] arrlngNumber);

    #endregion

    #region "Sub / Function"

    private static long FastMultiply(long[] arrlngNumber)
      //***
      // Action
      //   - Define lngResult as 1
      //   - Loop thru all the numbers
      //     - If lngNumber = 0
      //       - lngResult becomes 0
      //     - If not
      //       - lngResult is multiplied with lngNumber
      //   - Return lngResult
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      long lngResult = 1;

      foreach (long lngNumber in arrlngNumber)
      {

        if (lngNumber == 0)
        {
          lngResult = 0;
        }
        else
          // lngNumber <> 0
        {
          lngResult *= lngNumber;
        }
        // lngNumber = 0

      }
      // in arrlngNumber

      return lngResult;
    }
    // int FastMultiply(int[])

    static void Main()
      //***
      // Action
      //   - Define an array with numbers
      //   - Define a variable based on a delegate
      //   - Show the starting time of the fast multiply
      //   - Set the variable to an instance of delegate to the fast multiply
      //   - Run the delegate variable
      //   - Show te result
      //   - Show the ending time of the fast multiply
      //   - Show the starting time of the slow multiply
      //   - Set the variable to an instance of delegate to the slow multiply
      //   - Run the delegate variable
      //   - Show te result
      //   - Show the ending time of the slow multiply
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - long FastMultiply(long[])
      //   - long SlowMultiply(long[])
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      DoMultiply DoAMultiplication;
      long lngResult;
      long[] arrlngNumber = new long[] {3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14};

      // Long notation
      Console.WriteLine("Start Fast: " + DateTime.Now + "." + DateTime.Now.Millisecond);
      DoAMultiplication = new DoMultiply(FastMultiply);
      lngResult = DoAMultiplication.Invoke(arrlngNumber);
      Console.WriteLine(lngResult);
      Console.WriteLine("End Fast: " + DateTime.Now + "." + DateTime.Now.Millisecond);

      // Short notation
      Console.WriteLine("Start Fast: " + DateTime.Now + "." + DateTime.Now.Millisecond);
      DoAMultiplication = FastMultiply;
      lngResult = DoAMultiplication(arrlngNumber);
      Console.WriteLine(lngResult);
      Console.WriteLine("End Fast: " + DateTime.Now + "." + DateTime.Now.Millisecond);

      Console.WriteLine("Start Slow: " + DateTime.Now + "." + DateTime.Now.Millisecond);
      DoAMultiplication = new DoMultiply(SlowMultiply);
      lngResult = DoAMultiplication(arrlngNumber);
      Console.WriteLine(lngResult);
      Console.WriteLine("End Slow: " + DateTime.Now + "." + DateTime.Now.Millisecond);
      Console.ReadLine();
    }
    // Main()

    private static long SlowMultiply(long[] arrlngNumber)
      //***
      // Action
      //   - Define lngResult as 1
      //   - Loop thru all the numbers
      //     - If lngNumber = 0
      //       - lngResult becomes 0
      //     - If not
      //       - lngHelpResult = 0
      //       - Loop from 1 to lngResult
      //         - lngHelpResult is added with lngNumber
      //       - lngResult becomes lngHelpResult
      //   - Return lngResult
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250712 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250712 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      long lngResult = 1;

      foreach (long lngNumber in arrlngNumber)
      {

        if (lngNumber == 0)
        {
          lngResult = 0;
        }
        else
          // lngNumber <> 0
        {
          long lngCounter;
          long lngHelpResult = 0;

          for (lngCounter = 1; lngCounter <= lngResult; lngCounter++)
          {
            lngHelpResult += lngNumber;
          }
          // lngCounter = lngResult + 1

          lngResult = lngHelpResult;
        }
        // lngNumber == 0

      }
      // in arrlngNumber

      return lngResult;
    }
    // int FastMultiply(int[])

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning
