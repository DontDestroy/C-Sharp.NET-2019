//***
// Action
//   - Implementation of cpPerson
// Created
//   - CopyPaste � 20240705 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240705 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpPerson
  {

    #region "Constructors / Destructors"

    public cpPerson(string strName, int lngAge, string strPhone)
      //***
      // Action
      //   - Constructor of a cpPerson with a given Name, Age and Phone number
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mstrName = strName;
      mlngAge = lngAge;
      mstrPhone = strPhone;
    }
    // cpPerson(string, int, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    public int mlngAge;
    public string mstrName;
    public string mstrPhone;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ShowPerson()
      //***
      // Action
      //   - Show the relevant information of a cpPerson
      // Called by
      //   - modSimpleClass.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240705 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240705 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Name: " + mstrName);
      Console.WriteLine("Age: " + mlngAge);
      Console.WriteLine("Phone: " + mstrPhone);
    }
		// ShowPerson()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpPerson

}
// CopyPaste.Learning