<%@ Page Language="C#" %>

<%@ Import Namespace="System.IO" %>

<html>
<head>
  <title>ShowFile</title>
</head>
<body>
  <center>
    <h1>ASP.NET File Demo</h1>
  </center>
  <hr>
  <pre> 
    <!-- VVDW - Take carriage returns and linefeeds from the file to read that are not html -->
    
    <%

      string strFilename;

      strFilename = Request.Form["strFilename"];

      if (strFilename == "")
      {
        Response.Write("Filename not specified");
      }
      else
      {

        try
        {
          StreamReader strReader = new StreamReader(strFilename);
          string strContent;

          Response.Write("<br>");
          strContent = strReader.ReadToEnd();
          Response.Write(strContent + "<br>");
          strReader.Close();
        }
        catch (Exception theException)
        {
          Response.Write("Error opening or reading file");
        }

      }

    %>

  </pre>
</body>
</html>
