//***
// Action
//   - Preview, Page Settings and Print a text
// Created
//   - CopyPaste � 20240719 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240719 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPrintText: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtText;
    internal System.Windows.Forms.Button cmdPrint;
    internal System.Windows.Forms.Button cmdPreview;
    internal System.Windows.Forms.Button cmdPageSetup;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPrintText));
      this.txtText = new System.Windows.Forms.TextBox();
      this.cmdPrint = new System.Windows.Forms.Button();
      this.cmdPreview = new System.Windows.Forms.Button();
      this.cmdPageSetup = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(16, 64);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(264, 232);
      this.txtText.TabIndex = 7;
      this.txtText.Text = "";
      // 
      // cmdPrint
      // 
      this.cmdPrint.Location = new System.Drawing.Point(200, 24);
      this.cmdPrint.Name = "cmdPrint";
      this.cmdPrint.TabIndex = 6;
      this.cmdPrint.Text = "Print";
      this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
      // 
      // cmdPreview
      // 
      this.cmdPreview.Location = new System.Drawing.Point(110, 24);
      this.cmdPreview.Name = "cmdPreview";
      this.cmdPreview.TabIndex = 5;
      this.cmdPreview.Text = "Preview";
      this.cmdPreview.Click += new System.EventHandler(this.cmdPreview_Click);
      // 
      // cmdPageSetup
      // 
      this.cmdPageSetup.Location = new System.Drawing.Point(20, 24);
      this.cmdPageSetup.Name = "cmdPageSetup";
      this.cmdPageSetup.TabIndex = 4;
      this.cmdPageSetup.Text = "Page Setup";
      this.cmdPageSetup.Click += new System.EventHandler(this.cmdPageSetup_Click);
      // 
      // frmPrintText
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(296, 325);
      this.Controls.Add(this.txtText);
      this.Controls.Add(this.cmdPrint);
      this.Controls.Add(this.cmdPreview);
      this.Controls.Add(this.cmdPageSetup);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPrintText";
      this.Text = "Print Text";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPrintText'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPrintText()
      //***
      // Action
      //   - Create instance of 'frmPrintText'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      //   - PrintPage(System.Object theSender, PrintPageEventArgs thePrintPageEventArguments)
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      mprndoc.PrintPage += new PrintPageEventHandler(PrintPage);
    }
    // frmPrintText()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private PrintDialog mdlgPrint = new PrintDialog();
    private PageSetupDialog mdlgPageSetup = new PageSetupDialog();
    private PrintPreviewDialog mdlgPrintPreview = new PrintPreviewDialog();
    private PrinterSettings mdlgPrinterSettings = new PrinterSettings();
    private PrintDocument mprndoc = new PrintDocument();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdPageSetup_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Assign the Print Document to the Page Setup Dialog
      //   - Show Page Setup Dialog
      //   - If OK is hit
      //     - Convert the margins to centimeter (there is an error in the dialogbox)
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdlgPageSetup.Document = mprndoc;

      if (mdlgPageSetup.ShowDialog() == DialogResult.OK)
      {
        mdlgPageSetup.PageSettings.Margins.Top = Convert.ToInt32(mdlgPageSetup.PageSettings.Margins.Top * 2.54);
        mdlgPageSetup.PageSettings.Margins.Left = Convert.ToInt32(mdlgPageSetup.PageSettings.Margins.Left * 2.54);
        mdlgPageSetup.PageSettings.Margins.Right = Convert.ToInt32(mdlgPageSetup.PageSettings.Margins.Right * 2.54);
        mdlgPageSetup.PageSettings.Margins.Bottom = Convert.ToInt32(mdlgPageSetup.PageSettings.Margins.Bottom * 2.54);
      }
      else
        // mdlgPageSetup.ShowDialog() <> DialogResult.OK
      {
      }
      // mdlgPageSetup.ShowDialog() = DialogResult.OK
    
    }
    // cmdPageSetup_Click(System.Object, System.EventArgs) Handles cmdPageSetup.Click

    private void cmdPreview_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Assign the Print Document to the Print Preview Dialog
      //   - Show Print Preview Dialog
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdlgPrintPreview.Document = mprndoc;
      mdlgPrintPreview.ShowDialog();
    }
    // cmdPreview_Click(System.Object, System.EventArgs) Handles cmdPreview.Click

    private void cmdPrint_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Assign the Print Document to the Print Dialog
      //   - Assign the Printer Settings to the Print Dialog
      //   - Show Print Dialog
      //   - If OK is hit
      //     - Print the document
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdlgPrint.Document = mprndoc;
      mdlgPrint.PrinterSettings = mdlgPrinterSettings;

      if (mdlgPrint.ShowDialog() == DialogResult.OK)
      {
        mprndoc.Print();
      }
      else
        // mdlgPrint.ShowDialog() <> DialogResult.OK 
      {
      }
      // mdlgPrint.ShowDialog() = DialogResult.OK 
    
    }
    // cmdPrint_Click(System.Object, System.EventArgs) Handles cmdPrint.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPrintText
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmPrintText()
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPrintText());
    }
    // Main() 
    
    private void PrintPage(System.Object theSender, PrintPageEventArgs thePrintPageEventArguments)
      //***
      // Action
      //   - If Page Settings was opened
      //     - Get the left and top margin
      //     - Draw the text at that position
      //   - If not
      //     - Show message
      // Called by
      //   - frmPrintText()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - Only left and top are taken into account
      //   - This exercise is for demo purpose
      //***
    {
      float fltX;
      float fltY;

      if (mdlgPageSetup.PageSettings == null)
      {
        MessageBox.Show("First go to Page Setup");
      }
      else
        // mdlgPageSetup.PageSettings <> null
      {
        fltX = mdlgPageSetup.PageSettings.Margins.Left;
        fltY = mdlgPageSetup.PageSettings.Margins.Top;
        thePrintPageEventArguments.Graphics.DrawString(txtText.Text, txtText.Font, Brushes.Black, fltX, fltY);
      }
      // mdlgPageSetup.PageSettings = null

    }
    // PrintPage(System.Object theSender, PrintPageEventArgs thePrintPageEventArguments)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPrintText

}
// CopyPaste.Learning