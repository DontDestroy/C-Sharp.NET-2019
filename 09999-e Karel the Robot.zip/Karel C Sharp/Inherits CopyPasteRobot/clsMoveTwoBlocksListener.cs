﻿//***
// Action
//   - A definition of a MoveTwoBlocksListener
// Created
//   - CopyPaste – 20251028 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251028 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpMoveTwoBlocksListener: cpCopyPasteRobot, cpinfRobotListener
	{

		#region "Constructors / Destructors"

		public cpMoveTwoBlocksListener(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpMoveTwoBlocksListener starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpMoveTwoBlocksListener(int, int, Directions.Direction, int) 
    //   - cpProgram.Observer()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpMoveTwoBlocksListener(int, int, Directions.Direction, int, Color) 

    public cpMoveTwoBlocksListener(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpMoveTwoBlocksListener starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpMoveTwoBlocksListener(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpMoveTwoBlocksListener(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Action()
    //***
    // Action
    //   - Move two forward
    //   - Will be executed when there is a key given by the robot (or something else) that is observed
    // Called by
    //   -
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      move();
      move();
    }
    // Action()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpMoveTwoBlocksListener

}
// cpKarelTheRobot