﻿//***
// Action
//   - The definition of a cpEmployee
// Created
//   - CopyPaste – 20230329 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230329 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.HumanResources
{

  public class cpEmployee
  {

    #region "Constructors / Destructors"

    public cpEmployee(int intUniqueNumber, string strFirstName, string strLastName)
    //***
    // Action
    //   - Creating an instance of a cpEmployee
    // Called by
    //   - cpCompany(string)
    // Calls
    //   - int EmployeeNumber (Set)
    //   - string FirstName (Set)
    //   - string LastName (Set)
    // Created
    //   - CopyPaste – 20230329 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230329 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      EmployeeNumber = intUniqueNumber;
      FirstName = strFirstName;
      LastName = strLastName;
    }
    // cpEmployee(int, string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"
    
    public int EmployeeNumber { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Name { get => FirstName + " " + LastName; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpEmployee

}
// CopyPaste.HumanResources