﻿//***
// Action
//   - Demo of restrictions with Linq.
//   - Keyword Where
// Created
//   - CopyPaste – 20230416 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230416 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.HumanResources
{

  public class cpInvestment
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public long Amount { get; set; }
    public DateTime DatePayment { get; set; }
    public int EmployeeNumber { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion  

  }
  // cpInvestment

}
// CopyPaste.HumanResources 