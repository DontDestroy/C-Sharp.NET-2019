//***
// Action
//   - Testroutines for cpCard, cpHand and cpDeck
// Created
//   - CopyPaste � 20240128 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240128 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Games
{

  public class cpProgram
	{

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Creating a card (theTwoOfClubs)
      //   - Creating a card (theQueenOfHearts)
      //   - Creating a card (theAceOfSpades), but with wrong FaceValue and wrong Suit
      //   - Changing the FaceValue of theAceOfSpades to cpFaceValue.Ace
      //   - Changing the Suit of theAceOfSpades to cpSuit.Spades
      //   - Showing the information of the 3 cards
      //   - Create a hand using an array of cards
      //   - Creating an empty hand
      //   - Count the cards of both hands
      //   - Using the indexer / default property of a hand
      //   - Let the indexer / default property fail
      //   - Add a card to a hand
      //   - Count the cards of the hand again
      //   - Check if a hand contains a specific card using a card (True and False)
      //   - Check if a hand contains a specific card using a suit and a facevalue (True and False)
      //   - Remove a card from a hand using a card
      //   - Remove a card from a hand using a suit and a facevalue
      //   - Make a hand with 5 cards
      //   - Show the content of the hand
      //   - Remove the pairs
      //   - Show the content of the hand
      //   - Create a deck of 52 cards
      //   - Count the cards of the deck
      //   - Create a deck of 12 cards (All suits, Jack, Queen, King)
      //   - Count the cards of the deck
      //   - Using the indexer / default property of a deck
      //   - Let the indexer / default property fail
      //   - Show the order of the second deck (12 cards)
      //   - Shuffle
      //   - Show the order of the second deck (12 cards)
      //   - Shuffle first deck (52 cards)
      //   - Draw one by one the cards and show them
      //   - Make 4 hands
      //   - Deal the seconde deck (12 cards) over the 4 hands
      //   - Show the content of the hands
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - bool cpHand.Contains(cpCard) 
      //   - bool cpHand.Contains(cpSuit, cpFaceValue)
      //   - cpCard(cpSuit, cpFaceValue)
      //   - cpCard cpDeck[int] (Get)
      //   - cpCard cpDeck.Draw()
      //   - cpCard cpHand[int] (Get)
      //   - cpCard.FaceValue(cpFaceValue) (Set)
      //   - cpCard.Suit(cpSuit) (Set)
      //   - cpDeck()
      //   - cpDeck.Deal(cpHand[])
      //   - cpDeck.Shuffle()
      //   - cpFaceValue cpCard.FaceValue (Get)
      //   - cpHand()
      //   - cpHand(cpCard[])
      //   - cpHand.Add(cpCard)
      //   - cpHand.Remove(cpCard)
      //   - cpHand.Remove(cpSuit, cpFaceValue)
      //   - cpHand.RemovePairs()
      //   - cpSuit cpCard.Suit (Get)
      //   - int cpDeck.Count (Get)
      //   - int cpHand.Count (Get)
      // Created
      //   - CopyPaste � 20240128 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240128 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Deck of cards Tests");
      Console.WriteLine("");
      Console.WriteLine("Card Tests");
      
      cpCard[] arrcpCards;
      cpFaceValue[] arrcpFaceValues;
      cpHand[] arrcpHands;
      cpSuit[] arrcpSuits;

      int lngCounterCard;
      int lngCounterDeck;
      int lngCounterHand;

      cpHand thecpFirstHand;
      cpHand thecpFirstHandDeal;
      cpHand thecpFourthHandDeal;
      cpHand thecpSecondHand;
      cpHand thecpSecondHandDeal;
      cpHand thecpThirdHandDeal;

      cpDeck thecpFirstDeck;
      cpDeck thecpSecondDeck;

      cpCard theAceOfSpades;
      cpCard theDrawCard;
      cpCard theQueenOfHearts;
      cpCard theTwoOfClubs;

      theTwoOfClubs = new cpCard(cpSuit.Clubs, cpFaceValue.Two);
      theQueenOfHearts = new cpCard(cpSuit.Hearts, cpFaceValue.Queen);
      theAceOfSpades = new cpCard(cpSuit.Diamonds, cpFaceValue.Four);

      theAceOfSpades.Suit = cpSuit.Spades;
      theAceOfSpades.FaceValue = cpFaceValue.Ace;

      Console.WriteLine("Suit: {0} - Face Value: {1}", theTwoOfClubs.Suit, theTwoOfClubs.FaceValue);
      Console.WriteLine("Suit: {0} - Face Value: {1}", theQueenOfHearts.Suit, theQueenOfHearts.FaceValue);
      Console.WriteLine("Suit: {0} - Face Value: {1}", theAceOfSpades.Suit, theAceOfSpades.FaceValue);

      Console.WriteLine("");
      Console.WriteLine("Hand Tests");

      arrcpCards = new cpCard[] {theQueenOfHearts, theTwoOfClubs};
      thecpFirstHand = new cpHand(arrcpCards);
      thecpSecondHand = new cpHand();

      // VVDW Test: Count
      //   Expect: Hand has 2 Cards
      Console.WriteLine("1st Hand has {0} cards.", thecpFirstHand.Count);
      //   Expect: Hand has 0 Cards
      Console.WriteLine("2nd Hand has {0} cards.", thecpSecondHand.Count);

      // VVDW Test: Indexer / Default Property
      //   Expect: First Card theQueenOfHearts is shown
      Console.WriteLine("1st Card in 1st Hand is Suit: {0} - Face Value: {1}.", thecpFirstHand[0].Suit, thecpFirstHand[0].FaceValue);
      //   Expect: Second Card theTwoOfClubs is shown
      Console.WriteLine("2nd Card in 1st Hand is Suit: {0} - Face Value: {1}.", thecpFirstHand[1].Suit, thecpFirstHand[1].FaceValue);

      try
      {
        // Expect: First Card of 2nd Hand is shown
        // Expect: Error message
        Console.WriteLine("1st Card in 2nd Hand is Suit: {0} - Face Value: {1}.", thecpSecondHand[0].Suit, thecpSecondHand[0].FaceValue);
      }
      catch (ArgumentOutOfRangeException theException)
      {
        Console.WriteLine(theException.ParamName);
      }

      // VVDW Test: Add(cpCard)
      //   Expect: Card theAceOfSpades is added to the second Hand
      thecpSecondHand.Add(theAceOfSpades);
      //   Expect: Hand has 1 card
      Console.WriteLine("2nd Hand has {0} cards.", thecpSecondHand.Count);
      //   Expect: First Card theAceOfSpades is shown
      Console.WriteLine("1st Card in 2nd Hand is Suit: {0} - Face Value: {1}.", thecpSecondHand[0].Suit, thecpSecondHand[0].FaceValue);

      // VVDW Test: Contains(cpCard)
      //   Expect: Card theQueenOfHearts is there --> True
      Console.WriteLine("1st Hand contains Queen Of Hearts: {0}.", thecpFirstHand.Contains(theQueenOfHearts));
      //   Expect: Card theAceOfSpades is not there --> False
      Console.WriteLine("1st Hand contains Ace Of Spades: {0}.", thecpFirstHand.Contains(theAceOfSpades));

      // VVDW Test: Contains(cpSuit, cpValue)
      //   Expect: Card theQueenOfHearts is not there --> False
      Console.WriteLine("2nd Hand contains Queen Of Hearts: {0}.", thecpSecondHand.Contains(cpSuit.Hearts, cpFaceValue.Queen));
      //   Expect: Card theAceOfSpades is there --> True
      Console.WriteLine("2nd Hand contains Ace Of Spades: {0}.", thecpSecondHand.Contains(cpSuit.Spades, cpFaceValue.Ace));

      // VVDW Test: Remove(cpCard)
      //   Expect: Card theQueenOfHearts will be removed
      thecpFirstHand.Remove(theQueenOfHearts);
      //   Expect: Card theQueenOfHearts is not there --> False
      Console.WriteLine("1st Hand contains Queen Of Hearts: {0}.", thecpFirstHand.Contains(theQueenOfHearts));
      //   Expect: Card theTwoOfClubs will be removed
      thecpFirstHand.Remove(cpSuit.Clubs, cpFaceValue.Two);
      //   Expect: Card theTwoOfClubs is not there --> False
      Console.WriteLine("1st Hand contains Two Of Clubs: {0}.", thecpFirstHand.Contains(theTwoOfClubs));

      // VVDW Test: Add(cpSuit, cpFaceValue)
      thecpFirstHand.Add(new cpCard(cpSuit.Diamonds, cpFaceValue.Ace));
      thecpFirstHand.Add(new cpCard(cpSuit.Clubs, cpFaceValue.Ace));
      thecpFirstHand.Add(new cpCard(cpSuit.Spades, cpFaceValue.Ace));
      thecpFirstHand.Add(new cpCard(cpSuit.Diamonds, cpFaceValue.Ten));
      thecpFirstHand.Add(new cpCard(cpSuit.Hearts, cpFaceValue.Ten));

      // VVDW Test: Remove Pairs
      //   Expect: Before remove pairs Hand has 5 Cards
      Console.WriteLine("Before Remove Pairs, Hand has {0} cards.", thecpFirstHand.Count);
      thecpFirstHand.RemovePairs();
      //   Expect: After remove pairs Hand has 1 Card
      Console.WriteLine("After Remove Pairs, Hand has {0} cards.", thecpFirstHand.Count);

      Console.WriteLine("");
      Console.WriteLine("Deck Tests");

      // VVDW Test: Create normal Deck
      thecpFirstDeck = new cpDeck();
      //   Expect: There are 52 Cards
      Console.WriteLine("1st Deck has {0} cards.", thecpFirstDeck.Count);

      // VVDW Test: Create special Deck
      arrcpSuits = new cpSuit[] {cpSuit.Clubs, cpSuit.Diamonds, cpSuit.Hearts, cpSuit.Spades};
      arrcpFaceValues = new cpFaceValue[] {cpFaceValue.Jack, cpFaceValue.King, cpFaceValue.Queen};
      thecpSecondDeck = new cpDeck(arrcpSuits, arrcpFaceValues);
      //   Expect: There are 12 Cards
      Console.WriteLine("2st Deck has {0} cards.", thecpSecondDeck.Count);

      // VVDW Test: Indexer / Default Property
      //   Expect: First Card of First Deck is shown
      Console.WriteLine("1st Card in 1st Deck is Suit: {0} - Face Value: {1}.", thecpFirstDeck[0].Suit, thecpFirstDeck[0].FaceValue);
      //   Expect: Second Card of First Deck is shown
      Console.WriteLine("1st Card in 2nd Deck is Suit: {0} - Face Value: {1}.", thecpSecondDeck[0].Suit, thecpSecondDeck[0].FaceValue);

      try
      {
        // Expect: 13th Card of 2nd Deck is shown
        // Expect: Error message
        Console.WriteLine("13th Card in 2nd Deck is Suit: {0} - Face Value: {1}.", thecpSecondDeck[13].Suit, thecpSecondDeck[13].FaceValue);
      }
      catch (ArgumentOutOfRangeException theException)
      {
        Console.WriteLine(theException.ParamName);
      }

      // VVDW Test: Loop thru deck
      //   Expect: The order of the cards is shown

      Console.WriteLine("");
      Console.WriteLine("Deck Original order");

      for (lngCounterDeck = 0; lngCounterDeck < thecpSecondDeck.Count; lngCounterDeck++)
      {
        Console.WriteLine("Next Card in 2nd Deck is Suit: {0} - Face Value: {1}.", thecpSecondDeck[lngCounterDeck].Suit, thecpSecondDeck[lngCounterDeck].FaceValue);
      }
      // lngCounterDeck = thecpSecondDeck.Count

      // VVDW Test: Shuffle deck
      //   Expect: The order of the cards is changed
      thecpSecondDeck.Shuffle();

      Console.WriteLine("");
      Console.WriteLine("Deck shuffled order");

      for (lngCounterDeck = 0; lngCounterDeck < thecpSecondDeck.Count; lngCounterDeck++)
      {
        Console.WriteLine("Next Card in 2nd Deck is Suit: {0} - Face Value: {1}.", thecpSecondDeck[lngCounterDeck].Suit, thecpSecondDeck[lngCounterDeck].FaceValue);
      }
      // lngCounterDeck = thecpSecondDeck.Count

      // VVDW Test: Draw deck
      //   Expect: The 52 cards are shuffled and drawn one by one
      thecpFirstDeck.Shuffle();

      Console.WriteLine("");
      Console.WriteLine("Draw 52 cards one by one");

      while (thecpFirstDeck.Count != 0)
      {
        theDrawCard = thecpFirstDeck.Draw();
        Console.WriteLine("Next Card from 1st Deck is Suit: {0} - Face Value: {1}.", theDrawCard.Suit, theDrawCard.FaceValue);
      }
      // thecpFirstDeck.Count = 0

      // VVDW Test: Deal deck
      //   Expect: The 12 cards are divided over 4 hands
      thecpFirstHandDeal = new cpHand();
      thecpSecondHandDeal = new cpHand();
      thecpThirdHandDeal = new cpHand();
      thecpFourthHandDeal = new cpHand();

      arrcpHands = new cpHand[] {thecpFirstHandDeal, thecpSecondHandDeal, thecpThirdHandDeal, thecpFourthHandDeal};

      thecpSecondDeck.Deal(arrcpHands);

      Console.WriteLine("");
      Console.WriteLine("Hands after dealing deck of 12 cards");

      for (lngCounterHand = 0; lngCounterHand < arrcpHands.Length; lngCounterHand++)
      {

        for (lngCounterCard = 0; lngCounterCard < arrcpHands[lngCounterHand].Count; lngCounterCard++)
        {
          Console.WriteLine("Card {0} in Hand {1} is Suit: {2} - Face Value: {3}.", lngCounterCard, lngCounterHand, arrcpHands[lngCounterHand][lngCounterCard].Suit, arrcpHands[lngCounterHand][lngCounterCard].FaceValue);
        }
        // lngCounterCard = arrcpHands[lngCounterHand].Count

      }
      // lngCounterHand = arrcpHands.Count

      Console.WriteLine("");
      Console.WriteLine("Hit enter to stop test program.");
      Console.ReadLine();
    }
    // Main()
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpProgram

}
// CopyPaste.Learning.Games