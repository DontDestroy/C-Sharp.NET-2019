﻿//***
// Action
//   - A definition of a RemoveBeepersTillWallError01
// Created
//   - CopyPaste – 20251025 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251025 – VVDW
// Proposal (To Do)
//   - The example is correct, but the starting point in the world where it is used not
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpRemoveBeepersTillWallError01 : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpRemoveBeepersTillWallError01(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpRemoveBeepersTillWallError01 starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpProgram.RemoveBeepersTillWallError01()
    //   - cpRemoveBeepersTillWallError01(int, int, Directions.Direction, int)
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRemoveBeepersTillWallError01(int, int, Directions.Direction, int, Color) 

    public cpRemoveBeepersTillWallError01(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpRemoveBeepersTillWallError01 starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpRemoveBeepersTillWallError01(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpRemoveBeepersTillWallError01(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void RemoveBeepersTillWall()
    //***
    // Action
    //   - A row of beepers will be removes
    //   - As long the front is clear
    //     - Move
    //     - Pick beeper
    // Called by
    //   - cpProgram.RemoveBeepersTillWallError01()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251025 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251025 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      while (frontIsClear())
      {
        move();
        pickBeeper();
      }
      // frontIsClear()

    }
    // RemoveBeepersTillWall()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpRemoveBeepersTillWallError01

}
// cpKarelTheRobot