//***
// Action
//   - Write and read message from console screen
// Created
//   - CopyPaste � 20210823 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20210823 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Greeting
{

  class cpGreeting
	{

		static void Main()
    //***
    // Action
    //   - Show 2 messages
    //   - Read info
    //   - Show 4 messages
    //   - Read info
    // Called by
    //   - 
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.Write(string)
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20210823 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20210823 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      string strName;

      Console.WriteLine("Welcome to C# .NET 2019!");
      Console.Write("Please type your name: ");
      strName = Console.ReadLine();
      Console.WriteLine();
      Console.WriteLine("Hello, {0}!", strName);
      Console.WriteLine();
      Console.WriteLine("Press Enter to quit ...");
      Console.ReadLine();
		}
    // Main()

  }
  // cpGreeting

}
// Greeting