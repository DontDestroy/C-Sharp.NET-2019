//***
// Action
//   - Read info from console screen
// Created
//   - CopyPaste � 20220111 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220111 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace ReadLine
{

  class cpReadLine
	{

    static void Main()
    //***
    // Action
    //   - Ask for a size in centimeter
    //   - Calculate that size in inches
    //   - Show result
    //   - Ask for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - decimal System.Convert.ToDecimal(string)
    //   - System.Console.ReadLine()
    //   - System.Console.Write(string)
    //   - System.Console.WriteLine()
    //   - System.Console.WriteLine(string)
    //   - System.Console.WriteLine(string, System.Object)
    //   - System.Console.WriteLine(string, System.Object, System.Object)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      const decimal decCmInch = 2.54M;

      decimal decCm;
      decimal decInch;

      Console.Write("Type a length in cm: ");
      decCm = Convert.ToDecimal(Console.ReadLine());

      decInch = decCm / decCmInch;
      
      Console.WriteLine();
      Console.WriteLine("Length in inch: " + decInch);
      Console.WriteLine("Length in inch: {0}", decInch);
      Console.WriteLine("Length {0} cm is {1} inch", decCm, decInch);
      Console.ReadLine();
    }
    // Main()

  }
  // cpReadLine

}
// ReadLine