﻿//***
// Action
//   - Check the validations on an extension
// Created
//   - CopyPaste – 20260121 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260121 – VVDW
// Proposal (To Do)
//   - Not used in program, just for explanation
//***

namespace CopyPaste.Learning
{

  public class cpCheckExtension: cpCheckString
  {

    #region "Constructors / Destructors"

    public cpCheckExtension(cpCheckExtension theExtension) : this(theExtension.StringValue)
      //***
      // Action
      //   - Define a new instance with a given check extension
      // Called by
      //   - cpCheckBusinessPhoneNumber(cpCheckBusinessPhoneNumber)
      //   - User action (Creating an instance)
      // Calls
      //   - string cpCheckString.StringValue (Get)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpCheckExtension(cpCheckExtension)

    public cpCheckExtension(string strExtension) : base()
      //***
      // Action
      //   - Define a new instance with a given extension
      // Called by
      //   - cpCheckBusinessPhoneNumber(cpCheckBusinessPhoneNumber)
      //   - User action (Creating an instance)
      // Calls
      //   - cpCheckString()
      //   - cpCheckString.StringValue(string) (Set)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      StringValue = strExtension;
    }
    // cpCheckExtension(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    protected override void DefineValidCharacters()
      //***
      // Action
      //   - Define the valid characters for an extension
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      marrchrValid = new string[] {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
    }
    // DefineValidCharacters()

    protected override cpInvalidStringException ThrowException(string strInvalidExtension)
      //***
      // Action
      //   - Throw an exception with information
      // Called by
      //   - 
      // Calls
      //   - cpInvalidExtensionException(string)
      // Created
      //   - CopyPaste – 20260121 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260121 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      throw new cpInvalidExtensionException(strInvalidExtension);
    }
    // cpInvalidStringException ThrowException(string)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
   	//#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCheckExtension

}
// CopyPaste.Learning