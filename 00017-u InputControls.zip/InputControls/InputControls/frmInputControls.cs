//***
// Action
//   - Demo of some input controls
// Created
//   - CopyPaste � 20240704 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240704 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmInputControls: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdQuit;
    internal System.Windows.Forms.PictureBox picProductOrdered06;
    internal System.Windows.Forms.PictureBox picProductOrdered05;
    internal System.Windows.Forms.PictureBox picProductOrdered04;
    internal System.Windows.Forms.PictureBox picProductOrdered03;
    internal System.Windows.Forms.PictureBox picProductOrdered02;
    internal System.Windows.Forms.PictureBox picProductOrdered01;
    internal System.Windows.Forms.ComboBox cmbPaymentMethod;
    internal System.Windows.Forms.Label lblPeripherals;
    internal System.Windows.Forms.ListBox lstPeripherals;
    internal System.Windows.Forms.GroupBox grpOffice;
    internal System.Windows.Forms.CheckBox chkCopyMachine;
    internal System.Windows.Forms.CheckBox chkCalculator;
    internal System.Windows.Forms.CheckBox chkAnsweringMachine;
    internal System.Windows.Forms.GroupBox grpComputer;
    internal System.Windows.Forms.RadioButton optLaptop;
    internal System.Windows.Forms.RadioButton optMacintosh;
    internal System.Windows.Forms.RadioButton optPC;
    internal System.Windows.Forms.Label lblProductsOrdered;
    internal System.Windows.Forms.Label lblDescription;
    internal System.Windows.Forms.Label lblTitle;


    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmInputControls));
      this.cmdQuit = new System.Windows.Forms.Button();
      this.picProductOrdered06 = new System.Windows.Forms.PictureBox();
      this.picProductOrdered05 = new System.Windows.Forms.PictureBox();
      this.picProductOrdered04 = new System.Windows.Forms.PictureBox();
      this.picProductOrdered03 = new System.Windows.Forms.PictureBox();
      this.picProductOrdered02 = new System.Windows.Forms.PictureBox();
      this.picProductOrdered01 = new System.Windows.Forms.PictureBox();
      this.cmbPaymentMethod = new System.Windows.Forms.ComboBox();
      this.lblPeripherals = new System.Windows.Forms.Label();
      this.lstPeripherals = new System.Windows.Forms.ListBox();
      this.grpOffice = new System.Windows.Forms.GroupBox();
      this.chkCopyMachine = new System.Windows.Forms.CheckBox();
      this.chkCalculator = new System.Windows.Forms.CheckBox();
      this.chkAnsweringMachine = new System.Windows.Forms.CheckBox();
      this.grpComputer = new System.Windows.Forms.GroupBox();
      this.optLaptop = new System.Windows.Forms.RadioButton();
      this.optMacintosh = new System.Windows.Forms.RadioButton();
      this.optPC = new System.Windows.Forms.RadioButton();
      this.lblProductsOrdered = new System.Windows.Forms.Label();
      this.lblDescription = new System.Windows.Forms.Label();
      this.lblTitle = new System.Windows.Forms.Label();
      this.grpOffice.SuspendLayout();
      this.grpComputer.SuspendLayout();
      this.SuspendLayout();
      // 
      // cmdQuit
      // 
      this.cmdQuit.Location = new System.Drawing.Point(208, 256);
      this.cmdQuit.Name = "cmdQuit";
      this.cmdQuit.Size = new System.Drawing.Size(80, 24);
      this.cmdQuit.TabIndex = 29;
      this.cmdQuit.Text = "Quit";
      this.cmdQuit.Click += new System.EventHandler(this.cmdQuit_Click);
      // 
      // picProductOrdered06
      // 
      this.picProductOrdered06.Location = new System.Drawing.Point(424, 216);
      this.picProductOrdered06.Name = "picProductOrdered06";
      this.picProductOrdered06.Size = new System.Drawing.Size(80, 64);
      this.picProductOrdered06.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picProductOrdered06.TabIndex = 28;
      this.picProductOrdered06.TabStop = false;
      // 
      // picProductOrdered05
      // 
      this.picProductOrdered05.Location = new System.Drawing.Point(328, 224);
      this.picProductOrdered05.Name = "picProductOrdered05";
      this.picProductOrdered05.Size = new System.Drawing.Size(80, 56);
      this.picProductOrdered05.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picProductOrdered05.TabIndex = 27;
      this.picProductOrdered05.TabStop = false;
      // 
      // picProductOrdered04
      // 
      this.picProductOrdered04.Location = new System.Drawing.Point(424, 144);
      this.picProductOrdered04.Name = "picProductOrdered04";
      this.picProductOrdered04.Size = new System.Drawing.Size(80, 64);
      this.picProductOrdered04.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picProductOrdered04.TabIndex = 26;
      this.picProductOrdered04.TabStop = false;
      // 
      // picProductOrdered03
      // 
      this.picProductOrdered03.Location = new System.Drawing.Point(328, 152);
      this.picProductOrdered03.Name = "picProductOrdered03";
      this.picProductOrdered03.Size = new System.Drawing.Size(80, 56);
      this.picProductOrdered03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picProductOrdered03.TabIndex = 25;
      this.picProductOrdered03.TabStop = false;
      // 
      // picProductOrdered02
      // 
      this.picProductOrdered02.Location = new System.Drawing.Point(432, 80);
      this.picProductOrdered02.Name = "picProductOrdered02";
      this.picProductOrdered02.Size = new System.Drawing.Size(72, 56);
      this.picProductOrdered02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picProductOrdered02.TabIndex = 24;
      this.picProductOrdered02.TabStop = false;
      // 
      // picProductOrdered01
      // 
      this.picProductOrdered01.Location = new System.Drawing.Point(328, 80);
      this.picProductOrdered01.Name = "picProductOrdered01";
      this.picProductOrdered01.Size = new System.Drawing.Size(80, 56);
      this.picProductOrdered01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picProductOrdered01.TabIndex = 23;
      this.picProductOrdered01.TabStop = false;
      // 
      // cmbPaymentMethod
      // 
      this.cmbPaymentMethod.DropDownWidth = 120;
      this.cmbPaymentMethod.Location = new System.Drawing.Point(192, 208);
      this.cmbPaymentMethod.Name = "cmbPaymentMethod";
      this.cmbPaymentMethod.Size = new System.Drawing.Size(120, 21);
      this.cmbPaymentMethod.TabIndex = 22;
      this.cmbPaymentMethod.Text = "Payment Method";
      this.cmbPaymentMethod.SelectedIndexChanged += new System.EventHandler(this.cmbPaymentMethod_SelectedIndexChanged);
      // 
      // lblPeripherals
      // 
      this.lblPeripherals.Location = new System.Drawing.Point(192, 88);
      this.lblPeripherals.Name = "lblPeripherals";
      this.lblPeripherals.Size = new System.Drawing.Size(120, 16);
      this.lblPeripherals.TabIndex = 21;
      this.lblPeripherals.Text = "Peripherals (one only)";
      // 
      // lstPeripherals
      // 
      this.lstPeripherals.Location = new System.Drawing.Point(192, 104);
      this.lstPeripherals.Name = "lstPeripherals";
      this.lstPeripherals.Size = new System.Drawing.Size(120, 69);
      this.lstPeripherals.TabIndex = 20;
      this.lstPeripherals.SelectedIndexChanged += new System.EventHandler(this.lstPeripherals_SelectedIndexChanged);
      // 
      // grpOffice
      // 
      this.grpOffice.Controls.Add(this.chkCopyMachine);
      this.grpOffice.Controls.Add(this.chkCalculator);
      this.grpOffice.Controls.Add(this.chkAnsweringMachine);
      this.grpOffice.Location = new System.Drawing.Point(8, 200);
      this.grpOffice.Name = "grpOffice";
      this.grpOffice.Size = new System.Drawing.Size(168, 104);
      this.grpOffice.TabIndex = 19;
      this.grpOffice.TabStop = false;
      this.grpOffice.Text = "Office Equipment (0-3)";
      // 
      // chkCopyMachine
      // 
      this.chkCopyMachine.Location = new System.Drawing.Point(16, 72);
      this.chkCopyMachine.Name = "chkCopyMachine";
      this.chkCopyMachine.Size = new System.Drawing.Size(130, 16);
      this.chkCopyMachine.TabIndex = 2;
      this.chkCopyMachine.Text = "Copy machine";
      this.chkCopyMachine.CheckedChanged += new System.EventHandler(this.chkCopyMachine_CheckedChanged);
      // 
      // chkCalculator
      // 
      this.chkCalculator.Location = new System.Drawing.Point(16, 48);
      this.chkCalculator.Name = "chkCalculator";
      this.chkCalculator.Size = new System.Drawing.Size(130, 16);
      this.chkCalculator.TabIndex = 1;
      this.chkCalculator.Text = "Calculator";
      this.chkCalculator.CheckedChanged += new System.EventHandler(this.chkCalculator_CheckedChanged);
      // 
      // chkAnsweringMachine
      // 
      this.chkAnsweringMachine.Location = new System.Drawing.Point(16, 24);
      this.chkAnsweringMachine.Name = "chkAnsweringMachine";
      this.chkAnsweringMachine.Size = new System.Drawing.Size(130, 16);
      this.chkAnsweringMachine.TabIndex = 0;
      this.chkAnsweringMachine.Text = "Answering Machine";
      this.chkAnsweringMachine.CheckedChanged += new System.EventHandler(this.chkAnsweringMachine_CheckedChanged);
      // 
      // grpComputer
      // 
      this.grpComputer.Controls.Add(this.optLaptop);
      this.grpComputer.Controls.Add(this.optMacintosh);
      this.grpComputer.Controls.Add(this.optPC);
      this.grpComputer.Location = new System.Drawing.Point(8, 80);
      this.grpComputer.Name = "grpComputer";
      this.grpComputer.Size = new System.Drawing.Size(168, 104);
      this.grpComputer.TabIndex = 18;
      this.grpComputer.TabStop = false;
      this.grpComputer.Text = "Computer (required)";
      // 
      // optLaptop
      // 
      this.optLaptop.Location = new System.Drawing.Point(16, 72);
      this.optLaptop.Name = "optLaptop";
      this.optLaptop.Size = new System.Drawing.Size(130, 16);
      this.optLaptop.TabIndex = 2;
      this.optLaptop.Text = "Laptop";
      this.optLaptop.CheckedChanged += new System.EventHandler(this.optLaptop_CheckedChanged);
      // 
      // optMacintosh
      // 
      this.optMacintosh.Location = new System.Drawing.Point(16, 48);
      this.optMacintosh.Name = "optMacintosh";
      this.optMacintosh.Size = new System.Drawing.Size(130, 16);
      this.optMacintosh.TabIndex = 1;
      this.optMacintosh.Text = "Macintosh";
      this.optMacintosh.CheckedChanged += new System.EventHandler(this.optMacintosh_CheckedChanged);
      // 
      // optPC
      // 
      this.optPC.Checked = true;
      this.optPC.Location = new System.Drawing.Point(16, 24);
      this.optPC.Name = "optPC";
      this.optPC.Size = new System.Drawing.Size(130, 16);
      this.optPC.TabIndex = 0;
      this.optPC.TabStop = true;
      this.optPC.Text = "PC";
      this.optPC.CheckedChanged += new System.EventHandler(this.optPC_CheckedChanged);
      // 
      // lblProductsOrdered
      // 
      this.lblProductsOrdered.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblProductsOrdered.Location = new System.Drawing.Point(344, 40);
      this.lblProductsOrdered.Name = "lblProductsOrdered";
      this.lblProductsOrdered.Size = new System.Drawing.Size(136, 24);
      this.lblProductsOrdered.TabIndex = 17;
      this.lblProductsOrdered.Text = "Products Ordered";
      // 
      // lblDescription
      // 
      this.lblDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
      this.lblDescription.Location = new System.Drawing.Point(8, 40);
      this.lblDescription.Name = "lblDescription";
      this.lblDescription.Size = new System.Drawing.Size(320, 32);
      this.lblDescription.TabIndex = 16;
      this.lblDescription.Text = "Outfit your office now by choosing the office products you need using radio butto" +
        "ns, check boxes, a list box, and a combo box.";
      // 
      // lblTitle
      // 
      this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblTitle.Location = new System.Drawing.Point(8, 8);
      this.lblTitle.Name = "lblTitle";
      this.lblTitle.Size = new System.Drawing.Size(248, 32);
      this.lblTitle.TabIndex = 15;
      this.lblTitle.Text = "The Online Shopper";
      // 
      // frmInputControls
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(512, 325);
      this.Controls.Add(this.cmdQuit);
      this.Controls.Add(this.picProductOrdered06);
      this.Controls.Add(this.picProductOrdered05);
      this.Controls.Add(this.picProductOrdered04);
      this.Controls.Add(this.picProductOrdered03);
      this.Controls.Add(this.picProductOrdered02);
      this.Controls.Add(this.picProductOrdered01);
      this.Controls.Add(this.cmbPaymentMethod);
      this.Controls.Add(this.lblPeripherals);
      this.Controls.Add(this.lstPeripherals);
      this.Controls.Add(this.grpOffice);
      this.Controls.Add(this.grpComputer);
      this.Controls.Add(this.lblProductsOrdered);
      this.Controls.Add(this.lblDescription);
      this.Controls.Add(this.lblTitle);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmInputControls";
      this.Text = "Online Shopper";
      this.Load += new System.EventHandler(this.frmInputControls_Load);
      this.grpOffice.ResumeLayout(false);
      this.grpComputer.ResumeLayout(false);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmInputControls'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmInputControls()
      //***
      // Action
      //   - Create instance of 'frmInputControls'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmInputControls()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    string mstrPath;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void chkAnsweringMachine_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - You select or deselect an Answering machine
      //   - The corresponding picture is shown or not in place holder 3
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (chkAnsweringMachine.CheckState == CheckState.Checked)
      {
        picProductOrdered03.Image = Image.FromFile(mstrPath + "answmach.bmp");
        picProductOrdered03.Visible = true;
      }
      else
        // chkAnsweringMachine.CheckState <> CheckState.Checked
      {
        picProductOrdered03.Visible = false;
      }
      // chkAnsweringMachine.CheckState = CheckState.Checked
    
    }
    // chkAnsweringMachine_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments) Handling chkAnsweringMachine.CheckedChanged

    private void chkCalculator_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - You select or deselect a Calculator
      //   - The corresponding picture is shown or not in place holder 4
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (chkCalculator.CheckState == CheckState.Checked)
      {
        picProductOrdered04.Image = Image.FromFile(mstrPath + "calcultr.bmp");
        picProductOrdered04.Visible = true;
      }
      else
        // chkCalculator.CheckState <> CheckState.Checked
      {
        picProductOrdered04.Visible = false;
      }
      // chkCalculator.CheckState = CheckState.Checked
    
    }
    // chkCalculator_CheckedChanged(System.Object, System.EventArgs) Handles chkCalculator.CheckedChanged

    private void chkCopyMachine_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - You select or deselect a Copy Machine
      //   - The corresponding picture is shown or not in place holder 5
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (chkCopyMachine.CheckState == CheckState.Checked)
      {
        picProductOrdered05.Image = Image.FromFile(mstrPath + "copymach.bmp");
        picProductOrdered05.Visible = true;
      }
      else
        // chkCopyMachine.CheckState <> CheckState.Checked
      {
        picProductOrdered05.Visible = false;
      }
      // chkCopyMachine.CheckState = CheckState.Checked

    }
    // chkCopyMachine_CheckedChanged(System.Object, System.EventArgs) Handles chkCopyMachine.CheckedChanged

    private void cmbPaymentMethod_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The item you picked (0-2) is held in the SelectedIndex property
      //   - The corresponding picture is shown in place holder 6
      // Called by
      //   - User action (Clicking an item of a combobox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

        switch (cmbPaymentMethod.SelectedIndex)
        {
          case 0:
            picProductOrdered06.Image = Image.FromFile(mstrPath + "Dollar.bmp");
            break;
          case 1:
            picProductOrdered06.Image = Image.FromFile(mstrPath + "Check.bmp");
            break;
          case 2:
            picProductOrdered06.Image = Image.FromFile(mstrPath + "PoundBag.bmp");
            break;
        }
        // cmbPaymentMethod.SelectedIndex
    
    }
    // cmbPaymentMethod_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbPaymentMethod.SelectedIndexChanged

    private void cmdQuit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Application stops
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Application.Exit();
    }
    // cmdQuit_Click(System.Object, System.EventArgs) Handles cmdQuit.Click

    private void frmInputControls_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the current path of the application
      //   - Set the defaults of the online shopper
      //   - Show the first image of ordered products
      //   - Add 3 items to the listobx
      //   - Add 3 items to the combobox
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrPath = Environment.CurrentDirectory + "\\";
      picProductOrdered01.Image = Image.FromFile(mstrPath + "pcomputr.bmp");
      lstPeripherals.Items.Add("Extra hard disk");
      lstPeripherals.Items.Add("Printer");
      lstPeripherals.Items.Add("Satellite dish");
      cmbPaymentMethod.Items.Add("U.S. Dollars");
      cmbPaymentMethod.Items.Add("Check");
      cmbPaymentMethod.Items.Add("English Pounds");
    }
    // frmInputControls_Load(System.Object, System.EventArgs) Handles frmInputControls.Load

    private void lstPeripherals_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The item you picked (0-2) is held in the SelectedIndex property
      //   - The corresponding picture is shown in place holder 2
      // Called by
      //   - User action (Clicking an item of a listbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      switch (lstPeripherals.SelectedIndex)
      {
        case 0:
          picProductOrdered02.Image = Image.FromFile(mstrPath + "harddisk.bmp");
          break;
        case 1:
          picProductOrdered02.Image = Image.FromFile(mstrPath + "printer.bmp");
          break;
        case 2:
          picProductOrdered02.Image = Image.FromFile(mstrPath + "satedish.bmp");
          break;
      }
      // lstPeripherals.SelectedIndex
    
    }
    // lstPeripherals_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstPeripherals.SelectedIndexChanged

    private void optLaptop_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the first image of ordered products (Laptop is choosen)
      // Called by
      //   - User action (Clicking an option)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      picProductOrdered01.Image = Image.FromFile(mstrPath + "laptop1.bmp");
    }
    // optLaptop_CheckedChanged(System.Object, System.EventArgs) Handles optLaptop.CheckedChanged

    private void optMacintosh_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the first image of ordered products (Mac is choosen)
      // Called by
      //   - User action (Clicking an option)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      picProductOrdered01.Image = Image.FromFile(mstrPath + "computer.bmp");
    }
    // optMacintosh_CheckedChanged(System.Object, System.EventArgs) Handles optMacintosh.CheckedChanged

    private void optPC_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the first image of ordered products (PC is choosen)
      // Called by
      //   - User action (Clicking an option)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      picProductOrdered01.Image = Image.FromFile(mstrPath + "pcomputr.bmp");
    }
    // optPC_CheckedChanged(System.Object, System.EventArgs) Handles optPC.CheckedChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmInputControls
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmInputControls()
      // Created
      //   - CopyPaste � 20240704 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240704 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmInputControls());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmInputControls

}
// CopyPaste.Learning