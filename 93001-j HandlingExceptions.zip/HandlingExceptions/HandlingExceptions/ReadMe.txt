Microsoft Access Developer's Handbook
Diskette Contents
22 July 1994

The sample diskette contains this file (README.TXT) and a self-extracting
compressed file (_GLRFILE.EXE).

To extract the sample files, first copy _GLRFILE.EXE to your hard disk. Run
this executable file by typing

 _GLRFILE

at the DOS prompt. This process will create the following self-extracting
compressed files:

 _ACCPRIN.EXE   ACCPRINT.DLL and its source (used in Chapter 9)
 _ATTINI.EXE    Attached File manager add-in
 _CHAPTER.EXE   All the chapter databases
 _GLR.EXE       GLR.DLL and its source (used in Chapters 17 through 19)
 _GLRBOOK.EXE   GLRBOOK.HLP, a Windows help file containing information on the
                public functions and subroutines in the sample databases
 _HELP.EXE      Help file samples for Chapter 23
 _MBCONST.EXE   MB_CONST.TXT, a listing of MsgBox constants
 _SECWZ2.EXE    Security Wizard for Access 2.0
 _SPRSPY.EXE    SuperSpy, as described in Chapter 8
 _VISIO.EXE     Sample files for Chapter 19's OLE example
 _WIZBLD.EXE    Sample builder/wizard for Chapter 20

Due to space limitations, the freeware DLL, STRINGS.DLL, and its sample files
had to be left off the diskette. These files are available as STRDL2.ZIP
in the MSACCESS forum on Compuserve.

In addition, we wanted to include the Microsoft-supplied Security Conversion
Wizard, but there was not enough space on the diskette. You should be able
to find the file, SECCON.ZIP, in the MSACCESS forum on Compuserve.  We're
sorry for any inconvenience because of these missing files.

To extract any file, copy it to a directory on your hard disk,
and execute the file.  That is, to extract the chapter databases,
copy _CHAPTER.EXE to its own directory, and type

 _CHAPTER

at the DOS prompt from within that directory.

