//***
// Action
//   - Definition of a cpUsingAccount
// Created
//   - CopyPaste � 20240105 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240105 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;

namespace CopyPaste.Learning
{

	public class cpUsingAccount : cpAccount
	{

		#region "Constructors / Destructors"

		public cpUsingAccount(long lngAccountNumber, decimal decAmount, DateTime dtmCreation, decimal decMaxCredit, cpClient thecpOwmner) : base(lngAccountNumber, decAmount, dtmCreation, thecpOwmner)
			//***
			// Action
			//   - Constructor with 5 arguments
			//   - An accountnumber, an amount, the creation date, a maximum credit and an owner
			//   - Set the 4 properties thru the base class
			//   - Set the maximum credit with the given argument
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - cpAccount(long, decimal, DateTime, cpClient)
			//   - MaxCredit(decimal) (Set)
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			MaxCredit = decMaxCredit;
		}
		// cpUsingAccount(long, decimal, DateTime, decimal, cpClient)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private decimal mdecMaxCredit;

		#endregion

		#region "Properties"

		public decimal MaxCredit
		{
			
			get
				//***
				// Action Get
				//   - Returns mdecMaxCredit
				// Called by
				//   - string ToString()
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{
				return mdecMaxCredit;
			}
			// decimal MaxCredit (Get)

			set
				//***
				// Action Set
				//   - Checks if value is negative or zero
				//	 - If check is correct
				//     - mdecMaxCredit becomes value
				//   - If not
				//     - Throw error message
				// Called by
				//   - cpSavingAccount(long, decimal, DateTime, decimal, cpClient)
				// Calls
				//   - 
				// Created
				//   - CopyPaste � 20240105 � VVDW
				// Changed
				//   - CopyPaste � yyyymmdd � VVDW � What changed
				// Tested
				//   - CopyPaste � 20240105 � VVDW
				// Keyboard key
				//   - 
				// Proposal (To Do)
				//   - 
				//***
			{

				if (value <= 0)
				{
					mdecMaxCredit = value;
				}
					// value > 0
				else
				{
					throw new ApplicationException("Maximum credit is not acceptable");
				}
				// value <= 0

			}
			// MaxCredit(decimal) (Set)

		}
		// decimal MaxCredit

		#endregion

		#region "Methods"

		#region "Overrides"

		public override string ToString()
			//***
			// Action
			//   - Return the ToString() of the base class and the intrest rate
			// Called by
			//   - cpProgram.Main()
			// Calls
			//   - decimal MaxCredit() (Get)
			//   - string cpAccount.ToString()
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
	  {
      string strInfo;

      strInfo = base.ToString() + ControlChars.CrLf + "Maximum credit: " + MaxCredit;

      return strInfo;			
		}
		// string ToString()

		#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpUsingAccount

}
// CopyPaste.Learning