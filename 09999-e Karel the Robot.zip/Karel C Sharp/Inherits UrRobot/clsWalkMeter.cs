﻿//***
// Action
//   - Definition of a green robot at origin looking to the East
//   - There is a method added that moves a meter (four blocks)
// Created
//   - CopyPaste – 20251011 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251011 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpWalkMeter : UrRobot
	{

		#region "Constructors / Destructors"

		public cpWalkMeter() : base(1, 1, Directions.East, 0, Color.green)
		//***
		// Action
		//   - Basic constructor (start situation)
	  //   - Robot becomes a green origin sitter starting at position (1, 1), looking to the East with no beepers in the bag
		//   - Nothing else happens
		// Called by
		//   - cpProgram.WalkMeter()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251011 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251011 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
  	}
		// cpWalkMeter()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public void MoveMeter()
		//***
		// Action
		//   - In the world a meter is 4 blocks wide
		//   - So moving a meter is moving 4 blocks (in any direction)
		// Called by
		//   - cpProgram.WalkMeter()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251011 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251011 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			move();
			move();
			move();
			move();
		}
		// MoveMeter()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpWalkMeter

}
// cpKarelTheRobot