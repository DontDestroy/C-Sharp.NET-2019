//***
// Action
//   - Showing an image on the screen
// Created
//   - CopyPaste � 20240424 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240424 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDiskDriveError: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.PictureBox picPicture;
    internal System.Windows.Forms.Button cmdCheck;
    internal System.Windows.Forms.Label lblText;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDiskDriveError));
      this.picPicture = new System.Windows.Forms.PictureBox();
      this.cmdCheck = new System.Windows.Forms.Button();
      this.lblText = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // picPicture
      // 
      this.picPicture.Location = new System.Drawing.Point(72, 130);
      this.picPicture.Name = "picPicture";
      this.picPicture.Size = new System.Drawing.Size(144, 168);
      this.picPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
      this.picPicture.TabIndex = 5;
      this.picPicture.TabStop = false;
      // 
      // cmdCheck
      // 
      this.cmdCheck.Location = new System.Drawing.Point(96, 90);
      this.cmdCheck.Name = "cmdCheck";
      this.cmdCheck.Size = new System.Drawing.Size(88, 24);
      this.cmdCheck.TabIndex = 4;
      this.cmdCheck.Text = "&Check";
      this.cmdCheck.Click += new System.EventHandler(this.cmdCheck_Click);
      // 
      // lblText
      // 
      this.lblText.Location = new System.Drawing.Point(16, 10);
      this.lblText.Name = "lblText";
      this.lblText.Size = new System.Drawing.Size(256, 72);
      this.lblText.TabIndex = 3;
      this.lblText.Text = "This program checks the File \"C:\\FileOpen.jpg\". If the file does not exist or the" +
        " floppy is not ready, then there is an error. Click the checkbutton.";
      // 
      // frmDiskDriveError
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(288, 309);
      this.Controls.Add(this.picPicture);
      this.Controls.Add(this.cmdCheck);
      this.Controls.Add(this.lblText);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDiskDriveError";
      this.Text = "Floppy Error";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDiskDriveError'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDiskDriveError()
      //***
      // Action
      //   - Create instance of 'frmDiskDriveError'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDiskDriveError()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCheck_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show an image that is on the harddisk C:\
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240424 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240424 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - This routine will fail
      //   - Solve it
      //***
    {  
      picPicture.Image = Bitmap.FromFile("C:\\FileOpen.jpg");
    }
    // cmdCheck_Click(System.Object theSender, System.EventArgs theEventArguments) Handles cmdCheck.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDiskDriveError
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDiskDriveError()
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDiskDriveError());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDiskDriveError

}
// CopyPaste.Learning