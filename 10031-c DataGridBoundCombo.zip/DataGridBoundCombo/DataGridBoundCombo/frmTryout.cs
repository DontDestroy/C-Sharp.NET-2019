//***
// Action
//   - Demo of a DataGrid ComboBox Column
//   - Having a data grid with a combo box in the column ContactCombo
//   - Having a data grid with the choosen value in the combo box
//   - Having a data grid with the selected row in the data grid
// Created
//   - CopyPaste � 20260706 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260706 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning.Data
{

  public class frmTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;
    private System.Windows.Forms.DataGrid dgrThree;
    private System.Windows.Forms.DataGrid dgrTwo;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwindScript2019;
    private System.Windows.Forms.DataGrid dgrOne;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTryout));
      this.dgrThree = new System.Windows.Forms.DataGrid();
      this.dgrTwo = new System.Windows.Forms.DataGrid();
      this.dgrOne = new System.Windows.Forms.DataGrid();
      this.cnncpNorthwindScript2019 = new System.Data.SqlClient.SqlConnection();
      ((System.ComponentModel.ISupportInitialize)(this.dgrThree)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrTwo)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOne)).BeginInit();
      this.SuspendLayout();
      // 
      // dgrThree
      // 
      this.dgrThree.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrThree.CaptionText = "DataGrid combobox values";
      this.dgrThree.DataMember = "";
      this.dgrThree.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrThree.Location = new System.Drawing.Point(392, 250);
      this.dgrThree.Name = "dgrThree";
      this.dgrThree.Size = new System.Drawing.Size(248, 208);
      this.dgrThree.TabIndex = 5;
      // 
      // dgrTwo
      // 
      this.dgrTwo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrTwo.CaptionText = "DataGrid shows ValueMember in column 1";
      this.dgrTwo.DataMember = "";
      this.dgrTwo.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrTwo.Location = new System.Drawing.Point(16, 250);
      this.dgrTwo.Name = "dgrTwo";
      this.dgrTwo.Size = new System.Drawing.Size(368, 208);
      this.dgrTwo.TabIndex = 4;
      // 
      // dgrOne
      // 
      this.dgrOne.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrOne.CaptionText = "DataGrid with ComboBox in column 1 showing DisplayMember";
      this.dgrOne.DataMember = "";
      this.dgrOne.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrOne.Location = new System.Drawing.Point(16, 18);
      this.dgrOne.Name = "dgrOne";
      this.dgrOne.Size = new System.Drawing.Size(624, 224);
      this.dgrOne.TabIndex = 3;
      // 
      // cnncpNorthwindScript2019
      // 
      this.cnncpNorthwindScript2019.ConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthwindScript2019.FireInfoMessageEventOnUserErrors = false;
      // 
      // frmTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(656, 477);
      this.Controls.Add(this.dgrTwo);
      this.Controls.Add(this.dgrOne);
      this.Controls.Add(this.dgrThree);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTryout";
      this.Text = "Tryout ComboBox in DataGrid";
      ((System.ComponentModel.ISupportInitialize)(this.dgrThree)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrTwo)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOne)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTryout()
      //***
      // Action
      //   - Create instance of 'frmTryout'
      //   - Make sure you have the correct data sets binded to the data grids
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      //   - MakeDataSetAndBindGrid()
      // Created
      //   - CopyPaste � 20260706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      MakeDataSetAndBindGrid();
    }
    // frmTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTryout
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmTryout()
      // Created
      //   - CopyPaste � 20260706 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260706 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTryout());
    }
    // Main() 
    
    private void MakeDataSetAndBindGrid()
    //***
    // Action
    //   - Define and create a new data set
    //   - Define an sql data adapter for order
    //   - Define an sql data adapter for customer
    //   - Define and create a SQL statement to get the orders
    //   - Define and set a connection
    //   - Define and create a new data grid table style
    //   - Try to
    //     - Open the connection
    //     - Define the data adapter for order
    //     - Fill the data set thru the adapter
    //     - Define a select statement for customer contact persons
    //     - Define teh data adapter for customers
    //     - Fill the data set thru the adapter
    //     - Close the connection
    //   - On possible error
    //     - Show message that there was a problem with the connection
    //     - Close form
    //     - Set exit variable to true
    //   - If exit variable
    //     - Do nothing
    //   - If not
    //     - Set data grid mapping to the order table
    //     - Set data table to order table
    //     - Loop thru all the columns
    //       - If the column is the second column
    //         - Define and create a new cpDataGridComboBoxColumn
    //         - Set the mapping, header text, with, datasource, display member and value member of the column
    //         - Set the preferred row height for the combobox
    //         - Add the cpDataGridComboBoxColumn to the GridColumnStyles of the data grid
    //       - If not
    //         - A combobox is not needed, so a normal textbox is used
    //         - Set the mapping, header text
    //         - Add the cpDataGridTextBoxColumn to the GridColumnStyles of the data grid
    //       - Increment the column number
    //   - The first data grid data source becomes order
    //     - The styles are cleared
    //     - The created style is added
    //   - The second data grid data source becomes order
    //   - The third data grid data source becomes customer
    //   - The dataset deletion, created and updating is set to false
    // Called by
    //   - New()
    // Calls
    //   - cpDataGridComboBoxColumn()
    // Created
    //   - CopyPaste � 20260706 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20260706 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   - Editing the data is not implemented
    //***
    {
      bool blnExit = false;
      DataSet dsOrder = new DataSet();
      SqlDataAdapter dtaOrder;
      SqlDataAdapter dtaCustomer;
      DataTable dtOrder;
      int lngColumn = 0;
      string strSQLStatement = "SELECT * FROM tblCPOrder";
      SqlConnection theConnection = cnncpNorthwindScript2019;
      DataGridTableStyle theDataGridTableStyle = new DataGridTableStyle();

      try
      {
        theConnection.Open();
        dtaOrder = new SqlDataAdapter(strSQLStatement, theConnection);
        dtaOrder.Fill(dsOrder, "tblCPOrder");
        strSQLStatement = "SELECT strIdCustomer, strContactName FROM tblCPCustomer";
        dtaCustomer = new SqlDataAdapter(strSQLStatement, theConnection);
        dtaCustomer.Fill(dsOrder, "tblCPCustomer");
        theConnection.Close();
      }
      catch (Exception theException)
      {
        MessageBox.Show("Problem with DB access - connection: " + theConnection.ConnectionString + " - query: " + strSQLStatement + theException.ToString());
        this.Close();
        blnExit = true;
      }
      finally
      {
      }

      if (blnExit)
      {
      }
      else
        // Not blnExit
      {
        theDataGridTableStyle.MappingName = "tblCPOrder";
        dtOrder = dsOrder.Tables["tblCPOrder"];

        while (lngColumn < dtOrder.Columns.Count)
        {

          if (lngColumn == 1)
          {
            cpDataGridComboBoxColumn thecpDataGridComboBoxColumn = new cpDataGridComboBoxColumn();

            thecpDataGridComboBoxColumn.MappingName = "strCustomerId";
            thecpDataGridComboBoxColumn.HeaderText = "ContactCombo";
            thecpDataGridComboBoxColumn.Width = 120;
            thecpDataGridComboBoxColumn.mcpComboBox.DataSource = dsOrder.Tables["tblCPCustomer"].DefaultView;
            thecpDataGridComboBoxColumn.mcpComboBox.DisplayMember = "strContactName";
            thecpDataGridComboBoxColumn.mcpComboBox.ValueMember = "strIdCustomer";
            theDataGridTableStyle.PreferredRowHeight = thecpDataGridComboBoxColumn.mcpComboBox.Height + 2;
            theDataGridTableStyle.GridColumnStyles.Add(thecpDataGridComboBoxColumn);
          }
          else
            // lngColumn <> 1
          {
            DataGridTextBoxColumn theDataGridTextBoxColumn = new DataGridTextBoxColumn();

            theDataGridTextBoxColumn.MappingName = dtOrder.Columns[lngColumn].ColumnName.ToString();
            theDataGridTextBoxColumn.HeaderText = "Test " + dtOrder.Columns[lngColumn].ColumnName.ToString();
            theDataGridTableStyle.GridColumnStyles.Add(theDataGridTextBoxColumn);
          }
          // lngColumn = 1

          lngColumn += 1;
        }
        // lngColumn < dtOrder.Columns.Count

        dgrOne.DataSource = dtOrder;
        dgrOne.TableStyles.Clear();
        dgrOne.TableStyles.Add(theDataGridTableStyle);

        dgrTwo.DataSource = dtOrder;
        dgrThree.PreferredColumnWidth = 97;
        dgrThree.DataSource = dsOrder.Tables["tblCPCustomer"].DefaultView;
        dgrThree.Enabled = false;

        dsOrder.Tables["tblCPCustomer"].DefaultView.AllowDelete = false;
        dsOrder.Tables["tblCPCustomer"].DefaultView.AllowNew = false;
        dsOrder.Tables["tblCPCustomer"].DefaultView.AllowEdit = false;
      }
      // Not blnExit

    }
    // MakeDataSetAndBindGrid()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTryout

}
// CopyPaste.Learning.Data