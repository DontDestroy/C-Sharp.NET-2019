﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmAdRotator.aspx.cs" Inherits="CopyPaste.Learning.wfrmAdRotator" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Advertisement Rotator</title>
</head>
<body>
  <form id="wfrmAdRotator" method="post" runat="server">
    <asp:AdRotator ID="adrTravelAdvise" Style="z-index: 101; position: absolute; top: 16px; left: 112px"
      runat="server" Width="40px" Height="32px" AdvertisementFile="Countries.xml"></asp:AdRotator>
    <asp:Label ID="lblTravelAdvise" Style="z-index: 102; position: absolute; top: 16px; left: 16px"
      runat="server">Travel advise</asp:Label>
  </form>
</body>
</html>
