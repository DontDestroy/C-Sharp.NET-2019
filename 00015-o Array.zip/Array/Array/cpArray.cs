//***
// Action
//   - Asking the temperature of twelve months
//   - Show them to the console
//   - Show the number of days of every month
// Created
//   - CopyPaste � 20220216 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220216 � VVDW
// Proposal (To Do)
//   - Leap years are not taken into account
//***

using System;

namespace Array
{

  class cpArray
	{

    static void Main()
      //***
      // Action
      //   - Defining an array of 12 elements (double)
      //   - This represents the 12 months of a year
      //     - Ask the temperature of every month
      //   - Loop thru the 12 months
      //     - Show information on the console
      //   - Define an array of 12 elements (integers)
      //   - This represents the length of every month of the year
      //   - Loop thru the 12 lengths (with counter)
      //     - Show information on the console
      //   - Loop thru the 12 lengths (thru the elements)
      //     - Show information on the console
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Console.Write(string, int)
      //   - Console.WriteLine()
      //   - Console.WriteLine(string, int)
      //   - Console.WriteLine(string, int, double)
      //   - Console.WriteLine(string, int, int)
      //   - double Convert.ToDouble(string)
      //   - string Console.ReadLine()
      // Created
      //   - CopyPaste � 20220216 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220216 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      double[] arrdblTemp = new double[12];
      int[] arrintDaysInMonth = new int[] {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
      int intMonth;

      for (intMonth = 1; intMonth <= 12; intMonth++)
      {
        Console.Write("Enter temperature of the month {0}: ", intMonth);
        arrdblTemp[intMonth - 1] = Convert.ToDouble(Console.ReadLine());
      }
      // intMonth = 13

      Console.WriteLine();

      for (intMonth = 1; intMonth <= 12; intMonth++)
      {
        Console.WriteLine("Month {0} has temperature {1}", intMonth, arrdblTemp[intMonth - 1]);
      }
      // lngMonth = 13
      
      Console.WriteLine();

      for (intMonth = 0; intMonth < 12; intMonth++)
      {
        Console.WriteLine("Month {0}: {1} days", intMonth + 1, arrintDaysInMonth[intMonth]);
      }
      // lngMonth = 12

      Console.WriteLine();
      
      foreach (int intNumberOfDays in arrintDaysInMonth)
      {
        Console.WriteLine("{0} days", intNumberOfDays);
      }
      // in arrintDaysInMonth
      
      Console.WriteLine();
      Console.ReadLine();
    }
    // Main()

  }
  // cpArray

}
// Array