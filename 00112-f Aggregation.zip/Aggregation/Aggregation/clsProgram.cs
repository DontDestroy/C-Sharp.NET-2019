//***
// Action
//   - Testroutine for cpDepartment, cpEmployee, cpHandWorker, cpOfficeWorker, cpManager and cpDirector
// Created
//   - CopyPaste � 20240409 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240409 � VVDW
// Proposal (To Do)
//   - Not all getters and setters are tested, but the usual stuff is
//   - Pay attention, the result of the testroutine will be different if you do the extra exercises
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Create 2 departments
      //   - Create a director with and without department
      //   - Create an employee with and without department
      //   - Create a handworker with and without department
      //   - Create a manager with and without department
      //   - Create an officeworker with and without department
      //   - Show for all the information
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpDepartment(string)
      //   - cpDirector(string)
      //   - cpDirector(string, cpDepartment)
      //   - cpEmployee(string)
      //   - cpEmployee(string, cpDepartment)
      //   - cpHandWorker(string)
      //   - cpHandWorker(string, cpDepartment)
      //   - cpManager(string)
      //   - cpManager(string, cpDepartment)
      //   - cpOfficeWorker(string)
      //   - cpOfficeWorker(string, cpDepartment)
      //   - cpDirector.ShowInfo()
      //   - cpEmployee.ShowInfo()
      //   - cpHandWorker.ShowInfo()
      //   - cpManager.ShowInfo()
      //   - cpOfficeWorker.ShowInfo()
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpDepartment thecpDepartmentMaintenance = new cpDepartment("Maintenance");
      cpDepartment thecpDepartmentSell = new cpDepartment("Sell");

      cpDirector thecpDirector = new cpDirector("Vincent", thecpDepartmentSell);
      cpDirector thecpDirectorNoDepartment = new cpDirector("Vincent");
      cpEmployee thecpEmployee = new cpEmployee("Alfons", thecpDepartmentMaintenance);
      cpEmployee thecpEmployeeNoDepartment = new cpEmployee("Alfons");
      cpHandWorker thecpHandWorker = new cpHandWorker("Xavier", thecpDepartmentMaintenance);
      cpHandWorker thecpHandWorkerNoDepartment = new cpHandWorker("Xavier");
      cpManager thecpManager = new cpManager("Martijn", thecpDepartmentSell);
      cpManager thecpManagerNoDepartment = new cpManager("Martijn");
      cpOfficeWorker thecpOfficeWorker = new cpOfficeWorker("Hilde", thecpDepartmentSell);
      cpOfficeWorker thecpOfficeWorkerNoDepartment = new cpOfficeWorker("Hilde");

      thecpEmployeeNoDepartment.ShowInfo();
      thecpHandWorkerNoDepartment.ShowInfo();
      thecpOfficeWorkerNoDepartment.ShowInfo();
      thecpManagerNoDepartment.ShowInfo();
      thecpDirectorNoDepartment.ShowInfo();

      Console.WriteLine();

      thecpEmployee.ShowInfo();
      thecpHandWorker.ShowInfo();
      thecpOfficeWorker.ShowInfo();
      thecpManager.ShowInfo();
      thecpDirector.ShowInfo();

      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning.Employee