//***
// Action
//   - Setting some text in labels on a form
// Created
//   - CopyPaste � 20240417 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240417 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmVariableTest: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblTwo;
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.Label lblOne;
    internal System.Windows.Forms.Button cmdShow;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmVariableTest));
      this.lblTwo = new System.Windows.Forms.Label();
      this.cmdExit = new System.Windows.Forms.Button();
      this.lblOne = new System.Windows.Forms.Label();
      this.cmdShow = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // lblTwo
      // 
      this.lblTwo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblTwo.Location = new System.Drawing.Point(152, 78);
      this.lblTwo.Name = "lblTwo";
      this.lblTwo.Size = new System.Drawing.Size(160, 32);
      this.lblTwo.TabIndex = 7;
      this.lblTwo.Text = "Label2";
      // 
      // cmdExit
      // 
      this.cmdExit.Location = new System.Drawing.Point(32, 78);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.Size = new System.Drawing.Size(88, 32);
      this.cmdExit.TabIndex = 6;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // lblOne
      // 
      this.lblOne.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblOne.Location = new System.Drawing.Point(152, 22);
      this.lblOne.Name = "lblOne";
      this.lblOne.Size = new System.Drawing.Size(160, 32);
      this.lblOne.TabIndex = 5;
      this.lblOne.Text = "Label1";
      // 
      // cmdShow
      // 
      this.cmdShow.Location = new System.Drawing.Point(32, 22);
      this.cmdShow.Name = "cmdShow";
      this.cmdShow.Size = new System.Drawing.Size(88, 32);
      this.cmdShow.TabIndex = 4;
      this.cmdShow.Text = "&Show";
      this.cmdShow.Click += new System.EventHandler(this.cmdShow_Click);
      // 
      // frmVariableTest
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(392, 133);
      this.Controls.Add(this.lblTwo);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.lblOne);
      this.Controls.Add(this.cmdShow);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmVariableTest";
      this.Text = "Variable Test";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmVariableTest'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240417 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240417 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmVariableTest()
      //***
      // Action
      //   - Create instance of 'frmVariableTest'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240417 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240417 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmVariableTest()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop the application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240417 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240417 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit.Click

    private void cmdShow_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set 2 texts (variable values) into a label
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240417 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240417 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strLastName;

      strLastName = "Luther";
      lblOne.Text = strLastName;
      strLastName = "Rodenstein von Hamburg";
      lblTwo.Text = strLastName;
    }
    // cmdShow_Click(System.Object, System.EventArgs) Handles cmdShow.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmVariableTest
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDefault()
      // Created
      //   - CopyPaste � 20240417 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240417 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmVariableTest());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmVariableTest

}
// CopyPaste.Learning