//***
// Action
//   - Testroutine for cpDuracellBunny
// Created
//   - CopyPaste � 20240522 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240522 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.Event;
using System;
using System.Diagnostics;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static cpDuracellBunny thecpBunny;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    private static void thecpBunny_DoSomething()
      //***
      // Action
      //   - If there is still power in the bunny
      //     - Do some action (showing trr-)
      //     - Power decremented by one
      // Called by
      //   - cpDuracellBunny.Power(int) (Set)
      // Calls
      //   - int cpDuracellBunny.Power (Get)
      //   - cpDuracellBunny.Power(int) (Set)
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Debug.Write("trr-");
      thecpBunny.Power -= 1;
    }
    // thecpBunny_DoSomething() Handles thecpBunny.DoSomething

    private static void thecpBunny_Park()
      //***
      // Action
      //   - Showing ka-djing
      //   - Show that the rabbit needs a powerboost
      // Called by
      //   - cpDuracellBunny.Power(int) (Set)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Debug.Write("ka-djing");
      Debug.WriteLine("");
      Debug.WriteLine("Rabbit needs a powerboost - Rabbit goes to sleep");
      Debug.WriteLine("");
    }
    // thecpBunny_Park() Handles thecpBunny.Park

    #endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Define a new cpDuracellBunny with the name "Bunny"
      //   - If thecpBunny is something
      //     - Add handlers for the events
      //     - Set the power to 15
      //     - Rabbit starts to do some stuff till powerloss
      //     - Set the power to 1
      //     - Rabbit starts to do some stuff till powerloss
      //   - If not
      //     - Do nothing
      //   - Show "info is on the immediate window"
      //   - Show "Hit any key"
      //   - Wait till user hits any key
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpDuracellBunny(string)
      //   - cpDuracellBunny.Power(int) (Set)
      //   - thecpBunny_DoSomething()
      //   - thecpBunny_Park()
      // Created
      //   - CopyPaste � 20240522 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240522 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      thecpBunny = new cpDuracellBunny("Bunny");

      if (thecpBunny == null)
      {
      }
      else
        // thecpBunny <> null
      {
        thecpBunny.DoSomething += new cpDuracellBunny.cpActionWithPower(thecpBunny_DoSomething);
        thecpBunny.Park += new cpDuracellBunny.cpActionNoPower(thecpBunny_Park);
        Debug.WriteLine("Some time and some actions");
        thecpBunny.Power = 15;
        Debug.WriteLine("Some time and some actions");
        thecpBunny.Power = 1;
      }
      // thecpBunny = null

      Console.WriteLine("All the info is written in the immediate window.");
      Console.WriteLine("Hit any key");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning