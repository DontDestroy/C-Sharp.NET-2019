//***
// Action
//   - Example Switch Case ... Default
// Created
//   - CopyPaste � 20220119 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220119 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Switch
{

  class cpSwitch
	{

    static void Main()
    //***
    // Action
    //   - Depending on day of week, show correct day
    //   - Depending on score, show correct grade
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - DayOfWeek System.DateTime.Now.DayOfWeek()
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220119 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220119 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   - Suppose you don't work with a DayOfWeek but with an integer.
    //   - How do you solve this?
    //   - Suppose you want to write it in one statement (so not using a switch).
    //   - How do you solve this?
    //***
    {
      DayOfWeek theDayOfWeek;
      long lngTestScore;

      theDayOfWeek = DateTime.Now.DayOfWeek;

      switch (theDayOfWeek)
      {
        case DayOfWeek.Sunday:
          Console.WriteLine("Sunday");
          break;
        case DayOfWeek.Monday:
          Console.WriteLine("Monday");
          break;
        case DayOfWeek.Tuesday:
          Console.WriteLine("Tuesday");
          break;
        case DayOfWeek.Wednesday:
          Console.WriteLine("Wednesday");
          break;
        case DayOfWeek.Thursday:
          Console.WriteLine("Thursday");
          break;
        case DayOfWeek.Friday:
          Console.WriteLine("Friday");
          break;
        case DayOfWeek.Saturday:
          Console.WriteLine("Saturday");
          break;
      }
      // lngDayOfWeek

      lngTestScore = 84;
      
      if (lngTestScore >= 90)
      {
        Console.WriteLine("Grade: A");
      }
      else if (lngTestScore >= 80)
        //lngTestScore < 90
      {
        Console.WriteLine("Grade: B");
      }
      else if (lngTestScore >= 70)
        //lngTestScore < 80
      {
        Console.WriteLine("Grade: C");
      }
      else
        //lngTestScore < 70
      {
        Console.WriteLine("Grade: F");
      }
      // lngTestScore >= 90
      // lngTestScore >= 80
      // lngTestScore >= 70

      switch (lngTestScore)
      {
        case long lngValue when lngValue >= 90:
          Console.WriteLine("Grade: A");
          break;
        case long lngValue when lngValue >= 80:
          Console.WriteLine("Grade: B");
          break;
        case long lngValue when lngValue >= 70:
          Console.WriteLine("Grade: C");
          break;
        default:
          Console.WriteLine("Grade: F");
          break;
      }
      // lngTestScore

      Console.ReadLine();
    }
    // Main()

  }
  // cpSwitch

}
// Switch