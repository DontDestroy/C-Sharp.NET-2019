//***
// Action
//   - A block game
//   - Working with properties (Get and Set) and methods in a class
// Created
//   - CopyPaste � 20240214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240214 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBlock: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.Label lblScore;
    internal System.Windows.Forms.Label lblLives;
    internal System.Windows.Forms.PictureBox picBall;
    internal System.Windows.Forms.PictureBox picBlue05;
    internal System.Windows.Forms.PictureBox picBlue04;
    internal System.Windows.Forms.PictureBox picBlue03;
    internal System.Windows.Forms.PictureBox picBlue02;
    internal System.Windows.Forms.PictureBox picBlue01;
    internal System.Windows.Forms.PictureBox picGreen05;
    internal System.Windows.Forms.PictureBox picGreen04;
    internal System.Windows.Forms.PictureBox picGreen03;
    internal System.Windows.Forms.PictureBox picGreen02;
    internal System.Windows.Forms.PictureBox picGreen01;
    internal System.Windows.Forms.Timer tmrTimer;
    internal System.Windows.Forms.PictureBox picYellow05;
    internal System.Windows.Forms.PictureBox picYellow04;
    internal System.Windows.Forms.PictureBox picYellow03;
    internal System.Windows.Forms.PictureBox picYellow02;
    internal System.Windows.Forms.PictureBox picYellow01;
    internal System.Windows.Forms.PictureBox picRed05;
    internal System.Windows.Forms.PictureBox picRed04;
    internal System.Windows.Forms.PictureBox picRed03;
    internal System.Windows.Forms.PictureBox picRed02;
    internal System.Windows.Forms.PictureBox picPaddle;
    internal System.Windows.Forms.PictureBox picRed01;
    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmBlock));
      this.lblScore = new System.Windows.Forms.Label();
      this.lblLives = new System.Windows.Forms.Label();
      this.picBall = new System.Windows.Forms.PictureBox();
      this.picBlue05 = new System.Windows.Forms.PictureBox();
      this.picBlue04 = new System.Windows.Forms.PictureBox();
      this.picBlue03 = new System.Windows.Forms.PictureBox();
      this.picBlue02 = new System.Windows.Forms.PictureBox();
      this.picBlue01 = new System.Windows.Forms.PictureBox();
      this.picGreen05 = new System.Windows.Forms.PictureBox();
      this.picGreen04 = new System.Windows.Forms.PictureBox();
      this.picGreen03 = new System.Windows.Forms.PictureBox();
      this.picGreen02 = new System.Windows.Forms.PictureBox();
      this.picGreen01 = new System.Windows.Forms.PictureBox();
      this.tmrTimer = new System.Windows.Forms.Timer(this.components);
      this.picYellow05 = new System.Windows.Forms.PictureBox();
      this.picYellow04 = new System.Windows.Forms.PictureBox();
      this.picYellow03 = new System.Windows.Forms.PictureBox();
      this.picYellow02 = new System.Windows.Forms.PictureBox();
      this.picYellow01 = new System.Windows.Forms.PictureBox();
      this.picRed05 = new System.Windows.Forms.PictureBox();
      this.picRed04 = new System.Windows.Forms.PictureBox();
      this.picRed03 = new System.Windows.Forms.PictureBox();
      this.picRed02 = new System.Windows.Forms.PictureBox();
      this.picPaddle = new System.Windows.Forms.PictureBox();
      this.picRed01 = new System.Windows.Forms.PictureBox();
      this.SuspendLayout();
      // 
      // lblScore
      // 
      this.lblScore.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblScore.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblScore.Location = new System.Drawing.Point(375, 8);
      this.lblScore.Name = "lblScore";
      this.lblScore.Size = new System.Drawing.Size(104, 24);
      this.lblScore.TabIndex = 47;
      this.lblScore.Text = "Score: 0";
      this.lblScore.TextAlign = System.Drawing.ContentAlignment.TopRight;
      // 
      // lblLives
      // 
      this.lblLives.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.lblLives.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblLives.Location = new System.Drawing.Point(7, 8);
      this.lblLives.Name = "lblLives";
      this.lblLives.Size = new System.Drawing.Size(88, 24);
      this.lblLives.TabIndex = 46;
      this.lblLives.Text = "Lives: 3";
      // 
      // picBall
      // 
      this.picBall.BackColor = System.Drawing.Color.White;
      this.picBall.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBall.Location = new System.Drawing.Point(231, 376);
      this.picBall.Name = "picBall";
      this.picBall.Size = new System.Drawing.Size(16, 16);
      this.picBall.TabIndex = 45;
      this.picBall.TabStop = false;
      // 
      // picBlue05
      // 
      this.picBlue05.BackColor = System.Drawing.Color.Blue;
      this.picBlue05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBlue05.Location = new System.Drawing.Point(391, 168);
      this.picBlue05.Name = "picBlue05";
      this.picBlue05.Size = new System.Drawing.Size(88, 32);
      this.picBlue05.TabIndex = 44;
      this.picBlue05.TabStop = false;
      // 
      // picBlue04
      // 
      this.picBlue04.BackColor = System.Drawing.Color.Blue;
      this.picBlue04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBlue04.Location = new System.Drawing.Point(295, 168);
      this.picBlue04.Name = "picBlue04";
      this.picBlue04.Size = new System.Drawing.Size(88, 32);
      this.picBlue04.TabIndex = 43;
      this.picBlue04.TabStop = false;
      // 
      // picBlue03
      // 
      this.picBlue03.BackColor = System.Drawing.Color.Blue;
      this.picBlue03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBlue03.Location = new System.Drawing.Point(199, 168);
      this.picBlue03.Name = "picBlue03";
      this.picBlue03.Size = new System.Drawing.Size(88, 32);
      this.picBlue03.TabIndex = 42;
      this.picBlue03.TabStop = false;
      // 
      // picBlue02
      // 
      this.picBlue02.BackColor = System.Drawing.Color.Blue;
      this.picBlue02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBlue02.Location = new System.Drawing.Point(103, 168);
      this.picBlue02.Name = "picBlue02";
      this.picBlue02.Size = new System.Drawing.Size(88, 32);
      this.picBlue02.TabIndex = 41;
      this.picBlue02.TabStop = false;
      // 
      // picBlue01
      // 
      this.picBlue01.BackColor = System.Drawing.Color.Blue;
      this.picBlue01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picBlue01.Location = new System.Drawing.Point(7, 168);
      this.picBlue01.Name = "picBlue01";
      this.picBlue01.Size = new System.Drawing.Size(88, 32);
      this.picBlue01.TabIndex = 40;
      this.picBlue01.TabStop = false;
      // 
      // picGreen05
      // 
      this.picGreen05.BackColor = System.Drawing.Color.Lime;
      this.picGreen05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picGreen05.Location = new System.Drawing.Point(391, 128);
      this.picGreen05.Name = "picGreen05";
      this.picGreen05.Size = new System.Drawing.Size(88, 32);
      this.picGreen05.TabIndex = 39;
      this.picGreen05.TabStop = false;
      // 
      // picGreen04
      // 
      this.picGreen04.BackColor = System.Drawing.Color.Lime;
      this.picGreen04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picGreen04.Location = new System.Drawing.Point(295, 128);
      this.picGreen04.Name = "picGreen04";
      this.picGreen04.Size = new System.Drawing.Size(88, 32);
      this.picGreen04.TabIndex = 38;
      this.picGreen04.TabStop = false;
      // 
      // picGreen03
      // 
      this.picGreen03.BackColor = System.Drawing.Color.Lime;
      this.picGreen03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picGreen03.Location = new System.Drawing.Point(199, 128);
      this.picGreen03.Name = "picGreen03";
      this.picGreen03.Size = new System.Drawing.Size(88, 32);
      this.picGreen03.TabIndex = 37;
      this.picGreen03.TabStop = false;
      // 
      // picGreen02
      // 
      this.picGreen02.BackColor = System.Drawing.Color.Lime;
      this.picGreen02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picGreen02.Location = new System.Drawing.Point(103, 128);
      this.picGreen02.Name = "picGreen02";
      this.picGreen02.Size = new System.Drawing.Size(88, 32);
      this.picGreen02.TabIndex = 36;
      this.picGreen02.TabStop = false;
      // 
      // picGreen01
      // 
      this.picGreen01.BackColor = System.Drawing.Color.Lime;
      this.picGreen01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picGreen01.Location = new System.Drawing.Point(7, 128);
      this.picGreen01.Name = "picGreen01";
      this.picGreen01.Size = new System.Drawing.Size(88, 32);
      this.picGreen01.TabIndex = 35;
      this.picGreen01.TabStop = false;
      // 
      // tmrTimer
      // 
      this.tmrTimer.Interval = 20;
      this.tmrTimer.Tick += new System.EventHandler(this.tmrTimer_Tick);
      // 
      // picYellow05
      // 
      this.picYellow05.BackColor = System.Drawing.Color.Yellow;
      this.picYellow05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picYellow05.Location = new System.Drawing.Point(391, 88);
      this.picYellow05.Name = "picYellow05";
      this.picYellow05.Size = new System.Drawing.Size(88, 32);
      this.picYellow05.TabIndex = 34;
      this.picYellow05.TabStop = false;
      // 
      // picYellow04
      // 
      this.picYellow04.BackColor = System.Drawing.Color.Yellow;
      this.picYellow04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picYellow04.Location = new System.Drawing.Point(295, 88);
      this.picYellow04.Name = "picYellow04";
      this.picYellow04.Size = new System.Drawing.Size(88, 32);
      this.picYellow04.TabIndex = 33;
      this.picYellow04.TabStop = false;
      // 
      // picYellow03
      // 
      this.picYellow03.BackColor = System.Drawing.Color.Yellow;
      this.picYellow03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picYellow03.Location = new System.Drawing.Point(199, 88);
      this.picYellow03.Name = "picYellow03";
      this.picYellow03.Size = new System.Drawing.Size(88, 32);
      this.picYellow03.TabIndex = 32;
      this.picYellow03.TabStop = false;
      // 
      // picYellow02
      // 
      this.picYellow02.BackColor = System.Drawing.Color.Yellow;
      this.picYellow02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picYellow02.Location = new System.Drawing.Point(103, 88);
      this.picYellow02.Name = "picYellow02";
      this.picYellow02.Size = new System.Drawing.Size(88, 32);
      this.picYellow02.TabIndex = 31;
      this.picYellow02.TabStop = false;
      // 
      // picYellow01
      // 
      this.picYellow01.BackColor = System.Drawing.Color.Yellow;
      this.picYellow01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picYellow01.Location = new System.Drawing.Point(7, 88);
      this.picYellow01.Name = "picYellow01";
      this.picYellow01.Size = new System.Drawing.Size(88, 32);
      this.picYellow01.TabIndex = 30;
      this.picYellow01.TabStop = false;
      // 
      // picRed05
      // 
      this.picRed05.BackColor = System.Drawing.Color.Red;
      this.picRed05.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picRed05.Location = new System.Drawing.Point(391, 48);
      this.picRed05.Name = "picRed05";
      this.picRed05.Size = new System.Drawing.Size(88, 32);
      this.picRed05.TabIndex = 29;
      this.picRed05.TabStop = false;
      // 
      // picRed04
      // 
      this.picRed04.BackColor = System.Drawing.Color.Red;
      this.picRed04.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picRed04.Location = new System.Drawing.Point(295, 48);
      this.picRed04.Name = "picRed04";
      this.picRed04.Size = new System.Drawing.Size(88, 32);
      this.picRed04.TabIndex = 28;
      this.picRed04.TabStop = false;
      // 
      // picRed03
      // 
      this.picRed03.BackColor = System.Drawing.Color.Red;
      this.picRed03.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picRed03.Location = new System.Drawing.Point(199, 48);
      this.picRed03.Name = "picRed03";
      this.picRed03.Size = new System.Drawing.Size(88, 32);
      this.picRed03.TabIndex = 27;
      this.picRed03.TabStop = false;
      // 
      // picRed02
      // 
      this.picRed02.BackColor = System.Drawing.Color.Red;
      this.picRed02.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picRed02.Location = new System.Drawing.Point(103, 48);
      this.picRed02.Name = "picRed02";
      this.picRed02.Size = new System.Drawing.Size(88, 32);
      this.picRed02.TabIndex = 26;
      this.picRed02.TabStop = false;
      // 
      // picPaddle
      // 
      this.picPaddle.BackColor = System.Drawing.Color.White;
      this.picPaddle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picPaddle.Location = new System.Drawing.Point(191, 416);
      this.picPaddle.Name = "picPaddle";
      this.picPaddle.Size = new System.Drawing.Size(96, 16);
      this.picPaddle.TabIndex = 25;
      this.picPaddle.TabStop = false;
      // 
      // picRed01
      // 
      this.picRed01.BackColor = System.Drawing.Color.Red;
      this.picRed01.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.picRed01.Location = new System.Drawing.Point(7, 48);
      this.picRed01.Name = "picRed01";
      this.picRed01.Size = new System.Drawing.Size(88, 32);
      this.picRed01.TabIndex = 24;
      this.picRed01.TabStop = false;
      // 
      // frmBlock
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(486, 461);
      this.Controls.Add(this.lblLives);
      this.Controls.Add(this.picBall);
      this.Controls.Add(this.picBlue05);
      this.Controls.Add(this.picBlue04);
      this.Controls.Add(this.picBlue03);
      this.Controls.Add(this.picBlue02);
      this.Controls.Add(this.picBlue01);
      this.Controls.Add(this.picGreen05);
      this.Controls.Add(this.picGreen04);
      this.Controls.Add(this.picGreen03);
      this.Controls.Add(this.picGreen02);
      this.Controls.Add(this.picGreen01);
      this.Controls.Add(this.picYellow05);
      this.Controls.Add(this.picYellow04);
      this.Controls.Add(this.picYellow03);
      this.Controls.Add(this.picYellow02);
      this.Controls.Add(this.picYellow01);
      this.Controls.Add(this.picRed05);
      this.Controls.Add(this.picRed04);
      this.Controls.Add(this.picRed03);
      this.Controls.Add(this.picRed02);
      this.Controls.Add(this.picPaddle);
      this.Controls.Add(this.picRed01);
      this.Controls.Add(this.lblScore);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBlock";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Blocks";
      this.Load += new System.EventHandler(this.frmBlock_Load);
      this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.frmBlock_MouseMove);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmBlock'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBlock()
      //***
      // Action
      //   - Create instance of 'frmBlock'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmBlock()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mlngAllGone;
    private int mlngLives = 3;
    private int mlngScore;
    private int mlngSpeedX = 2;
    private int mlngSpeedY = -2;

    #endregion

    #region "Properties"

    public int AllGone
    {

      get
        //***
        // Action Get
        //   - Return the number of boxes that are visible in the game (mlngAllGone)
        // Called by
        //   - CheckCollision(PictureBox, bool)
        //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngAllGone;
      }
      // int AllGone (Get)

      set
        //***
        // Action Set
        //   - Sets the number of boxes that are visible in the game (mlngAllGone becomes value)
        // Called by
        //   - CheckCollision(PictureBox, bool)
        //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngAllGone = value;
      }
      // AllGone(int) (Set)

    }
    // int AllGone

    public int BallX
    {

      get
        //***
        // Action Get
        //   - Return X coordinate of the ball (picBall.Left)
        // Called by
        //   - CheckCollision(PictureBox, bool)
        //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return picBall.Left;
      }
      // int BallX (Get)

      set
        //***
        // Action Set
        //   - Set X coordinate of the ball (picBall.Left becomes value)
        // Called by
        //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        picBall.Left = value;
      }
      // BallX(int) (Set)

    }
    // int BallX

    public int BallY
    {

      get
        //***
        // Action Get
        //   - Return Y coordinate of the ball (picBall.Top)
        // Called by
        //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return picBall.Top;
      }
      // int BallY (Get)

      set
        //***
        // Action Set
        //   - Set Y coordinate of the ball (picBall.Top becomes value)
        // Called by
        //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        picBall.Top = value;
      }
      // BallY(int) (Set)

    }
    // int BallY

    public int Lives
    {

      get
        //***
        // Action Get
        //   - Return the number of lives you still have in the game (mlngLives)
        // Called by
        //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        //   - UpdateLives()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngLives;     
      }
      // int Lives (Get)

      set
        //***
        // Action Set
        //   - Set the number of lives you still have in the game (mlngLives becomes value)
        // Called by
        //   - UpdateLives()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngLives = value;
      }
      // Lives(int) (Set)

    }
    // int Lives

    public int Score
    {

      get
        //***
        // Action Get
        //   - Return the score of the game (mlngScore)
        // Called by
        //   - UpdateScore()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngScore;
      }
      // int Score (Get)

      set
        //***
        // Action Set
        //   - Set the score of the game (mlngScore becomes value)
        // Called by
        //   - UpdateScore()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngScore = value;
      }
      //int Score (Set)
    
    }
    // int Score

    public int SpeedX
    {

      get
        //***
        // Action Get
        //   - Return the speed of the ball horizontally (mlngSpeedX)
        // Called by
        //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngSpeedX;
      }
      // int SpeedX (Get)

      set
        //***
        // Action Set
        //   - Set the speed of the ball horizontally (mlngSpeedX becomes value)
        // Called by
        //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngSpeedX = value;
      }
      // SpeedX(int) (Set)

    }
    // int SpeedX

    public int SpeedY
    {

      get
        //***
        // Action Get
        //   - Return the speed of the ball vertically (mlngSpeedY)
        // Called by
        //   - CheckCollision(PictureBox, bool)
        //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngSpeedY;
      }
      // int SpeedY (Get)

      set
        //***
        // Action Set
        //   - Set the speed of the ball vertically (mlngSpeedY becomes value)
        // Called by
        //   - CheckCollision(PictureBox, bool)
        //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240214 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240214 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngSpeedY = value;
      }
      // SpeedY(int) (Set)

    }
    // int SpeedY

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void frmBlock_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The timer starts to tick
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      tmrTimer.Enabled = true;
    }
    // frmBlock_Load(System.Object, System.EventArgs) Handles this.Load

    private void frmBlock_MouseMove(System.Object theSender, System.Windows.Forms.MouseEventArgs theMouseEventArguments)
      //***
      // Action
      //   - Place the position of the paddle where the mouse pointer is, horizontally
      // Called by
      //   - User action (Moving the mouse over the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      picPaddle.Left = theMouseEventArguments.X - picPaddle.Width / 2;
    }
    // frmBlock_MouseMove(System.Object, System.Windows.Forms.MouseEventArgs) Handles frmBlock.MouseMove
    
    private void tmrTimer_Tick(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Actions to be taken every time the games progresses
      //   - AllGone becomes 0
      //   - All blocks are checked on collision
      //   - If AllGone = 1
      //     - Stop timer
      //     - Show message that you finished the game
      //   - If Not
      //     - Do Nothing
      //   - Move the ball towards the X-coordinate
      //   - If the ball gets out the frame of the window
      //     - Reverse direction on the X-coordinate
      //   - If Not
      //     - Do Nothing
      //   - Move the ball towards the Y-coordinate
      //   - If the ball gets out the frame of the window
      //     - Reverse direction on the Y-coordinate
      //   - If Not
      //     - Do Nothing
      //   - If the ball passes the paddle
      //     - Stop timer
      //     - Update the lives
      //     - Put ball in starting position
      //     - Put direction in starting position
      //     - If Lives is 0
      //       - Show message that you have lost the game
      //     - If Not
      //       - Show message that you have lost a live
      //       - Enable timer
      //   - If Not
      //     - Do Nothing
      // Called by
      //   - Program action (The beating heart of the game)
      // Calls
      //   - AllGone(int) (Set)
      //   - BallX(int) (Set)
      //   - BallY(Int32) (Set)
      //   - CheckCollisions()
      //   - int AllGone (Get)
      //   - int BallX (Get)
      //   - int BallY (Get)
      //   - int Lives (Get)
      //   - int SpeedX (Get)
      //   - int SpeedY (Get)
      //   - SpeedX(int) (Set)
      //   - SpeedY(int) (Set)
      //   - UpdateLives()
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      AllGone = 0;
      CheckCollisions();

      if (AllGone == 1)
      {
        tmrTimer.Enabled = false;
        MessageBox.Show("You finished the game!", "CONGRATULATIONS");
      }
      else
        // AllGone <> 1
      {
      }
      // AllGone = 1

      BallX += SpeedX;

      if ((BallX < 3) || ((BallX + picBall.Width) > (this.Width - 5)))
      {
        SpeedX = -SpeedX;
      }
      else
        // BallX <= 3 And BallX + picBall.Width <= this.Width - 5
      {
      }
      // BallX < 3 Or BallX + picBall.Width > this.Width - 5

      BallY += SpeedY;

      if (BallY < 3)
      {
        SpeedY = -SpeedY;
      }
      else
        // BallY >= 3
      {
      }
      // BallY < 3 

      if ((BallY + picBall.Height) > (this.Height - 5))
      {
        tmrTimer.Enabled = false;
        UpdateLives();
        BallX = 232;
        BallY = 376;
        SpeedX = 2;
        SpeedY = -2;

        if (Lives < 1)
        {
          MessageBox.Show("You have lost the game.", "OH NO!");
        }
        else
          // Lives >= 1
        {
          MessageBox.Show("You missed!", "OH NO");
          tmrTimer.Enabled = true;
        }
        // Lives < 1

      }
      else
        // BallY + picBall.Height <= this.Height - 5
      {
      }
      // BallY + picBall.Height > Me.Height - 5

    }
    // tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void CheckCollision(PictureBox thePictureBox)
      //***
      // Action
      //   - Check collision
      //   - If collision, hide thePictureBox
      // Called by
      //   - CheckCollisions()
      // Calls
      //   - CheckCollision(PictureBox, bool)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      CheckCollision(thePictureBox, true);
    }
    // CheckCollision(PictureBox)

    public void CheckCollision(PictureBox thePictureBox, bool blnHide)
      //***
      // Action
      //   - A given picturebox (thePictureBox) is checked if the ball collides
      //   - If thePictureBox is visible (not touched yet)
      //     - If location of thePictureBox collides with the location of the Ball
      //       - Reverse the speed at Y-coordinate
      //       - Update the score
      //       - If blnHide (not the paddle)
      //         - Hide thePictureBox
      //       - If Not
      //         - Do Nothing
      //     - If Not
      //       - Do Nothing
      //     - Add 1 to AllGone
      //   - If Not
      // Called by
      //   - CheckCollisions()
      //   - CheckCollision(PictureBox)
      // Calls
      //   - AllGone(int) (Set)
      //   - int AllGone (Get)
      //   - int BallX (Get)
      //   - int SpeedY (Get)
      //   - SpeedY(int) (Set)
      //   - UpdateScore()
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (thePictureBox.Visible)
      {
        
        if ((BallX > thePictureBox.Location.X) &&
          (BallX < (thePictureBox.Location.X + thePictureBox.Size.Width)) &&
          (picBall.Location.Y > thePictureBox.Location.Y) &&
          (picBall.Location.Y < (thePictureBox.Location.Y + thePictureBox.Size.Height)))
        {
          SpeedY = -SpeedY;
          UpdateScore();

          if (blnHide)
          {
            thePictureBox.Visible = false;
          }
          else
            // Not blnHide
          {
          }
          // blnHide

        }
        else
          // Not ((BallX > thePictureBox.Location.X) And _
          //     (BallX < thePictureBox.Location.X + thePictureBox.Size.Width) And _
          //     (picBall.Location.Y > thePictureBox.Location.Y) And _
          //     (picBall.Location.Y < thePictureBox.Location.Y + thePictureBox.Size.Height))
        {
        }
        // (BallX > thePictureBox.Location.X) And _
        // (BallX < thePictureBox.Location.X + thePictureBox.Size.Width) And _
        // (picBall.Location.Y > thePictureBox.Location.Y) And _
        // (picBall.Location.Y < thePictureBox.Location.Y + thePictureBox.Size.Height)

        AllGone += 1;
      }
      else
        // Not thePictureBox.Visible 
      {
      }
      // thePictureBox.Visible 

    }
    // CheckCollision(PictureBox, bool)

    public void CheckCollisions()
      //***
      // Action
      //   - Paddle is checked on collision (no hiding)
      //   - All reds are checked on collision
      //   - All yellows are checked on collision
      //   - All greens are checked on collision
      //   - All bleus are checked on collision
      // Called by
      //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - CheckCollision(PictureBox)
      //   - CheckCollision(PictureBox, bool)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      CheckCollision(picPaddle, false);
      CheckCollision(picRed01);
      CheckCollision(picRed02);
      CheckCollision(picRed03);
      CheckCollision(picRed04);
      CheckCollision(picRed05);
      CheckCollision(picYellow01);
      CheckCollision(picYellow02);
      CheckCollision(picYellow03);
      CheckCollision(picYellow04);
      CheckCollision(picYellow05);
      CheckCollision(picGreen01);
      CheckCollision(picGreen02);
      CheckCollision(picGreen03);
      CheckCollision(picGreen04);
      CheckCollision(picGreen05);
      CheckCollision(picBlue01);
      CheckCollision(picBlue02);
      CheckCollision(picBlue03);
      CheckCollision(picBlue04);
      CheckCollision(picBlue05);
    }
    // CheckCollisions()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmBlock
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmBlock());
    }
    // Main() 

    public void UpdateLives()
      //***
      // Action
      //   - Subtract 1 from Lives
      //   - Show Number of Lives
      // Called by
      //   - tmrTimer_Tick(System.Object, System.EventArgs) Handles tmrTimer.Tick
      // Calls
      //   - int Lives(Get)
      //   - Lives(int) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Lives -= 1;
      lblLives.Text = "Lives: " + Lives;
    }
    // UpdateLives()

    public void UpdateScore()
      //***
      // Action
      //   - Add 10 to Score
      //   - Show Score
      // Called by
      //   - CheckCollision(PictureBox, bool)
      // Calls
      //   - int Score (Get)
      //   - Score(int) (Set)
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Score += 10;
      lblScore.Text = "Score: " + Score;
    }
    // UpdateScore()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBlock

}
// CopyPaste.Learning