//***
// Action
//   - Shell sort routine (Array 1-based, first element has index 1)
//   - Shell sort is mainly a variation of Insertion Sort
//   - In insertion sort, we move elements only one position ahead
//   - When an element has to be moved far ahead, many movements are involved
//   - The idea of ShellSort is to allow the exchange of far items
//   - In Shell sort, we make the array h-sorted for a large value of h
//   - We keep reducing the value of h until it becomes 1
//   - An array is said to be h-sorted if all sublists of every h-th element are sorted
// Created
//   - CopyPaste � 20240503 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240503 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpSort
  {

    #region "Constructors / Destructors"

    public cpSort()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpSort()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static string[] marrstrText;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void ShellSort(string[] arrstrSort, int lngNumberOfElements)
      //***
      // Action
      //   - Shell sort routine
      //   - There is an array and a number of elements (0-based)
      //   - The number of elements is divided by 2 (lngSpan)
      //   - While lngSpan is larger than 0
      //     - Loop thru the second part of the array (from lngSpan till second last step by step) (lngCounter1)
      //       - Loop thru the corresponding first part of the array (from lngCounter1 - lngSpan + 1 till 1 step -lngSpan) (lngCounter2)
      //         - If element on the first part is smaller or equal to the corresponding element on the second part
      //           - Corresponding is lngCounter2 and the one with a gap of lngSpan
      //           - Exit loop
      //         - If not
      //           - Swap both elements
      //     - Divide lngSpan by 2
      //   - Array is sorted
      // Called by
      //   - frmSortText.mnuFileSortText_Click(System.Object, System.EventArgs) Handles mnuFileSortText.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240503 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240503 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngCounter1;
      int lngCounter2;
      int lngSpan;
      string strTemp;

      lngSpan = lngNumberOfElements / 2;

      while (lngSpan > 0)
      {
        
        for (lngCounter1 = lngSpan; lngCounter1 < lngNumberOfElements; lngCounter1++)
        {
          
          for (lngCounter2 = (lngCounter1 - lngSpan); lngCounter2 >= 0; lngCounter2 = lngCounter2 -lngSpan)
          {

            if (arrstrSort[lngCounter2].CompareTo(arrstrSort[lngCounter2 + lngSpan]) <= 0)
            {
              break;
            }
            else 
              // arrstrSort[lngCounter2].CompareTo(arrstrSort[lngCounter2 + lngSpan]) > 0
            {
            }
            // arrstrSort[lngCounter2].CompareTo(arrstrSort[lngCounter2 + lngSpan]) <= 0 
            
            strTemp = arrstrSort[lngCounter2];
            arrstrSort[lngCounter2] = arrstrSort[lngCounter2 + lngSpan];
            arrstrSort[lngCounter2 + lngSpan] = strTemp;
          }
          // lngCounter2 = 1

        }
        // lngCounter1 = lngNumberOfElements
        
        lngSpan = lngSpan / 2;
      }
      // lngSpan <= 0

    }
    // ShellSort(string[], int)
	
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpSort

}
// CopyPaste.Learning