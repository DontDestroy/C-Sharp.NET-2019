//***
// Action
//   - The representation of a cpDocument in a WFP form
//   - When the document is loaded 
// Created
//   - CopyPaste � 20220817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220817 � VVDW
// Proposal (To Do)
//   -
//***

using System.IO;
using System.Windows;

namespace SingleInstanceApplication
{

  public partial class wpfcpDocument : Window
  {

    #region "Constructors / Destructors"

    public wpfcpDocument()
    //***
    // Action
    //   - Creates an instance of a wpfcpDocument
    // Called by
    //   - User action (A new window is added to the application)
    //   - wpfcpApplication.ShowDocument(string)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfcpDocument()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpDocumentReference thecpDocumentReference;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    protected override void OnClosed(System.EventArgs theEventArguments)
    //***
    // Action
    //   - When a Document is closed from the application
    //   - A reference to that document is removed
    // Called by
    //   - User action (A window is closed from the application)
    // Calls
    //   - cpwpfApplication.ObservableCollection<cpDocumentReference> OpenDocuments (Get)
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      base.OnClosed(theEventArguments);

      ((cpwpfApplication)Application.Current).OpenDocuments.Remove(thecpDocumentReference);
    }
    // OnClosed(System.EventArgs)

    #endregion

    #region "Sub / Function"

    public void LoadFile(cpDocumentReference acpDocumentReference)
    //***
    // Action
    //   - When a Document is added to the application
    //   - A reference to that document is added to the document itself
    //   - The content of the form becomes the text of the Document (using the name)
    //   - The title of the form becomes the name of the Document
    // Called by
    //   - User action (A new window is added to the application)
    //   - cpwpfApplication.ShowDocument(string)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      this.thecpDocumentReference = acpDocumentReference;
      this.Content = File.ReadAllText(acpDocumentReference.Name);
      this.Title = acpDocumentReference.Name;
    }
    // LoadFile(cpDocumentReference)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfcpDocument

}
// SingleInstanceApplication