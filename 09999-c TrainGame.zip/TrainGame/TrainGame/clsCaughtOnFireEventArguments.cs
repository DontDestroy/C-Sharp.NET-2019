//***
// Action
//   - Implementation of cpCaughtOnFireEventArguments
//   - Used for giving information on the event (signal) from ctlTrack to the frmTrainGame
//     - cpCaughtOnFireEventArguments contains the needed data / information for the event
//   - Information given is the location of the fire
//   - The cltTrack triggers the event
//   - The frmTrainGame handles the event
// Created
//   - CopyPaste � 20240228 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240228 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Games
{

  public class cpCaughtOnFireEventArguments: System.EventArgs
  {

    #region "Constructors / Destructors"

    public cpCaughtOnFireEventArguments(int lngLocation)
      //***
      // Action
      //   - Constructor with the location of the fire next to the track on the form
      //   - At the start of the game, the fire is at the end of the track on the form
      // Called by
      //   - cpctlTrack.tmrFire_Tick(System.Object, System.EventArgs) Handles tmrFire.Tick
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240228 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240228 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mlngLocation = lngLocation;
    }
    // cpCaughtOnFireEventArguments(int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mlngLocation = 0;

    #endregion

    #region "Properties"

    public int Location
    {

      get
        //***
        // Action Get
        //   - Returning mlngLocation
        // Called by
        //   - frmTrainGame.cpctlTrack_cpRepositionFire(System.Object, cpCaughtOnFireEventArguments) Handles cpctlTrack.cpRepositionFire
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240228 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240228 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngLocation;
      }
      // int Location (Get)

    }
    // int Location

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpCaughtOnFireEventArguments

}
// CopyPaste.Learning.Games