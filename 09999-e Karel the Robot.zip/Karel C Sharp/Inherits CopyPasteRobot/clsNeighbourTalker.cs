﻿//***
// Action
//   - A definition of a NeighbourTalker
// Created
//   - CopyPaste – 20251028 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251028 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpNeighbourTalker : cpCopyPasteRobot, cpinfBeeperPutter
	{

		#region "Constructors / Destructors"

		public cpNeighbourTalker(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor, cpinfBeeperPutter aRobot) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpNeighbourTalker starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag and a neighbour
    //   - The neighbour robot is assigned
    // Called by
    //   - cpNeighbourTalker(int, int, Directions.Direction, int, cpinfBeeperPutter)
    //   - cpProgram.TwoDifferentRobotsInterface()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theNeighbour = aRobot;
    }
    // cpNeighbourTalker(int, int, Directions.Direction, int, Color, cpinfBeeperPutter) 

    public cpNeighbourTalker(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, cpinfBeeperPutter aRobot) : this(intStreet, intAvenue, theDirection, intBeepers, null, aRobot)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpNeighbourTalker starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag and a neighbour
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpNeighbourTalker(int, int, Directions.Direction, int, Color, cpinfBeeperPutter)
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpNeighbourTalker(int, int, Directions.Direction, int, cpinfBeeperPutter) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpinfBeeperPutter theNeighbour = null;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void DistributeBeepers()
    //***
    // Action
    //   - Implementation of method from cpinfBeeperPutter
    //   - Put a beeper down
    //   - Move one forward
    //   - Send message to the neighbour to distribute the beepers
    // Called by
    //   - cpProgram.TwoDifferentRobotsInterface()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      putBeeper();
      move();
      theNeighbour.DistributeBeepers();
      SwitchOff();
    }
    // DistributeBeepers()

    public void SwitchOff()
    //***
    // Action
    //   - Implementation of method from cpinfBeeperPutter
    //   - Turn off the robot
    // Called by
    //   - cpProgram.TwoDifferentRobotsInterface()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251028 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251028 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      base.turnOff();
    }
    // SwitchOff()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpNeighbourTalker

}
// cpKarelTheRobot