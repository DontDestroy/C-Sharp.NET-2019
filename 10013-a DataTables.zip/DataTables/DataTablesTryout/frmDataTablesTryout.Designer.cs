﻿//***
// Action
//   - Having DataTables in the application
// Created
//   - CopyPaste – 20210714 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210714 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

namespace DataTablesTryout
{

  partial class frmDataTablesTryout
  {

    #region Windows Form Designer generated code

    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    internal System.Windows.Forms.ListBox lstClient;
    internal System.Windows.Forms.Button cmdTable;
    internal System.Windows.Forms.Button cmdSelect;
    internal System.Windows.Forms.Button cmdUnique;
    internal System.Windows.Forms.Button cmdForeign;
    internal System.Windows.Forms.Button cmdSchema;
    internal System.Windows.Forms.Button cmdVersion;
    internal System.Windows.Forms.Button cmdAddRow;
    internal System.Windows.Forms.Button cmdCalculate;
    internal System.Windows.Forms.Button cmdDataSet;
    internal System.Windows.Forms.DataGrid dgrOrder;
    internal System.Windows.Forms.ListBox lstEmployee;
    internal System.Windows.Forms.Label lblOrder;
    internal System.Windows.Forms.Label lblClient;
    internal System.Windows.Forms.Label lblEmployee;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.lstClient = new System.Windows.Forms.ListBox();
      this.cmdTable = new System.Windows.Forms.Button();
      this.cmdSelect = new System.Windows.Forms.Button();
      this.cmdUnique = new System.Windows.Forms.Button();
      this.cmdForeign = new System.Windows.Forms.Button();
      this.cmdSchema = new System.Windows.Forms.Button();
      this.cmdVersion = new System.Windows.Forms.Button();
      this.cmdAddRow = new System.Windows.Forms.Button();
      this.cmdCalculate = new System.Windows.Forms.Button();
      this.cmdDataSet = new System.Windows.Forms.Button();
      this.dgrOrder = new System.Windows.Forms.DataGrid();
      this.lstEmployee = new System.Windows.Forms.ListBox();
      this.lblOrder = new System.Windows.Forms.Label();
      this.lblClient = new System.Windows.Forms.Label();
      this.lblEmployee = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).BeginInit();
      this.SuspendLayout();
      // 
      // lstClient
      // 
      this.lstClient.DisplayMember = "tblCPCustomers.strIdCustomer";
      this.lstClient.Location = new System.Drawing.Point(200, 26);
      this.lstClient.Name = "lstClient";
      this.lstClient.Size = new System.Drawing.Size(200, 95);
      this.lstClient.TabIndex = 18;
      this.lstClient.ValueMember = "tblCPCustomers.strIdCustomer";
      // 
      // cmdTable
      // 
      this.cmdTable.Location = new System.Drawing.Point(520, 10);
      this.cmdTable.Name = "cmdTable";
      this.cmdTable.Size = new System.Drawing.Size(96, 24);
      this.cmdTable.TabIndex = 21;
      this.cmdTable.Text = "Add Table";
      // 
      // cmdSelect
      // 
      this.cmdSelect.Location = new System.Drawing.Point(520, 266);
      this.cmdSelect.Name = "cmdSelect";
      this.cmdSelect.Size = new System.Drawing.Size(96, 23);
      this.cmdSelect.TabIndex = 29;
      this.cmdSelect.Text = "Select A*";
      // 
      // cmdUnique
      // 
      this.cmdUnique.Location = new System.Drawing.Point(520, 234);
      this.cmdUnique.Name = "cmdUnique";
      this.cmdUnique.Size = new System.Drawing.Size(96, 23);
      this.cmdUnique.TabIndex = 28;
      this.cmdUnique.Text = "Unique";
      // 
      // cmdForeign
      // 
      this.cmdForeign.Location = new System.Drawing.Point(520, 202);
      this.cmdForeign.Name = "cmdForeign";
      this.cmdForeign.Size = new System.Drawing.Size(96, 23);
      this.cmdForeign.TabIndex = 27;
      this.cmdForeign.Text = "Foreign Key";
      // 
      // cmdSchema
      // 
      this.cmdSchema.Location = new System.Drawing.Point(520, 170);
      this.cmdSchema.Name = "cmdSchema";
      this.cmdSchema.Size = new System.Drawing.Size(96, 23);
      this.cmdSchema.TabIndex = 26;
      this.cmdSchema.Text = "FillSchema";
      // 
      // cmdVersion
      // 
      this.cmdVersion.Location = new System.Drawing.Point(520, 138);
      this.cmdVersion.Name = "cmdVersion";
      this.cmdVersion.Size = new System.Drawing.Size(96, 23);
      this.cmdVersion.TabIndex = 25;
      this.cmdVersion.Text = "Row Version";
      // 
      // cmdAddRow
      // 
      this.cmdAddRow.Location = new System.Drawing.Point(520, 106);
      this.cmdAddRow.Name = "cmdAddRow";
      this.cmdAddRow.Size = new System.Drawing.Size(96, 23);
      this.cmdAddRow.TabIndex = 24;
      this.cmdAddRow.Text = "Add DataRow";
      // 
      // cmdCalculate
      // 
      this.cmdCalculate.Location = new System.Drawing.Point(520, 74);
      this.cmdCalculate.Name = "cmdCalculate";
      this.cmdCalculate.Size = new System.Drawing.Size(96, 24);
      this.cmdCalculate.TabIndex = 23;
      this.cmdCalculate.Text = "Calculate";
      // 
      // cmdDataSet
      // 
      this.cmdDataSet.Location = new System.Drawing.Point(520, 42);
      this.cmdDataSet.Name = "cmdDataSet";
      this.cmdDataSet.Size = new System.Drawing.Size(96, 24);
      this.cmdDataSet.TabIndex = 22;
      this.cmdDataSet.Text = "Dataset Table ";
      // 
      // dgrOrder
      // 
      this.dgrOrder.DataMember = "";
      this.dgrOrder.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrOrder.Location = new System.Drawing.Point(8, 154);
      this.dgrOrder.Name = "dgrOrder";
      this.dgrOrder.Size = new System.Drawing.Size(496, 208);
      this.dgrOrder.TabIndex = 20;
      // 
      // lstEmployee
      // 
      this.lstEmployee.Location = new System.Drawing.Point(8, 26);
      this.lstEmployee.Name = "lstEmployee";
      this.lstEmployee.Size = new System.Drawing.Size(184, 95);
      this.lstEmployee.TabIndex = 16;
      // 
      // lblOrder
      // 
      this.lblOrder.AutoSize = true;
      this.lblOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOrder.Location = new System.Drawing.Point(8, 138);
      this.lblOrder.Name = "lblOrder";
      this.lblOrder.Size = new System.Drawing.Size(48, 13);
      this.lblOrder.TabIndex = 19;
      this.lblOrder.Text = "Orders:";
      // 
      // lblClient
      // 
      this.lblClient.AutoSize = true;
      this.lblClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblClient.Location = new System.Drawing.Point(200, 10);
      this.lblClient.Name = "lblClient";
      this.lblClient.Size = new System.Drawing.Size(49, 13);
      this.lblClient.TabIndex = 17;
      this.lblClient.Text = "Clients:";
      // 
      // lblEmployee
      // 
      this.lblEmployee.AutoSize = true;
      this.lblEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblEmployee.Location = new System.Drawing.Point(8, 10);
      this.lblEmployee.Name = "lblEmployee";
      this.lblEmployee.Size = new System.Drawing.Size(71, 13);
      this.lblEmployee.TabIndex = 15;
      this.lblEmployee.Text = "Employees:";
      // 
      // frmDataTablesTryout
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(624, 373);
      this.Controls.Add(this.lstClient);
      this.Controls.Add(this.cmdTable);
      this.Controls.Add(this.cmdSelect);
      this.Controls.Add(this.cmdUnique);
      this.Controls.Add(this.cmdForeign);
      this.Controls.Add(this.cmdSchema);
      this.Controls.Add(this.cmdVersion);
      this.Controls.Add(this.cmdAddRow);
      this.Controls.Add(this.cmdCalculate);
      this.Controls.Add(this.cmdDataSet);
      this.Controls.Add(this.dgrOrder);
      this.Controls.Add(this.lstEmployee);
      this.Controls.Add(this.lblOrder);
      this.Controls.Add(this.lblClient);
      this.Controls.Add(this.lblEmployee);
      this.Name = "frmDataTablesTryout";
      this.Text = "DataTables Tryout";
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Cleanup after closing the form
    // Called by
    //   - User Action (Closing form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20210714 – VVDW
    // Changed
    //   - Organisation – yyyymmdd – Initials of programmer – What changed
    // Tested
    //   - CopyPaste – 20210714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing && (components != null))
      {
        components.Dispose();
      }
      // (disposing && (components != null))

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataTablesTryout

}
// DataTablesTryout