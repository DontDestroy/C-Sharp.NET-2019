﻿//***
// Action
//   - Two different routines are compared to each other
//     - Concatenating strings using the + operator
//     - Concatenating strings using the StringBuilder
//   - Benchmarking the memory and the time consumption of both routines
// Created
//   - CopyPaste – 20260525 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260525 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpStringBenchMarks
  {

    #region "Constructors / Destructors"

    public cpStringBenchMarks()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - cpProgram.Main()
    //   - cpProgram.RunSomeCodeWithStopWatch()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpStringBenchMarks()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private const int intNumberOfIterations = 100_000;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [BenchmarkAttribute]
    public string StringBuilder()
    //***
    // Action
    //   - Concatenating strings using the + operator
    //   - Loop a intNumberOfIterations times to create a longer string
    // Called by
    //   - cpProgram.Main()
    //   - cpProgram.RunSomeCodeWithStopWatch()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      StringBuilder sbString = new StringBuilder();

      for (int intCounter = 0; intCounter < intNumberOfIterations; intCounter++)
      {
        sbString.Append("a");
      }
      // intCounter < intNumberOfIterations

      return sbString.ToString();
    }
    // StringPlusOperator()

    [BenchmarkAttribute]
    public string StringPlusOperator()
    //***
    // Action
    //   - Concatenating strings using the StringBuilder
    //   - Loop a intNumberOfIterations times to create a longer string
    // Called by
    //   - cpProgram.Main()
    //   - cpProgram.RunSomeCodeWithStopWatch()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strString = string.Empty;

      for (int intCounter = 0; intCounter < intNumberOfIterations; intCounter++)
      {
        strString += "a";
      }
      // intCounter < intNumberOfIterations

      return strString;
    }
    // StringPlusOperator()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpStringBenchMarks

}
// CopyPaste.Learning