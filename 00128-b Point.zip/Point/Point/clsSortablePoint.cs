//***
// Action
//   - Implementation of a sortable point
//   - Interface IComparable and IFormattable are used
//   - The goal is this
//     - You have a point with two coordinates (X and Y)
//     - Depending on a fixed point (the center) (Coordinates 0 and 0)
//       - The distance towards that center is calculated
//       - So a sortable point has a distance towards the center
//     - A list of sortable points can be sorted depending on the distance towards the center 
//     - You can decide to add the coordinates in the visualisation of the sortable point
//     - It is possible to give a format for the X and Y coordinates
// Created
//   - CopyPaste � 20240314 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240314 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpSortablePoint : IComparable, IFormattable
  {

    #region "Constructors / Destructors"

    public cpSortablePoint()
      //***
      // Action
      //   - Empty Constructor of a sortable point
      //   - Two coordinates are not given and are by default 0
      // Called by
      //   - cpSortablePoint(int, int)
      // Calls
      //   - Center(cpSortablePoint) (Set)
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      // Center = new cpSortablePoint();
    }
    // cpSortablePoint()

    public cpSortablePoint(int lngX, int lngY) : this()
      //***
      // Action
      //   - Constructor of a sortable point
      //   - First create the point with the default properties
      //   - Two coordinates are given
      // Called by
      //   - cpSortedPointList.AddRandomPoints(Int32, Int32)
      //   - frmPoint.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
      // Calls
      //   - cpSortablePoint()
      //   - X(int) (Set)
      //   - Y(int) (Set)
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      X = lngX;
      Y = lngY;
    }
    // cpSortablePoint(int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static cpSortablePoint mcpCenter = new cpSortablePoint();
    private int mlngX;
    private int mlngY;

    #endregion

    #region "Properties"

    public static cpSortablePoint Center
    {

      get
        //***
        // Action Get
        //   - Returns the center
        // Called by
        //   - int cpSquaredDistance()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240314 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240314 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mcpCenter;
      }
      // cpSortablePoint Center() (Get)

      set
        //***
        // Action Set
        //   - mcpCenter becomes value
        // Called by
        //   - cpSortablePoint()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240314 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240314 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mcpCenter = value;
      }
      // Center(cpSortablePoint) (Set)

    }
    // cpSortablePoint Center()

    public int X
    {

      get
        //***
        // Action Get
        //   - Returns the X coordinate
        // Called by
        //   - frmPoint.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
        //   - frmPointCoordinate.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
        //   - frmPointList.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
        //   - int cpSquaredDistance()
        //   - string ToString(string, System.IFormatProvider)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240314 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240314 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngX;
      }
      // int X (Get)

      set
        //***
        // Action Set
        //   - mlngX becomes value
        // Called by
        //   - cpSortablePoint(int, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240314 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240314 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngX = value;
      }
      // X(int) (Set)

    }
    // int X

    public int Y
    {

      get
        //***
        // Action Get
        //   - Returns the Y coordinate
        // Called by
        //   - frmPoint.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
        //   - frmPointCoordinate.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
        //   - frmPointList.cmdDraw_Click(System.Object, System.EventArgs) Handles cmdDraw.Click
        //   - int cpSquaredDistance()
        //   - string ToString(string, System.IFormatProvider)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240314 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240314 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mlngY;
      }
      // int Y (Get)

      set
        //***
        // Action Set
        //   - mlngY becomes value
        // Called by
        //   - cpSortablePoint(int, int)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240314 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240314 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mlngY = value;
      }
      // Y(int) (Set)

    }
    // int Y

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string ToString()
      //***
      // Action
      //   - When a sortable point is converted to a string
      //   - The coordinate are shown in the format L
      //   - This is (X, Y)
      // Called by
      //   - 
      // Calls
      //   - string ToString(string)
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return ToString("L");
    }
    // string ToString()

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int CompareTo(System.Object theObject)
      //***
      // Action
      //   - An obligatory implementation due to IComparable
      //   - 2 things (Sortable points) are compared to each other
      //     - Subtract the distances towards the center
      // Called by
      //   - 
      // Calls
      //   - int cpSquaredDistance()
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpSortablePoint thePointToCompareWith;

      thePointToCompareWith = (cpSortablePoint)theObject;
      return cpSquaredDistance() - thePointToCompareWith.cpSquaredDistance();
    }
    // int CompareTo(System.Object)

    private int cpSquaredDistance()
      //***
      // Action
      //   - Substract the X coordinate from the X coordinate of the center
      //   - Substract the Y coordinate from the Y coordinate of the center
      //   - Square both distances
      //   - Add them
      //   - We don't square it
      //                     '     - Because it makes things slower
      //     - Because CompareTo expects integer values
      // 
      //   - The calculation used is a part of the rule of Pythagoras
      //
      //   - c (Center)
      //   - p (Sortable point)
      //
      //   y----p(x, y)
      //       /|
      //      / |
      //     /  |
      //    /   |
      //   c----x
      //
      // Called by
      //   - cpCompareTo(System.Object) As Integer 
      // Calls
      //   - cpSortablePoint Center (Get)
      //   - int X (Get)
      //   - int Y (Get)
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int lngXDistance;
      int lngYDistance;

      lngXDistance = Center.X - X;
      lngYDistance = Center.Y - Y;

      return (lngXDistance * lngXDistance) + (lngYDistance * lngYDistance);
    }
    // int cpSquaredDistance()

    public string ToString(string strFormat)
      //***
      // Action
      //   - When a sortable point is converted to a string
      //   - The coordinate can be shown in the format L
      //     - This is (X,Y)
      //   - The coordinate can be shown in the format S
      //     - This is X:Y
      //   - The coordinate can be show in another formatprovidor
      //     - This depends on the given formatprovidor
      // Called by
      //   - string ToString()
      // Calls
      //   - string ToString(string, System.IFormatProvider)
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      return ToString(strFormat, null);
    }
    // string ToString()

    public string ToString(string strFormat, System.IFormatProvider theFormatProvider)
      //***
      // Action
      //   - When a sortable point is converted to a string
      //   - The coordinate can be shown in the format L
      //     - This is "(X, Y)"
      //   - The coordinate can be shown in the format S
      //     - This is "X:Y"
      //   - The coordinate can be show in another formatprovidor
      //     - This depends on the given formatprovidor
      //     - This is "X Y" (X and Y formatted by the formatprovidor)
      // Called by
      //   - string ToString(string)
      // Calls
      //   - int X (Get)
      //   - int Y (Get)
      // Created
      //   - CopyPaste � 20240314 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240314 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strResult;

      switch (strFormat.ToUpper())
      {
        case "L":
          strResult = String.Format("({0},{1})", X, Y);
          break;
        case "S":
          strResult = String.Format("{0}:{1}", X, Y);
          break;
        default:
          strResult = (X.ToString(strFormat, theFormatProvider) + " " + Y.ToString(strFormat, theFormatProvider));
          break;
      }
      // strFormat.ToUpper()

      return strResult;
    }
    // string ToString(string, System.IFormatProvider)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion
  
  }
  // cpSortablePoint

}
// CopyPaste.Learning