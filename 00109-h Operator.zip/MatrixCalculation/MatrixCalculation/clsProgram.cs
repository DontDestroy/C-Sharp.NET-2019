﻿//***
// Action
//   - Example of an operator of matrixes
//   - The goal is to test the creation of an operator
// Created
//   - CopyPaste – 20220531 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220531 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.MatrixCalculation
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220531 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Demo of the class cpMatrix calculations
    //   - Define 2 matrices
    //   - Display first matrix in the console
    //   - Display if they are all ones
    //   - Display second matrix in the console
    //   - Display if they are all ones
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - bool false(cpMatrix)
    //   - bool true(cpMatrix)
    //   - cpMatrix cpMatrix.+(cpMatrix, cpMatrix)
    //   - cpMatrix(int, int)
    //   - string cpMatrix.ToString()
    //   - this[int, int](int) (Set)
    // Created
    //   - CopyPaste – 20220531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220531 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpMatrix aMatrix1 = new cpMatrix(3, 3);
      cpMatrix aMatrix2 = new cpMatrix(3, 3);

      aMatrix1[0, 0] = 1;
      aMatrix1[0, 1] = 2;
      aMatrix1[0, 2] = 0;
      aMatrix1[1, 0] = 0;
      aMatrix1[1, 1] = 1;
      aMatrix1[1, 2] = 2;
      aMatrix1[2, 0] = 1;
      aMatrix1[2, 1] = 0;
      aMatrix1[2, 2] = 2;

      aMatrix2[0, 0] = 1;
      aMatrix2[0, 1] = 1;
      aMatrix2[0, 2] = 1;
      aMatrix2[1, 0] = 1;
      aMatrix2[1, 1] = 1;
      aMatrix2[1, 2] = 1;
      aMatrix2[2, 0] = 1;
      aMatrix2[2, 1] = 1;
      aMatrix2[2, 2] = 1;

      Console.WriteLine("Matrix 1");
      Console.WriteLine(aMatrix1);

      if (aMatrix1)
      {
        Console.WriteLine("All ones");
      }
      else
      // Not aMatrix1
      {
        Console.WriteLine("Not all ones");
      }
      // aMatrix1

      Console.WriteLine();
      Console.WriteLine("Matrix 2");
      Console.WriteLine(aMatrix2);

      if (aMatrix2)
      {
        Console.WriteLine("All ones");
      }
      else
      // Not aMatrix2
      {
        Console.WriteLine("Not all ones");
      }
      // aMatrix2

      Console.WriteLine();
      Console.WriteLine("Matrix Sum");

      // VVDW - Do you see why this below is bad programming?

      Console.WriteLine(aMatrix1 + aMatrix2);

      if (aMatrix1 + aMatrix2)
      {
        Console.WriteLine("All ones");
      }
      // Not aMatrix1 + aMatrix2
      else
      {
        Console.WriteLine("Not all ones");
      }
      // aMatrix1 + aMatrix2

      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning.MatrixCalculation