﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCopyPasteCoffee.aspx.cs" Inherits="CopyPaste.Learning.wfrmCopyPasteCoffee" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Copy Paste Coffee</title>
  <style type="text/css">
    body {
      background-color: #d2b48c;
      margin-left: 20%;
      margin-right: 20%;
      border: 2px dotted black;
      padding: 10px 10px 10px 10px;
      font-family: sans-serif;
    }
  </style>
</head>
<body>
  <form id="wfrmCopyPasteCoffee">
    <h1>Copy Paste Coffee Beverages</h1>
    <h2 id="hdrCappuccino">Cappuccino, € 1.89</h2>
    <p>A mixture of espresso, steamed milk and milk foam.</p>
    <h2 id="hdrChaiTea">Chai Tea, € 2.85</h2>
    <p>A spicy drink made with black tea, spices, milk and honey.</p>
    <h2 id="hdrHouseBlend">House Blend, € 2.49</h2>
    <p>A smooth, mild blend of coffees from Mexico, Bolivia and Guatemala.</p>
    <h2 id="hdrMochaCaffeLatte">Mocha Caffe Latte, € 2.35</h2>
    <p>Espresso, steamed milk and chocolate syrup.</p>
    <br>
    <p>
      Read about our 
        <a href="wfrmCopyPasteCoffeeMission.aspx"
          title="Read about our Copy Paste Coffee mission">Mission</a>.<br>
            Read the <a href="CaffeineBuzz.html#hdrCoffee"
              target="_blank"
              title="Read all about caffeine on the Buzz">Caffeine Buzz</a>
      .
    </p>
  </form>
</body>
</html>
