﻿//***
// Action
//   - Demo of a CheckBox
// Created
//   - CopyPaste – 20220921 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220921 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;
using System.Windows;

namespace WPFCheckBox
{

  public partial class wpfExampleCheckBox : Window
  {

    #region "Constructors / Destructors"

    public wpfExampleCheckBox()
    //***
    // Action
    //   - Create an instance of 'wpfExampleCheckBox'
    // Called by
    //   - User action (Starting application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220921 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220921 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfExampleCheckBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void chkVisible_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Depending on the value of chkVisible, is cmdClickMe visible or not
    // Called by
    //   - User action (Clicking a checkbox)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220921 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220921 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if ((bool)chkVisible.IsChecked)
      {
        cmdClickMe.Visibility = Visibility.Visible;
      }
      else
      // Not (bool)chkVisible.IsChecked
      {
        cmdClickMe.Visibility = Visibility.Hidden;
      }
      // (bool)chkVisible.IsChecked

    }
    // chkVisible_Click(System.Object, System.Windows.RoutedEventArgs) Handles chkVisible.Click

    private void cmdClickMe_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Prove that you have clicked on the button
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220921 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220921 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Debug.WriteLine("You have clicked the button");
    }
    // cmdClickMe_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdClickMe.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfExampleCheckBox

}
// WPFCheckBox