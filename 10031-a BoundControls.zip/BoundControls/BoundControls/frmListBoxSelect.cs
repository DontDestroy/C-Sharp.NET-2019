//***
// Action
//   - Bind individual textboxes based on a selected listbox item
// Created
//   - CopyPaste � 20251231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251231 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmListBoxSelect: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.GroupBox grpInfoCustomer;
    internal System.Windows.Forms.TextBox txtFax;
    internal System.Windows.Forms.TextBox txtCompanyName;
    internal System.Windows.Forms.TextBox txtAddress;
    internal System.Windows.Forms.TextBox txtContactTitle;
    internal System.Windows.Forms.TextBox txtIdCustomer;
    internal System.Windows.Forms.TextBox txtContact;
    internal System.Windows.Forms.TextBox txtCountry;
    internal System.Windows.Forms.TextBox txtCity;
    internal System.Windows.Forms.TextBox txtPostalCode;
    internal System.Windows.Forms.TextBox txtRegion;
    internal System.Windows.Forms.TextBox txtPhone;
    internal System.Windows.Forms.Label lblContactTitle;
    internal System.Windows.Forms.Label lblFax;
    internal System.Windows.Forms.Label lblRegion;
    internal System.Windows.Forms.Label lblCountry;
    internal System.Windows.Forms.Label lblPostalCode;
    internal System.Windows.Forms.Label lblCity;
    internal System.Windows.Forms.Label lblAddress;
    internal System.Windows.Forms.Label lblCustomerName;
    internal System.Windows.Forms.Label lblContact;
    internal System.Windows.Forms.Label lblIdCustomer;
    internal System.Windows.Forms.Label lblPhone;
    internal System.Data.SqlClient.SqlDataAdapter dtaCustomer;
    internal System.Data.SqlClient.SqlCommand cmmSelectCustomer;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwindScript2005;
    internal System.Windows.Forms.Button cmdLoadList;
    internal System.Windows.Forms.Label lblCustomer;
    internal System.Data.SqlClient.SqlCommand cmmSelectCustomerInfo;
    internal System.Data.SqlClient.SqlDataAdapter dtaCustomerInfo;
    internal System.Windows.Forms.TextBox txtCustomerLimit;
    internal System.Windows.Forms.ListBox lstCustomer;
    private BoundControls.dsCustomer dsCustomer;
    private BoundControls.dsCustomerInfo dsCustomerInfo;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmListBoxSelect));
      this.grpInfoCustomer = new System.Windows.Forms.GroupBox();
      this.txtFax = new System.Windows.Forms.TextBox();
      this.dsCustomerInfo = new BoundControls.dsCustomerInfo();
      this.txtCompanyName = new System.Windows.Forms.TextBox();
      this.txtAddress = new System.Windows.Forms.TextBox();
      this.txtContactTitle = new System.Windows.Forms.TextBox();
      this.txtIdCustomer = new System.Windows.Forms.TextBox();
      this.txtContact = new System.Windows.Forms.TextBox();
      this.txtCountry = new System.Windows.Forms.TextBox();
      this.txtCity = new System.Windows.Forms.TextBox();
      this.txtPostalCode = new System.Windows.Forms.TextBox();
      this.txtRegion = new System.Windows.Forms.TextBox();
      this.txtPhone = new System.Windows.Forms.TextBox();
      this.lblContactTitle = new System.Windows.Forms.Label();
      this.lblFax = new System.Windows.Forms.Label();
      this.lblRegion = new System.Windows.Forms.Label();
      this.lblCountry = new System.Windows.Forms.Label();
      this.lblPostalCode = new System.Windows.Forms.Label();
      this.lblCity = new System.Windows.Forms.Label();
      this.lblAddress = new System.Windows.Forms.Label();
      this.lblCustomerName = new System.Windows.Forms.Label();
      this.lblContact = new System.Windows.Forms.Label();
      this.lblIdCustomer = new System.Windows.Forms.Label();
      this.lblPhone = new System.Windows.Forms.Label();
      this.dtaCustomer = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectCustomer = new System.Data.SqlClient.SqlCommand();
      this.cnncpNorthwindScript2005 = new System.Data.SqlClient.SqlConnection();
      this.cmdLoadList = new System.Windows.Forms.Button();
      this.lblCustomer = new System.Windows.Forms.Label();
      this.cmmSelectCustomerInfo = new System.Data.SqlClient.SqlCommand();
      this.dtaCustomerInfo = new System.Data.SqlClient.SqlDataAdapter();
      this.txtCustomerLimit = new System.Windows.Forms.TextBox();
      this.lstCustomer = new System.Windows.Forms.ListBox();
      this.dsCustomer = new BoundControls.dsCustomer();
      this.grpInfoCustomer.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomerInfo)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomer)).BeginInit();
      this.SuspendLayout();
      // 
      // grpInfoCustomer
      // 
      this.grpInfoCustomer.Controls.Add(this.txtFax);
      this.grpInfoCustomer.Controls.Add(this.txtCompanyName);
      this.grpInfoCustomer.Controls.Add(this.txtAddress);
      this.grpInfoCustomer.Controls.Add(this.txtContactTitle);
      this.grpInfoCustomer.Controls.Add(this.txtIdCustomer);
      this.grpInfoCustomer.Controls.Add(this.txtContact);
      this.grpInfoCustomer.Controls.Add(this.txtCountry);
      this.grpInfoCustomer.Controls.Add(this.txtCity);
      this.grpInfoCustomer.Controls.Add(this.txtPostalCode);
      this.grpInfoCustomer.Controls.Add(this.txtRegion);
      this.grpInfoCustomer.Controls.Add(this.txtPhone);
      this.grpInfoCustomer.Controls.Add(this.lblContactTitle);
      this.grpInfoCustomer.Controls.Add(this.lblFax);
      this.grpInfoCustomer.Controls.Add(this.lblRegion);
      this.grpInfoCustomer.Controls.Add(this.lblCountry);
      this.grpInfoCustomer.Controls.Add(this.lblPostalCode);
      this.grpInfoCustomer.Controls.Add(this.lblCity);
      this.grpInfoCustomer.Controls.Add(this.lblAddress);
      this.grpInfoCustomer.Controls.Add(this.lblCustomerName);
      this.grpInfoCustomer.Controls.Add(this.lblContact);
      this.grpInfoCustomer.Controls.Add(this.lblIdCustomer);
      this.grpInfoCustomer.Controls.Add(this.lblPhone);
      this.grpInfoCustomer.Location = new System.Drawing.Point(384, 30);
      this.grpInfoCustomer.Name = "grpInfoCustomer";
      this.grpInfoCustomer.Size = new System.Drawing.Size(296, 304);
      this.grpInfoCustomer.TabIndex = 9;
      this.grpInfoCustomer.TabStop = false;
      this.grpInfoCustomer.Text = "Info customer";
      // 
      // txtFax
      // 
      this.txtFax.BackColor = System.Drawing.SystemColors.Control;
      this.txtFax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtFax.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsCustomerInfo, "tblCPCustomer.strFax", true));
      this.txtFax.Enabled = false;
      this.txtFax.Location = new System.Drawing.Point(120, 272);
      this.txtFax.Name = "txtFax";
      this.txtFax.Size = new System.Drawing.Size(160, 20);
      this.txtFax.TabIndex = 21;
      // 
      // dsCustomerInfo
      // 
      this.dsCustomerInfo.DataSetName = "dsCustomerInfo";
      this.dsCustomerInfo.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsCustomerInfo.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // txtCompanyName
      // 
      this.txtCompanyName.BackColor = System.Drawing.SystemColors.Control;
      this.txtCompanyName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCompanyName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsCustomerInfo, "tblCPCustomer.strCompanyName", true));
      this.txtCompanyName.Enabled = false;
      this.txtCompanyName.Location = new System.Drawing.Point(120, 56);
      this.txtCompanyName.Name = "txtCompanyName";
      this.txtCompanyName.Size = new System.Drawing.Size(160, 20);
      this.txtCompanyName.TabIndex = 3;
      // 
      // txtAddress
      // 
      this.txtAddress.BackColor = System.Drawing.SystemColors.Control;
      this.txtAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtAddress.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsCustomerInfo, "tblCPCustomer.strAddress", true));
      this.txtAddress.Enabled = false;
      this.txtAddress.Location = new System.Drawing.Point(120, 128);
      this.txtAddress.Name = "txtAddress";
      this.txtAddress.Size = new System.Drawing.Size(160, 20);
      this.txtAddress.TabIndex = 9;
      // 
      // txtContactTitle
      // 
      this.txtContactTitle.BackColor = System.Drawing.SystemColors.Control;
      this.txtContactTitle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtContactTitle.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsCustomerInfo, "tblCPCustomer.strContactTitle", true));
      this.txtContactTitle.Enabled = false;
      this.txtContactTitle.Location = new System.Drawing.Point(120, 104);
      this.txtContactTitle.Name = "txtContactTitle";
      this.txtContactTitle.Size = new System.Drawing.Size(160, 20);
      this.txtContactTitle.TabIndex = 7;
      // 
      // txtIdCustomer
      // 
      this.txtIdCustomer.BackColor = System.Drawing.SystemColors.Control;
      this.txtIdCustomer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtIdCustomer.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsCustomerInfo, "tblCPCustomer.strIdCustomer", true));
      this.txtIdCustomer.Enabled = false;
      this.txtIdCustomer.Location = new System.Drawing.Point(120, 32);
      this.txtIdCustomer.Name = "txtIdCustomer";
      this.txtIdCustomer.Size = new System.Drawing.Size(160, 20);
      this.txtIdCustomer.TabIndex = 1;
      // 
      // txtContact
      // 
      this.txtContact.BackColor = System.Drawing.SystemColors.Control;
      this.txtContact.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtContact.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsCustomerInfo, "tblCPCustomer.strContactName", true));
      this.txtContact.Enabled = false;
      this.txtContact.Location = new System.Drawing.Point(120, 80);
      this.txtContact.Name = "txtContact";
      this.txtContact.Size = new System.Drawing.Size(160, 20);
      this.txtContact.TabIndex = 5;
      // 
      // txtCountry
      // 
      this.txtCountry.BackColor = System.Drawing.SystemColors.Control;
      this.txtCountry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCountry.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsCustomerInfo, "tblCPCustomer.strCountry", true));
      this.txtCountry.Enabled = false;
      this.txtCountry.Location = new System.Drawing.Point(120, 224);
      this.txtCountry.Name = "txtCountry";
      this.txtCountry.Size = new System.Drawing.Size(160, 20);
      this.txtCountry.TabIndex = 17;
      // 
      // txtCity
      // 
      this.txtCity.BackColor = System.Drawing.SystemColors.Control;
      this.txtCity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtCity.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsCustomerInfo, "tblCPCustomer.strCity", true));
      this.txtCity.Enabled = false;
      this.txtCity.Location = new System.Drawing.Point(120, 152);
      this.txtCity.Name = "txtCity";
      this.txtCity.Size = new System.Drawing.Size(160, 20);
      this.txtCity.TabIndex = 11;
      // 
      // txtPostalCode
      // 
      this.txtPostalCode.BackColor = System.Drawing.SystemColors.Control;
      this.txtPostalCode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtPostalCode.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsCustomerInfo, "tblCPCustomer.strPostalCode", true));
      this.txtPostalCode.Enabled = false;
      this.txtPostalCode.Location = new System.Drawing.Point(120, 200);
      this.txtPostalCode.Name = "txtPostalCode";
      this.txtPostalCode.Size = new System.Drawing.Size(160, 20);
      this.txtPostalCode.TabIndex = 15;
      // 
      // txtRegion
      // 
      this.txtRegion.BackColor = System.Drawing.SystemColors.Control;
      this.txtRegion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtRegion.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsCustomerInfo, "tblCPCustomer.strRegion", true));
      this.txtRegion.Enabled = false;
      this.txtRegion.Location = new System.Drawing.Point(120, 176);
      this.txtRegion.Name = "txtRegion";
      this.txtRegion.Size = new System.Drawing.Size(160, 20);
      this.txtRegion.TabIndex = 13;
      // 
      // txtPhone
      // 
      this.txtPhone.BackColor = System.Drawing.SystemColors.Control;
      this.txtPhone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.txtPhone.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsCustomerInfo, "tblCPCustomer.strPhone", true));
      this.txtPhone.Enabled = false;
      this.txtPhone.Location = new System.Drawing.Point(120, 248);
      this.txtPhone.Name = "txtPhone";
      this.txtPhone.Size = new System.Drawing.Size(160, 20);
      this.txtPhone.TabIndex = 19;
      // 
      // lblContactTitle
      // 
      this.lblContactTitle.Location = new System.Drawing.Point(16, 104);
      this.lblContactTitle.Name = "lblContactTitle";
      this.lblContactTitle.Size = new System.Drawing.Size(88, 16);
      this.lblContactTitle.TabIndex = 6;
      this.lblContactTitle.Text = "Contact Title";
      // 
      // lblFax
      // 
      this.lblFax.Location = new System.Drawing.Point(16, 272);
      this.lblFax.Name = "lblFax";
      this.lblFax.Size = new System.Drawing.Size(88, 16);
      this.lblFax.TabIndex = 20;
      this.lblFax.Text = "Fax";
      // 
      // lblRegion
      // 
      this.lblRegion.Location = new System.Drawing.Point(16, 176);
      this.lblRegion.Name = "lblRegion";
      this.lblRegion.Size = new System.Drawing.Size(88, 16);
      this.lblRegion.TabIndex = 12;
      this.lblRegion.Text = "Region";
      // 
      // lblCountry
      // 
      this.lblCountry.Location = new System.Drawing.Point(16, 224);
      this.lblCountry.Name = "lblCountry";
      this.lblCountry.Size = new System.Drawing.Size(88, 16);
      this.lblCountry.TabIndex = 16;
      this.lblCountry.Text = "Country";
      // 
      // lblPostalCode
      // 
      this.lblPostalCode.Location = new System.Drawing.Point(16, 200);
      this.lblPostalCode.Name = "lblPostalCode";
      this.lblPostalCode.Size = new System.Drawing.Size(88, 16);
      this.lblPostalCode.TabIndex = 14;
      this.lblPostalCode.Text = "Postal Code";
      // 
      // lblCity
      // 
      this.lblCity.Location = new System.Drawing.Point(16, 152);
      this.lblCity.Name = "lblCity";
      this.lblCity.Size = new System.Drawing.Size(88, 16);
      this.lblCity.TabIndex = 10;
      this.lblCity.Text = "City";
      // 
      // lblAddress
      // 
      this.lblAddress.Location = new System.Drawing.Point(16, 128);
      this.lblAddress.Name = "lblAddress";
      this.lblAddress.Size = new System.Drawing.Size(88, 16);
      this.lblAddress.TabIndex = 8;
      this.lblAddress.Text = "Address";
      // 
      // lblCustomerName
      // 
      this.lblCustomerName.Location = new System.Drawing.Point(16, 56);
      this.lblCustomerName.Name = "lblCustomerName";
      this.lblCustomerName.Size = new System.Drawing.Size(88, 16);
      this.lblCustomerName.TabIndex = 2;
      this.lblCustomerName.Text = "Company Name";
      // 
      // lblContact
      // 
      this.lblContact.Location = new System.Drawing.Point(16, 80);
      this.lblContact.Name = "lblContact";
      this.lblContact.Size = new System.Drawing.Size(88, 16);
      this.lblContact.TabIndex = 4;
      this.lblContact.Text = "Contact";
      // 
      // lblIdCustomer
      // 
      this.lblIdCustomer.Location = new System.Drawing.Point(16, 32);
      this.lblIdCustomer.Name = "lblIdCustomer";
      this.lblIdCustomer.Size = new System.Drawing.Size(88, 16);
      this.lblIdCustomer.TabIndex = 0;
      this.lblIdCustomer.Text = "Customer Key";
      // 
      // lblPhone
      // 
      this.lblPhone.Location = new System.Drawing.Point(16, 248);
      this.lblPhone.Name = "lblPhone";
      this.lblPhone.Size = new System.Drawing.Size(88, 16);
      this.lblPhone.TabIndex = 18;
      this.lblPhone.Text = "Phone";
      // 
      // dtaCustomer
      // 
      this.dtaCustomer.SelectCommand = this.cmmSelectCustomer;
      this.dtaCustomer.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCustomer", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("strIdCustomer", "strIdCustomer"),
                        new System.Data.Common.DataColumnMapping("strCompanyName", "strCompanyName")})});
      // 
      // cmmSelectCustomer
      // 
      this.cmmSelectCustomer.CommandText = "SELECT strIdCustomer, strCompanyName FROM tblCPCustomer WHERE (strCompanyName LIK" +
    "E @CompanyStart + \'%\')";
      this.cmmSelectCustomer.Connection = this.cnncpNorthwindScript2005;
      this.cmmSelectCustomer.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@CompanyStart", System.Data.SqlDbType.VarChar, 40, "strCompanyName")});
      // 
      // cnncpNorthwindScript2005
      // 
      this.cnncpNorthwindScript2005.ConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthwindScript2005.FireInfoMessageEventOnUserErrors = false;
      // 
      // cmdLoadList
      // 
      this.cmdLoadList.Location = new System.Drawing.Point(288, 6);
      this.cmdLoadList.Name = "cmdLoadList";
      this.cmdLoadList.Size = new System.Drawing.Size(88, 24);
      this.cmdLoadList.TabIndex = 7;
      this.cmdLoadList.Text = "Load List";
      this.cmdLoadList.Click += new System.EventHandler(this.cmdLoadList_Click);
      // 
      // lblCustomer
      // 
      this.lblCustomer.Location = new System.Drawing.Point(8, 6);
      this.lblCustomer.Name = "lblCustomer";
      this.lblCustomer.Size = new System.Drawing.Size(56, 16);
      this.lblCustomer.TabIndex = 5;
      this.lblCustomer.Text = "Customer";
      // 
      // cmmSelectCustomerInfo
      // 
      this.cmmSelectCustomerInfo.CommandText = resources.GetString("cmmSelectCustomerInfo.CommandText");
      this.cmmSelectCustomerInfo.Connection = this.cnncpNorthwindScript2005;
      this.cmmSelectCustomerInfo.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@KeyCustomer", System.Data.SqlDbType.VarChar, 5, "strIdCustomer")});
      // 
      // dtaCustomerInfo
      // 
      this.dtaCustomerInfo.SelectCommand = this.cmmSelectCustomerInfo;
      this.dtaCustomerInfo.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCustomer", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("strIdCustomer", "strIdCustomer"),
                        new System.Data.Common.DataColumnMapping("strCompanyName", "strCompanyName"),
                        new System.Data.Common.DataColumnMapping("strContactName", "strContactName"),
                        new System.Data.Common.DataColumnMapping("strContactTitle", "strContactTitle"),
                        new System.Data.Common.DataColumnMapping("strAddress", "strAddress"),
                        new System.Data.Common.DataColumnMapping("strCity", "strCity"),
                        new System.Data.Common.DataColumnMapping("strRegion", "strRegion"),
                        new System.Data.Common.DataColumnMapping("strPostalCode", "strPostalCode"),
                        new System.Data.Common.DataColumnMapping("strCountry", "strCountry"),
                        new System.Data.Common.DataColumnMapping("strPhone", "strPhone"),
                        new System.Data.Common.DataColumnMapping("strFax", "strFax")})});
      // 
      // txtCustomerLimit
      // 
      this.txtCustomerLimit.Location = new System.Drawing.Point(72, 6);
      this.txtCustomerLimit.Name = "txtCustomerLimit";
      this.txtCustomerLimit.Size = new System.Drawing.Size(208, 20);
      this.txtCustomerLimit.TabIndex = 6;
      this.txtCustomerLimit.Text = "A";
      // 
      // lstCustomer
      // 
      this.lstCustomer.DataSource = this.dsCustomer;
      this.lstCustomer.DisplayMember = "tblCPCustomer.strCompanyName";
      this.lstCustomer.Location = new System.Drawing.Point(8, 38);
      this.lstCustomer.Name = "lstCustomer";
      this.lstCustomer.Size = new System.Drawing.Size(368, 290);
      this.lstCustomer.TabIndex = 8;
      this.lstCustomer.ValueMember = "tblCPCustomer.strIdCustomer";
      this.lstCustomer.SelectedIndexChanged += new System.EventHandler(this.lstCustomer_SelectedIndexChanged);
      // 
      // dsCustomer
      // 
      this.dsCustomer.DataSetName = "dsCustomer";
      this.dsCustomer.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsCustomer.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // frmListBoxSelect
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(688, 341);
      this.Controls.Add(this.txtCustomerLimit);
      this.Controls.Add(this.lstCustomer);
      this.Controls.Add(this.grpInfoCustomer);
      this.Controls.Add(this.cmdLoadList);
      this.Controls.Add(this.lblCustomer);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmListBoxSelect";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Bind Individual Textboxes Based On a Selected Listbox Item";
      this.Load += new System.EventHandler(this.frmListBoxSelect_Load);
      this.grpInfoCustomer.ResumeLayout(false);
      this.grpInfoCustomer.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomerInfo)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomer)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmListBoxSelect'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmListBoxSelect()
      //***
      // Action
      //   - Create instance of 'frmListBoxSelect'
      // Called by
      //   - frmBoundCountrolsMain.cmdListBoxSelect_Click(System.Object, System.EventArgs) Handles cmdListBoxSelect.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmListBoxSelect()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdLoadList_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the parameter of the select command to the text on the form
      //   - Clear the data set
      //   - Fill the data set using the data adapter
      //   - Show the currently selected record in detail
      // Called by
      //   - User action (Clicking a button)
      //   - frmListBoxSelect_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - RefreshIndividual()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dtaCustomer.SelectCommand.Parameters["@CompanyStart"].Value = txtCustomerLimit.Text;
      dsCustomer.Clear();
      dtaCustomer.Fill(dsCustomer);
      RefreshIndividual();
    }
    // cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click

    private void frmListBoxSelect_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Run the code that is executed when you click the LoadList button 
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click   
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cmdLoadList_Click(new System.Object(), new System.EventArgs());
    }
    // frmListBoxSelect_Load(System.Object, System.EventArgs) Handles this.Load

    private void lstCustomer_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the currently selected record in detail
      // Called by
      //   - User action (Selecting a list item)
      // Calls
      //   - RefreshIndividual()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      RefreshIndividual();
    }
    // lstCustomer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstCustomer.SelectedIndexChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void RefreshIndividual()
      //***
      // Action
      //   - Clear the data set with detailed information
      //   - If an item is selected in the listbox
      //     - Define and set a data row view with the currently selected item
      //     - Set the parameter to the data table select command to select the correct customer
      //     - Fill the data set using the data adapter
      //   - If not
      //     - Do nothing
      // Called by
      //   - cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click
      //   - lstCustomer_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstCustomer.SelectedIndexChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsCustomerInfo.Clear();

      if (lstCustomer.SelectedIndex == -1)
      {
      }
      else
        // lstCustomer.SelectedIndex <> -1
      {
        DataRowView drvCustomer = (DataRowView)lstCustomer.SelectedItem;

        dtaCustomerInfo.SelectCommand.Parameters["@KeyCustomer"].Value = drvCustomer["strIdCustomer"];
        dtaCustomerInfo.Fill(dsCustomerInfo);
      }
      // lstCustomer.SelectedIndex = -1

    }
    // RefreshIndividual()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmListBoxSelect

}
// CopyPaste.Learning