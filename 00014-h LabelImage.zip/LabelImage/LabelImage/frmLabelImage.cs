//***
// Action
//   - Example of pictures in a form
// Created
//   - CopyPaste � 20240214 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240214 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmImage: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdDone;
    internal System.Windows.Forms.Label lblSecond;
    internal System.Windows.Forms.Label lblFirst;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmImage));
      this.cmdDone = new System.Windows.Forms.Button();
      this.lblSecond = new System.Windows.Forms.Label();
      this.lblFirst = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // cmdDone
      // 
      this.cmdDone.Location = new System.Drawing.Point(280, 72);
      this.cmdDone.Name = "cmdDone";
      this.cmdDone.TabIndex = 5;
      this.cmdDone.Text = "Done";
      this.cmdDone.Click += new System.EventHandler(this.cmdDone_Click);
      // 
      // lblSecond
      // 
      this.lblSecond.Location = new System.Drawing.Point(24, 200);
      this.lblSecond.Name = "lblSecond";
      this.lblSecond.Size = new System.Drawing.Size(200, 150);
      this.lblSecond.TabIndex = 4;
      // 
      // lblFirst
      // 
      this.lblFirst.Location = new System.Drawing.Point(24, 30);
      this.lblFirst.Name = "lblFirst";
      this.lblFirst.Size = new System.Drawing.Size(200, 150);
      this.lblFirst.TabIndex = 3;
      // 
      // frmImage
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(408, 381);
      this.Controls.Add(this.cmdDone);
      this.Controls.Add(this.lblSecond);
      this.Controls.Add(this.lblFirst);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmImage";
      this.Text = "Label Image";
      this.Load += new System.EventHandler(this.frmImage_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmImage'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmImage()
      //***
      // Action
      //   - Create instance of 'frmImage'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmImage()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public Image mpicFirst;
    public Image mpicSecond;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdDone_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Stop the application
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();
    }
    // cmdDone_Click(System.Object, System.EventArgs) Handles cmdDone.Click
    
    private void frmImage_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Add 2 pictures into the form
      // Called by
      //   - System action (Form is loaded)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mpicFirst = Image.FromFile("Labrador.jpg");
      mpicSecond = Image.FromFile("Dalmatier.jpg");
      
      lblFirst.Image = mpicFirst;
      lblSecond.Image = mpicSecond;
    }
    // frmImage_Load(System.Object, System.EventArgs) Handles frmImage.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmImage
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240214 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240214 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmImage());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmImage

}
// CopyPaste.Learning