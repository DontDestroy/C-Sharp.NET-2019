﻿//***
// Action
//   - Implementation of a cpTextBySMS
//		 - The way a cell phone camera app shares a photo
// Created
//   - CopyPaste – 20240810 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240810 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Camera.Library
{

	public class cpTextBySMS : cpiShare
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of cpTextBySMS
		/// </summary>
		public cpTextBySMS()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - cpBasicCamera()
		//   - cpSpecialCamera()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240810 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240810 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpTextBySMS()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		/// <summary>
		/// Define how a camera is sharing a photo
		/// </summary>
		public void Share()
		//***
		// Action
		//   - Define how a photo is shared by text message (SMS)
		// Called by
		//   - cpBasicCamera() (indirectly, thru delegate)
		//   - cpSpecialCamera() (indirectly, thru delegate)
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240810 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240810 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Photo is texted by SMS");
		}
		// Share()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpTextBySMS

}
// CopyPaste.Camera.Library