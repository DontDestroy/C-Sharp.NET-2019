//***
// Action
//   - Demo of printing multiple pages
// Created
//   - CopyPaste � 20240527 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240527 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPrintFile: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Drawing.Printing.PrintDocument prtDocument;
    internal System.Windows.Forms.RichTextBox rtxtText;
    internal System.Windows.Forms.PrintDialog dlgPrint;
    internal System.Windows.Forms.OpenFileDialog dlgFileOpen;
    internal System.Windows.Forms.Button cmdPrint;
    internal System.Windows.Forms.Button cmdOpen;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPrintFile));
      this.prtDocument = new System.Drawing.Printing.PrintDocument();
      this.rtxtText = new System.Windows.Forms.RichTextBox();
      this.dlgPrint = new System.Windows.Forms.PrintDialog();
      this.dlgFileOpen = new System.Windows.Forms.OpenFileDialog();
      this.cmdPrint = new System.Windows.Forms.Button();
      this.cmdOpen = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // prtDocument
      // 
      this.prtDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.prtDocument_PrintPage);
      // 
      // rtxtText
      // 
      this.rtxtText.Location = new System.Drawing.Point(8, 98);
      this.rtxtText.Name = "rtxtText";
      this.rtxtText.Size = new System.Drawing.Size(312, 160);
      this.rtxtText.TabIndex = 5;
      this.rtxtText.Text = "";
      // 
      // cmdPrint
      // 
      this.cmdPrint.Enabled = false;
      this.cmdPrint.Location = new System.Drawing.Point(24, 50);
      this.cmdPrint.Name = "cmdPrint";
      this.cmdPrint.Size = new System.Drawing.Size(88, 24);
      this.cmdPrint.TabIndex = 4;
      this.cmdPrint.Text = "&Print";
      this.cmdPrint.Click += new System.EventHandler(this.cmdPrint_Click);
      // 
      // cmdOpen
      // 
      this.cmdOpen.Location = new System.Drawing.Point(24, 10);
      this.cmdOpen.Name = "cmdOpen";
      this.cmdOpen.Size = new System.Drawing.Size(88, 24);
      this.cmdOpen.TabIndex = 3;
      this.cmdOpen.Text = "&Open";
      this.cmdOpen.Click += new System.EventHandler(this.cmdOpen_Click);
      // 
      // frmPrintFile
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(328, 269);
      this.Controls.Add(this.rtxtText);
      this.Controls.Add(this.cmdPrint);
      this.Controls.Add(this.cmdOpen);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPrintFile";
      this.Text = "Print File";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPrintFile'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPrintFile()
      //***
      // Action
      //   - Create instance of 'frmPrintFile'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      mthePrintFont = new Font("Arial", 10);
      mthePrintPageSettings = new PageSettings();
    }
    // frmPrintFile()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrToPrint;
    private Font mthePrintFont;
    private PageSettings mthePrintPageSettings;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdOpen_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Initialize the file open dialog
      //     - Textfiles
      //     - Current directory
      //   - Show the file open dialog
      //   - If there is a filename
      //     - Try
      //       - Define a file stream with the choosen file
      //       - Load the file into the rich text box
      //       - Close the file
      //       - Take the text of the rich text box and place it in mstrToPrint
      //       - Enable the print button
      //     - When there is an error
      //       - Show the corresponding error message
      //   - If not
      //     - Nothing happens
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strFilePath;

      dlgFileOpen.Filter = "Text files (*.txt)|*.txt";
      dlgFileOpen.InitialDirectory = Environment.CurrentDirectory;
      dlgFileOpen.ShowDialog();

      if (dlgFileOpen.FileName == "")
      {
      }
      else
        // dlgFileOpen.FileName <> ""
      {
        strFilePath = dlgFileOpen.FileName;

        try
        {
          FileStream theFileStream = new FileStream(strFilePath, FileMode.Open);

          rtxtText.LoadFile(theFileStream, RichTextBoxStreamType.PlainText);
          theFileStream.Close();
          mstrToPrint = rtxtText.Text;
          cmdPrint.Enabled = true;
        }
        catch (Exception theException)
        {
          MessageBox.Show(theException.Message);
        }
        finally
        {
        }

      }
      // dlgFileOpen.FileName = ""

    }
    // cmdOpen_Click(System.Object, System.EventArgs) Handles cmdOpen.Click

    private void cmdPrint_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try
      //     - Initialize the values of the print document
      //     - Show the print dialog
      //     - If button OK is clicked
      //       - Print the document
      //     - If not
      //       - Nothing happens
      //   - When there is an error
      //     - Show the corresponding error message
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      try
      {
        DialogResult shtResult; 

        prtDocument.DefaultPageSettings = mthePrintPageSettings;
        mstrToPrint = rtxtText.Text;
        dlgPrint.Document = prtDocument;

        shtResult = dlgPrint.ShowDialog();

        if (shtResult == DialogResult.OK)
        {
          prtDocument.Print();
        }
        else
          // shtResult <> DialogResult.OK
        {
        }
        // shtResult = DialogResult.OK

      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
      }
    
    }
    // cmdPrint_Click(System.Object, System.EventArgs) Handles cmdPrint.Click

    private void prtDocument_PrintPage(System.Object theSender, PrintPageEventArgs thePrintPageEventArguments)
      //***
      // Action
      //   - Define a rectangle where the margins of your page are
      //   - Define a size where your place is to print on the page
      //   - Calculate the length of the string using MeasureString
      //   - Take the part that an be printed
      //   - Draw that part on the graphics
      //   - Check if all is printed
      //     - Set HasMorePages to false
      //     - mstrToPrint becomes the text (for the next time you want to print)
      //   - If Not
      //     - Take the rest of the text that must be printed
      //     - Set HasMorePages to true
      // Called by
      //   - System action (Printing a page)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      int lngNumChars;
      int lngNumLines;
      string strForPage;
      StringFormat theFormat = new StringFormat();

      RectangleF theRectDraw = new RectangleF(
        thePrintPageEventArguments.MarginBounds.Left, 
        thePrintPageEventArguments.MarginBounds.Top,
        thePrintPageEventArguments.MarginBounds.Width,
        thePrintPageEventArguments.MarginBounds.Height);
      SizeF theSizeMeasure = new SizeF(
        thePrintPageEventArguments.MarginBounds.Width, 
        thePrintPageEventArguments.MarginBounds.Height - mthePrintFont.GetHeight(thePrintPageEventArguments.Graphics));

      theFormat.Trimming = StringTrimming.Word;
      thePrintPageEventArguments.Graphics.MeasureString(mstrToPrint, mthePrintFont, theSizeMeasure, theFormat, out lngNumChars, out lngNumLines);
      strForPage = mstrToPrint.Substring(0, lngNumChars);
      thePrintPageEventArguments.Graphics.DrawString(strForPage, mthePrintFont, Brushes.Black, theRectDraw, theFormat);

      if (lngNumChars < mstrToPrint.Length)
      {
        mstrToPrint = mstrToPrint.Substring(lngNumChars);
        thePrintPageEventArguments.HasMorePages = true;
      }
      else
        // lngNumChars >= mstrToPrint.Length
      {
        thePrintPageEventArguments.HasMorePages = false;
        mstrToPrint = rtxtText.Text;
      }
      // lngNumChars < mstrToPrint.Length
    
    }
    // prtDocument_PrintPage(System.Object, System.Drawing.Printing.PrintPageEventArgs) Handles prtDocument.PrintPage

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [STAThreadAttribute]
    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPrintFile
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmPrintFile()
      // Created
      //   - CopyPaste � 20240527 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240527 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPrintFile());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPrintFile

}
// CopyPaste.Learning