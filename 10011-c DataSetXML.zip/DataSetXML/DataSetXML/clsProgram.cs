﻿//***
// Action
//   - Show the data set using XML
// Created
//   - CopyPaste – 20251127 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251127 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Try to
      //     - Define a connection string
      //     - Create a connection
      //     - Define a new data set
      //     - Open a connection
      //     - Set a command string
      //     - Define a data adapter
      //     - Fill the data set
      //     - Get the XML of the data set
      //     - Write the XML to the console
      //   - On an error
      //     - Show the error information
      //   - Wait for user action
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20251127 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251127 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        string strConnection = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integrated Security=True";
        SqlConnection theConnection = new SqlConnection(strConnection);
        DataSet theDataSet = new DataSet();

        theConnection.Open();
        
        string strCommand = "SELECT * From tblCPCustomer Where strCompanyName Like '%Restau%'";
        SqlDataAdapter theDataAdapter = new SqlDataAdapter(strCommand, theConnection);
        theDataAdapter.Fill(theDataSet);
        
        string strXMLContent = theDataSet.GetXml();
        
        Console.WriteLine(strXMLContent);
      }
      catch (Exception theException)
      {
        Console.WriteLine("Exception: " + theException.Message);
        Console.WriteLine(theException.ToString());
      }
      finally
      {
        Console.ReadLine();
      }

    }
    // Main()

		#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning