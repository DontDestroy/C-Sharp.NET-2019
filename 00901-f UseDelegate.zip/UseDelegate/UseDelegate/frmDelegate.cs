//***
// Action
//   - Set a few buttons to setup the execution using delegates
//   - One button to execute
// Created
//   - CopyPaste � 20250714 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20070328 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDelegate: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdGreet;
    internal System.Windows.Forms.Button cmdEveningSpanish;
    internal System.Windows.Forms.Button cmdAfternoonSpanish;
    internal System.Windows.Forms.Button cmdMorningSpanish;
    internal System.Windows.Forms.Button cmdEveningEnglish;
    internal System.Windows.Forms.Button cmdAfternoonEnglish;
    internal System.Windows.Forms.Button cmdMorningEnglish;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmDelegate));
      this.cmdGreet = new System.Windows.Forms.Button();
      this.cmdEveningSpanish = new System.Windows.Forms.Button();
      this.cmdAfternoonSpanish = new System.Windows.Forms.Button();
      this.cmdMorningSpanish = new System.Windows.Forms.Button();
      this.cmdEveningEnglish = new System.Windows.Forms.Button();
      this.cmdAfternoonEnglish = new System.Windows.Forms.Button();
      this.cmdMorningEnglish = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdGreet
      // 
      this.cmdGreet.Location = new System.Drawing.Point(120, 168);
      this.cmdGreet.Name = "cmdGreet";
      this.cmdGreet.TabIndex = 13;
      this.cmdGreet.Text = "Greet User";
      this.cmdGreet.Click += new System.EventHandler(this.cmdGreet_Click);
      // 
      // cmdEveningSpanish
      // 
      this.cmdEveningSpanish.Location = new System.Drawing.Point(168, 120);
      this.cmdEveningSpanish.Name = "cmdEveningSpanish";
      this.cmdEveningSpanish.Size = new System.Drawing.Size(120, 25);
      this.cmdEveningSpanish.TabIndex = 12;
      this.cmdEveningSpanish.Text = "Evening Spanish";
      this.cmdEveningSpanish.Click += new System.EventHandler(this.cmdEveningSpanish_Click);
      // 
      // cmdAfternoonSpanish
      // 
      this.cmdAfternoonSpanish.Location = new System.Drawing.Point(168, 72);
      this.cmdAfternoonSpanish.Name = "cmdAfternoonSpanish";
      this.cmdAfternoonSpanish.Size = new System.Drawing.Size(120, 25);
      this.cmdAfternoonSpanish.TabIndex = 11;
      this.cmdAfternoonSpanish.Text = "Afternoon Spanish";
      this.cmdAfternoonSpanish.Click += new System.EventHandler(this.cmdAfternoonSpanish_Click);
      // 
      // cmdMorningSpanish
      // 
      this.cmdMorningSpanish.Location = new System.Drawing.Point(168, 24);
      this.cmdMorningSpanish.Name = "cmdMorningSpanish";
      this.cmdMorningSpanish.Size = new System.Drawing.Size(120, 25);
      this.cmdMorningSpanish.TabIndex = 10;
      this.cmdMorningSpanish.Text = "Morning Spanish";
      this.cmdMorningSpanish.Click += new System.EventHandler(this.cmdMorningSpanish_Click);
      // 
      // cmdEveningEnglish
      // 
      this.cmdEveningEnglish.Location = new System.Drawing.Point(40, 120);
      this.cmdEveningEnglish.Name = "cmdEveningEnglish";
      this.cmdEveningEnglish.Size = new System.Drawing.Size(120, 25);
      this.cmdEveningEnglish.TabIndex = 9;
      this.cmdEveningEnglish.Text = "Evening English";
      this.cmdEveningEnglish.Click += new System.EventHandler(this.cmdEveningEnglish_Click);
      // 
      // cmdAfternoonEnglish
      // 
      this.cmdAfternoonEnglish.Location = new System.Drawing.Point(40, 72);
      this.cmdAfternoonEnglish.Name = "cmdAfternoonEnglish";
      this.cmdAfternoonEnglish.Size = new System.Drawing.Size(120, 25);
      this.cmdAfternoonEnglish.TabIndex = 8;
      this.cmdAfternoonEnglish.Text = "Afternoon English";
      this.cmdAfternoonEnglish.Click += new System.EventHandler(this.cmdAfternoonEnglish_Click);
      // 
      // cmdMorningEnglish
      // 
      this.cmdMorningEnglish.Location = new System.Drawing.Point(40, 24);
      this.cmdMorningEnglish.Name = "cmdMorningEnglish";
      this.cmdMorningEnglish.Size = new System.Drawing.Size(120, 25);
      this.cmdMorningEnglish.TabIndex = 7;
      this.cmdMorningEnglish.Text = "Morning English";
      this.cmdMorningEnglish.Click += new System.EventHandler(this.cmdMorningEnglish_Click);
      // 
      // frmDelegate
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(328, 229);
      this.Controls.Add(this.cmdGreet);
      this.Controls.Add(this.cmdEveningSpanish);
      this.Controls.Add(this.cmdAfternoonSpanish);
      this.Controls.Add(this.cmdMorningSpanish);
      this.Controls.Add(this.cmdEveningEnglish);
      this.Controls.Add(this.cmdAfternoonEnglish);
      this.Controls.Add(this.cmdMorningEnglish);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDelegate";
      this.Text = "Use Delegate";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDelegate'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDelegate()
      //***
      // Action
      //   - Create instance of 'frmDelegate'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmDelegate()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private GreetingMethod mtheGreeting = new GreetingMethod(MorningEnglish);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdAfternoonEnglish_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Assign AfternoonEnglish to the delegate
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - AfternoonEnglish()
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheGreeting = new GreetingMethod(AfternoonEnglish);
    }
    // cmdAfternoonEnglish_Click(System.Object, System.EventArgs) Handles cmdAfternoonEnglish.Click

    private void cmdAfternoonSpanish_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Assign AfternoonSpanish to the delegate
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - AfternoonSpanish()
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheGreeting = new GreetingMethod(AfternoonSpanish);
    }
    // cmdAfternoonSpanish_Click(System.Object, System.EventArgs) Handles cmdAfternoonSpanish.Click
    
    private void cmdEveningEnglish_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Assign EveningEnglish to the delegate
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - EveningEnglish()
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheGreeting = new GreetingMethod(EveningEnglish);
    }
    // cmdEveningEnglish_Click(System.Object, System.EventArgs) Handles cmdEveningEnglish.Click

    private void cmdEveningSpanish_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Assign EveningSpanish to the delegate
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - EveningSpanish()
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheGreeting = new GreetingMethod(EveningSpanish);
    }
    // cmdEveningSpanish_Click(System.Object, System.EventArgs) Handles cmdEveningSpanish.Click

    private void cmdGreet_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Execute the delegate
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - AfternoonEnglish()
      //   - AfternoonSpanish()
      //   - EveningEnglish()
      //   - EveningSpanish()
      //   - MorningEnglish()
      //   - MorningSpanish()
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheGreeting();
    }
    // cmdGreet_Click(System.Object, System.EventArgs) Handles cmdGreet.Click

    private void cmdMorningEnglish_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Assign MorningEnglish to the delegate
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - MorningEnglish()
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheGreeting = new GreetingMethod(MorningEnglish);
    }
    // cmdMorningEnglish_Click(System.Object, System.EventArgs) Handles cmdMorningEnglish.Click

    private void cmdMorningSpanish_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Assign MorningSpanish to the delegate
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - MorningSpanish()
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheGreeting = new GreetingMethod(MorningSpanish);
    }
    // cmdMorningSpanish_Click(System.Object, System.EventArgs) Handles cmdMorningSpanish.Click

    #endregion

    #region "Functionality"

    #region "Event"

    public delegate void GreetingMethod();

    #endregion

    #region "Sub / Function"

    private static void AfternoonEnglish()
      //***
      // Action
      //   - Show good afternoon in English
      // Called by
      //   - cmdAfternoonEnglish_Click(System.Object, System.EventArgs) Handles cmdAfternoonEnglish.Click
      //   - cmdGreet_Click(System.Object, System.EventArgs) Handles cmdGreet.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show("Good afternoon");
    }
    // AfternoonEnglish()

    private static void AfternoonSpanish()
      //***
      // Action
      //   - Show good Afternoon in Spanish
      // Called by
      //   - cmdAfternoonSpanish_Click(System.Object, System.EventArgs) Handles cmdAfternoonSpanish.Click
      //   - cmdGreet_Click(System.Object, System.EventArgs) Handles cmdGreet.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show("Buenos tardes");
    }
    // AfternoonSpanish()

    private static void EveningEnglish()
      //***
      // Action
      //   - Show good evening in English
      // Called by
      //   - cmdEveningEnglish_Click(System.Object, System.EventArgs) Handles cmdEveningEnglish.Click
      //   - cmdGreet_Click(System.Object, System.EventArgs) Handles cmdGreet.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show("Good evening");
    }
    // EveningEnglish()

    private static void EveningSpanish()
      //***
      // Action
      //   - Show good evening in Spanish
      // Called by
      //   - cmdEveningSpanish_Click(System.Object, System.EventArgs) Handles cmdEveningSpanish.Click
      //   - cmdGreet_Click(System.Object, System.EventArgs) Handles cmdGreet.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show("Buenos noches");
    }
    // EveningSpanish()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmDelegate
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmDelegate()
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmDelegate());
    }
    // Main() 
    
    private static void MorningEnglish()
      //***
      // Action
      //   - Show good morning in English
      // Called by
      //   - cmdGreet_Click(System.Object, System.EventArgs) Handles cmdGreet.Click
      //   - cmdMorningEnglish_Click(System.Object, System.EventArgs) Handles cmdMorningEnglish.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show("Good morning");
    }
    // MorningEnglish()

    private static void MorningSpanish()
      //***
      // Action
      //   - Show good morning in Spanish
      // Called by
      //   - cmdGreet_Click(System.Object, System.EventArgs) Handles cmdGreet.Click
      //   - cmdMorningSpanish_Click(System.Object, System.EventArgs) Handles cmdMorningSpanish.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20070328 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20070328 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      MessageBox.Show("Buenas dias");
    }
    // MorningSpanish()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDelegate

}
// CopyPaste.Learning