using System;

namespace SimpleProjectWithCode
{

  public class cpProgram
	{

		public static void Main()
		{
      Console.WriteLine("Hit any key to stop the program ...");
      Console.ReadLine();
		}
    // Main()

	}
  // cpProgram

}
// SimpleProjectWithCode