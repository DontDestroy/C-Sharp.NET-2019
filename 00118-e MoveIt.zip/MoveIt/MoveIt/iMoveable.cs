//***
// Action
//   - Definition of a cpiMoveable
//   - How to move a pawn (a piece of a game)
// Created
//   - CopyPaste � 20240313 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240313 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Games
{

  public enum cpDirection
  {
    Up,
    Down,
    Left,
    Right
  }
  // cpDirection

  public interface cpiMoveable
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    //bool Captured
    //{
    //  get;
    //  set;
    //}

    int X
    {
      get;
      set;
    }

    int Y
    {
      get;
      set;
    }

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    void Move(cpDirection thecpDirection, int lngHowFar);

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpiMoveable

}
// CopyPaste.Games