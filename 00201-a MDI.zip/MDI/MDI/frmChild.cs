//***
// Action
//   - Child window in the MDI application
// Created
//   - CopyPaste � 20250707 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250707 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmChild: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtToDo;

    private void InitializeComponent()
    {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmChild));
			this.txtToDo = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// txtToDo
			// 
			this.txtToDo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.txtToDo.Location = new System.Drawing.Point(6, 6);
			this.txtToDo.Multiline = true;
			this.txtToDo.Name = "txtToDo";
			this.txtToDo.Size = new System.Drawing.Size(281, 96);
			this.txtToDo.TabIndex = 1;
			this.txtToDo.TextChanged += new System.EventHandler(this.txtToDo_TextChanged);
			// 
			// frmChild
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 109);
			this.Controls.Add(this.txtToDo);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmChild";
			this.Text = "Todo";
			this.ResumeLayout(false);
			this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmChild'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmChild()
      //***
      // Action
      //   - Create instance of 'frmChild'
      // Called by
      //   - 
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmChild()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void txtToDo_TextChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If there is text
      //     - First line of the text becomes the title of the child window
      //   - If not
      //     - Title of the child window become the text Todo
      //   - The master window gets the title of the active child window
      // Called by
      //   - User action (Changing a textbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250707 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250707 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (txtToDo.Lines.Length > 0)
      {
        this.Text = txtToDo.Lines[0];
      }
      else
        // txtToDo.Lines.Length <= 0
      {
        this.Text = "Todo";
      }
      // txtToDo.Lines.Length > 0

      this.MdiParent.Text = "Todo items - " + this.Text;
    }
    // txtToDo_TextChanged(System.Object, System.EventArgs) Handles txtToDo.TextChanged

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmChild

}
// CopyPaste.Learning