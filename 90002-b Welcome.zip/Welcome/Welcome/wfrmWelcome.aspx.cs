﻿//***
// Action
//   - Showing a welcome screen started from HTML page
// Created
//   - CopyPaste – 20260414 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260414 – VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CopyPaste.Learning
{

  public partial class wfrmWelcome : System.Web.UI.Page
  {

    #region Web Form Designer generated code

    private void InitializeComponent()
    {
      this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
      this.Load += new System.EventHandler(this.Page_Load);

    }

    #endregion

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override protected void OnInit(System.EventArgs theEventArguments)
    //***
    // Action
    //   - Initalize the page
    // Called by
    //   - User action (Starting the page)
    // Calls
    //   - InitializeComponent()
    // Created
    //   - CopyPaste – 20260414 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260414 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***    
    {
      InitializeComponent();
      base.OnInit(theEventArguments);
    }
    // OnInit(System.EventArgs)

    #endregion

    #region "Controls"

    private void cmdOK_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Change the label of the form
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260414 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260414 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      lblWelcome.Text = "Welcome, " + txtName.Text;
    }
    // cmdOK_Click(System.Object, System.EventArgs) Handles cmdStart.Click

    private void Page_Load(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Set the culture info of a certain page into the user language of the request
    //   - Set that information in the today label as text
    //   - Set that user language in the info label as text
    //   - If the form is a postback (recalled)
    //     - Do nothing
    //   - If not
    //     - Set the text box text to the given name of the request
    // Called by
    //   - User action (Starting the page)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260414 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260414 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      System.Threading.Thread.CurrentThread.CurrentCulture = new CultureInfo(Request.UserLanguages[0]);

      lblToday.Text = DateTime.Today.ToLongDateString();
      lblInfo.Text = Request.UserLanguages[0];

      if (IsPostBack || Request.Form["name"] == null)
      {
        txtName.Text = "Page not correctly loaded";
      }
      else
      // Not IsPostBack 
      {
        txtName.Text = Request.Form["name"];
      }
      // IsPostBack 

    }
    // Page_Load(System.Object, System.EventArgs)

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wfrmWelcome

}
// CopyPaste.Learning