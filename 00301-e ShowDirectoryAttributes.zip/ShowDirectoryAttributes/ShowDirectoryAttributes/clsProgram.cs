//***
// Action
//   - Show attributes of a directory
// Created
//   - CopyPaste � 20240719 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240719 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - If "C:\Windows\Temp" exists
      //     - Show the information about this directory
      //   - If not
      //     - Show error message
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240719 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240719 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (Directory.Exists("C:\\WINDOWS\\Temp"))
      {
        DirectoryInfo theDirectory = new DirectoryInfo("C:\\WINDOWS\\Temp");
        string strDirectory = theDirectory.FullName;

        Console.WriteLine("Full name: {0}", theDirectory.FullName);
        Console.WriteLine("Creation time: {0}", theDirectory.CreationTime);
        Console.WriteLine("Last access time: {0}", theDirectory.LastAccessTime);
        Console.WriteLine("Last write time: {0}", theDirectory.LastWriteTime);

        // Alternative way
        Console.WriteLine("Creation time: {0}", Directory.GetCreationTime(strDirectory));
        Console.WriteLine("Last access time: {0}", Directory.GetLastAccessTime(strDirectory));
        Console.WriteLine("Last write time: {0}", Directory.GetLastWriteTime(strDirectory));
      }
      else
        // Not Directory.Exists("C:\WINDOWS\Temp")
      {
        Console.WriteLine("C:\\WINDOWS\\Temp does not exist");
      }
      // Directory.Exists("C:\WINDOWS\Temp")

      Console.ReadLine();
    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning