//***
// Action
//   - Example of a procedure that can be called from another place
// Created
//   - CopyPaste � 20220207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220207 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace Message
{

  public class cpOtherMessage
	{

    public void ShowOtherMessage()
    //***
    // Action
    //   - Show another message
    // Called by
    //   - cpMessage.Main()
    // Calls
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220207 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220207 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      MessageBox.Show("This is an example of a subroutine of another class");
      Console.WriteLine("This is an example of a subroutine of another class");
    }
    // ShowOtherMessage()

  }
  // cpOtherMessage

}
// Message