//***
// Action
//   - A pet shop, the form and the definitions of an animal (base class)
//   - Working with properties (Get and Set) and methods in several classes, that can be reused
//   - This is not fully documented, because it becomes very big and unclear
//   - This is not an optimal solution, but is used to explain things (everything is in the same file)
//   - The only purpose is explain that is can be used in this way
// Created
//   - CopyPaste � 20220304 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW
// Tested
//   - CopyPaste � 20220304 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.PetShop
{

  public class frmPetShop : System.Windows.Forms.Form
  {
    #region Windows Form Designer generated code

    internal System.Windows.Forms.Label lblColor;
    internal System.Windows.Forms.Label lblCost;
    internal System.Windows.Forms.Label lblGender;
    internal System.Windows.Forms.Label lblSpecies;
    internal System.Windows.Forms.Label lblLeg;
    internal System.Windows.Forms.Label lblName;
    internal System.Windows.Forms.Button cmdPlay;
    internal System.Windows.Forms.TextBox txtName;
    internal System.Windows.Forms.TextBox txtCost;
    internal System.Windows.Forms.TextBox txtLeg;
    internal System.Windows.Forms.TextBox txtGender;
    internal System.Windows.Forms.TextBox txtBreed;
    internal System.Windows.Forms.Label lblBreed;
    internal System.Windows.Forms.TextBox txtSpecies;
    internal System.Windows.Forms.TextBox txtColor;
    internal System.Windows.Forms.Button cmdSpeak;
    internal System.Windows.Forms.Label lblAnimalList;
    internal System.Windows.Forms.ListBox lstAnimal;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPetShop));
      this.lblColor = new System.Windows.Forms.Label();
      this.lblCost = new System.Windows.Forms.Label();
      this.lblGender = new System.Windows.Forms.Label();
      this.lblSpecies = new System.Windows.Forms.Label();
      this.lblLeg = new System.Windows.Forms.Label();
      this.lblName = new System.Windows.Forms.Label();
      this.cmdPlay = new System.Windows.Forms.Button();
      this.txtName = new System.Windows.Forms.TextBox();
      this.txtCost = new System.Windows.Forms.TextBox();
      this.txtLeg = new System.Windows.Forms.TextBox();
      this.txtGender = new System.Windows.Forms.TextBox();
      this.txtBreed = new System.Windows.Forms.TextBox();
      this.lblBreed = new System.Windows.Forms.Label();
      this.txtSpecies = new System.Windows.Forms.TextBox();
      this.txtColor = new System.Windows.Forms.TextBox();
      this.cmdSpeak = new System.Windows.Forms.Button();
      this.lblAnimalList = new System.Windows.Forms.Label();
      this.lstAnimal = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // lblColor
      // 
      this.lblColor.Location = new System.Drawing.Point(200, 152);
      this.lblColor.Name = "lblColor";
      this.lblColor.Size = new System.Drawing.Size(56, 16);
      this.lblColor.TabIndex = 36;
      this.lblColor.Text = "Colors:";
      // 
      // lblCost
      // 
      this.lblCost.Location = new System.Drawing.Point(200, 216);
      this.lblCost.Name = "lblCost";
      this.lblCost.Size = new System.Drawing.Size(56, 16);
      this.lblCost.TabIndex = 35;
      this.lblCost.Text = "Cost:";
      // 
      // lblGender
      // 
      this.lblGender.Location = new System.Drawing.Point(200, 120);
      this.lblGender.Name = "lblGender";
      this.lblGender.Size = new System.Drawing.Size(56, 16);
      this.lblGender.TabIndex = 34;
      this.lblGender.Text = "Gender:";
      // 
      // lblSpecies
      // 
      this.lblSpecies.Location = new System.Drawing.Point(200, 56);
      this.lblSpecies.Name = "lblSpecies";
      this.lblSpecies.Size = new System.Drawing.Size(56, 16);
      this.lblSpecies.TabIndex = 33;
      this.lblSpecies.Text = "Species:";
      // 
      // lblLeg
      // 
      this.lblLeg.Location = new System.Drawing.Point(200, 184);
      this.lblLeg.Name = "lblLeg";
      this.lblLeg.Size = new System.Drawing.Size(56, 16);
      this.lblLeg.TabIndex = 32;
      this.lblLeg.Text = "Legs:";
      // 
      // lblName
      // 
      this.lblName.Location = new System.Drawing.Point(200, 24);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(56, 16);
      this.lblName.TabIndex = 31;
      this.lblName.Text = "Name:";
      // 
      // cmdPlay
      // 
      this.cmdPlay.Location = new System.Drawing.Point(288, 288);
      this.cmdPlay.Name = "cmdPlay";
      this.cmdPlay.Size = new System.Drawing.Size(104, 32);
      this.cmdPlay.TabIndex = 30;
      this.cmdPlay.Text = "Play";
      this.cmdPlay.Click += new System.EventHandler(this.cmdPlay_Click);
      // 
      // txtName
      // 
      this.txtName.Location = new System.Drawing.Point(264, 24);
      this.txtName.Name = "txtName";
      this.txtName.Size = new System.Drawing.Size(176, 20);
      this.txtName.TabIndex = 29;
      this.txtName.Text = "";
      // 
      // txtCost
      // 
      this.txtCost.Location = new System.Drawing.Point(264, 216);
      this.txtCost.Name = "txtCost";
      this.txtCost.Size = new System.Drawing.Size(176, 20);
      this.txtCost.TabIndex = 28;
      this.txtCost.Text = "";
      // 
      // txtLeg
      // 
      this.txtLeg.Location = new System.Drawing.Point(264, 184);
      this.txtLeg.Name = "txtLeg";
      this.txtLeg.Size = new System.Drawing.Size(176, 20);
      this.txtLeg.TabIndex = 27;
      this.txtLeg.Text = "";
      // 
      // txtGender
      // 
      this.txtGender.Location = new System.Drawing.Point(264, 120);
      this.txtGender.Name = "txtGender";
      this.txtGender.Size = new System.Drawing.Size(176, 20);
      this.txtGender.TabIndex = 26;
      this.txtGender.Text = "";
      // 
      // txtBreed
      // 
      this.txtBreed.Location = new System.Drawing.Point(264, 88);
      this.txtBreed.Name = "txtBreed";
      this.txtBreed.Size = new System.Drawing.Size(176, 20);
      this.txtBreed.TabIndex = 25;
      this.txtBreed.Text = "";
      // 
      // lblBreed
      // 
      this.lblBreed.Location = new System.Drawing.Point(200, 88);
      this.lblBreed.Name = "lblBreed";
      this.lblBreed.Size = new System.Drawing.Size(56, 16);
      this.lblBreed.TabIndex = 24;
      this.lblBreed.Text = "Breed:";
      // 
      // txtSpecies
      // 
      this.txtSpecies.Location = new System.Drawing.Point(264, 56);
      this.txtSpecies.Name = "txtSpecies";
      this.txtSpecies.Size = new System.Drawing.Size(176, 20);
      this.txtSpecies.TabIndex = 23;
      this.txtSpecies.Text = "";
      // 
      // txtColor
      // 
      this.txtColor.Location = new System.Drawing.Point(264, 152);
      this.txtColor.Name = "txtColor";
      this.txtColor.Size = new System.Drawing.Size(176, 20);
      this.txtColor.TabIndex = 22;
      this.txtColor.Text = "";
      // 
      // cmdSpeak
      // 
      this.cmdSpeak.Location = new System.Drawing.Point(56, 288);
      this.cmdSpeak.Name = "cmdSpeak";
      this.cmdSpeak.Size = new System.Drawing.Size(104, 32);
      this.cmdSpeak.TabIndex = 21;
      this.cmdSpeak.Text = "Speak";
      this.cmdSpeak.Click += new System.EventHandler(this.cmdSpeak_Click);
      // 
      // lblAnimalList
      // 
      this.lblAnimalList.Location = new System.Drawing.Point(8, 8);
      this.lblAnimalList.Name = "lblAnimalList";
      this.lblAnimalList.Size = new System.Drawing.Size(144, 16);
      this.lblAnimalList.TabIndex = 20;
      this.lblAnimalList.Text = "List of animals:";
      // 
      // lstAnimal
      // 
      this.lstAnimal.Location = new System.Drawing.Point(8, 24);
      this.lstAnimal.Name = "lstAnimal";
      this.lstAnimal.Size = new System.Drawing.Size(168, 212);
      this.lstAnimal.TabIndex = 19;
      this.lstAnimal.SelectedIndexChanged += new System.EventHandler(this.lstAnimal_SelectedIndexChanged);
      // 
      // frmPetShop
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(448, 365);
      this.Controls.Add(this.lblColor);
      this.Controls.Add(this.lblCost);
      this.Controls.Add(this.lblGender);
      this.Controls.Add(this.lblSpecies);
      this.Controls.Add(this.lblLeg);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.cmdPlay);
      this.Controls.Add(this.txtName);
      this.Controls.Add(this.txtCost);
      this.Controls.Add(this.txtLeg);
      this.Controls.Add(this.txtGender);
      this.Controls.Add(this.txtBreed);
      this.Controls.Add(this.txtSpecies);
      this.Controls.Add(this.txtColor);
      this.Controls.Add(this.lblBreed);
      this.Controls.Add(this.cmdSpeak);
      this.Controls.Add(this.lblAnimalList);
      this.Controls.Add(this.lstAnimal);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPetShop";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Pet Shop";
      this.Load += new System.EventHandler(this.frmPetShop_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPetShop'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220304 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220304 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPetShop()
      //***
      // Action
      //   - Create instance of 'frmPetShop'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220304 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220304 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPetShop()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    Animal[] arrPets = new Animal[9];
    int intCounter;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdPlay_Click(System.Object theSender, System.EventArgs theEventArguments)
    {
      MessageBox.Show(arrPets[lstAnimal.SelectedIndex].Play());
    }
    // cmdPlay_Click(System.Object, As System.EventArgs) Handles cmdPlay.Click

    private void cmdSpeak_Click(System.Object theSender, System.EventArgs theEventArguments)
    {
      MessageBox.Show(arrPets[lstAnimal.SelectedIndex].Speak());
    }
    // cmdSpeak_Click(System.Object, System.EventArgs) Handles cmdSpeak.Click
    
    private void frmPetShop_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define some animals (Dogs, Cats and Birds)
      // Called by
      //   - User action (Loading a form)
      // Calls
      //   - Not documented
      // Created
      //   - CopyPaste � 20220304 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220304 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      arrPets[0] = new Dog("Ranger");

      arrPets[0].Breed = "German Shepherd";
      arrPets[0].Coloration = "Brown/Black";
      arrPets[0].Cost = 200;
      arrPets[0].Gender = "Male";

      arrPets[1] = new MiniDoxen("Cindy", "Black");
      arrPets[1].Gender = "Female";

      arrPets[2] = new GreatDane("Sir Ralph", "Brown/White");
      arrPets[2].Gender = "Male";

      arrPets[3] = new Cat("Misty");
      arrPets[3].Breed = "Calico";
      arrPets[3].Coloration = "Orange/Black";
      arrPets[3].Cost = 50;
      arrPets[3].Gender = "Female";

      arrPets[4] = new Siamese("Buster", "Orange/White");
      arrPets[4].Gender = "Male";
      
      arrPets[5] = new Manx("Horatio", "Brown");
      arrPets[5].Gender = "Male";
      
      arrPets[6] = new Bird("Bluebill");
      arrPets[6].Breed = "Blue Macaw Parrot";
      arrPets[6].Coloration = "Blue/Green/Yellow";
      arrPets[6].Cost = 1200;
      arrPets[6].Gender = "Male";

      arrPets[7] = new Cockatiel("Sparky", "Gray/Yellow");
      arrPets[7].Gender = "Female";
      
      arrPets[8] = new Parakeet("Sprinkles", "White");
      arrPets[8].Gender = "Male";

      for (intCounter = 0; intCounter < arrPets.Length; intCounter++)
      {
        lstAnimal.Items.Add(arrPets[intCounter].Breed);
      }
      // intCounter = arrPets.Length
    
    }
    // frmPetShop_Load(System.Object, System.EventArgs) Handles this.Load

    private void lstAnimal_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
    {
      Display(arrPets[lstAnimal.SelectedIndex]);
    }
    // lstAnimal_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstAnimal.SelectedIndexChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPetShop
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220304 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220304 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPetShop());
    }
    // Main() 

    private void Display(Animal thePet)
    {
      txtName.Text = thePet.Name;
      txtSpecies.Text = thePet.Species;
      txtBreed.Text = thePet.Breed;
      txtGender.Text = thePet.Gender;
      txtColor.Text = thePet.Coloration;
      txtLeg.Text = Convert.ToString(thePet.Legs);
      txtCost.Text = Convert.ToString(thePet.Cost);
    }
    // Display(�Animal)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPetShop

  public class Animal
  {

    #region "Constructors / Destructors"

    public Animal()
    {
      strSpecies = "";
      strBreed = "";
      strColor = "";
      strName = "";
      strGender = "";
      intLegs = 0;
      intCost = 0;
      Console.WriteLine("Animal default constructor");
    }
    // Animal()

    public Animal(string strSpecies, int intLegs) : this()
    {
      Species = strSpecies;
      Legs = intLegs;
      Console.WriteLine("Animal overloaded constructor");
    }
    // Animal(string, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int intCost;
    private int intLegs;
    private string strBreed;
    private string strColor;
    private string strGender;
    private string strName;
    private string strSpecies;

    #endregion

    #region "Properties"

    public string Breed
    {

      get
      {
        return strBreed;
      }
      // string Breed (Get)

      set
      {
        strBreed = value;
      }
      // Breed(string) (Set)

    }
    // string Breed

    public string Coloration
    {

      get
      {
        return strColor;
      }
      // string Coloration (Get)

      set
      {
        strColor = value;
      }
      // Coloration(string) (Set)

    }
    // string Coloration

    public int Cost
    {

      get
      {
        return intCost;
      }
      // int Cost (Get)

      set
      {
        intCost = value;
      }
      // Cost(int) (Set)

    }
    // string Cost

    public string Gender
    {

      get
      {
        return strGender;
      }
      // string Gender (Get)

      set
      {
        strGender = value;
      }
      // Gender(string) (Set)

    }
    // string Gender

    public int Legs
    {

      get
      {
        return intLegs;
      }
      // int Legs (Get)

      set
      {
        intLegs = value;
      }
      // Legs(int) (Set)

    }
    // string Legs

    public string Name
    {

      get
      {
        return strName;
      }
      // string Name (Get)

      set
      {
        strName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    public string Species
    {

      get
      {
        return strSpecies;
      }
      // string Species (Get)

      set
      {
        strSpecies = value;
      }
      // Species(string) (Set)

    }
    // string Species

    #endregion

    //#region "Methods"

    #region "Overrides"

    public virtual string Play()
    {
      Console.WriteLine("Animal.Play");
      return "";
    }
    // string Play()

    public virtual string Speak()
    {
      Console.WriteLine("Animal.Speak");
      return "";
    }
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // Animal

  public class Bird : Animal
  {

    #region "Constructors / Destructors"

    public Bird() : base ("Bird", 2)
    {
      Breed = "";
      Gender = "";
      Coloration = "";
      Cost = 0;
      Console.WriteLine("Bird default constructor");
    }
    // Bird()

    public Bird(string strName) : this()
    {
      Name = strName;
    }
    // Bird(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"
    
    override public string Play()
    {
      Console.WriteLine("Bird.Play");
      return Name + " bites your finger.";
    }
    //string Play()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Bird

  public class Cat : Animal
  {

    #region "Constructors / Destructors"
    
    public Cat() : base ("Cat", 4)
    {
      Breed = "";
      Gender = "";
      Coloration = "";
      Cost = 0;
      Console.WriteLine("Cat default constructor");
    }
    // Cat()

    public Cat(string strName) : this()
    {
      Name = strName;
      Console.WriteLine("Cat overloaded constructor");
    }
    // Cat(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Play()
    {
      Console.WriteLine("Cat.Play");
      return Name + " attacks the yarn ball";
    }
    // string Play()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Cat()

  public class Cockatiel: Bird
  {

    #region "Constructors / Destructors"

    public Cockatiel() : base()
    {
      Breed = "Cockatiel";
      Cost = 250;
      Console.WriteLine("Cockatiel default constructor");
    }
    // Parakeet()

    public Cockatiel(string strName, string strColor) : base(strName)
    {
      Breed = "Cockatiel";
      Cost = 250;
      Coloration = strColor;
      Console.WriteLine("Cockatiel overloaded constructor");
    }
    // Cockatiel(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Speak()
    {
      Console.WriteLine("Cockatiel.Speak");
      return Name + " says 'Squawkkk, " + Name + " want a cracker!'";
    }
    //End Function
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Parakeet

  public class Dog : Animal
  {

    #region "Constructors / Destructors"
    
    public Dog() : base ("Dog", 4)
    {
      Breed = "";
      Gender = "";
      Coloration = "";
      Cost = 0;
      Console.WriteLine("Dog default constructor");
    }
    // Dog()

    public Dog(string strName) : this()
    {
      Name = strName;
      Console.WriteLine("Dog overloaded constructor");
    }
    // Dog(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Play()
    {
      Console.WriteLine("Dog.Play");
      return Name + " fetches the frisbie";
    }
    // string Play()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Dog()

  public class GreatDane : Dog
  {

    #region "Constructors / Destructors"

    public GreatDane() : base()
    {
      Breed = "Great Dane";
      Cost = 400;
      Console.WriteLine("GreatDane default constructor");
    }
    // GreatDane()

    public GreatDane(string strName, string strColor) : base(strName)
    {
      Breed = "Great Dane";
      Cost = 400;
      Coloration = strColor;
      Console.WriteLine("GreatDane overloaded constructor");
    }
    // GreatDane(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Speak()
    {
      Console.WriteLine("GreatDane.Speak");
      return Name + " says 'oof, Woof!'";
    }
    //End Function
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // GreatDane

  public class Manx : Cat
  {

    #region "Constructors / Destructors"

    public Manx() : base()
    {
      Breed = "Manx";
      Cost = 100;
      Console.WriteLine("Manx default constructor");
    }
    // Manx()

    public Manx(string strName, string strColor) : base(strName)
    {
      Breed = "Manx";
      Cost = 100;
      Coloration = strColor;
      Console.WriteLine("Manx overloaded constructor");
    }
    // Manx(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Speak()
    {
      Console.WriteLine("Siamese.Speak");
      return Name + " says 'ffftttt!'";
    }
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Manx

  public class MiniDoxen : Dog
  {

    #region "Constructors / Destructors"

    public MiniDoxen() : base()
    {
      Breed = "Miniature Doxen";
      Cost = 600;
      Console.WriteLine("MiniDoxen default constructor");
    }
    // MiniDoxen()

    public MiniDoxen(string strName, string strColor) : base(strName)
    {
      Breed = "Miniature Doxen";
      Cost = 600;
      Coloration = strColor;
      Console.WriteLine("MiniDoxen overloaded constructor");
    }
    // MiniDoxen(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Speak()
    {
      Console.WriteLine("MiniDoxen.Speak");
      return Name + " says 'Boo boo boo boo!'";
    }
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // MiniDoxen

  public class Parakeet : Bird
  {

    #region "Constructors / Destructors"

    public Parakeet() : base()
    {
      Breed = "Parakeet";
      Cost = 75;
      Console.WriteLine("Parakeet default constructor");
    }
    // Parakeet()

    public Parakeet(string strName, string strColor) : base(strName)
    {
      Breed = "Parakeet";
      Cost = 75;
      Coloration = strColor;
      Console.WriteLine("Parakeet overloaded constructor");
    }
    // Parakeet(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Speak()
    {
      Console.WriteLine("Parakeet.Speak");
      return Name + " says 'Pee-dee-deet, peet.'";
    }
    //End Function
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Parakeet

  public class Siamese : Cat
  {

    #region "Constructors / Destructors"

    public Siamese() : base()
    {
      Breed = "Siamese";
      Cost = 250;
      Console.WriteLine("Siamese default constructor");
    }
    // Siamese()

    public Siamese(string strName, string strColor) : base(strName)
    {
      Breed = "Siamese";
      Cost = 250;
      Coloration = strColor;
      Console.WriteLine("Siamese overloaded constructor");
    }
    // Siamese(string, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    #region "Overrides"

    override public string Speak()
    {
      Console.WriteLine("Siamese.Speak");
      return Name + " says 'Rrrrowwll!'";
    }
    // string Speak()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // Siamese

}
// CopyPaste.PetShop