//***
// Action
//   - Drill down to data in the data grid control
// Created
//   - CopyPaste � 20251231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251231 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmDataGridDrillDown: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Data.SqlClient.SqlConnection cnncpNorthwindScript2005;
    internal System.Data.SqlClient.SqlCommand cmmSelectOrder;
    internal System.Windows.Forms.Button cmdOrderDetail;
    internal System.Windows.Forms.Label lblChooseCustomer;
    internal System.Data.SqlClient.SqlDataAdapter dtaOrder;
    internal System.Windows.Forms.DataGrid dgrOrder;
    internal System.Windows.Forms.ComboBox cmbCustomer;
    internal System.Data.SqlClient.SqlCommand cmmSelectCustomer;
    private BoundControls.dsCustomer dsCustomer;
    internal BoundControls.dsOrder dsOrder;
    internal System.Data.SqlClient.SqlDataAdapter dtaCustomer;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDataGridDrillDown));
      this.cnncpNorthwindScript2005 = new System.Data.SqlClient.SqlConnection();
      this.cmmSelectOrder = new System.Data.SqlClient.SqlCommand();
      this.cmdOrderDetail = new System.Windows.Forms.Button();
      this.lblChooseCustomer = new System.Windows.Forms.Label();
      this.dtaOrder = new System.Data.SqlClient.SqlDataAdapter();
      this.dgrOrder = new System.Windows.Forms.DataGrid();
      this.dsOrder = new BoundControls.dsOrder();
      this.cmbCustomer = new System.Windows.Forms.ComboBox();
      this.dsCustomer = new BoundControls.dsCustomer();
      this.cmmSelectCustomer = new System.Data.SqlClient.SqlCommand();
      this.dtaCustomer = new System.Data.SqlClient.SqlDataAdapter();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsOrder)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomer)).BeginInit();
      this.SuspendLayout();
      // 
      // cnncpNorthwindScript2005
      // 
      this.cnncpNorthwindScript2005.ConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthwindScript2005.FireInfoMessageEventOnUserErrors = false;
      // 
      // cmmSelectOrder
      // 
      this.cmmSelectOrder.CommandText = "SELECT intIdOrder, dtmOrderDate, dtmRequiredDate, dtmShippedDate, strCustomerId F" +
    "ROM tblCPOrder WHERE (strCustomerId = @KeyCustomer) ORDER BY dtmOrderDate DESC";
      this.cmmSelectOrder.Connection = this.cnncpNorthwindScript2005;
      this.cmmSelectOrder.Parameters.AddRange(new System.Data.SqlClient.SqlParameter[] {
            new System.Data.SqlClient.SqlParameter("@KeyCustomer", System.Data.SqlDbType.Variant)});
      // 
      // cmdOrderDetail
      // 
      this.cmdOrderDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cmdOrderDetail.Location = new System.Drawing.Point(316, 280);
      this.cmdOrderDetail.Name = "cmdOrderDetail";
      this.cmdOrderDetail.Size = new System.Drawing.Size(80, 23);
      this.cmdOrderDetail.TabIndex = 7;
      this.cmdOrderDetail.Text = "Order detail";
      this.cmdOrderDetail.Click += new System.EventHandler(this.cmdOrderDetail_Click);
      // 
      // lblChooseCustomer
      // 
      this.lblChooseCustomer.Location = new System.Drawing.Point(20, 16);
      this.lblChooseCustomer.Name = "lblChooseCustomer";
      this.lblChooseCustomer.Size = new System.Drawing.Size(160, 16);
      this.lblChooseCustomer.TabIndex = 4;
      this.lblChooseCustomer.Text = "Customers to List Orders For:";
      // 
      // dtaOrder
      // 
      this.dtaOrder.SelectCommand = this.cmmSelectOrder;
      this.dtaOrder.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPOrder", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdOrder", "intIdOrder"),
                        new System.Data.Common.DataColumnMapping("dtmOrderDate", "dtmOrderDate"),
                        new System.Data.Common.DataColumnMapping("dtmRequiredDate", "dtmRequiredDate"),
                        new System.Data.Common.DataColumnMapping("dtmShippedDate", "dtmShippedDate"),
                        new System.Data.Common.DataColumnMapping("strCustomerId", "strCustomerId")})});
      // 
      // dgrOrder
      // 
      this.dgrOrder.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrOrder.DataMember = "tblCPOrder";
      this.dgrOrder.DataSource = this.dsOrder;
      this.dgrOrder.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrOrder.Location = new System.Drawing.Point(28, 56);
      this.dgrOrder.Name = "dgrOrder";
      this.dgrOrder.ReadOnly = true;
      this.dgrOrder.Size = new System.Drawing.Size(368, 208);
      this.dgrOrder.TabIndex = 6;
      // 
      // dsOrder
      // 
      this.dsOrder.DataSetName = "dsOrder";
      this.dsOrder.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsOrder.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // cmbCustomer
      // 
      this.cmbCustomer.DataSource = this.dsCustomer;
      this.cmbCustomer.DisplayMember = "tblCPCustomer.strCompanyName";
      this.cmbCustomer.DropDownWidth = 192;
      this.cmbCustomer.Location = new System.Drawing.Point(196, 16);
      this.cmbCustomer.Name = "cmbCustomer";
      this.cmbCustomer.Size = new System.Drawing.Size(192, 21);
      this.cmbCustomer.TabIndex = 5;
      this.cmbCustomer.ValueMember = "tblCPCustomer.strIdCustomer";
      this.cmbCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbCustomer_SelectedIndexChanged);
      // 
      // dsCustomer
      // 
      this.dsCustomer.DataSetName = "dsCustomer";
      this.dsCustomer.Locale = new System.Globalization.CultureInfo("nl-BE");
      this.dsCustomer.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // cmmSelectCustomer
      // 
      this.cmmSelectCustomer.CommandText = "SELECT strIdCustomer, strCompanyName FROM tblCPCustomer ORDER BY strCompanyName";
      this.cmmSelectCustomer.Connection = this.cnncpNorthwindScript2005;
      // 
      // dtaCustomer
      // 
      this.dtaCustomer.SelectCommand = this.cmmSelectCustomer;
      this.dtaCustomer.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCustomer", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("strIdCustomer", "strIdCustomer"),
                        new System.Data.Common.DataColumnMapping("strCompanyName", "strCompanyName")})});
      // 
      // frmDataGridDrillDown
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(416, 317);
      this.Controls.Add(this.cmbCustomer);
      this.Controls.Add(this.cmdOrderDetail);
      this.Controls.Add(this.lblChooseCustomer);
      this.Controls.Add(this.dgrOrder);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmDataGridDrillDown";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Bind Data To ComboBox and DataGrid Controls";
      this.Load += new System.EventHandler(this.frmDataGridDrillDown_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsOrder)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomer)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmDataGridDrillDown'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmDataGridDrillDown()
      //***
      // Action
      //   - Create instance of 'frmDataGridDrillDown'
      //   - Set the global variable to this instance
      // Called by
      //   - frmBoundCountrolsMain.cmdDrillDown_Click(System.Object, System.EventArgs) Handles cmdDrillDown.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      cpProgram.thefrmDataGridDrillDown = this;
    }
    // frmDataGridDrillDown()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmbCustomer_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Refresh the orders
      // Called by
      //   - User action (Choosing an item in a combo box)
      // Calls
      //   - RefreshOrders()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
       RefreshOrders();
    }
    // cmbCustomer_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbCustomer.SelectedIndexChanged

    private void cmdOrderDetail_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmOrderDetail
      //   - Show it on the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmOrderDetail()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmOrderDetail thefrmOrderDetail = new frmOrderDetail();

      thefrmOrderDetail.Show();
    }
    // cmdOrderDetail_Click(System.Object, System.EventArgs) Handles cmdOrderDetail.Click

    private void frmDataGridDrillDown_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Fill the data set customers (using the data adapter)
      //   - Refresh the orders
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - RefreshOrders()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dtaCustomer.Fill(dsCustomer);
      RefreshOrders();
    }
    // frmComboBoxDataGrid_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void RefreshOrders()
      //***
      // Action
      //   - Clear the data set of the orders
      //   - If a customer is selected
      //     - Declare and initialize a data row view to the selected record
      //     - Set the command to a data adapter (using the unique key of the customer)
      //     - Fill the data set using the data adapter
      //   - If not
      //     - Do nothing
      // Called by
      //   - cmbCustomer_SelectedIndexChanged(System.Object, System.EventArgs) Handles cmbCustomer.SelectedIndexChanged
      //   - frmComboBoxDataGrid_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsOrder.Clear();

      if (cmbCustomer.SelectedIndex == -1)
      {
      }
      else
        // cmbCustomer.SelectedIndex <> -1
      {
        DataRowView drvCustomer = (DataRowView)cmbCustomer.SelectedItem;

        dtaOrder.SelectCommand.Parameters["@KeyCustomer"].Value = drvCustomer["strIdCustomer"];
        dtaOrder.Fill(dsOrder);
      }
      // cmbCustomer.SelectedIndex = -1

    }
    // RefreshOrders()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataGridDrillDown

}
// CopyPaste.Learning