﻿//***
// Action
//   - Adding some methods to the class / object string
// Created
//   - CopyPaste – 20260129 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260129 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public static class cpStringExtension
  {

    #region "Constructors / Destructors"

    static cpStringExtension()
    //***
    // Action
    //   - Basic static constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260129 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260129 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpStringExtension()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static bool IsValidInteger(this string strValue)
    //***
    // Action
    //   - Define a result variable
    //   - If successful to parse to an integer (discard the value)
    //     - Result variable becomes true
    //   - If not
    //     - Result variable becomes false
    //   - Return result variable
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260129 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260129 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnValid = false;

      if (int.TryParse(strValue, out int _))
      {
        blnValid = true;
      }
      else
      // Not int.TryParse(strValue, out int _)
      {
      }
      // int.TryParse(strValue, out int _)

      return blnValid;
    }
    // bool IsValidInteger(string)

    public static bool IsValidInteger(this string strValue, out int intValue)
    //***
    // Action
    //   - Define a result variable
    //   - If successful to parse to an integer
    //     - Result variable becomes true
    //     - Integer value is returned thru out parameter
    //   - If not
    //     - Result variable becomes false
    //     - 0 is returned thru out parameter
    //   - Return result variable
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260129 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260129 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnValid = false;
      intValue = 0;

      if (int.TryParse(strValue, out int intReturnValue))
      {
        blnValid = true;
        intValue = intReturnValue;
      }
      else
      // Not int.TryParse(strValue, out int intReturnValue)
      {
        intValue = 0;
      }
      // int.TryParse(strValue, out int intReturnValue)

      return blnValid;
    }
    // bool IsValidInteger(string, int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpStringExtension

}
// CopyPaste.Learning