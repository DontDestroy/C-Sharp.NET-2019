//***
// Action
//   - Demo of a trackbar
// Created
//   - CopyPaste � 20240330 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240330 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTrackBar: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Label lblBlue;
    internal System.Windows.Forms.Label lblGreen;
    internal System.Windows.Forms.TrackBar trbBlue;
    internal System.Windows.Forms.TrackBar trbGreen;
    internal System.Windows.Forms.TrackBar trbRed;
    internal System.Windows.Forms.Label lblRed;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTrackBar));
      this.lblBlue = new System.Windows.Forms.Label();
      this.lblGreen = new System.Windows.Forms.Label();
      this.trbBlue = new System.Windows.Forms.TrackBar();
      this.trbGreen = new System.Windows.Forms.TrackBar();
      this.trbRed = new System.Windows.Forms.TrackBar();
      this.lblRed = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.trbBlue)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.trbGreen)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.trbRed)).BeginInit();
      this.SuspendLayout();
      // 
      // lblBlue
      // 
      this.lblBlue.Location = new System.Drawing.Point(26, 128);
      this.lblBlue.Name = "lblBlue";
      this.lblBlue.Size = new System.Drawing.Size(56, 23);
      this.lblBlue.TabIndex = 10;
      this.lblBlue.Text = "Blue";
      // 
      // lblGreen
      // 
      this.lblGreen.Location = new System.Drawing.Point(26, 72);
      this.lblGreen.Name = "lblGreen";
      this.lblGreen.Size = new System.Drawing.Size(48, 23);
      this.lblGreen.TabIndex = 8;
      this.lblGreen.Text = "Green";
      // 
      // trbBlue
      // 
      this.trbBlue.Location = new System.Drawing.Point(86, 128);
      this.trbBlue.Maximum = 255;
      this.trbBlue.Name = "trbBlue";
      this.trbBlue.Size = new System.Drawing.Size(180, 42);
      this.trbBlue.TabIndex = 11;
      this.trbBlue.TickFrequency = 25;
      this.trbBlue.ValueChanged += new System.EventHandler(this.trbBlue_ValueChanged);
      // 
      // trbGreen
      // 
      this.trbGreen.Location = new System.Drawing.Point(86, 72);
      this.trbGreen.Maximum = 255;
      this.trbGreen.Name = "trbGreen";
      this.trbGreen.Size = new System.Drawing.Size(180, 42);
      this.trbGreen.TabIndex = 9;
      this.trbGreen.TickFrequency = 25;
      this.trbGreen.ValueChanged += new System.EventHandler(this.trbGreen_ValueChanged);
      // 
      // trbRed
      // 
      this.trbRed.Location = new System.Drawing.Point(86, 24);
      this.trbRed.Maximum = 255;
      this.trbRed.Name = "trbRed";
      this.trbRed.Size = new System.Drawing.Size(180, 42);
      this.trbRed.TabIndex = 7;
      this.trbRed.TickFrequency = 25;
      this.trbRed.ValueChanged += new System.EventHandler(this.trbRed_ValueChanged);
      // 
      // lblRed
      // 
      this.lblRed.Location = new System.Drawing.Point(26, 24);
      this.lblRed.Name = "lblRed";
      this.lblRed.Size = new System.Drawing.Size(56, 23);
      this.lblRed.TabIndex = 6;
      this.lblRed.Text = "Red";
      // 
      // frmTrackBar
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.lblBlue);
      this.Controls.Add(this.lblGreen);
      this.Controls.Add(this.trbBlue);
      this.Controls.Add(this.trbGreen);
      this.Controls.Add(this.trbRed);
      this.Controls.Add(this.lblRed);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTrackBar";
      this.Text = "TrackBar";
      this.Activated += new System.EventHandler(this.frmTrackBar_Activated);
      ((System.ComponentModel.ISupportInitialize)(this.trbBlue)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.trbGreen)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.trbRed)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTrackBar'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTrackBar()
      //***
      // Action
      //   - Create instance of 'frmTrackBar'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTrackBar()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    public byte mbytBlue;
    public byte mbytGreen;
    public byte mbytRed;
    public Color mcolBackground;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmTrackBar_Activated(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The red, green and blue values of the backcolor of the form are determined
      //   - The corresponding trackbars are set to the correct value
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mbytRed = frmTrackBar.ActiveForm.BackColor.R;
      mbytGreen = frmTrackBar.ActiveForm.BackColor.G;
      mbytBlue = frmTrackBar.ActiveForm.BackColor.B;
      trbRed.Value = mbytRed;
      trbGreen.Value = mbytGreen;
      trbBlue.Value = mbytBlue;    
    }
    // frmTrackBar_Activated(System.Object, System.EventArgs) Handles MyBase.Activated

    private void trbBlue_ValueChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The blue value is changed using the blue trackbar
      //   - The color is determined using the 3 values
      //   - Backcolor of the form is changed
      // Called by
      //   - User action (Changing the trackbar)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {    
      mbytBlue = Convert.ToByte(trbBlue.Value);
      mcolBackground = Color.FromArgb(mbytRed, mbytGreen, mbytBlue);
      
      frmTrackBar.ActiveForm.BackColor = mcolBackground;
      frmTrackBar.ActiveForm.Refresh();
    }
    // trbBlue_ValueChanged(System.Object, System.EventArgs) Handles trbBlue.ValueChanged

    
    private void trbGreen_ValueChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The green value is changed using the green trackbar
      //   - The color is determined using the 3 values
      //   - Backcolor of the form is changed
      // Called by
      //   - User action (Changing the trackbar)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {    
      mbytGreen = Convert.ToByte(trbGreen.Value);
      mcolBackground = Color.FromArgb(mbytRed, mbytGreen, mbytBlue);
      
      frmTrackBar.ActiveForm.BackColor = mcolBackground;
      frmTrackBar.ActiveForm.Refresh();
    }
    // trbGreen_ValueChanged(System.Object, System.EventArgs) Handles trbGreen.ValueChanged

    private void trbRed_ValueChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The red value is changed using the red trackbar
      //   - The color is determined using the 3 values
      //   - Backcolor of the form is changed
      // Called by
      //   - User action (Changing the trackbar)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {    
      mbytRed = Convert.ToByte(trbRed.Value);
      mcolBackground = Color.FromArgb(mbytRed, mbytGreen, mbytBlue);
      
      frmTrackBar.ActiveForm.BackColor = mcolBackground;
      frmTrackBar.ActiveForm.Refresh();
    }
    // trbRed_ValueChanged(System.Object, System.EventArgs) Handles trbRed.ValueChanged

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTrackBar
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTrackBar());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTrackBar

}
// CopyPaste.Learning