﻿//***
// Action
//   - Having DataSets in the application
// Created
//   - CopyPaste – 20210709 – VVDW
// Changed
//   - Organisation – yyyymmdd – Initials of programmer – What changed
// Tested
//   - CopyPaste – 20210709 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

namespace DataSetsTryout
{

  partial class frmDataSetsTryout
  {

    #region Windows Form Designer generated code

    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;
    internal System.Windows.Forms.Button cmdCopy;
    internal System.Windows.Forms.Button cmdRelation;
    internal System.Windows.Forms.Button cmdTable;
    internal System.Windows.Forms.ListBox lstClient;
    internal System.Windows.Forms.ListBox lstEmployee;
    internal System.Windows.Forms.Label lblOrder;
    internal System.Windows.Forms.Label lblEmployee;
    internal System.Windows.Forms.DataGrid dgrOrder;
    internal System.Windows.Forms.Label lblClient;
    internal System.Windows.Forms.Button cmdClone;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.cmdCopy = new System.Windows.Forms.Button();
      this.cmdRelation = new System.Windows.Forms.Button();
      this.cmdTable = new System.Windows.Forms.Button();
      this.lstClient = new System.Windows.Forms.ListBox();
      this.lstEmployee = new System.Windows.Forms.ListBox();
      this.lblOrder = new System.Windows.Forms.Label();
      this.lblEmployee = new System.Windows.Forms.Label();
      this.dgrOrder = new System.Windows.Forms.DataGrid();
      this.lblClient = new System.Windows.Forms.Label();
      this.cmdClone = new System.Windows.Forms.Button();
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdCopy
      // 
      this.cmdCopy.Location = new System.Drawing.Point(416, 102);
      this.cmdCopy.Name = "cmdCopy";
      this.cmdCopy.Size = new System.Drawing.Size(96, 23);
      this.cmdCopy.TabIndex = 19;
      this.cmdCopy.Text = "Copy DataSet";
      // 
      // cmdRelation
      // 
      this.cmdRelation.Location = new System.Drawing.Point(416, 38);
      this.cmdRelation.Name = "cmdRelation";
      this.cmdRelation.Size = new System.Drawing.Size(96, 23);
      this.cmdRelation.TabIndex = 17;
      this.cmdRelation.Text = "Create Relation";
      // 
      // cmdTable
      // 
      this.cmdTable.Location = new System.Drawing.Point(416, 6);
      this.cmdTable.Name = "cmdTable";
      this.cmdTable.Size = new System.Drawing.Size(96, 23);
      this.cmdTable.TabIndex = 16;
      this.cmdTable.Text = "Create Table";
      // 
      // lstClient
      // 
      this.lstClient.DisplayMember = "tblCPCustomer.strIdCustomer";
      this.lstClient.Location = new System.Drawing.Point(200, 22);
      this.lstClient.Name = "lstClient";
      this.lstClient.Size = new System.Drawing.Size(200, 95);
      this.lstClient.TabIndex = 13;
      this.lstClient.ValueMember = "tblCPCustomer.strIdCustomer";
      // 
      // lstEmployee
      // 
      this.lstEmployee.Location = new System.Drawing.Point(8, 22);
      this.lstEmployee.Name = "lstEmployee";
      this.lstEmployee.Size = new System.Drawing.Size(184, 95);
      this.lstEmployee.TabIndex = 11;
      // 
      // lblOrder
      // 
      this.lblOrder.AutoSize = true;
      this.lblOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOrder.Location = new System.Drawing.Point(8, 134);
      this.lblOrder.Name = "lblOrder";
      this.lblOrder.Size = new System.Drawing.Size(48, 13);
      this.lblOrder.TabIndex = 14;
      this.lblOrder.Text = "Orders:";
      // 
      // lblEmployee
      // 
      this.lblEmployee.AutoSize = true;
      this.lblEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblEmployee.Location = new System.Drawing.Point(8, 6);
      this.lblEmployee.Name = "lblEmployee";
      this.lblEmployee.Size = new System.Drawing.Size(71, 13);
      this.lblEmployee.TabIndex = 10;
      this.lblEmployee.Text = "Employees:";
      // 
      // dgrOrder
      // 
      this.dgrOrder.DataMember = "";
      this.dgrOrder.HeaderForeColor = System.Drawing.SystemColors.ControlText;
      this.dgrOrder.Location = new System.Drawing.Point(8, 150);
      this.dgrOrder.Name = "dgrOrder";
      this.dgrOrder.Size = new System.Drawing.Size(504, 208);
      this.dgrOrder.TabIndex = 15;
      // 
      // lblClient
      // 
      this.lblClient.AutoSize = true;
      this.lblClient.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblClient.Location = new System.Drawing.Point(200, 6);
      this.lblClient.Name = "lblClient";
      this.lblClient.Size = new System.Drawing.Size(49, 13);
      this.lblClient.TabIndex = 12;
      this.lblClient.Text = "Clients:";
      // 
      // cmdClone
      // 
      this.cmdClone.Location = new System.Drawing.Point(416, 70);
      this.cmdClone.Name = "cmdClone";
      this.cmdClone.Size = new System.Drawing.Size(96, 23);
      this.cmdClone.TabIndex = 18;
      this.cmdClone.Text = "Clone DataSet";
      // 
      // frmDataSetsTryout
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(520, 373);
      this.Controls.Add(this.cmdCopy);
      this.Controls.Add(this.cmdRelation);
      this.Controls.Add(this.cmdTable);
      this.Controls.Add(this.lstClient);
      this.Controls.Add(this.lstEmployee);
      this.Controls.Add(this.lblOrder);
      this.Controls.Add(this.lblEmployee);
      this.Controls.Add(this.dgrOrder);
      this.Controls.Add(this.lblClient);
      this.Controls.Add(this.cmdClone);
      this.Name = "frmDataSetsTryout";
      this.Text = "DataSets Tryout";
      ((System.ComponentModel.ISupportInitialize)(this.dgrOrder)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Cleanup after closing the form
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20210709 – VVDW
      // Changed
      //   - Organisation – yyyymmdd – Initials of programmer – What changed
      // Tested
      //   - CopyPaste – 20210709 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {

      if (disposing && (components != null))
      {
        components.Dispose();
      }
      // (disposing && (components != null))

      base.Dispose(disposing);
    }
    // Dispose(bool)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // frmDataSetsTryout
}
// DataSetsTryout