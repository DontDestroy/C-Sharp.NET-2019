﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmExample.aspx.cs" Inherits="CopyPaste.Learning.wfrmExample" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>WebForm Example</title>
</head>
<body>
    <form id="wfrmExample">
        <div>
        </div>
    </form>
</body>
</html>
