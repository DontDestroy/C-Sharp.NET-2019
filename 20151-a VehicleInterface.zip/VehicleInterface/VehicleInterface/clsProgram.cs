﻿//***
// Action
//   - Example of an interface
// Created
//   - CopyPaste – 20260128 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260128 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    #region "Constructors / Destructors"

    public cpProgram()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpProgram()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Create an instance of a default cpRoadVehicle
    //   - Test the use of properties of cpRoadVehicle
    //     - Not all getters are tested directly, indirectly with ToString() they are tested
    //   - Test the use of methods of cpRoadVehicle
    //   - Create an instance of a default cpCar
    //   - Test the use of properties of cpCar
    //   - Test the use of methods of cpCar
    //   - Create an instance of a default cpSuv
    //   - Test the use of properties of cpSuv
    //   - Test the use of methods of cpSuv
    //   - End routine
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - bool cpCar.VehicleIdentificationNumberCheck(cpCar)
    //   - bool cpSuv.VehicleIdentificationNumberCheck(cpSuv)
    //   - bool cpSuv.AutomaticDifferential (Get)
    //   - cpCar()
    //   - cpCar(string, uint, uint, uint)
    //   - cpRoadVehicle()
    //   - cpRoadVehicle(string, uint, uint, uint)
    //   - cpRoadVehicle.BreakingDown(uint)
    //   - cpRoadVehicle.ChangeDirection()
    //   - cpRoadVehicle.CurrentSpeed(uint) (Set)
    //   - cpRoadVehicle.DirectionForward(bool) (Set)
    //   - cpRoadVehicle.MaximumSpeedBackward(uint) (Set)
    //   - cpRoadVehicle.MaximumSpeedForward(uint) (Set)
    //   - cpRoadVehicle.SpeedingUp(uint)
    //   - cpRoadVehicle.WheelCount(uint) (Set)
    //   - cpRoadVehicle.VehicleIdentificationNumber(string) (Set)
    //   - cpSuv()
    //   - cpSuv(string, uint, uint, uint, bool)
    //   - cpSuv.AutomaticDifferential(bool) (Set)
    //   - string cpRoadVehicle.ToString()
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      // VVDW - Testing all paths in constructors cpRoadVehicle
      Console.WriteLine("Use constructor");

      // cpVehicle theVehicle = new cpVehicle();
      // VVDW - The line above is impossible (you can't initialize from an abstract class)
      cpVehicle theVehicle = new cpRoadVehicle();
      theVehicle = new cpRoadVehicle("XYZ-789", 4, 120, 30);
      Console.WriteLine(theVehicle);

      // VVDW - Testing all paths in changes of properties cpRoadVehicle
      Console.WriteLine("Change speed");
      theVehicle.CurrentSpeed = 100;
      Console.WriteLine(theVehicle);

      Console.WriteLine("Change wheelcount, VINNumber and speed");
      theVehicle.WheelCount = 5;
      theVehicle.VehicleIdentificationNumber = "ABC-123";
      theVehicle.CurrentSpeed = 200;
      Console.WriteLine(theVehicle);

      Console.WriteLine("Change direction to backward");
      theVehicle.DirectionForward = false;
      Console.WriteLine(theVehicle);

      Console.WriteLine("Change maximum speed backward");
      theVehicle.MaximumSpeedBackward = 20;
      Console.WriteLine(theVehicle);

      Console.WriteLine("Change direction to forward, maximum speed forward, change current speed");
      theVehicle.DirectionForward = true;
      theVehicle.MaximumSpeedForward = 120;
      theVehicle.CurrentSpeed = 130;
      Console.WriteLine(theVehicle);

      Console.WriteLine("Change current speed, direction to backward, maximum speed forward, direction to forward");
      theVehicle.CurrentSpeed = 20;
      theVehicle.DirectionForward = false;
      theVehicle.MaximumSpeedForward = 15;
      theVehicle.DirectionForward = true;
      Console.WriteLine(theVehicle);

      Console.WriteLine("Change direction to backward, maximum speed backward, direction to forward, maximum speed forward");
      theVehicle.DirectionForward = false;
      theVehicle.MaximumSpeedBackward = 30;
      theVehicle.DirectionForward = true;
      theVehicle.MaximumSpeedForward = 130;
      Console.WriteLine(theVehicle);

      Console.WriteLine("Change current spreed, maximum speed forward");
      theVehicle.CurrentSpeed = 130;
      theVehicle.MaximumSpeedForward = 120;

      // VVDW - Testing all paths in methods cpRoadVehicle
      Console.WriteLine("Slow down 50");
      theVehicle.BreakingDown(50);
      Console.WriteLine(theVehicle);

      Console.WriteLine("Slow down 100");
      theVehicle.BreakingDown(100);
      Console.WriteLine(theVehicle);

      Console.WriteLine("Switch direction");
      theVehicle.ChangeDirection();
      Console.WriteLine(theVehicle);

      Console.WriteLine("Speed up 10");
      theVehicle.SpeedingUp(10);
      Console.WriteLine(theVehicle);

      Console.WriteLine("Speed up 50");
      theVehicle.SpeedingUp(50);
      Console.WriteLine(theVehicle);

      Console.WriteLine("Switch direction and speed up 100");
      theVehicle.ChangeDirection();
      theVehicle.SpeedingUp(100);
      Console.WriteLine(theVehicle);

      // VVDW - Testing all paths in constructors cpCar
      cpCar carOne = new cpCar();
      cpCar carTwo = new cpCar();
      cpCar carThree = new cpCar("CAR-789", 3, 100, 20);
      
      Console.WriteLine("Info car One");
      Console.WriteLine(carOne);
      Console.WriteLine("Info car Two");
      Console.WriteLine(carTwo);
      Console.WriteLine("Info car Three");
      Console.WriteLine(carThree);

      // VVDW - Testing all paths in properties cpCar

      // VVDW - Testing all paths in methods cpCar
      Console.WriteLine("Check Vehicle Identification Number of cars");
      Console.WriteLine("Have the cars 1 and 2 the same number : {0}", carOne.VehicleIdentificationNumberCheck(carTwo));
      Console.WriteLine("Have the cars 1 and 3 the same number : {0}", carOne.VehicleIdentificationNumberCheck(carThree));
      Console.WriteLine();

      // VVDW - Testing all paths in constructors cpSuv
      cpSuv suvOne = new cpSuv();
      cpSuv suvTwo = new cpSuv();
      cpSuv suvThree = new cpSuv("SUV-789", 3, 100, 20, true);

      Console.WriteLine("Info suv One");
      Console.WriteLine(suvOne);
      Console.WriteLine("Info suv Two");
      Console.WriteLine(suvTwo);
      Console.WriteLine("Info suv Three");
      Console.WriteLine(suvThree);

      // VVDW - Testing all paths in properties cpSuv
      suvThree.AutomaticDifferential = !suvThree.AutomaticDifferential;
      Console.WriteLine("Info suv Three - Changed");
      Console.WriteLine(suvThree);

      // VVDW - Testing all paths in methods cpSuv
      Console.WriteLine("Check Vehicle Identification Number of suvs");
      Console.WriteLine("Have the suvs 1 and 2 the same number : {0}", suvOne.VehicleIdentificationNumberCheck(suvTwo));
      Console.WriteLine("Have the suv 1 and 3 the same number : {0}", suvOne.VehicleIdentificationNumberCheck(suvThree));

      // VVDW - End routine
      Console.WriteLine();
      Console.WriteLine("Hit any key");
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning