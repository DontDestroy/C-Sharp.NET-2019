//***
// Action
//   - A demo of a system exception
// Created
//   - CopyPaste � 20230808 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230808 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmSystemException : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    internal System.Windows.Forms.Button cmdButton;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmSystemException));
      this.cmdButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdButton
      // 
      this.cmdButton.Location = new System.Drawing.Point(67, 40);
      this.cmdButton.Name = "cmdButton";
      this.cmdButton.TabIndex = 1;
      this.cmdButton.Text = "Click";
      this.cmdButton.Click += new System.EventHandler(this.cmdButton_Click);
      // 
      // frmSystemException
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(208, 102);
      this.Controls.Add(this.cmdButton);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmSystemException";
      this.Text = "System Exception";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmSystemException'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmSystemException()
      //***
      // Action
      //   - Create instance of 'frmSystemException'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmSystemException()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdButton_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create an array of 5 elements
      //   - Show the information of element with index 9
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int[] arrlngNumber = {1, 2, 3, 4, 5};

      try 
      {
        MessageBox.Show(arrlngNumber[9].ToString());
      }
      catch (Exception theException)
      {
        MessageBox.Show("Something went wrong: " + theException.Message);
      }
      finally
      {
      }
          
    }
    // cmdButton_Click(System.Object, System.EventArgs) Handles cmdButton.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmSystemException
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmSystemException());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmSystemException

}
// CopyPaste.Learning