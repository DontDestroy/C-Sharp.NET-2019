//***
// Action
//   - Testroutine for cpDemo and cpDerivedDemo
// Created
//   - CopyPaste � 20240531 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240531 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Explanation of the code in this method
      //   - Define 1 cpDemo instance
      //   - Define 1 cpDerivedDemo instances
      //   - Show the ToString of the 2 instances
      //   - Compare the 2 instances with each other (compare on the length)
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpDemo(string)
      //   - cpDerivedDemo(string)
      //   - int cpDemo.CompareTo(System.Object) Implements IComparable.CompareTo
      //   - string cpDemo.ToString(String, IFormatProvider) Implements IFormattable.ToString
      //   - string cpDerivedDemo.ToString(String, IFormatProvider) As String
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpDemo thecpDemoA = new cpDemo("Hello");
      cpDerivedDemo thecpDemoB = new cpDerivedDemo("HoHoHo");

      Console.WriteLine(thecpDemoA);
      Console.WriteLine(thecpDemoB);
      Console.WriteLine("thecpDemoA is longer then thecpDemoB: " + thecpDemoA.CompareTo(thecpDemoB));
      Console.WriteLine("thecpDemoB is longer then thecpDemoA: " + thecpDemoB.CompareTo(thecpDemoA));
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning