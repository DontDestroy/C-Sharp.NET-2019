//***
// Action
//'   - 
//' Created
//'   - CopyPaste � 20220105 � VVDW
//' Changed
//'   - CopyPaste � yyyymmdd � VVDW � What changed
//' Tested
//'   - CopyPaste � 20220105 � VVDW
//' Proposal (To Do)
//'   -
//'***

using Microsoft.VisualBasic;
using System;

namespace NetDataType
{

  class cpNetDataType
	{

    static void Main()
    //***
    // Action
    //   - A simple message box
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - Microsoft.VisualBasic.Interaction.Msgbox(string, MsgBoxStyle, string)
    //   - string int.ToString()
    // Created
    //   - CopyPaste � 20220105 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220105 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      int intNumber = (int)12.3456;
      string strString;

      strString = intNumber.ToString();
      Interaction.MsgBox(strString, MsgBoxStyle.OkOnly, "Copy Paste");
    }
    // Main()

  }
  // cpNetDataType

}
// NetDataType