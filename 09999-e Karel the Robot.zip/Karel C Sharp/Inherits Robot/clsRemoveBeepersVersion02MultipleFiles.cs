﻿//***
// Action
//   - A field of crops must be harvested
// Created
//   - CopyPaste – 20251013 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251013 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpRemoveBeepersVersion02MultipleFiles : cpHarvesterVersion02
	{

		#region "Constructors / Destructors"

		public cpRemoveBeepersVersion02MultipleFiles(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Robot becomes a theColor cpRemoveBeepersVersion02MultipleFiles starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
		//   - Nothing else happens
		// Called by
		//   - cpProgram.RemoveBeepersVersion02MultipleFiles()
		// Calls
		//   - cpHarvesterVersion02(int, int,  Directions.Direction, int, Color)
		// Created
		//   - CopyPaste – 20251013 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251013 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
		}
		// cpRemoveBeepersVersion02MultipleFiles(int, int, Directions.Direction, int, Color) 

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public void HarvestTheField()
		//***
		// Action
		//   - Harvest two rows
		//   - Set the robot good for the next harvest of 2 rows
		//   - Repeat this twice
		//   - Harvest the last 2 rows
		// Called by
		//   - 
		// Calls
		//   - cpHarvesterVersion02.HarvestTwoRows()
		//   - cpHarvesterVersion02.PositionForNextHarvest()
		// Created
		//   - CopyPaste – 20251013 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251013 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			move(); // The robot must be placed on the first beeper (looking East)
			HarvestTwoRows();
			PositionForNextHarvest();
			HarvestTwoRows();
			PositionForNextHarvest();
			HarvestTwoRows();
			move(); // The robot must be placed one further (looking West)
		}
		// HarvestTheField()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpRemoveBeepersVersion02MultipleFiles

}
// cpKarelTheRobot