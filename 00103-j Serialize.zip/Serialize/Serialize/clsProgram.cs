//***
// Action
//   - Testroutine for cpDivision and cpEmployee
// Created
//   - CopyPaste � 20240608 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240608 � VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Learning.CompanyDivision;
using CopyPaste.Learning.Employee;
using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Create 2 employees using cpDivision
      //   - Set all properties for first employee
      //   - Show all information of first employee
      //   - Set 2 properties for second employee
      //   - Show all information of second employee
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - bool cpDivision.Serialize()
      //   - cpDivision.Division(string) (Set)
      //   - cpDivision.MonthsInDivision(int) (Set)
      //   - cpDivision()
      //   - cpDivision(string, string)
      //   - cpEmployee.FirstName(string) (Set)
      //   - cpEmployee.LastName(string) (Set)
      //   - ShowEmployee(cpDivision)
      // Created
      //   - CopyPaste � 20240608 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240608 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpDivision theEmployee1 = new cpDivision();
      cpDivision theEmployee2 = new cpDivision("Vincent", "Van De Walle");

      theEmployee1.FirstName = "Hilde";
      theEmployee1.LastName = "Saelens";
      theEmployee1.Division = "Secretary";
      theEmployee1.MonthsInDivision = 18;

      ShowEmployee(theEmployee1);

      theEmployee2.Division = "Management";
      theEmployee2.MonthsInDivision = 142;

      if (theEmployee2 is cpDivision)
      {

        if (theEmployee2.Serialize())
        {
          ShowEmployee(theEmployee2);
        }
        else
          // Not theEmployee2.Serialize()
        {
        }
        // theEmployee2.Serialize()

      }
      else
        // Not theEmployee2 Is cpDivision 
      {
      }
      // theEmployee2 Is cpDivision 

    }
    // Main()

    private static void ShowEmployee(cpDivision theCurrentEmployee)
      //***
      // Action
      //   - Explanation of the code in this method
      // Called by
      //   - Main()
      // Calls
      //   - int cpDivision.EmployeeNumber() As Integer (Get)
      //   - int cpDivision.MonthsInDivision() As Integer (Get)
      //   - string cpDivision.Division() As String (Get)
      //   - string cpDivision.FirstName() As String (Get)
      //   - string cpDivision.LastName() As String (Get)
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - Alternative, you can implement the ToString for cpDivision
      //***
    {
      string strDisplayString;

      strDisplayString = "Employee Name: " + theCurrentEmployee.FirstName + " " + theCurrentEmployee.LastName + Environment.NewLine;
      strDisplayString += "Employee Division: " + theCurrentEmployee.Division + Environment.NewLine;
      strDisplayString += "Employee Months: " + theCurrentEmployee.MonthsInDivision + Environment.NewLine;
      strDisplayString += "Employee Number: " + theCurrentEmployee.EmployeeNumber + Environment.NewLine;

      MessageBox.Show(strDisplayString, "Employee Scanner", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // ShowEmployee(cpDivision)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx