//***
// Action
//   - Definition of a cpInfoAccount
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpInfoAccount
  {

    #region "Constructors / Destructors"

    public cpInfoAccount(string strClientName, decimal decAmount)
      //***
      // Action
      //   - Creating an instance of cpInfoAcount with a given name and an amount
      // Called by
      //   - cpInfoAccount cpCommand.FindInfoAccount(string) 
      //   - User action (Creating instance)
      // Calls
      //   - Amount(decimal) (Set)
      //   - ClientName(string) (Set)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Amount = decAmount;
      ClientName = strClientName;
    }
    // cpInfoAccount(string, decimal)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private decimal mdecAmount;
    private string mstrClientName;

    #endregion

    #region "Properties"

    public decimal Amount
    {

      get
        //***
        // Action Set
        //   - Return 'mdecAmount'
        // Called by
        //   - cmdFindInfo_Click(System.Object, System.EventArgs) Handles cmdFindInfo.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260204 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260204 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecAmount;
      }
      // decimal Amount (Get)

      set
        //***
        // Action Set
        //   - 'mdecAmount' becomes 'value'
        // Called by
        //   - cpInfoAccount(string, decimal)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260204 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260204 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
      {
        mdecAmount = value;
      }
      // Amount(decimal) (Set)

    }
    // decimal Amount

    public string ClientName
    {

      get
        //***
        // Action Get
        //   - Return 'mstrClientName'
        // Called by
        //   - string ToString()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260204 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260204 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrClientName;
      }
      // string ClientName (Get)

      set
        //***
        // Action Set
        //   - 'mstrClientName' becomes 'value'
        // Called by
        //   - cpInfoAccount(string, decimal)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20260204 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20260204 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrClientName = value;
      }
      // ClientName(string) (Set)

    }
    // string ClientName

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpInfoAccount

}
// CopyPaste.Learning