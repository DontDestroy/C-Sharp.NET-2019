//***
// Action
//   - Testroutine of an instance of cpCircle
// Created
//   - CopyPaste � 20231230 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20231230 � VVDW
// Proposal (To Do)
//   - 
//***

using CopyPaste.Learning.Math;
using Microsoft.VisualBasic;
using System;
using System.Windows.Forms;

namespace Circle
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Create a new instance of a cpCircle
    //   - Get some properties
    //   - Set some properties
    //   - Use of ToString()
    //   - Show the diameter
    //   - Show the circumference
    //   - Show the area
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpCircle()
    //   - cpCircle(int, int, double)
    //   - cpCircle.Radius(double) (Set)
    //   - cpPoint.X(int) (Set)
    //   - cpPoint.Y(int) (Set)
    //   - double cpCircle.Area()
    //   - double cpCircle.Circumference()
    //   - double cpCircle.Diameter()
    //   - double cpCircle.Radius() (Get)
    //   - int cpCircle.X() (Get)
    //   - int cpCircle.Y() (Get)
    //   - int cpPoint.X() (Get)
    //   - int cpPoint.Y() (Get)
    //   - string cpCircle.ToString()
    // Created
    //   - CopyPaste � 20231230 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20231230 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      string strOutput;
      cpCircle thecpCircle;

      thecpCircle = new cpCircle();

      strOutput = thecpCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      thecpCircle = new cpCircle(37, 43, 2.5);

      strOutput = thecpCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      thecpCircle.X = 2;
      thecpCircle.Y = 2;
      thecpCircle.Radius = 4.25;

      strOutput = "The new location and radius of circle are " + Environment.NewLine + thecpCircle.ToString();
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Diameter is " + String.Format("{0:F}", thecpCircle.Diameter());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Circumference is " + String.Format("{0:F}", thecpCircle.Circumference());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      strOutput = "Area is " + String.Format("{0:F}", thecpCircle.Area());
      MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

      /*
        // Not happy flow - Now the tests are correct, tests are also extended to cover all the possible situations
        MessageBox.Show("The wrong results are corrected", "Demonstrating Class cpCircle");

        cpCircle thecpFirstCircle;
        cpCircle thecpSecondCircle;
        cpCircle thecpThirdCircle;

        thecpFirstCircle = new cpCircle(); // X = 0; Y = 0; Radius = 0;
        thecpSecondCircle = new cpCircle(); // X = 0; Y = 0; Radius = 0;
        thecpThirdCircle = new cpCircle(); // X = 0; Y = 0; Radius = 0;

        thecpFirstCircle.X = 1; // X = 1; Y = 0; Radius = 0; You change the coordinates of the circle
        thecpSecondCircle.Center.X = 1; // Center.X = 1; Center.Y = 0; Radius = 0; You change the coordinates of the center of the circle
        // thecpThirdCircle.Center = new cpPoint(2, 2); // This must be blocked, because you ran into problems if you allow it

        strOutput = thecpFirstCircle.ToString();
        MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

        strOutput = "X coordinate is " + thecpFirstCircle.Center.X + ControlChars.CrLf +
          "Y coordinate is " + thecpFirstCircle.Center.Y + Environment.NewLine +
          "Radius is " + thecpFirstCircle.Radius;
        MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

        strOutput = thecpSecondCircle.ToString();
        MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

        strOutput = "X coordinate is " + thecpSecondCircle.Center.X + ControlChars.CrLf +
          "Y coordinate is " + thecpSecondCircle.Center.Y + Environment.NewLine +
          "Radius is " + thecpSecondCircle.Radius;
        MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

        strOutput = thecpThirdCircle.ToString();
        MessageBox.Show(strOutput, "Demonstrating Class cpCircle");

        strOutput = "X coordinate is " + thecpThirdCircle.Center.X + ControlChars.CrLf +
          "Y coordinate is " + thecpThirdCircle.Center.Y + Environment.NewLine +
          "Radius is " + thecpThirdCircle.Radius;
        MessageBox.Show(strOutput, "Demonstrating Class cpCircle");
      */

    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// Circle