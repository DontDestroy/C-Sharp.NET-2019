﻿//***
// Action
//   - A definition of an ControllerStrategyVersion01
// Created
//   - CopyPaste – 20251030 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251030 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpControllerStrategyVersion01 : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpControllerStrategyVersion01(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpControllerStrategyVersion01 starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Define the current turn as a cpLeftTurnController
    //   - Define the other turn as a cpRightTurnController
    // Called by
    //   - cpProgram.ControllerStrategyVersion01()
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      currentTurn = new cpLeftTurnController(this);
      otherTurn = new cpRightTurnController(this);
    }
    // cpControllerStrategyVersion01(int, int, Directions.Direction, int, Color) 

    public cpControllerStrategyVersion01(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpControllerStrategyVersion01 starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpControllerStrategyVersion01(int, int, Directions.Direction, int, Color, cpinfStrategy) 
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpControllerStrategyVersion01(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpinfController currentTurn;
    private cpinfController otherTurn;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void LayRow()
    //***
    // Action
    //   - Robot repeats this 4 times
    //     - Put beeper
    //     - Move one forward
    //   - Put last beeper
    // Called by
    //   - cpProgram.ControllerStrategyVersion01()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      for (int beeperCounter = 0; beeperCounter < 4; beeperCounter++)
      {
        putBeeper();
        move();
      }
      // beeperCounter = 4

      putBeeper();
    }
    // LayRow()

    public void Turn()
    //***
    // Action
    //   - Robot turns by executing the current turn controller
    //   - Current turn controller is swapped with other turn controller
    // Called by
    //   - cpProgram.ControllerStrategyVersion01()
    // Calls
    //   - cpLeftTurnController.ControlIt()
    //   - cpRightTurnController.ControlIt()
    // Created
    //   - CopyPaste – 20251030 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251030 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpinfController temporaryController;

      currentTurn.ControlIt();
      temporaryController = currentTurn;
      currentTurn = otherTurn;
      otherTurn = temporaryController;
    }
    // Turn()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpControllerStrategyVersion01

}
// cpKarelTheRobot