﻿//***
// Action
//   - Home controller
//   - Controls the logic flow of the application
//   - Controls the correct response to a typed or choosen URL
// Created
//   - CopyPaste – 20260427 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260427 – VVDW
// Proposal (To Do)
//   -
//***

using AgileTasks.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AgileTasks.Controllers
{

  public class HomeController : Controller
  {

    #region "Constructors / Destructors"

    public HomeController()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - xxxx
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // HomeController()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public ActionResult About()
    //***
    // Action
    //   - Sets a message to the view bag
    //   - Returns the view
    // Called by
    //   - User action in _Layout (Clicking a link)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      ViewBag.Message = "Your application description page.";

      return View();
    }
    // ActionResult About()

    public ActionResult Contact()
    //***
    // Action
    //   - Sets a message to the view bag
    //   - Returns the view
    // Called by
    //   - User action in _Layout (Clicking a link)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      ViewBag.Message = "Your contact page.";

      return View();
    }
    // ActionResult Contact()

    public ActionResult Dashboard()
    //***
    // Action
    //   - Returns the view
    // Called by
    //   - User action in _Layout (Clicking a link)
    // Calls
    //   - cpTask()
    //   - List<cpTask> cpTask.GetTasks()
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      cpTask theTask = new cpTask();
      List<cpTask> tasks = theTask.GetTasks();

      return View(tasks);
    }
    // ActionResult Dashboard()

    public ActionResult Index()
    //***
    // Action
    //   - Returns the view
    // Called by
    //   - User action in _Layout (Clicking a link)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260427 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260427 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return View();
    }
    // ActionResult Index()


    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // HomeController

}
// AgileTasks.Controllers