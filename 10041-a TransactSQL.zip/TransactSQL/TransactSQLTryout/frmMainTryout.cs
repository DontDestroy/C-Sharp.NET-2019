//***
// Action
//   - Startscreen of the application to demo SQL statements (Transact SQL)
//   - Show eight options with tooltips
// Created
//   - CopyPaste � 20260114 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260114 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMainTryout: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdTableData;
    internal System.Windows.Forms.Button cmdTable;
    internal System.Windows.Forms.Button cmdSubQueries;
    internal System.Windows.Forms.Button cmdNotCorresponding;
    internal System.Windows.Forms.Button cmdUserDefinedFunction;
    internal System.Windows.Forms.Button cmdWildcards;
    internal System.Windows.Forms.Button cmdVariables;
    internal System.Windows.Forms.ToolTip ttpInfo;
    internal System.Windows.Forms.Button cmdRetrieveUniqueRecord;
    private System.ComponentModel.IContainer components;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMainTryout));
      this.cmdTableData = new System.Windows.Forms.Button();
      this.cmdTable = new System.Windows.Forms.Button();
      this.cmdSubQueries = new System.Windows.Forms.Button();
      this.cmdNotCorresponding = new System.Windows.Forms.Button();
      this.cmdUserDefinedFunction = new System.Windows.Forms.Button();
      this.cmdWildcards = new System.Windows.Forms.Button();
      this.cmdVariables = new System.Windows.Forms.Button();
      this.ttpInfo = new System.Windows.Forms.ToolTip(this.components);
      this.cmdRetrieveUniqueRecord = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // cmdTableData
      // 
      this.cmdTableData.Location = new System.Drawing.Point(152, 104);
      this.cmdTableData.Name = "cmdTableData";
      this.cmdTableData.Size = new System.Drawing.Size(112, 32);
      this.cmdTableData.TabIndex = 14;
      this.cmdTableData.Text = "Table with data";
      this.cmdTableData.Click += new System.EventHandler(this.cmdTableData_Click);
      // 
      // cmdTable
      // 
      this.cmdTable.Location = new System.Drawing.Point(152, 56);
      this.cmdTable.Name = "cmdTable";
      this.cmdTable.Size = new System.Drawing.Size(112, 32);
      this.cmdTable.TabIndex = 13;
      this.cmdTable.Text = "Table";
      this.cmdTable.Click += new System.EventHandler(this.cmdTable_Click);
      // 
      // cmdSubQueries
      // 
      this.cmdSubQueries.Location = new System.Drawing.Point(152, 8);
      this.cmdSubQueries.Name = "cmdSubQueries";
      this.cmdSubQueries.Size = new System.Drawing.Size(112, 32);
      this.cmdSubQueries.TabIndex = 12;
      this.cmdSubQueries.Text = "Subqueries";
      this.cmdSubQueries.Click += new System.EventHandler(this.cmdSubQueries_Click);
      // 
      // cmdNotCorresponding
      // 
      this.cmdNotCorresponding.Location = new System.Drawing.Point(8, 152);
      this.cmdNotCorresponding.Name = "cmdNotCorresponding";
      this.cmdNotCorresponding.Size = new System.Drawing.Size(112, 32);
      this.cmdNotCorresponding.TabIndex = 11;
      this.cmdNotCorresponding.Text = "Not Corresponding";
      this.cmdNotCorresponding.Click += new System.EventHandler(this.cmdNotCorresponding_Click);
      // 
      // cmdUserDefinedFunction
      // 
      this.cmdUserDefinedFunction.Location = new System.Drawing.Point(152, 152);
      this.cmdUserDefinedFunction.Name = "cmdUserDefinedFunction";
      this.cmdUserDefinedFunction.Size = new System.Drawing.Size(112, 32);
      this.cmdUserDefinedFunction.TabIndex = 15;
      this.cmdUserDefinedFunction.Text = "User-Defined function";
      this.cmdUserDefinedFunction.Click += new System.EventHandler(this.cmdUserDefinedFunction_Click);
      // 
      // cmdWildcards
      // 
      this.cmdWildcards.Location = new System.Drawing.Point(8, 104);
      this.cmdWildcards.Name = "cmdWildcards";
      this.cmdWildcards.Size = new System.Drawing.Size(112, 32);
      this.cmdWildcards.TabIndex = 10;
      this.cmdWildcards.Text = "Wildcards";
      this.cmdWildcards.Click += new System.EventHandler(this.cmdWildcards_Click);
      // 
      // cmdVariables
      // 
      this.cmdVariables.Location = new System.Drawing.Point(8, 56);
      this.cmdVariables.Name = "cmdVariables";
      this.cmdVariables.Size = new System.Drawing.Size(112, 32);
      this.cmdVariables.TabIndex = 9;
      this.cmdVariables.Text = "Variables";
      this.cmdVariables.Click += new System.EventHandler(this.cmdVariables_Click);
      // 
      // cmdRetrieveUniqueRecord
      // 
      this.cmdRetrieveUniqueRecord.Location = new System.Drawing.Point(8, 8);
      this.cmdRetrieveUniqueRecord.Name = "cmdRetrieveUniqueRecord";
      this.cmdRetrieveUniqueRecord.Size = new System.Drawing.Size(112, 32);
      this.cmdRetrieveUniqueRecord.TabIndex = 8;
      this.cmdRetrieveUniqueRecord.Text = "Retrieve Unique Record";
      this.cmdRetrieveUniqueRecord.Click += new System.EventHandler(this.cmdRetrieveUniqueRecord_Click);
      // 
      // frmMainTryout
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(272, 237);
      this.Controls.Add(this.cmdTable);
      this.Controls.Add(this.cmdSubQueries);
      this.Controls.Add(this.cmdNotCorresponding);
      this.Controls.Add(this.cmdUserDefinedFunction);
      this.Controls.Add(this.cmdWildcards);
      this.Controls.Add(this.cmdVariables);
      this.Controls.Add(this.cmdRetrieveUniqueRecord);
      this.Controls.Add(this.cmdTableData);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMainTryout";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Transact SQL Main Form Tryout";
      this.Load += new System.EventHandler(this.frmMainTryout_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMainTryout'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMainTryout()
      //***
      // Action
      //   - Create instance of 'frmMainTryout'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMainTryout()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdNotCorresponding_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmNotCorrespondingTryout'
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmNotCorrespondingTryout()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdNotCorresponding_Click(System.Object, System.EventArgs) Handles cmdNotCorresponding.Click

    private void cmdRetrieveUniqueRecord_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmUniqueRecordTryout'
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmUniqueRecordTryout()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdRetrieveUniqueRecord_Click(System.Object, System.EventArgs) Handles cmdRetrieveUniqueRecord.Click

    private void cmdSubQueries_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmSubqueriesTryout'
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmSubqueriesTryout()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdSubQueries_Click(System.Object, System.EventArgs) Handles cmdSubQueries.Click

    private void cmdTable_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmTableTryout'
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmTableTryout()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdTable_Click(System.Object, System.EventArgs) Handles cmdTable.Click

    private void cmdTableData_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmTableDataTryout'
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmTableDataTryout()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdTableData_Click(System.Object, System.EventArgs) Handles cmdTableData.Click

    private void cmdUserDefinedFunction_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmUserDefinedFunctionTryout'
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmUserDefinedFunctionTryout()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdUserDefinedFunction_Click(System.Object, System.EventArgs) Handles cmdUserDefinedFunction.Click

    private void cmdVariables_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmVariablesTryout'
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmVariablesTryout()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdVariables_Click(System.Object, System.EventArgs) Handles cmdVariables.Click

    private void cmdWildcards_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create new instance of 'frmWildcardsTryout'
      //   - Show the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmWildCardsTryout()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cmdWildcards_Click(System.Object, System.EventArgs) Handles cmdWildcards.Click

    private void frmMainTryout_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set tooltips to the buttons
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ttpInfo.SetToolTip(cmdRetrieveUniqueRecord, "Retrieve Unique Records Only Using a Select Query");
      ttpInfo.SetToolTip(cmdVariables, "Use Variables and Functions in Transact-SQL");
      ttpInfo.SetToolTip(cmdWildcards, "Use Wildcards and Ranges of Values in a SQL Query");
      ttpInfo.SetToolTip(cmdNotCorresponding, "Find Records in a Table Without Corresponding Entries in a Related Table");
      ttpInfo.SetToolTip(cmdSubQueries, "Locate Records with Duplicate Values");
      ttpInfo.SetToolTip(cmdTable, "Create, Modify and Delete Tables");
      ttpInfo.SetToolTip(cmdTableData, "Create a New Table with Data from Existing Tables");
      ttpInfo.SetToolTip(cmdUserDefinedFunction, "Create and Call SQL Server 2005 User Defined Functions");
    }
    // frmMainTryout_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMainTryout
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmMainTryout()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMainTryout());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMainTryout

}
// CopyPaste.Learning