//***
// Action
//   - An example of using an array
// Created
//   - CopyPaste � 20210827 � VVDW
// Changed
//   - Organisation � yyyymmdd � Initials of programmer � What changed
// Tested
//   - CopyPaste � 20210827 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;

namespace NamesAgesArrays
{

  class cpNameAgesArrays
	{

    static void Main()
    //***
    // Action
    //   - Define 2 arrays and a counter
    //   - Fill array of the names
    //   - Fill array of the ages
    //   - Loop thru items of array
    //     - Show the names with their ages
    //   - End nicely with a message
    // Called by
    //   - User action (by starting the program)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20210827 � VVDW
    // Changed
    //   - Organisation � yyyymmdd � Initials of programmer � What changed
    // Tested
    //   - CopyPaste � 20210827 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

    int[] intarrAges = new int[8];
    int intNumber;
    string[] strarrNames = new string[8];

    strarrNames[0] = "Thomas";
    intarrAges[0] = 32;
    strarrNames[1] = "James";
    intarrAges[1] = 20;
    strarrNames[2] = "Percy";
    intarrAges[2] = 24;
    strarrNames[3] = "Gordon";
    intarrAges[3] = 38;
    strarrNames[4] = "Harold";
    intarrAges[4] = 49;
    strarrNames[5] = "Terence";
    intarrAges[5] = 17;
    strarrNames[6] = "Annie";
    intarrAges[6] = 32;
    strarrNames[7] = "Clarabell";
    intarrAges[7] = 25;

    for (intNumber = 0; intNumber < 8; ++intNumber)
    {
      Console.WriteLine("{0} is {1} years old.", strarrNames[intNumber], intarrAges[intNumber]);
    }
    // intNumber = 8

    Console.WriteLine("");
    Console.WriteLine("Hit Enter");
    Console.ReadLine();
		}
    // Main()

	}
  // cpNameAgesArrays

}
// NamesAgesArrays