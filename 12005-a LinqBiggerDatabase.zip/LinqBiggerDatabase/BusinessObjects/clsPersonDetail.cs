﻿//***
// Action
//   - Definition of a PersonDetail
// Created
//   - CopyPaste – 20230713 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230713 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Text;

namespace CopyPaste.BusinessObjects
{

  [SerializableAttribute]
  public class PersonDetail
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    [MaxLengthAttribute(30)]
    public string City { get; set; }

    [MaxLengthAttribute(3)]
    public string Country { get; set; }

    [KeyAttribute]
    public int Id { get; set; }

    public string Memo { get; set; }
    public byte[] Photo { get; set; }

    // Will be used for demo a first migration
    // [MaxLengthAttribute(130)]
    // public string Planet { get; set; }

    // Will be used for demo a second migration
    // [MaxLengthAttribute(130)]
    // public string Quadrant { get; set; }

    [MaxLengthAttribute(30)]
    public string Street { get; set; }

    [MaxLengthAttribute(8)]
    public virtual string ZipCode { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // PersonDetail

}
// CopyPaste.BusinessObjects 