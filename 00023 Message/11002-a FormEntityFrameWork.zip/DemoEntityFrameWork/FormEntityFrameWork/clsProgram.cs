//***
// Action
//   - Starting up the application will create the database when needed
//     - Do not execute the "update-database" command in "Package Manager Console"
//     - If you do, a wrong database name will be created in the LocalDB SQL Server and seeding will fail
//   - This part is done with a library
//     - The console application, the Windows Form and the WPF Form is using the same library
//   - Create a database based on the class cpInfo using Entity Framework (version 6.4.4)
//   - Data will be seeded into it (but not when you first created the database)
//   - Query the table
// Created
//   - CopyPaste � 20230406 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230406 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormEntityFrameWork
{
  static class cpProgram
  {

    [STAThread]
    static void Main()
    {
      Application.SetHighDpiMode(HighDpiMode.SystemAware);
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);
      Application.Run(new frmWarnings());
    }
    // Main()

  }
  // cpProgram

}
// FormEntityFrameWork