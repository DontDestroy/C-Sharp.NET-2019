//***
// Action
//   - Definition of a cpBook
// Created
//   - CopyPaste � 20230804 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230804 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpBook
  {

    #region "Constructors / Destructors"

    public cpBook(string strTitle, string strAuthor, string strPublisher, double dblPrice)
      // ***
      //  Action
      //    - Constructor that sets four variables
      //  Called by
      //    - cpBestseller()
      //  Calls
      //    - cpProgram.Main()
      //  Created
      //    - CopyPaste � 20230804 � VVDW
      //  Changed
      //    - CopyPaste � yyyymmdd � VVDW � What changed
      //  Tested
      //    - CopyPaste � 20230804 � VVDW
      //  Keyboard key
      //    - 
      //  Proposal (To Do)
      //    - 
      // ***
    {
      mstrTitle = strTitle;
      mstrAuthor = strAuthor;
      mstrPublisher = strPublisher;
      mdblPrice = dblPrice;
    }
    // cpBook(string, string, string, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    public double mdblPrice;
    public string mstrAuthor;
    public string mstrPublisher;
    public string mstrTitle;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public virtual void ShowTitle()
      //***
      // Action
      //   - Shows the information of a cpBook
      // Called by
      //   - cpBestseller.ShowTitle()
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230804 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230804 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Title: " + mstrTitle);
      Console.WriteLine("Author: " + mstrAuthor);
      Console.WriteLine("Publisher: " + mstrPublisher);
      Console.WriteLine("Price: " + mdblPrice);
    }
    // ShowTitle()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpBook

}
// CopyPaste.Learning