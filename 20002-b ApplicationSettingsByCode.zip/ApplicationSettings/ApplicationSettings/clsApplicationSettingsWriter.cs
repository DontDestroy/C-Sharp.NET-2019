//***
// Action
//   - Write application settings to a certain file
// Created
//   - CopyPaste � 20260130 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260130 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;
using System.Xml;

namespace CopyPaste.Learning
{

  public class cpApplicationSettingsWriter
  {

    #region "Constructors / Destructors"

    public cpApplicationSettingsWriter()
      //***
      // Action
      //   - Create a new instance of cpApplicationSettingsWriter
      //   - Define a location string
      //   - Define an assembly
      //   - Get the current entry assembly
      //   - Initialize the location of the assembly to the location string
      //   - Create the config file name
      //   - If the file exists
      //     - Do nothing
      //   - If not
      //     - Create a default configuration settings file
      //   - Create a new XMLDocument instance
      //   - Load the config file name in the XMLDocument
      // Called by
      //   - frmApplicationSettings_Closing(System.Object, System.ComponentModel.CancelEventArgs) Handles this.Closing
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strName;
      System.Reflection.Assembly theAssembly;

      theAssembly = System.Reflection.Assembly.GetEntryAssembly();
      strName = theAssembly.Location;

      mstrConfigFileName = strName + ".config";

      if (File.Exists(mstrConfigFileName))
      {
      }
      else
        // Not File.Exists(mstrConfigFileName)
      {
        StreamWriter theStreamWriter = File.AppendText(mstrConfigFileName);

        theStreamWriter.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
        theStreamWriter.WriteLine("  <configuration>");
        theStreamWriter.WriteLine("    <appSettings>");
        theStreamWriter.WriteLine("    </appSettings>");
        theStreamWriter.WriteLine("  </configuration>");
        theStreamWriter.Flush();
        theStreamWriter.Close();
      }
      // File.Exists(mstrConfigFileName)

      mtheXmlDocument = new XmlDocument();
      mtheXmlDocument.Load(mstrConfigFileName);
    }
    // cpApplicationSettingsWriter()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private const char mchrQuote = '"';
    private string mstrConfigFileName;
    private XmlDocument mtheXmlDocument;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void SaveFile()
      //***
      // Action
      //   - Save the configuration settings file
      // Called by
      //   - frmApplicationSettings_Closing(System.Object, System.ComponentModel.CancelEventArgs) Handles this.Closing
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mtheXmlDocument.Save(mstrConfigFileName);
    }
    // SaveFile()

    public void SaveKeyValue(string strKey, string strValue)
      //***
      // Action Set
      //   - Add the setting to the configuration settings file with a given key and value
      //   - Create a query to find an existing node (configuration)
      //   - Select that node
      //   - If found
      //     - Change the value of that node
      //   - If not
      //     - Create that node with a specific key and value
      //     - Find the root node
      //     - If found
      //       - Add the created node to the root node
      //     - If not
      //       - Throw an exception with information about the error
      // Called by
      //   - frmApplicationSettings_Closing(System.Object, System.ComponentModel.CancelEventArgs) Handles this.Closing
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260130 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260130 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strQuery;
      XmlNode theXmlAttribute1;
      XmlNode theXmlAttribute2;
      XmlNode theXmlNode;
      XmlNode theXmlRoot;

      strQuery = "/configuration/appSettings/add[@key=" + mchrQuote + strKey + mchrQuote + "]";
      theXmlNode = mtheXmlDocument.DocumentElement.SelectSingleNode(strQuery);

      if (theXmlNode == null)
      {
        theXmlNode = mtheXmlDocument.CreateNode(XmlNodeType.Element, "add", "");

        theXmlAttribute1 = mtheXmlDocument.CreateNode(XmlNodeType.Attribute, "key", "");
        theXmlAttribute1.Value = strKey;
        theXmlNode.Attributes.SetNamedItem(theXmlAttribute1);

        theXmlAttribute2 = mtheXmlDocument.CreateNode(XmlNodeType.Attribute, "value", "");
        theXmlAttribute2.Value = strValue;
        theXmlNode.Attributes.SetNamedItem(theXmlAttribute2);

        strQuery = "/configuration/appSettings";
        theXmlRoot = mtheXmlDocument.DocumentElement.SelectSingleNode(strQuery);

        if (theXmlRoot == null)
        {
          throw new InvalidOperationException("Node is not added to the configuration file");
        }
        else
          // theXmlRoot <> null
        {
          theXmlRoot.AppendChild(theXmlNode);
        }
        // theXmlRoot = null
      
      }
      else
        // Not theXmlNode = null
      {
        theXmlNode.Attributes.GetNamedItem("value").Value = strValue;
      }
      // theXmlNode = null

    }
    // SaveKeyValue(string, string)
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpApplicationSettingsWriter

}
// CopyPaste.Learning