﻿//***
// Action
//   - Defines a Huffman tree
//   - A top node with branches under it
//   - At the bottom of the tree you have the leaves
// Created
//   - CopyPaste – 20220719 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220719 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Text;

namespace CopyPaste.Huffman_Code
{
  public class cpHuffmanTree
  {

    #region "Constructors / Destructors"

    public cpHuffmanTree(string strGivenText)
    //***
    // Action
    //   - Constructor of a cpHuffmanTree with a given text
    //   - Loop thru the characters and count them
    //     - Create a dictionary with those characters and the counts
    //     - Count the total number of characters
    //   - Loop thru the dictionary
    //     - Create a leaf cpHuffmanNode from it
    //     - Add this cpHuffmanNode to the dictionary of leaves
    //     - Add this cpHuffmanNode to a queue
    //   - Build up the tree
    //     - While the queue is more than 2 long
    //       - Sort the queue
    //       - Take a left branch
    //       - Take a right branch
    //       - Create a parent node with the 2 branches
    //       - Add the parent node to the queue
    //   - Loop thru the dictionary
    //     - Find the leaf 
    //     - Build up the Huffman Code going up to the root (Encode)
    //     - Add this Huffman code to the node
    // Called by
    //   - Main()
    // Calls
    //   - bool cpHuffmanNode.IsZero (Set)
    //   - cpHuffmanNode(cpHuffmanNode, cpHuffmanNode)
    //   - cpHuffmanNode(Int32, string)
    //   - cpHuffmanQueue()
    //   - cpHuffmanNode cpHuffmanQueue.Dequeue()
    //   - cpHuffmanQueue.Enqueue(cpHuffmanNode)
    //   - cpHuffmanQueue.Sort()
    //   - Encode(cpHuffmanNode)
    //   - int cpHuffmanQueue.Count (Get)
    // Created
    //   - CopyPaste – 20220719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Dictionary<char, Int32> dicCountCharacters = new Dictionary<char, Int32>();
      cpHuffmanQueue aQueue = new cpHuffmanQueue();

      foreach (char aCharacter in strGivenText)
      {

        if (dicCountCharacters.ContainsKey(aCharacter))
        {
          dicCountCharacters[aCharacter]++;
        }
        else
        // Not dicCountCharacters.ContainsKey(aCharacter)
        {
          dicCountCharacters[aCharacter] = 1;
        }
        // dicCountCharacters.ContainsKey(aCharacter)

      }
      // char in strGivenText

      foreach (char aCharacter in dicCountCharacters.Keys)
      {
        cpHuffmanNode aLeaf = new cpHuffmanNode(dicCountCharacters[aCharacter], aCharacter.ToString());
        dicLeafs[aCharacter.ToString()] = aLeaf;
        aQueue.Enqueue(aLeaf);
      }
      // char in dicCountCharacters.Keys

      while (aQueue.Count > 1)
      {
        aQueue.Sort();
        cpHuffmanNode leftBranch = aQueue.Dequeue();
        cpHuffmanNode rightBranch = aQueue.Dequeue();
        cpHuffmanNode aNode = new cpHuffmanNode(leftBranch, rightBranch);
        aQueue.Enqueue(aNode);
      }
      // aQueue.Count = 1

      if (aQueue.Count == 0)
      { 
      }
      else
      // aQueue.Count <> 0
      {
        rootHuffmanTree = aQueue.Dequeue();
        rootHuffmanTree.IsZero = false;
      }
      // aQueue.Count = 0

      foreach (char aCharacter in dicCountCharacters.Keys)
      {
        cpHuffmanNode aLeaf = dicLeafs[aCharacter.ToString()];
        Encode(aLeaf);
      }
      // char in dicCountCharacters.Keys

    }
    // cpHuffmanTree(string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    private readonly cpHuffmanNode rootHuffmanTree;
    private readonly Dictionary<string, cpHuffmanNode> dicLeafs = new Dictionary<string, cpHuffmanNode>();
    #endregion

    #region "Properties"

    public Dictionary<string, cpHuffmanNode> Leafs
    {

      get
      //***
      // Action Get
      //   - Returns the list of leafs in the Huffman tree
      // Called by
      //   - 
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20220719 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220719 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
      {
        return dicLeafs;
      }
      // Dictionary<string, cpHuffmanNode> Leafs() (Get)

    }
    // Dictionary<string, cpHuffmanNode> Leafs

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string Compress(string strGivenText)
    //***
    // Action
    //   - Compress a given string using the Huffman codes
    //   - Loop thru the characters
    //     - Add the Huffman code corresponding to the character in the result
    //   - Return result
    // Called by
    //   - Main()
    // Calls
    //   - string cpHuffmanNode.HuffmanCode() (Get)
    // Created
    //   - CopyPaste – 20220719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      string strResult = "";

      foreach (char aCharacter in strGivenText)
      {
        strResult += dicLeafs[aCharacter.ToString()].HuffmanCode;
      }
      // char in strGivenText

      return strResult;
    }
    // string Compress(string)

    public string Decompress(string strGivenCompressed)
    //***
    // Action
    //   - DeCompresses a given string using the Huffman codes
    //   - Loop thru the characters
    //     - If the character is 0
    //       - If leaf is also the root, do nothing
    //       - If Not, go to the leftBranch
    //       - If leaf
    //         - Add Value to strResult
    //         - Go back to the root
    //     - If Not, the character is 1
    //       - Go to the rightBranch
    //       - If leaf
    //         - Add Value to strResult
    //         - Go back to the root
    //   - Return result
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      cpHuffmanNode cpCurrentNode;
      string strResult = "";

      cpCurrentNode = rootHuffmanTree;

      foreach (char aCharacter in strGivenCompressed)
      {

        if (aCharacter == '0')
        {

          if (cpCurrentNode.IsLeaf && cpCurrentNode.IsRoot)
          { 
          }
          else
          {
            cpCurrentNode = cpCurrentNode.LeftBranch;
          }

          if (cpCurrentNode.IsLeaf)
          {
            strResult += cpCurrentNode.Value;
            cpCurrentNode = rootHuffmanTree;
          }
          else
          // Not cpCurrentNode.IsLeaf
          {
          }
          // cpCurrentNode.IsLeaf

        }
        else
        // aCharacter <> '0'
        {
          cpCurrentNode = cpCurrentNode.RightBranch;

          if (cpCurrentNode.IsLeaf)
          {
            strResult += cpCurrentNode.Value;
            cpCurrentNode = rootHuffmanTree;
          }
          else
          // Not cpCurrentNode.IsLeaf
          {
          }
          // cpCurrentNode.IsLeaf

        }
        // aCharacter = '0'

      }
      // char in strGivenText

      return strResult;
    }
    // string Decompress(string)

    private void Encode(cpHuffmanNode aLeaf)
    //***
    // Action
    //   - Encode every leaf in the tree towards a bitstring
    // Called by
    //   - cpHuffmanTree(string)
    // Calls
    //   - bool cpHuffmanNode.IsRoot() (Get)
    //   - cpHuffmanNode.HuffmanCode(string) (Set)
    //   - string cpHuffmanNode.HuffmanCode() (Get)
    // Created
    //   - CopyPaste – 20220719 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220719 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      cpHuffmanNode aNode;

      aNode = aLeaf;

      if (aNode.IsRoot)
      {
        aLeaf.HuffmanCode = "0";
      }
      // Not aNode.IsRoot
      else
      { 

        while (!aNode.IsRoot)
        {

          if (aNode.IsZero)
          {
            aLeaf.HuffmanCode = "0" + aLeaf.HuffmanCode;
          }
          else
          {
            aLeaf.HuffmanCode = "1" + aLeaf.HuffmanCode;
          }
          // aNode.IsZero

          aNode = aNode.Parent;
        }
        // aNode.IsRoot

      }
      // aNode.IsRoot

    }
    // Encode(cpHuffmanNode)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpHuffmanTree

}
// CopyPaste.Huffman_Code
