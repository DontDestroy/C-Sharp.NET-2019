//***
// Action
//   - Testroutine for cpPageContent, cpHTMLPage and cpWMLPage
// Created
//   - CopyPaste � 20240412 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240412 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Page
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
      //***
      // Action
      //   - Define a mobile page with content
      //   - Define a webpage with content
      //   - Show information of webpage
      //   - Show information of mobile page
      // Called by
      //   - cpHTMLPage(string)
      //   - cpHTMLPage.ShowPage()
      //   - cpWMLPage(string)
      //   - cpWMLPage.ShowPage()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240412 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240412 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpWMLPage thecpMobilePage = new cpWMLPage("Copy Paste");
      cpHTMLPage thecpWebPage = new cpHTMLPage("<a href=\"www.CopyPaste.com\">Copy Paste</a>");

      thecpWebPage.ShowPage();
      Console.WriteLine();
      thecpMobilePage.ShowPage();
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning.Page
