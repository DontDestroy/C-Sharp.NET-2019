﻿//***
// Action
//   - Example of Overloading Functions
//   - There are errors in it (Overloading does not work when only output is different)
// Created
//   - CopyPaste – 20220815 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220815 – VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Overload_WPF
{

  public partial class wpfOverload : Window
  {

    #region "Constructors / Destructors"

    public wpfOverload()
    //***
    // Action
    //   - Create instance of 'wpfOverload'
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220815 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220815 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfOverload()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void Window_Loaded(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Show the squares of an integer of an double
    // Called by
    //   - System action (Loading a form)
    // Calls
    //   - double Square(double)
    //   - Environment.NewLine()
    //   - long Square(long)
    // Created
    //   - CopyPaste – 20220815 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220815 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      lblOutput.Content = "The square of Integer 7 is " + Square(7) + Environment.NewLine +
        "The square of Double 7.5 is " + Square(7.5);
    }
    // Window_Loaded(System.Object, System.Windows.RoutedEventArgs) Handles Windows.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static long Square(double dblValue)
    //***
    // Action
    //   - Multiply a double with itself
    // Called by
    //   - Window_Loaded(System.Object, System.Windows.RoutedEventArgs) Handles Windows.Load
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220815 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220815 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return Convert.ToInt64(dblValue * dblValue);
    }
    // long Square(long)

    static double Square(double dblValue)
    //***
    // Action
    //   - Multiply a double with itself
    // Called by
    //   - Window_Loaded(System.Object, System.Windows.RoutedEventArgs) Handles Windows.Load
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220815 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220815 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      return dblValue * dblValue;
    }
    // double Square(double)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfOverload 

}
// Overload_WPF
