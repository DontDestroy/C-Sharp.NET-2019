//***
// Action
//   - 
// Created
//   - CopyPaste � 20220815 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220815 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LoadFromCommandLine
{
  public partial class FileViewer : Window
  {

    #region "Constructors / Destructors"

    public FileViewer()
    //***
    // Action
    //   - Constructor of FileViewer
    // Called by
    //   - cpStartup.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220815 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220815 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      InitializeComponent();
    }
    // FileViewer()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void LoadFile(string strPath)
    //***
    // Action
    //   - Read all text from a certain file
    //   - Place that into the content of the Window
    //   - Place the value strPath as text of the Window
    // Called by
    //   - cpStartup.ApplicationStartup(System.Object, System.Windows.StartupEventArgs)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220815 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220815 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      this.Content = File.ReadAllText(strPath);
      this.Title = strPath;
    }
    // LoadFile(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // FileViewer

}
// LoadFromCommandLine 