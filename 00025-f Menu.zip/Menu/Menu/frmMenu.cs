//***
// Action
//   - An example of a menu with menu items
// Created
//   - CopyPaste � 20240411 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240411 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmMenu: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.MainMenu mnuMain;
    internal System.Windows.Forms.MenuItem mnuClock;
    internal System.Windows.Forms.MenuItem mnuClockDate;
    internal System.Windows.Forms.MenuItem mnuClockTime;
    internal System.Windows.Forms.Label lblClock;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMenu));
      this.mnuMain = new System.Windows.Forms.MainMenu();
      this.mnuClock = new System.Windows.Forms.MenuItem();
      this.mnuClockDate = new System.Windows.Forms.MenuItem();
      this.mnuClockTime = new System.Windows.Forms.MenuItem();
      this.lblClock = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // mnuMain
      // 
      this.mnuMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuClock});
      // 
      // mnuClock
      // 
      this.mnuClock.Index = 0;
      this.mnuClock.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                             this.mnuClockDate,
                                                                             this.mnuClockTime});
      this.mnuClock.Text = "&Clock";
      // 
      // mnuClockDate
      // 
      this.mnuClockDate.Index = 0;
      this.mnuClockDate.Text = "&Date";
      this.mnuClockDate.Click += new System.EventHandler(this.mnuClockDate_Click);
      // 
      // mnuClockTime
      // 
      this.mnuClockTime.Index = 1;
      this.mnuClockTime.Text = "&Time";
      this.mnuClockTime.Click += new System.EventHandler(this.mnuClockTime_Click);
      // 
      // lblClock
      // 
      this.lblClock.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblClock.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblClock.Location = new System.Drawing.Point(74, 72);
      this.lblClock.Name = "lblClock";
      this.lblClock.Size = new System.Drawing.Size(144, 48);
      this.lblClock.TabIndex = 1;
      this.lblClock.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // frmMenu
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 293);
      this.Controls.Add(this.lblClock);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Menu = this.mnuMain;
      this.Name = "frmMenu";
      this.Text = "Menu";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMenu'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMenu()
      //***
      // Action
      //   - Create instance of 'frmMenu'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmMenu()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void mnuClockDate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The clock gets the date in day, month and year
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblClock.Text = DateTime.Now.ToString("dd/MM/yyyy");    
    }
    // mnuClockDate_Click(System.Object, System.EventArgs) Handles mnuClockDate.Click
    
    private void mnuClockTime_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The clock gets the time in hours, minutes and seconds
      // Called by
      //   - User action (Clicking a menu item)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblClock.Text = DateTime.Now.ToString("HH:mm:ss");
    }
    // mnuClockTime_Click(System.Object, System.EventArgs) Handles mnuClockTime.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMenu
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmMenu()
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMenu());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMenu

}
// CopyPaste.Learning