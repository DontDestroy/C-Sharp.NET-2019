//***
// Action
//   - Options with Checkboxes and Option buttons
// Created
//   - CopyPaste � 20240129 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240129 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

	public class frmCheckTheRadio: System.Windows.Forms.Form
	{

		#region Windows Form Designer generated code

		private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.GroupBox grpBackGround;
    internal System.Windows.Forms.RadioButton optYellow;
    internal System.Windows.Forms.RadioButton optWhite;
    internal System.Windows.Forms.CheckBox chkTitleBox;
    internal System.Windows.Forms.Label lblChoose;
    internal System.Windows.Forms.GroupBox grpForeGround;
    internal System.Windows.Forms.RadioButton optBlue;
    internal System.Windows.Forms.RadioButton optBlack;

		private void InitializeComponent()
		{
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmCheckTheRadio));
      this.grpBackGround = new System.Windows.Forms.GroupBox();
      this.optYellow = new System.Windows.Forms.RadioButton();
      this.optWhite = new System.Windows.Forms.RadioButton();
      this.chkTitleBox = new System.Windows.Forms.CheckBox();
      this.lblChoose = new System.Windows.Forms.Label();
      this.grpForeGround = new System.Windows.Forms.GroupBox();
      this.optBlue = new System.Windows.Forms.RadioButton();
      this.optBlack = new System.Windows.Forms.RadioButton();
      this.grpBackGround.SuspendLayout();
      this.grpForeGround.SuspendLayout();
      this.SuspendLayout();
      // 
      // grpBackGround
      // 
      this.grpBackGround.Controls.Add(this.optYellow);
      this.grpBackGround.Controls.Add(this.optWhite);
      this.grpBackGround.Location = new System.Drawing.Point(32, 104);
      this.grpBackGround.Name = "grpBackGround";
      this.grpBackGround.Size = new System.Drawing.Size(128, 136);
      this.grpBackGround.TabIndex = 6;
      this.grpBackGround.TabStop = false;
      this.grpBackGround.Text = "Background Color";
      // 
      // optYellow
      // 
      this.optYellow.Location = new System.Drawing.Point(24, 64);
      this.optYellow.Name = "optYellow";
      this.optYellow.Size = new System.Drawing.Size(72, 24);
      this.optYellow.TabIndex = 1;
      this.optYellow.Text = "&Yellow";
      this.optYellow.CheckedChanged += new System.EventHandler(this.optYellow_CheckedChanged);
      // 
      // optWhite
      // 
      this.optWhite.Location = new System.Drawing.Point(24, 32);
      this.optWhite.Name = "optWhite";
      this.optWhite.Size = new System.Drawing.Size(72, 24);
      this.optWhite.TabIndex = 0;
      this.optWhite.Text = "&White";
      this.optWhite.CheckedChanged += new System.EventHandler(this.optWhite_CheckedChanged);
      // 
      // chkTitleBox
      // 
      this.chkTitleBox.Location = new System.Drawing.Point(24, 64);
      this.chkTitleBox.Name = "chkTitleBox";
      this.chkTitleBox.TabIndex = 5;
      this.chkTitleBox.Text = "&Title has box";
      this.chkTitleBox.CheckedChanged += new System.EventHandler(this.chkTitleBox_CheckedChanged);
      // 
      // lblChoose
      // 
      this.lblChoose.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblChoose.Location = new System.Drawing.Point(8, 8);
      this.lblChoose.Name = "lblChoose";
      this.lblChoose.Size = new System.Drawing.Size(312, 32);
      this.lblChoose.TabIndex = 4;
      this.lblChoose.Text = "Choose your options";
      this.lblChoose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // grpForeGround
      // 
      this.grpForeGround.Controls.Add(this.optBlue);
      this.grpForeGround.Controls.Add(this.optBlack);
      this.grpForeGround.Location = new System.Drawing.Point(168, 104);
      this.grpForeGround.Name = "grpForeGround";
      this.grpForeGround.Size = new System.Drawing.Size(128, 136);
      this.grpForeGround.TabIndex = 7;
      this.grpForeGround.TabStop = false;
      this.grpForeGround.Text = "Foreground Color";
      // 
      // optBlue
      // 
      this.optBlue.Location = new System.Drawing.Point(24, 64);
      this.optBlue.Name = "optBlue";
      this.optBlue.Size = new System.Drawing.Size(72, 24);
      this.optBlue.TabIndex = 1;
      this.optBlue.Text = "B&lue";
      this.optBlue.CheckedChanged += new System.EventHandler(this.optBlue_CheckedChanged);
      // 
      // optBlack
      // 
      this.optBlack.Location = new System.Drawing.Point(24, 32);
      this.optBlack.Name = "optBlack";
      this.optBlack.Size = new System.Drawing.Size(72, 24);
      this.optBlack.TabIndex = 0;
      this.optBlack.Text = "&Black";
      this.optBlack.CheckedChanged += new System.EventHandler(this.optBlack_CheckedChanged);
      // 
      // frmCheckTheRadio
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(328, 271);
      this.Controls.Add(this.grpBackGround);
      this.Controls.Add(this.chkTitleBox);
      this.Controls.Add(this.lblChoose);
      this.Controls.Add(this.grpForeGround);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.Name = "frmCheckTheRadio";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "CheckBox, RadioButton and GroupBox";
      this.grpBackGround.ResumeLayout(false);
      this.grpForeGround.ResumeLayout(false);
      this.ResumeLayout(false);

    }
		// InitializeComponent()
//
		#endregion

		#region "Constructors / Destructors"

		protected override void Dispose(bool disposing)
			//***
			// Action
			//   - Clean up instance of 'frmCheckTheRadio'
			// Called by
			//   - User action (Closing the form)
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240129 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240129 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{

			if(disposing)
			{

				if (components == null) 
				{
				}
				else
					// (components != null)
				{
					components.Dispose();
				}
				// (components == null)
      
			}
			else
				// Not disposing
			{
			}
			// disposing

			base.Dispose(disposing);
		}
		// Dispose(bool)

		public frmCheckTheRadio()
			//***
			// Action
			//   - Create instance of 'frmCheckTheRadio'
			// Called by
			//   - Main()
			// Calls
			//   - 
			// Created
			//   - CopyPaste � 20240129 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240129 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			InitializeComponent();
		}
		// frmCheckTheRadio()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		#region "Controls"
   
    private void chkTitleBox_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Changing the way a border around a text is shown
      // Called by
      //   - User action (Clicking a checkbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240129 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240129 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (chkTitleBox.Checked)
      {
        lblChoose.BorderStyle = BorderStyle.FixedSingle;
      }
      else
        // Not chkTitleBox.Checked
      {
        lblChoose.BorderStyle = BorderStyle.None;
      }
      // chkTitleBox.Checked

    }
    // chkTitleBox_CheckedChanged(System.Object, System.EventArgs) Handles chkTitleBox.CheckedChanged

    private void optBlack_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Changing the colour of a text to black
      // Called by
      //   - User action (Clicking an optionbutton)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240129 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240129 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblChoose.ForeColor = Color.Black;
    }
    // optBlack_CheckedChanged(System.Object, System.EventArgs) Handles optBlack.CheckedChanged

    private void optBlue_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Changing the colour of a text to blue
      // Called by
      //   - User action (Clicking an optionbutton)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240129 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240129 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblChoose.ForeColor = Color.Blue;
    }
    // optBlue_CheckedChanged(System.Object, System.EventArgs) Handles optBlue.CheckedChanged

    private void optWhite_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Changing the background colour of a textbox to white
      // Called by
      //   - User action (Clicking an optionbutton)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240129 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240129 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblChoose.BackColor = Color.White;
    }
    // optWhite_CheckedChanged(System.Object, System.EventArgs) Handles optWhite.CheckedChanged

    private void optYellow_CheckedChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Changing the background colour of a textbox to yellow
      // Called by
      //   - User action (Clicking an optionbutton)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240129 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240129 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      lblChoose.BackColor = Color.Yellow;
    }
    // optYellow_CheckedChanged(System.Object, System.EventArgs) Handles optYellow.CheckedChanged

		#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		static void Main() 
			//***
			// Action
			//   - Start application
			//   - Showing frmCheckTheRadio
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - frmCheckTheRadio()
			// Created
			//   - CopyPaste � 20240129 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240129 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - 
			//***
		{
			Application.Run(new frmCheckTheRadio());
		}
		// Main() 
    
		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// frmCheckTheRadio

}
// CopyPaste.Learning