﻿//***
// Action
//   - Definition of a Die
//   - A Die is a randomizer with a number of faces (e.g. A die with 6 options)
// Created
//   - CopyPaste – 20251106 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251106 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;
using System;

namespace cpKarelTheRobot
{

	public class cpDie
	{

		#region "Constructors / Destructors"

		public cpDie(int intFaces)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - A die with a number of faces
    //   - A normal die has 6
    //   - A coin die has 2
    // Called by
    //   - cpDeadLock(int, int, Directions.Direction, int, Color)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      numberOfFaces = intFaces;
    }
		// cpDie(int)

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		#region "Fields"

		private int numberOfFaces;
		private Random theRandom = new Random(DateTime.Now.Millisecond);

		#endregion

		#region "Properties"

		public int Faces
		{ 

			get
      //***
      // Action Get
      //   - Return numberOfFaces
      // Called by
      //   - int Roll()
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20251106 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20251106 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return numberOfFaces;
			}
			// int Faces (Get)

		}
		// int Faces

		#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public int Roll()
    //***
    // Action
    //   - Take a number randomly
    //   - Divide this by the number of faces and add 1
    //   - When 6 faces, you have a random number between 1 and 6 (borders included)
    //   - That value is returned (abs is returned, because an integer can be negative
    // Called by
    //   - cpDeadLock.run()
    // Calls
    //   - int Faces (Get)
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
			return Math.Abs(theRandom.Next() % Faces + 1);
    }
    // int Roll()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpDie

}
// cpKarelTheRobot