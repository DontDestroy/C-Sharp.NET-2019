﻿//***
// Action
//   - Implementation of cpIntegerDivision
// Created
//   - CopyPaste – 20260128 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260128 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpIntegerDivision : cpCalculation 
  {

    #region "Constructors / Destructors"

    public cpIntegerDivision() : this(1, 1)
    //***
    // Action
    //   - Basic constructor with no parameters
    // Called by
    //   - 
    // Calls
    //   - cpMultiplication(int, int)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpIntegerDivision()

    public cpIntegerDivision(int intFirstValue, int intSecondValue)
    //***
    // Action
    //   - Basic constructor with 2 parameters
    // Called by
    //   - cpIntegerDivision()
    //   - cpProgram.Main()
    // Calls
    //   - FirstValue(int) (Set)
    //   - SecondValue(int) (Set)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      FirstValue = intFirstValue;
      SecondValue = intSecondValue;
    }
    // cpIntegerDivision(int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public override int FirstValue
    {
      
      get
      //***
      // Action Get
      //   - Return _firstValue
      // Called by
      //   - int Calculate()
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        return _firstValue;
      }
      // int FirstValue (Get)

      set
      //***
      // Action Set
      //   - _firstValue becomes value
      // Called by
      //   - cpIntegerDivision(int, int)
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        _firstValue = value;
      }
      // FirstValue(int) (Set)

    }
    // int FirstValue

    public override int SecondValue
    {

      get
      //***
      // Action Get
      //   - Return _secondValue
      // Called by
      //   - int Calculate()
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        return _secondValue;
      }
      // int SecondValue (Get)

      set
      //***
      // Action Set
      //   - _secondValue becomes value
      // Called by
      //   - cpIntegerDivision(int, int)
      // Calls
      //   -
      // Created
      //   - CopyPaste – 20260128 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20260128 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
      {
        _secondValue = value;
      }
      // FirstValue(int) (Set)

    }
    // int FirstValue

    #endregion

    #region "Methods"

    #region "Overrides"

    public override int Calculate()
    //***
    // Action
    //   - Return the integer (whole) division of two values
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - int FirstValue (Get)
    //   - int SecondValue (Get)
    // Created
    //   - CopyPaste – 20260128 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260128 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      int intResult;

      if (SecondValue == 0)
      {
        intResult = 0;
      }
      else
      // SecondValue <> 0
      {
        intResult = FirstValue / SecondValue;
      }
      // SecondValue = 0

      return intResult;
    }
    // int Calculate()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpMultiplication

}
// CopyPaste.Learning