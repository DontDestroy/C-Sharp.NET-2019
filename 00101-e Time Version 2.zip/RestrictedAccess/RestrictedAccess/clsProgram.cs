//***
// Action
//   - Demo the class cpTime that fails
// Created
//   - CopyPaste � 20220301 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220301 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Toolkit.Time
{

  class cpProgram
	{

    static void Main()
    //***
    // Action
    //   - Define an instance of cpTime (thecpTime)
    //   - Try to access mintHour
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - cpTime.New()
    //   - int cpTime.mintHour()
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpTime thecpTime = new cpTime();

      thecpTime.mintHour = 7;
		}
    // Main()

  }
  // cpProgram

}
// CopyPaste.Learning.Toolkit.Time