﻿//***
// Action
//   - Definition of a Person class
// Created
//   - CopyPaste – 20221211 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20221211 – VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpPerson
  {

    #region "Constructors / Destructors"

    public cpPerson()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - User action (Creating an instance)
    //   - cpAlumnus()
    //   - cpLecturer()
    //   - cpStudent()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20221211 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20221211 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpPerson()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public int Age { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpPerson

}
// CopyPaste.Learning