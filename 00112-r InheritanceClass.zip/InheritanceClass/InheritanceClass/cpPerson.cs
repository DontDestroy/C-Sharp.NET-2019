//***
// Action
//   - Implementation of cpPerson
// Created
//   - CopyPaste � 20240525 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240525 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpPerson
  {

    #region "Constructors / Destructors"

    public cpPerson()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpTeacher()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240525 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240525 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpPerson()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private string mstrFirstName;
    private string mstrLastName;

    #endregion

    #region "Properties"

    public string FirstName
    {

      get
        //***
        // Action Get
        //   - Returns mstrFirstName
        // Called by
        //   - frmEmployee.cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240525 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240525 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrFirstName;
      }
      // string FirstName (Get)

      set
        //***
        // Action Set
        //   - mstrFirstName becomes value
        // Called by
        //   - frmEmployee.cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240525 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240525 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mstrFirstName = value;
      }
      // FirstName(string) (Set)

    }
    // string FirstName

    public string LastName
    {

      get
        //***
        // Action Get
        //   - Returns mstrLastName
        // Called by
        //   - frmEmployee.cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240525 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240525 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mstrLastName;
      }
      // string LastName (Get)

      set
        //***
        // Action Set
        //   - mstrLastName becomes value
        // Called by
        //   - frmEmployee.cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240525 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240525 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mstrLastName = value;
      }
      // LastName(string) (Set)

    }
    // string LastName

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public int Age(DateTime dtmBirthday)
      //***
      // Action
      //   - Calculate the age with a given birthdate
      // Called by
      //   - frmEmployee.cmdDisplay_Click(System.Object, System.EventArgs) Handles cmdDisplay.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240525 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240525 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - The way of calculating the age is correct for 99.95% of the cases (not 100%)
      //***
    {
      return Convert.ToInt16(DateTime.Now.Subtract(dtmBirthday).Days / 365.25);
    }
    // int Age(DateTime)
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx