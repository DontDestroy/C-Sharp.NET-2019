//***
// Action
//   - Show a listbox bound to a data set but with a filter (limitation)
// Created
//   - CopyPaste � 20251231 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251231 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmListBoxLimitWizard: System.Windows.Forms.Form
  {
    private IContainer components;

    #region Windows Form Designer generated code
    internal System.Windows.Forms.Button cmdLoadList;
    internal System.Windows.Forms.Label lblCustomer;
    internal System.Windows.Forms.TextBox txtCustomerLimit;
    private BindingSource bdsrcCustomerFilter;
    private BoundControlWizard.dsCustomerFilter dsCustomerFilter;
    private BoundControlWizard.dsCustomerFilterTableAdapters.tbaCustomerFilter tbaCustomerFilter;
    internal System.Windows.Forms.ListBox lstListBox;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmListBoxLimitWizard));
      this.cmdLoadList = new System.Windows.Forms.Button();
      this.lblCustomer = new System.Windows.Forms.Label();
      this.txtCustomerLimit = new System.Windows.Forms.TextBox();
      this.lstListBox = new System.Windows.Forms.ListBox();
      this.dsCustomerFilter = new BoundControlWizard.dsCustomerFilter();
      this.bdsrcCustomerFilter = new System.Windows.Forms.BindingSource(this.components);
      this.tbaCustomerFilter = new BoundControlWizard.dsCustomerFilterTableAdapters.tbaCustomerFilter();
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomerFilter)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCustomerFilter)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdLoadList
      // 
      this.cmdLoadList.Location = new System.Drawing.Point(288, 9);
      this.cmdLoadList.Name = "cmdLoadList";
      this.cmdLoadList.Size = new System.Drawing.Size(88, 24);
      this.cmdLoadList.TabIndex = 6;
      this.cmdLoadList.Text = "Load List";
      this.cmdLoadList.Click += new System.EventHandler(this.cmdLoadList_Click);
      // 
      // lblCustomer
      // 
      this.lblCustomer.Location = new System.Drawing.Point(8, 9);
      this.lblCustomer.Name = "lblCustomer";
      this.lblCustomer.Size = new System.Drawing.Size(56, 16);
      this.lblCustomer.TabIndex = 4;
      this.lblCustomer.Text = "Customer";
      // 
      // txtCustomerLimit
      // 
      this.txtCustomerLimit.Location = new System.Drawing.Point(72, 9);
      this.txtCustomerLimit.Name = "txtCustomerLimit";
      this.txtCustomerLimit.Size = new System.Drawing.Size(208, 20);
      this.txtCustomerLimit.TabIndex = 5;
      this.txtCustomerLimit.Text = "A";
      // 
      // lstListBox
      // 
      this.lstListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
      this.lstListBox.DataSource = this.bdsrcCustomerFilter;
      this.lstListBox.DisplayMember = "strCompanyName";
      this.lstListBox.Location = new System.Drawing.Point(8, 41);
      this.lstListBox.Name = "lstListBox";
      this.lstListBox.Size = new System.Drawing.Size(368, 290);
      this.lstListBox.TabIndex = 7;
      this.lstListBox.ValueMember = "strCompanyName";
      // 
      // dsCustomerFilter
      // 
      this.dsCustomerFilter.DataSetName = "dsCustomerFilter";
      this.dsCustomerFilter.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // bdsrcCustomerFilter
      // 
      this.bdsrcCustomerFilter.DataMember = "tblCPCustomer";
      this.bdsrcCustomerFilter.DataSource = this.dsCustomerFilter;
      // 
      // tbaCustomerFilter
      // 
      this.tbaCustomerFilter.ClearBeforeFill = true;
      // 
      // frmListBoxLimitWizard
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(384, 341);
      this.Controls.Add(this.txtCustomerLimit);
      this.Controls.Add(this.lstListBox);
      this.Controls.Add(this.cmdLoadList);
      this.Controls.Add(this.lblCustomer);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmListBoxLimitWizard";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Limiting Data in a Bound Listbox Wizard";
      ((System.ComponentModel.ISupportInitialize)(this.dsCustomerFilter)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcCustomerFilter)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmListBoxLimitWizard'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmListBoxLimitWizard()
      //***
      // Action
      //   - Create instance of 'frmListBoxLimitWizard'
      // Called by
      //   - frmBoundControlsMainWizard.cmdListBoxLimit_Click(System.Object, System.EventArgs) Handles cmdListBoxLimit.Click
      // Calls
      //   - cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      cmdLoadList_Click(new System.Object(), new System.EventArgs());
    }
    // frmListBoxLimitWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdLoadList_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set the parameter of the select command to the text on the form
      //   - Clear the data set
      //   - Fill the data set using the data adapter
      // Called by
      //   - User action (Clicking a button)
      //   - frmListBoxLimitWizard()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251231 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251231 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsCustomerFilter.Clear();
      tbaCustomerFilter.Fill(dsCustomerFilter.tblCPCustomer, txtCustomerLimit.Text);
    }
    // cmdLoadList_Click(System.Object, System.EventArgs) Handles cmdLoadList.Click

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmListBoxLimitWizard

}
// CopyPaste.Learning