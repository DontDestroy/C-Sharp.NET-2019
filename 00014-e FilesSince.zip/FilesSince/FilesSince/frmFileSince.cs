//***
// Action
//   - Show files that are changed since a specific date
// Created
//   - CopyPaste � 20240207 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240207 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFileSince: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdFind;
    internal System.Windows.Forms.DateTimePicker dtpDate;
    internal System.Windows.Forms.TextBox txtResult;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFileSince));
      this.cmdFind = new System.Windows.Forms.Button();
      this.dtpDate = new System.Windows.Forms.DateTimePicker();
      this.txtResult = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdFind
      // 
      this.cmdFind.Location = new System.Drawing.Point(168, 304);
      this.cmdFind.Name = "cmdFind";
      this.cmdFind.Size = new System.Drawing.Size(112, 23);
      this.cmdFind.TabIndex = 5;
      this.cmdFind.Text = "Find Files";
      this.cmdFind.Click += new System.EventHandler(this.cmdFind_Click);
      // 
      // dtpDate
      // 
      this.dtpDate.Location = new System.Drawing.Point(128, 256);
      this.dtpDate.Name = "dtpDate";
      this.dtpDate.TabIndex = 4;
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(32, 32);
      this.txtResult.Multiline = true;
      this.txtResult.Name = "txtResult";
      this.txtResult.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.txtResult.Size = new System.Drawing.Size(408, 208);
      this.txtResult.TabIndex = 3;
      this.txtResult.Text = "";
      // 
      // frmFileSince
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(472, 349);
      this.Controls.Add(this.cmdFind);
      this.Controls.Add(this.dtpDate);
      this.Controls.Add(this.txtResult);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFileSince";
      this.Text = "Files Since";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFileSince'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFileSince()
      //***
      // Action
      //   - Create instance of 'frmFileSince'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
      dtpDate.Value = DateTime.Today.AddDays(-1);
    }
    // frmFileSince()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public DateTime mdtmSearch;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdFind_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Find the files that are changed since
      //   - By default, I'm taking hard disk T:\
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - FindFiles(string)
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtResult.Text = "";
      mdtmSearch = dtpDate.Value;
      FindFiles("T:\\");
    }
    // cmdFind_Click(System.Object, System.EventArgs) Handles cmdFind.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private void FindFiles(string strDirectory)
      //***
      // Action
      //   - Get all the files and directories form strDirectory location
      //   - Create a text with all the fullnames of files that have a last change date after the choosen date
      //   - Loop thru all the files in the files list
      //     - If file is changed after choosen date
      //       - Add the filename to the textbox
      //   - Loop thru all the directories in the directory list
      //     - Restart FindFiles with current directory
      //   - Show an error when directory is not accessible
      // Called by
      //   - cmdFind_Click(System.Object, System.EventArgs) Handles cmdFind.Click
      //   - FindFiles(string)
      // Calls
      //   - FindFiles(string)
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - There is a recursive technique in this solution
      //***
    {
      DirectoryInfo theDirectory = new DirectoryInfo(strDirectory);
      DirectoryInfo[] arrDirectory = theDirectory.GetDirectories("*.*");
      FileInfo[] arrFile = theDirectory.GetFiles("*.*");

      foreach (FileInfo theFileName in arrFile)
      {
        
        if (theFileName.LastWriteTime > mdtmSearch)
        {
          txtResult.AppendText(theFileName.FullName + Environment.NewLine);
        }
        else
          // theFileName.LastWriteTime <= mdtmSearch
        {
        }
        // theFileName.LastWriteTime > mdtmSearch
  
      }
      // in arrFile

      foreach (DirectoryInfo theDirectoryName in arrDirectory)
      {

        try
        {
          FindFiles(theDirectoryName.FullName);
        }
        catch (Exception theException)
        {
          MessageBox.Show("*** Error accessing " + theDirectoryName.FullName);
        }

      }
      // In arrDirectory

    }
    // FindFiles(string)

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFileSince
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240207 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240207 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFileSince());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmFileSince

}
// CopyPaste.Learning