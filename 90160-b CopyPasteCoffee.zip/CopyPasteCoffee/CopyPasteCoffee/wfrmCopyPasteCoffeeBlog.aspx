﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCopyPasteCoffeeBlog.aspx.cs" Inherits="CopyPaste.Learning.wfrmCopyPasteCoffeeBlog" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Copy Paste Coffee Blog</title>
  <link rel="stylesheet" type="text/css" href="cssCopyPasteCoffeeBlog.css">
</head>
<body>
  <form id="wfrmCopyPasteCoffeeBlog">
    <header class="Top">
      <img id="HeaderLogo" src="./Resources/HeaderLogo.gif" alt="Copy Paste Coffee Header Logo">
      <img id="HeaderSlogan" src="./Resources/HeaderSlogan.gif" alt="Copy Paste Coffee Header Slogan">
    </header>
    <nav>
      <ul>
        <li><a href="wfrmCopyPasteCoffee.aspx">Home</a></li>
        <li class="Selected"><a href="wfrmCopyPasteCoffeeBlog.aspx">Blog</a></li>
        <li><a href="DoesNotExistYet.html">Inventions</a></li>
        <li><a href="DoesNotExistYet.html">Recipes</a></li>
        <li><a href="DoesNotExistYet.html">Locations</a></li>
      </ul>
    </nav>
    <div id="TableContainer">
      <div id="TableRow">
        <section id="Drinks">
          <h1>BEVERAGES</h1>
          <p>Cappuccino, € 1.89</p>
          <p>Chai Tea, € 2.85</p>
          <p>House Blend, € 2.49</p>
          <p>Mocha Cafe Latte, € 2.35</p>
          <h1>ELIXIRS</h1>
          <p>
            We proudly serve elixirs brewed by our friends at the Copy Paste Lounge.
          </p>
          <p>Black Brain Brew, € 2.99</p>
          <p>Blueberry Bliss Elixir, € 2.99</p>
          <p>Chai Chiller, € 2.99</p>
          <p>Cranberry Antioxidant Blast, € 2.99</p>
          <p>Green Tea Cooler, € 2.99</p>
          <p>Raspberry Ice Concentration, € 2.99</p>
        </section>
        <section id="CopyPasteBlog">
          <article>
            <header>
              <h1>Copy Paste Coffee launches Tweeter</h1>
              <time datetime="2026-07-04">04/07/2026</time>
            </header>
            <p>
              As promised, today I'm proud to announce that Copy Paste Coffee is launching the Tweeter cup,
              a special Copy Paste Coffee cup that tweets each time you take a sip!
              Check out my video of our new invention.
            </p>
            <video id="vidTweeter" controls autoplay muted width="512" height="288" poster="./Resources/Poster Tweeter.png">
              <source src="./Resources/Tweeter.mp4" type="video/mp4">
              <source src="./Resources/Tweeter.webm" type="video/webm">
              <source src="./Resources/Tweeter.ogv" type="video/ogg">
              <p>Sorry, your browser doesn't support the video element.</p>
            </video>
          </article>
          <article>
            <header>
              <h1>Copy Paste Coffee meets social media</h1>
              <time datetime="2026-06-25">25/06/2026</time>
            </header>
            <p>
              Here at Copy Paste Coffee we're embracing the social media craze.
              In fact, we're going further than any of our competitors and we're very close to announcing
              a revolutionary new product that links your coffee drinking directly to your social network.
              Forget "checking in"; we're going way beyond that, and with this new product every sip of smooth,
              aromatic, hot Copy Paste Coffee blend is going to to be shared with your social network.
            </p>
            <p>
              Sound like science fiction? It's not; I'm already testing our final prototype social network cup
              as I write this, which links you, the drinker, right to your favorite social networks.
              We've made a huge investment to make this happen and we've created a reusable coffee cup complete with RFID,
              NFC, Bluetooth, and Wifi (not to mention a few more things the tech folks know about,
              because hey, I'm just the coffee guy).
            </p>
            <p>
              So, keep your eyes out for this amazing new cup. And I'll be releasing a video teaser soon
              to tell you all about this new invention, straight from Copy Paste Coffee.
            </p>
          </article>
          <article>
            <header>
              <h1>Copy Paste Coffee uses computer science</h1>
              <time datetime="2026-07-10">10/07/2026</time>
            </header>
            <p>
              Have you ever noticed how efficient a Copy Paste Coffee house is?
              The lines always move fast, and despite the astronomical number of different drinks any customer can order,
              we have your drink up, hot (or cold if that's the way you want it) and ready in seconds. How do we do it? 
            </p>
            <p>
              To pull this off, we take advantage of the latest and greatest in computer science.
              In fact, we train our staff to be one big distributed computer. The cashiers create the orders
              for the distributed computer, complete with your name and the drinks special instructions.
              Then our specialized drink makers grab the next cup and go about working on your order until it's finished.  
            </p>
            <p>
              With this design, we are able to horizontally scale our operation any time we want.
              All we need to do is add more cashiers and drink makers (not to mention a fair amount
              of support staff you never see) as the customer flow grows.
            </p>
          </article>
          <article>
            <header>
              <h1>Most unique patron of the month	</h1>
              <time datetime="2026-07-20">20/07/2026</time>
            </header>
            <p>
              Our most unique patron of the month award goes to a customer in Poulsbo, Washington,
              whose daily morning order is a "six-splenda, no-foam, 130-degree non-fat-soy latte,
              with the splenda stirred in before the milk is added." Do we have unique customers or what? 
            </p>
          </article>
        </section>
        <!-- CopyPasteBlog -->
        <aside>
          <p class="BeanHeading">
            <img src="./Resources/Bag.gif" alt="Bean Machine Bag">
            <br>
            ORDER ONLINE
        with the 
        <a href="DoesNotExistYet.html">BEAN MACHINE</a>
            <br>
            <span class="Slogan">FAST
                <br>
              FRESH
                  <br>
              TO YOUR DOOR
                    <br>
            </span>
          </p>
          <p>
            Why wait? You can order all our fine coffees right from the Internet with our new, automated Bean Machine.
        How does it work? Just click on the Bean Machine link, enter your order, and behind the scenes, your coffee is roasted,
        ground (if you want), packaged, and shipped to your door.
          </p>
        </aside>
        <!-- SideBar -->
      </div>
      <!-- TableRow -->
    </div>
    <!-- TableContainer -->
    <footer>
      <p>
        <img src="./Resources/CopyPaste.jpg" alt="Copy Paste Logo not available"><br>
        &copy; 2026 - Copy Paste - All trademarks and registered trademarks appearing on this site are the property of their respective owners.
      </p>
    </footer>
  </form>
</body>
</html>
