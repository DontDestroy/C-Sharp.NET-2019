﻿//***
// Action
//   - Create an interface service that handles data
//   - We start by faking that the data comes from a database, by creating the needed entities and lists
//   - We will end with an implementation of this interface with a connection to the actual database
// Created
//   - CopyPaste – 20220907 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220907 – VVDW
// Proposal (To Do)
//   -
//***

using ProductCategory_WPF_MVVM.Models;
using System.Collections.Generic;

namespace ProductCategory_WPF_MVVM.Services
{

  public interface IDataService
  {
    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    IList<ProductCategory> AllProductCategories();
    IList<Product> AllProducts();

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // IDataService

}
// ProductCategory_WPF_MVVM.Services