//***
// Action
//   - Definition of a cpCommand
// Created
//   - CopyPaste � 20260204 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260204 � VVDW
// Proposal (To Do)
//   -
//***

using Code;
using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpCommand
  {

    #region "Constructors / Destructors"

    public cpCommand()
      //***
      // Action
      //   - Creating a default instance of cpCommand
      // Called by
      //   - frmBeerAndAccount.cmdChangeStoredProcedure_Click(System.Object, System.EventArgs) Handles cmdChangeStoredProcedure.Click
      //   - frmBeerAndAccount.cmdChangeAmount_Click(System.Object, System.EventArgs) Handles cmdChangeAmount.Click
      //   - frmBeerAndAccount.cmdDoTransaction_Click(System.Object, System.EventArgs) Handles cmdDoTransaction.Click
      //   - frmBeerAndAccount.cmdIntrestOnAllAccounts_Click(System.Object, System.EventArgs) Handles cmdIntrestOnAllAccounts.Click
      //   - frmBeerBrewerDatagrid.frmBeerBrewerDatagrid_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmBeerBrewerTypedDatagrid.frmBeerBrewerTypedDatagrid_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmBeerBrewerTypedFilterDatagrid.frmBeerBrewerTypedFilterDatagrid_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles this.Load
      //   - frmBrewer.cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      //   - frmBrewer.frmBrewer_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmBrewerMultiUser.frmBrewerMultiUser_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmBrewerMultiUser.cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      //   - frmBrewerTypedDatagridUpdate.cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      //   - frmBrewerTypedDatagridUpdate.frmBrewerTypedDatagridUpdate_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmFindAmountAccount.cmdAddAccountClient_Click(System.Object, System.EventArgs) Handles cmdAddAccountClient.Click
      //   - frmFindAmountAccount.cmdFindAmount_Click(System.Object, System.EventArgs) Handles cmdFindAmount.Click
      //   - frmFindAmountAccount.cmdFindInfo_Click(System.Object, System.EventArgs) Handles cmdFindInfo.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpCommand()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public System.Int32 AddAccountClient(string strName)
      //***
      // Action
      //   - Define two commands
      //   - Create a new instance of cpConnection
      //   - Define one parameter
      // Called by
      //   - frmAddAmountAccount.cmdAddAccountClient_Click(System.Object, System.EventArgs) Handles cmdAddAccountClient.Click
      // Calls
      //   - cpConnection()
      //   - cpConnection.Dispose() Implements IDisposable.Dispose
      //   - IDbConnection cpConnection.Connection()
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      IDbCommand cmmAccount;
      IDbCommand cmmAutoNumber;
      cpConnection thecpConnection = new cpConnection("cpBank");
      IDataParameter theParameterAccount;
      System.Int32 lngResult = -1;

      cmmAccount = thecpConnection.Connection.CreateCommand();
      theParameterAccount = cmmAccount.CreateParameter();

      cmmAccount.Connection = thecpConnection.Connection;
      cmmAccount.CommandType = CommandType.StoredProcedure;
      cmmAccount.CommandText = "spCPAddAccountClient";

      theParameterAccount.ParameterName = "@ClientName";
      theParameterAccount.DbType = DbType.String;
      theParameterAccount.Value = strName;

      cmmAccount.Parameters.Add(theParameterAccount);

      cmmAutoNumber = thecpConnection.Connection.CreateCommand();
      cmmAutoNumber.Connection = thecpConnection.Connection;
      cmmAutoNumber.CommandType = CommandType.StoredProcedure;
      cmmAutoNumber.CommandText = "spCPGetAutoNumber";

      try
      {
        cmmAccount.ExecuteNonQuery();
        lngResult = Convert.ToInt32(cmmAutoNumber.ExecuteScalar());
      }
      catch (Exception theException)
      {
        throw new Exception(theException.Message);
      }
      finally
      {
        thecpConnection.Dispose();
      }

      return lngResult;
    }
    // System.Int32 AddAccountClient(string)

    public void CreateParameter(IDbCommand theCommand, string strParameterName, string strFieldName)
      //***
      // Action
      //   - Create a parameter
      //   - Set the name
      //   - Set the source
      //   - Add the parameter to the command
      // Called by
      //   - bool UpdateBrewer(dsData)
      //   - bool UpdateBrewerMultiUser(dsData)
      // Calls
      //   - cpConnection(string)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      IDbDataParameter theParameter = theCommand.CreateParameter();

      theParameter.ParameterName = "@" + strParameterName;
      theParameter.SourceColumn = strFieldName;
      theCommand.Parameters.Add(theParameter);
    }
    // CreateParameter(IDbCommand, string, string)

    public void CreateParameterOriginal(IDbCommand theCommand, string strParameterName, string strFieldName)
      //***
      // Action
      //   - Create a parameter
      //   - Set the name
      //   - Set the source
      //   - Add the parameter to the command
      // Called by
      //   - bool UpdateBrewerMultiUser(dsData)
      // Calls
      //   - cpConnection(string)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      IDbDataParameter theParameter = theCommand.CreateParameter();

      theParameter.ParameterName = "@" + strParameterName + "Original";
      theParameter.SourceColumn = strFieldName;
      theParameter.SourceVersion = DataRowVersion.Original;
      theCommand.Parameters.Add(theParameter);
    }
    // CreateParameterOriginal(IDbCommand, string, string)

    public bool DoTransaction(string strAccountFrom, string strAccountTo, decimal decAmount)
      //***
      // Action
      //   - Define a result
      //   - Create a new connection
      //   - Begin the transaction
      //   - Subtract an amount from the from account
      //   - If successful
      //     - Add the same amount to the to account
      //     - If sucessful
      //     - If not
      //       - Rollback the transaction
      //       - Dispose the connection
      //       - Throw a corresponding error exception with information
      //   - If not
      //     - Rollback the transaction
      //     - Dispose the connection
      //     - Throw a corresponding error exception with information
      //   - Commit the transaction
      //   - Dispose the connection
      //   - Return true
      // Called by
      //   - frmBeerAndAccount.cmdDoTransaction_Click(System.Object, System.EventArgs) Handles cmdDoTransaction.Click
      // Calls
      //   - bool cpCommand.UpdateAccountWithTransaction(cpConnection, IDbTransaction, string, decimal)
      //   - cpConnection(string)
      //   - cpConnection.Dispose() Implements IDisposable.Dispose
      //   - IDbConnection cpConnection.Connection (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnResult;
      cpConnection thecpConnection = new cpConnection("cpBank");
      IDbTransaction trsTransaction = thecpConnection.Connection.BeginTransaction();

      blnResult = UpdateAccountWithTransaction(thecpConnection, trsTransaction, strAccountFrom, -decAmount);

      if (blnResult)
      {
        blnResult = UpdateAccountWithTransaction(thecpConnection, trsTransaction, strAccountTo, decAmount);

        if (blnResult)
        {
        }
        else
          // Not blnResult
        {
          trsTransaction.Rollback();
          thecpConnection.Dispose();
          throw new Exception("The To-Account does not exist");
        }
        // blnResult

      }
      else
        // Not blnResult
      {
        trsTransaction.Rollback();
        thecpConnection.Dispose();
        throw new Exception("The From-Account does not exist");
      }
      // blnResult

      trsTransaction.Commit();
      thecpConnection.Dispose();
      return true;
    }
    // bool DoTransaction(string, string, decimal)

    public decimal FindAmountAccount(string strKeyAccount)
      //***
      // Action
      //   - Define a command
      //   - Create a new instance of cpConnection
      //   - Define a parameter
      //   - Create a command defined on a stored procedure
      //   - Create the parameter
      //   - Add the parameter to the command
      //   - Try to
      //     - Execute the stored procedure
      //     - If there is a result
      //       - Assign result to return variable
      //     - If not
      //       - Throw new exception
      //   - When something else
      //     - Throw new exception with information
      //   - Dispose the connection
      //   - Return the result
      // Called by
      //   - frmFindAmountAccount.cmdFindAmount_Click(System.Object, System.EventArgs) Handles cmdFindAmount.Click
      // Calls
      //   - cpConnection(string)
      //   - cpConnection.Dispose() Implements IDisposable.Dispose
      //   - IDbConnection cpConnection.Connection (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      IDbCommand cmmAccount;
      decimal decResult = 0.0M;
      System.Object objResult;
      cpConnection thecpConnection = new cpConnection("cpBank");
      IDataParameter theParameterAccount;

      cmmAccount = thecpConnection.Connection.CreateCommand();
      theParameterAccount = cmmAccount.CreateParameter();

      cmmAccount.Connection = thecpConnection.Connection;
      cmmAccount.CommandType = CommandType.StoredProcedure;
      cmmAccount.CommandText = "spCPFindAmountAccount";

      theParameterAccount.ParameterName = "@KeyAccount";
      theParameterAccount.DbType = DbType.String;
      theParameterAccount.Value = strKeyAccount;

      cmmAccount.Parameters.Add(theParameterAccount);

      try
      {
        objResult = cmmAccount.ExecuteScalar();

        if (objResult == null)
        {
          throw new Exception();
        }
        else
          // objResult <> null
        {
          decResult = Convert.ToDecimal(objResult);
        }
        // objResult = null
      
      }
      catch (Exception theException)
      {
        throw new Exception("Account does not exist");
      }
      finally
      {
        thecpConnection.Dispose();
      }

      return decResult;
    }
    // decimal FindAmountAccount(string)

    public DataSet FindBrewerBeer()
      //***
      // Action
      //   - Define a command for beer
      //   - Define a command for brewer
      //   - Create a new data set with the new BeerBrewer
      //   - Define a data adapter for beer
      //   - Define a data adapter for brewer
      //   - Create a new instance of cpConnection
      //   - Try to
      //     - Create a command
      //     - Set the SQL command as text to find beers
      //     - Create a command
      //     - Set the SQL command as text to find brewers
      //     - Depending on the connection create the correct adapters
      //       - Set the select commands of the adapters
      //       - Set the missing schema actions
      //       - Set the table mappings
      //     - Fill the data set thru the adapters
      //     - Create a relationship between the two data tables
      //     - Return value becomes the instance of dsData
      //   - On possible Error
      //     - Return value becomes nothing
      //     - Throw new exception with information
      //   - Dispose the connection
      //   - Return the return value
      // Called by
      //   - frmBeerBrewerDatagrid.frmBeerBrewerDatagrid_Load(System.Object, System.EventArgs) Handles MyBase.Load
      // Calls
      //   - cpConnection(string)
      //   - cpConnection.Dispose() Implements IDisposable.Dispose 
      //   - IDbConnection cpConnection.Connection (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      IDbCommand cmmBeer;
      IDbCommand cmmBrewer;
      DataSet dsData = new DataSet("BeerBrewer");
      IDbDataAdapter dtaBeer;
      IDbDataAdapter dtaBrewer;
      cpConnection thecpConnection = new cpConnection("cpBeer");
      DataSet theResult;

      try
      {
        cmmBeer = thecpConnection.Connection.CreateCommand();
        cmmBeer.CommandType = CommandType.Text;
        cmmBeer.CommandText = "SELECT * FROM tblCPBeer";

        cmmBrewer = thecpConnection.Connection.CreateCommand();
        cmmBrewer.CommandType = CommandType.Text;
        cmmBrewer.CommandText = "SELECT * FROM tblCPBrewer";
       
        if (thecpConnection.Connection.GetType().ToString() == "System.Data.SqlClient.SqlConnection")
        {
          dtaBeer = new SqlDataAdapter();
          dtaBrewer = new SqlDataAdapter();
        }
        else
          // Not thecpConnection.Connection.GetType().ToString() <> "System.Data.SqlClient.SqlConnection"
        {
          dtaBeer = new OleDbDataAdapter();
          dtaBrewer = new OleDbDataAdapter();
        }
        // thecpConnection.Connection.GetType().ToString() = "System.Data.SqlClient.SqlConnection"
        
        dtaBeer.SelectCommand = cmmBeer;
        dtaBeer.MissingSchemaAction = MissingSchemaAction.AddWithKey;
        dtaBeer.TableMappings.Add("Table", "tblCPBeer");
        dtaBrewer.SelectCommand = cmmBrewer;
        dtaBrewer.MissingSchemaAction = MissingSchemaAction.AddWithKey;
        dtaBrewer.TableMappings.Add("Table", "tblCPBrewer");

        dtaBeer.Fill(dsData);
        dtaBrewer.Fill(dsData);
        dsData.Relations.Add("BeerBrewer", dsData.Tables["tblCPBrewer"].Columns["lngIdBrewer"], dsData.Tables["tblCPBeer"].Columns["lngBrewerId"]);
        theResult = dsData;
      }
      catch (Exception theException)
      {
        theResult = null;
      }
      finally
      {
        thecpConnection.Dispose();
      }

      return theResult;
    }
    // DataSet FindBrewerBeer()

    public dsData FindBrewerBeersTypedDataSet(bool blnBrewer, bool blnBeer)
      //***
      // Action
      //   - Define a command for beer
      //   - Define a command for brewer
      //   - Define a data adapter for beer
      //   - Define a data adapter for brewer
      //   - Create a new instance of cpConnection
      //   - Create a new instance of dsData
      //   - Try to
      //     - If brewer must be loaded
      //       - Create a command
      //       - Set the SQL command as text
      //       - Depending on the connection create the correct adapter
      //       - Set the select command of the adapter
      //       - Set the table mappings
      //       - Fill the data set thru the adapter
      //     - If not
      //       - Do nothing
      //     - If beer must be loaded
      //       - Create a command
      //       - Set the SQL command as text
      //       - Depending on the connection create the correct adapter
      //       - Set the select command of the adapter
      //       - Set the table mappings
      //       - Fill the data set thru the adapter
      //     - If not
      //       - Do nothing
      //     - Return value becomes the instance of dsData
      //   - On possible Error
      //     - Return value becomes nothing
      //     - Throw new exception with information
      //   - Dispose the connection
      //   - Return the return value
      // Called by
      //   - frmBrewer.frmBrewer_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmBrewerMultiUser.frmBrewerMultiUser_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmBeerBrewerDatagrid.frmBeerBrewerDatagrid_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmBeerBrewerTypedDatagrid.frmBeerBrewerTypedDatagrid_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmBeerBrewerTypedFilterDatagrid.frmBeerBrewerTypedFilterDatagrid_Load(ByVal theSender As System.Object, ByVal theEventArguments As System.EventArgs) Handles this.Load
      // Calls
      //   - cpConnection(string)
      //   - cpConnection.Dispose() Implements IDisposable.Dispose 
      //   - IDbConnection cpConnection.Connection (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - First parameter should be default false
      //   - Second parameter should be default true
      //***
    {
      cpConnection thecpConnection = new cpConnection("cpBeer");
      dsData thedsData = new dsData();
      dsData theReturn;
      IDbCommand cmmBeer;
      IDbCommand cmmBrewer;
      IDbDataAdapter dtaBeer;
      IDbDataAdapter dtaBrewer;

      try
      {

        if (blnBrewer)
        {
          cmmBrewer = thecpConnection.Connection.CreateCommand();
          cmmBrewer.CommandType = CommandType.Text;
          cmmBrewer.CommandText = "SELECT * FROM tblCPBrewer";
          
          if (thecpConnection.Connection.GetType().ToString() == "System.Data.SqlClient.SqlConnection")
          {
            dtaBrewer = new SqlDataAdapter();
          }
          else
            // thecpConnection.Connection.GetType().ToString() <> "System.Data.SqlClient.SqlConnection"
          {
            dtaBrewer = new OleDbDataAdapter();
          }
          // thecpConnection.Connection.GetType().ToString() = "System.Data.SqlClient.SqlConnection"

          dtaBrewer.SelectCommand = cmmBrewer;
          dtaBrewer.TableMappings.Add("Table", "tblCPBrewer");
          dtaBrewer.Fill(thedsData);
        }
        else
          // Not blnBrewer
        {
        }
        // blnBrewer
        
        if (blnBeer)
        {
          cmmBeer = thecpConnection.Connection.CreateCommand();
          cmmBeer.CommandType = CommandType.Text;
          cmmBeer.CommandText = "SELECT * FROM tblCPBeer";
          
          if (thecpConnection.Connection.GetType().ToString() == "System.Data.SqlClient.SqlConnection")
          {
            dtaBeer = new SqlDataAdapter();
          }
          else
            // thecpConnection.Connection.GetType().ToString() <> "System.Data.SqlClient.SqlConnection"
          {
            dtaBeer = new OleDbDataAdapter();
          }
          // thecpConnection.Connection.GetType().ToString() = "System.Data.SqlClient.SqlConnection"

          dtaBeer.SelectCommand = cmmBeer;
          dtaBeer.TableMappings.Add("Table", "tblCPBeer");
          dtaBeer.Fill(thedsData);
        }
        else
          // Not blnBeer
        {
        }
        // blnBeer

        theReturn = thedsData;
      }
      catch (Exception theException)
      {
        theReturn = null;
        throw new Exception(theException.Message);
      }
      finally
      {
        thecpConnection.Dispose();
      }

      return theReturn;
    }
    // dsData FindBrewerBeersTypedDataSet([bool], [bool])

    public cpInfoAccount FindInfoAccount(string strKeyAccount)
      //***
      // Action
      //   - Define a command
      //   - Create a new instance of cpConnection
      //   - Try to
      //     - Depending on the type of connection
      //       - When "Access"
      //         - Throw exception with information about the exception
      //       - When "SQL"
      //         - Create 3 parameters, with correct direction and data type
      //         - Create a command defined on a stored procedure
      //         - Add the 3 parameters to the command
      //         - Try to
      //           - Execute the stored procedure
      //           - Create a new instance of cpInfoAccount with the 2 output parameters
      //         - On possible error
      //           - Throw new exception with exception information
      //       - When something else
      //         - Do nothing
      //   - On possible error
      //     - Throw new exception with exception information
      //   - Dispose the connection
      //   - Return the result
      // Called by
      //   - frmFindAmountAccount.cmdFindInfo_Click(System.Object, System.EventArgs) Handles cmdFindInfo.Click
      // Calls
      //   - cpConnection(string)
      //   - cpConnection.Dispose() Implements IDisposable.Dispose 
      //   - cpInfoAccount(string, decimal)
      //   - IDbConnection cpConnection.Connection (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpConnection thecpConnection = new cpConnection("cpBank");
      cpInfoAccount theResult = null;
      IDbCommand cmmAccount;

      try
      {

        switch (System.Configuration.ConfigurationSettings.AppSettings["KindOfDatabase"])
        {
          case "Access":
            throw new Exception("Output parameters does not exist in Access!" + Environment.NewLine + Environment.NewLine + "Function cancelled.");
          case "SQL":
            SqlParameter theParameterAccount = new SqlParameter();
            SqlParameter theParameterAmount = new SqlParameter();
            SqlParameter theParameterClient = new SqlParameter();

            cmmAccount = thecpConnection.Connection.CreateCommand();

            cmmAccount.Connection = thecpConnection.Connection;
            cmmAccount.CommandType = CommandType.StoredProcedure;
            cmmAccount.CommandText = "spCPFindInfoAccount";

            theParameterAccount.ParameterName = "@KeyAccount";
            theParameterAccount.DbType = DbType.String;
            theParameterAccount.Value = strKeyAccount;

            theParameterAmount.ParameterName = "@Amount";
            theParameterAmount.DbType = DbType.Decimal;
            theParameterAmount.Direction = ParameterDirection.Output;

            theParameterClient.ParameterName = "@ClientName";
            theParameterClient.DbType = DbType.String;
            theParameterClient.Size = 50;
            theParameterClient.Direction = ParameterDirection.Output;

            cmmAccount.Parameters.Add(theParameterAccount);
            cmmAccount.Parameters.Add(theParameterAmount);
            cmmAccount.Parameters.Add(theParameterClient);

            try
            {
              cmmAccount.ExecuteNonQuery();
              theResult = new cpInfoAccount(theParameterClient.Value.ToString(), Convert.ToDecimal(theParameterAmount.Value));
            }
            catch (Exception theException)
            {
              throw new Exception("Account does not exist");
            }
            finally
            {
            }

            break;
          default:
            break;
        }
        // System.Configuration.ConfigurationSettings.AppSettings["KindOfDatabase"]
      
      }
      catch (Exception theException)
      {
        throw new Exception(theException.Message);
      }
      finally
      {
        thecpConnection.Dispose();
      }

      return theResult;
    }
    // cpInfoAccount FindInfoAccount(string strKeyAccount)

    public System.Int32 IntrestOnAllAccounts()
      //***
      // Action
      //   - Define a command
      //   - Define the number of records changed
      //   - Create a new connection
      //   - Set the SQL command string
      //   - Execute the command
      //   - Dispose the connection
      // Called by
      //   - frmBeerAndAccount.cmdIntrestOnAllAccounts_Click(System.Object, System.EventArgs) Handles cmdIntrestOnAllAccounts.Click
      // Calls
      //   - cpConnection(string)
      //   - cpConnection.Dispose() Implements IDisposable.Dispose 
      //   - IDbConnection cpConnection.Connection (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      IDbCommand cmmIntrest;
      System.Int32 lngNumberOfRecordsChanged;
      cpConnection thecpConnection = new cpConnection("cpBank");

      cmmIntrest = thecpConnection.Connection.CreateCommand();
      cmmIntrest.CommandType = CommandType.Text;
      cmmIntrest.CommandText = "UPDATE tblCPAccount SET dblAmount = dblAmount * 1.1";
      lngNumberOfRecordsChanged = cmmIntrest.ExecuteNonQuery();
      thecpConnection.Dispose();
      
      return lngNumberOfRecordsChanged;
    }
    // System.Int32 IntrestOnAllAccounts()

    public bool UpdateAccount(string strKeyAccount, decimal decAmount)
      //***
      // Action
      //   - Define a command
      //   - Define a variable to store the number of records changed
      //   - Create a new connection
      //   - Define two parameters
      //   - Create a command
      //   - Create two parameters
      //   - Set the connection to the command
      //   - Set the command type
      //   - Set the command SQL string
      //   - Define the two parameters
      //   - Add the two parameters to the command
      //   - Execute the command and store the numbers of records changed
      //   - Dispose the connection
      //   - If the number of records changed is zero
      //     - Return false
      //   - If not
      //     - Return true
      // Called by
      //   - frmBeerAndAccount.cmdChangeAmount_Click(System.Object, System.EventArgs) Handles cmdChangeAmount.Click
      // Calls
      //   - cpConnection(string)
      //   - cpConnection.Dispose() Implements IDisposable.Dispose 
      //   - IDbConnection cpConnection.Connection (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnReturn;
      cpConnection thecpConnection = new cpConnection("cpBank");
      IDataParameter theParameterAccount;
      IDataParameter theParameterAmount;
      IDbCommand cmmAccount;
      System.Int32 lngNumberOfRecordsChanged;

      cmmAccount = thecpConnection.Connection.CreateCommand();
      theParameterAccount = cmmAccount.CreateParameter();
      theParameterAmount = cmmAccount.CreateParameter();

      cmmAccount.Connection = thecpConnection.Connection;
      cmmAccount.CommandType = CommandType.Text;
      cmmAccount.CommandText = "UPDATE tblCPAccount SET dblAmount = dblAmount + @Amount WHERE strIdAccount = @KeyAccount";

      theParameterAccount.ParameterName = "@KeyAccount";
      theParameterAccount.DbType = DbType.String;
      theParameterAccount.Value = strKeyAccount;
      theParameterAmount.ParameterName = "@Amount";
      theParameterAmount.DbType = DbType.Double;
      theParameterAmount.Value = decAmount;

      cmmAccount.Parameters.Add(theParameterAmount);
      cmmAccount.Parameters.Add(theParameterAccount);

      lngNumberOfRecordsChanged = cmmAccount.ExecuteNonQuery();
      thecpConnection.Dispose();

      if (lngNumberOfRecordsChanged == 0)
      {
        blnReturn = false;
      }
      else
        // lngNumberOfRecordsChanged <> 0
      {
        blnReturn = true;
      }
      // lngNumberOfRecordsChanged = 0

      return blnReturn;
    }
    // bool UpdateAccount(string, decimal)

    public bool UpdateAccountWithTransaction(cpConnection thecpConnection, IDbTransaction theTransaction, string strKeyAccount, decimal decAmount)
      //***
      // Action
      //   - Define a command
      //   - Define a variable to store the number of records changed
      //   - Define two parameters
      //   - Create a command
      //   - Create two parameters
      //   - Set the connection to the command
      //   - Set the command type
      //   - Set the command SQL string
      //   - Set the transaction to the command
      //   - Define the two parameters
      //   - Add the two parameters to the command
      //   - Execute the command and store the numbers of records changed
      //   - Dispose the connection
      //   - If the number of records changed is zero
      //     - Return false
      //   - If not
      //     - Return true
      // Called by
      //   - bool DoTransaction(string, string, decimal) 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnReturn;
      IDataParameter theParameterAccount; 
      IDataParameter theParameterAmount;
      IDbCommand cmmAccount;
      System.Int32 lngNumberOfRecordsChanged;

      cmmAccount = thecpConnection.Connection.CreateCommand();
      theParameterAccount = cmmAccount.CreateParameter();
      theParameterAmount = cmmAccount.CreateParameter();

      cmmAccount.Connection = thecpConnection.Connection;
      cmmAccount.CommandType = CommandType.Text;
      cmmAccount.CommandText = "UPDATE tblCPAccount SET dblAmount = dblAmount + @Amount WHERE strIdAccount = @KeyAccount";
      cmmAccount.Transaction = theTransaction;

      theParameterAccount.ParameterName = "@KeyAccount";
      theParameterAccount.DbType = DbType.String;
      theParameterAccount.Value = strKeyAccount;
      theParameterAmount.ParameterName = "@Amount";
      theParameterAmount.DbType = DbType.Double;
      theParameterAmount.Value = decAmount;

      cmmAccount.Parameters.Add(theParameterAmount);
      cmmAccount.Parameters.Add(theParameterAccount);

      lngNumberOfRecordsChanged = cmmAccount.ExecuteNonQuery();

      if (lngNumberOfRecordsChanged == 0)
      {
        blnReturn = false;
      }
      else
        // lngNumberOfRecordsChanged <> 0
      {
        blnReturn = true;
      }
      // lngNumberOfRecordsChanged = 0

      return blnReturn;
    }
    // bool UpdateAccountWithTransaction(cpConnection, IDbTransaction, string, decimal)

    public bool UpdateAccountWithStoredProcedure(string strKeyAccount, decimal decAmount)
      //***
      // Action
      //   - Define a command
      //   - Define a variable to store the number of records changed
      //   - Create a new connection
      //   - Define two parameters
      //   - Create a command
      //   - Create two parameters
      //   - Set the connection to the command
      //   - Set the command type
      //   - Set the command stored procedure
      //   - Define the two parameters
      //   - Add the two parameters to the command
      //   - Execute the command and store the numbers of records changed
      //   - Dispose the connection
      //   - If the number of records changed is zero
      //     - Return false
      //   - If not
      //     - Return true
      // Called by
      //   - frmBeerAndAccount.cmdChangeStoredProcedure_Click(System.Object, System.EventArgs) Handles cmdChangeStoredProcedure.Click
      // Calls
      //   - cpConnection(string)
      //   - cpConnection.Dispose() Implements IDisposable.Dispose 
      //   - IDbConnection cpConnection.Connection (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      bool blnReturn;
      cpConnection thecpConnection = new cpConnection("cpBank");
      IDataParameter theParameterAccount;
      IDataParameter theParameterAmount;
      IDbCommand cmmAccount;
      System.Int32 lngNumberOfRecordsChanged;

      cmmAccount = thecpConnection.Connection.CreateCommand();
      theParameterAccount = cmmAccount.CreateParameter();
      theParameterAmount = cmmAccount.CreateParameter();

      cmmAccount.Connection = thecpConnection.Connection;
      cmmAccount.CommandType = CommandType.StoredProcedure;
      cmmAccount.CommandText = "spCPUpdateAmountAccount";

      theParameterAccount.ParameterName = "@KeyAccount";
      theParameterAccount.DbType = DbType.String;
      theParameterAccount.Value = strKeyAccount;
      theParameterAmount.ParameterName = "@Amount";
      theParameterAmount.DbType = DbType.Double;
      theParameterAmount.Value = decAmount;

      cmmAccount.Parameters.Add(theParameterAmount);
      cmmAccount.Parameters.Add(theParameterAccount);

      lngNumberOfRecordsChanged = cmmAccount.ExecuteNonQuery();
      thecpConnection.Dispose();

      if (lngNumberOfRecordsChanged == 0)
      {
        blnReturn = false;
      }
      else
        // lngNumberOfRecordsChanged <> 0
      {
        blnReturn = true;
      }
      // lngNumberOfRecordsChanged = 0

      return blnReturn;
    }
    // bool UpdateAccountWithStoredProcedure(string, decimal)

    public bool UpdateBrewer(dsData thedsData)
      //***
      // Action
      //   - Define a delete, insert and update command
      //   - Define a data adapter
      //   - Create a new instance of cpConnection
      //   - Depending on the kind of connection
      //     - Create a new instance of the correct data adapter
      //   - Set the table mappings to the brewer
      //   - Create a command for the update of a brewer
      //   - Set the correct SQL Statement
      //   - Define the correct parameters
      //   - Create a command for the insert of a brewer
      //   - Set the correct SQL Statement
      //   - Define the correct parameters
      //   - Create a command for the delete of a brewer
      //   - Set the correct SQL Statement
      //   - Define the correct parameters
      //   - Update the data set thru the data adapter
      // Called by
      //   - frmBrewer.cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      //   - frmBrewerTypedDatagridUpdate.cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      // Calls
      //   - cpConnection(string)
      //   - cpConnection.Dispose() Implements IDisposable.Dispose 
      //   - CreateParameter(IDbCommand, string, string)
      //   - IDbConnection cpConnection.Connection (Get)
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      IDbCommand cmmBrewerDelete;
      IDbCommand cmmBrewerInsert;
      IDbCommand cmmBrewerUpdate;
      IDbDataAdapter dtaBrewer;
      cpConnection thecpConnection = new cpConnection("cpBeer");

      if (thecpConnection.Connection.GetType().ToString() == "System.Data.SqlClient.SqlConnection")
      {
        dtaBrewer = new SqlDataAdapter();
      }
      else
        // thecpConnection.Connection.GetType().ToString() <> "System.Data.SqlClient.SqlConnection"
      {
        dtaBrewer = new OleDbDataAdapter();
      }
      // thecpConnection.Connection.GetType().ToString() = "System.Data.SqlClient.SqlConnection"

      dtaBrewer.TableMappings.Add("Table", "tblCPBrewer");
      cmmBrewerUpdate = thecpConnection.Connection.CreateCommand();
      cmmBrewerUpdate.CommandType = CommandType.Text;
      cmmBrewerUpdate.CommandText = "UPDATE tblCPBrewer SET " +
        "strBrewerName = @BrewerName, " +
        "strBrewerAddress = @BrewerAddress, " +
        "strBrewerZipCode = @BrewerZipCode, " +
        "strBrewerCity = @BrewerCity,  " +
        "lngBrewerProduction = @BrewerProduction " +
        "WHERE lngIdBrewer = @KeyBrewer";

      CreateParameter(cmmBrewerUpdate, "BrewerName", "strBrewerName");
      CreateParameter(cmmBrewerUpdate, "BrewerAddress", "strBrewerAddress");
      CreateParameter(cmmBrewerUpdate, "BrewerZipCode", "strBrewerZipCode");
      CreateParameter(cmmBrewerUpdate, "BrewerCity", "strBrewerCity");
      CreateParameter(cmmBrewerUpdate, "BrewerProduction", "lngBrewerProduction");
      CreateParameter(cmmBrewerUpdate, "KeyBrewer", "lngIdBrewer");
      dtaBrewer.UpdateCommand = cmmBrewerUpdate;

      cmmBrewerInsert = thecpConnection.Connection.CreateCommand();
      cmmBrewerInsert.CommandType = CommandType.Text;
      cmmBrewerInsert.CommandText = "INSERT INTO tblCPBrewer " +
        "(strBrewerName,  strBrewerAddress, strBrewerZipCode, strBrewerCity, lngBrewerProduction) " +
        "VALUES (@BrewerName, @BrewerAddress, @BrewerZipCode, @BrewerCity,  @BrewerProduction)";
      CreateParameter(cmmBrewerInsert, "BrewerName", "strBrewerName");
      CreateParameter(cmmBrewerInsert, "BrewerAddress", "strBrewerAddress");
      CreateParameter(cmmBrewerInsert, "BrewerZipCode", "strBrewerZipCode");
      CreateParameter(cmmBrewerInsert, "BrewerCity", "strBrewerCity");
      CreateParameter(cmmBrewerInsert, "BrewerProduction", "lngBrewerProduction");
      dtaBrewer.InsertCommand = cmmBrewerInsert;

      cmmBrewerDelete = thecpConnection.Connection.CreateCommand();
      cmmBrewerDelete.CommandType = CommandType.Text;
      cmmBrewerDelete.CommandText = "DELETE FROM tblCPBrewer " +
        "WHERE lngIdBrewer = @KeyBrewer";

      CreateParameter(cmmBrewerDelete, "KeyBrewer", "lngIdBrewer");
      dtaBrewer.DeleteCommand = cmmBrewerDelete;

      // ((System.Data.Common.DataAdapter)dtaBrewer).ContinueUpdateOnError = true;
      dtaBrewer.Update(thedsData);
      thecpConnection.Dispose();
      
      return true;
    }
    // bool UpdateBrewer(dsData)

    public bool UpdateBrewerMultiUser(dsData thedsData)
      //***
      // Action
      //   - Define a delete, insert and update command
      //   - Define a data adapter
      //   - Create a new instance of cpConnection
      //   - Depending on the kind of connection
      //     - Create a new instance of the correct data adapter
      //   - Set the table mappings to the brewer
      //   - Create a command for the update of a brewer
      //   - Set the correct SQL Statement
      //   - Define the correct parameters
      //   - Create a command for the insert of a brewer
      //   - Set the correct SQL Statement
      //   - Define the correct parameters
      //   - Create a command for the delete of a brewer
      //   - Set the correct SQL Statement
      //   - Define the correct parameters
      //   - Continue when errors (commented)
      //   - Update the data set thru the data adapter
      // Called by
      //   - frmBrewerMultiuser.cmdSave_Click(System.Object, System.EventArgs) Handles cmdSave.Click
      // Calls
      //   - cpConnection(string)
      //   - cpConnection.Dispose() Implements IDisposable.Dispose 
      //   - CreateParameter(IDbCommand, string, string)
      //   - CreateParameterOriginal(IDbCommand, string, string)
      //   - IDbConnection cpConnection.Connection 
      // Created
      //   - CopyPaste � 20260204 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260204 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpConnection thecpConnection = new cpConnection("cpBeer");
      IDbCommand cmmBrewerDelete;
      IDbCommand cmmBrewerInsert;
      IDbCommand cmmBrewerUpdate;
      IDbDataAdapter dtaBrewer;

      if (thecpConnection.Connection.GetType().ToString() == "System.Data.SqlClient.SqlConnection")
      {
        dtaBrewer = new SqlDataAdapter();
      }
      else
        // thecpConnection.Connection.GetType().ToString() <> "System.Data.SqlClient.SqlConnection"
      {
        dtaBrewer = new OleDbDataAdapter();
      }
      // thecpConnection.Connection.GetType().ToString() = "System.Data.SqlClient.SqlConnection"

      dtaBrewer.TableMappings.Add("Table", "tblCPBrewer");
      cmmBrewerUpdate = thecpConnection.Connection.CreateCommand();
      cmmBrewerUpdate.CommandType = CommandType.Text;
      cmmBrewerUpdate.CommandText = "UPDATE tblCPBrewer SET " +
        "strBrewerName = @BrewerName, " +
        "strBrewerAddress = @BrewerAddress, " +
        "strBrewerZipCode = @BrewerZipCode, " +
        "strBrewerCity = @BrewerCity,  " +
        "lngBrewerProduction = @BrewerProduction " +
        "WHERE lngIdBrewer = @KeyBrewer AND " +
        "strBrewerName = @BrewerNameOriginal AND " +
        "strBrewerAddress = @BrewerAddressOriginal AND " +
        "strBrewerZipCode = @BrewerZipCodeOriginal AND " +
        "strBrewerCity = @BrewerCityOriginal AND " +
        "lngBrewerProduction = @BrewerProductionOriginal";

      CreateParameter(cmmBrewerUpdate, "BrewerName", "strBrewerName");
      CreateParameter(cmmBrewerUpdate, "BrewerAddress", "strBrewerAddress");
      CreateParameter(cmmBrewerUpdate, "BrewerZipCode", "strBrewerZipCode");
      CreateParameter(cmmBrewerUpdate, "BrewerCity", "strBrewerCity");
      CreateParameter(cmmBrewerUpdate, "BrewerProduction", "lngBrewerProduction");
      CreateParameter(cmmBrewerUpdate, "KeyBrewer", "lngIdBrewer");
      CreateParameterOriginal(cmmBrewerUpdate, "BrewerName", "strBrewerName");
      CreateParameterOriginal(cmmBrewerUpdate, "BrewerAddress", "strBrewerAddress");
      CreateParameterOriginal(cmmBrewerUpdate, "BrewerZipCode", "strBrewerZipCode");
      CreateParameterOriginal(cmmBrewerUpdate, "BrewerCity", "strBrewerCity");
      CreateParameterOriginal(cmmBrewerUpdate, "BrewerProduction", "lngBrewerProduction");
      dtaBrewer.UpdateCommand = cmmBrewerUpdate;

      cmmBrewerInsert = thecpConnection.Connection.CreateCommand();
      cmmBrewerInsert.CommandType = CommandType.Text;
      cmmBrewerInsert.CommandText = "INSERT INTO tblCPBrewer " +
        "(strBrewerName,  strBrewerAddress, strBrewerZipCode, strBrewerCity, lngBrewerProduction) " +
        "VALUES (@BrewerName, @BrewerAddress, @BrewerZipCode, @BrewerCity,  @BrewerProduction)";
      CreateParameter(cmmBrewerInsert, "BrewerName", "strBrewerName");
      CreateParameter(cmmBrewerInsert, "BrewerAddress", "strBrewerAddress");
      CreateParameter(cmmBrewerInsert, "BrewerZipCode", "strBrewerZipCode");
      CreateParameter(cmmBrewerInsert, "BrewerCity", "strBrewerCity");
      CreateParameter(cmmBrewerInsert, "BrewerProduction", "lngBrewerProduction");
      dtaBrewer.InsertCommand = cmmBrewerInsert;
      cmmBrewerDelete = thecpConnection.Connection.CreateCommand();
      cmmBrewerDelete.CommandType = CommandType.Text;
      cmmBrewerDelete.CommandText = "DELETE FROM tblCPBrewer " +
        "WHERE lngIdBrewer = @KeyBrewer";
      CreateParameter(cmmBrewerDelete, "KeyBrewer", "lngIdBrewer");
      dtaBrewer.DeleteCommand = cmmBrewerDelete;

      // ((System.Data.Common.DataAdapter)dtaBrewer).ContinueUpdateOnError = true;
      dtaBrewer.Update(thedsData);
      thecpConnection.Dispose();

      return true;
    }
    // bool UpdateBrewerMultiUser(dsData)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpCommand

}
// CopyPaste.Learning