﻿//***
// Action
//   - A definition of a Checker
// Created
//   - CopyPaste – 20251103 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251103 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using java.util;
using kareltherobot;
using static sun.awt.SunHints;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace cpKarelTheRobot
{

	public class cpChecker : cpCopyPasteRobot
	{

		#region "Constructors / Destructors"

		public cpChecker(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpChecker starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpChecker(int, int, Directions.Direction, int) 
    // Calls
    //   - cpCopyPasteRobot(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251103 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251103 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpChecker(int, int, Directions.Direction, int, Color) 

    public cpChecker(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpChecker starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpChecker(int, int, Directions.Direction, int, Color) 
    // Created
    //   - CopyPaste – 20251103 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251103 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpChecker(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public bool EnoughToCarry()
    //***
    // Action
    //   - Precondition: Facing North on 1st Street
    //   - Define a boolean to check if there is enough to carry
    //   - Loop 10 times
    //     - Check boolean variable to carry
    //     - If true
    //       - If next to a beeper
    //         - Pick beeper
    //       - If not
    //         - Put all the beepers down
    //         - Set variable to carry to false
    //    - If not
    //      - Do nothing     
    //  - Check boolean variable to carry
    //  - If true
    //    - Move forward to second street
    //    - Put all the beepers down
    //    - Go back to first street
    //  - If not
    //    - Do nothing     
    //  - Return the value of the variable to carry
    // Called by
    //   - cpCalculator.AddColumn()
    // Calls
    //   - PutAllBeepers()
    //   - TurnAround()
    // Created
    //   - CopyPaste – 20251103 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251103 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      bool blnReturn = true;

      for (int countBeepers = 0; countBeepers < 10; countBeepers++)
      {

        if (blnReturn)
        {

          if (nextToABeeper())
          {
            pickBeeper();
          }
          else
          // Not nextToABeeper()
          {
            PutAllBeepers();
            blnReturn = false;
          }
          // nextToABeeper()

        }
        else
        // Not blnReturn
        { 
        }
        // blnReturn

      }
      // countBeepers = 10

      if (blnReturn) // Found ten beepers
      {
        move();
        PutAllBeepers(); // Leave them on second Street
        TurnAround();
        move();
        TurnAround();
      }
      else
      // Not blnReturn
      {
      }
      // blnReturn

      return blnReturn;
    }
    // EnoughToCarry()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpChecker

}
// cpKarelTheRobot