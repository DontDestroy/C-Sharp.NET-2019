//***
// Action
//   - Having a context to the data set
// Created
//   - CopyPaste � 20251120 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251120 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmBindingContextWizard: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private IContainer components;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Label lblPosition;
    internal System.Windows.Forms.TextBox txtNotes;
    internal System.Windows.Forms.TextBox txtTitle;
    internal System.Windows.Forms.Button cmdPrevious;
    internal System.Windows.Forms.TextBox txtLastName;
    private BindingSource bdsrcEmployee;
    private BindingContextWizard.dsData dsData;
    private BindingContextWizard.dsDataTableAdapters.tbaEmployee tbaEmployee;
    internal System.Windows.Forms.TextBox txtFirstName;

    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBindingContextWizard));
      this.cmdNext = new System.Windows.Forms.Button();
      this.lblPosition = new System.Windows.Forms.Label();
      this.txtNotes = new System.Windows.Forms.TextBox();
      this.txtTitle = new System.Windows.Forms.TextBox();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.txtLastName = new System.Windows.Forms.TextBox();
      this.txtFirstName = new System.Windows.Forms.TextBox();
      this.bdsrcEmployee = new System.Windows.Forms.BindingSource(this.components);
      this.dsData = new BindingContextWizard.dsData();
      this.tbaEmployee = new BindingContextWizard.dsDataTableAdapters.tbaEmployee();
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcEmployee)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdNext
      // 
      this.cmdNext.Location = new System.Drawing.Point(201, 168);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(40, 23);
      this.cmdNext.TabIndex = 13;
      this.cmdNext.Text = ">>";
      // 
      // lblPosition
      // 
      this.lblPosition.BackColor = System.Drawing.Color.Lime;
      this.lblPosition.Location = new System.Drawing.Point(65, 168);
      this.lblPosition.Name = "lblPosition";
      this.lblPosition.Size = new System.Drawing.Size(128, 23);
      this.lblPosition.TabIndex = 11;
      this.lblPosition.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // txtNotes
      // 
      this.txtNotes.Location = new System.Drawing.Point(16, 80);
      this.txtNotes.Multiline = true;
      this.txtNotes.Name = "txtNotes";
      this.txtNotes.Size = new System.Drawing.Size(224, 72);
      this.txtNotes.TabIndex = 10;
      // 
      // txtTitle
      // 
      this.txtTitle.Location = new System.Drawing.Point(16, 48);
      this.txtTitle.Name = "txtTitle";
      this.txtTitle.Size = new System.Drawing.Size(225, 20);
      this.txtTitle.TabIndex = 9;
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Location = new System.Drawing.Point(17, 168);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(40, 23);
      this.cmdPrevious.TabIndex = 12;
      this.cmdPrevious.Text = "<<";
      // 
      // txtLastName
      // 
      this.txtLastName.Location = new System.Drawing.Point(145, 16);
      this.txtLastName.Name = "txtLastName";
      this.txtLastName.Size = new System.Drawing.Size(96, 20);
      this.txtLastName.TabIndex = 8;
      // 
      // txtFirstName
      // 
      this.txtFirstName.Location = new System.Drawing.Point(16, 16);
      this.txtFirstName.Name = "txtFirstName";
      this.txtFirstName.Size = new System.Drawing.Size(100, 20);
      this.txtFirstName.TabIndex = 7;
      // 
      // bdsrcEmployee
      // 
      this.bdsrcEmployee.DataMember = "tblCPEmployee";
      this.bdsrcEmployee.DataSource = this.dsData;
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // tbaEmployee
      // 
      this.tbaEmployee.ClearBeforeFill = true;
      // 
      // frmBindingContextWizard
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(256, 206);
      this.Controls.Add(this.txtNotes);
      this.Controls.Add(this.txtTitle);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.txtLastName);
      this.Controls.Add(this.txtFirstName);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.lblPosition);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmBindingContextWizard";
      this.Text = "BindingText Wizard";
      this.Load += new System.EventHandler(this.frmBindingContextWizard_Load);
      ((System.ComponentModel.ISupportInitialize)(this.bdsrcEmployee)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmBindingContextWizard'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20251120 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20251120 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmBindingContextWizard()
    //***
    // Action
    //   - Create instance of 'frmBindingContextWizard'
    // Called by
    //   - Main()
    // Calls
    //   - InitializeComponent()
    //   - SetUpData();
    //   - UpdateLabel();
    // Created
    //   - CopyPaste � 20251120 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20251120 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
      SetUpData();
      UpdateLabel();
    }
    // frmBindingContextWizard()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private static int mlngCurrentPosition;
    private static int mlngRecordCount;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmBindingContextWizard_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Doing some stuff with data set, data row, data table, and columns
      //   - Get the columns of data table tblCPEmployee
      //   - Loop thru all the columns
      //     - Get the column name and column data type
      //   - Show the result
      //   - Fill the data set
      //   - Get how many records there are
      //   - Loop thru all the records
      //     - Get the key and last name
      //   - Show the result
      //   - Add a table (not in the database)
      //   - Create 2 columns and add them to the table
      //   - Create 3 records and add them to the table
      //   - Find a record
      //   - Update a record
      //   - Delete a record
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251120 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251120 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   - Everything is in comment because it was a style exercise
      //***
    {
      //DataColumn dclDataColumn;
      //DataColumnCollection coldclCollection;
      //DataColumn[] arrdclPrimaryKey = new DataColumn[1];
      //DataRow[] arrdrwColumn;
      //DataRow drwDataRow;
      //DataSet dsDataSet;
      //DataTable dtDataTable;
      //DataTable dtEmployee;
      //string strDescription = "";
      //string strFind;
      //string strMessage = "";

      //dtEmployee = dsData.tblCPEmployee;
      //coldclCollection = dtEmployee.Columns;

      //foreach (DataColumn theDataColumn in coldclCollection)
      //{
      //  strDescription += "Name: " + theDataColumn.ColumnName + " --> DataType:  " +
      //    theDataColumn.DataType.ToString() + Environment.NewLine;
      //}
      //// in coldclCollection

      //MessageBox.Show(strDescription, "Employees Table Column Collection", MessageBoxButtons.OK, MessageBoxIcon.Information);

      //tbaEmployee.Fill(dsData.tblCPEmployee);
      //dtEmployee = dsData.tblCPEmployee;

      //strDescription = "There are " + dtEmployee.Rows.Count + " rows in the tblCPEmployees table" + Environment.NewLine;

      //foreach (DataRow theDataRow in dtEmployee.Rows)
      //{
      //  strDescription += "Key: " + theDataRow["intIdEmployee"].ToString() +
      //    "\tLast Name: " + theDataRow["strLastName"].ToString() + Environment.NewLine;
      //}
      //// dtEmployee.Rows

      //MessageBox.Show(strDescription, "Employees Table Data Rows", MessageBoxButtons.OK, MessageBoxIcon.Information);

      //dtDataTable = new DataTable("tblCPLanguage");
      //dclDataColumn = new DataColumn();

      //dclDataColumn.DataType = System.Type.GetType("System.Int32");
      //dclDataColumn.ColumnName = "intIdLanguage";
      //dclDataColumn.ReadOnly = true;
      //dclDataColumn.AutoIncrement = true;

      //dtDataTable.Columns.Add(dclDataColumn);
      //dclDataColumn = new DataColumn();

      //dclDataColumn.DataType = System.Type.GetType("System.String");
      //dclDataColumn.ColumnName = "strLanguage";
      //dclDataColumn.AutoIncrement = false;
      //dclDataColumn.ReadOnly = false;
      //dclDataColumn.Unique = false;

      //dtDataTable.Columns.Add(dclDataColumn);

      //arrdclPrimaryKey[0] = dtDataTable.Columns["intIdLanguage"];
      //dtDataTable.PrimaryKey = arrdclPrimaryKey;

      //drwDataRow = dtDataTable.NewRow();
      //drwDataRow["strLanguage"] = "VB .NET";
      //dtDataTable.Rows.Add(drwDataRow);

      //drwDataRow = dtDataTable.NewRow();
      //drwDataRow["strLanguage"] = "C#";
      //dtDataTable.Rows.Add(drwDataRow);

      //drwDataRow = dtDataTable.NewRow();
      //drwDataRow["strLanguage"] = "C++";
      //dtDataTable.Rows.Add(drwDataRow);

      //dsDataSet = new DataSet();
      //dsDataSet.Tables.Add(dtDataTable);

      //strFind = "strLanguage = 'VB .NET'";
      //arrdrwColumn = dtDataTable.Select(strFind);

      //for (int intCounter = 0; intCounter <= arrdrwColumn.GetUpperBound(0); intCounter++)
      //{
      //  strMessage = "Item: " + arrdrwColumn[intCounter]["strLanguage"].ToString();
      //  arrdrwColumn[intCounter]["strLanguage"] = "Visual Basic .NET";
      //  strMessage += " is now " + arrdrwColumn[intCounter]["strLanguage"].ToString();
      //}
      //// intCounter > arrdrwColumn.GetUpperBound(0)

      //MessageBox.Show(strMessage, "Finding Records", MessageBoxButtons.OK, MessageBoxIcon.Information);
      //strFind = "strLanguage = 'C++'";
      //arrdrwColumn = dtDataTable.Select(strFind);

      //for (int intCounter = 0; intCounter <= arrdrwColumn.GetUpperBound(0); intCounter++)
      //{
      //  strMessage = "Item: " + arrdrwColumn[intCounter]["strLanguage"].ToString() + " found." + Environment.NewLine;
      //  arrdrwColumn[intCounter].Delete();
      //  strMessage += "C++ was successfuly deleted" + Environment.NewLine;
      //}
      //// intCounter > arrdrwColumn.GetUpperBound(0)

      //arrdrwColumn = dtDataTable.Select(strFind);

      //if (arrdrwColumn.Length == 0)
      //{
      //  strMessage += "C++ not found" + Environment.NewLine;
      //}
      //else
      //// arrdrwColumn.Length <> 0
      //{
      //}
      //// arrdrwColumn.Length = 0

      //MessageBox.Show(strMessage, "Finding Records", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // frmBindingContextWizard_Load(System.Object, System.EventArgs) Handling this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmBindingContextWizard
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - frmBindingContextTryout()
    // Created
    //   - CopyPaste � 20251120 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20251120 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Application.Run(new frmBindingContextWizard());
    }
    // Main() 

    private void SetUpData()
    //***
    // Action
    //   - Make an array of 4 controls
    //   - Fill the data of employee
    //   - Bind the correct column to the control
    //   - Loop thru the controls
    //     - Set the backcolor
    //     - Set the fore color
    //     - Disable the control
    //   - Add a functionality to the next and previous button
    // Called by
    //   - frmBindingContextWizard()
    // Calls
    //   - ValidateRecords(System.Object, System.EventArgs)
    // Created
    //   - CopyPaste � 20251120 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20251120 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   - 
    //***
    {
      Control[] arrctlBackground = { txtLastName, txtFirstName, txtTitle, txtNotes };

      tbaEmployee.Fill(dsData.tblCPEmployee);
      this.txtFirstName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcEmployee, "strFirstName", true));
      this.txtLastName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcEmployee, "strLastName", true));
      this.txtTitle.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcEmployee, "strTitle", true));
      this.txtNotes.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bdsrcEmployee, "memNotes", true));

      foreach (Control theControl in arrctlBackground)
      {
        theControl.BackColor = Color.BlanchedAlmond;
        theControl.ForeColor = Color.DarkGray;
        theControl.Enabled = false;
      }
      // in arrctlBackground

      cmdNext.Click += new EventHandler(ValidateRecords);
      cmdPrevious.Click += new EventHandler(ValidateRecords);
    }
    // SetUpData()

    private void UpdateLabel()
    //***
    // Action
    //   - Get the number of records in tblCPEmployee
    //   - Get the current position (what record is selected)
    //   - If there are records
    //     - Show the current position
    //   - If not
    //     - Show that there are no records
    // Called by
    //   - frmBindingContext()
    //   - ValidateRecords(System.Object, System.EventArgs)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20251120 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20251120 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   - 
    //***
    {
      mlngRecordCount = tbaEmployee.GetData().Count;
      mlngCurrentPosition = bdsrcEmployee.Position + 1;

      if (mlngRecordCount > 0)
      {
        lblPosition.Text = "Record " + mlngCurrentPosition + " of " + mlngRecordCount;
      }
      else
      // mlngRecordCount <= 0
      {
        lblPosition.Text = "No Records";
      }
      // mlngRecordCount > 0

    }
    // UpdateLabel()

    private void ValidateRecords(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Get the number of records in tblCPEmployee
    //   - Get the current position (what record is selected)
    //   - If there are records
    //     - Have you clicked on the previous button
    //       - If you are on the first position
    //         - Previous button is disabled
    //       - If not
    //         - Go one back in the recordset
    //     - Have you clicked on the next button
    //       - If you are on the last position
    //         - Next button is disabled
    //       - If not
    //         - Go one forward in the recordset
    //     - Get the current position
    //     - If you are at the last position
    //       - Disable next button
    //     - If not
    //       - Enable next button
    //     - If you are at the first position
    //       - Disable previous button
    //     - If not
    //       - Enable previous button
    //   - If not
    //     - Next and previous buttons are disabled
    //   - Show correct label
    // Called by
    //   - User action (Clicking the next or previous button)
    // Calls
    //   - UpdateLabel()
    // Created
    //   - CopyPaste � 20251120 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20251120 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   - 
    //***
    {
      mlngRecordCount = tbaEmployee.GetData().Count;
      mlngCurrentPosition = bdsrcEmployee.Position + 1;

      if (mlngRecordCount > 0)
      {

        if (theSender.Equals(cmdPrevious))
        {

          if (mlngCurrentPosition == 0)
          {
            cmdPrevious.Enabled = false;
          }
          else
          // mlngCurrentPosition <> 0
          {
            bdsrcEmployee.Position -= 1;
          }
          // mlngCurrentPosition = 0

        }
        else if (theSender.Equals(cmdNext))
        // Not theSender.Equals(cmdPrevious)
        {

          if (mlngRecordCount > mlngCurrentPosition)
          {
            bdsrcEmployee.Position += 1;
          }
          else
          // mlngRecordCount <= mlngCurrentPosition
          {
            cmdNext.Enabled = false;
          }
          // mlngRecordCount > mlngCurrentPosition

        }
        // theSender.Equals(cmdNext)
        // theSender.Equals(cmdPrevious)

        mlngCurrentPosition = bdsrcEmployee.Position + 1;

        if (mlngRecordCount == mlngCurrentPosition)
        {
          cmdNext.Enabled = false;
        }
        else
        // mlngRecordCount <> mlngCurrentPosition
        {
          cmdNext.Enabled = true;
        }
        // mlngRecordCount = mlngCurrentPosition

        if (mlngCurrentPosition == 1)
        {
          cmdPrevious.Enabled = false;
        }
        else
        // mlngCurrentPosition <> 1
        {
          cmdPrevious.Enabled = true;
        }
        // mlngCurrentPosition = 1

      }
      else
      // mlngRecordCount <= 0
      {
        cmdPrevious.Enabled = false;
        cmdNext.Enabled = false;
      }
      // mlngRecordCount > 0

      UpdateLabel();
    }
    // ValidateRecords(System.Object, System.EventArgs)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmBindingContextWizard

}
// CopyPaste.Learning