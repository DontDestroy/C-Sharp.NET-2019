//***
// Action
//   - A class that is a singleton
//   - This means that only one instance can be created
// Created
//   - CopyPaste � 20240402 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240402 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;

namespace CopyPaste.Learning
{

  public class cpSingleton
  {

    #region "Constructors / Destructors"

    private cpSingleton()
      //***
      // Action
      //   - A private constructor
      //   - You can't create an instance with it outside the class
      // Called by
      //   - cpSingleton GetInstance()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpSingleton()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    ArrayList marrList = new ArrayList();
    static cpSingleton mcpInstance;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void AddString(string strNew)
      //***
      // Action
      //   - Add as string (strNew) to an ArrayList
      // Called by
      //   - frmSingleton.cmdAddString_Click(System.Object, System.EventArgs) Handles cmdAddString.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      marrList.Add(strNew);
    }
    // AddString(string)

    public static cpSingleton GetInstance()
      //***
      // Action
      //   - Get or create the instance of the singleton
      //   - If there is an instance
      //     - Do nothing
      //   - If Not
      //     - A new instance is created
      // Called by
      //   - frmSingleton.frmSingleton_Load(System.Object, System.EventArgs) Handles this.Load
      // Calls
      //   - cpSingleton()
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if (mcpInstance == null)
      {
        mcpInstance = new cpSingleton();
      }
      else
        // mcpInstance <> null
      {
      }
      // mcpInstance = null

      return mcpInstance;
    }
    // cpSingleton GetInstance()

    public string[] GetStrings()
      //***
      // Action
      //   - Return the strings inside the ArrayList as an array
      //   - Define a type and put the datatype System.String in it
      //   - Convert the marrList to an array of strings
      // Called by
      //   - frmSingleton.cmdAddString_Click(System.Object, System.EventArgs) Handles cmdAddString.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240402 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240402 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***

    {
      Type theType;

      theType = System.Type.GetType("System.String");

      return (string[])marrList.ToArray(theType);
    }
    // string[] GetStrings()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDefault

}
// CopyPaste.xxx