//***
// Action
//   - Showing a popup menu (Context menu)
// Created
//   - CopyPaste � 20240514 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240514 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmPopupMenu: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.MenuItem mnuTuesday;
    internal System.Windows.Forms.MenuItem mnuWednesday;
    internal System.Windows.Forms.MenuItem mnuThursday;
    internal System.Windows.Forms.MenuItem mnuFriday;
    internal System.Windows.Forms.MenuItem mnuMonday;
    internal System.Windows.Forms.ContextMenu ctmMain;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmPopupMenu));
      this.mnuTuesday = new System.Windows.Forms.MenuItem();
      this.mnuWednesday = new System.Windows.Forms.MenuItem();
      this.mnuThursday = new System.Windows.Forms.MenuItem();
      this.mnuFriday = new System.Windows.Forms.MenuItem();
      this.mnuMonday = new System.Windows.Forms.MenuItem();
      this.ctmMain = new System.Windows.Forms.ContextMenu();
      // 
      // mnuTuesday
      // 
      this.mnuTuesday.Index = 0;
      this.mnuTuesday.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                               this.mnuWednesday});
      this.mnuTuesday.Text = "Tuesday";
      // 
      // mnuWednesday
      // 
      this.mnuWednesday.Index = 0;
      this.mnuWednesday.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                 this.mnuThursday});
      this.mnuWednesday.Text = "Wednesday";
      // 
      // mnuThursday
      // 
      this.mnuThursday.Index = 0;
      this.mnuThursday.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                                this.mnuFriday});
      this.mnuThursday.Text = "Thursday";
      // 
      // mnuFriday
      // 
      this.mnuFriday.Index = 0;
      this.mnuFriday.Text = "Friday";
      // 
      // mnuMonday
      // 
      this.mnuMonday.Index = 0;
      this.mnuMonday.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                              this.mnuTuesday});
      this.mnuMonday.Text = "Monday";
      // 
      // ctmMain
      // 
      this.ctmMain.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
                                                                            this.mnuMonday});
      // 
      // frmPopupMenu
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 161);
      this.ContextMenu = this.ctmMain;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmPopupMenu";
      this.Text = "Popup Menu";

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmPopupMenu'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmPopupMenu()
      //***
      // Action
      //   - Create instance of 'frmPopupMenu'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmPopupMenu()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmPopupMenu
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmPopupMenu()
      // Created
      //   - CopyPaste � 20240514 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240514 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmPopupMenu());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmPopupMenu

}
// CopyPaste.Learning