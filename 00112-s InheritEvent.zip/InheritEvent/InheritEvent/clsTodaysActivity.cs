//***
// Action
//   - Implementation of a cpTodaysActivity
// Created
//   - CopyPaste � 20240531 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240531 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpTodaysActivity : cpDailyEvent
  {

    #region "Constructors / Destructors"

    public cpTodaysActivity(DateTime dtmStart, DateTime dtmEnd) : base()
      //***
      // Action
      //   - Create an instance of cpTodaysActivity
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpDailyEvent()
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdtmStart = dtmStart;
      mdtmEnd = dtmEnd;
    }
    // cpTodaysActivity(DateTime, DateTime)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public DateTime mdtmEnd;
    public DateTime mdtmStart;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpTodaysActivity

}
// CopyPaste.Learning