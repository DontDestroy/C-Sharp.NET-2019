//***
// Action
//   - Testing a Try ... Catch over methods
// Created
//   - CopyPaste � 20230808 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230808 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpProperties
  {

    #region "Constructors / Destructors"

    public cpProperties()
      //***
      // Action
      //   - Empty Constructor of cpProperties
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpProperties()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Run Method1
      //   - On error show
      //     - The error message (using ToString())
      //     - The error message
      //     - The StackTrace
      //     - The inner error message (using ToString())
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - Method1()
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        Method1();
      }
      catch (Exception theException)
      {
        Console.WriteLine("theException.ToString: \n{0}\n", theException.ToString());
        Console.WriteLine("theException.Message: \n{0}\n", theException.Message);
        Console.WriteLine("theException.StackTrace: \n{0}\n", theException.StackTrace);
        Console.WriteLine("theException.InnerException: \n{0}\n", theException.InnerException.ToString());
      }

      Console.ReadLine();
    }
    // Main() 

    public static void Method1()
      //***
      // Action
      //   - Run Method2
      // Called by
      //   - Main()
      // Calls
      //   - Method2()
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Method2();
    }
    // Method1()

    public static void Method2()
      //***
      // Action
      //   - Run Method3
      // Called by
      //   - Method1()
      // Calls
      //   - Method3()
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Method3();
      }
    // Method2()

    public static void Method3()
      //***
      // Action
      //   - An error is generated trying to convert a text into an integer
      // Called by
      //   - Method2()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230808 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230808 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      
      try
      {
        int aNumber = Convert.ToInt32("Not an integer");
      }
      catch (FormatException theFormatException)
      {
        throw new Exception("Exception occurred in Method3", theFormatException);
      }

    }
    // Method2()

    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpProperties

}
// CopyPaste.Learning