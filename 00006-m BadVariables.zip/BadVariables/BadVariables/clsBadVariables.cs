//***
// Action
//   - This is asking for trouble
//   - C# is selfprotecting for unknown or wrong variables
//   - In comparison with Visual Basic, the Option Explicit Off or Option Strict Off does not exist
// Created
//   - CopyPaste � 20220111 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220111 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace BadVariables
{

  class cpBadVariables
	{

    static void Main()
    //***
    // Action
    //   - Set values to some not defined variables (Will generate a compile error)
    //   - Show results at console screen
    //   - Wait for user interaction
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - string System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    // Created
    //   - CopyPaste � 20220111 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220111 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      // double dblEmployeeSalary;
      // int intNumberOfEmployee;
      // string strEmployeeName;
      // string strEmployeePhoneNumber;

      dblEmployeeSalary = 45000.0;
      intNumberOfEmployee = 1;
      strEmployeeName = "Buddy Jamsa";
      strEmployeePhoneNumber = "555-1212";
      
      // Console.WriteLine("Number of employees: " + intEmployeeNumber);
      // Console.WriteLine("Employee name: " + strEmployeName);
      // Console.WriteLine("Employee phone number: " + strEmployeesPhoneNumber);
      // Console.WriteLine("Employee salary: " + dblEmployeeWage);

      Console.WriteLine("Number of employees: " + intNumberOfEmployee);
      Console.WriteLine("Employee name: " + strEmployeeName);
      Console.WriteLine("Employee phone number: " + strEmployeePhoneNumber);
      Console.WriteLine("Employee salary: " + dblEmployeeSalary);
      
      Console.ReadLine();
		}
    // Main()

  }
  // cpBadVariables

}
// BadVariables