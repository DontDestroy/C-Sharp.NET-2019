//***
// Action
//   - The startup screen
//   - Create some Windows
//   - Loop thru the Windows
//     - Change something on it thru events
// Created
//   - CopyPaste � 20220817 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220817 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows;

namespace WindowTrackerEventsDelegates
{

  public partial class wpfStartupScreen : Window
  {

    #region "Constructors / Destructors"

    public wpfStartupScreen()
    //***
    // Action
    //   - Create instance of 'wpfStartupScreen'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // wpfStartupScreen()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCreate_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Initialize a new wpfWindow
    //   - Make it child of the wpfStartupScreen
    //   - Show it
    //   - Add it to the list of started Windows
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - ActionOnTheWindow(System.Object, cpwpfWindowRoutedEventArguments)
    //   - cpwpfWindowRoutedEventHandler wpfWindow.ActionWithWindow
    //   - List<wpfWindow> App.StartedWindows (Get)
    //   - OtherActionOnTheWindow(System.Object, cpwpfWindowRoutedEventArguments)
    //   - OtherActionOnTheWindow(System.Object, System.Windows.RoutedEventArgs)
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      wpfWindow aWindow = new wpfWindow();

      aWindow.ActionWithWindow += ActionOnTheWindow;
      aWindow.ActionWithWindow += OtherActionOnTheWindow;

      aWindow.Owner = this;
      aWindow.Show();
      ((App)Application.Current).StartedWindows.Add(aWindow);
    }
    // cmdCreate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCreate.Click

    private void cmdUpdate_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - Loop thru the list of started windows
    //     - Content becomes the current time
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - List<wpfWindow> App.StartedWindows (Get)
    //   - wpfWindow.SomeActionsOnTheWindow(string, string)
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      string strContent = "Refreshed at " + DateTime.Now.ToLongTimeString() + ".";
      string strTitle = "This is also changed.";

      foreach (wpfWindow aWindow in ((App)Application.Current).StartedWindows)
      {
        aWindow.SomeActionsOnTheWindow(strTitle, strContent);
      }
      // in ((App)Application.Current).StartedWindows

    }
    // cmdUpdate_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdUpdate.Click

    #endregion

    #region "Functionality"

    #region "Event"

    static void ActionOnTheWindow(System.Object theSender, cpwpfWindowRoutedEventArguments thewpfWindowRoutedEventArguments)
    //***
    // Action
    //   - Content becomes the current time thru the event arguments
    // Called by
    //   - Event (Clicking a button)
    // Calls
    //   - string wpfWindow.Content() (Get)
    //   - cpwpfWindowRoutedEventArguments.Content(string) (Set)
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      wpfWindow theThingThatContainsEvent;

      theThingThatContainsEvent = (wpfWindow)theSender;
      theThingThatContainsEvent.Content = thewpfWindowRoutedEventArguments.Content;
    }
    // ActionOnTheWindow(System.Object, System.Windows.RoutedEventArgs)

    static void OtherActionOnTheWindow(System.Object theSender, cpwpfWindowRoutedEventArguments thewpfWindowRoutedEventArguments)
    //***
    // Action
    //   - Title becomes another text thru the event arguments
    // Called by
    //   - Event (Clicking a button)
    // Calls
    //   - string wpfWindow.Title() (Get)
    //   - cpwpfWindowRoutedEventArguments.Title(string) (Set)
    // Created
    //   - CopyPaste � 20220817 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220817 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      wpfWindow theThingThatContainsEvent;

      theThingThatContainsEvent = (wpfWindow)theSender;
      theThingThatContainsEvent.Title = thewpfWindowRoutedEventArguments.Title;
    }
    // OtherActionOnTheWindow(System.Object, System.Windows.cpwpfWindowRoutedEventArguments)

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfStartupScreen

}
// WindowTrackerEventsDelegates