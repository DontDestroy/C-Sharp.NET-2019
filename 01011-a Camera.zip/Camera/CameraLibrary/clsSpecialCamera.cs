﻿//***
// Action
//   - Implementation of a cpSpecialCamera
//     - Inherits from cpCamera
//   - The way a cpSpecialCamera takes and saves photos is inherited
//     - All cpCamera and child classes do this in the same way
//   - The editing of a photo with a cpSpecialCamera makes must be implemented
//   - The sharing of photo with a cpSpecialCamera makes is given thru a delegate and an event
// Created
//   - CopyPaste – 20240810 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240810 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.Camera.Library;
using System;
using System.Diagnostics;

namespace CopyPaste.Camera.Library
{

	public class cpSpecialCamera : cpCamera
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpBasicCamera
		/// </summary>
		public cpSpecialCamera() : base()
		//***
		// Action
		//   - Basic constructor
		//   - Define how a cpSpecialCamera is sharing photos (Output Window)
		// Called by
		//   - CopyPaste.Camera.Test.cpProgram.Main()
		// Calls
		//   - cpCamera()
		//   - cpCamera.HowToShare(cpiShare) (Set)
		// Created
		//   - CopyPaste – 20240810 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240810 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			HowToShare = new cpWhatsApp();
		}
		// cpSpecialCamera()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		#region "Overrides"

		public override void Edit()
		//***
		// Action
		//   - Shows a message on the Debug Window
		//   - Beeps
		// Called by
		//   - CopyPaste.Camera.Test.cpProgram.Main()
		// Calls
		//   - cpCamera()
		// Created
		//   - CopyPaste – 20240810 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240810 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Photo is edited with special camera app");
			Console.Beep();
		}
		// Edit()

		#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpSpecialCamera

}
// CopyPaste.Camera.Library