//***
// Action
//   - Implementation of a cpOffice
//   - Inherits from cpEmployee
// Created
//   - CopyPaste � 20240405 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240405 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Employee
{

  public class cpOffice : cpEmployee
  {

    #region "Constructors / Destructors"

    public cpOffice() : base()
      //***
      // Action
      //   - Default constructor
      // Called by
      //   - 
      // Calls
      //   - cpEmployee()
      //   - Earnings(Decimal) (Set)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Earnings = 0;
    }
    // cpOffice()

    public cpOffice(string strName, cpSex thecpSex, DateTime dtmStartDate, Decimal decEarnings) : base(strName, thecpSex, dtmStartDate)
      //***
      // Action
      //   - Constructor with Name, Sex, StartDate and Earnings
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpEmployee(string, cpSex, DateTime)
      //   - Earnings(decimal) (Set)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Earnings = decEarnings;
    }
    // cpOffice(string, cpSex, DateTime, Decimal)
 
    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private decimal mdecEarnings;

    #endregion

    #region "Properties"

    public decimal Earnings
    {

      get
        //***
        // Action Get
        //   - Returns mdecEarnings
        // Called by
        //   - ShowInfo() 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mdecEarnings;
      }
      // decimal Earnings (Get)

      set
        //***
        // Action Set
        //   - mdecEarnings becomes value
        //   - Only positive values or zero are allowed
        // Called by
        //   - cpOffice()
        //   - cpOffice(string, cpSex, DateTime, decimal, byte)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240405 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240405 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {

        if (value >= 0)
        {
          mdecEarnings = value;
        }
        else
          // value < 0
        {
        }
        // value >= 0

      }
      // Earnings(decimal) (Set)

    }
    // decimal Earnings

    #endregion

    #region "Methods"

    #region "Overrides"

    public override void ShowInfo()
      //***
      // Action
      //   - Shows information to the console
      //     - Name, Sex, StartDate, Is it a Workanniversary, Is it CompanyParty
      //     - HourPrice and Shift
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - byte Shift (Get)
      //   - cpEmployee.ShowInfo()
      //   - decimal Earnings (Get)
      // Created
      //   - CopyPaste � 20240405 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240405 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      base.ShowInfo();
      Console.WriteLine("Earnings: {0}", Earnings);
    }
    // ShowInfo()

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpOffice

}
// CopyPaste.Learning.Employee