//***
// Action
//   - xample of a combo box
// Created
//   - CopyPaste � 20240330 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240330 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmComboBox: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdResult;
    internal System.Windows.Forms.Label lblArtist;
    internal System.Windows.Forms.ComboBox cmbArtist;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmComboBox));
      this.cmdResult = new System.Windows.Forms.Button();
      this.lblArtist = new System.Windows.Forms.Label();
      this.cmbArtist = new System.Windows.Forms.ComboBox();
      this.SuspendLayout();
      // 
      // cmdResult
      // 
      this.cmdResult.Location = new System.Drawing.Point(201, 224);
      this.cmdResult.Name = "cmdResult";
      this.cmdResult.TabIndex = 5;
      this.cmdResult.Text = "Result";
      this.cmdResult.Click += new System.EventHandler(this.cmdResult_Click);
      // 
      // lblArtist
      // 
      this.lblArtist.Location = new System.Drawing.Point(17, 16);
      this.lblArtist.Name = "lblArtist";
      this.lblArtist.Size = new System.Drawing.Size(88, 23);
      this.lblArtist.TabIndex = 3;
      this.lblArtist.Text = "&Choose Artist:";
      // 
      // cmbArtist
      // 
      this.cmbArtist.Items.AddRange(new object[] {
                                                   "2 Belgen",
                                                   "Duran Duran",
                                                   "INXS",
                                                   "Pink Floyd",
                                                   "Queen",
                                                   "Status Quo",
                                                   "Tangerin Dream",
                                                   "TC Matic",
                                                   "The Who",
                                                   "Won Ton Ton"});
      this.cmbArtist.Location = new System.Drawing.Point(113, 16);
      this.cmbArtist.Name = "cmbArtist";
      this.cmbArtist.Size = new System.Drawing.Size(160, 21);
      this.cmbArtist.Sorted = true;
      this.cmbArtist.TabIndex = 4;
      // 
      // frmComboBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Controls.Add(this.cmdResult);
      this.Controls.Add(this.lblArtist);
      this.Controls.Add(this.cmbArtist);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmComboBox";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "ComboBox";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmComboBox'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmComboBox()
      //***
      // Action
      //   - Create instance of 'frmComboBox'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmComboBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdResult_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Show the selected item in a messagebox
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      MessageBox.Show(cmbArtist.Text);
    }
    // cmdResult_Click(System.Object, System.EventArgs) Handles cmdResult.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmComboBox
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmComboBox());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmComboBox

}
// CopyPaste.Learning