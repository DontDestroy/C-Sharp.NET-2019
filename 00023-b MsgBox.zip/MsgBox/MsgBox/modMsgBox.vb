'***
' Action
'   - Showing a messagebox
' Created
'   - CopyPaste � 20210831 � VVDW
' Changed
'   - CopyPaste � yyyymmdd � VVDW � What changed
' Tested
'   - CopyPaste � 20210831 � VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On 
Option Strict On

Imports Microsoft.VisualBasic

Module modMsgBox

  Sub Main()
    '***
    ' Action
    '   - Show a message
    '   - Show a message with a title and 3 buttons
    ' Called by
    '   - 
    ' Calls
    '   - Microsoft.VisualBasic.Interaction.MsgBox(String, [Integer], [String])
    ' Created
    '   - CopyPaste � 20210831 � VVDW
    ' Changed
    '   - CopyPaste � yyyymmdd � VVDW � What changed
    ' Tested
    '   - CopyPaste � 20210831 � VVDW
    ' Keyboard key
    '   -
    ' Proposal (To Do)
    '   -
    '***

    MsgBox("Message")
    MsgBox("Message", MsgBoxStyle.AbortRetryIgnore, "Copy Paste")
  End Sub
  ' Main()

End Module
' modMsgBox