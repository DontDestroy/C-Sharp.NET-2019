<%@ Page language="c#" %>
<html>
<head>
   <title>ShowTime</title>
</head>
<body>
  <center><h1>ASP.NET ShowTime Demo</h1></center>
  <hr>
  <br>
  The current date and time time is <% =DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") %>
</body>
</html>