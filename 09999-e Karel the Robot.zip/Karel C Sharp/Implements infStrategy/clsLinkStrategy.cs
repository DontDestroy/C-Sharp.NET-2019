﻿//***
// Action
//   - Implementation of a LinkStrategy
// Created
//   - CopyPaste – 20251106 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251106 – VVDW
// Proposal (To Do)
//   -
//***

using kareltherobot;

namespace cpKarelTheRobot
{

  public class cpLinkStrategy : cpinfStrategy
  {

    #region "Constructors / Destructors"

    public cpLinkStrategy(cpinfStrategy theStrategy)
    //***
    // Action
    //   - Constructor of the start situation
    //   - Strategy next becomes the given strategy
    // Called by
    //   - cpMoveStrategy(cpinfStrategy)
    //   - cpShutDownStrategy(cpinfStrategy)
    //   - cpThreeBeeperLayerStrategy(cpinfStrategy)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      next = theStrategy;
    }
    // cpLinkStrategy(cpinfStrategy)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpinfStrategy next = new cpNullStrategy();

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public virtual void DoIt(cpCopyPasteRobot aRobot)
    //***
    // Action
    //   - Implementation of DoIt
    //     - The DoIt routine is runned from the defined strategy next with a given robot
    // Called by
    //   - cpinfStrategy.DoIt(cpCopyPasteRobot)
    // Calls
    //   - cpinfStrategy.DoIt(cpCopyPasteRobot)
    // Created
    //   - CopyPaste – 20251106 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251106 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      next.DoIt(aRobot);
    }
    // DoIt(cpCopyPasteRobot)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpLinkStrategy

}
// cpKarelTheRobot