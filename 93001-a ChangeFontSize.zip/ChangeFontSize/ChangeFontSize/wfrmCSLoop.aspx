<%@ Page Language="C#" %>

<html>
<head>
   <title>Font Size Demo</title>
</head>
<body>
  <center>
    <h1>Using ASP.NET to Change Font Sizes</h1>
  </center>
  <hr/>
  
  <% int intCounter;

       for (intCounter =1; intCounter < 8; intCounter++)
          {   
             Response.Write("<font size=");
             Response.Write(intCounter);    
             Response.Write(">");
             Response.Write("C#.Net Programming Tips & Techniques<br>");
          }

  %>
  
</body>
</html>