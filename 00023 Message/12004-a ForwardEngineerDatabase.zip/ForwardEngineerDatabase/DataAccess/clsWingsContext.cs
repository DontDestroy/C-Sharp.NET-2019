﻿//***
// Action
//   - Definition of the Database Context
// Created
//   - CopyPaste – 20230711 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230711 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.BusinessObjects;
using Microsoft.EntityFrameworkCore;
using System;

namespace CopyPaste.DataAccess
{

  public class cpWingsContext : DbContext
  {

    #region "Constructors / Destructors"

    public cpWingsContext()
    //***
    // Action
    //   - Constructor of cpWingsContext
    // Called by
    //   - 
    // Calls
    //   - ConnectionString(string) (Set)
    // Created
    //   - CopyPaste – 20230711 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230711 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      ConnectionString = @"Data Source=COPYPASTEPOWER\COPYPASTE;Initial Catalog = cpWingsV2ForwardEngineered ; Integrated Security = True; MultipleActiveResultSets=True";
    }
    // cpWingsContext()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public static string ConnectionString { get; set; }

    #region "01st creation of Database"

    ////***
    //// Action Get and Set
    ////   - First Entry point for the database context to create the model towards the database
    ////   - Do this for the first tests, put this in comments for later tests
    ////   - It will give possible errors, comment the correct lines in OnModelCreating
    //// Called by
    ////   - 
    //// Calls
    ////   - Person()
    //// Created
    ////   - CopyPaste – 20230711 – VVDW
    //// Changed
    ////   - CopyPaste – yyyymmdd – VVDW – What changed
    //// Tested
    ////   - CopyPaste – 20230711 – VVDW
    //// Keyboard key
    ////   - 
    //// Proposal (To Do)
    ////   - 
    ////***
    //public DbSet<Person> Person { get; set; }
    //// DbSet<Person> Person (Get)
    //// Person(DbSet<Person>) (Set)

    #endregion

    #region "02nd creation of Database"

    ////***
    //// Action Get and Set
    ////   - Second Entry point for the database context to create the model towards the database
    ////   - Do this for the second tests, put this in comments for later tests
    ////   - It will give possible errors, comment and uncomment the correct lines in OnModelCreating
    //// Called by
    ////   - 
    //// Calls
    ////   - Employee()
    //// Created
    ////   - CopyPaste – 20230711 – VVDW
    //// Changed
    ////   - CopyPaste – yyyymmdd – VVDW – What changed
    //// Tested
    ////   - CopyPaste – 20230711 – VVDW
    //// Keyboard key
    ////   - 
    //// Proposal (To Do)
    ////   - 
    ////***
    //public DbSet<Employee> Employee { get; set; }
    //// DbSet<Employee> Employee (Get)
    //// Employee(DbSet<Employee>) (Set)

    #endregion

    #region "03th creation of Database"

    ////***
    //// Action Get and Set
    ////   - Third Entry point for the database context to create the model towards the database
    ////   - Do this for the third tests, put this in comments for later tests
    ////   - It will give possible errors, comment and uncomment the correct lines in OnModelCreating
    ////   - Look at the discriminator field
    //// Called by
    ////   - 
    //// Calls
    ////   - Employee()
    ////   - Person()
    //// Created
    ////   - CopyPaste – 20230711 – VVDW
    //// Changed
    ////   - CopyPaste – yyyymmdd – VVDW – What changed
    //// Tested
    ////   - CopyPaste – 20230711 – VVDW
    //// Keyboard key
    ////   - 
    //// Proposal (To Do)
    ////   - 
    ////***
    //public DbSet<Person> Person { get; set; }
    //// DbSet<Person> Person (Get)
    //// Person(DbSet<Person>) (Set)
    //public DbSet<Employee> Employee { get; set; }
    //// DbSet<Employee> Employee (Get)
    //// Employee(DbSet<Employee>) (Set)

    #endregion

    #region "04th creation of Database"

    //***
    // Action Get and Set
    //   - Fourth and final Entry point for the database context to create the model towards the database
    //   - It will give possible errors, uncomment the correct lines in OnModelCreating
    // Called by
    //   - 
    // Calls
    //   - Booking()
    //   - Flight()
    //   - Passenger()
    //   - Pilot()
    // Created
    //   - CopyPaste – 20230711 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230711 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***

    public DbSet<Booking> Booking { get; set; }
    // DbSet<Booking> Booking (Get)
    // Booking(DbSet<Booking>) (Set)

    public DbSet<Flight> Flight { get; set; }
    // DbSet<Flight> Flight (Get)
    // Flight(DbSet<Flight>) (Set)

    public DbSet<Passenger> Passenger { get; set; }
    // DbSet<Passenger> Passenger (Get)
    // Passenger(DbSet<Passenger>) (Set)

    public DbSet<Pilot> Pilot { get; set; }
    // DbSet<Pilot> Pilot (Get)
    // Pilot(DbSet<Pilot>) (Set)

    #endregion

    #endregion

    //#region "Methods"

    #region "Overrides"

    protected override void OnConfiguring(DbContextOptionsBuilder theOptionsBuilder)
    //***
    // Action
    //   - While configuring the database context, we say it is a SQL Server database
    //   - Configure the DbContext by giving the correct ConnectionString
    // Called by
    //   - User action (Creating instance of cpWingsContext)
    // Calls
    //   - string ConnectionString (Get)
    // Created
    //   - CopyPaste – 20230711 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230711 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theOptionsBuilder.UseSqlServer(ConnectionString);
    }
    // OnConfiguring(DbContextOptionsBuilder)

    protected override void OnModelCreating(ModelBuilder theModelBuilder)
    //***
    // Action
    //   - Creating the table of Booking gives an error that there is no primary key defined
    //     - Force the key to a combination of FlightNo and PassengerId (both of Booking)
    //   - Creating the table of Flight gives an error that there is no fields that is candidate for the primary key
    //     - Force the key to FlightNo
    //   - Creating the table of Employee gives an error that there is no primary key defined
    //     - Force the key to PersonId
    //   - Creating the table of Passenger gives an error that there is no primary key defined
    //     - Force the key to PersonId
    //   - There are two relations between a Flight and a Pilot
    //     - One for the Pilot and one for the CoPilot
    //     - Force the key to a combination of FlightAsPilot and PilotId
    //     - Force the key to a combination of FlightAsCoPilot and CoPilotId
    // Called by
    //   - User action (Creating instance of cpWingsContext)
    // Calls
    //   - ICollection<Flight> Pilot.FlightAsPilot (Get)
    //   - ICollection<Flight> Pilot.FlightAsCoPilot (Get)
    //   - int Booking.FlightNo (Get)
    //   - int Booking.PassengerId (Get)
    //   - int Flight.CoPilotId (Get)
    //   - int Flight.FlightNo (Get)
    //   - int Flight.PilotId (Get)
    //   - int Employee.PersonId (Get)
    //   - int Passenger.PersonId (Get)
    //   - Pilot Pilot.CoPilot (Get)
    //   - Pilot Pilot.Pilot (Get)
    // Created
    //   - CopyPaste – 20230711 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230711 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      // The order is important, putting Booking after Passenger, has a different result
      theModelBuilder.Entity<Booking>().HasKey(theBooking => new { theBooking.FlightNo, theBooking.PassengerId });
      theModelBuilder.Entity<Flight>().HasKey(theFlight => theFlight.FlightNo);
      theModelBuilder.Entity<Employee>().HasKey(theEmployee => theEmployee.PersonId);
      theModelBuilder.Entity<Passenger>().HasKey(thePassenger => thePassenger.PersonId);
      theModelBuilder.Entity<Pilot>().HasMany(thePilot => thePilot.FlightAsPilot).WithOne(thePilot => thePilot.Pilot).HasForeignKey(theFlight => theFlight.PilotId).OnDelete(DeleteBehavior.Restrict);
      theModelBuilder.Entity<Pilot>().HasMany(theCoPilot => theCoPilot.FlightAsCoPilot).WithOne(theCoPilot => theCoPilot.CoPilot).HasForeignKey(theFlight => theFlight.CoPilotId).OnDelete(DeleteBehavior.Restrict);
      base.OnModelCreating(theModelBuilder);
    }
    // OnModelCreating(ModelBuilder)

    #endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpWingsContext

}
// CopyPaste.DataAccess
