//***
// Action
//   - Startup screen for a Multithreading demo
// Created
//   - CopyPaste � 20220818 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220818 � VVDW
// Proposal (To Do)
//   - There is an error in the code, try to find it and solve it
//***

using System.Threading;
using System.Windows.Threading;

namespace Multithreading
{

  public partial class wpfStartup : System.Windows.Window
  {

    #region "Constructors / Destructors"

    public wpfStartup()
    //***
    // Action
    //   - Create instance of 'wpfStartup'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      InitializeComponent();
    }
    // wpfStartup()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdBackgroundWorker_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - A demo of something that works in the background (in a different thread)
    //   - A dialog to show primes is shown
    // Called by
    //   - Manual action (Clicking a button)
    // Calls
    //   - wpfBackgroundWorkerDemo()
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      wpfBackgroundWorkerDemo theDemo = new wpfBackgroundWorkerDemo();
      theDemo.ShowDialog();
    }
    // cmdBackgroundWorker_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdBackgroundWorker.Click

    private void cmdCorrectWay_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - You try to change a text in a textbox in a different thread
    // Called by
    //   - Manual action (Clicking a button)
    // Calls
    //   - ChangeTextCorrectWay()
    //   - ChangeTextCorrectWayLambda()
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      Thread thread = new Thread(ChangeTextCorrectWay);
      // Thread thread = new Thread(ChangeTextCorrectWayLambda);
      thread.Start();
    }
    // cmdCorrectWay_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCorrectWay.Click

    private void cmdWrongWay_Click(System.Object theSender, System.Windows.RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - You try to change a text in a textbox in a different thread
    //   - This will fail
    // Called by
    //   - Manual action (Clicking a button)
    // Calls
    //   - ChangeText()
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - This is a wrong way of programming Multithreading
    //   - Can you see what is wrong?
    //   - When you run it you get an error message, try to understand it
    //***
    {
      Thread thread = new Thread(ChangeText);
      thread.Start();
    }
    // cmdWrongWay_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdWrongWay.Click

    #endregion

    #region "Functionality"

    #region "Event"

    private delegate void DoSomething();

    #endregion

    #region "Sub / Function"

    private void ChangeText()
    //***
    // Action
    //   - Change text in a textbox
    // Called by
    //   - ChangeTextCorrectWay()
    //   - ChangeTextCorrectWayLambda()
    //   - cmdWrongWay_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdWrongWay.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      txtDemo.Text = "Here is some other text";
    }
    // ChangeText()

    private void ChangeTextCorrectWay()
    //***
    // Action
    //   - Change text in a textbox using a delegate
    // Called by
    //   - cmdCorrectWay_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCorrectWay.Click
    // Calls
    //   - ChangeText()
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      DoSomething doTheUpdate = new DoSomething(ChangeText);

      this.Dispatcher.BeginInvoke(DispatcherPriority.Normal, doTheUpdate);
    }
    // ChangeTextCorrectWay()

    private void ChangeTextCorrectWayLambda()
    //***
    // Action
    //   - Change text in a textbox using a Lambda expression
    // Called by
    //   - cmdCorrectWay_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdCorrectWay.Click
    // Calls
    //   - ChangeText()
    // Created
    //   - CopyPaste � 20220818 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220818 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - This is very hard to read, especially when there is a lot of code
    //   - I prefer the delegate solution
    //***
    {

      this.Dispatcher.BeginInvoke(DispatcherPriority.Normal,
        (ThreadStart) delegate ()
        {
          ChangeText();
        }
      );

    }
    // ChangeTextCorrectWayLambda()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfStartup

}
// Multithreading