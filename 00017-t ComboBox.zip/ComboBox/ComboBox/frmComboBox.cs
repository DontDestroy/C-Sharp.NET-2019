//***
// Action
//   - Example of a combobox
// Created
//   - CopyPaste � 20240330 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240330 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmComboBox: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdDone;
    internal System.Windows.Forms.ComboBox cmbChoose;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmComboBox));
      this.cmdDone = new System.Windows.Forms.Button();
      this.cmbChoose = new System.Windows.Forms.ComboBox();
      this.SuspendLayout();
      // 
      // cmdDone
      // 
      this.cmdDone.Location = new System.Drawing.Point(128, 115);
      this.cmdDone.Name = "cmdDone";
      this.cmdDone.TabIndex = 3;
      this.cmdDone.Text = "Done";
      this.cmdDone.Click += new System.EventHandler(this.cmdDone_Click);
      // 
      // cmbChoose
      // 
      this.cmbChoose.Items.AddRange(new object[] {
                                                   "Birds",
                                                   "Cats",
                                                   "Dogs",
                                                   "Fish",
                                                   "Horses"});
      this.cmbChoose.Location = new System.Drawing.Point(32, 35);
      this.cmbChoose.Name = "cmbChoose";
      this.cmbChoose.Size = new System.Drawing.Size(136, 21);
      this.cmbChoose.TabIndex = 2;
      this.cmbChoose.Text = "Pets";
      // 
      // frmComboBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(328, 173);
      this.Controls.Add(this.cmdDone);
      this.Controls.Add(this.cmbChoose);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmComboBox";
      this.Text = "ComboBox";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmComboBox'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmComboBox()
      //***
      // Action
      //   - Create instance of 'frmComboBox'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmComboBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdDone_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The text "Pets" is not an item of the combobox
      //   - If selected item is nothing
      //     - Show messagebox that something must be selected
      //   - IfNot
      //     - Show the text of the selected item
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (cmbChoose.SelectedItem == null)
      {
        MessageBox.Show("You must select an item");
      }
      else
        // cmbChoose.SelectedItem <> null
      {
        MessageBox.Show("You selected: " + cmbChoose.SelectedItem.ToString());
      }
      // cmbChoose.SelectedItem = null
    
    }
    // cmdDone_Click(System.Object, System.EventArgs) Handles cmdDone.Click
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmComboBox
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmComboBox());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmComboBox

}
// CopyPaste.Learning