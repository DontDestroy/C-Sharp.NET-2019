//***
// Action
//   - Define a cpDay (Day, Month, Year)
//   - A constructor, a check and a presentation
// Created
//   - CopyPaste � 20220308 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220308 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Windows.Forms;

namespace CopyPaste.Learning.Toolkit
{

  public class cpDay
	{

    #region "Constructors / Destructors"
    
    public cpDay(int intDay, int intMonth, int intYear)
    //***
    // Action
    //   - Create a new instance of cpDay
    //   - Check the month
    //   - Check the day
    //   - Define the year
    // Called by
    //   - cpEmployee.New(string, string, int, int, int, int, int, int)
    // Calls
    //   - int CheckDay(int)
    // Created
    //   - CopyPaste � 20220308 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220308 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      if (intMonth > 0 && intMonth <= 12)
      {
        mintMonth = intMonth;
      }
      else
      // (intMonth <= 0 || intMonth > 12)
      {
        string strErrorMessage = "Month invalid. Set to month 1.";
      
        MessageBox.Show(strErrorMessage, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
        mintMonth = 1;
      }
      //' (lngMonth > 0 AndAlso lngMonth <= 12)

      mintDay = CheckDay(intDay);
      mintYear = intYear;
    }
    // cpDay(int, int, int)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mintDay;
    private int mintMonth;
    private int mintYear;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    private int CheckDay(int intTestDay)
    //***
    // Action
    //   - Check if the day is correct
    //   - Define the possible months
    //   - Check for leap year
    // Called by
    //   - cpDay(int, int, int)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220308 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220308 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {

      int[] arrintDaysPerMonth = new int[] {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

      if (intTestDay > 0 && intTestDay <= arrintDaysPerMonth[mintMonth])
      {
        return intTestDay;
      }
      else
        // (intTestDay <= 0 || intTestDay > arrintDaysPerMonth[mintMonth])
      {
      }
      // (intTestDay > 0 && intTestDay <= arrintDaysPerMonth[mintMonth])

      // Check for leap year in February

      if (mintMonth == 2 && intTestDay == 29 && mintYear % 400 == 0 || mintYear % 4 == 0 && mintYear % 100 != 0)
      {
        return intTestDay;
      }
      else
        // Not (mintMonth == 2 &&  intTestDay == 29 && mintYear % 400 == 0 || mintYear % 4 == 0 && mintYear % 100 != 0)
      {
        string strErrorMessage = "Day " + intTestDay + " invalid. Set to day 1. ";
        MessageBox.Show(strErrorMessage, "", MessageBoxButtons.OK, MessageBoxIcon.Error);
        return 1;
      }                                                                                                    
      // (mintMonth == 2 &&  intTestDay == 29 && mintYear % 400 == 0 || mintYear % 4 == 0 && mintYear % 100 != 0)

    }
    // int CheckDay(int)

    public string ToStandardString()
    //***
    // Action
    //   - Return a string that defines the value of cpDay
    // Called by
    //   - string cpEmployee.ToStandardString()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220308 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220308 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return mintDay + "/" + mintMonth + "/" + mintYear;
    }
    // string ToStandardString()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDay

}
// CopyPaste.Learning.Toolkit