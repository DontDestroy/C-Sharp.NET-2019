﻿//***
// Action
//   - Compare an array of strings
//   - Compare a readonly Span of characters
// Created
//   - CopyPaste – 20260531 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260531 – VVDW
// Proposal (To Do)
//   -
//***

using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using System;
using System.Collections.Generic;

namespace CopyPaste.Learning
{

  [MemoryDiagnoserAttribute]
  public class cpSplitString
  {

    #region "Constructors / Destructors"

    public cpSplitString()
    //***
    // Action
    //   - Basic constructor
    // Called by
    //   - Main()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20260531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260531 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpSplitString()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    [BenchmarkAttribute]
    public void ArrayOfStrings()
    //***
    // Action
    //   - Define a given text
    //   - Define an array of results
    //   - Assign a given text
    //   - Split the given text into the array of results (Allocatas a new array and substrings)
    //   - Have 3 variables with the result after the split
    // Called by    
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260531 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      char chrDelimiter = ',';
      string strInput;
      string strFirst;
      string strSecond;
      string strThird;
      string[] strResult;

      strInput = "123,456,789";
      strResult = strInput.Split(chrDelimiter);

      strFirst = strResult[0];
      strSecond = strResult[1];
      strThird = strResult[2];
    }
    // ArrayOfStrings()

    [BenchmarkAttribute]
    public void SpanOfStrings()
    //***
    // Action
    //   - Define a given text
    //   - Define an array of results
    //   - Assign a given text
    //   - Split the given text into the array of results (Allocatas a new array and substrings)
    //   - Have 3 variables with the result after the split
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260531 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260531 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      char chrDelimiter = ',';

      int intFirstDelimiter;

      ReadOnlySpan<char> rospnInput;
      ReadOnlySpan<char> rospnFirst;
      ReadOnlySpan<char> rospnRest;
      ReadOnlySpan<char> rospnSecond;
      ReadOnlySpan<char> rospnThird;

      rospnInput = "123,456,789".AsSpan();
      intFirstDelimiter = rospnInput.IndexOf(chrDelimiter);
      rospnFirst = rospnInput[..intFirstDelimiter];
      intFirstDelimiter++;
      rospnRest = rospnInput[intFirstDelimiter..];
      intFirstDelimiter = rospnRest.IndexOf(chrDelimiter);
      rospnSecond = rospnRest[..intFirstDelimiter];
      intFirstDelimiter++;
      rospnThird = rospnRest[intFirstDelimiter..];
    }
    // SpanOfStrings()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpSplitString

}
// CopyPaste.Learning