//***
// Action
//   - Use an XML to fill a data set
// Created
//   - CopyPaste � 20251127 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20251127 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Data;
using System.Data.SqlClient;

namespace CopyPaste.Learning
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main()
      //***
      // Action
      //   - Try to
      //     - Define a data set
      //     - Read the XML information into the data set
      //     - Loop thru the records
      //       - Show Title, Author, Publisher and price information
      //   - When something fails
      //     - The error information is shown
      //   - Wait for user action
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20251127 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20251127 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      try
      {
        DataSet theDataSet = new DataSet();

        theDataSet.ReadXml("Authors.XML");

        for (int lngCounter = 0; lngCounter < theDataSet.Tables[0].Rows.Count; lngCounter++)
        {
          Console.WriteLine(theDataSet.Tables[0].Rows[lngCounter]["Title"]);
          Console.WriteLine(theDataSet.Tables[0].Rows[lngCounter]["Author"]);
          Console.WriteLine(theDataSet.Tables[0].Rows[lngCounter]["Publisher"]);
          Console.WriteLine(theDataSet.Tables[0].Rows[lngCounter]["Price"]);
        }
        // lngCounter = theDataSet.Tables(0).Rows.Count
      
      }
      catch (Exception theException)
      {
        Console.WriteLine("Exception: " + theException.Message);
        Console.WriteLine(theException.ToString());
      }
      finally
      {
        Console.ReadLine();
      }

    }
		// Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpProgram

}
// CopyPaste.Learning