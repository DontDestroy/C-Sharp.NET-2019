﻿<%@ Page Language="vb" AutoEventWireup="false" CodeBehind="wfrmWelcome.aspx.vb" Inherits="Welcome.CopyPaste.Learning.wfrmWelcome" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Welcome</title>
</head>
<body>
    <form id="wfrmWelcome" method="post" runat="server">
      <DIV id="lblTitle" style="Z-INDEX: 101; POSITION: absolute; WIDTH: 400px; DISPLAY: inline; HEIGHT: 24px; TOP: 24px; LEFT: 24px"
        ms_positioning="FlowLayout">Enter your name and hit the Start button</DIV>
      <asp:TextBox id="txtName" style="Z-INDEX: 102; POSITION: absolute; TOP: 64px; LEFT: 24px" runat="server"></asp:TextBox>
      <asp:Button id="cmdStart" style="Z-INDEX: 103; POSITION: absolute; TOP: 104px; LEFT: 24px" runat="server"
        Text="Start"></asp:Button>
      <asp:Label id="lblMessage" style="Z-INDEX: 104; POSITION: absolute; TOP: 152px; LEFT: 24px"
        runat="server">Label</asp:Label>
    </form>
</body>
</html>
