//***
// Action
//   - Ask 3 numbers
//   - Use those numbers to generate a color
//   - The form gets that color
// Created
//   - CopyPaste � 20240220 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240220 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTextBox: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.Button cmdExit;
    internal System.Windows.Forms.Button cmdShow;
    internal System.Windows.Forms.Label lblGreen;
    internal System.Windows.Forms.Label lblBlue;
    internal System.Windows.Forms.Label lblRed;
    internal System.Windows.Forms.TextBox txtGreen;
    internal System.Windows.Forms.TextBox txtBlue;
    internal System.Windows.Forms.TextBox txtRed;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTextBox));
      this.cmdExit = new System.Windows.Forms.Button();
      this.cmdShow = new System.Windows.Forms.Button();
      this.lblGreen = new System.Windows.Forms.Label();
      this.lblBlue = new System.Windows.Forms.Label();
      this.lblRed = new System.Windows.Forms.Label();
      this.txtGreen = new System.Windows.Forms.TextBox();
      this.txtBlue = new System.Windows.Forms.TextBox();
      this.txtRed = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // cmdExit
      // 
      this.cmdExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.cmdExit.Location = new System.Drawing.Point(120, 160);
      this.cmdExit.Name = "cmdExit";
      this.cmdExit.TabIndex = 15;
      this.cmdExit.Text = "&Exit";
      this.cmdExit.Click += new System.EventHandler(this.cmdExit_Click);
      // 
      // cmdShow
      // 
      this.cmdShow.Location = new System.Drawing.Point(16, 160);
      this.cmdShow.Name = "cmdShow";
      this.cmdShow.TabIndex = 14;
      this.cmdShow.Text = "&Show Color";
      this.cmdShow.Click += new System.EventHandler(this.cmdShow_Click);
      // 
      // lblGreen
      // 
      this.lblGreen.Location = new System.Drawing.Point(16, 72);
      this.lblGreen.Name = "lblGreen";
      this.lblGreen.Size = new System.Drawing.Size(64, 23);
      this.lblGreen.TabIndex = 10;
      this.lblGreen.Text = "&Green:";
      // 
      // lblBlue
      // 
      this.lblBlue.Location = new System.Drawing.Point(16, 112);
      this.lblBlue.Name = "lblBlue";
      this.lblBlue.Size = new System.Drawing.Size(64, 23);
      this.lblBlue.TabIndex = 12;
      this.lblBlue.Text = "&Blue:";
      // 
      // lblRed
      // 
      this.lblRed.Location = new System.Drawing.Point(16, 32);
      this.lblRed.Name = "lblRed";
      this.lblRed.Size = new System.Drawing.Size(64, 23);
      this.lblRed.TabIndex = 8;
      this.lblRed.Text = "&Red:";
      // 
      // txtGreen
      // 
      this.txtGreen.Location = new System.Drawing.Point(88, 72);
      this.txtGreen.MaxLength = 3;
      this.txtGreen.Name = "txtGreen";
      this.txtGreen.Size = new System.Drawing.Size(64, 20);
      this.txtGreen.TabIndex = 11;
      this.txtGreen.Text = "";
      this.txtGreen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGeneral_KeyPress);
      this.txtGreen.Validating += new System.ComponentModel.CancelEventHandler(this.txtGeneral_Validating);
      // 
      // txtBlue
      // 
      this.txtBlue.Location = new System.Drawing.Point(88, 112);
      this.txtBlue.MaxLength = 3;
      this.txtBlue.Name = "txtBlue";
      this.txtBlue.Size = new System.Drawing.Size(64, 20);
      this.txtBlue.TabIndex = 13;
      this.txtBlue.Text = "";
      this.txtBlue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGeneral_KeyPress);
      this.txtBlue.Validating += new System.ComponentModel.CancelEventHandler(this.txtGeneral_Validating);
      // 
      // txtRed
      // 
      this.txtRed.Location = new System.Drawing.Point(88, 32);
      this.txtRed.MaxLength = 3;
      this.txtRed.Name = "txtRed";
      this.txtRed.Size = new System.Drawing.Size(64, 20);
      this.txtRed.TabIndex = 9;
      this.txtRed.Text = "";
      this.txtRed.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtGeneral_KeyPress);
      this.txtRed.Validating += new System.ComponentModel.CancelEventHandler(this.txtGeneral_Validating);
      // 
      // frmTextBox
      // 
      this.AcceptButton = this.cmdShow;
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.CancelButton = this.cmdExit;
      this.ClientSize = new System.Drawing.Size(210, 199);
      this.Controls.Add(this.cmdExit);
      this.Controls.Add(this.cmdShow);
      this.Controls.Add(this.lblGreen);
      this.Controls.Add(this.lblBlue);
      this.Controls.Add(this.lblRed);
      this.Controls.Add(this.txtGreen);
      this.Controls.Add(this.txtBlue);
      this.Controls.Add(this.txtRed);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.MaximizeBox = false;
      this.Name = "frmTextBox";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Red Green Blue (RGB)";
      this.Closing += new System.ComponentModel.CancelEventHandler(this.frmTextBox_Closing);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTextBox'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240220 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240220 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTextBox()
      //***
      // Action
      //   - Create instance of 'frmTextBox'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240220 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240220 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTextBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdExit_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Close the form
      // Called by
      //   - User action (Hitting a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240220 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240220 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      this.Close();   
    }
    // cmdExit_Click(System.Object, System.EventArgs) Handles cmdExit.Click

    private void cmdShow_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Read the 3 byte values from the screen
      //   - Create a color with it
      //   - The backcolor of the form becomes that color
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240220 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240220 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      byte bytBlue = Convert.ToByte(txtBlue.Text);
      byte bytGreen = Convert.ToByte(txtGreen.Text);
      byte bytRed = Convert.ToByte(txtRed.Text);

      this.BackColor = Color.FromArgb(bytRed, bytGreen, bytBlue);
    }
    // cmdShow_Click(System.Object, System.EventArgs) Handles cmdShow.Click

    private void frmTextBox_Closing(System.Object theSender, System.ComponentModel.CancelEventArgs theCancelEventArguments)
      //***
      // Action
      //   - Show a messagebox with a confirmation
      //   - If Yes
      //     - Form is closed
      //   - If Not Yes
      //     - Closing is cancelled
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240220 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240220 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (MessageBox.Show("Do you want to close?", "Closing", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
      {
      }
      else
        // MessageBox.Show(xxx) <> DialogResult.Yes
      {
        theCancelEventArguments.Cancel = true;
      }
      // MessageBox.Show(xxx) = DialogResult.Yes
    
    }
    // frmTextBox_Closing(System.Object, System.ComponentModel.CancelEventArgs) Handling this.Closing

    private void txtGeneral_KeyPress(System.Object theSender, System.Windows.Forms.KeyPressEventArgs theKeyPressEventArguments)
      //***
      // Action
      //   - The moment you type a character
      //   - Is the character a digit or the back button
      //   - If So
      //     - Execute the KeyPress action
      //   - If Not
      //     - Cancel the KeyPress action by doing nothing
      // Called by
      //   - User action (Typing a character)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240220 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240220 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      char backButton;

      backButton = (char)8;

      if ((Char.IsDigit(theKeyPressEventArguments.KeyChar)) || (theKeyPressEventArguments.KeyChar == backButton))
      {
      }
      else
        // Not Char.IsDigit(theKeyPressEventArguments.KeyChar) AndAlso theKeyPressEventArguments.KeyChar <> backButton
      {
        theKeyPressEventArguments.Handled = true;
      }
      // Char.IsDigit(theKeyPressEventArguments.KeyChar) OrElse theKeyPressEventArguments.KeyChar = backButton
    
    }
    // txtGeneral_KeyPress(System.Object, System.Windows.Forms.KeyPressEventArgs) Handles txtBlue.KeyPress, txtGreen.KeyPress, txtRed.KeyPress
    
    private void txtGeneral_Validating(System.Object theSender, System.ComponentModel.CancelEventArgs theCancelEventArguments)
      //***
      // Action
      //   - The moment you validate the control (after leaving)
      //   - theSender is casted as a textbox
      //   - Try to convert the content of the textbox into a byte
      //   - When this fails
      //     - There is something typed
      //       - Show a messasge that the entered text must be a byte value
      //     - If Not
      //       - Show a message that something must be filled in
      //     - Validation action is cancelled
      // Called by
      //   - User action (Validating a textbox)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240220 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240220 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      byte bytColor;
      TextBox txtGeneral = (TextBox)theSender;

      try
      {
        bytColor = Convert.ToByte(txtGeneral.Text);
      }
      catch (Exception theException)
      {

        if (txtGeneral.Text.Length > 0)
        {
          MessageBox.Show("Do not enter text or a number bigger than 255!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
        else
          // txtGeneral.Text.Length <= 0
        {
          MessageBox.Show("You have to fill in something !", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Hand);
        }
        // txtGeneral.Text.Length > 0

        theCancelEventArguments.Cancel = true;
      }
      finally
      {
      }
    
    }
    // txtGeneral_Validating(System.Object, System.ComponentModel.CancelEventArgs) Handles txtBlue.Validating, txtGreen.Validating, txtRed.Validating

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmTextBox
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240220 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240220 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmTextBox());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTextBox

}
// CopyPaste.Learning