'***
' Action
'   - Definition of cpNegativeNumberException
' Created
'   - CopyPaste � 20230820 � VVDW
' Changed
'   - CopyPaste � yyyymmdd � VVDW � What changed
' Tested
'   - CopyPaste � 20230820 � VVDW
' Proposal (To Do)
'   -
'***

Option Explicit On
Option Strict On

Namespace CopyPaste.Learning

  Public Class cpNegativeNumberException
    Inherits ApplicationException

#Region "Constructors / Destructors"

    Public Sub New()
      '***
      ' Action
      '   - Constructor for cpNegativeNumberException with no parameters
      ' Called by
      '   - 
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste � 20230820 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20230820 � VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      MyBase.New("Illegal operation for a negative number")
    End Sub
    ' New()

    Public Sub New(ByVal strMessage As String)
      '***
      ' Action
      '   - Constructor for cpNegativeNumberException with a text as parameter
      ' Called by
      '   - frmSquareRootTest.SquareRoot(Double) As Double
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste � 20230820 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20230820 � VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      MyBase.New(strMessage)
    End Sub
    ' New(String)

    Public Sub New(ByVal strMessage As String, ByVal theInnerException As Exception)
      '***
      ' Action
      '   - Constructor for cpNegativeNumberException with a text and an exception as parameters
      ' Called by
      '   - 
      ' Calls
      '   - 
      ' Created
      '   - CopyPaste � 20230820 � VVDW
      ' Changed
      '   - CopyPaste � yyyymmdd � VVDW � What changed
      ' Tested
      '   - CopyPaste � 20230820 � VVDW
      ' Keyboard key
      '   - 
      ' Proposal (To Do)
      '   - 
      '***

      MyBase.New(strMessage, theInnerException)
    End Sub
    ' New(String, Exception)

#End Region

    '#Region "Designer"
    '#End Region

    '#Region "Structures"
    '#End Region

    '#Region "Fields"
    '#End Region

    '#Region "Properties"
    '#End Region

    '#Region "Methods"

    '#Region "Overrides"
    '#End Region

    '#Region "Controls"
    '#End Region

    '#Region "Functionality"

    '#Region "Event"
    '#End Region

    '#Region "Sub / Function"
    '#End Region

    '#End Region

    '#End Region

    '#Region "Not used"
    '#End Region

  End Class
  ' cpNegativeNumberException

End Namespace
' CopyPaste.Learning