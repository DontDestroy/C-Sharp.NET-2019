//***
// Action
//   - Reading and writing a random access file
// Created
//   - CopyPaste � 20230809 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230809 � VVDW
// Proposal (To Do)
//   -
//***

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmRandomTest : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    private System.ComponentModel.Container components = null;

    internal System.Windows.Forms.TextBox txtText;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmRandomTest));
      this.txtText = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(8, 6);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(392, 328);
      this.txtText.TabIndex = 1;
      this.txtText.Text = "";
      // 
      // frmRandomTest
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(408, 341);
      this.Controls.Add(this.txtText);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmRandomTest";
      this.Text = "RandomTest";
      this.Load += new System.EventHandler(this.frmRandomTest_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmRandomTest'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmRandomTest()
      //***
      // Action
      //   - Create instance of 'frmRandomTest'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmRandomTest()

    #endregion

    //#region "Designer"
    //#endregion

    #region "Structures"

    public struct EmployeeData
    {
      public DateTime dtmBirthDate;
      [VBFixedStringAttribute(20)]
      public string strTitle;
      [VBFixedStringAttribute(20)]
      public string strLastName;
      [VBFixedStringAttribute(20)]
      public string strFirstName;
      [VBFixedStringAttribute(40)]
      public string strAddress;
      [VBFixedStringAttribute(20)]
      public string strCity;
      [VBFixedStringAttribute(2)]
      public string strState;
      [VBFixedStringAttribute(10)]
      public string strZipCode;
      [VBFixedStringAttribute(20)]
      public string strPhone;
      [VBFixedStringAttribute(20)]
      public string strJobTitle;
      public decimal decSalary;
      public DateTime dtmStartDate;
    }
    // EmployeeData

    #endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmRandomTest_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Set font to Courier New 10
      //   - Find first free filenumber (lngFileNumber)
      //   - Determine the filename that contain the records
      //   - Open file (lngFileNumber) random readwrite with a specific length of the record
      //   - Add a first employee
      //   - Add a second employee
      //   - Close the file (lngFileNumber)
      //   - Open file (lngFileNumber) random readwrite with a specific length of the record
      //   - Get a random employee
      //   - Show the information of that employee
      //   - Set cursor at the start of the textbox
      //   - Seek the second employee and show firstname
      //   - Seek the first employee and show firstname
      //   - Close the file (lngFileNumber)
      // Called by
      //   - User action (Loading the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - Organisation � yyyymmdd � Initials of programmer � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - List of actions that can be added to the functionality
      //***
    {
      EmployeeData theEmployee = new EmployeeData();
      int lngFileNumber;
      Random rndNumber = new Random();
      string strFileName;
      string strTemp;
      System.ValueType theResult = theEmployee;

      this.Font = new Font("Courier New", 10);
      lngFileNumber = FileSystem.FreeFile();
      strFileName = Directory.GetCurrentDirectory() + "\\Employee.dat";

      FileSystem.FileOpen(lngFileNumber, strFileName, OpenMode.Random, OpenAccess.ReadWrite, OpenShare.Default, Strings.Len(theEmployee));

      theEmployee.strTitle = "Mr.";
      theEmployee.strLastName = "Smith";
      theEmployee.strFirstName = "John";
      theEmployee.dtmBirthDate = Convert.ToDateTime("04/01/1980");
      theEmployee.strAddress = "1234 Stupendous Street";
      theEmployee.strCity = "Washington";
      theEmployee.strState = "DC";
      theEmployee.strZipCode = "10001";
      theEmployee.strPhone = "212-555-0101";
      theEmployee.strJobTitle = "District Manager";
      theEmployee.decSalary = 75000;
      theEmployee.dtmStartDate = Convert.ToDateTime("01/01/2002");

      FileSystem.FilePut(lngFileNumber, theEmployee, 1);

      theEmployee.strTitle = "Mr.";
      theEmployee.strLastName = "Van De Walle";
      theEmployee.strFirstName = "Vincent";
      theEmployee.dtmBirthDate = Convert.ToDateTime("06/05/1970");
      theEmployee.strAddress = "Hazebos 13";
      theEmployee.strCity = "Zonnebeke";
      theEmployee.strState = "WV";
      theEmployee.strZipCode = "8980";
      theEmployee.strPhone = "057-21 25 71";
      theEmployee.strJobTitle = "Teacher";
      theEmployee.decSalary = 75000;
      theEmployee.dtmStartDate = Convert.ToDateTime("01/10/1991");

      FileSystem.FilePut(lngFileNumber, theEmployee, 2);
      FileSystem.FileClose(lngFileNumber);
      FileSystem.FileOpen(lngFileNumber, strFileName, OpenMode.Random, OpenAccess.ReadWrite, OpenShare.Default, Strings.Len(theEmployee));
      FileSystem.FileGet(lngFileNumber, ref theResult, rndNumber.Next(1, 3));

      theEmployee = (EmployeeData)theResult;
      strTemp = "Employee name".PadRight(15) + ": ";
      strTemp += theEmployee.strTitle.Trim() + " " + theEmployee.strFirstName.Trim();
      strTemp += " " + theEmployee.strLastName.Trim() + Environment.NewLine;
      strTemp += "Job title".PadRight(15) + ": ";
      strTemp += theEmployee.strJobTitle.Trim() + Environment.NewLine;
      strTemp += "Birth date".PadRight(15) + ": ";
      strTemp += theEmployee.dtmBirthDate + Environment.NewLine;
      strTemp += "Address".PadRight(15) + ": ";
      strTemp += theEmployee.strAddress.Trim() + Environment.NewLine;
      strTemp += "City,State,Zip".PadRight(15) + ": ";
      strTemp += theEmployee.strCity.Trim() + ", " + theEmployee.strState.Trim();
      strTemp += "  " + theEmployee.strZipCode.Trim() + Environment.NewLine;
      strTemp += "Phone number".PadRight(15) + ": ";
      strTemp += theEmployee.strPhone.Trim() + Environment.NewLine;
      strTemp += "Salary".PadRight(15) + ": ";
      strTemp += Strings.Format(theEmployee.decSalary, "Currency") + Environment.NewLine;
      strTemp += "Start date".PadRight(15) + ": ";
      strTemp += theEmployee.dtmStartDate;

      txtText.Text = strTemp;
      txtText.Select(0, 0);

      FileSystem.FileGet(lngFileNumber, ref theResult, 1);
      theEmployee = (EmployeeData)theResult;
      Console.WriteLine(theEmployee.strFirstName);
      FileSystem.FileGet(lngFileNumber, ref theResult, 2);
      theEmployee = (EmployeeData)theResult;
      Console.WriteLine(theEmployee.strFirstName);
      FileSystem.FileClose(lngFileNumber);
    }
    // frmRandomTest_Load(System.Object, System.EventArgs) Handles this.Load
    
    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmRandomTest
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230809 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230809 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmRandomTest());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmRandomTest

}
// CopyPaste.Learning