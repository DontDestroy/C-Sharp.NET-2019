//***
// Action
//   - Having an example of looping
//   - This form is a startpoint of the exercise
// Created
//   - CopyPaste � 20230807 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230807 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmLoopingNumbers : System.Windows.Forms.Form
	{
    #region Windows Form Designer generated code

    internal System.Windows.Forms.Button cmdCopy;
    internal System.Windows.Forms.Button cmdFill;
    internal System.Windows.Forms.TextBox txtText;
    internal System.Windows.Forms.ListBox lstNumbers;

    private System.ComponentModel.Container components = null;

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.cmdCopy = new System.Windows.Forms.Button();
      this.cmdFill = new System.Windows.Forms.Button();
      this.txtText = new System.Windows.Forms.TextBox();
      this.lstNumbers = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // cmdCopy
      // 
      this.cmdCopy.Location = new System.Drawing.Point(218, 236);
      this.cmdCopy.Name = "cmdCopy";
      this.cmdCopy.Size = new System.Drawing.Size(168, 40);
      this.cmdCopy.TabIndex = 7;
      this.cmdCopy.Text = "Copy List";
      this.cmdCopy.Click += new System.EventHandler(this.cmdCopy_Click);
      // 
      // cmdFill
      // 
      this.cmdFill.Location = new System.Drawing.Point(22, 236);
      this.cmdFill.Name = "cmdFill";
      this.cmdFill.Size = new System.Drawing.Size(168, 40);
      this.cmdFill.TabIndex = 5;
      this.cmdFill.Text = "Fill List";
      this.cmdFill.Click += new System.EventHandler(this.cmdFill_Click);
      // 
      // txtText
      // 
      this.txtText.Location = new System.Drawing.Point(218, 24);
      this.txtText.Multiline = true;
      this.txtText.Name = "txtText";
      this.txtText.Size = new System.Drawing.Size(168, 184);
      this.txtText.TabIndex = 6;
      this.txtText.Text = "";
      // 
      // lstNumbers
      // 
      this.lstNumbers.Location = new System.Drawing.Point(22, 24);
      this.lstNumbers.Name = "lstNumbers";
      this.lstNumbers.Size = new System.Drawing.Size(168, 186);
      this.lstNumbers.TabIndex = 4;
      // 
      // frmLoopingNumbers
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(408, 329);
      this.Controls.Add(this.cmdCopy);
      this.Controls.Add(this.cmdFill);
      this.Controls.Add(this.txtText);
      this.Controls.Add(this.lstNumbers);
      this.Name = "frmLoopingNumbers";
      this.Text = "Looping Numbers";
      this.Load += new System.EventHandler(this.frmLoopingNumbers_Load);
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmLoopingNumbers'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmLoopingNumbers()
      //***
      // Action
      //   - Create instance of 'frmLoopingNumbers'
      // Called by
      //   - Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmLoopingNumbers()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    Random mrndRandom = new Random(DateTime.Now.Millisecond);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdCopy_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - txtText becomes empty
      //   - Loop thru lstNumbers.Items (with a counter lngNumber)
      //     - txtText becomes txtText concatenated with lstNumbers.Items(lngNumber)
      //     - txtText becomes txtText with a hard return
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int intNumber;

      txtText.Text = "";

      for (intNumber = 0; intNumber < lstNumbers.Items.Count; intNumber++)
      {
        txtText.Text += Convert.ToString(lstNumbers.Items[intNumber]);
        txtText.Text += Environment.NewLine;
      }
      // intNumber = lstNumbers.Items.Count

    }
    // cmdCopy_Click(System.Object, System.EventArgs) Handles cmdCopy.Click
    
    private void cmdFill_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - lstNumbers becomes empty
      //   - Loop from 1 till 10 (with a counter lngNumber)
      //     - Add an item to lstNumbers (Random a number between 1 and 100)
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int intNumber;

      lstNumbers.Items.Clear();

      for (intNumber = 1; intNumber <= 10; intNumber++)
      {
        lstNumbers.Items.Add("Number " + mrndRandom.Next(1, 101));
      }
      // lngNumber = 11
    
    }
    // cmdFill_Click(System.Object, System.EventArgs) Handles cmdFill.Click

    private void frmLoopingNumbers_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Loop thru the controls of the form (lngNumber)
      //   - Write the number of the control 'lngNumber' and the name of the control to the console
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230807 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230807 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      int intNumber;

      for (intNumber = 0; intNumber < Controls.Count; intNumber++)
      {
        Console.WriteLine("Control #" + intNumber + 1 + " : " + Controls[intNumber].Name);
      }
      // lngNumber = Controls.Count()

    }
    // frmLoopingNumbers_Load(System.Object, System.EventArgs) Handles frmLoopingNumbers.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmLoopingNumbers
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmLoopingNumbers());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // frmLoopingNumbers

}
// CopyPaste.Learning