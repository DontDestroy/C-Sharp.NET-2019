﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmSomeTags.aspx.cs" Inherits="CopyPaste.Learning.wfrmSomeTags" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/html">
<head runat="server">
  <title>Copy Paste Lounge with Some Tags</title>
</head>
<body>
  <form id="wfrmSomeTags" runat="server">
    <h1>Welcome to the Copy Paste Lounge</h1>
    <p> <a href="wfrmCopyPasteCoffee.aspx">List of coffee and tea drinks</a>.<br>
    <p><br>
      Join us any evening for refreshing elixirs, conversations and maybe a game of two of <em>Ticket to Ride</em>.
      Wireless access is always provided.
      BYOWS (Bring Your Own Web Server).
    </p>
    <h2>Directions</h2>
    <p>
      You will find us right in the center of DownTown WebVille.
    </p>
    <p>
      Always straight, till you must turn.
      Come join us!
    </p>
    <p>
      <br></br>
    </p>
    <h3>Welcome to new website of Copy Paste Lounge</h3>
    <p> <a href="wfrmCopyPasteCoffeeNew.aspx">New website</a><br>
    <p>
      <br></br>
    </p>
    <img src="./Resources/CopyPaste.jpg" />
  </form>
</body>
</html>
