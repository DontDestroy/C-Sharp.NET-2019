//***
// Action
//   - Showing screen that can duplicate itself
// Created
//   - CopyPaste � 20230421 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230421 � VVDW
// Proposal (To Do)
//   - List of actions that can be added to the functionality
//***

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace DoingSomethingFunny
{

  public class frmScreen: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
      internal System.Windows.Forms.Button cmdClone;

      private System.ComponentModel.Container components = null;

      private void InitializeComponent()
      {
        System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmScreen));
        this.cmdClone = new System.Windows.Forms.Button();
        this.SuspendLayout();
        // 
        // cmdClone
        // 
        this.cmdClone.Location = new System.Drawing.Point(16, 15);
        this.cmdClone.Name = "cmdClone";
        this.cmdClone.Size = new System.Drawing.Size(224, 56);
        this.cmdClone.TabIndex = 1;
        this.cmdClone.Text = "&Clone Me";
        this.cmdClone.Click += new System.EventHandler(this.cmdClone_Click);
        // 
        // frmScreen
        // 
        this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
        this.ClientSize = new System.Drawing.Size(256, 86);
        this.Controls.Add(this.cmdClone);
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.Name = "frmScreen";
        this.Text = "Mirror Image";
        this.ResumeLayout(false);

      }

    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
    //***
    // Action
    //   - Clean up instance of 'frmScreen'
    // Called by
    //   - User action (Closing the form)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {

      if (disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmScreen()
    //***
    // Action
    //   - Create instance of 'frmScreen'
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      InitializeComponent();
    }
    // frmScreen()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private frmScreen theNewScreen;
    static int intFormCounter = 0;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdClone_Click(System.Object theSender, System.EventArgs theEventArguments)
    //***
    // Action
    //   - Create a new screen
    //   - Add one to the shared counter
    //   - Set a text for the screen
    //   - Show the screen
    //   - Show a messagebox with some information
    // Called by
    //   - User action (Clicking a button)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theNewScreen = new frmScreen();
      intFormCounter += 1;
      theNewScreen.Text = "Doppleganger - Number " + intFormCounter.ToString();
      theNewScreen.Show();
      MessageBox.Show(theNewScreen.Text + " has a handle of " + theNewScreen.Handle.ToString(), "Doppelganger", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
    // cmdClone_Click(System.Object, System.EventArgs) Handles cmdClose.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Start application
    //   - Showing frmScreen
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20230421 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230421 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      Application.Run(new frmScreen());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmScreen

}
// DoingSomethingFunny