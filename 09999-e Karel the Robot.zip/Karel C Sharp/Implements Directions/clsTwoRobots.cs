﻿//***
// Action
//   - Create a class cpTwoRobots that uses the interface Directions
// Created
//   - CopyPaste – 20251011 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251011 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpTwoRobots : Directions
	{

		#region "Constructors / Destructors"

		public cpTwoRobots()
		//***
		// Action
		//   - Basic constructor (start situation)
		//   - Reset the world
		//   - Build the world according to the One Beeper specifications
		//   - Make the world visible
		//   - Carl becomes a green robot starting at position (1, 1), looking to the right with no beepers in the bag
		//   - Karel becomes a blue robot starting at position (4, 1), looking to the right with no beepers in the bag
		//   - Karel will turn right
		//   - Karel will move one forward
		//   - Karel will pick the beeper at that position
		//   - Karel will move two forward
		//   - Karel will turn left
		//   - Karel will put the beeper at that position
		//   - Carl will pick the beeper at that position
		//   - Carl will move two forward
		//   - Carl will put the beeper at that position
		//   - Carl will move one forward
		//   - Carl is switched off
		//   - Karel is switched off
		// Called by
		//   - cpProgram.TwoRobots()
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20251011 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20251011 – VVDW
		// Keyboard key
		//   - 
		// Proposal (To Do)
		//   - 
		//***
		{
			World.reset(); // World is resetted
			World.readWorld("Worlds\\02.09 One Beeper.kwld"); // World is created with specifications
			World.setVisible(true); // World is made visible
			UrRobot carl = new UrRobot(1, 1, Directions.East, 0, Color.green); // A green UrRobot with name carl is put on the World
																															// At Street 1, Avenue 1, looking East, no Beepers in the bag
			UrRobot karel = new UrRobot(4, 1, Directions.East, 0, Color.blue); // A blue UrRobot with name karel is put on the World
																															// At Street 3, Avenue 1, looking East, no Beepers in the bag
			karel.turnLeft(); // Turn to the left (Looking to the North)
			karel.turnLeft(); // Turn to the left (Looking to the West)
			karel.turnLeft(); // Turn to the left (Looking to the South)
			karel.move(); // Moving one to the South (position Street 3, Avenue 1)
			karel.pickBeeper(); // Pick the Beeper at that position
			karel.move(); // Moving one to the South (position Street 2, Avenue 1)
			karel.move(); // Moving one to the South (position Street 1, Avenue 1)
			karel.turnLeft(); // Turn to the left (Looking to the East)
			karel.putBeeper(); // put the Beeper at that position
			carl.pickBeeper(); // Pick the Beeper at that position
			carl.move(); // Moving one to the East (position Street 1, Avenue 2)
			carl.move(); // Moving one to the East (position Street 1, Avenue 3)
			carl.putBeeper(); // put the Beeper at that position
			carl.move(); // Moving one to the East (position Street 1, Avenue 4)
			carl.turnOff(); // Robot carl has done its duty and is switched off
			karel.turnOff(); // Robot karel has done its duty and is switched off
		}
		// cpTwoRobots()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		//#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		//#endregion

		//#region "Not used"
		//#endregion

	}
	// cpTwoRobots

}
// cpKarelTheRobot