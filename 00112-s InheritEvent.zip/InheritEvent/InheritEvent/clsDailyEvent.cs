//***
// Action
//   - Implementation of a cpDailyEvent
// Created
//   - CopyPaste � 20240531 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240531 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpDailyEvent
  {

    #region "Constructors / Destructors"

    public cpDailyEvent()
      //***
      // Action
      //   - Basic constructor
      // Called by
      //   - cpTodaysActivity(DateTime, DateTime)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDailyEvent()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public delegate void DoSomething(string strItem, string strStart);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public event DoSomething Family;
    public event DoSomething Meals;
    public event DoSomething Meeting;

    #endregion

    #region "Sub / Function"

    public void GenerateEvents()
      //***
      // Action
      //   - Starting some events
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - Family(string, string)
      //   - Meals(string, string)
      //   - Meeting(string, string)
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Meeting("Sales Presentation", "9:30");
      Meeting("Client", "11:30");
      Meals("Lunch with Debbie", "12:30");
      Meeting("Production Scheduling", "14:30");
      Family("Ball Game", "17:30");
    }
		// GenerateEvents()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDailyEvent

}
// CopyPaste.Learning