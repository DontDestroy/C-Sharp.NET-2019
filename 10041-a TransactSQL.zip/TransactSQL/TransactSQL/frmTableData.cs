//***
// Action
//   - Create a New Table with Data from Existing Tables
//     - Create a tblCPProductCategory
// Created
//   - CopyPaste � 20260114 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260114 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmTableData: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code

    private System.ComponentModel.IContainer components;
    internal System.Windows.Forms.Button cmdExecute;
    internal System.Windows.Forms.DataGrid dgrResult;
    internal System.Windows.Forms.Label lblResult;
    internal System.Windows.Forms.Label lblSQLString;
    internal System.Windows.Forms.Label lblSQLStatement;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmTableData));
      this.cmdExecute = new System.Windows.Forms.Button();
      this.dgrResult = new System.Windows.Forms.DataGrid();
      this.lblResult = new System.Windows.Forms.Label();
      this.lblSQLString = new System.Windows.Forms.Label();
      this.lblSQLStatement = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.dgrResult)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdExecute
      // 
      this.cmdExecute.Location = new System.Drawing.Point(424, 72);
      this.cmdExecute.Name = "cmdExecute";
      this.cmdExecute.Size = new System.Drawing.Size(72, 32);
      this.cmdExecute.TabIndex = 7;
      this.cmdExecute.Text = "Execute";
      this.cmdExecute.Click += new System.EventHandler(this.cmdExecute_Click);
      // 
      // dgrResult
      // 
      this.dgrResult.AlternatingBackColor = System.Drawing.Color.Silver;
      this.dgrResult.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
        | System.Windows.Forms.AnchorStyles.Left) 
        | System.Windows.Forms.AnchorStyles.Right)));
      this.dgrResult.BackColor = System.Drawing.Color.White;
      this.dgrResult.CaptionBackColor = System.Drawing.Color.Maroon;
      this.dgrResult.CaptionFont = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.CaptionForeColor = System.Drawing.Color.White;
      this.dgrResult.DataMember = "";
      this.dgrResult.Font = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.ForeColor = System.Drawing.Color.Black;
      this.dgrResult.GridLineColor = System.Drawing.Color.Silver;
      this.dgrResult.HeaderBackColor = System.Drawing.Color.Silver;
      this.dgrResult.HeaderFont = new System.Drawing.Font("Tahoma", 8F);
      this.dgrResult.HeaderForeColor = System.Drawing.Color.Black;
      this.dgrResult.LinkColor = System.Drawing.Color.Maroon;
      this.dgrResult.Location = new System.Drawing.Point(16, 192);
      this.dgrResult.Name = "dgrResult";
      this.dgrResult.ParentRowsBackColor = System.Drawing.Color.Silver;
      this.dgrResult.ParentRowsForeColor = System.Drawing.Color.Black;
      this.dgrResult.PreferredColumnWidth = 100;
      this.dgrResult.SelectionBackColor = System.Drawing.Color.Maroon;
      this.dgrResult.SelectionForeColor = System.Drawing.Color.White;
      this.dgrResult.Size = new System.Drawing.Size(480, 144);
      this.dgrResult.TabIndex = 9;
      // 
      // lblResult
      // 
      this.lblResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblResult.Location = new System.Drawing.Point(16, 168);
      this.lblResult.Name = "lblResult";
      this.lblResult.Size = new System.Drawing.Size(96, 16);
      this.lblResult.TabIndex = 8;
      this.lblResult.Text = "Results";
      // 
      // lblSQLString
      // 
      this.lblSQLString.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.lblSQLString.Location = new System.Drawing.Point(16, 32);
      this.lblSQLString.Name = "lblSQLString";
      this.lblSQLString.Size = new System.Drawing.Size(392, 120);
      this.lblSQLString.TabIndex = 6;
      // 
      // lblSQLStatement
      // 
      this.lblSQLStatement.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
      this.lblSQLStatement.Location = new System.Drawing.Point(16, 8);
      this.lblSQLStatement.Name = "lblSQLStatement";
      this.lblSQLStatement.Size = new System.Drawing.Size(168, 16);
      this.lblSQLStatement.TabIndex = 5;
      this.lblSQLStatement.Text = "SQL Statement";
      // 
      // frmTableData
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(504, 341);
      this.Controls.Add(this.cmdExecute);
      this.Controls.Add(this.dgrResult);
      this.Controls.Add(this.lblResult);
      this.Controls.Add(this.lblSQLString);
      this.Controls.Add(this.lblSQLStatement);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmTableData";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "Create a New Table with Data from Existing Tables";
      this.Load += new System.EventHandler(this.frmTableData_Load);
      ((System.ComponentModel.ISupportInitialize)(this.dgrResult)).EndInit();
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmTableData'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmTableData()
      //***
      // Action
      //   - Create instance of 'frmTableData'
      // Called by
      //   - frmMain.cmdTableData_Click(System.Object, System.EventArgs) Handles cmdTableData.Click
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmTableData()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void cmdExecute_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a data adapter
      //   - Define and create a data table
      //   - Create a command with the SQL statement
      //   - Try to
      //     - Set the connection to the command
      //     - Open the connnection
      //     - Execute the SQL statement
      //     - Create a data adapter using another SQL statement and the connection
      //     - Fill the data table using the data adapter
      //     - Use the data table as data source for the data grid
      //   - When error occurs
      //     - Show the exception message
      //   - Close the connection
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - cpGeneralRoutines()
      //   - SqlClient.SqlConnection cpGeneralRoutines.GetConnection()
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      cpGeneralRoutines theRoutines = new cpGeneralRoutines();
      DataTable dtResult = new DataTable();
      SqlCommand cmmCommand = new SqlCommand(lblSQLString.Text);
      SqlDataAdapter dtaResult;

      try
      {
        cmmCommand.Connection = theRoutines.GetConnection();
        cmmCommand.Connection.Open();
        cmmCommand.ExecuteNonQuery();

        dtaResult = new SqlDataAdapter("SELECT * FROM tblCPProductCategory", theRoutines.GetConnection());
        dtaResult.Fill(dtResult);
        dgrResult.DataSource = dtResult;
      }
      catch (Exception theException)
      {
        MessageBox.Show(theException.Message);
      }
      finally
      {
        cmmCommand.Connection.Close();
      }
    
    }
    // cmdExecute_Click(System.Object, System.EventArgs) Handles cmdExecute.Click

    private void frmTableData_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define and set a SQL statement
      //     - To create and add data into a table
      //   - Show the SQL statement on the form
      // Called by
      //   - User action (Starting a form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260114 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260114 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strSQLStatement;

      strSQLStatement = "IF EXISTS (SELECT * FROM sys.objects " + Environment.NewLine +
        "     WHERE object_id = OBJECT_ID(N'[dbo].[tblCPProductCategory]') AND type in (N'U'))"  + Environment.NewLine +
        "     DROP TABLE [cpNorthwindScript2005].[dbo].[tblCPProductCategory]"  + Environment.NewLine + Environment.NewLine +
        "SELECT tblCPCategory.strCategoryName, tblCPProduct.strProductName"  + Environment.NewLine +
        "INTO tblCPProductCategory"  + Environment.NewLine +
        "FROM tblCPCategory INNER JOIN tblCPProduct"  + Environment.NewLine +
        "ON tblCPCategory.intIdCategory = tblCPProduct.intCategoryId";
      lblSQLString.Text = strSQLStatement;
    }
    // frmTableData_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmTableData

}
// CopyPaste.Learning