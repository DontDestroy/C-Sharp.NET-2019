//***
// Action
//   - Testroutine of cpAccount
// Created
//   - CopyPaste � 20240105 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240105 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

	public class cpProgram
	{
	
		//#region "Constructors / Destructors"
		//#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		//#region "Overrides"
		//#endregion

		//#region "Controls"
		//#endregion

		#region "Functionality"

		//#region "Event"
		//#endregion

		#region "Sub / Function"

		public static void Main()
			//***
			// Action
			//   - Create a correct Belgian account
			//   - Show the information
			//   - Add 100 to the account
			//   - Show the information
			//   - Create a wrong Belgian account (bankaccount is wrong)
			//   - Create a wrong Belgian account (date is wrong)
			//   - Create a wrong Belgian account (bankaccount and date are wrong)
			// Called by
			//   - User action (Starting the application)
			// Calls
			//   - cpAccount(long, decimal, DateTime)
			//   - cpAccount.Show()
			// Created
			//   - CopyPaste � 20240105 � VVDW
			// Changed
			//   - CopyPaste � yyyymmdd � VVDW � What changed
			// Tested
			//   - CopyPaste � 20240105 � VVDW
			// Keyboard key
			//   - 
			// Proposal (To Do)
			//   - Not all properties are tested in this routine
			//***
   	{

			try
			{
				// Happy flow
				cpAccount thecpAccount = new cpAccount(747524091936, 0, new DateTime(2004, 12, 17));
				cpAccount thecpWrongAccount;

				thecpAccount.Show();
				thecpAccount.Add(100);
				thecpAccount.Show();

				// Not so happy flow
				thecpWrongAccount = new cpAccount(123456789012, 0, new DateTime(2004, 12, 17));
				thecpWrongAccount = new cpAccount(747524091936, 0, new DateTime(1830, 01, 01));
				thecpWrongAccount = new cpAccount(123456789012, 0, new DateTime(1830, 01, 01));
			}
			catch (Exception theException)
			{
				Console.WriteLine(theException.Message);
			}
			finally
			{
				Console.ReadLine();
			}

		}
		// Main()

		#endregion

		#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpProgram

}
// CopyPaste.Learning