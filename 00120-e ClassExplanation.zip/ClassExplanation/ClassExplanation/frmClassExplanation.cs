//***
// Action
//   - Testroutine for cpProject and cpAnotherProject
// Created
//   - CopyPaste � 20240618 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240618 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmClassExplanation: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmClassExplanation));
      // 
      // frmClassExplanation
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(292, 273);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmClassExplanation";
      this.Text = "Class Explanation";
      this.Load += new System.EventHandler(this.frmClassExplanation_Load);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmClassExplanation'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmClassExplanation()
      //***
      // Action
      //   - Create instance of 'frmClassExplanation'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmClassExplanation()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void frmClassExplanation_Load(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create instances of classes from cpProject
      //   - Create an instance of cpProject
      //   - Create instances of classes from cpAnotherProject
      //   - Show fields of classes of cpProject
      //   - Execute test routine of cpProject
      //   - Show fields of classes of cpAnotherProject
      //   - Execute test routine of cpAnotherProject
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpAnotherProject.Test()
      //   - cpProject.Test()
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      cpProject.ClassPublic theClassPublic = new cpProject.ClassPublic();
      cpProject.ClassInternal theClassInternal = new cpProject.ClassInternal();
      // cpProject.ClassPrivate theClassPrivate = new cpProject.ClassPrivate();
      // cpProject.ClassProtected theClassProtected = new cpProject.ClassProtected();
      cpProject.ClassProtectedInternal theClassProtectedInternal = new cpProject.ClassProtectedInternal();
      cpAnotherProject.ClassPublic theClassPublicInOtherProject = new cpAnotherProject.ClassPublic();
      // cpAnotherProject.ClassInternal theClassInternalInOtherProject = new cpAnotherProject.ClassInternal();
      // cpAnotherProject.ClassPrivate theClassPrivateInOtherProject = new cpAnotherProject.ClassPrivate();
      // cpAnotherProject.ClassProtected theClassProtectedInOtherProject = new cpAnotherProject.ClassProtected();
      // cpAnotherProject.ClassProtectedInternal theClassProtectedFriendInOtherProject = new cpAnotherProject.ClassProtectedInternal();
      cpAnotherProject theAnotherProject = new cpAnotherProject();
      cpProject theProject = new cpProject();

      Console.WriteLine(theClassPublic.strClassPublic);
      Console.WriteLine(theClassInternal.strClassInternal);
      // Console.WriteLine(theClassPrivate.strClassPrivate);
      // Console.WriteLine(theClassProtected.strClassProtected);
      Console.WriteLine(theClassProtectedInternal.strClassProtectedInternal);

      theProject.Test();

      Console.WriteLine(theClassPublicInOtherProject.strClassPublic);
      // Console.WriteLine(theClassInternalInOtherProject.strClassInternal);
      // Console.WriteLine(theClassPrivateInOtherProject.strClassPrivate);
      // Console.WriteLine(theClassProtectedInOtherProject.strClassProtected);
      // Console.WriteLine(theClassProtectedInternalInOtherProject.strClassProtectedInternal);

      theAnotherProject.Test();
    }
    // frmClassExplanation_Load(System.Object, System.EventArgs) Handles this.Load

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmClassExplanation
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmClassExplanation()
      // Created
      //   - CopyPaste � 20240618 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240618 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmClassExplanation());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmClassExplanation

}
// CopyPaste.Learning