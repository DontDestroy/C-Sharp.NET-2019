﻿//***
// Action
//   - Data Layer Product
// Created
//   - CopyPaste – 20220826 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220826 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Text;

namespace CopyPaste.BackEndApplication
{

  public class dtsProduct : IdtsProduct
  {

    #region "Constructors / Destructors"

    public dtsProduct()
    //***
    // Action
    //   - Create instance of dtsProduct
    //   - Create a list of products
    //   - Fill the list with product items
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220825 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220825 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      _dicProduct = new Dictionary<int, string>();
      _dicProduct.Add(1, "Extending Bootstrap with CSS, JavaScript and jQuery#1");
      _dicProduct.Add(2, "Build your own Bootstrap Business Application Template in MVC#1");
      _dicProduct.Add(3, "Building Mobile Web Sites Using Web Forms, Bootstrap, and HTML5#1");
      _dicProduct.Add(4, "How to Start and Run A Consulting Business#");
      _dicProduct.Add(5, "The Many Approaches to XML Processing in .NET Applications#1");
      _dicProduct.Add(6, "WPF for the Business Programmer#1");
      _dicProduct.Add(7, "WPF for the Visual Basic Programmer - Part 1#1");
      _dicProduct.Add(8, "WPF for the Visual Basic Programmer - Part 2#1");
      _dicProduct.Add(10, "Practical Team Management for Software Engineers#2");
      _dicProduct.Add(11, "Leadership and Communication Skills for Software Engineers#2");
      _dicProduct.Add(12, "Best Practices for Project Estimation#2");
      _dicProduct.Add(23, "Using PowerShell#4");
    }
    // dtsProduct()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private IDictionary<int, string> _dicProduct;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public IDictionary<int, string> AllProducts()
    //***
    // Action
    //   - Returns the full list of products
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220826 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220826 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      return _dicProduct;
    }
    // IDictionary<string> AllProducts()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // dtsProduct

}
// CopyPaste.BackEndApplication