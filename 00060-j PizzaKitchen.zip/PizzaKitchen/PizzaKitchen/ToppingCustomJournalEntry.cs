﻿//***
// Action
//   - Class to collect the data of wpfPageFunctionToppings
//   - Information will be used to set the correct information when "going back" to the page
// Created
//   - CopyPaste – 20220819 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20220819 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Navigation;

namespace PizzaKitchen
{

  [Serializable()]
  public class ToppingCustomJournalEntry : CustomContentState
  {

    #region "Constructors / Destructors"

    public ToppingCustomJournalEntry(List<ListBoxItem> lstAvailable, List<ListBoxItem> lstChosen, ReplayDelegate Replay)
    //***
    // Action
    //   - Set the list with available toppings
    //   - Set the list with chosen toppings
    //   - Define the replay routine (as a delegate)
    // Called by
    //   - cmdAddToppings_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAddTopping.Click
    //   - cmdRemoveToppings_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdRemoveToppings.Click
    //   - System.Windows.Navigation.CustomContentState wpfPageFunctionToppings.GetContentState()
    // Calls
    //   - AvailableToppings(List<ListBoxItem>) (Set)
    //   - ChosenToppings(List<ListBoxItem>) (Set)
    // Created
    //   - CopyPaste – 20220819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      AvailableToppings = lstAvailable;
      ChosenToppings = lstChosen;
      theReplayDelegate = Replay;
    }
    // ToppingCustomJournalEntry(List<ListBoxItem>, List<ListBoxItem>, ReplayDelegate)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private List<ListBoxItem> lstAvailableToppings;
    private List<ListBoxItem> lstChosenToppings;
    private ReplayDelegate theReplayDelegate;

    #endregion

    #region "Properties"

    public List<ListBoxItem> AvailableToppings
    {

      get
      //***
      // Action Get
      //   - Returns the list of AvailableToppings
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220819 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220819 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return lstAvailableToppings;
      }
      // List<ListBoxItem> AvailableToppings (Get)

      set
      //***
      // Action Set
      //   - Sets the list of AvailableToppings
      // Called by
      //   - ToppingCustomJournalEntry(List<ListBoxItem>, List<ListBoxItem>, ReplayDelegate)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220819 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220819 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        lstAvailableToppings = value;
      }
      // AvailableToppings(List<ListBoxItem>) (Set)

    }
    // List<ListBoxItem> AvailableToppings

    public List<ListBoxItem> ChosenToppings
    {

      get
      //***
      // Action Get
      //   - Returns the list of ChosenToppings
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220819 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220819 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return lstChosenToppings;
      }
      // List<ListBoxItem> ChosenToppings (Get)

      set
      //***
      // Action Set
      //   - Sets the list of AvailableToppings
      // Called by
      //   - ToppingCustomJournalEntry(List<ListBoxItem>, List<ListBoxItem>, ReplayDelegate)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220819 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220819 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        lstChosenToppings = value;
      }
      // ChosenToppings(List<ListBoxItem>) (Set)

    }
    // List<ListBoxItem> ChosenToppings

    #endregion

    #region "Methods"

    #region "Overrides"

    public override string JournalEntryName
    {

      get
      //***
      // Action Get
      //   - Returns a string "Topping Custom Journal Entry"
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20220819 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20220819 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return "Topping Custom Journal Entry";
      }
      // string JournalEntryName (Get)

    }
    // string JournalEntryName

    public override void Replay(System.Windows.Navigation.NavigationService theNavigationService, System.Windows.Navigation.NavigationMode theNavigationMode)
    //***
    // Action
    //   - Defines the actions that must be done when Replay is triggered using a delegate
    // Called by
    //   - 
    // Calls
    //   - ReplayCallback(ToppingCustomJournalEntry)
    // Created
    //   - CopyPaste – 20220819 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220819 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      this.theReplayDelegate(this);
    }
    // Replay(System.Windows.Navigation.NavigationService, System.Windows.Navigation.NavigationMode)

    #endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    #region "Event"

    public delegate void ReplayDelegate(ToppingCustomJournalEntry theToppingCustomJournalEntry);

    #endregion

    //#region "Sub / Function"
    //#endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // CustomJournalEntry

}
// PizzaKitchen