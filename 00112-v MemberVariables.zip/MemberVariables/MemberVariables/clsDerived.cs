//***
// Action
//   - Implementation of cpDerived
// Created
//   - CopyPaste � 20240531 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240531 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpDerived : cpBase
  {

    #region "Constructors / Destructors"

    public cpDerived(string strName, int lngAmount, string strMessage) : base(strName, lngAmount, strMessage)
      //***
      // Action
      //   - Default constructor
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - cpBase()
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrMessage = "***" + strMessage + "***";
    }
    // cpDerived(string, int, string)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    public new string mstrMessage;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void ShowDerivedMembers()
      //***
      // Action
      //   - Shows the 3 values of the variables
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240531 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240531 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Name: " + mstrName);
      Console.WriteLine("Amount: " + mlngAmount);
      Console.WriteLine("Message: " + mstrMessage);
    }
    // ShowDerivedMembers()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpDerived

}
// CopyPaste.Learning