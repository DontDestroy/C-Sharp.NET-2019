//***
// Action
//   - Creating a cpBook class
// Created
//   - CopyPaste � 20220301 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220301 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Book
{

  public class cpBook
	{

    #region "Constructors / Destructors"
    
    public cpBook()
    //***
    // Action
    //   - Creating an instance of cpBook
    // Called by
    //   - User action (Creating an instance)
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
    }
    // cpBook()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public double mdblPrice;
    public string mstrAuthor;
    public string mstrPublisher;
    public string mstrTitle;
    
    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void DisplayBookInfo()
    //***
    // Action
    //   - Diplaying information of a cpBook
    // Called by
    //   - cpProgram.Main()
    // Calls
    //   - Console.WriteLine(String)
    // Created
    //   - CopyPaste � 20220301 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220301 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      Console.WriteLine("Title: " + mstrTitle);
      Console.WriteLine("Author: " + mstrAuthor);
      Console.WriteLine("Publisher: " + mstrPublisher);
      Console.WriteLine("Price: " + mdblPrice);
    }
    // DisplayBookInfo()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpBook

}
// Book