﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmBritain.aspx.cs" Inherits="CopyPaste.Learning.wfrmBritain" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>myPod: Britain</title>
  <style>
    body {
      background-color: #eaf3da;
    }
  </style>
</head>
<body>
  <form id="wfrmBritain">
    <h1>Britain</h1>
    <p>
      <img src="./Resources/Britain.jpg" alt="An iPod in Birmingham at a telephone box" />
    </p>
  </form>
</body>
</html>
