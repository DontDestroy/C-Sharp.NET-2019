﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCookies2.aspx.cs" Inherits="CopyPaste.Learning.wfrmCookies2" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
  <title>Cookies</title>
</head>
<body>
  <form id="wfrmCookies2" method="post" runat="server">
    <asp:Label ID="lblEmail" Style="z-index: 101; position: absolute; top: 72px; left: 40px" runat="server"></asp:Label>
    <asp:Button ID="cmdRemove" Style="z-index: 103; position: absolute; top: 136px; left: 152px"
      runat="server" Text="Remove cookie"></asp:Button>
    <asp:Label ID="lblName" Style="z-index: 102; position: absolute; top: 32px; left: 40px" runat="server"></asp:Label>
  </form>
</body>
</html>
