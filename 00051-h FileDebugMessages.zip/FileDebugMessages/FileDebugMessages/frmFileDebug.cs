//***
// Action
//   - Demo the functionality of Debug.Listeners
// Created
//   - CopyPaste � 20240508 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240508 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmFileDebug: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.TextBox txtResult;
    internal System.Windows.Forms.Button cmdView;
    internal System.Windows.Forms.Button cmdGenerate;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmFileDebug));
      this.txtResult = new System.Windows.Forms.TextBox();
      this.cmdView = new System.Windows.Forms.Button();
      this.cmdGenerate = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // txtResult
      // 
      this.txtResult.Location = new System.Drawing.Point(24, 120);
      this.txtResult.Multiline = true;
      this.txtResult.Name = "txtResult";
      this.txtResult.Size = new System.Drawing.Size(256, 168);
      this.txtResult.TabIndex = 5;
      this.txtResult.Text = "";
      // 
      // cmdView
      // 
      this.cmdView.Location = new System.Drawing.Point(88, 72);
      this.cmdView.Name = "cmdView";
      this.cmdView.Size = new System.Drawing.Size(120, 32);
      this.cmdView.TabIndex = 4;
      this.cmdView.Text = "View Messages";
      this.cmdView.Click += new System.EventHandler(this.cmdView_Click);
      // 
      // cmdGenerate
      // 
      this.cmdGenerate.Location = new System.Drawing.Point(88, 24);
      this.cmdGenerate.Name = "cmdGenerate";
      this.cmdGenerate.Size = new System.Drawing.Size(120, 32);
      this.cmdGenerate.TabIndex = 3;
      this.cmdGenerate.Text = "Generate Messages";
      this.cmdGenerate.Click += new System.EventHandler(this.cmdGenerate_Click);
      // 
      // frmFileDebug
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(304, 317);
      this.Controls.Add(this.txtResult);
      this.Controls.Add(this.cmdView);
      this.Controls.Add(this.cmdGenerate);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmFileDebug";
      this.Text = "File Debug Message";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmFileDebug'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmFileDebug()
      //***
      // Action
      //   - Create instance of 'frmFileDebug'
      // Called by
      //   - Main()
      // Calls
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      InitializeComponent();
    }
    // frmFileDebug()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdGenerate_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a textfile "C:\DebugMessages.txt" (theFileStream)
      //   - Create a stream writer to add text to theFileStream (strWriter)
      //   - Create a trace listener with strWriter (theListener)
      //   - Add the listener to the Debug window
      //   - Whatever you do in debug window, it is put in theFileStream
      //   - New line, nov, "In Button Click", "Calling First"
      //   - Execute method "First"
      //   - Exiting Button Click
      //   - Remove the listener from the Debug window
      //   - Close theFileStream
      //   - Set "Done" as text on the screen
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - First()
      // Created
      //   - CopyPaste � 20240508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      FileStream theFileStream = new FileStream("T:\\DebugMessages.txt", FileMode.Append);
      StreamWriter strWriter = new StreamWriter(theFileStream);

      TextWriterTraceListener theListener = new TextWriterTraceListener(strWriter);

      Debug.Listeners.Add(theListener);
      Debug.AutoFlush = true;
      Debug.WriteLine("");
      Debug.WriteLine("Messages generated at " + DateTime.Now);
      Debug.WriteLine("In Button Click");
      Debug.WriteLine("Calling First");
      First();
      Debug.WriteLine("Exiting Button Click");
      Debug.Listeners.Remove(theListener);
      theFileStream.Close();
      txtResult.Text = "Done";
   
    }
    // cmdGenerate_Click(System.Object, System.EventArgs) Handles cmdGenerate.Click

    private void cmdView_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Try to read the file created with the debug messages
      //   - textfile "C:\DebugMessages.txt" (strReader)
      //   - All the text in strReader is put on the screen
      //   - If there is no text
      //     - Show "No messages"
      //   - Close strReader
      //   - On errors show that debug file does not exist yet
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      StreamReader strReader;

      try
      {
        strReader = new StreamReader("T:\\DebugMessages.txt");
        txtResult.Text = strReader.ReadToEnd();

        if (txtResult.Text.Length == 0)
        {
          txtResult.Text = "No messages";
        }
        else
          // txtResult.Text.Length <> 0
        {
        }
        // txtResult.Text.Length = 0

        strReader.Close();
      }
      catch (Exception theException)
      {
        MessageBox.Show("Debug file does not yet exist");
      }
      finally
      {
      }
    
    }
    // cmdView_Click(System.Object, System.EventArgs) Handles cmdView.Click

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void First()
      //***
      // Action
      //   - Add text "In First" to the debug window
      //   - Add text "Calling Second" to the debug window
      //   - Run Second method
      //   - Add text "Back in First" to the debug window
      // Called by
      //   - cmdGenerate_Click(System.Object, System.EventArgs) Handles cmdGenerate.Click
      // Calls
      //   - Second()
      // Created
      //   - CopyPaste � 20240508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Debug.WriteLine("In First");
      Debug.WriteLine("Calling Second");
      Second();
      Debug.WriteLine("Back in First");
    }
    // First()

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmFileDebug
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmFileDebug()
      // Created
      //   - CopyPaste � 20240508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240508 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmFileDebug());
    }
    // Main() 

    public void Second()
      //***
      // Action
      //   - Add text "In Second" to the debug window
      // Called by
      //   - First()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240508 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240508 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Debug.WriteLine("In Second");
    }
    // Second()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmFileDebug

}
// CopyPaste.Learning