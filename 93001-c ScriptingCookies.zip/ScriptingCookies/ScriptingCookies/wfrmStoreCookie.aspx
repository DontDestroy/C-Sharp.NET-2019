<%@ Page language="C#" %>

<html>
<head>
  <title>Store Cookies</title>
</head>
<body>
  <center>
    <h1>Cookies Stored</h1>
  </center>
  <hr/>
  
  <%
  
       Response.Cookies["cpBook"]["Title"] = "C#.Net Programming Tips & Techniques";
       Response.Cookies["cpBook"]["Publisher"] = "McGraw-Hill/Osborne";
       Response.Cookies["cpBook"]["Author"] = "Jamsa";
  
  %>
  
  <a href="wfrmRetrieveCookie.aspx">View the Cookies</a>
</body>
</html>