//***
// Action
//   - Implemenetation of cpDeckGridIncompatibilityException
// Created
//   - CopyPaste � 20240310 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240310 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.CardGames
{

  public class cpDeckGridIncompatibilityException : System.ApplicationException
  {

    #region "Constructors / Destructors"

    public cpDeckGridIncompatibilityException() : base()
      //***
      // Action
      //   - Default Constructor for cpDeckGridIncompatibilityException
      // Called by
      //   - User action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDeckGridIncompatibilityException()

    public cpDeckGridIncompatibilityException(string strMessage) : base(strMessage)
      //***
      // Action
      //   - Default Constructor for cpDeckGridIncompatibilityException with a message
      // Called by
      //   - cpctlMemory.Play()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDeckGridIncompatibilityException(string)

    public cpDeckGridIncompatibilityException(string strMessage, Exception theInnerException) : base(strMessage, theInnerException)
      //***
      // Action
      //   - Constructor for cpDeckGridIncompatibilityException with a message and inner exception
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240310 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240310 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
    }
    // cpDeckGridIncompatibilityException(string, Exception)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpDeckGridIncompatibilityException

}
// CopyPaste.CardGames