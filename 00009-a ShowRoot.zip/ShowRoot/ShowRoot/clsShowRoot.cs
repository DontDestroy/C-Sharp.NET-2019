//***
// Action
//   - Exercise 00009-a
// Created
//   - CopyPaste � 20230607 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230607 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.IO;

namespace ShowRoot
{

  public class cpShowRoot
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Loop thru files of "C:\" (strFileName)
    //     - Write 'strFileName' at console screen
    // Called by
    //   - System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    //   - System.IO.Directory.GetFiles(string)
    // Calls
    //   - User action (Starting the application)
    // Created
    //   - CopyPaste � 20230607 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230607 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {

      foreach (string strFilename in Directory.GetFiles("C:\\"))
      {
        Console.WriteLine(strFilename);
      }
      // in Directory.GetFiles("C:\\")

      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpShowRoot

}
// ShowRoot