﻿//***
// Action
//   - Implementation of a cpPlasticRubberDuck
//     - Inherits from cpDuck, where Display (how do I look like) is an abstract method
//       - All class that inherit from cpDuck must implement the Display method
//       - The picture itself is placed in the directory "DuckDisplays"
//         - Every picture has the value "Copy Always" in property "Copy to Output Directory"
//   - The sound that a cpPlasticRubberDuck makes is inherited
//     - All cpDuck and child classes make the same noise
//   - The way a cpPlasticRubberDuck moves on water is inherited
//     - All cpDuck and child classes moves on water the same way
//   - The way a cpPlasticRubberDuck moves on land is overridden
//     - All child classes that are not living ducks moves on land the same way. They don't.
// Created
//   - CopyPaste – 20240716 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20240716 – VVDW
// Proposal (To Do)
//   -
//***

using System.Diagnostics;

namespace CopyPaste.Game.Duck.Library
{

	internal class cpPlasticRubberDuck : cpDuck
	{

		#region "Constructors / Destructors"

		/// <summary>
		/// Constructor of a cpPlasticRubberDuck
		/// </summary>
		public cpPlasticRubberDuck() : base()
		//***
		// Action
		//   - Basic constructor
		// Called by
		//   - User action (Creating an instance)
		// Calls
		//   - cpDuck()
		// Created
		//   - CopyPaste – 20240716 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240716 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
		}
		// cpPlasticRubberDuck()

		#endregion

		//#region "Designer"
		//#endregion

		//#region "Structures"
		//#endregion

		//#region "Fields"
		//#endregion

		//#region "Properties"
		//#endregion

		#region "Methods"

		#region "Overrides"

		/// <summary>
		/// The visualization (displaying) of a cpPlasticRubberDuck
		/// </summary>
		public override void Display()
		//***
		// Action
		//   - Define how a cpPlasticRubberDuck looks like
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240716 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240716 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("Representation of a cpPlasticRubberDuck");
		}
		// Display()

		/// <summary>
		/// How is a cpDuck moving on land
		/// </summary>
		public override void Walk()
		//***
		// Action
		//   - Define how the cpPlasticRubberDuck moves on land
		//     - A plastic rubber duck does not move on land
		// Called by
		//   - 
		// Calls
		//   - 
		// Created
		//   - CopyPaste – 20240716 – VVDW
		// Changed
		//   - CopyPaste – yyyymmdd – VVDW – What changed
		// Tested
		//   - CopyPaste – 20240716 – VVDW
		// Keyboard key
		//   -
		// Proposal (To Do)
		//   -
		//***
		{
			Debug.Print("cpPlasticRubberDuck is not able to move around on land");
		}
		// Walk()

		#endregion

		//#region "Controls"
		//#endregion

		//#region "Functionality"

		//#region "Event"
		//#endregion

		//#region "Sub / Function"
		//#endregion

		//#endregion

		#endregion

		//#region "Not used"
		//#endregion

	}
	// cpPlasticRubberDuck

}
// CopyPaste.Game.Duck.Library