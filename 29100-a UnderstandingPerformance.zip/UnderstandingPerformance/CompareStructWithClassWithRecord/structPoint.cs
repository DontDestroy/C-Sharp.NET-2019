﻿//***
// Action
//   - A definition of a point (structure)
// Created
//   - CopyPaste – 20260525 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20260525 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public struct structPoint
  {

    #region "Constructors / Destructors"

    public structPoint(double dblX, double dblY)
    //***
    // Action
    //   - Basic constructor
    //   - A given X and Y coordinate
    // Called by
    //   - cpProgram.Main()
    //   - cpTypeComparison()
    //   - double cpProgram.RunSomeCodeWithBenchmarkPointStruct()
    // Calls
    //   - double X (Get)
    //   - double Y (Get)
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      X = dblX;
      Y = dblY;
    }
    // structPoint(double, double)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    public double X { get; set; }
    // structPoint(double, double)
    // double Length()
    // double Sum()

    public double Y { get; set; }
    // structPoint(double, double)
    // double Length()
    // double Sum()

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public double Length()
    //***
    // Action
    //   - Calculate the length of the line with coordinates (0, 0) and (X, Y)
    // Called by
    //   - 
    // Calls
    //   - double X (Get)
    //   - double Y (Get)
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return Math.Sqrt(X * X + Y * Y);
    }
    // double Length()

    public double Sum()
    //***
    // Action
    //   - Sum the 2 coordinates
    // Called by
    //   - 
    // Calls
    //   - double X (Get)
    //   - double Y (Get)
    // Created
    //   - CopyPaste – 20260525 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260525 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return X + Y;
    }
    // double Sum()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // structPoint

}
// CopyPaste.Learning