//***
// Action
//   - Example of a class inside another class (nested classes)
//   - Implementation of cpEmployee
//   - Implementation of cpEmployee.cpWorkRegime
// Created
//   - CopyPaste � 20240409 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240409 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning
{

  public class cpEmployee
  {

    #region "Constructors / Destructors"

    public cpEmployee(string strName)
      //***
      // Action
      //   - Constructor of cpEmployee with Name
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - Name(string) (Set)
      // Created
      //   - CopyPaste � 20240409 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240409 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Name = strName;
    }
    // cpEmployee(string)

    #endregion

    #region "Designer"

    public class cpWorkRegime
    {

      #region "Constructors / Destructors"

      public cpWorkRegime(cpWorkRegimeType thecpWorkRegimeType)
        //***
        // Action
        //   - Constructor of cpWorkRegime with cpWorkRegimeType
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - WorkType(cpWorkRegimeType) (Set)
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        WorkType = thecpWorkRegimeType;
      }
      // cpWorkRegime(cpWorkRegimeType)

      #endregion

      #region "Designer"

      public enum cpWorkRegimeType
      {
        FullTime,
        FourFifth,
        HalfTime
      }
      // cpWorkRegimeType

      #endregion

      //#region "Structures"
      //#endregion

      #region "Fields"

      private cpWorkRegimeType mcpWorkRegimeType;

      #endregion

      #region "Properties"

      public int Vacation
      {

        get
          //***
          // Action Get
          //   - Returns the number of vacation days
          //   - Depending on the WorkType
          //     - When FourFifth, return 28
          //     - When FullTime, return 36
          //     - When HalfTime, return 18
          // Called by
          //   - cpProgram.Main()
          // Calls
          //   - cpWorkRegimeType WorkType (Get)
          // Created
          //   - CopyPaste � 20240409 � VVDW
          // Changed
          //   - CopyPaste � yyyymmdd � VVDW � What changed
          // Tested
          //   - CopyPaste � 20240409 � VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {
          int intResult = 0;

          switch (WorkType)
          {
            case cpWorkRegimeType.FourFifth:
              intResult = 28;
              break;
            case cpWorkRegimeType.FullTime:
              intResult = 36;
              break;
            case cpWorkRegimeType.HalfTime:
              intResult = 18;
              break;
          }
          // WorkType

          return intResult;
        }
        // int Vacation (Get)

      }
      // int Vacation

      public cpWorkRegimeType WorkType
      {

        get
          //***
          // Action Get
          //   - Returns mcpWorkRegimeType
          // Called by
          //   - int Vacation (Get)
          //   - string ToString
          // Calls
          //   - 
          // Created
          //   - CopyPaste � 20240409 � VVDW
          // Changed
          //   - CopyPaste � yyyymmdd � VVDW � What changed
          // Tested
          //   - CopyPaste � 20240409 � VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {
          return mcpWorkRegimeType;
        }
        // cpWorkRegimeType WorkType (Get)

        set
          //***
          // Action Set
          //   - mcpWorkRegimeType becomes value
          // Called by
          //   - cpWorkRegime(cpWorkRegimeType)
          // Calls
          //   - 
          // Created
          //   - CopyPaste � 20240409 � VVDW
          // Changed
          //   - CopyPaste � yyyymmdd � VVDW � What changed
          // Tested
          //   - CopyPaste � 20240409 � VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {
          mcpWorkRegimeType = value;
        }
        // WorkType(cpWorkRegimeType) (Set)

      }
      // cpWorkRegimeType WorkType

      #endregion

      #region "Methods"

      #region "Overrides"

      public override string ToString()
        //***
        // Action
        //   - Visualisation of the WorkType
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - cpWorkRegimeType WorkType (Get)
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        string strResult = "";

        switch (WorkType)
        {
          case cpWorkRegimeType.FourFifth:
            strResult = "FourFifth";
            break;
          case cpWorkRegimeType.FullTime:
            strResult = "Fulltime";
            break;
          case cpWorkRegimeType.HalfTime:
            strResult = "Halftime";
            break;
        }
        // WorkType

        return strResult;
      }
      // string ToString()

      #endregion

      //#region "Controls"
      //#endregion

      #region "Functionality"

      //#region "Event"
      //#endregion

      #region "Sub / Function"

      //***
      // Action
      //   - Explanation of the code in this method
      // Called by
      //   - 
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
		
      #endregion

      #endregion

      #endregion

      //#region "Not used"
      //#endregion

    }
    // cpDefault

    #endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private cpWorkRegime mcpWorkRegime;
    private string mstrName;

    #endregion

    #region "Properties"

    public string Name
    {

      get
        //***
        // Action Get
        //   - Returns mstrName
        // Called by
        //   - 
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

      set
        //***
        // Action Set
        //   - mstrName becomes value
        // Called by
        //   - cpEmployee(string)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    public cpWorkRegime Regime
    {

      get
        //***
        // Action Get
        //   - Returns mcpWorkRegime
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mcpWorkRegime;
      }
      // cpWorkRegime Regime (Get)

      set
        //***
        // Action Set
        //   - mcpWorkRegime becomes value
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240409 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240409 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mcpWorkRegime = value;
      }
      // Regime(cpWorkRegime) (Set)

    }
    // cpWorkRegime Regime

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    //***
    // Action
    //   - Explanation of the code in this method
    // Called by
    //   - 
    // Calls
    //   - 
    // Created
    //   - CopyPaste � yyyymmdd � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � yyyymmdd � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
		
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpEmployee

}
// CopyPaste.Learning