//***
// Action
//   - Definition of cpEmployee
// Created
//   - CopyPaste � 20230614 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230614 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpEmployee
  {

    #region "Constructors / Destructors"

    public cpEmployee()
      //***
      // Action
      //   - Empty constructor of cpEmployee
      // Called by
      //   - modPublicPrivate.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpEmployee()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mlngAge;
    private string mstrHomePhone;
    public string mstrName;
    public string mstrOfficeNumber;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void AssignAge(int lngEmployeeAge)
      //***
      // Action
      //   - Assign an age to an employee
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      
      if ((lngEmployeeAge > 18) && (lngEmployeeAge < 100))
      {
        mlngAge = lngEmployeeAge;
      }
      else
        // (lngEmployeeAge <= 18) || (lngEmployeeAge >= 100)
      {
      }
      // (lngEmployeeAge > 18) && (lngEmployeeAge < 100) 

    }
    // AssignAge(int)

    public void AssignHomePhone(string strPhone)
      //***
      // Action
      //   - Assign a phone to an employee
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      mstrHomePhone = strPhone;
    }
    // AssignHomePhone(string)

    public void ShowEmployee()
      //***
      // Action
      //   - Show the information of an employee
      // Called by
      //   - cpProgram.Main()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230614 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230614 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Console.WriteLine("Name: " + mstrName);
      Console.WriteLine("Age: " + mlngAge);
      Console.WriteLine("Office Number: " + mstrOfficeNumber);
      Console.WriteLine("Home Phone: " + mstrHomePhone);
    }
    // ShowEmployee()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpEmployee 

}
// CopyPaste.Learning