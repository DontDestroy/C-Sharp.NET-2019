﻿//***
// Action
//   - Implementation of Interface cpiValidationRestriction to validate a textbox on negative number
//   - A negative number starts with a "-" and contains only digits
// Created
//   - CopyPaste – 20250718 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250718 – VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Globalization;

namespace CopyPaste.Learning
{

  public class cpValidationRestrictionNegativeNumeric: cpiValidationRestriction
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public bool Validate(cpctlValidationTextbox theSender, System.Windows.Forms.KeyPressEventArgs theKeyPressEventArgs )
      //***
      // Action
      //   - Test of a character typed can be part of a negative number
      //   - Find the negative sign on the settings of the operating system
      //   - If the first typed character is the negative sign or a digit
      //       Or whatever character typed is a digit 
      //     - Return True
      //   - If not
      //     - Return False
      // Called by
      //   - cpctlValidationTextbox.OnKeyPress(KeyPressEventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250718 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250718 – VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      string strNegativeSign = NumberFormatInfo.CurrentInfo.NegativeSign;
    
      return (((theKeyPressEventArgs.KeyChar.ToString() == strNegativeSign) &&
        (theSender.SelectionStart == 0)) ||
        Char.IsNumber(theKeyPressEventArgs.KeyChar));
    }
    // Validate(cpctlValidationTextbox, System.Windows.Forms.KeyPressEventArgs) As Boolean Implements cpiValidationRestriction.Validate

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpValidationRestrictionNegativeNumeric

}
// CopyPaste.Learning