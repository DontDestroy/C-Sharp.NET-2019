//***
// Action
//   - Interface for Cost
//     - A decimal that is an amount of money
//     - Is the cost human (or not)
// Created
//   - CopyPaste � 20240410 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240410 � VVDW
// Proposal (To Do)
//   -
//***

namespace CopyPaste.Learning.Employee
{

  public interface cpiCost
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    #region "Properties"

    bool Human { get;}
    decimal Amount { get;}

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpiCost

}
// CopyPaste.Learning.Employee