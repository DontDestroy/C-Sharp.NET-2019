﻿//***
// Action
//   - The startup screen of the application
// Created
//   - CopyPaste – 20220824 – VVDW
// Changed
//   - CopyPaste – 20260409 – VVDW – Changed the visibility of the expander of the product list
// Tested
//   - CopyPaste – 20220824 – VVDW
// Proposal (To Do)
//   -
//***

using System.Windows;

namespace ProductCategory_WPF_MVVM
{

  public partial class wpfStartupScreen : Window
  {

    #region "Constructors / Destructors"

    public wpfStartupScreen()
    //***
    // Action
    //   - Creating an new instance of 'wpfStartupScreen'
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20220824 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20220824 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {
      InitializeComponent();
    }
    // wpfStartupScreen()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void expProduct_Collapsed(System.Object theSender, RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - If expander of product is collapsed
    //     - set visibility of grpProductDetails to hidden
    // Called by
    //   - User action (Collapsing an expander)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260409 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260409 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      if (this.grpProductDetails == null)
      {
      }
      else
      // this.grpProductDetails <> null
      {
        this.grpProductDetails.Visibility = Visibility.Hidden;
      }
      // this.grpProductDetails = null

    }
    // expProduct_Collapsed(System.Object, RoutedEventArgs) Handles expCategory.Collapsed

    private void expProduct_Expanded(System.Object theSender, RoutedEventArgs theRoutedEventArguments)
    //***
    // Action
    //   - If expander of product is expanded
    //     - set visibility of grpProductDetails to visible
    // Called by
    //   - User action (expanding an expander)
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20260409 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20260409 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   -
    //***
    {

      if (this.grpProductDetails == null)
      {
      }
      else
      // this.grpProductDetails <> null
      {
        this.grpProductDetails.Visibility = Visibility.Visible;
      }
      // this.grpProductDetails = null

    }
    // expProduct_Expanded(System.Object, RoutedEventArgs) Handles expCategory.Expanded

    #endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // wpfStartupScreen 

}
// ProductCategory_WPF_MVVM