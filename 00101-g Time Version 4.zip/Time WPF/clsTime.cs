//***
// Action
//   - Creating a cpTime with properties
// Created
//   - CopyPaste � 20230320 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230320 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Toolkit.Time
{

  public class cpTime
	{

    #region "Constructors / Destructors"

    public cpTime()
    //***
    // Action
    //   - Creating an instance of cpTime all default values
    // Called by
    //   - Main()
    // Calls
    //   - SetTime(int, int, int)
    // Created
    //   - CopyPaste � 20230320 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230320 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      SetTime(0, 0, 0);
    }
    // cpTime()

    public cpTime(int intHour)
    //***
    // Action
    //   - Creating an instance of cpTime with given hour
    // Called by
    //   - Main()
    // Calls
    //   - SetTime(int, int, int)
    // Created
    //   - CopyPaste � 20230320 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230320 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      SetTime(intHour, 0, 0);
    }
    // cpTime(int)

    public cpTime(int intHour, int intMinute)
    //***
    // Action
    //   - Creating an instance of cpTime with given hour and minute
    // Called by
    //   - Main()
    // Calls
    //   - SetTime(int, int, int)
    // Created
    //   - CopyPaste � 20230320 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230320 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      SetTime(intHour, intMinute, 0);
    }
    // cpTime(int, int)

    public cpTime(int intHour, int intMinute, int intSecond)
    //***
    // Action
    //   - Creating an instance of cpTime with given hour, minute and second
    // Called by
    //   - Main()
    // Calls
    //   - SetTime(int, int, int)
    // Created
    //   - CopyPaste � 20230320 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230320 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      SetTime(intHour, intMinute, intSecond);
    }
    // cpTime(int, int)

    public cpTime(cpTime thecpTime)
    //***
    // Action
    //   - Creating an instance of cpTime wit given cpTime
    // Called by
    //   - Main()
    // Calls
    //   - SetTime(int, int, int)
    // Created
    //   - CopyPaste � 20230320 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230320 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      SetTime(thecpTime.mintHour, thecpTime.mintMinute, thecpTime.mintSecond);
    }
    // cpTime(cpTime)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    private int mintHour;
    private int mintMinute;
    private int mintSecond;
    
    #endregion

    #region "Properties"
    
    public int Hour
    {
      get
      //***
      // Action Get
      //   - Return mintHour
      // Called by
      //   - wpfTime.cmdAddSecond_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAddSecond.Click
      //   - wpfTime.UpdateDisplay()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230320 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230320 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return mintHour;
      }
      // int Hour() (Get)

      set
      //***
      // Action Set
      //   - Perform validity checks on data
      //   - Set invalid values to zero
      //   - If hour is wrong, by default 0 is placed
      // Called by
      //   - wpfTime.cmdAddSecond_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAddSecond.Click
      //   - wpfTime.txtSetHour_TextChanged(System.Object, System.Windows.RoutedEventArgs) Handles txtSetHour.TextChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230320 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230320 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if (value >= 0 && value < 24)
        {
          mintHour = value;
        }
        else
          // (value < 0 || value >= 24)
        {
          mintHour = 0;
        }
        // (value >= 0 && value < 24)

      }
      // Hour(int) (Set)

    }
    // int Hour

    public int Minute
    {
      
      get
      //***
      // Action Get
      //   - Return mintMinute
      // Called by
      //   - wpfTime.cmdAddSecond_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAddSecond.Click
      //   - wpfTime.UpdateDisplay()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230320 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230320 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return mintMinute;
      }
      // int Minute() (Get)
      
      set
      //***
      // Action Set
      //   - Perform validity checks on data
      //   - Set invalid values to zero
      //   - If minute is wrong, by default 0 is placed
      // Called by
      //   - wpfTime.cmdAddSecond_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAddSecond.Click
      //   - wpfTime.txtSetMinute_TextChanged(System.Object, System.Windows.RoutedEventArgs) Handles txtSetMinute.TextChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230320 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230320 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if (value >= 0 && value < 60)
        {
          mintMinute = value;
        }
        else
          // (value < 0 || value >= 60)
        {
          mintMinute = 0;
        }
        // (value >= 0 && value < 60)

      }
      // Minute(int) (Set)

    }
    // int Minute

    public int Second
    {
      
      get
      //***
      // Action Get
      //   - Return mintSecond
      // Called by
      //   - wpfTime.cmdAddSecond_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAddSecond.Click
      //   - wpfTime.UpdateDisplay()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230320 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230320 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {
        return mintSecond;
      }
      // int Second() (Get)
      
      set
      //***
      // Action Set
      //   - Perform validity checks on data
      //   - Set invalid values to zero
      //   - If second is wrong, by default 0 is placed
      // Called by
      //   - wpfTime.cmdAddSecond_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAddSecond.Click
      //   - wpfTime.txtSetSecond_TextChanged(System.Object, System.Windows.RoutedEventArgs) Handles txtSetSecond.TextChanged
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20230320 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20230320 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
      {

        if (value >= 0 && value < 60)
        {
          mintSecond = value;
        }
        else
          // (value < 0 || value >= 60)
        {
          mintSecond = 0;
        }
        // (value >= 0 && value < 60)

      }
      // Second(int) (Set)

    }
    // int Second

    #endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void SetTime(int intHour, int intMinute, int intSecond)
    //***
    // Action
    //   - Set new time value using universal time
    //   - Define the time of cpTime, by the hour, minutes and seconds
    // Called by
    //   - cpTime.New()
    //   - cpTime.New(int)
    //   - cpTime.New(int, int)
    //   - cpTime.New(int, int, int)
    //   - cpTime.New(cpTime)
    // Calls
    //   - cpTime.Hour(int) (Set)
    //   - cpTime.Minute(int) (Set)
    //   - cpTime.Second(int) (Set)
    // Created
    //   - CopyPaste � 20230320 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230320 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Hour = intHour;
      Minute = intMinute;
      Second = intSecond;
    }
    // SetTime(int, int, int)

    public string ToAmericanString()
    //***
    // Action
    //   - Show the time in American format
    //   - Is it AM or is it PM
    //   - How is the hour shown
    // Called by
    //   - wpfTime.UpdateDisplay()
    // Calls
    //   - string string.Format(string, System.Object, System.Object, System.Object)
    // Created
    //   - CopyPaste � 20230320 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230320 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      int intStandardHour;
      string strFormat = "{0}:{1:D2}:{2:D2}";
      string strSuffix;

      // Determine whether time is AM or PM
      
      if (mintHour < 12)
      {
        strSuffix = " AM";
      }      
      else
        // mintHour >= 12 
      {
        strSuffix = " PM";
      }
      // mintHour < 12 
      
      if (mintHour == 12 || mintHour == 0)
      {
        intStandardHour = 12;
      }
      else
        // (mintHour = 12 && mintHour = 0)
      {
        intStandardHour = mintHour % 12;
      }
      
      return string.Format(strFormat, intStandardHour, mintMinute, mintSecond) + strSuffix;
    }
    // string ToAmericanString()

    public string ToUniversalString()
    //***
    // Action
    //   - Show the time in Universal format
    // Called by
    //   - wpfTime.UpdateDisplay()
    // Calls
    //   - String.Format(String, Object, Object, Object)
    // Created
    //   - CopyPaste � 20230320 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230320 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      return String.Format("{0}:{1:D2}:{2:D2}", mintHour, mintMinute, mintSecond);
    }
    // string ToUniversalString()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpTime

}
// CopyPaste.Learning.Toolkit.Time