<%@ Page Language="C#" %>

<html>
<head>
  <title>ShowForm</title>
</head>
<body>
  <center>
    <h1>Show User Information</h1>
  </center>
  <hr />

  <%

    if (Request.HttpMethod == "POST")
    {
      int intCounter;

      for (intCounter = 0; intCounter < Request.Form.Count; intCounter++)
      {
        Response.Write(Request.Form.GetKey(intCounter) + ": " + Request.Form[intCounter].ToString() + "<br>");
      }

    }
    else
    {
      int intCounter;

      for (intCounter = 0; intCounter < Request.QueryString.Count; intCounter++)
      {
        Response.Write(Request.QueryString.GetKey(intCounter) + ": " + Request.QueryString[intCounter].ToString() + "<br>");
      }

    }

  %>

</body>
</html>
