﻿//***
// Action
//   - A definition of an ThreeBeeperLayer
// Created
//   - CopyPaste – 20251027 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20251027 – VVDW
// Proposal (To Do)
//   -
//***

using java.awt;
using kareltherobot;

namespace cpKarelTheRobot
{

	public class cpThreeBeeperLayer : cpAbstractBeeperLayer
  {

		#region "Constructors / Destructors"

		public cpThreeBeeperLayer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers, Color theColor) : base(intStreet, intAvenue, theDirection, intBeepers, theColor)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a theColor cpThreeBeeperLayer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - cpProgram.TwoDifferentRobots()
    //   - cpThreeBeeperLayer(int, int, Directions.Direction, int)
    // Calls
    //   - cpAbstractBeeperLayer(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpTwoBeeperLayer(int, int, Directions.Direction, int, Color) 

    public cpThreeBeeperLayer(int intStreet, int intAvenue, Directions.Direction theDirection, int intBeepers) : this(intStreet, intAvenue, theDirection, intBeepers, null)
    //***
    // Action
    //   - Basic constructor (start situation)
    //   - Robot becomes a cpThreeBeeperLayer starting at position (intStreet, intAvenue), looking to the theDirection with intBeepers beepers in the bag
    //   - Nothing else happens
    // Called by
    //   - 
    // Calls
    //   - cpThreeBeeperLayer(int, int, Directions.Direction, int, Color)
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
    }
    // cpThreeBeeperLayer(int, int, Directions.Direction, int) 

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public override void PutBeepers()
    //***
    // Action
    //   - Put three beepers at the current location
    // Called by
    //   - cpAbstractBeeperLayer.LayBeepers()
    // Calls
    //   -
    // Created
    //   - CopyPaste – 20251027 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20251027 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      putBeeper();
      putBeeper();
      putBeeper();
    }
    // PutBeepers()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpThreeBeeperLayer

}
// cpKarelTheRobot