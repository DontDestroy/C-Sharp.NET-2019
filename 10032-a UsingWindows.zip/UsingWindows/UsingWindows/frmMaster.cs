//***
// Action
//   - Demo of some bound controls with event Format and Parse
//   - Show example of controls
//   - Show example of data grid
//   - Show example of treeview
//   - Show example of a find screen
//   - Show example of bound error provider
//   - Show some implemented events
// Created
//   - CopyPaste � 20260113 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20260113 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using UsingWindows;

namespace CopyPaste.Learning
{

  public class frmMaster: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private IContainer components;
    internal System.Windows.Forms.Button cmdFindCategory;
    internal System.Windows.Forms.Button cmdControls;
    internal System.Windows.Forms.Button cmdTreeView;
    internal System.Windows.Forms.Label lblProduct;
    internal System.Windows.Forms.Label lblOrder;
    internal System.Windows.Forms.Button cmdDataSet;
    internal System.Windows.Forms.Button cmdDataGrid;
    internal System.Windows.Forms.ErrorProvider erpDataSet;
    internal System.Windows.Forms.TextBox txtPosition;
    internal System.Windows.Forms.TextBox txtDescription;
    internal System.Windows.Forms.TextBox txtCategoryName;
    internal System.Windows.Forms.Label lblName;
    internal System.Windows.Forms.Label lblIdCategory;
    internal System.Windows.Forms.ErrorProvider erpControl;
    internal System.Windows.Forms.TextBox txtIdCategory;
    internal System.Windows.Forms.ListBox lstOrder;
    internal System.Windows.Forms.ListBox lstProduct;
    internal System.Windows.Forms.Button cmdNext;
    internal System.Windows.Forms.Button cmdLast;
    internal System.Windows.Forms.Button cmdFirst;
    internal System.Data.SqlClient.SqlConnection cnncpNorthWind2019;
    internal System.Data.SqlClient.SqlDataAdapter dtaProduct;
    internal System.Data.SqlClient.SqlCommand cmmSelectProduct;
    internal System.Data.SqlClient.SqlDataAdapter dtaCategory;
    internal System.Data.SqlClient.SqlCommand cmmSelectCategory;
    internal System.Data.SqlClient.SqlDataAdapter dtaOrderDate;
    internal System.Data.SqlClient.SqlCommand cmmSelectOrderDates;
    private UsingWindows.dsData dsData;
    internal System.Windows.Forms.Button cmdPrevious;

    private void InitializeComponent()
    {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMaster));
      this.cmdFindCategory = new System.Windows.Forms.Button();
      this.cmdControls = new System.Windows.Forms.Button();
      this.cmdTreeView = new System.Windows.Forms.Button();
      this.lblProduct = new System.Windows.Forms.Label();
      this.lblOrder = new System.Windows.Forms.Label();
      this.cmdDataSet = new System.Windows.Forms.Button();
      this.cmdDataGrid = new System.Windows.Forms.Button();
      this.erpDataSet = new System.Windows.Forms.ErrorProvider();
      this.dsData = new UsingWindows.dsData();
      this.txtPosition = new System.Windows.Forms.TextBox();
      this.txtDescription = new System.Windows.Forms.TextBox();
      this.txtCategoryName = new System.Windows.Forms.TextBox();
      this.lblName = new System.Windows.Forms.Label();
      this.lblIdCategory = new System.Windows.Forms.Label();
      this.erpControl = new System.Windows.Forms.ErrorProvider();
      this.txtIdCategory = new System.Windows.Forms.TextBox();
      this.lstOrder = new System.Windows.Forms.ListBox();
      this.lstProduct = new System.Windows.Forms.ListBox();
      this.cmdNext = new System.Windows.Forms.Button();
      this.cmdLast = new System.Windows.Forms.Button();
      this.cmdFirst = new System.Windows.Forms.Button();
      this.cmdPrevious = new System.Windows.Forms.Button();
      this.cnncpNorthWind2019 = new System.Data.SqlClient.SqlConnection();
      this.dtaProduct = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectProduct = new System.Data.SqlClient.SqlCommand();
      this.dtaCategory = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectCategory = new System.Data.SqlClient.SqlCommand();
      this.dtaOrderDate = new System.Data.SqlClient.SqlDataAdapter();
      this.cmmSelectOrderDates = new System.Data.SqlClient.SqlCommand();
      ((System.ComponentModel.ISupportInitialize)(this.erpDataSet)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.erpControl)).BeginInit();
      this.SuspendLayout();
      // 
      // cmdFindCategory
      // 
      this.cmdFindCategory.Location = new System.Drawing.Point(376, 112);
      this.cmdFindCategory.Name = "cmdFindCategory";
      this.cmdFindCategory.Size = new System.Drawing.Size(96, 23);
      this.cmdFindCategory.TabIndex = 36;
      this.cmdFindCategory.Text = "Find Category";
      this.cmdFindCategory.Click += new System.EventHandler(this.cmdFindCategory_Click);
      // 
      // cmdControls
      // 
      this.cmdControls.Location = new System.Drawing.Point(376, 16);
      this.cmdControls.Name = "cmdControls";
      this.cmdControls.Size = new System.Drawing.Size(96, 23);
      this.cmdControls.TabIndex = 33;
      this.cmdControls.Text = "Controls";
      this.cmdControls.Click += new System.EventHandler(this.cmdControls_Click);
      // 
      // cmdTreeView
      // 
      this.cmdTreeView.Location = new System.Drawing.Point(376, 80);
      this.cmdTreeView.Name = "cmdTreeView";
      this.cmdTreeView.Size = new System.Drawing.Size(96, 23);
      this.cmdTreeView.TabIndex = 35;
      this.cmdTreeView.Text = "TreeView";
      this.cmdTreeView.Click += new System.EventHandler(this.cmdTreeView_Click);
      // 
      // lblProduct
      // 
      this.lblProduct.AutoSize = true;
      this.lblProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblProduct.Location = new System.Drawing.Point(16, 88);
      this.lblProduct.Name = "lblProduct";
      this.lblProduct.Size = new System.Drawing.Size(61, 13);
      this.lblProduct.TabIndex = 24;
      this.lblProduct.Text = "Products:";
      // 
      // lblOrder
      // 
      this.lblOrder.AutoSize = true;
      this.lblOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblOrder.Location = new System.Drawing.Point(208, 88);
      this.lblOrder.Name = "lblOrder";
      this.lblOrder.Size = new System.Drawing.Size(48, 13);
      this.lblOrder.TabIndex = 26;
      this.lblOrder.Text = "Orders:";
      // 
      // cmdDataSet
      // 
      this.cmdDataSet.Location = new System.Drawing.Point(376, 144);
      this.cmdDataSet.Name = "cmdDataSet";
      this.cmdDataSet.Size = new System.Drawing.Size(96, 23);
      this.cmdDataSet.TabIndex = 37;
      this.cmdDataSet.Text = "DataSet Error";
      this.cmdDataSet.Click += new System.EventHandler(this.cmdDataSet_Click);
      // 
      // cmdDataGrid
      // 
      this.cmdDataGrid.Location = new System.Drawing.Point(376, 48);
      this.cmdDataGrid.Name = "cmdDataGrid";
      this.cmdDataGrid.Size = new System.Drawing.Size(96, 23);
      this.cmdDataGrid.TabIndex = 34;
      this.cmdDataGrid.Text = "DataGrid";
      this.cmdDataGrid.Click += new System.EventHandler(this.cmdDataGrid_Click);
      // 
      // erpDataSet
      // 
      this.erpDataSet.ContainerControl = this;
      this.erpDataSet.DataMember = "tblCPCategory";
      this.erpDataSet.DataSource = this.dsData;
      // 
      // dsData
      // 
      this.dsData.DataSetName = "dsData";
      this.dsData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
      // 
      // txtPosition
      // 
      this.txtPosition.Location = new System.Drawing.Point(80, 296);
      this.txtPosition.Name = "txtPosition";
      this.txtPosition.Size = new System.Drawing.Size(320, 20);
      this.txtPosition.TabIndex = 30;
      // 
      // txtDescription
      // 
      this.txtDescription.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPCategory.memDescription", true));
      this.txtDescription.Location = new System.Drawing.Point(16, 64);
      this.txtDescription.Name = "txtDescription";
      this.txtDescription.Size = new System.Drawing.Size(344, 20);
      this.txtDescription.TabIndex = 23;
      // 
      // txtCategoryName
      // 
      this.txtCategoryName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPCategory.strCategoryName", true));
      this.txtCategoryName.Location = new System.Drawing.Point(104, 36);
      this.txtCategoryName.Name = "txtCategoryName";
      this.txtCategoryName.Size = new System.Drawing.Size(256, 20);
      this.txtCategoryName.TabIndex = 22;
      this.txtCategoryName.Tag = "";
      this.txtCategoryName.Validating += new System.ComponentModel.CancelEventHandler(this.txtCategoryName_Validating);
      // 
      // lblName
      // 
      this.lblName.AutoSize = true;
      this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblName.Location = new System.Drawing.Point(16, 40);
      this.lblName.Name = "lblName";
      this.lblName.Size = new System.Drawing.Size(43, 13);
      this.lblName.TabIndex = 21;
      this.lblName.Text = "Name:";
      // 
      // lblIdCategory
      // 
      this.lblIdCategory.AutoSize = true;
      this.lblIdCategory.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblIdCategory.Location = new System.Drawing.Point(16, 16);
      this.lblIdCategory.Name = "lblIdCategory";
      this.lblIdCategory.Size = new System.Drawing.Size(86, 13);
      this.lblIdCategory.TabIndex = 19;
      this.lblIdCategory.Text = "Category Key:";
      // 
      // erpControl
      // 
      this.erpControl.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
      this.erpControl.ContainerControl = this;
      this.erpControl.DataMember = "";
      // 
      // txtIdCategory
      // 
      this.txtIdCategory.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.dsData, "tblCPCategory.intIdCategory", true));
      this.txtIdCategory.Location = new System.Drawing.Point(104, 8);
      this.txtIdCategory.Name = "txtIdCategory";
      this.txtIdCategory.Size = new System.Drawing.Size(256, 20);
      this.txtIdCategory.TabIndex = 20;
      this.txtIdCategory.Validating += new System.ComponentModel.CancelEventHandler(this.txtIdCategory_Validating);
      // 
      // lstOrder
      // 
      this.lstOrder.Location = new System.Drawing.Point(208, 104);
      this.lstOrder.Name = "lstOrder";
      this.lstOrder.Size = new System.Drawing.Size(152, 186);
      this.lstOrder.TabIndex = 27;
      // 
      // lstProduct
      // 
      this.lstProduct.DataSource = this.dsData;
      this.lstProduct.DisplayMember = "tblCPCategory.ProductCategory.strProductName";
      this.lstProduct.Location = new System.Drawing.Point(16, 104);
      this.lstProduct.Name = "lstProduct";
      this.lstProduct.Size = new System.Drawing.Size(184, 186);
      this.lstProduct.TabIndex = 25;
      this.lstProduct.ValueMember = "tblCPCategory.ProductCategory.intIdProduct";
      // 
      // cmdNext
      // 
      this.cmdNext.Location = new System.Drawing.Point(408, 296);
      this.cmdNext.Name = "cmdNext";
      this.cmdNext.Size = new System.Drawing.Size(32, 23);
      this.cmdNext.TabIndex = 31;
      this.cmdNext.Text = ">";
      this.cmdNext.Click += new System.EventHandler(this.cmdNext_Click);
      // 
      // cmdLast
      // 
      this.cmdLast.Location = new System.Drawing.Point(440, 296);
      this.cmdLast.Name = "cmdLast";
      this.cmdLast.Size = new System.Drawing.Size(32, 23);
      this.cmdLast.TabIndex = 32;
      this.cmdLast.Text = ">>|";
      this.cmdLast.Click += new System.EventHandler(this.cmdLast_Click);
      // 
      // cmdFirst
      // 
      this.cmdFirst.Location = new System.Drawing.Point(8, 296);
      this.cmdFirst.Name = "cmdFirst";
      this.cmdFirst.Size = new System.Drawing.Size(32, 23);
      this.cmdFirst.TabIndex = 28;
      this.cmdFirst.Text = "|<<";
      this.cmdFirst.Click += new System.EventHandler(this.cmdFirst_Click);
      // 
      // cmdPrevious
      // 
      this.cmdPrevious.Location = new System.Drawing.Point(40, 296);
      this.cmdPrevious.Name = "cmdPrevious";
      this.cmdPrevious.Size = new System.Drawing.Size(32, 23);
      this.cmdPrevious.TabIndex = 29;
      this.cmdPrevious.Text = "<";
      this.cmdPrevious.Click += new System.EventHandler(this.cmdPrevious_Click);
      // 
      // cnncpNorthWind2019
      // 
      this.cnncpNorthWind2019.ConnectionString = "Data Source=copypastepower\\copypaste;Initial Catalog=cpNorthWindScript2019;Integr" +
    "ated Security=True";
      this.cnncpNorthWind2019.FireInfoMessageEventOnUserErrors = false;
      // 
      // dtaProduct
      // 
      this.dtaProduct.SelectCommand = this.cmmSelectProduct;
      this.dtaProduct.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPProduct", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intCategoryId", "intCategoryId"),
                        new System.Data.Common.DataColumnMapping("intIdProduct", "intIdProduct"),
                        new System.Data.Common.DataColumnMapping("strProductName", "strProductName"),
                        new System.Data.Common.DataColumnMapping("blnDiscontinued", "blnDiscontinued"),
                        new System.Data.Common.DataColumnMapping("dblUnitPrice", "dblUnitPrice")})});
      // 
      // cmmSelectProduct
      // 
      this.cmmSelectProduct.CommandText = "SELECT        intCategoryId, intIdProduct, strProductName, blnDiscontinued, dblUn" +
    "itPrice\r\nFROM            tblCPProduct";
      this.cmmSelectProduct.Connection = this.cnncpNorthWind2019;
      // 
      // dtaCategory
      // 
      this.dtaCategory.SelectCommand = this.cmmSelectCategory;
      this.dtaCategory.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "tblCPCategory", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("intIdCategory", "intIdCategory"),
                        new System.Data.Common.DataColumnMapping("strCategoryName", "strCategoryName"),
                        new System.Data.Common.DataColumnMapping("memDescription", "memDescription")})});
      // 
      // cmmSelectCategory
      // 
      this.cmmSelectCategory.CommandText = "SELECT        intIdCategory, strCategoryName, memDescription\r\nFROM            tbl" +
    "CPCategory";
      this.cmmSelectCategory.Connection = this.cnncpNorthWind2019;
      // 
      // dtaOrderDate
      // 
      this.dtaOrderDate.SelectCommand = this.cmmSelectOrderDates;
      this.dtaOrderDate.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
            new System.Data.Common.DataTableMapping("Table", "OrderDate", new System.Data.Common.DataColumnMapping[] {
                        new System.Data.Common.DataColumnMapping("dtmOrderDate", "dtmOrderDate"),
                        new System.Data.Common.DataColumnMapping("intProductId", "intProductId")})});
      // 
      // cmmSelectOrderDates
      // 
      this.cmmSelectOrderDates.CommandText = resources.GetString("cmmSelectOrderDates.CommandText");
      this.cmmSelectOrderDates.Connection = this.cnncpNorthWind2019;
      // 
      // frmMaster
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(480, 325);
      this.Controls.Add(this.cmdDataGrid);
      this.Controls.Add(this.txtPosition);
      this.Controls.Add(this.txtDescription);
      this.Controls.Add(this.txtCategoryName);
      this.Controls.Add(this.lblName);
      this.Controls.Add(this.lblIdCategory);
      this.Controls.Add(this.txtIdCategory);
      this.Controls.Add(this.lblProduct);
      this.Controls.Add(this.lblOrder);
      this.Controls.Add(this.lstOrder);
      this.Controls.Add(this.lstProduct);
      this.Controls.Add(this.cmdNext);
      this.Controls.Add(this.cmdLast);
      this.Controls.Add(this.cmdFirst);
      this.Controls.Add(this.cmdPrevious);
      this.Controls.Add(this.cmdFindCategory);
      this.Controls.Add(this.cmdControls);
      this.Controls.Add(this.cmdTreeView);
      this.Controls.Add(this.cmdDataSet);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmMaster";
      this.Text = "Windows Controls Master";
      ((System.ComponentModel.ISupportInitialize)(this.erpDataSet)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.dsData)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.erpControl)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmMaster'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmMaster()
      //***
      // Action
      //   - Create new instance of 'frmMaster'
      //   - Fill the data set tblCPCategory with data adapter category
      //   - Fill the data set tblCPProduct with data adapter product
      //   - Fill the data set tblCPOrderDaet with data adapter orderdate
      //   - Sort the categories on key
      //   - Update the display
      //   - The data source for the list box becomes the data set
      //   - The displayed item for the list is the order date
      // Called by
      //   - User action (Starting the form)
      // Calls
      //   - FormatName(System.Object, System.Windows.Forms.ConvertEventArgs)
      //   - InitializeComponent()
      //   - ParseName(System.Object, System.Windows.Forms.ConvertEventArgs)
      //   - tblCPCategory_ColumnChanging(System.Object, System.Data.DataColumnChangeEventArgs)
      //   - tblCPCategory_ItemChanged(System.Object, System.Windows.Forms.ItemChangedEventArgs)
      //   - tblCPCategory_RowChanging(System.Object, System.Data.DataRowChangeEventArgs)
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();
      dtaCategory.Fill(dsData.tblCPCategory);
      dtaProduct.Fill(dsData.tblCPProduct);
      dtaOrderDate.Fill(dsData.OrderDate);
      dsData.tblCPCategory.DefaultView.Sort = "intIdCategory";
      UpdateDisplay();

      // The items below works correctly
      // txtCategoryName.DataBindings[0].Format += new ConvertEventHandler(FormatName);
      // txtCategoryName.DataBindings[0].Parse += new ConvertEventHandler(ParseName);
      // dsData.tblCPCategory.ColumnChanging += new System.Data.DataColumnChangeEventHandler(tblCPCategory_ColumnChanging);
      // dsData.tblCPCategory.RowChanging += new System.Data.DataRowChangeEventHandler(tblCPCategory_RowChanging);

      // Seems that this below now works correctly (in previous versions before 2019, this had a wrong behaviour
      // ((CurrencyManager)(BindingContext[dsData, "tblCPCategory"])).ItemChanged += new ItemChangedEventHandler(tblCPCategory_ItemChanged);
      
      lstOrder.DataSource = dsData;
      lstOrder.DisplayMember = "tblCPCategory.ProductCategory.OrderDateProduct.dtmOrderDate";
    }
    // frmMaster()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"

    private void cmdControls_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmControls
      //   - Show the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmControls()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmControls thefrmControls = new frmControls();

      thefrmControls.Show();
    }
    // cmdControls_Click(System.Object, System.EventArgs) Handles cmdControls.Click
    
    private void cmdDataGrid_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmDataGrid
      //   - Show the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmDataGrid()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmDataGrid thefrmDataGrid = new frmDataGrid();

      thefrmDataGrid.Show();
    }
    // cmdDataGrid_Click(System.Object, System.EventArgs) Handles cmdDataGrid.Click

    private void cmdDataSet_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - The first row, field "memDescription" shows an error
      //     - There is a data set assigned in the error provider
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      dsData.tblCPCategory.Rows[0].SetColumnError("memDescription", "Error Created Here");
    }
    // cmdDataSet_Click(System.Object, System.EventArgs) Handles cmdDataSet.Click

    private void cmdFindCategory_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define a array of data rows
      //   - Define a data table and assign tblCPCategory to it
      //   - Define a default data view on tblCPCategory
      //   - Define a key
      //   - Define a name
      //   - Create an instance of frmFindCategory
      //   - Show the dialog
      //   - If form was closed with default button
      //     - If the received key is zero
      //       - Get the received name
      //       - Try to
      //         - Find (using select) the data row with the typed name
      //           - Find does not work in a not sorted list, use Select instead
      //         - Get the key of that row
      //         - Find in the default view the position
      //         - Go to that position
      //       - On error
      //         - Show that record was not found
      //   - If not
      //     - Get the received key
      //     - Find in the default view the position
      //       - Find works in a sorted list
      //     - If position is -1
      //       - Show that record was not found
      //     - If not
      //       - Go to that position
      //   - Clean up the instance of frmFindCategory
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmFindCategory()
      //   - int frmFindCategory.GetKey (Get)
      //   - string frmFindCategory.GetName (Get)
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      DataRow[] arrdrwDataRow;
      DataTable dtDataTable = dsData.tblCPCategory;
      DataView dvDataView = dsData.tblCPCategory.DefaultView;
      int lngIndex;
      int lngKey;
      string strName;
      frmFindCategory thefrmFindCategory = new frmFindCategory();

      if (thefrmFindCategory.ShowDialog() == DialogResult.OK)
      {
        
        if (thefrmFindCategory.GetKey == 0)
        {
          strName = thefrmFindCategory.GetName;

          try
          {
            arrdrwDataRow = dtDataTable.Select("strCategoryName = '" + strName + "'");
            lngKey = ((dsData.tblCPCategoryRow)arrdrwDataRow[0]).intIdCategory;
            lngIndex = dvDataView.Find(lngKey);
            BindingContext[dsData, "tblCPCategory"].Position = lngIndex;
          }
          catch (Exception theException)
          {
            MessageBox.Show("Category " + strName + " not found", "Error");
          }
          finally
          {
          }

        }
        else
          // thefrmFindCategory.GetKey <> 0
        {
          lngKey = thefrmFindCategory.GetKey;
          lngIndex = dvDataView.Find(lngKey);

          if (lngIndex == -1)
          {
            MessageBox.Show("Category " + lngKey.ToString() + " not found", "Error");
          }
          else
            // lngIndex <> -1
          {
            BindingContext[dsData, "tblCPCategory"].Position = lngIndex;
          }
          // lngIndex = -1

        }
        // thefrmFindCategory.GetKey = 0
      
      }
      else
        // thefrmFindCategory.ShowDialog() <> DialogResult.OK
      {
      }
      // thefrmFindCategory.ShowDialog() = DialogResult.OK

      thefrmFindCategory.Dispose();
    }
    // cmdFindCategory_Click(System.Object, System.EventArgs) Handles cmdFindCategory.Click

    private void cmdFirst_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the first position
      //   - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsData, "tblCPCategory"].Position = 0;
      UpdateDisplay();
    }
    // cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click

    private void cmdLast_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Go to the last position
      //   - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      BindingContext[dsData, "tblCPCategory"].Position = BindingContext[dsData, "tblCPCategory"].Count - 1;
      UpdateDisplay();
    }
    // cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click

    private void cmdNext_Click(System.Object theSender, System.EventArgs theEventArguments)
      // Action
      //   - If you are at the last position
      //     - Do nothing
      //   - If not
      //     - Go to the next position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (BindingContext[dsData, "tblCPCategory"].Position == BindingContext[dsData, "tblCPCategory"].Count - 1)
      {
      }
      else
      // BindingContext[dsData, "tblCPCategory"].Position <> BindingContext[dsData, "tblCPCategory"].Count - 1 
      {
        BindingContext[dsData, "tblCPCategory"].Position += 1;
        UpdateDisplay();
      }
      // BindingContext[dsData, "tblCPCategory"].Position = BindingContext[dsData, "tblCPCategory"].Count - 1 

    }
    // cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click

    private void cmdPrevious_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - If you are at the first position
      //     - Do nothing
      //   - If not
      //     - Go to the previous position
      //     - Update the display
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - UpdateDisplay()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (BindingContext[dsData, "tblCPCategory"].Position == 0)
      {
      }
      else
      // BindingContext[dsData, "tblCPCategory"].Position <> 0
      {
        BindingContext[dsData, "tblCPCategory"].Position -= 1;
        UpdateDisplay();
      }
      // BindingContext[dsData, "tblCPCategory"].Position = 0

    }
    // cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click

    private void cmdTreeView_Click(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Create a new instance of frmTreeView
      //   - Show the form
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - frmTreeView()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      frmTreeView thefrmTreeView = new frmTreeView();

      thefrmTreeView.Show();
    }
    // cmdTreeView_Click(System.Object, System.EventArgs) Handles cmdTreeView.Click

    private void txtIdCategory_Validating(System.Object theSender, System.ComponentModel.CancelEventArgs theCancelEventArguments)
      //***
      // Action
      //   - If entered text is "Error"
      //     - Show error control with error message
      //     - Cancel the entered value
      //   - If not
      //     - Remove the error control
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (txtIdCategory.Text == "Error")
      {
        erpControl.SetError(txtIdCategory, "Please re-enter the Category-Id");
        theCancelEventArguments.Cancel = true;
      }
      else
        // txtIdCategory.Text <> "Error"
      {
        erpControl.SetError(txtIdCategory, "");
      }
      // txtIdCategory.Text = "Error"

    }
    // txtIdCategory_Validating(System.Object, System.ComponentModel.CancelEventArgs) Handles txtIdCategory.Validating

    private void txtCategoryName_Validating(System.Object theSender, System.ComponentModel.CancelEventArgs theCancelEventArguments)
      //***
      // Action
      //   - If entered text is "Error"
      //     - Show error message
      //     - Cancel the entered value
      //   - If not
      //     - Do nothing
      // Called by
      //   - User action (Clicking a button)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (txtCategoryName.Text == "Cancel")
      {
        MessageBox.Show("Change the Name from 'Cancel'", "Validating");
        theCancelEventArguments.Cancel = true;
      }
      else
        // txtCategoryName.Text <> "Cancel"
      {
      }
      // txtCategoryName.Text = "Cancel"

    }
    // txtCategoryName_Validating(System.Object, System.ComponentModel.CancelEventArgs) Handles txtCategoryName.Validating

    #endregion

    #region "Functionality"

    #region "Event"

    private void FormatName(System.Object theSender, ConvertEventArgs theConvertEventArguments)
      //***
      // Action
      //   - If tag of txtCategoryName equals "PARSE"
      //     - Do nothing
      //   - If not
      //     - Set the value of the argument to uppercase 
      //   - Tag of txtCategoryName becomes "FORMAT"
      //   - Show a messagebox with the convert arguments
      // Called by
      //   - frmMaster()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {

      if (txtCategoryName.Tag.ToString() == "PARSE")
      {
      }
      else
        // txtCategoryName.Tag.ToString() <> "PARSE"
      {
        theConvertEventArguments.Value = theConvertEventArguments.Value.ToString().ToUpper();
      }
      // txtCategoryName.Tag.ToString() = "PARSE"

      txtCategoryName.Tag = "FORMAT";
      MessageBox.Show(theConvertEventArguments.Value.ToString(), "Format");
    }
    // FormatName(System.Object, System.Windows.Forms.ConvertEventArgs)

    private void ParseName(System.Object theSender, ConvertEventArgs theConvertEventArguments)
      //***
      // Action
      //   - The tag of txtCategoryName becomes "PARSE"
      //   - Set the value of the argument to lowercase
      //   - Show a messagebox with the convert arguments
      // Called by
      //   - frmMaster()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      txtCategoryName.Tag = "PARSE";
      theConvertEventArguments.Value = theConvertEventArguments.Value.ToString().ToLower();
      MessageBox.Show(theConvertEventArguments.Value.ToString(), "Parse");
    }
    // ParseName(System.Object, System.Windows.Forms.ConvertEventArgs)

    private void tblCPCategory_ColumnChanging(System.Object theSender, System.Data.DataColumnChangeEventArgs theDataColumnChangeEventArguments)
      //***
      // Action
      //   - Prepare a message with the changed column and the new value
      //   - Show a messagebox with the prepared message
      // Called by
      //   - frmMaster()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strMessage;

      strMessage = "Column: " + theDataColumnChangeEventArguments.Column.ColumnName.ToString() + Environment.NewLine +
        "New Value: " + theDataColumnChangeEventArguments.ProposedValue.ToString();
      MessageBox.Show(strMessage);
    }
    // tblCPCategory_ColumnChanging(System.Object, System.Data.DataColumnChangeEventArgs)

    private void tblCPCategory_ItemChanged(System.Object theSender, System.Windows.Forms.ItemChangedEventArgs theItemChangedEventArguments)
      //***
      // Action
      //   - Prepare a message with the changed item
      //   - Show a messagebox with the prepared message
      // Called by
      //   - frmMaster()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strMessage;

      strMessage = "Index into CurrencyManager List: " + theItemChangedEventArguments.Index.ToString();
      MessageBox.Show(strMessage, "Item Changed");
    }
    // tblCPCategory_ItemChanged(System.Object, System.Windows.Forms.ItemChangedEventArgs)

    private void tblCPCategory_RowChanging(System.Object theSender, System.Data.DataRowChangeEventArgs theDataRowChangeEventArguments)
      //***
      // Action
      //   - Prepare a message with the action on the changed row and the key
      //   - Show a messagebox with the prepared message
      // Called by
      //   - frmMaster()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strMessage;

      strMessage = "Action: " + theDataRowChangeEventArguments.Action.ToString() + Environment.NewLine +
        "Key: " + theDataRowChangeEventArguments.Row["intIdCategory"].ToString();
      MessageBox.Show(strMessage);
    }
    // tblCPCategory_RowChanging(System.Object, System.Data.DataRowChangeEventArgs)

    #endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmMaster
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmMaster()
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmMaster());
    }
    // Main() 
    
    private void UpdateDisplay()
      //***
      // Action
      //   - Define a binding manager base
      //   - Assign the binding manager base to the data table tblCPCategory from the data set
      //   - Show the current position
      // Called by
      //   - cmdFirst_Click(System.Object, System.EventArgs) Handles cmdFirst.Click
      //   - cmdNext_Click(System.Object, System.EventArgs) Handles cmdNext.Click
      //   - cmdLast_Click(System.Object, System.EventArgs) Handles cmdLast.Click
      //   - cmdPrevious_Click(System.Object, System.EventArgs) Handles cmdPrevious.Click
      //   - frmMaster()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20260113 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20260113 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      System.Windows.Forms.BindingManagerBase bmbBindingManagerBase;

      bmbBindingManagerBase = BindingContext[dsData, "tblCPCategory"];
      txtPosition.Text = "Category " + (bmbBindingManagerBase.Position + 1).ToString() +
        " of " + bmbBindingManagerBase.Count.ToString();
    }
    // UpdateDisplay()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmMaster

}
// CopyPaste.Learning