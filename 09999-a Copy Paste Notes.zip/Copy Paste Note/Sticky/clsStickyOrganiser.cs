//***
// Action
//   - All code to have a correct behaviour to manage postits
// Created
//   - CopyPaste � 20250806 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20250806 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Xml;

namespace CopyPaste.Learning.PostIt
{

  public class cpStickyOrganiser
  {

    #region "Constructors / Destructors"

    public cpStickyOrganiser()
      //***
      // Action
      //   - Define a table "tblCPNote"
      //   - Clear the data in that table to remove older data
      //   - Define a new column "strTitle" of data type string
      //   - Add the column to the table
      //   - Define a new column "strMessage" of data type string
      //   - Add the column to the table
      //   - Define a new column "strLocation" of data type string
      //   - Add the column to the table
      //   - Define a new column "strSize" of data type string
      //   - Add the column to the table
      //   - Define a new dataset
      //   - Add the table to the dataset
      // Called by
      //   - frmNoteStartup()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mdtDataTable = new DataTable("tblCPNote");
      mdtDataTable.Clear();

      mdclDataColumn = new DataColumn();

      mdclDataColumn.DataType = System.Type.GetType("System.String");
      mdclDataColumn.ColumnName = "strTitle";
      mdtDataTable.Columns.Add(mdclDataColumn);

      mdclDataColumn = new DataColumn();

      mdclDataColumn.DataType = System.Type.GetType("System.String");
      mdclDataColumn.ColumnName = "strMessage";
      mdtDataTable.Columns.Add(mdclDataColumn);

      mdclDataColumn = new DataColumn();

      mdclDataColumn.DataType = System.Type.GetType("System.String");
      mdclDataColumn.ColumnName = "strLocation";
      mdtDataTable.Columns.Add(mdclDataColumn);

      mdclDataColumn = new DataColumn();

      mdclDataColumn.DataType = System.Type.GetType("System.String");
      mdclDataColumn.ColumnName = "strSize";
      mdtDataTable.Columns.Add(mdclDataColumn);

      mdsDataSet = new DataSet();
      mdsDataSet.Tables.Add(mdtDataTable);
    }
    // cpStickyOrganiser()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static ArrayList marrNote = new ArrayList();
    private DataColumn mdclDataColumn;
    private DataRow mdrwDataRow;
    private DataSet mdsDataSet;
    private DataTable mdtDataTable;

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void AddNewNote(frmStickyNote theNote)
      //***
      // Action
      //   - Add a note (theNote) to the array of notes
      // Called by
      //   - frmNoteStartup.mnuNew(System.Object, System.EventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      marrNote.Add(theNote);
    }
    // AddNewNote(frmStickyNote)

    public static void DeleteNote(frmStickyNote theNote)
      //***
      // Action
      //   - Delete a note from the array of notes
      // Called by
      //   - frmStickyNote.mnuNoteDelete_Click(System.Object, System.EventArgs) Handles mnuNoteDelete.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      marrNote.Remove(theNote);
    }
    // DeleteNote(frmStickyNote)

    private Point FormatPoint(string strPoint)
      //***
      // Action
      //   - Define an array of string with the content of strPoint delimited on the comma
      //   - Define an array of end characters
      //   - Define an array of start characters
      //   - Create a new point
      //   - Define the first element of arrstrPoint as the X coordinate (all start characters removed)
      //   - Define the second element of arrstrPoint as the rest of the coordinate (all start characters removed)
      //   - Define the Y coordinate of the rest (the "}" removed)
      //   - Return the point
      //     - An example: strPoint Contains {X=248,Y=184} --> Point need 248,184
      // Called by
      //   - ReadData()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      char[] arrchrEnd = {'Y', '='};
      char[] arrchrStart = {'{', 'X', '='};
      Point thePoint = new Point();
      string strFormattedPoint;
      string[] arrstrPoint = strPoint.Split(',');

      thePoint.X = Convert.ToInt32(arrstrPoint[0].TrimStart(arrchrStart));
      strFormattedPoint = arrstrPoint[1].TrimStart(arrchrEnd);
      thePoint.Y = Convert.ToInt32(strFormattedPoint.Trim('}'));
      return thePoint;
    }
    // Point FormatPoint(string)

    private Size FormatSize(string strPoint)
      //***
      // Action
      //   - Define an array of the height characters
      //   - Define an array of the width characters
      //   - Define an array of strings (split strPoint on a comma)
      //   - Define a new size
      //   - Set the width of the size to the first element of array of strings, with all width characters removed
      //   - Set the height of the size to the second element of array of strings, with all height characters removed
      //   - Return the size
      //     - An example: strPoint Contains {Width=248,Height=184} --> Size need 248,184
      //     - Due to the menu in the form, I subtract 19 points from the height
      // Called by
      //   - ReadData()
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      char[] arrchrHeight = {' ', 'H', 'e', 'i', 'g', 'h', 't', '='};
      char[] arrchrWidth = {'{', 'W', 'i', 'd', 't', 'h', '='};
      Size theSize = new Size();
      string strFormattedPoint;
      string[] arrstrPoint = strPoint.Split(',');

      theSize.Width = Convert.ToInt32(arrstrPoint[0].TrimStart(arrchrWidth));
      strFormattedPoint = arrstrPoint[1].TrimStart(arrchrHeight);
      theSize.Height = Convert.ToInt32(strFormattedPoint.Trim('}')) - 19;
      return theSize;
    }
    // Size FormatSize(string)

    public void HideAll()
      //***
      // Action
      //   - Loop thru all the notes
      //     - Hide them
      // Called by
      //   - frmNoteStartup.mnuHide(System.Object, System.EventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      
      foreach (frmStickyNote theNote in marrNote)
      {
        theNote.Hide();
      }
      // in marrNote

    }
    // HideAll()

    public void ReadData() // Deserialize
      //***
      // Action
      //   - We will deserialize the information
      //     - Going from textfile (xml) to objects
      //   - Define a location
      //   - Define a point
      //   - Define a stream
      //   - Try
      //     - Open a file from the T: root with read access into the stream
      //     - Define an xml text reader with the stream
      //     - Read the data from the stream into the dataset
      //     - Close the reader
      //     - Loop thru the tables of the dataset
      //       - Loop thru the rows of the table
      //         - Make a note (frmStickyNote)
      //         - The title of the form becomes content of column strTitle
      //         - The text becomes content of column strMessage
      //         - The location becomes content of column strLocation formatted into a point
      //         - The size becomes content of column strSize formatted into a size
      //         - Show the note
      //         - Add the note to the array of notes
      //     - Close the stream
      //     - If there are no notes
      //       - Show a message how to add one
      //     - If not
      //       - Do nothing
      // Called by
      //   - 
      // Calls
      //   - frmStickyNote()
      //   - Point FormatPoint(string)
      //   - Size FormatSize(string)
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      string strPoint;
      // Contains {X=248,Y=184} --> Point need 248,184
      string strSize;
      // Contains {Width=248,Height=184} --> Size need 248,184
      Stream theStream = null;

      try
      {
        theStream = File.Open("T:\\notes.xml", FileMode.OpenOrCreate, FileAccess.Read);
        
        XmlTextReader theXmlReader = new XmlTextReader(theStream);
        
        mdsDataSet.ReadXml(theXmlReader);
        theXmlReader.Close();
        
        foreach (DataTable mdtDataTable in mdsDataSet.Tables)
        {
          
          foreach (DataRow mdrwDataRow in mdtDataTable.Rows)
          {
            frmStickyNote theNote = new frmStickyNote();
            
            theNote.Text = mdrwDataRow["strTitle"].ToString();
            theNote.txtNote.Text = mdrwDataRow["strMessage"].ToString();
            strPoint = mdrwDataRow["strLocation"].ToString();
            theNote.Location = FormatPoint(strPoint);
            strSize = mdrwDataRow["strSize"].ToString();
            theNote.Size = FormatSize(strSize);
            theNote.Show();
            marrNote.Add(theNote);
          }
          // In mdtDataTable.Rows

        }
        // in mdsDataSet.Tables

      }
      catch
      {
      }
      finally
      {
      }

      theStream.Close();

      if (marrNote.Count == 0)
      {
        MessageBox.Show("No notes - please right click icon in tray", "Copy Paste - Sticky Notes", MessageBoxButtons.OK, MessageBoxIcon.Information);
      }
      else
        // marrNote.Count <> 0
      {
      }
      // marrNote.Count = 0

    }
    // ReadData()

    public void SaveData() // Serialize
      //***
      // Action
      //   - We will serialize the information
      //     - Going from objects to textfile (xml)
      //   - Define a frmStickyNote
      //   - Define a stream
      //   - Open a file from the T: root with read write access to the stream
      //   - Clear the data in the data table (inside the data set)
      //   - Loop thru the array of notes
      //     - Create a new row in the data table
      //     - Column strTitle becomes the The title of the form
      //     - Column strMessage becomes the text
      //     - Column strLocation becomes the location of the form
      //     - Column strSize becomes the size of the form
      //     - The row is added to the table
      //   - Save the dataset into the stream
      //   - Close the stream
      // Called by
      //   - frmNoteStartup.Dispose(bool)
      //   - frmNoteStartup.mnuSave(System.Object, System.EventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Stream theStream = File.Open("T:\\notes.xml", FileMode.Create, FileAccess.ReadWrite);

      mdtDataTable.Clear();

      foreach (frmStickyNote theNote in marrNote)
      {
        mdrwDataRow = mdtDataTable.NewRow();
        mdrwDataRow["strTitle"] = theNote.Text;
        mdrwDataRow["strMessage"] = theNote.txtNote.Text;
        mdrwDataRow["strLocation"] = theNote.Location;
        mdrwDataRow["strSize"] = theNote.Size;
        mdtDataTable.Rows.Add(mdrwDataRow);
      }
      // in marrNote

      mdsDataSet.WriteXml(theStream);
      theStream.Close();
    }
    // SaveData()

    public void ShowAll()
      //***
      // Action
      //   - Loop thru all the notes
      //     - Show them
      // Called by
      //   - frmNoteStartup.mnuShow(System.Object, System.EventArgs)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20250806 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20250806 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      
      foreach(frmStickyNote theNote in marrNote)
      {
        theNote.Show();
      }
      // in marrNote

    }
    // ShowAll()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpStickyOrganiser

}
// CopyPaste.Learning.PostIt