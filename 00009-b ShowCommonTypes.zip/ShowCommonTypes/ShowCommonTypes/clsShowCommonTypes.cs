//***
// Action
//   - Exercise on types of variables
// Created
//   - CopyPaste � 20230607 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20230607 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace ShowCommonTypes
{

  public class cpShowCommonTypes
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    static void Main()
    //***
    // Action
    //   - Write fullname of type of variables
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - System.Char.GetType.FullName() (Non-Shared)
    //   - System.Console.ReadLine()
    //   - System.Console.WriteLine(string)
    //   - System.Double.GetType.FullName() (Non-Shared)
    //   - System.Int32.GetType.FullName() (Non-Shared)
    //   - System.Int64.GetType.FullName() (Non-Shared)
    //   - System.Short.GetType.FullName() (Non-Shared)
    //   - System.Single.GetType.FullName() (Non-Shared)
    // Created
    //   - CopyPaste � 20230607 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20230607 � VVDW
    // Keyboard key
    //   -
    // Proposal (To Do)
    //   -
    //***
    {
      short A = 0;
      int B = 0;
      long C = 0;
      float D = 0;
      double E = 0;
      char F = 'A';
			
      Console.WriteLine("A: {0} ", A.GetType().FullName);
      Console.WriteLine("B: {0} ", B.GetType().FullName);
      Console.WriteLine("C: {0} ", C.GetType().FullName);
      Console.WriteLine("D: {0} ", D.GetType().FullName);
      Console.WriteLine("E: {0} ", E.GetType().FullName);
      Console.WriteLine("F: {0} ", F.GetType().FullName);
			
      Console.ReadLine();
    }
    // Main()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

	}
  // cpShowCommonTypes

}
// ShowCommonTypes