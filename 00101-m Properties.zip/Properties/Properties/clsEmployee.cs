//***
// Action
//   - Define a cpEmployee (Name and a set of Wage)
//   - An empty constructor and some properties
// Created
//   - CopyPaste � 20220308 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220308 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning.Toolkit
{

  public class cpEmployee
	{

    #region "Constructors / Destructors"

    public cpEmployee()
      //***
      // Action
      //   - 
      // Called by
      //   - System action (Creating an instance)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20220308 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20220308 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
    }
    // cpEmployee()

    #endregion

    #region "Designer"

    public enum WageConstant
    {
      Rate = 0,
      OverTime = 1,
      Weekend = 2,
      WeekendOverTime = 3,
    }
    // WageConstant

    #endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    decimal[] marrdecWage = new decimal[4];
    string mstrName;
    WageConstant mWageConstant;

    #endregion

    #region "Properties"

    public string Name
    {

      get
        //***
        // Action Get
        //   - Return mstrName
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220308 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220308 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mstrName;
      }
      // string Name (Get)

      set
        //***
        // Action Set
        //   - Set mstrName
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220308 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220308 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mstrName = value;
      }
      // Name(string) (Set)

    }
    // string Name

    public decimal Wage
    {
    
      get
        //***
        // Action Get
        //   - Return the correct Wage depending on theWageConstant
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220308 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220308 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return marrdecWage[(int)mWageConstant];
      }
      // decimal Wage (Get)

      set 
        //***
        // Action Set
        //   - Setting the correct Wage depending on theWageConstant
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220308 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220308 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        marrdecWage[(int)mWageConstant] = value;
      }
    
    }
    // Wage(decimal) (Set)

    public WageConstant theWageConstant
    {
    
      get
        //***
        // Action Get
        //   - Return the correct theWageConstant
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220308 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220308 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        return mWageConstant;
      }
      // WageConstant theWageConstant (Get)

      set 
        //***
        // Action Set
        //   - Setting the correct theWageConstant
        // Called by
        //   - cpProgram.Main()
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20220308 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20220308 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
        mWageConstant = value;
      }
    
    }
    // theWageConstant(WageConstant) (Set)

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion
    
  }
  // cpEmployee
}
// CopyPaste.Learning.Toolkit