﻿//***
// Action
//   - The event argument class is inherited with some useful information
// Created
//   - CopyPaste – 20250716 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20250716 – VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpMoreArguments: EventArgs
  {

    #region "Constructors / Destructors"

    public cpMoreArguments(string strText, DateTime dtmTime): base()
      //***
      // Action
      //   - Basic constructor with string and date time
      // Called by
      //   - cpHackerMonitor.GenerateEvent()
      // Calls
      //   - 
      // Created
      //   - CopyPaste – 20250716 – VVDW
      // Changed
      //   - CopyPaste – yyyymmdd – VVDW – What changed
      // Tested
      //   - CopyPaste – 20250716 – VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      mstrMessage = strText;
      mdtmTime = dtmTime;
    }
    // cpMoreArguments(string, DateTime)

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public DateTime mdtmTime;
    public string mstrMessage;

    #endregion

    //#region "Properties"
    //#endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
		//#endregion

    //#endregion
    
    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpMoreArguments

}
// CopyPaste.Learning