<%@ Page language="C#" %>

<html>
<head>
  <title>Retrieve Cookies</title>
</head>
<body>
  <center>
    <h1>Cookies Values</h1>
  </center>
  <hr/>
  
  <%
  
       Response.Write("Title: " + Request.Cookies["cpBook"]["Title"] + "<br>");
       Response.Write("Publisher: " + Request.Cookies["cpBook"]["Publisher"] + "<br>");
       Response.Write("Author: " + Request.Cookies["cpBook"]["Author"] + "<br>");
  
  %>
  
</body>
</html>