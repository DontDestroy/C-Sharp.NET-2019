//***
// Action
//   - Testroutine for a listbox using instances of cpCountry
// Created
//   - CopyPaste � 20240624 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240624 � VVDW
// Proposal (To Do)
//   - 
//***

using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class frmListBox: System.Windows.Forms.Form
  {

    #region Windows Form Designer generated code
    private System.ComponentModel.Container components = null;
    internal System.Windows.Forms.ListBox lstCountry;
    internal System.Windows.Forms.Label lblFlag;
    internal System.Windows.Forms.TextBox txtSize;
    internal System.Windows.Forms.TextBox txtCapital;
    internal System.Windows.Forms.TextBox txtCountry;
    internal System.Windows.Forms.ListBox lstCapital;

    private void InitializeComponent()
    {
      System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmListBox));
      this.lstCountry = new System.Windows.Forms.ListBox();
      this.lblFlag = new System.Windows.Forms.Label();
      this.txtSize = new System.Windows.Forms.TextBox();
      this.txtCapital = new System.Windows.Forms.TextBox();
      this.txtCountry = new System.Windows.Forms.TextBox();
      this.lstCapital = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // lstCountry
      // 
      this.lstCountry.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
      this.lstCountry.Location = new System.Drawing.Point(16, 16);
      this.lstCountry.Name = "lstCountry";
      this.lstCountry.Size = new System.Drawing.Size(120, 251);
      this.lstCountry.TabIndex = 12;
      this.lstCountry.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.lstCountry_DrawItem);
      this.lstCountry.SelectedIndexChanged += new System.EventHandler(this.ListBox_SelectedIndexChanged);
      // 
      // lblFlag
      // 
      this.lblFlag.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
      this.lblFlag.Location = new System.Drawing.Point(288, 120);
      this.lblFlag.Name = "lblFlag";
      this.lblFlag.Size = new System.Drawing.Size(100, 88);
      this.lblFlag.TabIndex = 11;
      // 
      // txtSize
      // 
      this.txtSize.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.txtSize.Location = new System.Drawing.Point(288, 80);
      this.txtSize.Name = "txtSize";
      this.txtSize.ReadOnly = true;
      this.txtSize.TabIndex = 10;
      this.txtSize.Text = "";
      // 
      // txtCapital
      // 
      this.txtCapital.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.txtCapital.Location = new System.Drawing.Point(288, 48);
      this.txtCapital.Name = "txtCapital";
      this.txtCapital.ReadOnly = true;
      this.txtCapital.TabIndex = 9;
      this.txtCapital.Text = "";
      // 
      // txtCountry
      // 
      this.txtCountry.BorderStyle = System.Windows.Forms.BorderStyle.None;
      this.txtCountry.Location = new System.Drawing.Point(288, 16);
      this.txtCountry.Name = "txtCountry";
      this.txtCountry.ReadOnly = true;
      this.txtCountry.TabIndex = 8;
      this.txtCountry.Text = "";
      // 
      // lstCapital
      // 
      this.lstCapital.Location = new System.Drawing.Point(144, 16);
      this.lstCapital.Name = "lstCapital";
      this.lstCapital.Size = new System.Drawing.Size(120, 251);
      this.lstCapital.Sorted = true;
      this.lstCapital.TabIndex = 7;
      this.lstCapital.SelectedIndexChanged += new System.EventHandler(this.ListBox_SelectedIndexChanged);
      // 
      // frmListBox
      // 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(552, 273);
      this.Controls.Add(this.lstCountry);
      this.Controls.Add(this.lblFlag);
      this.Controls.Add(this.txtSize);
      this.Controls.Add(this.txtCapital);
      this.Controls.Add(this.txtCountry);
      this.Controls.Add(this.lstCapital);
      this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
      this.Name = "frmListBox";
      this.Text = "ListBox";
      this.ResumeLayout(false);

    }
    #endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'frmListBox'
      // Called by
      //   - User action (Closing the form)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240624 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240624 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public frmListBox()
      //***
      // Action
      //   - Create new instance of 'frmListBox'
      //   - Create 4 instances of cpCountry
      //   - Create an array with the 4 countries
      //   - Add the 4 instances to lstCountry
      //   - Add the array to lstCapital
      //   - Show the capital property in the listbox of the capitals
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - cpCountry.New(String, String, Image, Int32)
      //   - InitializeComponent()
      // Created
      //   - CopyPaste � 20240624 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240624 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();

      // Add any initialization after the InitializeComponent() call
      cpCountry cpCountry01 = new cpCountry("Belgium", "Brussels", new Bitmap("Belgium.bmp"), 30258);
      cpCountry cpCountry02 = new cpCountry("Netherlands", "Amsterdam", new Bitmap("Netherlands.bmp"), 41547);
      cpCountry cpCountry03 = new cpCountry("Germany", "Berlin", new Bitmap("Germany.bmp"), 356970);
      cpCountry cpCountry04 = new cpCountry("France", "Paris", new Bitmap("France.bmp"), 544000);

      cpCountry[] arrcpCountry = {cpCountry01, cpCountry02, cpCountry03, cpCountry04};

      lstCountry.Items.Add(cpCountry01);
      lstCountry.Items.Add(cpCountry02);
      lstCountry.Items.Add(cpCountry03);
      lstCountry.Items.Add(cpCountry04);
      lstCapital.Items.AddRange(arrcpCountry);
      lstCapital.DisplayMember = "Capital";
    }
    // frmListBox()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    #region "Controls"
    
    private void ListBox_SelectedIndexChanged(System.Object theSender, System.EventArgs theEventArguments)
      //***
      // Action
      //   - Define the listbox that was selected
      //   - Cast the selected item into a cpCountry
      //   - Show the country information on the screen
      // Called by
      //   - User action (Selecting an item in a listbox)
      // Calls
      //   - Image cpCountry.Flag (Get)
      //   - int cpCountry.Size (Get)
      //   - string cpCountry.Name (Get)
      //   - string cpCountry.Capital (Get)
      // Created
      //   - CopyPaste � 20240624 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240624 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      ListBox theListBox = (ListBox)theSender;
      cpCountry thecpCountry = (cpCountry)theListBox.SelectedItem;

      txtCountry.Text = thecpCountry.Name;
      txtCapital.Text = thecpCountry.Capital;
      txtSize.Text = thecpCountry.Size.ToString();
      lblFlag.Image = thecpCountry.Flag;
    }
    // ListBox_SelectedIndexChanged(System.Object, System.EventArgs) Handles lstCountry.SelectedIndexChanged, lstCapital.SelectedIndexChanged
    
    private void lstCountry_DrawItem(System.Object theSender, System.Windows.Forms.DrawItemEventArgs theDrawItemEventArguments)
      //***
      // Action
      //   - Draw the picture of every country in the listbox
      //   - Define a brush
      //   - Draw the background
      //   - Draw the flag
      // Called by
      //   - User action (Selecting an item in a listbox)
      // Calls
      //   - Image cpCountry.Flag (Get)
      //   - string cpCountry.Name (Get)
      // Created
      //   - CopyPaste � 20240624 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240624 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      Brush theBrush;
      cpCountry theCountry = (cpCountry)lstCountry.Items[theDrawItemEventArguments.Index];

      theDrawItemEventArguments.DrawBackground();
      theDrawItemEventArguments.Graphics.DrawImage(theCountry.Flag, theDrawItemEventArguments.Bounds.Left + 1, theDrawItemEventArguments.Bounds.Top + 1, 8, 8);

      if ((theDrawItemEventArguments.State & DrawItemState.Selected) == DrawItemState.Selected)
      {
        theBrush = Brushes.White;
      }
      else
        // (theDrawItemEventArguments.State And DrawItemState.Selected) <> DrawItemState.Selected)
      {
        theBrush = Brushes.Black;
      }
      // (theDrawItemEventArguments.State And DrawItemState.Selected) = DrawItemState.Selected 

      theDrawItemEventArguments.Graphics.DrawString(theCountry.Name, lstCountry.Font, theBrush, theDrawItemEventArguments.Bounds.Left + 10, theDrawItemEventArguments.Bounds.Top);
    }
    // lstCountry_DrawItem(System.Object, DrawItemEventArgs) Handles lstCountry.DrawItem

    #endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void Main() 
      //***
      // Action
      //   - Start application
      //   - Showing frmListBox
      // Called by
      //   - User action (Starting the application)
      // Calls
      //   - frmListBox()
      // Created
      //   - CopyPaste � 20240624 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240624 � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {
      Application.Run(new frmListBox());
    }
    // Main() 
    
    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // frmListBox

}
// CopyPaste.Learning