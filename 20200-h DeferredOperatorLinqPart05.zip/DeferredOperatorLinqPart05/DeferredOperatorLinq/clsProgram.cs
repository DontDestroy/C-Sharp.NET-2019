﻿//***
// Action
//   - Demo of Grouping with Linq
//   - Keyword GroupBy
// Created
//   - CopyPaste – 20230505 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230505 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.HumanResources;
using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;

namespace DeferredOperatorLinq
{

  public class cpProgram
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static void GroupingSequencePart01()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Grouping operators return an output sequence of elements that is the input sequence grouped by a certain key
    //     - The input sequence is of the form IEnumerable<T>
    //     - The output sequence is of the form IEnumerable<IGrouping<TKey, TElement>>
    //   - GroupBy has 8 overloads (only 1 is used in this example)
    //     - Return the elements of a collection using a keySelector delegate and the elements of the collection defined by the keySelector delegate
    //   - Fill an array with investments (original an array) (the inner collection)
    //   - Group the investments by the key of the employees (Lambda Linq Dot Notation)
    //   - Show result 
    //   - Group the investments by the key of the employees (Linq Fluent Syntax Query Expression)
    //   - Show result 
    // Called by
    //   - Main()
    // Calls
    //   - cpCompany(string)
    //   - cpInvestment[] cpCompany.AllInvestments (Get)
    //   - int cpInvestment.EmployeeNumber (Get)
    //   - ShowContentOfGroupedInvestments(IEnumerable<T>, string)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpCompany theCopyPasteCompany;
      cpInvestment[] arrCopyPasteInvestments;
      IEnumerable<IGrouping<int, cpInvestment>> colResultLambda;
      IEnumerable<IGrouping<int, cpInvestment>> colResultExpression;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      theCopyPasteCompany = new cpCompany("Copy Paste");

      arrCopyPasteInvestments = theCopyPasteCompany.AllInvestments;

      colResultLambda = arrCopyPasteInvestments.GroupBy(anInvestment => anInvestment.EmployeeNumber);
      // GroupBy takes an input sequence and a selector delegates, and returns an object that, when enumerated,
      // enumerates the input sequence, using the key selector for every element in the sequence, and returns a sequence
      // with all elements that has that key selector
      // Key values are compared using EqualityComparerDefault
      // GroupBy is an extension method, so we use it on an instance of a sequence that is enumerable (arrCopyPasteInvestments)
      // GroupBy is creating a list of lists back into the result sequence

      ShowContentOfGroupedInvestments(colResultLambda, "The list of all investments grouped by employee: (Lambda Linq Dot Notation)");

      colResultExpression = from anInvestment in arrCopyPasteInvestments
                            group anInvestment by anInvestment.EmployeeNumber;

      Console.WriteLine();
      ShowContentOfGroupedInvestments(colResultExpression, "The list of all investments grouped by employee: (Linq Fluent Syntax Query Expression)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // GroupingSequencePart01()

    public static void GroupingSequencePart02()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Grouping operators return an output sequence of elements that is the input sequence grouped by a certain key
    //     - The input sequence is of the form IEnumerable<T>
    //     - The output sequence is of the form IEnumerable<IGrouping<TKey, TElement>>
    //   - GroupBy has 8 overloads (only 1 is used in this example)
    //     - Return the elements of a collection using a keySelector delegate and the elements of the collection defined by the keySelector delegate,
    //       using a comparer to check equality (implement IEqualityComparer<T>)
    //   - Fill an array with investments (original an array) (the inner collection)
    //   - Group the investments by being founder or not (Lambda Linq Dot Notation)
    //   - Show result 
    //   - Group the investments by being founder or not (Linq Fluent Syntax Query Expression)
    //   - Show result 
    // Called by
    //   - Main()
    // Calls
    //   - cpCompany(string)
    //   - cpFounderComparer()
    //   - cpFounderComparer.IsFounder()
    //   - cpInvestment[] cpCompany.AllInvestments (Get)
    //   - int cpInvestment.EmployeeNumber (Get)
    //   - ShowContentOfGroupedInvestmentsWithComparer(IEnumerable<IGrouping<int, cpInvestment>>, cpFounderComparer, string)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpCompany theCopyPasteCompany;
      cpInvestment[] arrCopyPasteInvestments;
      IEnumerable<IGrouping<int, cpInvestment>> colResultLambda;
      IEnumerable<IGrouping<bool, cpInvestment>> colResultExpressionCompare;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      theCopyPasteCompany = new cpCompany("Copy Paste");

      arrCopyPasteInvestments = theCopyPasteCompany.AllInvestments;

      cpFounderComparer theComparer = new cpFounderComparer();
      // Instead of instantiating a comparer on the fly, a reference is used
      // because the IsFounder() method on the group's key for header display purposes

      colResultLambda = arrCopyPasteInvestments.GroupBy(anInvestment => anInvestment.EmployeeNumber, theComparer);
      // GroupBy takes an input sequence and a selector delegates, and returns an object that, when enumerated,
      // enumerates the input sequence, using the key selector with a comparer for every element in the sequence, and returns a sequence
      // with all elements that has that key selector that is compared
      // Key values are compared using a selfmade comparer
      // GroupBy is an extension method, so we use it on an instance of a sequence that is enumerable (arrCopyPasteInvestments)
      // GroupBy is creating a list of lists back into the result sequence

      Console.WriteLine();
      ShowContentOfGroupedInvestmentsWithComparer(colResultLambda, theComparer, "The list of all investments grouped by being founder: (Lambda Linq Dot Notation)");

      colResultExpressionCompare = from anInvestment in arrCopyPasteInvestments
                                   group anInvestment by theComparer.IsFounder(anInvestment.EmployeeNumber);

      Console.WriteLine();
      ShowContentOfGroupedInvestmentsWithComparerBool(colResultExpressionCompare, theComparer, "The list of all investments grouped by being founder: (Linq Fluent Syntax Query Expression)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // GroupingSequencePart02()

    public static void GroupingSequencePart03()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Grouping operators return an output sequence of parts of elements that is the input sequence grouped by a certain key
    //     - The input sequence is of the form IEnumerable<T>
    //     - The output sequence is of the form IEnumerable<IGrouping<TKey, TElement>>
    //   - GroupBy has 8 overloads (only 1 is used in this example)
    //     - Return part of the elements of a collection using a keySelector delegate and an elementSelector delegate grouped by the keySelector
    //   - Fill an array with investments (original an array) (the inner collection)
    //   - Group the investments by the key of the employees but return only the dates (Lambda Linq Dot Notation)
    //   - Show result 
    //   - Group the investments by the key of the employees but return only the dates (Linq Fluent Syntax Query Expression)
    //   - Show result 
    // Called by
    //   - Main()
    // Calls
    //   - cpCompany(string)
    //   - cpInvestment[] cpCompany.AllInvestments (Get)
    //   - DateTime cpInvestment.DatePayment (Get)
    //   - int cpInvestment.EmployeeNumber (Get)
    //   - ShowContentOfGroupedInvestmentDates(IEnumerable<IGrouping<int, DateTime>>, string)
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpCompany theCopyPasteCompany;
      cpInvestment[] arrCopyPasteInvestments;
      IEnumerable<IGrouping<int, DateTime>> colResultLambda;
      IEnumerable<IGrouping<int, DateTime>> colResultExpression;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      theCopyPasteCompany = new cpCompany("Copy Paste");

      arrCopyPasteInvestments = theCopyPasteCompany.AllInvestments;

      colResultLambda = arrCopyPasteInvestments.GroupBy(anInvestment => anInvestment.EmployeeNumber, theInvestment => theInvestment.DatePayment);
      // GroupBy takes an input sequence and a selector delegates, and returns an object that, when enumerated,
      // enumerates the input sequence, using the key selector for every element in the sequence, and returns a sequence
      // with only the parts of the elements that is defined in the element selector
      // Key values are compared using EqualityComparerDefault
      // GroupBy is an extension method, so we use it on an instance of a sequence that is enumerable (arrCopyPasteInvestments)
      // GroupBy is creating a list of lists back into the result sequence

      ShowContentOfGroupedInvestmentDates(colResultLambda, "The list of all dates of investments grouped by employee: (Lambda Linq Dot Notation)");

      colResultExpression = from anInvestment in arrCopyPasteInvestments
                            group anInvestment.DatePayment by anInvestment.EmployeeNumber;

      Console.WriteLine();
      ShowContentOfGroupedInvestmentDates(colResultExpression, "The list of all dates of investments grouped by employee: (Linq Fluent Syntax Query Expression)");
      
      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // GroupingSequencePart03()

    public static void GroupingSequencePart04()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Grouping operators return an output sequence of elements that is the input sequence grouped by a certain key
    //     - The input sequence is of the form IEnumerable<T>
    //     - The output sequence is of the form IEnumerable<IGrouping<TKey, TElement>>
    //   - GroupBy has 8 overloads (only 1 is used in this example)
    //     - Return part of the elements of a collection using a keySelector delegate and the elements of the collection defined by the keySelector delegate,
    //       using a comparer to check equality (implement IEqualityComparer<T>)
    //   - Fill an array with investments (original an array) (the inner collection)
    //   - Group the dates of investments by being founder or not (Lambda Linq Dot Notation)
    //   - Show result 
    //   - Group the dates of investments by being founder or not (Linq Fluent Syntax Query Expression)
    //   - Show result 
    // Called by
    //   - Main()
    // Calls
    //   - cpCompany(string)
    //   - cpFounderComparer()
    //   - cpFounderComparer.IsFounder()
    //   - cpInvestment[] cpCompany.AllInvestments (Get)
    //   - int cpInvestment.EmployeeNumber (Get)
    //   - ShowContentOfGroupedInvestmentDatesWithComparer(IEnumerable<IGrouping<int, DateTime>>, cpFounderComparer, string)
    // Created
    //   - CopyPaste – 20230510 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230510 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      cpCompany theCopyPasteCompany;
      cpInvestment[] arrCopyPasteInvestments;
      IEnumerable<IGrouping<int, DateTime>> colResultLambda;
      IEnumerable<IGrouping<bool, DateTime>> colResultExpressionCompare;
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      theCopyPasteCompany = new cpCompany("Copy Paste");

      arrCopyPasteInvestments = theCopyPasteCompany.AllInvestments;

      cpFounderComparer theComparer = new cpFounderComparer();
      // Instead of instantiating a comparer on the fly, a reference is used
      // because the IsFounder() method on the group's key for header display purposes

      colResultLambda = arrCopyPasteInvestments.GroupBy(anInvestment => anInvestment.EmployeeNumber, theInvestment => theInvestment.DatePayment, theComparer);
      // GroupBy takes an input sequence and a selector delegates, and returns an object that, when enumerated,
      // enumerates the input sequence, using the key selector with a comparer for every element in the sequence, and returns a sequence
      // with all elements that has that key selector that is compared
      // Key values are compared using a selfmade comparer
      // GroupBy is an extension method, so we use it on an instance of a sequence that is enumerable (arrCopyPasteInvestments)
      // GroupBy is creating a list of lists back into the result sequence

      Console.WriteLine();
      ShowContentOfGroupedInvestmentDatesWithComparer(colResultLambda, theComparer, "The list of all investment dates grouped by being founder: (Lambda Linq Dot Notation)");

      colResultExpressionCompare = from anInvestment in arrCopyPasteInvestments
                                   group anInvestment.DatePayment by theComparer.IsFounder(anInvestment.EmployeeNumber);

      Console.WriteLine();
      ShowContentOfGroupedInvestmentDatesWithComparerBool(colResultExpressionCompare, theComparer, "The list of all investment dates grouped by being founder: (Lambda Linq Dot Notation)");

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // GroupingSequencePart04()

    public static void Main()
    //***
    // Action
    //   - Study the methods in order
    //   - Try to experiment, your own location to try things out
    //   - Group a sequence on a specific key (4 examples)
    //     - By a key
    //     - By a self created comparer on the key
    //     - By a key and another field
    //     - By a self created comparer on the key and another field
    // Called by
    //   - User action (Starting the application)
    // Calls
    //   - GroupingSequencePart01()
    //   - GroupingSequencePart02()
    //   - GroupingSequencePart03()
    //   - GroupingSequencePart04()
    // Created
    //   - CopyPaste – 20230510 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230510 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - List of actions that can be added to the functionality
    //***
    {
      TryToExperiment();
      // GroupingSequencePart01();
      // GroupingSequencePart02();
      // GroupingSequencePart03();
      // GroupingSequencePart04();
      Console.ReadLine();
    }
    // Main()

    private static void ShowContentOfGroupedInvestmentDates(IEnumerable<IGrouping<int, DateTime>> colSequence, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type IGrouping<int, DateTime> in a sequence (outer elements)
    //     - Loop thru the elements of type IGrouping<int, DateTime> in a sequence (inner elements)
    //     - Show information of the investment dates
    // Called by
    //   - GroupingSequencePart03()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230510 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230510 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine(strTitle);

      foreach (IGrouping<int, DateTime> anOuterElement in colSequence)
      {
        Console.WriteLine("Investments of employee: {0}", anOuterElement.Key);

        foreach (DateTime aDate in anOuterElement)
        {
          Console.WriteLine("Investment Date: {0}", aDate.ToShortDateString());
        }
        // in anOuterElement

      }
      // in colSequence

    }
    // ShowContentOfGroupedInvestmentDates(IEnumerable<IGrouping<int, DateTime>>, string)

    private static void ShowContentOfGroupedInvestmentDatesWithComparer(IEnumerable<IGrouping<int, DateTime>> colSequence, cpFounderComparer theComparer, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type IGrouping<int, DateTime> in a sequence (outer elements)
    //     - Show information of the comparer used
    //     - Loop thru the elements of type IGrouping<int, DateTime> in a sequence (inner elements)
    //     - Show dates of the investment
    // Called by
    //   - GroupingSequencePart02()
    // Calls
    //   - bool cpFounderComparer.IsFounder(int)
    //   - DateTime cpInvestment.DatePayment (Get)
    //   - int cpInvestment.EmployeeNumber (Get)
    //   - long cpInvestment.Amount (Get)
    // Created
    //   - CopyPaste – 20230505 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230505 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strGroupInfo;

      Console.WriteLine(strTitle);

      foreach (IGrouping<int, DateTime> anOuterElement in colSequence)
      {

        if (theComparer.IsFounder(anOuterElement.Key))
        {
          strGroupInfo = "founder";
        }
        else
        // Not theComparer.IsFounder(anOuterElement.Key)
        {
          strGroupInfo = "non-founder";
        }
        // theComparer.IsFounder(anOuterElement.Key)

        Console.WriteLine("Investments for: {0}", strGroupInfo);

        foreach (DateTime aDate in anOuterElement)
        {
          Console.WriteLine("Investment Date: {0}", aDate);
        }
        // in anOuterElement

      }
      // in colSequence

    }
    // ShowContentOfGroupedInvestmentDatesWithComparer(IEnumerable<IGrouping<int, DateTime>>, cpFounderComparer, string)

    private static void ShowContentOfGroupedInvestmentDatesWithComparerBool(IEnumerable<IGrouping<bool, DateTime>> colSequence, cpFounderComparer theComparer, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type IGrouping<bool, DateTime> in a sequence (outer elements)
    //     - Show information of the comparer used
    //     - Loop thru the elements of type IGrouping<bool, DateTime> in a sequence (inner elements)
    //     - Show date of the investment
    // Called by
    //   - GroupingSequencePart04()
    // Calls
    //   - bool cpFounderComparer.IsFounder(int)
    //   - DateTime cpInvestment.DatePayment (Get)
    //   - int cpInvestment.EmployeeNumber (Get)
    //   - long cpInvestment.Amount (Get)
    // Created
    //   - CopyPaste – 20230510 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230510 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strGroupInfo;

      Console.WriteLine(strTitle);

      foreach (IGrouping<bool, DateTime> anOuterElement in colSequence)
      {

        if (anOuterElement.Key)
        {
          strGroupInfo = "founder";
        }
        else
        // Not anOuterElement.Key
        {
          strGroupInfo = "non-founder";
        }
        // anOuterElement.Key

        Console.WriteLine("Investments for: {0}", strGroupInfo);

        foreach (DateTime aDate in anOuterElement)
        {
          Console.WriteLine("Investment Dates: {0}", aDate);
        }
        // in anOuterElement

      }
      // in colSequence

    }
    // ShowContentOfGroupedInvestmentDatesWithComparerBool(IEnumerable<IGrouping<bool, DateTime>>, cpFounderComparer, string)

    private static void ShowContentOfGroupedInvestments(IEnumerable<IGrouping<int, cpInvestment>> colSequence, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type IGrouping<int, cpInvestment> in a sequence (outer elements)
    //     - Loop thru the elements of type IGrouping<int, cpInvestment> in a sequence (inner elements)
    //     - Show information of the investment
    // Called by
    //   - GroupingSequencePart01()
    // Calls
    //   - DateTime cpInvestment.DatePayment (Get)
    //   - int cpInvestment.EmployeeNumber (Get)
    //   - long cpInvestment.Amount (Get)
    // Created
    //   - CopyPaste – 20230505 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230505 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Console.WriteLine(strTitle);

      foreach (IGrouping<int, cpInvestment> anOuterElement in colSequence)
      {
        Console.WriteLine("Investments of employee: {0}", anOuterElement.Key);

        foreach (cpInvestment anInnerElement in anOuterElement)
        {
          Console.WriteLine("Employee: {0} - Amount: {1} - Date: {2}", anInnerElement.EmployeeNumber, anInnerElement.Amount, anInnerElement.DatePayment);
        }
        // in anOuterElement

      }
      // in colSequence

    }
    // ShowContentOfGroupedInvestments(IEnumerable<IGrouping<int, cpInvestment>>, string)

    private static void ShowContentOfGroupedInvestmentsWithComparer(IEnumerable<IGrouping<int, cpInvestment>> colSequence, cpFounderComparer theComparer, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type IGrouping<int, cpInvestment> in a sequence (outer elements)
    //     - Show information of the comparer used
    //     - Loop thru the elements of type IGrouping<int, cpInvestment> in a sequence (inner elements)
    //     - Show information of the investment
    // Called by
    //   - GroupingSequencePart02()
    // Calls
    //   - bool cpFounderComparer.IsFounder(int)
    //   - DateTime cpInvestment.DatePayment (Get)
    //   - int cpInvestment.EmployeeNumber (Get)
    //   - long cpInvestment.Amount (Get)
    // Created
    //   - CopyPaste – 20230505 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230505 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strGroupInfo;

      Console.WriteLine(strTitle);

      foreach (IGrouping<int, cpInvestment> anOuterElement in colSequence)
      {

        if (theComparer.IsFounder(anOuterElement.Key))
        {
          strGroupInfo = "founder";
        }
        else
        // Not theComparer.IsFounder(anOuterElement.Key)
        {
          strGroupInfo = "non-founder";
        }
        // theComparer.IsFounder(anOuterElement.Key)

        Console.WriteLine("Investments for: {0}", strGroupInfo);

        foreach (cpInvestment anInnerElement in anOuterElement)
        {
          Console.WriteLine("Employee: {0} - Amount: {1} - Date: {2}", anInnerElement.EmployeeNumber, anInnerElement.Amount, anInnerElement.DatePayment);
        }
        // in anOuterElement

      }
      // in colSequence

    }
    // ShowContentOfGroupedInvestmentsWithComparer(IEnumerable<IGrouping<int, cpInvestment>>, cpFounderComparer, string)

    private static void ShowContentOfGroupedInvestmentsWithComparerBool(IEnumerable<IGrouping<bool, cpInvestment>> colSequence, cpFounderComparer theComparer, string strTitle)
    //***
    // Action
    //   - Loop thru the elements of type IGrouping<bool, cpInvestment> in a sequence (outer elements)
    //     - Show information of the comparer used
    //     - Loop thru the elements of type IGrouping<bool, cpInvestment> in a sequence (inner elements)
    //     - Show information of the investment
    // Called by
    //   - GroupingSequencePart02()
    // Calls
    //   - bool cpFounderComparer.IsFounder(int)
    //   - DateTime cpInvestment.DatePayment (Get)
    //   - int cpInvestment.EmployeeNumber (Get)
    //   - long cpInvestment.Amount (Get)
    // Created
    //   - CopyPaste – 20230505 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230505 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strGroupInfo;

      Console.WriteLine(strTitle);

      foreach (IGrouping<bool, cpInvestment> anOuterElement in colSequence)
      {

        if (anOuterElement.Key)
        {
          strGroupInfo = "founder";
        }
        else
        // Not anOuterElement.Key
        {
          strGroupInfo = "non-founder";
        }
        // anOuterElement.Key

        Console.WriteLine("Investments for: {0}", strGroupInfo);

        foreach (cpInvestment anInnerElement in anOuterElement)
        {
          Console.WriteLine("Employee: {0} - Amount: {1} - Date: {2}", anInnerElement.EmployeeNumber, anInnerElement.Amount, anInnerElement.DatePayment);
        }
        // in anOuterElement

      }
      // in colSequence

    }
    // ShowContentOfGroupedInvestmentsWithComparerBool(IEnumerable<IGrouping<bool, cpInvestment>>, cpFounderComparer, string)

    public static void TryToExperiment()
    //***
    // Action
    //   - There is a stacktrace shown for demo purposes at the beginning and at the end
    //   - Method used for experimenting
    // Called by
    //   - Main()
    // Calls
    //   - 
    // Created
    //   - CopyPaste – 20230502 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230502 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      string strCurrentMethodName;

      strCurrentMethodName = new StackTrace(0, true).GetFrame(0).GetMethod().Name;
      Console.WriteLine("Begin: {0}\n", strCurrentMethodName);

      //  Do your stuff here

      Console.WriteLine("\nEnd: {0}\n\n", strCurrentMethodName);
    }
    // TryToExperiment()

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion  

  }
  // cpProgram

}
// DeferredOperatorLinq