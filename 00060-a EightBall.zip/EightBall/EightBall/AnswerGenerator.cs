//***
// Action
//   - Generate a randow answer
// Created
//   - CopyPaste � 20220813 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20220813 � VVDW
// Proposal (To Do)
//   -
//***

using System;
using System.Collections.Generic;
using System.Text;

namespace EightBall
{

  public class AnswerGenerator
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    string[] arrAnswers = new string[]
    {
        "Ask Again later",
        "Can Not Predict Now",
        "Without a Doubt", 
        "Is Decidely So",
        "Concentrate and Ask Again",
        "My Sources Say No",
        "Yes, Definitely",
        "Don't Count On It",
        "Signs Point to Yes",
        "Better Not Tell You Now",
        "Outlook Not So Good",
        "Most Likely",
        "Very Doubtful",
        "As I See It, Yes",
        "My Reply is No",
        "It Is Certain",
        "Yes",
        "You May Rely On It",
        "Outlook Good",
        "Reply Hazy Try Again"
    };

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public string GetRandomAnswer(string strQuestion)
    //***
    // Action
    //   - Get randomly an answer out of arrAnswers
    // Called by
    //   - cmdAnswer_Click(System.Object, System.Windows.RoutedEventArgs) Handles cmdAnswer.Click
    // Calls
    //   - 
    // Created
    //   - CopyPaste � 20220813 � VVDW
    // Changed
    //   - CopyPaste � yyyymmdd � VVDW � What changed
    // Tested
    //   - CopyPaste � 20220813 � VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      Random aRandom = new Random();

      return arrAnswers[aRandom.Next(0, arrAnswers.Length)];
    }
    // string GetRandomAnswer(string)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // AnswerGenerator

}
// EightBall