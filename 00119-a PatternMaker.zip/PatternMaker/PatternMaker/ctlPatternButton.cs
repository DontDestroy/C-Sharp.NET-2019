//***
// Action
//   - Pattern button inherits from UserControl
//     - It can be placed at runtime on the form
//   - It is a visualisation of a cpPattern
// Created
//   - CopyPaste � 20240330 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240330 � VVDW
// Proposal (To Do)
//   -
//***

using System.Drawing;
using System.Windows.Forms;

namespace CopyPaste.Learning
{

  public class cpctlPatternButton : System.Windows.Forms.UserControl
	{

    private System.ComponentModel.Container components = null;

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			components = new System.ComponentModel.Container();
		}
		#endregion

    #region "Constructors / Destructors"

    protected override void Dispose(bool disposing)
      //***
      // Action
      //   - Clean up instance of 'cpctlPatternButton'
      // Called by
      //   - User action (Closing the control)
      // Calls
      //   - 
      // Created
      //   - CopyPaste � yyyymmdd � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � yyyymmdd � VVDW
      // Keyboard key
      //   - 
      // Proposal (To Do)
      //   - 
      //***
    {

      if(disposing)
      {

        if (components == null) 
        {
        }
        else
          // (components != null)
        {
          components.Dispose();
        }
        // (components == null)
      
      }
      else
        // Not disposing
      {
      }
      // disposing

      base.Dispose(disposing);
    }
    // Dispose(bool)

    public cpctlPatternButton(cpPattern thePattern)
      //***
      // Action
      //   - Create new instance of 'cpctlPatternButton'
      //   - The control has a size of 61 by 61 pixels
      //   - A cpPattern is assigned to it
      //   - The paint event triggers the cpDraw method
      // Called by
      //   - frmPatternMaker.frmPatternMaker_Load(System.Object, System.EventArgs) Handles this.Load
      //   - frmPatternMaker.PatternSaved(System.Object, System.EventArgs)
      //   - User action (Starting the control)
      // Calls
      //   - cpDraw(System.Object, System.Windows.Forms.PaintEventArgs)
      //   - InitializeComponent()
      //   - cpPattern Pattern (Get)
      //   - Pattern(cpPattern) (Set)
      // Created
      //   - CopyPaste � 20240330 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240330 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      InitializeComponent();

      this.Size = new Size(61, 61);
      Pattern = thePattern;
      this.Paint += new PaintEventHandler(Pattern.cpDraw);
    }
    // cpctlPatternButton()

    #endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"
    
    cpPattern mcpPattern;

    #endregion

    #region "Properties"

    public cpPattern Pattern
    {

      get
        //***
        // Action
        //   - Returns the cpPattern of the cpctlPatternButton
        // Called by
        //   - cpctlPatternButton(cpPattern)
        //   - frmPatternMaker.TemplateClick(System.Object, System.EventArgs)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240330 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240330 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        return mcpPattern;
      }
      // cpPattern Pattern (Get)

      set
        //***
        // Action
        //   - The cpPattern of the cpctlPatternButton becomes theValue
        // Called by
        //   - cpctlPatternButton(cpPattern)
        // Calls
        //   - 
        // Created
        //   - CopyPaste � 20240330 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240330 � VVDW
        // Keyboard key
        //   -
        // Proposal (To Do)
        //   -
        //***
      {
        mcpPattern = value;
      }
      // Pattern(cpPattern) (Set)

    }
    // cpPattern Pattern

    #endregion

    //#region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    //#region "Functionality"

    //#region "Event"
    //#endregion

    //#region "Sub / Function"
    //#endregion

    //#endregion

    //#endregion

    //#region "Not used"
    //#endregion

  }
  // cpctlPatternButton

}
// CopyPaste.Learning
