﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="wfrmCalendar.aspx.cs" Inherits="CopyPaste.Learning.wfrmCalendar" %>

<!DOCTYPE html>

<html lang="en" xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Calendar</title>
</head>
<body>
  <form id="wfrmCalendar" method="post" runat="server">
    <asp:Calendar ID="calDate" Style="z-index: 101; position: absolute; top: 40px; left: 56px" runat="server"
      Width="336px" SelectionMode="DayWeekMonth" FirstDayOfWeek="Monday">
      <TodayDayStyle BorderWidth="1px" BorderColor="Black" BackColor="Yellow"></TodayDayStyle>
      <DayStyle BackColor="Khaki"></DayStyle>
      <DayHeaderStyle BackColor="LightSteelBlue"></DayHeaderStyle>
      <OtherMonthDayStyle BackColor="LightSalmon"></OtherMonthDayStyle>
    </asp:Calendar>
    <asp:ListBox ID="lstDataSelected" Style="z-index: 103; position: absolute; top: 96px; left: 424px"
      runat="server" Width="248px" Height="136px"></asp:ListBox>
    <asp:Label ID="lblDate" Style="z-index: 102; position: absolute; top: 48px; left: 424px" runat="server"></asp:Label>
  </form>
</body>
</html>
