﻿//***
// Action
//   - Entity Type Configuration, used in the method OnModelCreating()
//   - This only works for Entity FrameWork Core (version 2.0 and later)
// Created
//   - CopyPaste – 20230714 – VVDW
// Changed
//   - CopyPaste – yyyymmdd – VVDW – What changed
// Tested
//   - CopyPaste – 20230714 – VVDW
// Proposal (To Do)
//   -
//***

using CopyPaste.BusinessObjects;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace CopyPaste.DataAccess
{

  public class cpFlightEntityTypeConfiguration : IEntityTypeConfiguration<Flight>
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    //#region "Fields"
    //#endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public void Configure(EntityTypeBuilder<Flight> theFligth)
    //***
    // Action
    //   - Configuration that is used in OnModelCreating
    //   - There are no other comments, the comments are the same as in syntax 01
    // Called by
    //   - ModelBuilder.ApplyConfiguration<Flight>(new cpFlightEntityTypeConfiguration())
    // Calls
    //   - DateTime Flight.Date (Get)
    //   - int Flight.FlightNo (Get)
    //   - short Flight.FreeSeats (Get)
    //   - short Flight.Seats (Get)
    //   - string Flight.Departure (Get)
    //   - string Flight.Destination (Get)
    //   - string Flight.Memo (Get)
    // Created
    //   - CopyPaste – 20230714 – VVDW
    // Changed
    //   - CopyPaste – yyyymmdd – VVDW – What changed
    // Tested
    //   - CopyPaste – 20230714 – VVDW
    // Keyboard key
    //   - 
    // Proposal (To Do)
    //   - 
    //***
    {
      theFligth.HasKey(theFlight => theFlight.FlightNo);
      theFligth.Property(theFlight => theFlight.Memo).HasMaxLength(4000);
      theFligth.Property(theFlight => theFlight.Seats).IsRequired();
      theFligth.Property(theFlight => theFlight.Destination).HasDefaultValue("(not set)");
      theFligth.Property(theFlight => theFlight.Date).HasDefaultValueSql("getdate()");
      theFligth.HasIndex(theFlight => theFlight.FreeSeats).HasDatabaseName("IndexFreeSeats");
      theFligth.HasIndex(theFlight => new { theFlight.Departure, theFlight.Destination }).HasDatabaseName("IndexFromTo");
    }
    // Configure(EntityTypeBuilder<Flight>)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpFlightEntityTypeConfiguration

}
// CopyPaste.DataAccess