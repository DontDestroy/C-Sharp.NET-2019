//***
// Action
//   - Global variables
// Created
//   - CopyPaste � 20240411 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240411 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace CopyPaste.Learning
{

  public class cpGlobal
  {

    //#region "Constructors / Destructors"
    //#endregion

    //#region "Designer"
    //#endregion

    //#region "Structures"
    //#endregion

    #region "Fields"

    public static short mshtWins = 0;
    public static int mlngCount = 0;
    public static Random mrndRandom = new Random(DateTime.Now.Millisecond);

    #endregion

    //#region "Properties"
    //#endregion

    #region "Methods"

    //#region "Overrides"
    //#endregion

    //#region "Controls"
    //#endregion

    #region "Functionality"

    //#region "Event"
    //#endregion

    #region "Sub / Function"

    public static string strProcent(short shtHits, int lngTries)
      //***
      // Action
      //   - Divide the number of hits by the number of tries
      //   - Convert the result to a single
      //   - Return the result as text as percentage with 2 decimals
      // Called by
      //   - frmSlotMachineLuckySeven.cmdNewAttempt_Click(System.Object, System.EventArgs) Handles cmdNewAttempt.Click
      // Calls
      //   - 
      // Created
      //   - CopyPaste � 20240411 � VVDW
      // Changed
      //   - CopyPaste � yyyymmdd � VVDW � What changed
      // Tested
      //   - CopyPaste � 20240411 � VVDW
      // Keyboard key
      //   -
      // Proposal (To Do)
      //   -
      //***
    {
      float fltPercent;

      fltPercent = Convert.ToSingle(shtHits / (float)lngTries);
      return fltPercent.ToString("0.00%");
    }
    // string strProcent(short, int)

    #endregion

    #endregion

    #endregion

    //#region "Not used"
    //#endregion

  }
  // cpGlobal

}
// CopyPaste.Learning