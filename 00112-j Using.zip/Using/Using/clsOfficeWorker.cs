//***
// Action
//   - Implementation of a cpOfficeWorker
//   - Inherits from cpEmployee
// Created
//   - CopyPaste � 20240410 � VVDW
// Changed
//   - CopyPaste � yyyymmdd � VVDW � What changed
// Tested
//   - CopyPaste � 20240410 � VVDW
// Proposal (To Do)
//   -
//***

using System;

namespace Company
{

  namespace Personel
  {

    public class cpOfficeWorker : cpEmployee
    {

      #region "Constructors / Destructors"

      public cpOfficeWorker(string strName) : base(strName)
        //***
        // Action
        //   - Constructor with Name
        // Called by
        //   - cpProgram.Main()
        //   - cpManager(string)
        // Calls
        //   - cpEmployee(string)
        // Created
        //   - CopyPaste � 20240410 � VVDW
        // Changed
        //   - CopyPaste � yyyymmdd � VVDW � What changed
        // Tested
        //   - CopyPaste � 20240410 � VVDW
        // Keyboard key
        //   - 
        // Proposal (To Do)
        //   - 
        //***
      {
      }
      // cpOfficeWorker(string)
   
      #endregion

      //#region "Designer"
      //#endregion

      //#region "Structures"
      //#endregion

      #region "Fields"

      private decimal mdecEarnings = 2900M;

      #endregion

      #region "Properties"

      public override decimal Amount
      {

        get
          //***
          // Action Get
          //   - Returns 12 times the monthly earnings
          //     - 12 is the estimated number of months an office worker works every year
          // Called by
          //   - cpProgram.Main()
          //   - decimal cpManager.Amount (Get)
          // Calls
          //   - 
          // Created
          //   - CopyPaste � 20240410 � VVDW
          // Changed
          //   - CopyPaste � yyyymmdd � VVDW � What changed
          // Tested
          //   - CopyPaste � 20240410 � VVDW
          // Keyboard key
          //   - 
          // Proposal (To Do)
          //   - 
          //***
        {
          return mdecEarnings * 12;
        }
        // decimal Amount (Get)

      }
      // decimal Amount

      #endregion

      //#region "Methods"

      //#region "Overrides"
      //#endregion

      //#region "Controls"
      //#endregion

      //#region "Functionality"

      //#region "Event"
      //#endregion

      //#region "Sub / Function"
      //#endregion

      //#endregion

      //#endregion

      //#region "Not used"
      //#endregion

    }
    // cpOfficeWorker

  }
  // Personel

}
// Company